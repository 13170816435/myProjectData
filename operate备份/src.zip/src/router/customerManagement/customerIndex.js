import Layout from '@/layout/index'
import LayoutBlank from '@/layout/indexBlank'
import personCenterLayout from '@/layout/personCenterLayout'

var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
export default [
  {
    path: basepath + '/CustomerManagement',
    component: Layout,
    name: 'CustomerHome',
    redirect: basepath + '/CustomerManagement/customerIndex',
    children: [
      {
        path: 'customerIndex',
        name: 'customerIndex',
        component: () => import('@/views/CustomerManagement/customerIndex/index.vue'),
        meta: {title: '首页'}
      }
    ]
  },
  {
    path: basepath + '/largeModel',
    component: LayoutBlank,
    name: 'largeModel',
    redirect: basepath + '/largeModel/index',
    children: [
      {
        path: 'index',
        name: 'largeModelIndex',
        component: () => import('@/views/PlatformOperation/largeModel/index.vue'),
        meta: {title: '大模型'}
      }
    ]
  },
  {
    path: basepath + '/personCenter',
    component: Layout,
    name: 'personCenter',
    redirect: basepath + '/personCenter/index',
    children: [
      {
        path: 'index',
        name: 'personCenterIndex',
        component: () => import('@/views/personCenter/index.vue'),
        meta: {title: '个人中心', icon: 'el-icon-s-release'}
      },
    ]
  },
  {
    path: basepath + '/myPersonCenter/index',
    component: personCenterLayout,
    name: 'myPersonCenter',
    redirect: basepath + '/accountInfor/index',
    // children: [
    //   {
    //     path: 'index',
    //     name: 'personCenterIndex',
    //     component: () => import('@/views/personCenter/index.vue'),
    //     meta: { title: '个人中心', icon: 'el-icon-s-release' }
    //   },
    // ]
  },
  {
    path: basepath + '/accountInfor',
    component: personCenterLayout,
    name: 'personAccountInfor',
    redirect: basepath + '/accountInfor/index',
    children: [
      {
        path: 'index',
        name: 'accountIndex',
        component: () => import('@/views/personCenter/index.vue'),
        meta: {title: '账号信息', icon: 'el-icon-s-release'}
      },
    ]
  },
  {
    path: basepath + '/safetySet',
    component: personCenterLayout,
    name: 'personSafetySet',
    redirect: basepath + '/safetySet/index',
    children: [
      {
        path: 'index',
        name: 'safetyIndex',
        component: () => import('@/views/personCenter/index.vue'),
        meta: {title: '安全设置', icon: 'el-icon-s-release'}
      },
    ]
  },
  {
    path: basepath + '/personalRole',
    component: personCenterLayout,
    name: 'personalRole',
    redirect: basepath + '/personalRole/index',
    children: [
      {
        path: 'index',
        name: 'roleIndex',
        component: () => import('@/views/personCenter/index.vue'),
        meta: {title: '角色管理', icon: 'el-icon-s-release'}
      },
    ]
  },
  {
    path: basepath + '/CustomerManagement',
    component: Layout,
    name: 'PlatformSetting',
    redirect: basepath + '/CustomerManagement/platformInfo',
    hidden: true,
    children: [
      {
        path: 'platformInfo',
        name: 'CustomerPlatformInfo',
        component: () => import('@/views/CustomerManagement/platformsettings/platforminfo.vue'),
        meta: {title: '平台信息', icon: 'el-icon-s-release'}
      },
      {
        path: 'parameterSetting',
        name: 'CustomerParameterSetting',
        component: () => import('@/views/CustomerManagement/platformsettings/paramstersetting.vue'),
        meta: {title: '参数设置', icon: 'el-icon-s-release'}
      },
      {
        path: 'basicCapability',
        name: 'basicCapability',
        component: () => import('@/views/CustomerManagement/externalCapability/basicCapability.vue'),
        meta: {title: '外部能力', icon: 'el-icon-s-release'}
      },
      {
        path: 'intelligentServices',
        name: 'customerIntelligentServices',
        component: () => import('@/views/PlatformOperation/intelligentServices/index.vue'),
        meta: { title: '智能服务', icon: 'el-icon-s-release', role:'tenancy' }
      },
      {
        path: 'addFrontEndProcessor',
        name: 'addFrontEndProcessor',
        component: () => import('@/views/PlatformOperation/intelligentServices/frontEndProcessorManagement/addFrontEndProcessor.vue'),
        meta: { title: '添加前置机', icon: 'el-icon-s-release', role:'tenancy' }
      },
      // {
      //   path: 'ExternalCapabilities',
      //   name: 'ExternalCapabilities',
      //   component: () => import('@/views/CustomerManagement/platformsettings/externalcapabilities.vue'),
      //   meta: { title: '外部能力', icon: 'el-icon-s-release' }
      // }
    ]
  },
  {
    path: basepath + '/CustomerUser',
    component: Layout,
    name: 'CustomerUser',
    redirect: basepath + '/CustomerUser/userList',
    children: [
      {
        path: 'userList',
        name: 'CustomerUserlist',
        component: () => import('@/views/CustomerManagement/user/index.vue'),
        meta: {title: '用户列表'}
      },
      {
        path: 'institutionsUserList',
        name: 'institutionsUserList',
        component: () => import('@/views/CustomerManagement/user/index.vue'),
        meta: {title: '用户账号', module: 'institutions',}
      },
      {
        path: 'jurisdictionGroup', // 权限用户组,用户列表
        name: 'CustomerJurisdictionGroup',
        meta: { title: '用户授权'},
        component: () => import('@/views/CustomerManagement/user/jurisdiction_groupindex.vue')
      }
    ]
  },
  {
    path: basepath + '/MedicalInstitution',
    component: Layout,
    name: 'MedicalInstitution',
    redirect: basepath + '/MedicalInstitution/institutionList',
    children: [
      {
        path: 'institutionList',
        name: 'institutionList',
        component: () => import('@/views/CustomerManagement/medicalinstitution/index.vue'),
        meta: {title: '医疗机构', icon: 'el-icon-s-release'}
      },
      {
        path: 'addOrgain',
        name: 'addOrgain',
        component: () => import('@/views/CustomerManagement/medicalinstitution/addorgan.vue'),
        meta: { title: '新增/编辑医疗机构或院区', icon: 'el-icon-s-release' }
      },
      {
        path: 'departmentList',
        name: 'departmentTableList',
        component: () => import('@/views/CustomerManagement/departmentManagement/departmentList.vue'),
        meta: {title: '科室管理', icon: 'el-icon-s-release'}
      },

      {
        path: 'register',
        name: 'institutionRegister',
        component: () => import('@/views/CustomerManagement/medicalinstitution/institution-register/index.vue'),
        meta: {title: '机构注册'}
      }
    ]
  },
  {
    path: basepath + '/runManage',
    component: Layout,
    name: 'runManage',
    redirect: basepath + 'runManage/trainingCondition',
    children: [
      {
        path: 'trainingCondition',
        name: 'trainingCondition',
        component: () => import('@/views/CustomerManagement/runManage/trainingCondition.vue'),
        meta: {title: '培训情况', icon: 'el-icon-s-release'}
      },
      {
        path: 'consultationCondition',
        name: 'consultationCondition',
        component: () => import('@/views/CustomerManagement/runManage/consultationCondition.vue'),
        meta: {title: '会诊情况', icon: 'el-icon-s-release'}
      },
      {
        path: 'referralCondition',
        name: 'referralCondition',
        component: () => import('@/views/CustomerManagement/runManage/referralCondition.vue'),
        meta: {title: '转诊情况', icon: 'el-icon-s-release'}
      },
      {
        path: 'diagnosisCondition',
        name: 'diagnosisCondition',
        component: () => import('@/views/CustomerManagement/runManage/diagnosisCondition.vue'),
        meta: {title: '诊断情况', icon: 'el-icon-s-release'}
      }
    ]
  },
  {
    path: basepath + '/CustomerManagement',
    component: Layout,
    name: 'DepartmentInfo',
    redirect: basepath + '/CustomerManagement/departmentList',
    children: [
      {
        path: 'departmentList',
        name: 'departmentList',
        component: () => import('@/views/CustomerManagement/departmentManagement/departmentList.vue'),
        meta: {title: '科室管理', icon: 'el-icon-s-release'}
      }
    ]
  },
  {
    path: basepath + '/CustomerManagement',
    component: Layout,
    name: 'PACS',
    redirect: basepath + '/CustomerManagement/pacsList',
    children: [
      {
        path: 'pacsList',
        name: 'pacsList',
        component: () => import('@/views/CustomerManagement/PACSsystem/pacs_list.vue'),
        meta: {title: 'PACS系统', icon: 'el-icon-s-release'}
      }
    ]
  },
  {
    path: basepath + '/applicationSystem',
    component: Layout,
    name: 'applicationSystem',
    redirect: basepath + '/applicationSystem/index',
    children: [
      {
        path: 'index',
        name: 'applicationSystemIndex',
        component: () => import('@/views/CustomerManagement/applicationSystem/index.vue'),
        meta: {title: '应用系统', icon: 'el-icon-s-release'}
      }
    ]
  },
  {
    path: basepath + '/CustomerManagement',
    component: Layout,
    name: 'CustomerManagement',
    redirect: basepath + '/CustomerManagement/aim',
    children: [
      {
        path: 'aim',
        name: 'aim',
        component: () => import('@/views/CustomerManagement/aim/index.vue'),
        meta: {title: '智能诊断', icon: 'el-icon-s-release'}
      }
    ]
  },
  {
    path: basepath + '/CustomerManagement',
    component: Layout,
    name: 'intelligenceOffice',
    redirect: basepath + '/CustomerManagement/intelligenceOfficeList',
    children: [
      {
        path: 'intelligenceOfficeList',
        name: 'intelligenceOfficeList',
        component: () => import('@/views/CustomerManagement/intelligenceOffice/intelligenceOfficeList.vue'),
        meta: {title: '智能科室', icon: 'el-icon-s-release'}
      }
    ]
  },
  {
    path: basepath + '/CustomerManagement',
    component: Layout,
    name: 'gatherAppointment',
    redirect: basepath + '/CustomerManagement/ewcssList',
    children: [
      {
        path: 'ewcssList',
        name: 'ewcssList',
        component: () => import('@/views/CustomerManagement/Ewcss/ewcssList.vue'),
        meta: {title: '集中预约', icon: 'el-icon-s-release'}
      }
    ]
  },
  {
    path: basepath + '/CustomerManagement',
    component: Layout,
    name: 'ImageSharing',
    redirect: basepath + '/CustomerManagement/imageJurisdictionList',
    children: [
      {
        path: 'imageJurisdictionList',
        name: 'imageJurisdictionList',
        component: () => import('@/views/CustomerManagement/imageSharing/index.vue'),
        meta: {title: '影像共享系统'}
      }
    ]
  },
  {
    path: basepath + '/CustomerManagement',
    component: Layout,
    name: 'imageControlSystem',
    redirect: basepath + '/CustomerManagement/imageControlSystemList',
    children: [
      {
        path: 'imageControlSystemList',
        name: 'imageControlSystemList',
        component: () => import('@/views/CustomerManagement/imageControlSystem/index.vue'),
        meta: {title: '影像质控'}
      }
    ]
  },
  // 影像大数据
  {
    path: basepath + '/CustomerManagement',
    component: Layout,
    name: 'customerImageBigDataList',
    redirect: basepath + '/CustomerManagement/imageBigDataList',
    children: [
      {
        path: 'imageBigDataList',
        name: 'imageBigDataList',
        component: () => import('@/views/CustomerManagement/imageBigData/imageBigDataList.vue'),
        meta: {title: '影像大数据', icon: 'el-icon-s-release'}
      }
    ]
  },
  {
    path: basepath + '/interfaceService',
    component: Layout,
    name: 'interfaceService',
    redirect: basepath + '/interfaceService/serviceDefinition',
    children: [
      {
        path: 'serviceDefinition',
        name: 'serviceDefinition',
        component: () => import('@/views/CustomerManagement/interfaceService/index.vue'),
        meta: {title: '服务定义'}
      },
      {
        path: 'interfaceLog',
        name: 'interfaceLog',
        component: () => import('@/views/CustomerManagement/interfaceService/interfaceLog.vue'),
        meta: { title: '服务跟踪' }
      },
      {
        path: 'interfaceParamSet',
        name: 'interfaceParamSet',
        component: () => import('@/views/CustomerManagement/interfaceService/interfaceParamSet.vue'),
        meta: {title: '服务配置'}
      },
    ]
  },
  {
    path: basepath + '/distanceTeaching',
    component: Layout,
    name: 'distanceTeachingSystem',
    redirect: basepath + '/distanceTeaching/distanceTeachingList',
    children: [
      {
        path: 'distanceTeachingList',
        name: 'distanceTeachingList',
        component: () => import('@/views/CustomerManagement/distanceTeaching/index.vue'),
        meta: {title: '教学中心'}
      },
      {
        path: 'contractedHospita',
        name: 'contractedHospita',
        component: () => import('@/views/CustomerManagement/distanceTeaching/contractedHospita.vue'),
        meta: {title: '签约医院'}
      },
      {
        path: 'contractedTeacher',
        name: 'contractedTeacher',
        component: () => import('@/views/CustomerManagement/distanceTeaching/contractedTeacher.vue'),
        meta: {title: '签约讲师'}
      }
    ]
  },
  // {
  //   path: '/authorization',
  //   component: Layout,
  //   name: 'authorization',
  //   redirect: '/authorization/myServiceAuthorize',
  //   hidden: true,
  //   children: [
  //     {
  //       path: 'myServiceAuthorize',
  //       name: 'myServiceAuthorize',
  //       component: () => import('@/views/CustomerManagement/service/myServiceAuthorize.vue'),
  //       meta: { title: '服务授权', icon: 'el-icon-s-release' }
  //     }
  //   ]
  // },
  // 远程医疗
  {
    path: basepath + '/telemedicine',
    component: Layout,
    name: 'telemedicine',
    redirect: basepath + '/telemedicine/servicecenter',
    children: [
      {
        path: 'servicecenter',
        name: 'servicecenter',
        component: () => import('@/views/CustomerManagement/telemedicine/servicecenter.vue'),
        meta: {title: '服务中心', icon: 'el-icon-s-release', noCache: true}
      },
      {
        path: 'addservicecenter',
        name: 'addservicecenter',
        component: () => import('@/views/CustomerManagement/telemedicine/addservicecenter.vue'),
        meta: {title: '添加服务中心', icon: 'el-icon-s-release', noCache: true}
      },
      {
        path: 'addThirdservicecenter',
        name: 'addThirdservicecenter',
        component: () => import('@/views/CustomerManagement/telemedicine/addThirdservicecenter.vue'),
        meta: {title: '添加服务中心', icon: 'el-icon-s-release', noCache: true}
      },
      {
        path: 'contractedhospital',
        name: 'contractedhospital',
        component: () => import('@/views/CustomerManagement/telemedicine/contractedhospital.vue'),
        meta: {title: '合作医院', noCache: true}
      },
      {
        path: 'servicedoctor',
        name: 'servicedoctor',
        component: () => import('@/views/CustomerManagement/telemedicine/servicedoctor.vue'),
        meta: {title: '服务医生', noCache: true}
      }
    ]
  },
  // 系统运维
  {
    path: basepath + '/systemOperation',
    component: Layout,
    name: 'systemOperation',
    redirect: basepath + '/systemOperation/serviceOrder',
    children: [
      {
        path: 'serviceOrder',
        name: 'serviceOrder',
        component: () => import('@/views/CustomerManagement/systemOperation/serviceOrder.vue'),
        meta: {title: '服务工单', icon: 'el-icon-s-release', noCache: true}
      },
      {
        path: 'systemLog',
        name: 'systemLog',
        component: () => import('@/views/CustomerManagement/systemOperation/systemLog.vue'),
        meta: {title: '日志查询', icon: 'el-icon-s-release', noCache: true}
      },
      {
        path: 'watchLogAudit',
        name: 'watchCustomerLogAudit',
        component: () => import('@/views/CustomerManagement/systemOperation/watchLogAudit.vue'),
        meta: {title: '查看日志', icon: 'el-icon-s-release', noCache: true}
      },
      {
        path: 'smsTemplate',
        name: 'CusotmerSmsTemplate',
        component: () => import('@/views/CustomerManagement/systemOperation/smsTemplate.vue'),
        meta: {title: '短信模板', icon: 'el-icon-s-release'}
      },
      {
        path: 'OfficialDocuments',
        name: 'CusotmerOfficialDocuments',
        component: () => import('@/views/CustomerManagement/systemOperation/OfficialDocuments.vue'),
        meta: {title: '文档发布', icon: 'el-icon-s-release'}
      },
      {
        path: 'DataMonitorCockpit/customerMonitorCockpit',
        name: 'anjiCustomerMonitorCockpit',
        redirect: basepath + '/DataMonitorCockpit/customerMonitorCockpit',
        meta: {title: '安吉县区域检查一体化服务平台数据监测', name: 'dataCockpit'}
      },
      {
        path: 'messageReleaseList',
        name: 'CusotmerMessageReleaseList',
        component: () => import('@/views/CustomerManagement/systemOperation/messageReleaseList.vue'),
        meta: {title: '信息发布', icon: 'el-icon-s-release'}
      },
      {
        path: 'videoManage',
        name: 'CusotmerVideoManage',
        component: () => import('@/views/CustomerManagement/systemOperation/videoManage.vue'),
        meta: { title: '会议录屏', icon: 'el-icon-s-release' }
      },
    ]
  },
  // 数据存储
  {
    path: basepath + '/dataStorage',
    component: Layout,
    name: 'dataStorage',
    redirect: basepath + '/dataStorage/storageDevice',
    children: [
      {
        path: 'caseExportManage',
        name: 'caseExportManage',
        component: () => import('@/views/CustomerManagement/dataStorage/caseExportManage.vue'),
        meta: { title: '导出管理', icon: 'el-icon-s-release', noCache: true }
      },
      {
        path: 'caseExportAllPage',
        name: 'caseExportAllPage',
        component: Layout,
        component: () => import('@/views/CustomerManagement/dataStorage/caseExportPage.vue'),
        meta: { title: '病例导出', icon: 'el-icon-s-release', noCache: true }
      },
      {
        path: 'storageDevice',
        name: 'storageDevice',
        component: () => import('@/views/CustomerManagement/dataStorage/storageDevice.vue'),
        meta: {title: '存储设备', icon: 'el-icon-s-release'}
      },
      {
        path: 'storageAuthorization',
        name: 'storageAuthorization',
        component: () => import('@/views/CustomerManagement/dataStorage/storageAuthorization.vue'),
        meta: {title: '存储授权', icon: 'el-icon-s-release'}
      },
      {
        path: 'storageStrategy',
        name: 'storageStrategy',
        component: () => import('@/views/CustomerManagement/dataStorage/storageStrategy.vue'),
        meta: {title: '存储策略', icon: 'el-icon-s-release'}
      },
      //标记策略页面未完成，不能放出来
      {
        path: 'markStrategy',
        name: 'markStrategy',
        component: () => import('@/views/CustomerManagement/dataStorage/markStrategy.vue'),
        meta: {title: '标记策略', icon: 'el-icon-s-release'}
      },
      {
        path: 'storageStatistics',
        name: 'storageStatistics',
        component: () => import('@/views/CustomerManagement/dataStorage/storageStatistics/index.vue'),
        meta: {title: '存储统计', icon: 'el-icon-s-release'},
        children: [
          {
            path: 'dataRange',
            name: 'dataRange',
            component: () => import('@/views/CustomerManagement/dataStorage/storageStatistics/index.vue'),
            meta: {title: '数据范围', icon: 'el-icon-s-release', noCache: true}
          },
          {
            path: 'storageMemory',
            name: 'storageMemory',
            component: () => import('@/views/CustomerManagement/dataStorage/storageStatistics/storageMemory.vue'),
            meta: {title: '存储容量', icon: 'el-icon-s-release', noCache: true}
          },
          {
            path: 'institutionDosage',
            name: 'institutionDosage',
            component: () => import('@/views/CustomerManagement/dataStorage/storageStatistics/institutionDosage.vue'),
            meta: {title: '机构用量', icon: 'el-icon-s-release', noCache: true}
          },
        ]
      },
      //
      {
        path: 'contentManage',
        name: 'contentManage',
        component: () => import('@/views/CustomerManagement/dataStorage/contentManage/index.vue'),
        meta: {title: '内容管理', icon: 'el-icon-s-release'},
        children: []

      },
      {
        path: 'setStrategy',
        name: 'SetStrategy',
        component: () => import('@/views/CustomerManagement/dataStorage/contentManage/setStrategy.vue'),
        meta: { title: '策略设置', icon: 'el-icon-s-release', noCache: true }
      },
    ]
  },
  {
    path: basepath + '/caseImportAlert',
    name: 'caseImportAlert',
    component: LayoutBlank,
    component: () => import('@/views/CustomerManagement/dataStorage/caseImportAlert.vue'),
    meta: { title: '病例导出进度界面', icon: 'el-icon-s-release', noCache: true }
  },
  {
    path: basepath + '/caseExportPage',
    name: 'caseExportPage',
    component: LayoutBlank,
    component: () => import('@/views/CustomerManagement/dataStorage/caseExportPage.vue'),
    meta: { title: '导出列表', icon: 'el-icon-s-release', noCache: true }
  },
  {
    path: basepath + '/caseExportManage',
    name: 'systemCaseExportManage',
    component: LayoutBlank,
    component: () => import('@/views/CustomerManagement/dataStorage/caseExportManage.vue'),
    meta: { title: '导出管理', icon: 'el-icon-s-release', noCache: true }
  },
  // 影像列表
  {
    path: basepath + '/paservice',
    component: Layout,
    name: 'paservice',
    redirect: basepath + '/paservice/',
    children: [
      {
        path: '/',
        name: 'paserviceindex',
        component: () => import('@/views/CustomerManagement/Imagelist/indexhome')
      },
      {
        path: 'IMGLIST',
        name: 'IMGLIST',
        component: () => import('@/views/CustomerManagement/Imagelist/imglist')
      },
      {
        path: 'IMGPROOFREAD',
        name: 'IMGPROOFREAD',
        component: () => import('@/views/CustomerManagement/Imagelist/imgproofread')
      },
      {
        path: 'paramsSetting/bacisParams',
        name: 'bacisParams',
        component: () => import('@/views/CustomerManagement/Imagelist/bacisParams')
      },
      {
        path: 'kong',
        name: 'kong',
        component: () => import('@/views/CustomerManagement/Imagelist/kong')
      }
    ]
  },
  // 外部能力
  {
    path: basepath + '/externalCapability',
    component: Layout,
    name: 'externalCapability',
    redirect: basepath + '/externalCapability/basicCapability',
    children: [
      {
        path: 'basicCapability',
        name: 'coustomerBasicCapability',
        component: () => import('@/views/CustomerManagement/externalCapability/basicCapability.vue'),
        meta: {title: '基础能力', icon: 'el-icon-s-release'}
      },
      {
        path: 'intelligentDiagnosis',
        name: 'myIntelligentDiagnosis',
        component: () => import('@/views/CustomerManagement/externalCapability/intelligentDiagnosis.vue'),
        meta: {title: '智能诊断', icon: 'el-icon-s-release'}
      }
    ]
  },
  // 叫号系统
  {
    path: basepath + '/calling',
    name: 'calling',
    component: Layout,
    redirect: basepath + '/calling/basicSetting',
    children: [
      {
        path: 'basicSetting',
        name: 'basicSetting',
        component: () => import('@/views/CustomerManagement/Calling/BasicSetting.vue'),
        meta: {title: '基础设置', icon: 'el-icon-s-data'}
      },
      {
        path: 'voiceSetting',
        name: 'voiceSetting',
        component: () => import('@/views/CustomerManagement/Calling/VoiceSetting.vue'),
        meta: {title: '语音设置', icon: 'el-icon-s-data'}
      },
      {
        path: 'callingScreen',
        name: 'callingScreen',
        component: () => import('@/views/CustomerManagement/Calling/CallingScreen.vue'),
        meta: {title: '叫号屏设置', icon: 'el-icon-s-data'}
      },
      {
        path: 'screenMonitoring',
        name: 'screenMonitoring',
        component: () => import('@/views/CustomerManagement/Calling/ScreenMonitoring.vue'),
        meta: {title: '屏幕监控', icon: 'el-icon-s-data'}
      }
    ]
  },
  // 刑侦调阅
  {
    path: basepath + '/criminalInvestigation',
    component: Layout,
    name: 'criminalInvestigation',
    redirect: basepath + '/criminalInvestigation/reviewCheck',
    children: [
      {
        path: 'reviewCheck',
        name: 'reviewCheck',
        component: () => import('@/views/CustomerManagement/criminalInvestigation/reviewCheck.vue'),
        meta: {title: '调阅审核', icon: 'el-icon-s-release'}
      },
      {
        path: 'loggingAudit',
        name: 'loggingAudit',
        component: () => import('@/views/CustomerManagement/criminalInvestigation/loggingAudit.vue'),
        meta: {title: '日志审计', icon: 'el-icon-s-release'}
      },
      {
        path: 'ciUserList',
        name: 'ciUserList',
        component: () => import('@/views/CustomerManagement/criminalInvestigation/user/userList.vue'),
        meta: {title: '用户管理', icon: 'el-icon-s-release'}
      },
      {
        path: 'comprehensiveSet', // 综合设置
        name: 'comprehensiveSet',
        component: () => import('@/views/CustomerManagement/criminalInvestigation/comprehensiveSet.vue'),
        // redirect: basepath + '/criminalInvestigation/comprehensiveSet/CIhomeSet',
        children: [
          {
            path: 'CIhomeSet',
            name: 'CIhomeSet',
            component: () => import('@/views/CustomerManagement/criminalInvestigation/homeSet.vue'),
            meta: {title: '门户设置', icon: 'el-icon-s-release'}
          },
          {
            path: 'CIparamsSet',
            name: 'CIparamsSet',
            component: () => import('@/views/CustomerManagement/criminalInvestigation/paramsSet.vue'),
            meta: {title: '参数设置', icon: 'el-icon-s-release'}
          }
        ]
      }
    ]
  },
  // 影像质控
  {
    path: basepath + '/imageQualityControl',
    component: Layout,
    name: 'imageQualityControl',
    redirect: basepath + '/imageQualityControl/imageControlList',
    children: [
      {
        path: 'imageControlList',
        name: 'imageControlList',
        component: () => import('@/views/CustomerManagement/imageQualityControl/imageControlList.vue'),
        meta: {title: '影像质控', icon: 'el-icon-s-release'}
      }
    ]
  },
  // 患者主索引
  {
    path: basepath + '/primaryIndexManage',
    component: Layout,
    name: 'primaryIndexManage',
    redirect: basepath + '/primaryIndexManage/primaryIndexPowerSet',
    children: [
      {
        path: 'primaryIndexPowerSet',
        name: 'primaryIndexPowerSet',
        component: () => import('@/views/CustomerManagement/primaryIndexManage/primaryIndexPowerSet.vue'),
        meta: {title: '主索引权重配置', icon: 'el-icon-s-release'}
      },
      {
        path: 'primaryIndexList',
        name: 'primaryIndexList',
        component: () => import('@/views/CustomerManagement/primaryIndexManage/primaryIndexList.vue'),
        meta: {title: '主索引列表', icon: 'el-icon-s-release'}
      },
      {
        path: 'pixPrimaryIndexList',
        name: 'pixPrimaryIndexList',
        component: () => import('@/views/CustomerManagement/primaryIndexManage/pixPrimaryIndexList.vue'),
        meta: { title: '交叉索引记录', icon: 'el-icon-s-release' }
      },
      {
        path: 'mergePrimaryIndex',
        name: 'mergePrimaryIndex',
        component: () => import('@/views/CustomerManagement/primaryIndexManage/mergePrimaryIndex.vue'),
        meta: {title: '合并患者索引', icon: 'el-icon-s-release'}
      },
      {
        path: 'mergePrimaryIndexLastStep',
        name: 'mergePrimaryIndexLastStep',
        component: () => import('@/views/CustomerManagement/primaryIndexManage/mergePrimaryIndexLastStep.vue'),
        meta: {title: '合并患者索引第二步', icon: 'el-icon-s-release'}
      },
      {
        path: 'splitPrimaryIndex',
        name: 'splitPrimaryIndex',
        component: () => import('@/views/CustomerManagement/primaryIndexManage/splitPrimaryIndex.vue'),
        meta: {title: '拆分患者索引', icon: 'el-icon-s-release'}
      },
      {
        path: 'primaryIndexDetailPage',
        name: 'primaryIndexDetailPage',
        component: () => import('@/views/CustomerManagement/primaryIndexManage/primaryIndexDetailPage.vue'),
        meta: {title: '查看详情', icon: 'el-icon-s-release'}
      },
      {
        path: 'markRealmList',
        name: 'markRealmList',
        component: () => import('@/views/CustomerManagement/primaryIndexManage/markRealmList.vue'),
        meta: {title: '标识域管理', icon: 'el-icon-s-release'}
      },
    ]
  },
  // 数据统计
  {
    path: basepath + '/dataStatistics',
    component: Layout,
    name: 'customerDataStatistics',
    redirect: basepath + '/dataStatistics/index',
    children: [
      {
        path: 'index',
        name: 'statisticsIndex',
        component: () => import('@/views/FrameView/index.vue'),
        meta: {title: '数据统计', icon: 'el-icon-s-release'}
      },
      {
        path: 'remoteDiagnosis',
        name: 'customerRemoteDiagnosis',
        component: () => import('@/views/FrameView/index.vue'),
        meta: {title: '远程诊断统计', icon: 'el-icon-s-release'}
      },
      {
        path: 'workLoad',
        name: 'workLoad',
        component: () => import('@/views/FrameView/index.vue'),
        meta: {
          title: '工作负荷', icon: 'el-icon-s-release', noCache: true, parenttitle: '数据统计',
          dataurl: 'YiGongTi/YiJiKeShi/GongZuoFuHe.frm'
        }
      },
      {
        path: 'workQuality',
        name: 'workQuality',
        component: () => import('@/views/FrameView/index.vue'),
        meta: {
          title: '工作质量', icon: 'el-icon-s-release', noCache: true, parenttitle: '数据统计',
          dataurl: 'YiGongTi/YiJiKeShi/GongZuoZhiLiang.frm'
        }
      },
      {
        path: 'costStatistics',
        name: 'costStatistics',
        component: () => import('@/views/FrameView/index.vue'),
        meta: {
          title: '费用统计', icon: 'el-icon-s-release', noCache: true, parenttitle: '数据统计',
          dataurl: 'YiGongTi/YiJiKeShi/FeiYongTongJi.frm'
        }
      },
      {
        path: 'remoteDiagnosis',
        name: 'customerRemoteDiagnosisIndex',
        component: () => import('@/views/FrameView/index.vue'),
        meta: {
          title: '远程诊断', icon: 'el-icon-s-release', noCache: true, parenttitle: '数据统计',
          dataurl: 'YiGongTi/YuanChengYiLiao/YuanChengZhenDuan.frm'
        }
      },
      {
        path: 'remoteConsultation',
        name: 'customerRemoteConsultation',
        component: () => import('@/views/FrameView/index.vue'),
        meta: {
          title: '远程会诊', icon: 'el-icon-s-release', noCache: true, parenttitle: '数据统计',
          dataurl: 'YiGongTi/YuanChengYiLiao/YuanChengHuiZhen.frm'
        }
      },
      {
        path: 'dataBrain',
        name: 'customerDataBrain',
        redirect: basepath + '/customerDataCockpit/index',
        meta: {
          title: '数据大脑', icon: 'el-icon-s-release', name: 'dataBrain', noCache: true, parenttitle: '数据统计',
          dataurl: 'YiGongTi/ShuJuDaPing/ShuJuDaPingYiGongTi.frm'
        }
      },
      {
        path: 'consultationStatistics',
        name: 'consultationStatistics',
        component: () => import('@/views/CustomerManagement/consultationStatistics'),
        meta: {title: '会诊统计', name: 'consultationStatistics', noCache: true}
      },
      {
        path: 'serviceDevelopStatistics',
        name: 'serviceDevelopStatistics',
        component: () => import('@/views/FrameView/serviceDevelopStatistics'),
        meta: {title: '服务开展统计', name: 'serviceDevelopStatistics', noCache: true}
      },
      {
        path: 'yzzkConsultationStatistics',
        name: 'yzzkConsultationStatistics',
        component: () => import('@/views/FrameView/yzzkConsultationStatistics'),
        meta: {title: '鄞州质控会诊统计', name: 'yzzkConsultationStatistics', noCache: true}
      },
      {
        path: 'yzzkDiagnosisStatistics',
        name: 'yzzkDiagnosisStatistics',
        component: () => import('@/views/FrameView/yzzkDiagnosisStatistics'),
        meta: {title: '鄞州质控诊断统计', name: 'yzzkDiagnosisStatistics', noCache: true}
      },
      {
        path: 'yzzkReservationStatistics',
        name: 'yzzkReservationStatistics',
        component: () => import('@/views/FrameView/yzzkReservationStatistics'),
        meta: {title: '鄞州质控预约统计', name: 'yzzkReservationStatistics', noCache: true}
      },
    ]
  },
  // 内容管理内嵌页面
  {
    path: basepath + '/dataStorage',
    name: 'dataStorageLayoutBlank',
    component: LayoutBlank,
    children: [
      {
        path: 'contentManageLayoutBlank',
        name: 'contentManageLayoutBlank',
        component: () => import('@/views/CustomerManagement/dataStorage/contentManage/index.vue'),
        meta: {title: '内容管理', icon: 'el-icon-s-release', hideNav: true}
      }
    ],
  },
  {
    path: basepath + '/fileView',
    name: 'customerFileView',
    component: LayoutBlank,
    children: [
      {
        path: 'index',
        name: 'FileViewIndex',
        component: () => import('@/views/CustomerManagement/dataStorage/fileView.vue'),
        meta: {title: '影像浏览', icon: 'el-icon-s-release'}
      }
    ],
  },
  {
    path: basepath + '/filePreview',
    name: 'filePreview',
    component: LayoutBlank,
    children: [
      {
        path: 'index',
        name: 'filePreviewIndex',
        component: () => import('@/views/CustomerManagement/dataStorage/filePreview.vue'),
        meta: { title: '影像浏览', icon: 'el-icon-s-release' }
      }
    ],
  },
  // 数据驾驶舱 临时路由
  {
    path: basepath + '/customerDataCockpit',
    name: 'customerDataCockpit',
    component: LayoutBlank,
    redirect: basepath + '/customerDataCockpit/index',
    children: [
      {
        path: 'index',
        name: 'customerDataCockpitIndex',
        component: () => import('@/views/CustomerManagement/dataCockpit/index.vue'),
        meta: {title: '数据驾驶舱', name: 'dataCockpit', noCache: true}
      }
    ]
  },
  // 数据驾驶舱 临时路由--武汉医疗云大屏假数据路由(给现场演示用的)
  {
    path: basepath + '/wuhanyiliaoyunStatic',
    name: 'wuhanyiliaoyunStatic',
    component: LayoutBlank,
    redirect: basepath + '/wuhanyiliaoyunStatic/index',
    children: [
      {
        path: 'index',
        name: 'wuhanyiliaoyunStaticIndex',
        component: () => import('@/views/CustomerManagement/dataCockpit/index/wuhanyiliaoyunStatic.vue'),
        meta: {title: '数据驾驶舱', name: 'dataCockpit', noCache: true}
      }
    ]
  },
  // 监管平台
  {
    path: basepath + '/regulatoryPlatform',
    name: 'regulatoryPlatform',
    component: Layout,
    children: [
      {
        path: 'informationPlatform',
        name: 'informationPlatform',
        component: () => import('@/views/CustomerManagement/regulatoryPlatform/informationPlatform.vue'),
        meta: {title: '平台信息', name: 'informationPlatform', noCache: true}
      },
      {
        path: 'dictionaryMapping',
        name: 'dictionaryMapping',
        component: () => import('@/views/CustomerManagement/regulatoryPlatform/dictionaryMapping.vue'),
        meta: {title: '字典映射', name: 'dictionaryMapping', noCache: true}
      },
      {
        path: 'regulatoryRecord',
        name: 'regulatoryRecord',
        component: () => import('@/views/CustomerManagement/regulatoryPlatform/regulatoryRecord.vue'),
        meta: {title: '监管记录', name: 'regulatoryRecord', noCache: true}
      }
    ]
  },
  // 公司官网
  {
    path: basepath + '/companyWebsite',
    name: 'companyWebsite',
    component: Layout,
    children: [
      {
        path: 'companyInfo',
        name: 'companyInfo',
        component: () => import('@/views/CustomerManagement/companyWebsite/index.vue'),
        meta: {title: '公司信息', name: 'companyInfo', noCache: true}
      },
      {
        path: 'tagInfo',
        name: 'tagInfo',
        component: () => import('@/views/CustomerManagement/companyWebsite/index.vue'),
        meta: {title: '标签信息', name: 'tagInfo', noCache: true}
      },
      {
        path: 'developmentHistory',
        name: 'developmentHistory',
        component: () => import('@/views/CustomerManagement/companyWebsite/index.vue'),
        meta: {title: '发展历程', name: 'developmentHistory', noCache: true}
      },
      {
        path: 'productClassification',
        name: 'productClassification',
        component: () => import('@/views/CustomerManagement/companyWebsite/index.vue'),
        meta: {title: '产品分类', name: 'productClassification', noCache: true}
      },
      {
        path: 'productList',
        name: 'productList',
        component: () => import('@/views/CustomerManagement/companyWebsite/index.vue'),
        meta: {title: '产品列表', name: 'productList', noCache: true}
      },
      {
        path: 'caseList',
        name: 'caseList',
        component: () => import('@/views/CustomerManagement/companyWebsite/index.vue'),
        meta: {title: '案例列表', name: 'developmentHistory', noCache: true}
      },
      {
        path: 'newsList',
        name: 'newsList',
        component: () => import('@/views/CustomerManagement/companyWebsite/index.vue'),
        meta: {title: '新闻列表', name: 'newsList', noCache: true}
      },
      {
        path: 'jobIntroduction',
        name: 'jobIntroduction',
        component: () => import('@/views/CustomerManagement/companyWebsite/index.vue'),
        meta: {title: '招聘简介', name: 'jobIntroduction', noCache: true}
      },
      {
        path: 'jobList',
        name: 'jobList',
        component: () => import('@/views/CustomerManagement/companyWebsite/index.vue'),
        meta: {title: '岗位列表', name: 'jobList', noCache: true}
      },
      {
        path: 'serverCenter',
        name: 'serverCenter',
        component: () => import('@/views/CustomerManagement/companyWebsite/index.vue'),
        meta: {title: '服务中心', name: 'serverCenter', noCache: true}
      },
      {
        path: 'systemParameter',
        name: 'systemParameter',
        component: () => import('@/views/CustomerManagement/companyWebsite/index.vue'),
        meta: {title: '系统参数', name: 'systemParameter', noCache: true}
      },
    ]
  },
]
