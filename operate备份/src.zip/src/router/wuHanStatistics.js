// 武汉医疗云项目，根据角色区分的菜单路由
import Layout from '@/layoutServiceCenter/index'
import customerLayout from '@/layout/index'
var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
export default [
  // 医生角色-心电统计
  {
    path: basepath + '/centerEcgStatistics',
    component: customerLayout,
    name: 'doctorEcgStatistics',
    hidden: true,
    children: [
      {
        path: 'doctorReportQuality',
        name: 'doctorReportQuality',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportQuality.vue'
          ),
        meta: {
          title: '报告质量',
          module: 'doctorManage',
          noCache: true
        }
      },
      {
        path: 'doctorCheckEfficiency',
        name: 'doctorCheckEfficiency',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/checkEfficiency.vue'
          ),
        meta: {
          title: '检查效率',
          module: 'doctorManage',
          noCache: true
        }
      },
      {
        path: 'doctorEcgWorkload',
        name: 'doctorEcgWorkload',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/ecgWorkload.vue'),
        meta: {
          title: '心电诊断量',
          module: 'doctorManage',
          noCache: true
        }
      },
      {
        path: 'doctorEcgCritical',
        name: 'doctorEcgCritical',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/ecgCritical.vue'),
        meta: {
          title: '危急值',
          module: 'doctorManage',
          noCache: true
        }
      },
      {
        path: 'institutionEcgCritical',
        name: 'institutionEcgCritical',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/ecgCritical.vue'),
        meta: {
          title: '危急值',
          module: 'institutionManage',
          noCache: true
        }
      },
      {
        path: 'doctorEcgCheckApplication',
        name: 'doctorEcgCheckApplication',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/ecgCheckApplication.vue'
          ),
        meta: {
          title: '心电申请量',
          module: 'doctorManage',
          noCache: true
        }
      },
      {
        path: 'doctorApplicationQuality',
        name: 'doctorApplicationQuality',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/applicationQuality.vue'
          ),
        meta: {
          title: '申请量质量',
          module: 'doctorManage',
          noCache: true
        }
      },
      {
        path: 'doctorCheckQuality',
        name: 'doctorCheckQuality',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/checkQuality.vue'),
        meta: {
          title: '检查质量',
          module: 'doctorManage',
          noCache: true
        }
      },
      {
        path: 'doctorReportPositiveRate',
        name: 'doctorReportPositiveRate',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportPositiveRate.vue'
          ),
        meta: {
          title: '报告阳性率',
          module: 'doctorManage',
          noCache: true
        }
      },
      {
        path: 'doctorReportRevisionRate',
        name: 'doctorReportRevisionRate',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportRevisionRate.vue'
          ),
        meta: {
          title: '报告修改率',
          module: 'serviceCenterManage',
          noCache: true
        }
      }
    ]
  },
  // 医生角色-病理统计
  {
    path: basepath + '/centerPisStatistics',
    component: customerLayout,
    name: 'doctorPisStatistics',
    hidden: true,
    children: [
      {
        path: 'doctorInspectionWorkload',
        name: 'doctorInspectionWorkload',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/inspectionWorkload.vue'
          ),
        meta: {
          title: '病理工作量',
          module: 'doctorManage',
          noCache: true
        }
      },
      {
        path: 'doctorReportWorkload',
        name: 'doctorReportWorkload',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportWorkload.vue'
          ),
        meta: {
          title: '检查项目量',
          module: 'doctorManage',
          noCache: true
        }
      },
      {
        path: 'doctorUnqualifiedSpecimen',
        name: 'doctorUnqualifiedSpecimen',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/unqualifiedSpecimen.vue'
          ),
        meta: {
          title: '不合格标本',
          module: 'doctorManage',
          noCache: true
        }
      },
      {
        path: 'doctorPisCheckApplication',
        name: 'doctorPisCheckApplication',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/pisCheckApplication.vue'
          ),
        meta: {
          title: '病理申请量',
          module: 'doctorManage',
          noCache: true
        }
      }
    ]
  },
  // 服务中心角色-病理统计
  {
    path: basepath + '/centerPisStatistics',
    component: Layout,
    name: 'centerPisStatistics',
    hidden: true,
    children: [
      {
        path: 'inspectionWorkload',
        name: 'centerInspectionWorkload',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/inspectionWorkload.vue'
          ),
        meta: {
          title: '病理工作量',
          module: 'serviceCenterManage',
          noCache: true
        }
      },
      {
        path: 'reportWorkload',
        name: 'centerReportWorkload',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportWorkload.vue'
          ),
        meta: {
          title: '检查项目量',
          module: 'serviceCenterManage',
          noCache: true
        }
      }
    ]
  },
  // 服务中心角色-病理质量统计
  {
    path: basepath + '/centerPisQuality',
    component: Layout,
    name: 'centerPisQuality',
    hidden: true,
    children: [
      {
        path: 'unqualifiedSpecimen',
        name: 'centerUnqualifiedSpecimen',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/unqualifiedSpecimen.vue'
          ),
        meta: {
          title: '不合格标本',
          module: 'serviceCenterManage',
          noCache: true
        }
      }
    ]
  },
  // 服务中心角色-心电统计
  {
    path: basepath + '/centerEcgStatistics',
    component: Layout,
    name: 'centerEcgStatistics',
    hidden: true,
    children: [
      {
        path: 'ecgWorkload',
        name: 'centerEcgWorkload',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/ecgWorkload.vue'),
        meta: {
          title: '心电诊断量',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'ECGIS'
        }
      },
      {
        path: 'gradedWarning',
        name: 'centerGradedWarning',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/gradedWarning.vue'
          ),
        meta: {
          title: '分级预警',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'ECGIS'
        }
      },
      {
        path: 'checkAbnormal',
        name: 'centerCheckAbnormal',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/checkAbnormal.vue'
          ),
        meta: {
          title: '检查异常率',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'ECGIS'
        }
      },
      {
        path: 'ecgCritical',
        name: 'centerEcgCritical',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/ecgCritical.vue'),
        meta: {
          title: '危急值',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'ECGIS'
        }
      },
      {
        path: 'ecgCheckApplication',
        name: 'centerEcgCheckApplication',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/ecgCheckApplication.vue'
          ),
        meta: {
          title: '心电申请量',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'ECGIS'
        }
      },
      {
        path: 'applicationQuality',
        name: 'centerApplicationQuality',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/applicationQuality.vue'
          ),
        meta: {
          title: '申请量质量',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'ECGIS'
        }
      },
      {
        path: 'qualityRadiography',
        name: 'centerQualityRadiography',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/qualityRadiography.vue'
          ),
        meta: {
          title: '摄片质量',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'ECGIS'
        }
      },
      {
        path: 'reportPositiveRate',
        name: 'centerReportPositiveRate',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportPositiveRate.vue'
          ),
        meta: {
          title: '报告阳性率',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'ECGIS'
        }
      }
    ]
  },
  // 服务中心角色-心电质量统计
  {
    path: basepath + '/centerEcgQuality',
    component: Layout,
    name: 'centerEcgQuality',
    hidden: true,
    children: [
      {
        path: 'checkQuality',
        name: 'centerCheckQuality',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/checkQuality.vue'),
        meta: {
          title: '检查质量',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'ECGIS'
        }
      },
      {
        path: 'reportQuality',
        name: 'centerReportQuality',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportQuality.vue'
          ),
        meta: {
          title: '报告质量',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'ECGIS'
        }
      },
      {
        path: 'checkEfficiency',
        name: 'centerCheckEfficiency',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/checkEfficiency.vue'
          ),
        meta: {
          title: '时间效率',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'ECGIS'
        }
      }
    ]
  },
  // 服务中心角色-放射统计
  {
    path: basepath + '/centerRisStatistics',
    component: Layout,
    name: 'centerRisStatistics',
    hidden: true,
    children: [
      {
        path: 'risWorkload',
        name: 'risCenterEcgWorkload',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/ecgWorkload.vue'),
        meta: {
          title: '放射诊断量',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'RIS'
        }
      },
      {
        path: 'risGradedWarning',
        name: 'risCenterGradedWarning',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/gradedWarning.vue'
          ),
        meta: {
          title: '分级预警',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'RIS'
        }
      },
      {
        path: 'risCritical',
        name: 'risCenterEcgCritical',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/ecgCritical.vue'),
        meta: {
          title: '危急值',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'RIS'
        }
      },
      {
        path: 'risCheckAbnormal',
        name: 'risCenterCheckAbnormal',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/checkAbnormal.vue'
          ),
        meta: {
          title: '检查异常率',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'RIS'
        }
      },
    ]
  },
  // 服务中心角色-放射质量统计
  {
    path: basepath + '/centerRisQuality',
    component: Layout,
    name: 'centerRisQuality',
    hidden: true,
    children: [
      {
        path: 'risCheckQuality',
        name: 'risCenterCheckQuality',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/checkQuality.vue'),
        meta: {
          title: '检查质量',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'RIS'
        }
      },
      {
        path: 'risReportQuality',
        name: 'risCenterReportQuality',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportQuality.vue'
          ),
        meta: {
          title: '报告质量',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'RIS'
        }
      },
      {
        path: 'risCheckEfficiency',
        name: 'risCenterCheckEfficiency',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/checkEfficiency.vue'
          ),
        meta: {
          title: '时间效率',
          module: 'serviceCenterManage',
          noCache: true,
          productCode: 'RIS'
        }
      }
    ]
  },
  // 机构角色-病理质量统计
  {
    path: basepath + '/centerPisQuality',
    component: customerLayout,
    name: 'institutionPisQuality',
    hidden: true,
    children: [
      {
        path: 'institutionUnSpecimen',
        name: 'institutionUnSpecimen',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/unqualifiedSpecimen.vue'
          ),
        meta: {
          title: '不合格标本',
          module: 'institutionManage',
          noCache: true
        }
      }
    ]
  },
  // 机构角色-病理监管统计
  {
    path: basepath + '/centerPisStatistics',
    component: customerLayout,
    name: 'institutionPisStatistics',
    hidden: true,
    children: [
      {
        path: 'pisCheckApplication',
        name: 'institution',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/pisCheckApplication.vue'
          ),
        meta: {
          title: '病理申请量',
          module: 'serviceCenterManage',
          noCache: true
        }
      },
      {
        path: 'institutionReportWorkload',
        name: 'institutionReportWorkload',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportWorkload.vue'
          ),
        meta: {
          title: '检查项目量',
          module: 'institutionManage',
          noCache: true
        }
      }
    ]
  },
  // 机构角色-心电统计
  {
    path: basepath + '/centerEcgStatistics',
    component: customerLayout,
    name: 'institutionEcgStatistics',
    hidden: true,
    children: [
      {
        path: 'institutionEcgCheckApplication',
        name: 'institutionEcgCheckApplication',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/ecgCheckApplication.vue'
          ),
        meta: {
          title: '心电申请量',
          module: 'institutionManage',
          noCache: true
        }
      },
      {
        path: 'institutionGradedWarning',
        name: 'institutionGradedWarning',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/gradedWarning.vue'
          ),
        meta: {
          title: '分级预警',
          module: 'institutionManage',
          noCache: true
        }
      },
      {
        path: 'institutionCheckAbnormal',
        name: 'institutionCheckAbnormal',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/checkAbnormal.vue'
          ),
        meta: {
          title: '检查异常率',
          module: 'institutionManage',
          noCache: true
        }
      },
      {
        path: 'institutionReportQuality',
        name: 'institutionReportQuality',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportQuality.vue'
          ),
        meta: {
          title: '报告质量',
          module: 'institutionManage',
          noCache: true
        }
      }
    ]
  },
  // 机构角色-心电质量统计
  {
    path: basepath + '/centerEcgQuality',
    component: customerLayout,
    name: 'institutionEcgQuality',
    hidden: true,
    children: [
      {
        path: 'institutionCheckEfficiency',
        name: 'institutionCheckEfficiency',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/checkEfficiency.vue'
          ),
        meta: {
          title: '检查效率',
          module: 'institutionManage',
          noCache: true
        }
      },
      {
        path: 'institutionCheckQuality',
        name: 'institutionCheckQuality',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/checkQuality.vue'),
        meta: {
          title: '检查质量',
          module: 'institutionManage',
          noCache: true
        }
      }
    ]
  },
  // 客户角色 -- 心电监管统计
  {
    path: basepath + '/customerEcgStatistics',
    component: customerLayout,
    name: 'customerEcgStatistics',
    children: [
      {
        path: 'customerEcgWorkload',
        name: 'customerEcgWorkload',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/ecgWorkload.vue'),
        meta: {
          title: '心电诊断量',
          module: 'customerManage',
          noCache: true
        }
      },
      {
        path: 'customerGradedWarning',
        name: 'customerGradedWarning',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/gradedWarning.vue'
          ),
        meta: {
          title: '分级预警',
          module: 'customerManage',
          noCache: true
        }
      },
      {
        path: 'customerCheckAbnormal',
        name: 'customerCheckAbnormal',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/checkAbnormal.vue'
          ),
        meta: {
          title: '检查异常率',
          module: 'customerManage',
          noCache: true
        }
      },
      {
        path: 'customerEcgCritical',
        name: 'customerEcgCritical',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/ecgCritical.vue'),
        meta: {
          title: '危急值',
          module: 'customerManage',
          noCache: true
        }
      }
    ]
  },
  // 客户角色 -- 心电质量统计
  {
    path: basepath + '/customerEcgQuality',
    component: customerLayout,
    name: 'customerEcgQuality',
    children: [
      {
        path: 'customerCheckQuality',
        name: 'customerCheckQuality',
        component: () =>
          import('@/views/ServiceCenterManagement/dataStatic/checkQuality.vue'),
        meta: {
          title: '检查质量',
          module: 'customerManage',
          noCache: true
        }
      },
      {
        path: 'customerReportQuality',
        name: 'customerReportQuality',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportQuality.vue'
          ),
        meta: {
          title: '报告质量',
          module: 'customerManage',
          noCache: true
        }
      },
      {
        path: 'customerCheckEfficiency',
        name: 'customerCheckEfficiency',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/checkEfficiency.vue'
          ),
        meta: {
          title: '时间效率',
          module: 'customerManage',
          noCache: true
        }
      }
    ]
  },
  // 客户角色 -- 病理诊断统计
  {
    path: basepath + '/customerPisStatistics',
    component: customerLayout,
    name: 'customerPisStatistics',
    children: [
      {
        path: 'customerInspectionWorkload',
        name: 'customerInspectionWorkload',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/inspectionWorkload.vue'
          ),
        meta: {
          title: '病理工作量',
          module: 'customerManage',
          noCache: true
        }
      },
      {
        path: 'customerReportWorkload',
        name: 'customerReportWorkload',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/reportWorkload.vue'
          ),
        meta: {
          title: '检查项目量',
          module: 'customerManage',
          noCache: true
        }
      }
    ]
  },
  // 客户角色 -- 病理质量统计
  {
    path: basepath + '/customerPisQuality',
    component: customerLayout,
    name: 'customerPisQuality',
    children: [
      {
        path: 'customerUnqualifiedSpecimen',
        name: 'customerUnqualifiedSpecimen',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/dataStatic/unqualifiedSpecimen.vue'
          ),
        meta: {
          title: '不合格标本',
          module: 'customerManage',
          noCache: true
        }
      }
    ]
  }
]
