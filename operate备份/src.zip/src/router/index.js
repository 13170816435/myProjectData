﻿import Vue from 'vue'
import VueRouter from 'vue-router'
import Layout from '@/layout/index'
import LayoutBlank from '@/layout/indexBlank'
import PlatformOperate from './platformOperation/platformIndex'
import CustomerManagement from './customerManagement/customerIndex'
import ServiceCenterManage from './serviceCenterManage/serviceCenterIndex'
import dataMonitorCockpit from './dataMonitorCockpit'
import wuHanStatistics from './wuHanStatistics'
import intelligentDiagnosis from './intelligentDiagnosis/intelligentDiagnosis'
Vue.use(VueRouter)

/**
 * 路由相关属性说明
 * hidden: 当设置hidden为true时，意思不在sideBars侧边栏中显示
 * mete{
 * title: xxx,  设置sideBars侧边栏名称
 * icon: xxx,  设置ideBars侧边栏图标
 * noCache: true  当设置为true时不缓存该路由页面
 * }
 */
// import Mgr from '@/utils/SecurityService'
// var tenancy_id
// var manager = new Mgr()
// manager.getRole().then(function (item) {
//   if (item) {
//     tenancy_id = item.profile.tenancy_id
//   }
// })
var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
export const currencyRoutes = [
  {
    path: '/',
    name: 'home',
    component: Layout,
    redirect: '/home',
    children: [
      {
        path: 'home',
        name: 'homeIndex',
        component: () => import('@/views/home.vue'),
        meta: { title: '首页', icon: 'el-icon-s-data' }
      }
    ]
  },
  {
    path: '/updatepwd',
    name: 'updatepwd',
    component: Layout,
    redirect: '/updatepwd/index',
    children: [
      {
        path: 'index',
        name: 'index',
        component: () => import('@/views/UpdateUserPwd.vue')
      }
    ]
  },
  {
    path: '/aboutSystem',
    name: 'aboutSystem',
    component: LayoutBlank,
    redirect: '/aboutSystem/index',
    children: [
      {
        path: 'index',
        name: 'index',
        component: () => import('@/views/aboutSystem/index.vue')
      }
    ]
  },
  // {
  //   path: basepath + '/noPermission',
  //   name: 'noPermission',
  //   component: LayoutBlank,
  //   redirect: basepath + '/noPermission/index',
  //   children: [
  //     {
  //       path: 'index',
  //       name: 'notFoundIndex',
  //       component: () => import('@/views/noPermission.vue')
  //     }
  //   ]
  // },
  ...PlatformOperate,
  ...CustomerManagement,
  ...ServiceCenterManage, // 服务中心管理
  ...dataMonitorCockpit,
  ...wuHanStatistics,
  ...intelligentDiagnosis,
  {
    path: '/noPermission',
    name: 'Page404',
    component: () => import('@/views/noPermission.vue'),
    hidden: true
  },
  // {
  //   path: '*', // 页面不存在的情况下会跳到404页面
  //   redirect: '/noPermission',
  //   name: 'notFound',
  //   hidden: true
  // },
]

/**
 * 判断是否拥有权限
 * @param {Array<string>} permissions - 要判断的权限列表
 */
 function includePermission (inputUrl) {
  // 这里要判断的权限没有设置的话，就等于不需要权限，直接返回 true
  if (!inputUrl) return true
  const permissionList = JSON.parse(sessionStorage.getItem('menuArr'))
  // console.log('permissionList==========',permissionList)
  let newPermissionList = []
  let hasPermission = true
  if (permissionList && permissionList.length == 0) {
    hasPermission = false
    return new Promise(function(resolve,reject) {
      resolve(false)
    })
  } else {
    if (permissionList) {
      permissionList.forEach((item) => {0
        if (item.children && item.children.length != 0) {
          item.children.forEach((one) => {//二级
            if (one.children && one.children.length != 0) { // 三级
              one.children.forEach((nth) => {
                let threeMenuPath = item.path + one.path + nth.path
                newPermissionList.push(threeMenuPath)
              })
            } else { //二级 (没有三级)
              let twoMenuPath = item.path + one.path
              // 特殊处理 产品发布
              if (twoMenuPath == (basepath +'/systemOperate/productManagement')) {
                let productManagementRouter1 = twoMenuPath + '/releaseOperate'
                let productManagementRouter2 = twoMenuPath + '/releaseRecord'
                newPermissionList.push(productManagementRouter1)
                newPermissionList.push(productManagementRouter2)

              } else if (twoMenuPath == (basepath +'/telemedicine/servicecenter')) { // 当有服务中心权限时 得把"添加服务中心"页面也有权限预览
                newPermissionList.push(twoMenuPath)
                let addServiceCenterPath = basepath+'/telemedicine/addservicecenter'
                newPermissionList.push(addServiceCenterPath)
                let addThirdServiceCenterPath = basepath+'/telemedicine/addThirdservicecenter' // 第三方服务中心的编辑
                newPermissionList.push(addThirdServiceCenterPath)
              }
              else if (twoMenuPath == (basepath +'/interfaceService/serviceDefinition')) { // 有接口服务权限时 配置权限也要有
                newPermissionList.push(twoMenuPath)
                let interfaceParamSetPath = basepath+'/interfaceService/interfaceParamSet'
                newPermissionList.push(interfaceParamSetPath)
              }
              else if (twoMenuPath == (basepath+'/operationDataBrain/operationDataCockpit')) { // 特殊处理数据大脑/数据驾驶舱
                let platformOperationCookpitPath =  basepath + '/platformDataCockpit/index' // 平台运营 数据大脑->数据驾驶舱
                newPermissionList.push(platformOperationCookpitPath)
              }
              else if (twoMenuPath == (basepath+'/operationDataBrain/inspectProfile')) { // 特殊处理数据大脑/检查画像
                let inspectProfileNewPath = basepath + '/platformDataCockpit/inspectProfile'
                newPermissionList.push(inspectProfileNewPath)
              }
              else if (twoMenuPath == (basepath+'/systemOperate/DataMonitorCockpit/platformMonitorCockpit')) { // 平台大屏路由加进来
                let platformMonitorCockpitPath = basepath + '/DataMonitorCockpit/platformMonitorCockpit'
                newPermissionList.push(platformMonitorCockpitPath)
              } else if (twoMenuPath == (basepath+'/dataStatistics/dataBrain')) { // 数据统计/数据驾驶舱
                let platformMonitorCockpitPath = basepath + '/customerDataCockpit/index'
                newPermissionList.push(platformMonitorCockpitPath)
              } else if (twoMenuPath == (basepath+'/systemOperation/DataMonitorCockpit/customerMonitorCockpit')) { // 系统运维/数据监测
                let platformMonitorCockpitPath = basepath + '/DataMonitorCockpit/customerMonitorCockpit'
                newPermissionList.push(platformMonitorCockpitPath)
              } else if (twoMenuPath == (basepath+'/PlatformOperation/operateUserlist')) {
                let OperateUserlistPath = basepath + '/PlatformOperation/operateUserlist'
                newPermissionList.push(OperateUserlistPath)
              }
              else {
                newPermissionList.push(twoMenuPath)
              }
            }
          })
        } else {
          newPermissionList.push(item.path)
        }
      })

      // 不受权限控制的路由有添加客户 添加机构 佛冈大屏 授权等 // 还有很多不受权限控制的路由
      // 平台运营->数据大脑 数据驾驶舱(/platformDataCockpit/index) 和检查画像(inspectProfile) 我默认它有权限
      let noPermissionRouter = ['/PlatformOperation/adduserinfo/serviceauthorization','/MedicalInstitution/addOrgain',
      '/systemOperation/watchLogAudit', '/primaryIndexManage/primaryIndexDetailPage',
      '/primaryIndexManage/mergePrimaryIndex','/primaryIndexManage/mergePrimaryIndexLastStep','/primaryIndexManage/splitPrimaryIndex','/PlatformOperation/adduserinfo/addconstomerinfo','/PlatformOperation/adduserinfo/addplatforminfo',
      '/PlatformOperation/adduserinfo/databaseinfo','/PlatformOperation/adduserinfo/registercomplete','/DataMonitorCockpit/cloudMonitorCockpit',
      '/DataMonitorCockpit/oneCloudMonitorCockpit','/systemOperate/watchLogAudit','/operateFileView/index','/personCenter/index','/MedicalInstitutionLayoutBlank/institutionList', '/MedicalInstitutionLayoutBlank/addOrgain',
     '/platformDataCockpit/index','/platformDataCockpit/inspectProfile','/accountInfor/index','/safetySet/index','/personalRole/index','/fileView/index','/filePreview/index','/DataMonitorCockpit/backCloudMonitorCockpit',
     ,'/dataStorage/contentManage','/dataStorage/setStrategy','/dataStorage/storageStrategy','/dataStorage/contentManageLayoutBlank','/dataStorage/caseExport','/dataStorage/caseExportManage','/caseExportPage','/caseExportManage','/largeModel/index','/serviceManage/serviceDetailPage','/serviceManage/serviceDetailPage','/DataMonitorCockpit/systemMonitorCockpit',
     '/PlatformOperation/organizationalStructure','/CustomerUser/userList','/systemUpdate/productManagement/releaseOperate','/systemUpdate/productManagement/releaseRecord','/externalCapabilities/vendorDetail','/CustomerManagement/addFrontEndProcessor']
     //'/dataStorage/contentManage','/dataStorage/setStrategy' 这两个页面其他系统会用
      noPermissionRouter.forEach((val) => {
        let newRouterPath = basepath + val
        newPermissionList.push(newRouterPath)
      })
      // newPermissionList.push(oneRouter)
      // console.log('inputUrl',inputUrl)
      // console.log('newPermissionList=====',newPermissionList)
      // test: 开发时新增的路由，暂时在这里手动添加一下，免得因为没有权限进不去
      // newPermissionList.push('/systemUpdate/microserviceManagement');
      if (newPermissionList.indexOf(inputUrl) !== -1) {
        hasPermission = true
      } else {
        hasPermission = false
      }
    }

    return new Promise(function(resolve,reject) {
      resolve(hasPermission)
    })
  }
}

let router = {}
function setRouterConfig () {
  const creatRouter = () => {
    let base = '/'
    if (window.Config.subdir != '') {
      base = window.Config.subdir
    }
    return new VueRouter({
      mode: 'history',
      base: base,
      routes: currencyRoutes,
      scrollBehavior () {
        return { x: 0, y: 0 }
      }
    })
  }
  router = creatRouter()

  // 导航守卫
  router.beforeEach(async (to, from, next) => {
    if(to.path.includes('/MedicalInstitution/register')) {
      next()
      return
    }
    var reg = /\/([^\/]*)\//g
    var basePath = to.path.split('/')[1]
    if (process.env.NODE_ENV === 'development') {
      basePath = 'operate'
    }

    if (process.env.NODE_ENV !== 'development') {
      const arr = to.path.split('/')
      if (arr[1] === 'telemedicine') {
        window.location.href = to.path
        next()
      }
    }
    const DEFAULT_TITLE_SUFFIX = '- 运维管理';
    const pageTitle = to.meta?.title || '首页';
    document.title = `${pageTitle} ${DEFAULT_TITLE_SUFFIX}`;

    var newPath = process.env.NODE_ENV === 'development' ? '' : '/operate'
    // var curCustomerPath = newPath + '/dataStatistics/dataBrain'
    // var platformOperationCookpitPath = newPath + '/operationDataBrain/operationDataCockpit' // 平台运营 数据大脑->数据驾驶舱
    // var platformOperationProfilePath = newPath + '/operationDataBrain/inspectProfile' // 平台运营 数据大脑->检查画像
    // var officePath = newPath + '/DepartmentSystem/dataStatistics/dataCockpit'
    var curCustomerPath = newPath + '/customerDataCockpit/index'
    var platformOperationCookpitPath = newPath + '/platformDataCockpit/index' // 平台运营 数据大脑->数据驾驶舱
    var platformOperationProfilePath = newPath + '/platformDataCockpit/inspectProfile' // 平台运营 数据大脑->检查画像
    var officePath = newPath + '/departMentDataCockpit/index'
    var personCenterPage = newPath + '/personCenter/index'
    // 数据监测大屏
    var customerMonitorCockpit = newPath + '/DataMonitorCockpit/customerMonitorCockpit'
    var platformMonitorCockpit = newPath + '/DataMonitorCockpit/platformMonitorCockpit'
    var cloudMonitorCockpit = newPath + '/DataMonitorCockpit/cloudMonitorCockpit'
    // 平台运营->数据大脑->基础分析
    var basicAnalyseCockpit = newPath + '/dataBrain/basicAnalyse'
    // 嘉兴大屏 点击客户管理->数据统计
    if (typeof _dataCockpitName !== 'undefined') {
      if ((_dataCockpitName == 'jiaxing'|| _dataCockpitName == 'haining') && (to.path === curCustomerPath)) {
        if (localStorage.getItem('tenancy_id')) {
          if (_dataCockpitName == 'jiaxing') {
            window.open(`${jxCockPitIp}?tenancy_id=${localStorage.getItem('tenancy_id')}`, '_blank')
            return
          } else { //海宁
            window.open(`${hnCockPitIp}?tenancy_id=${localStorage.getItem('tenancy_id')}`, '_blank')
            return
          }
        }
      }
    }
    // 当跳转到数据大屏时  新窗口打开   from.path !== '/' 是为了避免循环打开窗口
    if ((to.path === curCustomerPath || to.path === platformOperationCookpitPath || to.path === platformOperationProfilePath ||  to.path === officePath || to.path === customerMonitorCockpit || to.path === platformMonitorCockpit || to.path === cloudMonitorCockpit || to.path === basicAnalyseCockpit) && (from.path !== '/')) {
      let { href } = router.resolve({ path: to.path })
      if (to.path === basicAnalyseCockpit) {
        href = `${href}?id=`+ to.query.id+ '&name='+to.query.name
      }
      // 金华大屏
      else if (to.path == curCustomerPath && typeof _dataCockpitName !== 'undefined' && _dataCockpitName == 'jinhua') {
        if (localStorage.getItem('tenancy_id')) {
          href = `${href}?tenancy_id=`+localStorage.getItem('tenancy_id')
        }
      }
      // 佛冈、东阳大屏
      else if (to.path == platformOperationCookpitPath && typeof _dataCockpitName !== 'undefined' && (_dataCockpitName == 'fogangxian' || _dataCockpitName == 'dongyang')) {
        if (localStorage.getItem('tenancy_id')) {
          href = `${href}?tenancy_id=`+localStorage.getItem('tenancy_id')
        }
      }
      window.open(href, '_blank')
      return
    }

    const imgMapping = ['/paservice/', '/paservice/IMGLIST', '/paservice/IMGPROOFREAD', '/paservice/paramsSetting/bacisParams']
    // if (basePath === 'operate') {
    var systemType = reg.exec(to.path)
    if (!systemType) {
      next()
    }
    var allSystemIds = sessionStorage.getItem('systemArray')
    if (allSystemIds && allSystemIds !== 'undefined') {
      var arr = JSON.parse(sessionStorage.getItem('systemArray'))
      for (var i in arr) {
        if (arr[i].product_code === systemType) {
          console.log("arr[i].id====",arr[i].id)
          sessionStorage.setItem('lastname', arr[i].id)
        }
      }
    }
    // if (to.path === personCenterPage && to.query.from) {
    //   console.log("to",to)
    //   to.component = hadHead
    // }
    // 判断是否是服务中心管理界面
    if (to.meta.module === 'serviceCenterManage') {
      sessionStorage.setItem('isServiceCenterManage', true)
    } else {
      sessionStorage.setItem('isServiceCenterManage', false)
    }
    if (imgMapping.includes(to.path)) { // 判断是否其他系统页面\
      router.app.$options.store.commit('app/set_iframeUrl', to.path) // 外部能力-cs -类型
      localStorage.setItem('iframeUrl', to.path)
      // to.path = '/about/text'
    }

    // 随机输入的URL 权限判断处理
    if (to.meta) {
      const curPath = to.path
      // 这里需要判断下不等于'/noPermission'  不然没权限时会跳转到 '/noPermission'然后又进入权限判断
      // 菜单接口里面又不会返回 '/noPermission' 这样它就被判断成无权限访问  然后又跳转到 '/noPermission'  形成了死循环
      if (curPath != '/noPermission' && curPath != '/home' && curPath != '/im/') {
        includePermission(curPath).then((hasPermission) => {
          if (!hasPermission) {
            if (typeof _dataCockpitName !== 'undefined') {
              // 佛冈 东阳  大屏支持免登录预览
              if (((_dataCockpitName == 'fogangxian' || _dataCockpitName == 'dongyang') && window.location.href.indexOf('/platformDataCockpit/index') != -1)) {
                next()
              }
              // 金华大屏 支持免登录预览
              else if ((_dataCockpitName == 'jinhua' && window.location.href.indexOf('/customerDataCockpit/index') != -1)) {
                next()
              }
              else {
                next({
                  path: '/noPermission'
                })
              }
            } else {
              next({
                path: '/noPermission'
              })
            }
          }
          else {
            next()
          }
        })
      } else if (curPath != '/noPermission' && curPath == '/home') {
        next()
      }
    }
    //next()
  })

  return router
}
export { setRouterConfig }
// export default router
