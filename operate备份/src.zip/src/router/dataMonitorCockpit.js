
import LayoutBlank from '@/layout/indexBlank'
var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
export default [
  // 数据驾驶舱 临时路由
  {
    path: basepath +'/DataMonitorCockpit',
    name: 'DataMonitorCockpit',
    component: LayoutBlank,
    redirect: basepath + '/DataMonitorCockpit/cloudMonitorCockpit',
    children: [
      {
        path: 'cloudMonitorCockpit',
        name: 'cloudMonitorCockpit',
        component: () => import('@/views/DataMonitorCockpit/cloudMonitorCockpit.vue'),
        meta: { title: '华为云主子云朵数据监测', name: 'dataCockpit' }
      },
      {
        path: 'backCloudMonitorCockpit',
        name: 'backCloudMonitorCockpit',
        component: () => import('@/views/DataMonitorCockpit/cloudMonitorCockpit.vue'),
        meta: { title: '华为云主子云朵数据监测', name: 'dataCockpit' }
      },
      {
        path: 'instituteMonitorCockpit',
        name: 'instituteMonitorCockpit',
        component: () => import('@/views/DataMonitorCockpit/instituteMonitorCockpit.vue'),
        meta: { title: '安吉县第一人民医院影像云数据监测', name: 'dataCockpit'}
      },
      {
        path: 'customerMonitorCockpit',
        name: 'customerMonitorCockpit',
        component: () => import('@/views/DataMonitorCockpit/customerMonitorCockpit.vue'),
        meta: { title: '安吉县区域检查一体化服务平台数据监测', name: 'dataCockpit'}
      },
      {
        path: 'systemMonitorCockpit',
        name: 'systemMonitorCockpit',
        component: () => import('@/views/DataMonitorCockpit/systemMonitorCockpit.vue'),
        meta: { title: '安吉县区域检查一体化服务平台数据监测', name: 'dataCockpit'}
      },
      {
        path: 'platformMonitorCockpit',
        name: 'anjiPlatformMonitorCockpit',
        component: () => import('@/views/DataMonitorCockpit/platformMonitorCockpit.vue'),
        meta: { title: '安吉县区域检查一体化服务平台数据监测', name: 'dataCockpit'}
      },
      {
        path: 'oneCloudMonitorCockpit',
        name: 'oneCloudMonitorCockpit',
        component: () => import('@/views/DataMonitorCockpit/oneCloudMonitorCockpit.vue'),
        meta: { title: '单个云朵平台数据监测', name: 'dataCockpit'}
      },
    ]
  },
  // 数据驾驶舱 临时路由
  {
    path: basepath +'/dataBrain',
    name: 'basicAnalysePage',
    component: LayoutBlank,
    //redirect: basepath + '/dataBrain/basicAnalyse',
    children: [
      {
        path: 'basicAnalyse',
        name: 'basicAnalyse',
        component: () => import('@/views/PlatformOperation/dataBrain/basicAnalyse.vue'),
        meta: { title: '基础分析', name: 'basicAnalyse' }
      },
    ]
  }
]