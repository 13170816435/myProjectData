// 智能诊断系统使用的运营页面路由
import Layout from '@/layout/index'
import LayoutBlank from '@/layout/indexBlank'
var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
export default [
  {
    path: basepath + '/MedicalInstitutionLayoutBlank',
    component: LayoutBlank,
    name: 'MedicalInstitutionLayoutBlank',
    children: [
      {
        path: 'institutionList',
        name: 'institutionListLayoutBlank',
        component: () => import('@/views/CustomerManagement/medicalinstitution/index.vue'),
        meta: { title: '医疗机构', icon: 'el-icon-s-release', intelligentDiagnosis: true }
      },
      {
        path: 'addOrgain',
        name: 'addOrgainLayoutBlank',
        component: () => import('@/views/CustomerManagement/medicalinstitution/addorgan.vue'),
        meta: { title: '新增医疗机构', icon: 'el-icon-s-release', intelligentDiagnosis: true }
      }
    ]
  },
  {
    path: basepath + '/intelligentDiagnosisLayoutBlank',
    component: LayoutBlank,
    name: 'intelligentDiagnosisLayoutBlank',
    hidden: true,
    children: [
      {
        path: 'inspectionRecord',
        name: 'inspectionRecordLayoutBlank',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/inspectionRecord.vue'),
        meta: { title: '检测记录', icon: 'el-icon-s-release', intelligentDiagnosis: true }
      },
      {
        path: 'caseManage',
        name: 'caseManageLayoutBlank',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/caseManage.vue'),
        meta: { title: '病例管理', icon: 'el-icon-s-release', intelligentDiagnosis: true }
      },
      {
        path: 'qualityEvaluation',
        name: 'qualityEvaluationLayoutBlank',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/qualityEvaluation.vue'),
        meta: { title: '质量评价', icon: 'el-icon-s-release', intelligentDiagnosis: true }
      },
      {
        path: 'diagnosisStatistics',
        name: 'diagnosisStatisticsLayoutBlank',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/diagnosisStatistics.vue'),
        meta: { title: '诊断统计', icon: 'el-icon-s-release', intelligentDiagnosis: true }
      },
    ]
  },
  {
    path: basepath + '/systemOperateLayoutBlank', // 系统运维
    component: LayoutBlank,
    name: 'systemOperateLayoutBlank',
    hidden: true,
    children: [
      {
        path: 'logAudit',
        name: 'logAuditLayoutBlank',
        component: () => import('@/views/PlatformOperation/systemOperate/logAudit.vue'),
        meta: { title: '日志审计', icon: 'el-icon-s-release', intelligentDiagnosis: true }
      },
    ]
  }
]