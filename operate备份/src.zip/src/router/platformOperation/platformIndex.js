import Layout from "@/layout/index";
import LayoutBlank from "@/layout/indexBlank";

var basepath = process.env.NODE_ENV === "development" ? "" : "/operate";
export default [
  {
    path: basepath + "/PlatformOperation",
    component: Layout,
    name: "operationCustomerHome",
    redirect: basepath + "/PlatformOperation/customerIndex",
    children: [
      {
        path: "customerIndex",
        name: "operationCustomerIndex",
        component: () =>
          import("@/views/PlatformOperation/customerIndex/index.vue"),
        meta: { title: "平台首页" },
      },
    ],
  },
  {
    path: basepath + "/PlatformOperation", // 客户管理-客户列表
    name: "OperateUser",
    component: Layout,
    redirect: basepath + "/PlatformOperation/operateUserlist",
    children: [
      {
        path: "operateUserlist", // 客户列表 customerList
        name: "operateUserlist",
        meta: { title: "客户列表" },
        component: () => import("@/views/PlatformOperation/user/userlist.vue"),
      },
      {
        path: "customerUserList", // 用户列表 customerUserList
        name: "customerUserList",
        meta: { title: "用户帐号" },
        component: () =>
          import(
            "@/views/PlatformOperation/customerManagement/user/userList.vue"
          ),
      },
      {
        path: "toolAccount",
        name: "toolAccount",
        component: () =>
          import("@/views/PlatformOperation/systemOperate/toolAccount.vue"),
        meta: { title: "工具账号", icon: "el-icon-s-release" },
      },
      {
        path: "organizationalStructure", // 组织架构
        name: "organizationalStructure",
        meta: { title: "组织架构" },
        component: () =>
          import(
            "@/views/PlatformOperation/customerManagement/organizationalStructure/index.vue"
          ),
      },
      {
        path: "userinfo",
        name: "userinfo",
        component: () => import("@/views/PlatformOperation/user/userinfo.vue"),
      },
      {
        path: "adduserinfo",
        name: "adduserinfo",
        redirect: basepath + "/PlatformOperation/adduserinfo/addconstomerinfo",
        component: () =>
          import("@/views/PlatformOperation/user/adduserinfo.vue"),
        children: [
          {
            path: "addconstomerinfo",
            name: "addconstomerinfo",
            meta: { title: "客户信息" },
            component: () =>
              import("@/views/PlatformOperation/user/addconstomerinfo.vue"),
          },
          {
            path: "addplatforminfo",
            name: "addplatforminfo",
            meta: { title: "平台信息" },
            component: () =>
              import("@/views/PlatformOperation/user/addplatforminfo.vue"),
          },
          {
            path: "serviceauthorization",
            name: "serviceauthorization",
            meta: { title: "授权信息" },
            component: () =>
              import("@/views/PlatformOperation/user/serviceauthorization.vue"),
          },
          {
            path: "databaseinfo",
            name: "databaseinfo",
            meta: { title: "数据库信息" },
            component: () =>
              import("@/views/PlatformOperation/user/databaseinfo.vue"),
          },
          {
            path: "registercomplete",
            name: "registercomplete",
            meta: { title: "信息填写完成" },
            component: () =>
              import("@/views/PlatformOperation/user/registercomplete.vue"),
          },
        ],
      },
    ],
  },
  {
    path: basepath + "/operateUser", // 运维用户
    component: Layout,
    name: "operateUser",
    redirect: basepath + "/operateUser/userList",
    hidden: true,
    children: [
      {
        path: "userList", // 用户列表
        name: "userList",
        meta: { title: "运维帐号" },
        component: () =>
          import("@/views/PlatformOperation/operateUser/userList.vue"),
      },
      {
        path: "userGroup", // 用户组权限
        name: "userGroup",
        meta: { title: "用户组权限" },
        component: () =>
          import("@/views/PlatformOperation/operateUser/userGroup.vue"),
      },
    ],
  },
  {
    path: basepath + "/serviceManage", // 服务管理
    component: Layout,
    name: "serviceManage",
    redirect: basepath + "/serviceManage/serviceList",
    hidden: true,
    children: [
      {
        path: "serviceList", // 服务户列表
        name: "serviceList",
        meta: { title: "服务列表" },
        component: () =>
          import("@/views/PlatformOperation/serviceManage/serviceList.vue"),
      },
      {
        path: "serviceApplyList", // 服务申请列表
        name: "serviceApplyList",
        meta: { title: "服务申请列表" },
        component: () =>
          import(
            "@/views/PlatformOperation/serviceManage/serviceApplyList.vue"
          ),
      },
      {
        path: "serviceDetailPage", // 服务详情
        name: "serviceDetailPage",
        meta: { title: "服务详情" },
        component: () =>
          import(
            "@/views/PlatformOperation/serviceManage/serviceDetailPage.vue"
          ),
      },
      {
        path: "customerPartner", // 合作客户
        name: "customerPartner",
        meta: { title: "合作客户" },
        component: () =>
          import("@/views/PlatformOperation/serviceManage/customerPartner.vue"),
      },
    ],
  },
  {
    path: basepath + "/productPromotion", // 产品推广
    component: Layout,
    name: "productPromotion",
    redirect: basepath + "/productPromotion/advertisingSettings",
    hidden: true,
    children: [
      {
        path: "advertisingSettings", // 广告设置
        name: "advertisingSettings",
        meta: { title: "广告设置" },
        component: () =>
          import(
            "@/views/PlatformOperation/productPromotion/advertisingSettings.vue"
          ),
      },
    ],
  },
  {
    path: basepath + "/systemManager", // 系统设置
    component: Layout,
    name: "systemManager",
    redirect: basepath + "/systemManager/smsTemplate",
    hidden: true,
    children: [
      {
        path: "dataDictionary", // 文案管理OfficialDocuments
        name: "operationDataDictionary",
        meta: { title: "数据字段" },
        component: () =>
          import("@/views/PlatformOperation/systemManager/dataDictionary.vue"),
      },
      {
        path: "smsTemplate", // 短信模板
        name: "smsTemplate",
        meta: { title: "短信模板" },
        component: () =>
          import("@/views/PlatformOperation/systemManager/smsTemplate.vue"),
      },
      {
        path: "administrativeRegion", // 行政区管理
        name: "administrativeRegion",
        meta: { title: "行政区管理" },
        component: () =>
          import(
            "@/views/PlatformOperation/systemManager/administrativeRegion.vue"
          ),
      },
      {
        path: "paramSet",
        name: "operationParamSet",
        meta: { title: "参数设置" },
        component: () =>
          import("@/views/PlatformOperation/systemManager/paramSet.vue"),
      },
      {
        path: 'primaryIndexPower',
        name: 'primaryIndexPower',
        meta: { title: '主索引权重'},
        component: () => import('@/views/PlatformOperation/systemManager/primaryIndexPower.vue')
      },
      {
        path: 'imageArchiveRegister',
        name: 'imageArchiveRegister',
        component: () => import('@/views/PlatformOperation/systemOperate/imageArchiveRegister.vue'),
        meta: { title: '存档服务注册', icon: 'el-icon-s-release' }
      },
    ]
  },
  {
    path: basepath + "/systemOperate", // 系统运维
    component: Layout,
    name: "systemOperate",
    redirect: basepath + "/systemOperate/operationMonitoring",
    hidden: true,
    children: [
      {
        path: "operationMonitoring",
        name: "operationMonitoring",
        component: () =>
          import(
            "@/views/PlatformOperation/systemOperate/operationMonitoring.vue"
          ),
        meta: { title: "运行监控", icon: "el-icon-s-release" },
      },
      {
        path: "messageReleaseList",
        name: "platformMessageReleaseList",
        component: () =>
          import(
            "@/views/PlatformOperation/systemOperate/messageReleaseList.vue"
          ),
        meta: { title: "信息发布", icon: "el-icon-s-release" },
      },
      {
        path: "cloudOperate",
        name: "cloudOperate",
        component: () =>
          import("@/views/PlatformOperation/systemOperate/cloudOperate.vue"),
        meta: { title: "云朵管理", icon: "el-icon-s-release" },
      },
      {
        path: "operationOrder",
        name: "operationOrder",
        component: () =>
          import("@/views/PlatformOperation/systemOperate/operationOrder.vue"),
        meta: { title: "服务工单", icon: "el-icon-s-release" },
      },
      {
        path: "serviceReport", // 服务报告推送
        name: "serviceReport",
        component: () =>import("@/views/PlatformOperation/servicereport/index.vue"),
      },
      {
        path: "smsAudit",
        name: "smsAudit",
        component: () =>
          import("@/views/PlatformOperation/systemOperate/smsAudit.vue"),
        meta: { title: "短信审计", icon: "el-icon-s-release" },
      },
      {
        path: "logAudit",
        name: "logAudit",
        component: () =>
          import("@/views/PlatformOperation/systemOperate/logAudit.vue"),
        meta: { title: "日志审计", icon: "el-icon-s-release" },
      },
      {
        path: "watchLogAudit",
        name: "watchLogAudit",
        component: () =>
          import("@/views/PlatformOperation/systemOperate/watchLogAudit.vue"),
        meta: { title: "查看日志", icon: "el-icon-s-release" },
      },
      {
        path: "DataMonitorCockpit/platformMonitorCockpit",
        name: "platformMonitorCockpit",
        redirect: basepath + "/DataMonitorCockpit/platformMonitorCockpit",
        meta: {
          title: "安吉县区域检查一体化服务平台数据监测",
          name: "dataCockpit",
        },
      },
      {
        path: "versionManage",
        name: "versionManage",
        component: () =>
          import("@/views/PlatformOperation/systemOperate/versionManage.vue"),
        meta: { title: "版本管理", icon: "el-icon-s-release" },
      },
      {
        path: 'imageArchiveParamSet',
        name: 'imageArchiveParamSet',
        component: () => import('@/views/PlatformOperation/systemOperate/imageArchiveParamSet.vue'),
        meta: { title: '参数配置', icon: 'el-icon-s-release' }
      },
      {
        path: "smsDataStatic",
        name: "smsDataStatic",
        component: () =>
          import("@/views/PlatformOperation/systemOperate/smsDataStatic.vue"),
        meta: { title: "短信统计", icon: "el-icon-s-release" },
      },
      {
        path: "portalSetAndLog", // 门户设置和操作日志
        name: "portalSetAndLog",
        component: () =>
          import("@/views/PlatformOperation/systemOperate/portalSetAndLog.vue"),
        meta: { title: "门户管理", icon: "el-icon-s-release" },
      },
    ],
  },
  {
    path: basepath + "/externalCapabilities", // 外部能力
    component: Layout,
    name: "externalCapabilities",
    redirect: basepath + "/externalCapabilities/abilities",
    hidden: true,
    children: [
      {
        path: "abilities", // 外部能力
        name: "abilities",
        meta: { title: "其他能力" },
        component: () =>
          import(
            "@/views/PlatformOperation/systemManager/externalcapabilities.vue"
          ),
      },
      {
        path: "dataView",
        name: "dataView",
        component: () =>
          import("@/views/PlatformOperation/intelligentDiagnosis/dataView.vue"),
        meta: { title: "数据概览", icon: "el-icon-s-release" },
      },
      {
        path: "firmManage",
        name: "platformFirmManage",
        component: () =>
          import(
            "@/views/PlatformOperation/intelligentDiagnosis/firmManage.vue"
          ),
        meta: { title: "厂商管理", icon: "el-icon-s-release" },
      },
      {
        path: "serviceManage",
        name: "platformServiceManage",
        component: () =>
          import(
            "@/views/PlatformOperation/intelligentDiagnosis/serviceManage.vue"
          ),
        meta: { title: "服务管理", icon: "el-icon-s-release" },
      },
      {
        path: "accreditManagement",
        name: "accreditManagement",
        component: () =>
          import(
            "@/views/PlatformOperation/intelligentDiagnosis/accreditManagement.vue"
          ),
        meta: { title: "授权管理", icon: "el-icon-s-release" },
      },
      {
        path: "inspectionRecord",
        name: "inspectionRecord",
        component: () =>
          import(
            "@/views/PlatformOperation/intelligentDiagnosis/inspectionRecord.vue"
          ),
        meta: { title: "检测记录", icon: "el-icon-s-release" },
      },
      {
        path: "serviceTime",
        name: "serviceTime",
        component: () =>
          import(
            "@/views/PlatformOperation/intelligentDiagnosis/serviceTime.vue"
          ),
        meta: { title: "服务耗时", icon: "el-icon-s-release" },
      },
      {
        path: "abnormalManagement",
        name: "abnormalManagement",
        component: () =>
          import(
            "@/views/PlatformOperation/intelligentDiagnosis/abnormalManagement.vue"
          ),
        meta: { title: "异常管理", icon: "el-icon-s-release" },
      },
      {
        path: "caseManage",
        name: "caseManage",
        component: () =>
          import(
            "@/views/PlatformOperation/intelligentDiagnosis/caseManage.vue"
          ),
        meta: { title: "病例管理", icon: "el-icon-s-release" },
      },
      {
        path: "qualityEvaluation",
        name: "qualityEvaluation",
        component: () =>
          import(
            "@/views/PlatformOperation/intelligentDiagnosis/qualityEvaluation.vue"
          ),
        meta: { title: "质量评价", icon: "el-icon-s-release" },
      },
      {
        path: "diagnosisStatistics",
        name: "diagnosisStatistics",
        component: () =>
          import(
            "@/views/PlatformOperation/intelligentDiagnosis/diagnosisStatistics.vue"
          ),
        meta: { title: "诊断统计", icon: "el-icon-s-release" },
      },
      {
        path: "imagePush",
        name: "imagePush",
        component: () =>
          import(
            "@/views/PlatformOperation/intelligentDiagnosis/imagePush.vue"
          ),
        meta: { title: "影像推送", icon: "el-icon-s-release" },
      },
      {
        path: "returnRecord",
        name: "returnRecord",
        component: () =>
          import(
            "@/views/PlatformOperation/intelligentDiagnosis/returnRecord.vue"
          ),
        meta: { title: "回传记录", icon: "el-icon-s-release" },
      },
      {
        path: "messageRecord",
        name: "messageRecord",
        component: () =>
          import("@/views/PlatformOperation/systemOperate/messageRecord.vue"),
        meta: { title: "短信记录", icon: "el-icon-s-release" },
      },
      {
        path: 'dataView',
        name: 'dataView',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/dataView.vue'),
        meta: { title: '数据概览', icon: 'el-icon-s-release' }
      },
      {
        path: 'firmManage',
        name: 'platformFirmManage',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/firmManage.vue'),
        meta: { title: '厂商管理', icon: 'el-icon-s-release' }
      },
      {
        path: 'serviceManage',
        name: 'platformServiceManage',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/serviceManage.vue'),
        meta: { title: '服务管理', icon: 'el-icon-s-release' }
      },
      {
        path: 'accreditManagement',
        name: 'accreditManagement',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/accreditManagement.vue'),
        meta: { title: '授权管理', icon: 'el-icon-s-release' }
      },
      {
        path: 'inspectionRecord',
        name: 'inspectionRecord',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/inspectionRecord.vue'),
        meta: { title: '检测记录', icon: 'el-icon-s-release' }
      },
      {
        path: 'serviceTime',
        name: 'serviceTime',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/serviceTime.vue'),
        meta: { title: '服务耗时', icon: 'el-icon-s-release' }
      },
      {
        path: 'abnormalManagement',
        name: 'abnormalManagement',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/abnormalManagement.vue'),
        meta: { title: '异常管理', icon: 'el-icon-s-release' }
      },
      {
        path: 'caseManage',
        name: 'caseManage',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/caseManage.vue'),
        meta: { title: '病例管理', icon: 'el-icon-s-release' }
      },
      {
        path: 'qualityEvaluation',
        name: 'qualityEvaluation',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/qualityEvaluation.vue'),
        meta: { title: '质量评价', icon: 'el-icon-s-release' }
      },
      {
        path: 'diagnosisStatistics',
        name: 'diagnosisStatistics',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/diagnosisStatistics.vue'),
        meta: { title: '诊断统计', icon: 'el-icon-s-release' }
      },
      {
        path: 'imagePush',
        name: 'imagePush',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/imagePush.vue'),
        meta: { title: '影像推送', icon: 'el-icon-s-release' }
      },
      {
        path: 'returnRecord',
        name: 'returnRecord',
        component: () => import('@/views/PlatformOperation/intelligentDiagnosis/returnRecord.vue'),
        meta: { title: '回传记录', icon: 'el-icon-s-release' }
      },
      {
        path: 'messageRecord',
        name: 'messageRecord',
        component: () => import('@/views/PlatformOperation/systemOperate/messageRecord.vue'),
        meta: { title: '短信记录', icon: 'el-icon-s-release' }
      },
      {
        path: 'intelligentServices',
        name: 'intelligentServices',
        component: () => import('@/views/PlatformOperation/intelligentServices/index.vue'),
        meta: { title: '智能服务', icon: 'el-icon-s-release',role:'operate' }
      },
      {
        path: 'vendorDetail',
        name: 'vendorDetail',
        component: () => import('@/views/PlatformOperation/intelligentServices/vendorManagement/vendorDetail.vue'),
        meta: { title: '智能服务厂商详情', icon: 'el-icon-s-release',role:'operate' }
      },
    ]
  },
  // 数据存储
  {
    path: basepath + "/myDataStorage",
    component: Layout,
    name: "operateDataStorage",
    redirect: basepath + "/myDataStorage/storageDevice",
    children: [
      {
        path: "storageDevice",
        name: "operateStorageDevice",
        component: () =>
          import("@/views/PlatformOperation/dataStorage/storageDevice.vue"),
        meta: { title: "存储设备", icon: "el-icon-s-release" },
      },
      {
        path: "storageAuthorization",
        name: "operateStorageAuthorization",
        component: () =>
          import(
            "@/views/PlatformOperation/dataStorage/storageAuthorization.vue"
          ),
        meta: { title: "存储授权", icon: "el-icon-s-release" },
      },
      {
        path: "contentManage",
        name: "operateContentManage",
        component: () =>
          import("@/views/PlatformOperation/dataStorage/contentManage.vue"),
        meta: { title: "存储数据", icon: "el-icon-s-release" },
      },
      {
        path: "videoManage",
        name: "operateVideoManage",
        component: () =>
          import("@/views/PlatformOperation/systemOperate/videoManage.vue"),
        meta: { title: "会议录屏", icon: "el-icon-s-release" },
      },
    ],
  },
  // 系统更新
  {
    path: basepath + "/systemUpdate",
    component: Layout,
    name: "systemUpdate",
    redirect: basepath + "/systemUpdate/productManagement",
    children: [
      // {
      //   path: 'releaseOperate',
      //   name: 'releaseOperate',
      //   component: () => import('@/views/PlatformOperation/systemOperate/ProductPage/releaseOperate.vue'),
      //   meta: { title: '工具软件', icon: 'el-icon-s-release' }
      // },
      // {
      //   path: 'releaseRecord',
      //   name: 'releaseRecord',
      //   component: () => import('@/views/PlatformOperation/systemOperate/ProductPage/releaseRecord.vue'),
      //   meta: { title: '发布记录', icon: 'el-icon-s-release' }
      // },

      {
        path: "productManagement",
        name: "productManagement",
        component: () =>
          import(
            "@/views/PlatformOperation/systemOperate/productManagement.vue"
          ),
        meta: { title: "产品管理", icon: "el-icon-s-release" },
        redirect: basepath + "/systemUpdate/productManagement/releaseOperate",
        children: [
          {
            path: "releaseOperate",
            name: "releaseOperate",
            component: () =>
              import(
                "@/views/PlatformOperation/systemOperate/ProductPage/releaseOperate.vue"
              ),
            meta: { title: "发布管理", icon: "el-icon-s-release" },
          },
          {
            path: "releaseRecord",
            name: "releaseRecord",
            component: () =>
              import(
                "@/views/PlatformOperation/systemOperate/ProductPage/releaseRecord.vue"
              ),
            meta: { title: "发布记录", icon: "el-icon-s-release" },
          },
        ],
      },

      {
        path: "officialDocuments", // 文案管理OfficialDocuments
        name: "officialDocuments",
        component: () =>
          import(
            "@/views/PlatformOperation/systemOperate/OfficialDocuments.vue"
          ),
        meta: { title: "文档发布", icon: "el-icon-s-release" },
      },
      {
        path: "dataBaseUpdateList",
        name: "dataBaseUpdateList",
        component: () =>
          import(
            "@/views/PlatformOperation/systemOperate/dataBaseUpdateList.vue"
          ),
        meta: { title: "数据库更新", icon: "el-icon-s-release" },
      },
      {
        path: "microserviceManagement",
        name: "microserviceManagement",
        component: () =>
          import(
            "@/views/PlatformOperation/systemOperate/microserviceManagement/index.vue"
          ),
        meta: { title: "微服务管理", icon: "el-icon-s-release" },
      },
    ],
  },
  {
    path: basepath + "/operateFileView",
    name: "FileView",
    component: LayoutBlank,
    children: [
      {
        path: "index",
        name: "operateFileViewIndex",
        component: () =>
          import("@/views/PlatformOperation/dataStorage/fileView.vue"),
        meta: { title: "影像浏览", icon: "el-icon-s-release" },
      },
    ],
  },
  {
    path: basepath + "/operateFilePreview",
    name: "operateFileView",
    component: LayoutBlank,
    children: [
      {
        path: "index",
        name: "operateFilePreview",
        component: () =>
          import("@/views/CustomerManagement/dataStorage/filePreview.vue"),
        meta: { title: "影像浏览", icon: "el-icon-s-release" },
      },
    ],
  },
  {
    path: basepath + "/operationDataBrain", // 数据大脑
    component: Layout,
    name: "platOperationDataBrain",
    redirect: basepath + "/operationDataBrain/operationDataBrainIndex",
    hidden: true,
    meta: {
      title: "数据大脑",
      icon: "el-icon-s-release",
      noCache: true,
      parenttitle: "平台运营",
      dataurl: "YiGongTi/ShuJuDaPing/ShuJuDaPingWeiJianWei.frm",
    },
    children: [
      {
        path: "operationDataBrainIndex",
        name: "operationDataBrainIndex",
        component: () => import("@/views/FrameView/index.vue"),
        meta: {
          title: "数据大脑",
          icon: "el-icon-s-release",
          name: "dataBrain",
          dataurl: "YiGongTi/ShuJuDaPing/ShuJuDaPingWeiJianWei.frm",
        },
      },
      {
        path: "operationDataCockpit",
        name: "operationDataCockpit",
        redirect: basepath + "/platformDataCockpit/index",
        meta: {
          title: "数据驾驶舱",
          icon: "el-icon-s-release",
          name: "operationDataCockpit",
          dataurl: "YiGongTi/ShuJuDaPing/ShuJuDaPingWeiJianWei.frm",
        },
      },
      {
        path: "inspectProfile",
        name: "inspectProfile",
        redirect: basepath + "/platformDataCockpit/inspectProfile",
        meta: {
          title: "检查画像",
          icon: "el-icon-s-release",
          name: "inspectProfile",
          dataurl: "YiGongTi/ShuJuDaPing/JianChaHuaXiang.frm",
        },
      },
      {
        path: "dataCockpitManage",
        name: "dataCockpitManage",
        redirect: basepath + "/platformDataCockpit/dataCockpitManage",
        meta: { title: "大屏管理", name: "dataCockpit", noCache: true },
      },
    ],
  },
  // 数据驾驶舱 临时路由
  {
    path: basepath + "/platformDataCockpit",
    name: "platformDataCockpit",
    component: LayoutBlank,
    redirect: basepath + "/platformDataCockpit/index",
    children: [
      {
        path: "index",
        name: "platformDataCockpitIndex",
        component: () =>
          import("@/views/PlatformOperation/dataCockpit/index.vue"),
        meta: { title: "数据驾驶舱", name: "dataCockpit", noCache: true },
      },
      {
        path: "inspectProfile",
        name: "platformDataCockpitInspectProfile",
        component: () =>
          import("@/views/PlatformOperation/dataCockpit/inspectProfile.vue"),
        meta: { title: "检查画像", name: "dataCockpit", noCache: true },
      },
    ],
  },
  // 数据驾驶舱 临时路由
  {
    path: basepath + "/platformDataCockpit",
    name: "temporaryPlatformDataCockpit",
    component: Layout,
    children: [
      {
        path: "dataCockpitManage",
        name: "platformDataCockpitdataCockpitManage",
        ///component: () => import('@/views/PlatformOperation/dataCockpit/dataCockpitManage.vue'),
        meta: { title: "大屏管理", name: "dataCockpit", noCache: true },
      },
    ],
  },
  // 数据大脑-数据视窗
  {
    path: basepath + "/operationDataBrain",
    name: "myDataBrain",
    component: Layout,
    children: [
      {
        path: "dataWindow",
        name: "dataWindow",
        component: () =>
          import("@/views/PlatformOperation/dataBrain/dataWindow.vue"),
        meta: { title: "数据视窗", name: "dataWindow", noCache: true },
      },
      // {
      //   path: 'basicAnalyse',
      //   name: 'basicAnalyse',
      //   component: () => import('@/views/PlatformOperation/dataBrain/basicAnalyse.vue'),
      //   meta: { title: '基础分析', name: 'basicAnalyse', noCache: true }
      // },
      {
        path: "imageShareReport",
        name: "imageShareReport",
        component: () =>
          import("@/views/PlatformOperation/dataBrain/imageShareReport.vue"),
        meta: { title: "统计报表", name: "imageShareReport", noCache: true },
      },
      {
        path: "pacsReport",
        name: "pacsReport",
        component: () =>
          import("@/views/PlatformOperation/dataBrain/pacsReport.vue"),
        meta: { title: "统计报表", name: "pacsReport", noCache: true },
      },
      {
        path: "telemedicineReport",
        name: "telemedicineReport",
        component: () =>
          import("@/views/PlatformOperation/dataBrain/telemedicineReport.vue"),
        meta: { title: "统计报表", name: "telemedicineReport", noCache: true },
      },
      {
        path: "teachReport",
        name: "teachReport",
        component: () =>
          import("@/views/PlatformOperation/dataBrain/teachReport.vue"),
        meta: { title: "统计报表", name: "teachReport", noCache: true },
      },
    ],
  },
  // {
  //   path: '/service',
  //   component: Layout,
  //   name: 'service',
  //   redirect: '/service/service_list',
  //   hidden: true,
  //   children: [
  //     {
  //       path: 'service_list',
  //       name: 'service_list',
  //       component: () => import('@/views/PlatformOperation/service/servicelist.vue'),
  //       meta: { title: '服务管理', icon: 'el-icon-s-release' }
  //     }
  //   ]
  // },
  // {
  //   path: '/data',
  //   component: Layout,
  //   name: 'datamanagement',
  //   redirect: '/data/datamanage_list',
  //   hidden: true,
  //   children: [
  //     {
  //       path: 'datamanage_list',
  //       name: 'datamanage_list',
  //       component: () => import('@/views/PlatformOperation/data/index.vue'),
  //       meta: { title: '数据管理', icon: 'el-icon-s-release' }
  //     }
  //   ]
  // },
  // {
  //   path: '/subscription',
  //   component: Layout,
  //   name: 'subscription',
  //   redirect: '/subscription/subscription_list',
  //   hidden: true,
  //   children: [
  //     {
  //       path: 'subscription_list',
  //       name: 'subscription_list',
  //       component: () => import('@/views/PlatformOperation/subscription/index.vue'),
  //       meta: { title: '发布订阅', icon: 'el-icon-s-release' }
  //     }
  //   ]
  // },
  // {
  //   path: '/videoconference',
  //   component: Layout,
  //   name: 'videoconference',
  //   redirect: '/videoconference/videoconference_list',
  //   hidden: true,
  //   children: [
  //     {
  //       path: 'videoconference_list',
  //       name: 'videoconference_list',
  //       component: () => import('@/views/PlatformOperation/videoconference/index.vue'),
  //       meta: { title: '视频会议', icon: 'el-icon-s-release' }
  //     }
  //   ]
  // }
];
