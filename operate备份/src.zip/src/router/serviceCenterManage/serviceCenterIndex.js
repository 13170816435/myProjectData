import Layout from '@/layoutServiceCenter/index'
import LayoutBlank from '@/layout/indexBlank'

var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
// var path = process.env.NODE_ENV === 'development' ? '/' : '/operate/'
//  meta: {title: '服务中心信息', module: 'serviceCenterManage'}, 每个都得加上 为了便于区分是否是服务中心管理页面
// 确认好是服务中心管理页面的 话  systemId 就是服务中心id
export default [
  {
    path: basepath + '/centerSet',
    component: Layout,
    name: 'serviceCenterManage',
    meta: {title: '服务中心信息', module: 'serviceCenterManage'},
    children: [
      {
        path: 'reload-service-center',
        name: 'reloadServiceCenter',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/reload-page/index.vue'),
        meta: {title: '切换服务中心', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'serviceCenterIndex',
        name: 'serviceCenterIndex',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/serviceCenterIndex.vue'),
        meta: {title: '综合设置', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'serviceCenterSet',
        name: 'serviceCenterSet',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/serviceCenterSet.vue'),
        meta: {title: '综合设置', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'serviceCenterInfor',
        name: 'serviceCenterInfor',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/serviceCenterInfor.vue'),
        meta: {title: '中心信息', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'consultRoom',
        name: 'consultRoom',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/consultRoom.vue'),
        meta: {title: '会诊诊室', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'expertTeam',
        name: 'expertTeam',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/expertTeam/expertTeam.vue'),
        meta: {title: '专家团队', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'consultSchedule',
        name: 'consultSchedule',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/consultSchedule/consultSchedule.vue'),
        meta: {title: '会诊排班', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'clinicOffice',
        name: 'clinicOffice',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/clinicOffice/clinicOffice.vue'),
        meta: {title: '门诊科室', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'clinicSchedule',
        name: 'clinicSchedule',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/clinicSchedule/clinicSchedule.vue'),
        meta: {title: '门诊排班', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'diagnosisSchedule',
        name: 'diagnosisSchedule',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/diagnosisSchedule/diagnosisSchedule.vue'),
        meta: {title: '诊断排班', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'inspectProject',
        name: 'myInspectProject',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/inspectProject.vue'),
        meta: {title: '检查项目', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'writingTemplate',
        name: 'myWritingTemplate',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/writingTemplate.vue'),
        meta: {title: '诊断模板', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'printTemPlate',
        name: 'myPrintTemPlate',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/printTemPlate.vue'),
        meta: {title: '打印模板', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'dataDictionary',
        name: 'myDataDictionary',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/dataDictionary.vue'),
        meta: {title: '数据字典', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'qualityControlManage',
        name: 'centerQualityControlManage',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/qualityControlManage.vue'),
        meta: {title: '质控管理', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'qualityControlModel',
        name: 'centerQualityControlModel',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/qualityControlModel.vue'),
        meta: {title: '质控管理-管理', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'evaluate',
        name: 'centerEvaluate',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/serviceCenterSet/evaluate.vue'
            ),
        meta: {title: '评价管理', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'ecgshaftSet',
        name: 'centerEcgshaftSet',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/EcgshaftSet.vue'),
        meta: {title: '心电轴配置', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'ecgMeasuredvalueSet',
        name: 'centerEcgMeasuredvalueSet',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/EcgMeasuredvalueSet.vue'),
        meta: {title: '心电测量值配置', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'defineCriticalValues',
        name: 'defineCriticalValues',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/defineCriticalValues.vue'),
        meta: {title: '危急值定义', icon: 'el-icon-s-release', noCache: true}
      },
      {
        path: 'dataDefinition',
        name: 'dataDefinition',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/dataDefinition.vue'),
        meta: {title: '资料定义', icon: 'el-icon-s-release', noCache: true}
      },

      /**
       * hlp: 2022-08-08
       */
      {
        path: 'itemCheck',
        name: 'itemCheck',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/checkItem'),
        meta: {title: '项目检查对照', noCache: true, module: 'serviceCenterManage'}
      },

      {
        path: 'formFollowUp',
        name: 'formFollowUp',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/formFollowUp'),
        meta: {title: '随访表单', noCache: true, module: 'serviceCenterManage'}
      },

      {
        path: 'postGroupManage',
        name: 'postGroupManage',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/scheduling/postGroup'),
        meta: {title: '岗位组管理', noCache: true, module: 'serviceCenterManage'}
      },

      {
        path: 'postManage',
        name: 'postManage',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/scheduling/post'),
        meta: {title: '岗位管理', noCache: true, module: 'serviceCenterManage'}
      },

      {
        path: 'scheduling',
        name: 'scheduling',
        component: () => import('@/views/ServiceCenterManagement/serviceCenterSet/scheduling/scheduling'),
        meta: {title: '排班安排', noCache: true, module: 'serviceCenterManage'}
      }

      /** --------  */
    ]
  },
  {
    path: basepath + '/servcieCenterPersonCenter',
    component: Layout,
    name: 'servcieCenterPersonCenter',
    children: [
      {
        path: 'index',
        name: 'serviceCenterPersonCenterIndex',
        component: () => import('@/views/personCenter/index.vue'),
        meta: {title: '个人中心', icon: 'el-icon-s-release'}
      },
    ]
  },
  {
    path: basepath + '/organAndHospital',
    component: Layout,
    name: 'organAndHospital',
    meta: {title: '远程医疗', module: 'serviceCenterManage', noCache: true},
    children: [
      {
        path: 'myContractedhospital',
        name: 'myContractedhospital',
        component: () => import('@/views/ServiceCenterManagement/organAndHospital/myContractedhospital.vue'),
        meta: {title: '合作医院', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'myServicedoctor',
        name: 'myServicedoctor',
        component: () => import('@/views/ServiceCenterManagement/organAndHospital/myServicedoctor.vue'),
        meta: {title: '服务医生', module: 'serviceCenterManage', noCache: true}
      },

    ]
  },
  {
    path: basepath + '/permissionSet',
    component: Layout,
    name: 'permissionSet',
    hidden: true,
    meta: {title: '用户权限', module: 'serviceCenterManage'},
    children: [
      {
        path: 'userlist',
        name: 'centerUserlist',
        component: () => import('@/views/CustomerManagement/user/index.vue'),
        meta: {
          title: '用户账号',
          module: 'serviceCenterManage',
          noCache: true
        }
      },
      {
        path: 'permissionIndex',
        name: 'permissionIndex',
        component: () =>
          import(
            '@/views/ServiceCenterManagement/permissionsSet/permissionIndex.vue'
            ),
        meta: {
          title: '账号授权',
          module: 'serviceCenterManage',
          noCache: true
        }
      },
      {
        path: 'permissionGroup',
        name: 'permissionGroup',
        component: () => import('@/views/ServiceCenterManagement/permissionsSet/permissionGroup.vue'),
        meta: {title: '用户组', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'userAuthority',
        name: 'userAuthority',
        component: () => import('@/views/ServiceCenterManagement/permissionsSet/userAuthority.vue'),
        meta: {title: '用户授权', module: 'serviceCenterManage', noCache: true}
      }
    ]
  },
  {
    path: basepath + '/userReviews',
    component: Layout,
    name: 'userReviews',
    hidden: true,
    children: [
      {
        path: 'userReviewsList',
        name: 'userReviewsList',
        component: () => import('@/views/ServiceCenterManagement/userReviews/userReviewsList.vue'),
        meta: {title: '用户评价', module: 'serviceCenterManage', noCache: true}
      }
    ]
  },
  {
    path: basepath + '/dataStatic',
    component: Layout,
    name: 'dataStatic',
    hidden: true,
    children: [
      {
        path: 'remoteConsultation',
        name: 'remoteConsultation',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/remoteConsultation.vue'),
        meta: {title: '会诊统计', module: 'serviceCenterManage', noCache: true}
      },

      {
        path: 'remoteDiagnosis',
        name: 'remoteDiagnosis',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/remoteDiagnosis.vue'),
        meta: {title: '诊断统计', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'remoteDiagnosisApply',
        name: 'remoteDiagnosisApply',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/remote-diagnosis-apply-2'),
        meta: {title: '诊断申请量', module: 'serviceCenterManage', noCache: true}
      },

      {
        path: 'remoteDiagnosisWork',
        name: 'remoteDiagnosisWork',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/remote-diagnosis-work-2'),
        meta: {title: '诊断工作量', module: 'serviceCenterManage', noCache: true}
      },

      {
        path: 'remoteDiagnosisCenter',
        name: 'remoteDiagnosisCenter',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/remote-diagnosis-center'),
        meta: {title: '中心诊断量', module: 'serviceCenterManage', noCache: true}
      },

      {
        path: 'agreementRate',
        name: 'agreementRate',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/agreementRate'),
        meta: {title: '诊断符合率', module: 'serviceCenterManage', noCache: true}
      },
      /** ----------- */

      {
        path: 'diagnosisTime',
        name: 'diagnosisTime',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/diagnosisTime/diagnosisTime.vue'),
        meta: {title: '诊断耗时', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'positiveRate',
        name: 'positiveRate',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/positiveRate.vue'),
        meta: {title: '阳性率统计', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'twoWayReferral',
        name: 'twoWayReferral',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/twoWayReferral.vue'),
        meta: {title: '转诊统计', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'remoteWardRounds',
        name: 'remoteWardRounds',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/remoteWardRounds.vue'),
        meta: {title: '查房统计', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'diseaseStatistics',
        name: 'diseaseStatistics',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/diseaseStatistics.vue'),
        meta: {title: '病种统计', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'serviceCenterReport',
        name: 'serviceCenterReport',
        component: () => import('@/views/ServiceCenterManagement/dataStatic/serviceCenterReport/serviceCenterReport.vue'),
        meta: {title: '服务报告', module: 'serviceCenterManage', noCache: true}
      },
    ]
  },
  {
    path: basepath + '/teachingManage',
    component: Layout,
    name: 'teachingManage',
    hidden: true,
    children: [
      {
        path: 'courseManage',
        name: 'courseManage',
        component: () => import('@/views/ServiceCenterManagement/teachingManage/courseManage.vue'),
        meta: {title: '课程管理', module: 'serviceCenterManage', noCache: true}
      },
      {
        path: 'courseDetail/:id',
        name: 'eduCourseDetail',
        component: () => import('@/views/ServiceCenterManagement/teachingManage/courseDetail.vue'),
        meta: {title: '课程详情', module: 'serviceCenterManage', noCache: true}
      },
      { // 课程统计
        path: 'teachingStatistical',
        name: 'teachingStatistical',
        component: () => import('@/views/ServiceCenterManagement/teachingManage/teachingStatistical.vue'),
        meta: {title: '课程统计', noCache: true}
      },
      {
        path: 'studentManagement',
        name: 'studentManagement',
        component: () => import('@/views/ServiceCenterManagement/teachingManage/studentManagement.vue'),
        meta: {title: '学员管理', module: 'serviceCenterManage', noCache: true}
      }
    ]
  },
  // 教学课件浏览
  {
    path: basepath + '/education',
    name: 'courseWare',
    component: LayoutBlank,
    hidden: false,
    children: [
      {
        path: 'courseWare',
        name: 'edu-courseWare',
        component: () => import('@/views/ServiceCenterManagement/teachingManage/courseWare.vue'),
        meta: {title: '学习课件'}
      }
    ]
  }
]
