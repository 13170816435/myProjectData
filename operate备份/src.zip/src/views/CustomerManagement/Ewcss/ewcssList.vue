<template>
  <div class="jurisdictionlist">
    <div class="title-bar flex_row">
      <div class="tl flex_1">
        <span class="title-name clr_303"><i class="iconfont icondingwei mr10"></i>集中预约</span>
      </div>
      <div class="tr flex_1">
        <span @click="isShowinfoFn('add')" class="function-btn bg_e6 clr_ff">
          <i class="iconfont iconxinzeng"></i>新增系统
        </span>
      </div>
    </div>
    <div class="ewcssContainer" v-bind:class="{'noTableData':pacsList.length===0}">
      <div class="list flex_row flex_wrap">
        <div class="list-item" v-for="(item, index) in pacsList" :key="index">
          <div class="flex_row">
            <img class="pacs_img" :src="item.product_code == 'UIS'?CS:item.product_code == 'RIS'?FS:item.product_code == 'EIS'?NJ:XD" />
            <div class="ml15 flex_1 productContent">
              <div class="f20 clr_303 title over_ell" v-bind:title="item.name">{{item.name}}</div>
              <div class="clr_666 mt15">授权产品：检查预约</div>
            </div>
            <div class="item_btn ml10"  @click="isShowinfoFn('edit', item.id)">编辑</div>
            <div class="item_btn ml10" v-if="isShowManageBtn" @click="isShowinfoFn('operate', item.id, item.product_code, item.is_jump)">管理</div>
          </div>
          <div class="flex_row mt10 border_bd pb10">
            <div class="tl adminInfor" v-bind:title="'管理人员：'+ item.admin_name"><span class="clr_999">管理人员：</span> <span class="clr_303">{{item.admin_name}}</span></div>
            <div class="ml20"><span class="clr_999">联系电话：</span> <span class="clr_303">{{item.admin_phone}}</span></div>
          </div>
          <div class="flex_row mt10">
            <div class="tl">
              <div class="clr_999">使用机构：</div>
              <div class="clr_oarange pl10">({{item.institution_count}}家)</div>
            </div>
            <div class="flex_1 clr_999 over_ell_3"><span v-for="(itemname, index) in item.institution_names" :key="itemname"><span v-if="index!=0">、</span>{{itemname}}</span></div>
          </div>
        </div>
      </div>
    </div>
    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="isPacsinfo"
      :show-close="false"
      :withHeader="false"
      :wrapperClosable="this.operateSystemInfo.title === '编辑' ? true : false"
      :direction="direction"
      :before-close="handleClose">
      <ewcssInfor ref="info" :pacsinfo="operateSystemInfo" :pageInfo="InstitutionPage" @closeFn="closeFn" @selectInstitionListFn="selectInstitionListFn" @selectCurRowFn="selectCurRow" @delInstitutionFn="delInstitutionFn"
        @changePhone="changePhone" @ChoiceOrganFn="ChoiceOrganFn" @serchListFn="serchListFn" @getSerchName="getSerchName" @getAdminNameFn="getAdminNameFn" @pageSizeChangeFn="pageSizeChangeFn" @CheckOfficeidsFn="CheckOfficeidsFn"
        @activeSystemFn="activeSystemFn" @submitForm="submitForm" @isAddInstution="isAddInstution" @getRowKeys="getRowKeys" @instclose="instclose"></ewcssInfor>
    </el-drawer>
  </div>
</template>

<script>
import Vue from 'vue'
// import JSEncrypt from 'jsencrypt'
import JSEncrypt from '@/utils/jsencrypt.min'
import { mapGetters } from 'vuex'
import ewcssInfor from './ewcssInfor'
import { addPacsSystems, getInstitutionList, getPascList, getPacsSystemsInfoByid, putPacsSystems, getPasServicecList } from '@/api/platform_costomer/institution'
import { getLoginName, getConfigurations } from '@/api/commonHttp'
// import { setCachedSystemId } from 'tomtaw-caches'
export default {
  components: {
    ewcssInfor
  },
  data () {
    return {
      CS: require('../../../assets/images/CS_Image.png'), // 超声
      FS: require('../../../assets/images/Appoint_Image.png'), // 放射
      NJ: require('../../../assets/images/NJ_Image.png'), // 内镜
      XD: require('../../../assets/images/Appoint_Image.png'), // 心电
      info: '',
      isPacsinfo: false,
      direction: 'rtl',
      pacsList: [],
      isactive: '',
      isoperateactive: '',
      operateSystemInfo: {
        title: '新增系统',
        serchName: '',
        activesystem: '',
        systemList: [{ code: '', name: '' }], // 授权产品
        isAdminname: false,
        product_name: '',
        formInfo: {
          type: 4,
          product_code: 'ExamSchedule',
          name: '',
          admin_phone: '',
          admin_name: ''
        },
        rules: {
          product_code: [{ required: true, message: '请选择产品名称', trigger: 'change' }],
          name: [{ required: true, message: '请输入系统名称', trigger: 'blur' }],
          admin_phone: [{ required: true, message: '请输入管理员电话', trigger: 'change' }],
          admin_name: [{ required: true, message: '请输入管理员姓名', trigger: 'change' }]
        },
        isChioseOrgan: false,
        institutionList: [], // 机构列表
        deplist: [],
        multipleSelection: [] // 机构列表选中机构
      },
      isUpdate: false,
      isFirstChange: true,
      InstitutionPage: {
        eof: 1,
        page_index: 1,
        page_size: 15,
        total_count: 0,
        total_pages: 1
      },
      choiseList: [], // select 选中机构
      isChoiceFirst: true // 是否第一次select
    }
  },
  computed: {
    ...mapGetters(['isShowManageBtn'])
  },
  created () {
    this.getPascListFn()
    // 加密函数
    this.getConfigurationsFn()
  },
  methods: {
    async getConfigurationsFn () {
      const res = await getConfigurations('TransmissionSecurity.RSA.PublicKey')
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) { // 注册方法
          const pubKey = res.data// ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt()
          encryptStr.setPublicKey(pubKey) // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()) // 进行加密
          return data
        }
      }
    },
    changePhone () {
      if (this.isUpdate) {
        // 是否是第一次改变
        if (this.isFirstChange) {
          this.operateSystemInfo.formInfo.admin_phone = ''
          this.operateSystemInfo.formInfo.admin_name = ''
        }
        this.isFirstChange = false
      }
    },
    // 系统列表
    async getPascListFn () {
      var _type = 4
      const res = await getPascList(_type)
      if (res.code === 0) {
        this.pacsList = res.data
      }
    },
    // 授权产品列表
    async getPasServicecListFn () {
      const res = await getPasServicecList()
      if (res.code === 0) {
        this.operateSystemInfo.systemList = res.data
      }
    },
    isAddInstution () {
      if (!this.operateSystemInfo.formInfo.product_code) {
        this.$message({
          type: 'warning',
          message: '请选择授权产品！'
        })
        return
      }
      this.getInstitutionListFn()
      this.operateSystemInfo.isChioseOrgan = true
    },
    // 操作按钮
    isShowinfoFn (type, id, code, isopen) {
      if (type === 'add') {
        this.isPacsinfo = true
        this.operateSystemInfo.title = '新增系统'
        this.isUpdate = false
        this.getPasServicecListFn()
        this.operateSystemInfo = this.$options.data().operateSystemInfo
      } else if (type === 'operate') {
        // if (code) {
        //   sessionStorage.setItem('currentSystemClass', code)
        // }
        // if (id) {
        //   sessionStorage.setItem('lastname', id)
        // }
        var path = process.env.NODE_ENV === 'development' ? '/' : '/EWCSS'
        const href = configUrl.frontEndUrl + path + '/ExamSchedule/ScheduleList'
        sessionStorage.setItem('system_id', id)
        //setCachedSystemId(id)
        window.open(href, '_blank')
      } else {
        this.isactive = id
        this.isPacsinfo = true
        this.isUpdate = true
        this.isFirstChange = true
        this.operateSystemInfo.title = '编辑'
        const responce = getPacsSystemsInfoByid(id) // 详情接口
        responce.then(res => {
          if (res.code === 0) {
            this.operateSystemInfo.product_name = res.data.product_name
            this.operateSystemInfo.formInfo.product_code = res.data.product_code
            this.operateSystemInfo.formInfo.id = res.data.id
            this.operateSystemInfo.formInfo.name = res.data.name
            this.operateSystemInfo.formInfo.admin_phone = res.data.admin_phone
            this.operateSystemInfo.formInfo.admin_name = res.data.admin_name
            this.operateSystemInfo.multipleSelection = res.data.institutions
            this.operateSystemInfo.institution_count = res.data.institution_count
            this.operateSystemInfo.isAdminname = true
            this.isChoiceFirst = true
          }
        })
      }
    },
    // 选择产品类型
    activeSystemFn (index, code) {
      this.operateSystemInfo.activesystem = index
      this.operateSystemInfo.formInfo.product_code = code
    },
    // 手机号姓名匹配
    async getAdminNameFn () {
      var _phone = this.operateSystemInfo.formInfo.admin_phone
      var phoneReg = /^1[3456789]\d{9}$/
      if (!phoneReg.test(_phone)) {
        return
      }
      var url = `/users/lite/${_phone}`
      var res = await getLoginName(url)
      if (res.code === 0) {
        this.operateSystemInfo.formInfo.admin_name = res.data ? res.data.name : ''
        this.operateSystemInfo.isAdminname = true
      } else {
        this.operateSystemInfo.isAdminname = false
        this.operateSystemInfo.formInfo.admin_name = ''
      }
    },
    handleClose (done) {
      done()
    },
    // 关闭 选择机构
    instclose () {
      this.operateSystemInfo.institutionList.forEach(item => {
        this.$nextTick(() => {
          this.$refs.info.$refs.institutions.toggleRowSelection(item, false)
        })
      })
      this.operateSystemInfo.isChioseOrgan = false
    },
    closeFn () {
      var info = {
        type: 'cancel',
        refs: this.$refs['info'].$refs,
        formName: 'formInfo'
      }
      this.submitForm(info)
    },
    // 获取机构列表
    async getInstitutionListFn () {
      let filter_system_id = ''
      if (this.operateSystemInfo.title !== '新增系统') {
        filter_system_id = '&filter_system_id=' + this.isactive
      }
      const _url = '/institutions?offset=' + this.InstitutionPage.page_index + '&limit=' + this.InstitutionPage.page_size + filter_system_id
      const res = await getInstitutionList(_url)
      if (res.code === 0) {
        res.data.forEach(item => {
          item.office_ids = []
          if (item.offices.length === 1) {
            item.office_ids[0] = item.offices[0].id
          }
        })
        this.operateSystemInfo.institutionList = res.data
        this.InstitutionPage = res.page
        // 先全部清空下
        this.$refs.info.$refs.institutions.clearSelection()
        // if (this.operateSystemInfo.title === '编辑') {
          // 勾上已选中的
          res.data.forEach(itemids => {
            this.operateSystemInfo.multipleSelection.forEach(item => {
              if (itemids.id === item.id) {
                this.$nextTick(() => {
                  this.$refs.info.$refs.institutions.toggleRowSelection(itemids, true)
                })
                itemids.office_ids = item.office_ids
              }
            })
          })
        // }
      }
    },
    getRowKeys (row) {
      return row.id
    },
    // 分页
    pageSizeChangeFn (info) {
      this.InstitutionPage.page_index = info.page
      this.InstitutionPage.page_size = info.limit
      this.getInstitutionListFn()
    },
    // 选中某一行
    selectCurRow (selection, row) {
      const self = this
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1
      // 去掉选中时
      if (!selected) {
       self.operateSystemInfo.multipleSelection.forEach((item,i) => {
           if (item.id === row.id) {
             self.operateSystemInfo.multipleSelection.splice(i,1)
           }
        })
      }
    },
    // 去掉数组元素 里面对象 id值相同的
    clearCommonId (arr) {
      let obj = {}
      let peon = arr.reduce((cur,next) => {
          obj[next.id] ? "" : obj[next.id] = true && cur.push(next)
          return cur
      },[])
      return peon
    },
    handleInstituSelectionChange (val) {
      const self = this
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item)
      })
      self.operateSystemInfo.multipleSelection = self.clearCommonId(self.operateSystemInfo.multipleSelection)
    },
    // 机构 select change事件
    selectInstitionListFn (val) {
      // if (this.InstitutionPage.page_index === 1 && this.isChoiceFirst) {
      //   this.choiseList = [...this.operateSystemInfo.multipleSelection, ...rows]
      // } else {
      //   this.choiseList = rows
      // }
      // this.isChoiceFirst = false
      const self = this
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item)
      })
      self.operateSystemInfo.multipleSelection = self.clearCommonId(self.operateSystemInfo.multipleSelection)
    },
    // 机构 提交
    ChoiceOrganFn (type) {
      // if (type === 'commit') {
      //   this.operateSystemInfo.multipleSelection = this.choiseList
      // }
      this.instclose()
    },
    CheckOfficeidsFn (val) {
      // console.log(val)
    },
    delInstitutionFn (id) {
      this.$confirm('是否删除这条机构信息？', '删除信息', {
        distinguishCancelAndClose: true,
        confirmButtonText: '删除',
        cancelButtonText: '取消'
      }).then(() => {
        this.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === id) {
            if (this.operateSystemInfo.institutionList.length > 0) {
              this.$refs.info.$refs.institutions.toggleRowSelection(item, false)
            }
            this.operateSystemInfo.multipleSelection.splice(i, 1)
            this.$message({
              type: 'success',
              message: '删除成功'
            })
          }
        })
      })
    },
    async addPacsSystemsFn () {
      const loading = this.$loading({
        lock: true,
        text: '正在新增，请稍等...',
        spinner: 'el-icon-loading',
        background: 'rgba(255, 255, 255, 0.6)'
      })
      const _params = this.operateSystemInfo.formInfo
      var _institutionList = []
      this.operateSystemInfo.multipleSelection.forEach(item => {
        var info = {}
        info.id = item.id
        info.office_ids = item.office_ids
        _institutionList.push(info)
      })
      _params.institutions = _institutionList
      // 对手机号加密
      var adminPhone = _params.admin_phone
      _params.admin_phone = this.$getRsaCode(_params.admin_phone)
      var res = null
      var tipmsg = '新增系统成功！'
      if (_params.id) {
        res = await putPacsSystems(_params)
        tipmsg = '修改系统成功！'
      } else {
        res = await addPacsSystems(_params)
      }
      loading.close()
      if (res.code === 0) {
        this.$message({
          type: 'success',
          message: tipmsg
        })
        this.isPacsinfo = false
        this.getPascListFn()
        this.operateSystemInfo = this.$options.data().operateSystemInfo
      } else {
        this.operateSystemInfo.formInfo.admin_phone = adminPhone
        this.$message({
          type: 'error',
          message: res.msg
        })
      }
    },
    getSerchName (val) {
      this.operateSystemInfo.serchName = val
    },
    // 选择机构页面 查询按钮
    async serchListFn () {
      const _url = '/institutions?offset=1' + '&limit=' + this.InstitutionPage.page_size + '&name=' + this.operateSystemInfo.serchName
      const res = await getInstitutionList(_url)
      if (res.code === 0) {
        this.operateSystemInfo.institutionList = res.data
      }
    },
    submitForm (info) {
      if (info.type === 'commit') {
        if (!this.operateSystemInfo.formInfo.product_code) {
          this.$message({ type: 'error', message: '请选择产品' })
          return
        }
        if (!this.operateSystemInfo.formInfo.name) {
          this.$message({ type: 'error', message: '请输入产品名称' })
          return
        }
        if (!this.operateSystemInfo.formInfo.admin_phone) {
          this.$message({ type: 'error', message: '请输入管理员电话' })
          return
        }
        var phoneReg = /^1[3456789]\d{9}$/
        // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
        if (!this.isUpdate || (this.isUpdate && !this.isFirstChange)) {
          if (!phoneReg.test(this.operateSystemInfo.formInfo.admin_phone)) {
            this.$message({
              message: '请输入正确的手机号码!',
              type: 'warning'
            })
            return false
          }
        }
        if (!this.operateSystemInfo.formInfo.admin_name) {
          this.$message({ type: 'error', message: '请输入管理员姓名' })
          return
        }
        this.addPacsSystemsFn()
      } else {
        this.isPacsinfo = false
        this.isactive = ''
        this.operateSystemInfo = this.$options.data().operateSystemInfo
      }
    }
  }
}
</script>

<style lang="less" scoped>
.jurisdictionlist {
  height:100%;
  .ewcssContainer {
    height:calc(100% - 47px);
    padding: 10px 5px;
    overflow: auto;
    // background: #fff;
    .list-item{
      width: calc(33.33333% - 20px); 
      height: 210px; 
      padding: 20px 15px 15px 20px;
      margin: 10px;
      // min-width: 500px;
      border-radius: 3px;
      box-shadow: 0 2px 3px 0 rgba(0,0,0,.02);
      box-sizing: border-box;
      border:1px solid rgba(220, 223, 230, 1);
      cursor: pointer;
      .active{
        background: rgba(10, 112, 176) !important;
        color: #fff !important;
      }
      .pacs_img{
        width: 64px;
        height: 64px;
        vertical-align: middle;
      }
      .title{
        // max-width: 200px;
        width:100%;
      }
      .productContent{
        width:calc(100% - 227px);
      }
      .item_btn{
        width:64px;
        height:30px;
        line-height: 30px;
        text-align: center;
        background:rgba(255,255,255,1);
        border:1px solid rgba(10, 112, 176, 0.5);
        border-radius:3px;
        color: #0A70B0;
      }
      .item_btn:hover{
        background-color: #0a70b0;
        color: #fff;
      }
      .border_bd{
        border-bottom: 1px dashed #DCDFE6;
      }
      .iconfont{
        margin-right: 8px;
      }
    }
    .list-item:hover{
      box-shadow: 0 1px 5px rgba(0,0,0,.1);
      border: 1px solid rgba(10,112,176,.3);
    }
    .list-item:hover .title{
      color: #0A70B0;
    }
  }
}
.adminInfor{
  width:50%;
  max-width: 170px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

@media screen  and (max-width:1500px ){
  .list-item{
      width: calc(50% - 20px)!important; 
  }
}
</style>
