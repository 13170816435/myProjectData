<template>
  <div class="collect-main collect-main_color">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>叫号系统
          <i class="iconfont iconzhankaishouqi"></i> 语音设置
        </span>
      </div>
    </div>
    <div
      class="table-content"
      style="height: calc(100vh - 98px); overflow: auto"
    >
      <div class="div-base">
        <el-form :model="voiceConfig" label-width="100px">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>语音厂商配置</span>
              <!-- <el-button style="float: right; padding: 3px 0" type="text"
                >增加一个</el-button
              > -->
            </div>
            <span>服务端合成</span>
            <br />
            <div
              v-for="item in cloudVoiceList"
              :key="item.id"
              class="check-item"
            >
              <el-radio
                :label="item.id"
                v-model="voiceConfig.VendorType"
                @change="GetConfig"
                >{{ item.label }}</el-radio
              >
            </div>
            <el-divider class="divider"></el-divider>
            <span>客户端合成</span>
            <br />
            <div
              v-for="item in clientVoiceList"
              :key="item.id"
              class="check-item"
            >
              <el-radio
                :label="item.id"
                v-model="voiceConfig.VendorType"
                @change="GetConfig"
                >{{ item.label }}</el-radio
              >
            </div>
          </el-card>

          <el-card class="box-card" v-if="voiceConfig.VendorType != 5">
            <div slot="header" class="clearfix">
              <span>语音厂商参数</span>
              <!-- <el-button style="float: right; padding: 3px 0" type="text"
                >增加一个</el-button
              > -->
            </div>
            <el-row :span="24">
              <el-col
                :span="24"
                v-if="getShow(['1','2', '3'])"
              >
                <el-form-item label="AppId：" prop="AppId">
                  <el-input
                    size="small"
                    v-model="voiceConfig.AppId"
                    style="width: 500px"
                  ></el-input>
                </el-form-item>
              </el-col>

              <el-col
                :span="24"
                v-if="getShow(['2', '3', '4'])"
              >
                <el-form-item label="密钥ID：" prop="SecretId">
                  <el-input
                    size="small"
                    v-model="voiceConfig.SecretId"
                    style="width: 500px"
                  ></el-input>
                </el-form-item>
              </el-col>
              <el-col
                :span="24"
                v-if="getShow(['2', '3', '4'])"
              >
                <el-form-item label="key：" prop="SecretKey">
                  <el-input
                    size="small"
                    v-model="voiceConfig.SecretKey"
                    style="width: 500px"
                  ></el-input>
                </el-form-item>
              </el-col>
              <el-col
                :span="24"
                v-if="getShow(['4'])"
              >
                <el-form-item label="区域：" prop="Region">
                  <el-input
                    size="small"
                    v-model="voiceConfig.Region"
                    style="width: 500px"
                  ></el-input>
                </el-form-item>
              </el-col>
              <el-col
                :span="24"
                v-if="getShow(['1', '2', '3', '4'])"
              >
                <el-form-item label="音色：" prop="VoiceType">
                  <el-input
                    size="small"
                    v-model="voiceConfig.VoiceType"
                    style="width: 500px"
                  ></el-input>
                </el-form-item>
              </el-col>
              <el-col
                :span="24"
                v-if="getShow(['2', '3', '4'])"
              >
                <el-form-item label="语速：" prop="Speed">
                  <el-input-number
                    v-model="voiceConfig.Speed"
                    @change="handleChange"
                    :min="0"
                    :max="10"
                    label=""
                    style="width: 500px"
                  ></el-input-number>
                </el-form-item>
              </el-col>
              <el-col
                :span="24"
                v-if="['2', '3', '4'].indexOf(voiceConfig.VendorType) >= 0"
              >
                <el-form-item label="语音大小：" prop="Volume">
                  <el-input-number
                    v-model="voiceConfig.Volume"
                    @change="handleChange"
                    :min="0"
                    :max="10"
                    label=""
                    style="width: 500px"
                  ></el-input-number>
                </el-form-item>
              </el-col>
            </el-row>
          </el-card>
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>试听</span>
            </div>
            <div class="box-content">
              <audio
                ref="player"
                :src="audioUrl"
                controls
                :style="{
                  display: audioUrl == '' ? 'none' : 'none',
                  'margin-bottom': '10px',
                }"
              ></audio>
              <div>
                <div @click="playAudio()" class="btn-play">
                  <svg
                    t="1608797588280"
                    class="icon"
                    viewBox="0 0 1024 1024"
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    p-id="7563"
                    width="40"
                    height="40"
                  >
                    <path
                      d="M512 512m-512 0a512 512 0 1 0 1024 0 512 512 0 1 0-1024 0Z"
                      fill="#1196db"
                      p-id="7564"
                      data-spm-anchor-id="a313x.7781069.0.i13"
                      class=""
                    ></path>
                    <path
                      d="M290.021517 353.103448H143.077517A37.146483 37.146483 0 0 0 105.931034 390.249931v225.862621C105.931034 636.610207 122.562207 653.241379 143.077517 653.241379h146.944c6.62069 0 13.117793 1.765517 18.838069 5.12L544.308966 877.568c24.752552 14.565517 55.966897-3.283862 55.966896-32.008828V160.785655c0-28.724966-31.214345-46.574345-55.966896-32.008827L308.859586 347.983448c-5.720276 3.354483-12.217379 5.12-18.838069 5.12z"
                      fill="#ffffff"
                      p-id="7565"
                      data-spm-anchor-id="a313x.7781069.0.i14"
                      class="selected"
                    ></path>
                    <path
                      d="M733.413517 742.258759a17.637517 17.637517 0 0 1-12.482207-30.13738c110.132966-110.132966 110.132966-289.368276 0-399.501241a17.637517 17.637517 0 1 1 24.964414-24.964414c123.904 123.921655 123.904 325.526069 0 449.430069a17.655172 17.655172 0 0 1-12.482207 5.172966z"
                      fill="#ffffff"
                      p-id="7566"
                      data-spm-anchor-id="a313x.7781069.0.i16"
                      class="selected"
                    ></path>
                    <path
                      d="M670.896552 670.896552a17.637517 17.637517 0 0 1-12.482207-30.13738c75.864276-75.864276 75.864276-199.309241 0-275.173517a17.637517 17.637517 0 1 1 24.964414-24.964414c89.63531 89.63531 89.63531 235.467034 0 325.102345A17.602207 17.602207 0 0 1 670.896552 670.896552z"
                      fill="#ffffff"
                      p-id="7567"
                      data-spm-anchor-id="a313x.7781069.0.i15"
                      class="selected"
                    ></path>
                    <path
                      d="M785.231448 829.793103a17.637517 17.637517 0 0 1-12.482207-30.137379c76.905931-76.888276 119.26069-179.058759 119.26069-287.655724s-42.354759-210.767448-119.26069-287.655724a17.637517 17.637517 0 1 1 24.964414-24.964414c83.579586 83.561931 129.606621 194.577655 129.606621 312.620138s-46.027034 229.058207-129.606621 312.620138a17.602207 17.602207 0 0 1-12.482207 5.172965z"
                      fill="#ffffff"
                      p-id="7568"
                      data-spm-anchor-id="a313x.7781069.0.i17"
                      class="selected"
                    ></path>
                  </svg>
                </div>
              </div>
              <span style="line-height: 50px"
                >（试听内容：请张三到1号机房检查，请李四做准备。）</span
              >
            </div>
          </el-card>
          <div class="save-btn">
            <el-button type="primary" @click="submitForm()">保存</el-button>
          </div>
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
import {
  GetParameter,
  SaveParameter,
  GetImgBase64,
  GetPlayAudio,
} from "@/api/platform_costomer/call.js";
import HeadTabSwitch from "@/components/common/HeadTabSwitch"; // 头部tab
export default {
  data() {
    return {
      dialogFormVisible: false,
      voiceConfig: {
        VendorType: null,
        AppId: "",
        SecretId: "",
        SecretKey: "",
        Region: "ap-shanghai",
        Volume: 0,
        Speed: 0,
        VoiceType: "0",
      },
      cloudVoiceList: [
        { id: "1", type: 1, label: "科大讯飞（离线）" },
        // { id: "2", type: 1, label: "科大讯飞（在线）" },
        { id: "3", type: 1, label: "百度语音" },
        { id: "4", type: 1, label: "腾讯语音" },
      ],
      clientVoiceList: [{ id: "5", type: 2, label: "SpeechSynthesis" }],
      config: {
        platformService: 5,
        SystemInstanceId: 0,
        views: [
          {
            DepartmentId: null,
            Id: "0",
            LastUpdateTime: "",
            OrganizationId: null,
            ParamCode: "voiceSetting",
            ParamDesc: null,
            ParamGroup: "voiceSetting",
            ParamName: "语音设置",
            ParamOptions: "",
            ParamRefModules: 5000,
            ParamValue: "",
            ParamValueType: 2,
            SystemInstanceId: "",
          },
        ],
      },
      audioUrl: "",
    };
  },
  created() {
    this.GetConfig();
    this.checkVoice = this.cloudVoiceList[0];
  },
  methods: {
    async GetConfig(type = "") {
      const that = this;
      const obj = {
        name: "voiceSetting" + type,
      };
      that.voiceConfig={VendorType:type};
      const res = await GetParameter(obj);
      if (res.Code === 0) {
        if (res.Data != null && res.Data.length > 0) {
          that.config.views = res.Data;
          if (that.config.views != null && that.config.views.length > 0) {
            that.voiceConfig = JSON.parse(that.config.views[0].ParamValue);
            if (type !== "") {
              that.voiceConfig.VendorType = type;
            }
          }
        }
      }
    },
    handleChange() {},
    async submitForm() {
      const that = this;
      that.config.views[0].ParamCode="voiceSetting";
      that.config.views[0].ParamValue = JSON.stringify(that.voiceConfig);
      const res = await SaveParameter(that.config);
      if (res.Code === 0) {
        if (res.Data != null && res.Data.lenght > 0) {
          that.config = res.Data[0];
        }
        that.config.views[0].paramCode =
          "voiceSetting" + that.voiceConfig.VendorType;
        SaveParameter(that.config)
        that.config.paramCode=='voiceSetting'
        that.$message.success(res.Msg);
      } else {
        that.$message.error(res.Msg);
      }
    },
    h5judge() {
      var userAgentInfo = navigator.userAgent;
      var Agents = [
        "Android",
        "iPhone",
        "SymbianOS",
        "Windows Phone",
        "iPad",
        "iPod",
      ];
      var flag = false;
      for (var v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) > 0) {
          flag = true;
          break;
        }
      }
      return flag;
    },
    async playAudio() {
      const that = this;
      that.audioUrl = "";
      var ismobile = that.h5judge();
      if (that.voiceConfig.VendorType != 5 || ismobile) {
        const obj = {
          VendorType: that.voiceConfig.VendorType,
          VoiceText: "请张三到1号机房检查，请李四做准备。",
          VoiceConfig: that.voiceConfig,
          IsBase64:true,
        };
        const res = await GetPlayAudio(obj);
        if (res.Code === 0) {
          that.audioUrl = "data:audio/wav;base64," + res.Data;
          that.$refs.player.addEventListener("canplay", function () {
            // 监听audio是否加载完毕，如果加载完毕，则读取audio播放时间
            that.$refs.player.play();
          });
        } else {
          that.$message.error(res.Msg);
        }
      } else {
        var utterThis = new window.SpeechSynthesisUtterance();
        utterThis.text = "请张三到1号机房检查，请李四做准备。";
        window.speechSynthesis.speak(utterThis).speak();
        var main = plus.android.runtimeMainActivity();
        var SynthesizerPlayer = plus.android.importClass(
          "com.iflytek.speech.SynthesizerPlayer"
        );
        var play = SynthesizerPlayer.createSynthesizerPlayer(
          main,
          "appid=5177d8fe"
        );
        play.playText("水果", null, null);
      }
    },
    getShow(arr){
      return arr.indexOf(this.voiceConfig.VendorType) >= 0
    }
  },
};
</script>
<style lang="less" scoped>
.fz20 {
  font-size: 20px;
}
.collect-main {
  .table-content {
    border-bottom: none;
    position: relative;
    .el-icon-s-tools {
      width: 30px;
      height: 22px;
      line-height: 22px;
      text-align: center;
      background: rgb(242, 242, 242, 0.8);
      color: #0a70b0;
      font-size: 20px;
      position: absolute;
      right: 0px;
      top: 9px;
    }
  }
}
.div-base {
  width: 95%;
  margin-left: 2.5%;
  //margin-top: 20px;
}
::v-deep .el-card {
  margin-top: 20px;
}
.save-btn {
  width: 100%;
  height: 50px;
  padding-left: 150px;
}
.check-item {
  width: 20%;
  float: left;
  margin: 20px 0;
}
.divider {
  display: inline-block;
  margin: 10px 0;
}
.el-card__header {
  background-color: #f5f5f5;
}
.box-content {
  width: 100%;
  height: auto;
}
.btn-play {
  width: 50px;
  text-align: center;
  cursor: pointer;
  float: left;
}
.save-btn {
  width: 100%;
  height: 50px;
  margin-top: 20px;
  padding-left: 20px;
}
::v-deep .wrap_content {
  overflow: auto;
}
</style>
