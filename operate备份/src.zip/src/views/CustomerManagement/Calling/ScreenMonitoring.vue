<template>
  <div class="collect-main collect-main_color">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>叫号系统
          <i class="iconfont iconzhankaishouqi"></i> 屏幕监控
        </span>
      </div>
    </div>
    <div
      class="table-content"
      style="height: calc(100vh - 100px); overflow: auto"
    >
      <div class="div-base">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane
            v-for="(tab, listindex) in PacsSystemList"
            :key="listindex"
            :label="tab.label"
            :name="tab.value"
            v-if="isShow"
          >
            <el-card
              class="box-card client"
              v-for="(item, index) in clientList"
              :key="index"
            >
              <div slot="header" class="clearfix client-title">
                <div class="title-div">
                  <div class="no-div">{{ index + 1 }}</div>
                  {{ item.ScreenName }}
                </div>
              </div>
              <div class="client-body text item">
                屏幕编码:{{ item.ScreenCode }}
              </div>
              <!-- <div class="client-body text item">IP:{{ item.IP }}</div> -->
              <div class="client-body text item">
                关联机房:{{ item.ExamRooms }}
              </div>
              <div class="client-body text item">
                状态:<span
                  :style="{
                    color:
                      getState(item.ClientId) == '运行中' ? '#67c23a' : 'red',
                  }"
                  >{{ getState(item.ClientId) }}</span
                >
              </div>
              <div class="client-body text item">
                {{ item.PacsSystem }}
              </div>
              <div class="client-btn">
                <el-button
                  type="text"
                  style="padding: 0; font-size: 20px"
                  v-if="getState(item.ClientId) == '运行中'"
                  @click="closeClient(item)"
                  >断开连接</el-button
                >
              </div>
            </el-card>
          </el-tab-pane>
        </el-tabs>
      </div>
      <div
        style="
          height: 40px;
          font-size: 22px;
          line-height: 40px;
          padding-left: 20px;
          margin-top: 20px;
        "
      >
        推送数据监控
      </div>
      <el-table
        stripe
        height="200"
        :data="sendLogList"
        v-loading="loading"
        border
        style="margin-top: 20px; width: calc(100% - 40px); margin-left: 20px"
        ref="multipleTable"
        :header-cell-style="{ 'background-color': '#cdd8d833' }"
      >
        <!-- <el-table-column show-overflow-tooltip type="selection" width="55" align="center"></el-table-column> -->
        <el-table-column
          show-overflow-tooltip
          prop="time"
          label="时间"
        ></el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="doing"
          label="事件"
        ></el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="content"
          label="扩展消息内容"
        ></el-table-column>
      </el-table>
      <div class="centerPag tc" style="margin-bottom: 0">
        <pagination-tool
          :total="total"
          :page.sync="listQuery.offset"
          :limit.sync="listQuery.limit"
          layout="prev, pager, next"
          @pagination="pagination"
        />
      </div>
    </div>
  </div>
</template>
<script>
import paginationTool from "@/components/common/PaginationTool"; // 分页
import {
  GetClientSendLog,
  GetScreens,
  GetOnlineClient,
  SendCloseMsgToClient,
} from "@/api/platform_costomer/call.js";
export default {
  data() {
    return {
      dialogFormVisible: false,
      activeName: "ALL",
      PacsSystemList: [
        { value: "ALL", label: "全部" },
        { value: "RIS", label: "放射PACS系统" },
        { value: "ECGIS", label: "心电PACS系统" },
        { value: "PIS", label: "病理PACS系统" },
        { value: "UIS", label: "超声PACS系统" },
        { value: "EIS", label: "内镜PACS系统" },
      ],
      clientList: [],
      AllClientList: [],
      tabelData: [
        {
          time: "2020-12-30 09:18:12",
          doing: "CT9机房呼叫成功：“请张三到CT9机房检查，请李四做好准备”",
        },
      ],
      loading: false,
      total: 1,
      listQuery: {
        service_center_id: "",
        doctor_name: "",
        office_id: "",
        service_codes: [],
        limit: 10,
        offset: 1,
      },
      onlineList: [],
      sendLogList: [],
      isShow: false,
      callType: [
        { value: "SendCallToClient", type: "发送叫号信息" },
        { value: "SendVoiceToClient", type: "发送语音消息" },
        { value: "SendGetReportToClient", type: "发送取报告消息" },
        { value: "SendCloseMsgToClient", type: "发送断开客户端指令" },
      ],
    };
  },
  components: {
    paginationTool,
  },
  async created() {
    await this.GetScreens();
    this.GetOnlineClient();
    this.GetSendLog();
    setInterval(() => {
      this.GetOnlineClient();
      this.GetSendLog();
    }, 10000);
  },
  methods: {
    // 分页事件
    pagination(data) {
      this.listQuery.offset = data.page;
      this.listQuery.limit = data.limit;
    },
    async GetScreens() {
      const that = this;
      const obj = {
        groupName: "CallScreens",
      };
      that.AllClientList = [];
      await GetScreens(obj).then((res) => {
        if (res.Code === 0) {
          if (res.Data != null && res.Data.length > 0) {
            res.Data.forEach((element) => {
              let screen = JSON.parse(element.ParamValue);
              screen.Id = element.Id;
              that.AllClientList.push(screen);
              //此处为重点
            });
            that.clientList = that.AllClientList;
            that.$nextTick(() => {
              that.isShow = true;
            });
          }
        }
      });
    },
    GetOnlineClient() {
      const that = this;
      GetOnlineClient().then((res) => {
        that.onlineList = res.Data;
        //that.GetScreens();
      });
    },
    getState(val) {
      let index = this.onlineList.indexOf(val);
      return index > -1 ? "运行中" : "未运行";
    },
    GetSendLog() {
      const that = this;
      that.sendLogList=[];
      GetClientSendLog().then((res) => {
        if (res.Data != null && res.Data.length > 0) {
          res.Data.forEach((e) => {
            let type = that.callType.filter((f) => f.value == e.Content);
            let typelab = "";
            if (type != null && type.length > 0) {
              typelab = type[0].type;
            }
            let msg = {
              time: e.SentTime,
              doing: typelab,
              content: e.Exts.call_info,
            };
            that.sendLogList.push(msg);
          });
        }
      });
    },

    handleClick(val) {
      if (val.name != "ALL") {
        this.clientList = JSON.parse(
          JSON.stringify(
            this.AllClientList.filter((f) => {
              return f.PacsSystem == val.name;
            })
          )
        );
      } else {
        this.clientList = JSON.parse(JSON.stringify(this.AllClientList));
      }
    },
    closeClient(client) {
      let that = this;
      let obj = {
        ClientId: client.ClientId,
      };
      this.$confirm(
        "将强制断开该叫号屏的链接，断开后该叫号屏无法接受消息，是否确认断开?",
        "提示",
        {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        }
      )
        .then(() => {
          SendCloseMsgToClient(obj).then((res) => {
            if (res.Code == 0) {
              let index = that.onlineList.indexOf(client.id);
              if (index > -1) {
                that.onlineList.splice(index, 1);
              }
              that.$message({
                type: "success",
                message: "断开消息发送成功!",
              });
              that.GetSendLog();
            } else {
              that.$message.warning(res.Msg);
            }
          });
        })
        .catch(() => {
          that.$message({
            type: "info",
            message: "已取消",
          });
        });
    },
  },
};
</script>
<style lang="less" scoped>
.fz20 {
  font-size: 20px;
}
.collect-main {
  .table-content {
    border-bottom: none;
    position: relative;
    .el-icon-s-tools {
      width: 30px;
      height: 22px;
      line-height: 22px;
      text-align: center;
      background: rgb(242, 242, 242, 0.8);
      color: #0a70b0;
      font-size: 20px;
      position: absolute;
      right: 0px;
      top: 9px;
    }
  }
}
.div-base {
  width: calc(100% - 40px);
  margin-left: 20px;
  margin-top: 10px;
}
.save-btn {
  width: 100%;
  height: 50px;
  padding-left: 150px;
}
.client {
  width: calc(20% - 10px);
  min-width: 250px;
  text-align: center;
  font-size: 24px;
  float: left;
  margin: 5px 5px;
}
.client-body {
  text-align: left;
  padding: 10px 0px;
  font-size: 20px;
  font-size: 20px;
  margin-left: 10%;
  width: 80%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.client:hover {
  background: #207db7;
  color: white;
}
::v-deep .el-card__header {
  border: none;
  padding: 20px 0 0 0;
}
.client-title {
  width: 100%;
  height: 50px;
}
.client-btn {
  width: 100%;
  line-height: 50px;
  height: 50px;
  background: #f7fcff;
  font-size: 22px;
}
.client-btn > span:hover {
  color: #d56658;
}
::v-deep .el-card__body {
  padding: 0;
}
.no-div {
  background: orange;
  width: 20px;
  height: 20px;
  border-radius: 10px;
  font-size: 15px;
  color: white;
  float: left;
  text-align: center;
  margin: 0 auto;
  margin-top: 5px;
  margin-left: 10%;
}
.title-div {
  margin-top: 20px;
  width: calc(100% - 20px);
  text-align: left;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
