<template>
  <div class="collect-main collect-main_color">
    <div ref="tabHeight" class="bread">
      <head-tab-switch navTitle="基础设置" />
    </div>
    <div class="table-content"  style="height: calc(100vh - 100px)"  >
      <div class="div-base">
        <el-form :rules="rules" :model="form" label-width="150px">
          <el-form-item label="屏幕标题：" prop="title">
            <el-input
              size="small"
              placeholder="如：科室名称"
              v-model="form.title"
              style="width: 300px"
            ></el-input>
          </el-form-item>
          <el-form-item label="叫号屏logo：" prop="logoUrl">
            <el-upload
              class="upload-demo"
              drag
              :action="uploadUrl"
              ref="uploadLogo"
              show-file-list
              :on-success="uploadSuccessLogo"
              :on-change="(file, fileList) => onChange(file, fileList, 'logo')"
              limit="1"
              style="width: 400px; float: left"
            >
              <i class="el-icon-upload"></i>
              <div class="el-upload__text">
                将文件拖到此处，或<em>点击上传</em>
              </div>
              <div class="el-upload__tip" slot="tip">
                只能上传jpg/jpeg/png文件，且不超过3M
              </div>
            </el-upload>
            预览：
            <img
              v-if="form.logoUrl != ''"
              :src="logoUrl"
              width="100"
              height="100"
              style="margin-top: 40px"
            />
          </el-form-item>
          <el-form-item label="电离辐射图标：" prop="iconUrl">
            <el-upload
              class="upload-demo"
              drag
              :action="uploadUrl"
              ref="uploadIcon"
              show-file-list
              :on-success="uploadSuccessIcon"
              :on-change="(file, fileList) => onChange(file, fileList, 'icon')"
              limit="1"
              style="width: 400px; float: left"
            >
              <i class="el-icon-upload"></i>
              <div class="el-upload__text">
                将文件拖到此处，或<em>点击上传</em>
              </div>
              <div class="el-upload__tip" slot="tip">
                只能上传jpg/jpeg/png文件，且不超过3M
              </div>
            </el-upload>
            预览：
            <img
              v-if="form.iconUrl != ''"
              :src="iconUrl"
              width="100"
              height="100"
              style="margin-top: 40px"
            />
          </el-form-item>
          <el-form-item label="启用叫号屏显示时间：" prop="is_show_time">
            <el-switch
              v-model="form.is_show_time"
              active-color="#13ce66"
              inactive-color="#C4C6CF"
              active-value="1"
              inactive-value="0"
            >
            </el-switch>
          </el-form-item>
          <div class="save-btn">
            <el-button type="primary" @click="submitForm()">保存</el-button>
          </div>
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
import HeadTabSwitch from '@/components/common/HeadTabSwitch' // 头部tab
export default {
  data () {
    return {
      dialogFormVisible: false,
      form: {
        id: '',
        title: '',
        logo: '',
        ionizing_logo: '',
        is_show_time: '0',
        organization_id: '0',
        department_id: '0',
        system_instance_id: '0'
      },
      logoUrl: '',
      iconUrl: '',
      image: null,
      uploadUrl: configUrl.callapiurl + "/api/Upload/UploadLogoAndIcon",
      rules: {},
      config: {
        platformService: 5,
        systemInstanceId: 0,
        views: [
          {
            DepartmentId: null,
            Id: "0",
            LastUpdateTime: "",
            OrganizationId: null,
            ParamCode: "",
            ParamDesc: null,
            ParamGroup: "baseSetting",
            ParamName: "基础设置",
            ParamOptions: "",
            ParamRefModules: 5000,
            ParamValue: "",
            ParamValueType: 2,
            SystemInstanceId: "1340968858038571000",
          },
        ],
      },
       
    };
  },
  components: {
    HeadTabSwitch,
  },
  created () {
    this.GetConfig()
  },
  methods: {
    GetConfig () {
      const that = this
      // let obj = {
      //   name: "baseSetting",
      // };
      that.$callApi.callApi.GetScreenLayoutList().then((res) => {
        if (res.code === 0) {
          if (res.data != null && res.data.length > 0) {
            that.form = res.data[0]
            that.logoUrl = 'data:image/png;base64,' + that.form.logo
            that.iconUrl = 'data:image/png;base64,' + that.form.ionizing_logo
            // that.getImg("logo")
            // that.getImg("icon")
            // if (that.config.views != null && that.config.views.length > 0) {
            //   that.form = JSON.parse(that.config.views[0].ParamValue);
            //   that.form.id = that.config.views[0].Id;
            //   that.getImg("logo");
            //   that.getImg("icon");
            // }
          }
        }
      })
    },

    uploadSuccessLogo(response, file, fileList) {
      if (response.code == 0) {
        this.form.logoUrl = response.data;
      }
    },
    uploadSuccessIcon(response, file, fileList) {
      if (response.code == 0) {
        this.form.iconUrl = response.data;
      }
    },
    submitForm() {
      let that = this;
      that.config.views[0].ParamValue = JSON.stringify(that.form);
      that.$callApi.callApi.SaveParameter(that.config).then((res) => {
        if (res.code == 0) {
          if (res.data != null && res.data.lenght > 0) {
            that.config = res.data[0];
          }
        }
      });
    },
    onChange(file, fileList, type) {
      var _this = this;
      var event = event || window.event;
      var file = event.target.files[0];
      var reader = new FileReader();
      //转base64
      reader.onload = function (e) {
        if (type == "logo") {
          _this.logoUrl = e.target.result; //将图片路径赋值给src
        } else {
          _this.iconUrl = e.target.result; //将图片路径赋值给src
        }
      };
      reader.readAsDataURL(file);
    },
    getImg(type) {
      let that = this;
      let url = "";
      let src = "";
      if (type == "logo") {
        url = this.form.logoUrl;
      } else {
        url = this.form.iconUrl;
      }
      let imgarr = ["jpeg", "jpg", "png"];
      imgarr.forEach((e) => {
        if (url.indexOf(e) >= 0) {
          src = "data:image/" + e + ";base64,";
        }
      });
      if (this.form.id != "") {
        let obj = { path: url };
        that.$callApi.callApi.GetImgBase64(obj).then((res) => {
          if (res.code == 0) {
            if (res.data != null) {
              src += res.data;
              if (type == "logo") {
                that.logoUrl = src;
              } else {
                that.iconUrl = src;
              }
            }
          }
        });
      }
    },
  },
};
</script>
<style lang="less" scoped>
.fz20 {
  font-size: 20px;
}
.collect-main {
  // margin:0 20px;
  .bread {
    padding-left: 15px;
  }
  .table-content {
    border: 1px solid #eeeeee;
    border-bottom: none;
    position: relative;
    .el-icon-s-tools {
      width: 30px;
      height: 22px;
      line-height: 22px;
      text-align: center;
      background: rgb(242, 242, 242, 0.8);
      color: #0a70b0;
      font-size: 20px;
      position: absolute;
      right: 0px;
      top: 9px;
    }
  }
}
.div-base {
  width: 80%;
  margin-left: 10%;
  margin-top: 50px;
}
.save-btn {
  width: 100%;
  height: 50px;
  padding-left: 150px;
}
</style>
