<template>
  <div class="collect-main collect-main_color">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>叫号系统
          <i class="iconfont iconzhankaishouqi"></i> 基础设置
        </span>
      </div>
    </div>
    <div class="table-content" style="height: calc(100vh - 147px)">
      <div class="div-base">
        <el-form :rules="rules" :model="form" label-width="170px">
          <el-form-item label="屏幕标题：" prop="title">
            <el-input
              size="small"
              placeholder="如：科室名称"
              v-model="form.title"
              style="width: 300px"
            ></el-input>
          </el-form-item>
          <el-form-item label="叫号屏logo：" prop="logoUrl">
            <el-upload
              class="upload-demo"
              drag
              ref="uploadLogo"
              :headers="myHeaders"
              show-file-list
              action="#"
              :on-change="(file, fileList) => onChange(file, fileList, 'logo')"
              :limit="1"
              style="width: 400px; float: left"
            >
              <i class="el-icon-upload"></i>
              <div class="el-upload__text">
                将文件拖到此处，或<em>点击上传</em>
              </div>
              <div class="el-upload__tip" slot="tip">
                只能上传jpg/jpeg/png文件，且不超过48kb
              </div>
            </el-upload>
            预览：
            <img
              v-if="form.logoUrl != ''"
              :src="logoUrl"
              height="100"
              style="margin-top: 40px"
            />
          </el-form-item>
          <el-form-item label="电离辐射图标：" prop="iconUrl">
            <el-upload
              class="upload-demo"
              drag
              ref="uploadIcon"
              :headers="myHeaders"
              show-file-list
              action="#"
              :on-change="(file, fileList) => onChange(file, fileList, 'ionizing_logo')"
              :limit="1"
              style="width: 400px; float: left"
            >
              <i class="el-icon-upload"></i>
              <div class="el-upload__text">
                将文件拖到此处，或<em>点击上传</em>
              </div>
              <div class="el-upload__tip" slot="tip">
                只能上传jpg/jpeg/png文件，且不超过48kb
              </div>
            </el-upload>
            预览：
            <img
              v-if="form.iconUrl != ''"
              :src="iconUrl"
              height="100"
              style="margin-top: 40px"
            />
          </el-form-item>
          <el-form-item label="启用叫号屏显示时间：" prop="is_show_time">
            <el-switch
              v-model="form.is_show_time"
              active-color="#13ce66"
              inactive-color="#C4C6CF"
              :active-value=1
              :inactive-value=0
            >
            </el-switch>
          </el-form-item>
          <div class="save-btn">
            <el-button type="primary" @click="submitForm()">保存</el-button>
          </div>
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
import {
  GetScreenLayoutList,
  PostScreenLayout,
  PutScreenLayout
} from '@/api/platform_costomer/call.js';
import Mgr from '@/utils/SecurityService';
export default {
  data () {
    return {
      dialogFormVisible: false,
      form: {
        id: 0,
        title: '',
        logo: '',
        ionizing_logo: '',
        is_show_time: 0,
        organization_id: '',
        department_id: '',
        system_instance_id: ''
      },
      logoUrl: '',
      iconUrl: '',
      fileLogo: '',
      fileIonizingLogo: '',
      image: null,
      // uploadUrl: configUrl.callapiurl + "/callapi/Upload/UploadLogoAndIcon",
      rules: {},
      // config: {
      //   platformService: 5,
      //   SystemInstanceId: 0,
      //   views: [
      //     {
      //       DepartmentId: null,
      //       Id: "0",
      //       LastUpdateTime: "",
      //       OrganizationId: null,
      //       ParamCode: "baseSetting",
      //       ParamDesc: null,
      //       ParamGroup: "baseSetting",
      //       ParamName: "基础设置",
      //       ParamOptions: "",
      //       ParamRefModules: 5000,
      //       ParamValue: "",
      //       ParamValueType: 2,
      //       SystemInstanceId: "",
      //     },
      //   ],
      // },
      myHeaders: {},
    };
  },
  async created() {
    const manager = new Mgr();
    const user = await manager.getRole();
    this.myHeaders = {
      Authorization: user.token_type + " " + user.access_token,
    };
    this.GetConfig();
  },
  methods: {
    async GetConfig () {
      const that = this
      // const obj = { name: "baseSetting" };
      const res = await GetScreenLayoutList()
      if (res.code === 0) {
        if (res.data != null && res.data.length > 0) {
          that.form = res.data[0]
          that.logoUrl = 'data:image/png;base64,' + that.form.logo
          that.iconUrl = 'data:image/png;base64,' + that.form.ionizing_logo
          if (that.form.organization_id === null) {
            that.form.organization_id = ''
          }
          if (that.form.department_id === null) {
            that.form.department_id = ''
          }
          if (that.form.system_instance_id === null) {
            that.form.system_instance_id = ''
          }
          // that.config.views = res.Data;
          // if (that.config.views != null && that.config.views.length > 0) {
          //   that.form = JSON.parse(that.config.views[0].ParamValue);
          //   that.form.id = that.config.views[0].Id;
          //   that.getImg("logo");
          //   that.getImg("icon");
          // }
        }
      }
    },

    // // 叫号屏上传之前的钩子函数
    // beforeLogoUpload (file) {
    //   console.log(file)
    //   // let fd = new FormData();
    //   // fd.append('file',file.raw);//传文件
    //   this.fileLogo = file.raw
    // },

    // // 电离辐射上传之前的钩子函数
    // beforeIonizingLogoUpload (file) {
    //   console.log(file)
    //   // let fd = new FormData();
    //   // fd.append('file',file.raw);//传文件
    //   this.fileIonizingLogo = file.raw
    // },

    // uploadSuccessLogo(response, file, fileList) {
    //   if (response.Code == 0) {
    //     this.form.logoUrl = response.Data;
    //   }
    // },
    // uploadSuccessIcon(response, file, fileList) {
    //   if (response.Code === 0) {
    //     this.form.iconUrl = response.Data;
    //   }
    // },

    async submitForm () {
      const that = this
      // that.config.views[0].ParamValue = JSON.stringify(that.form);
      // const res = await SaveParameter(that.config);
      // 图片大小判断
      if (that.fileLogo !== '' && that.fileLogo.size > 49150) {
        that.$message.warning('叫号屏logo过大，请压缩后重新上传！') // 65535*0.75 = 48kb
        return
      }

      if (that.fileIonizingLogo !== '' && that.fileIonizingLogo.size > 49150) {
        that.$message.warning('电离辐射图标过大，请压缩后重新上传！')
        return
      }

      const formData = new FormData()
      if (that.fileLogo !== '') {
        formData.append('logo', that.fileLogo)
      } else {
        formData.append('logo', that.form.logo)
      }

      if (that.fileIonizingLogo !== '') {
        formData.append('IonizingLogo', that.fileIonizingLogo)
      } else {
        formData.append('IonizingLogo', that.form.ionizing_logo)
      }
      formData.append('Id', that.form.id)
      formData.append('Title', that.form.title)
      formData.append('IsShowTime', that.form.is_show_time) // todo 需要查找为什么下划线转驼峰不起左右
      formData.append('OrganizationId', that.form.organization_id)
      formData.append('DepartmentId', that.form.department_id)
      formData.append('SystemInstanceId', that.form.system_instance_id)

      let res = null
      if (that.form.id !== '' && that.form.id !== 0) { // 更新
        res = await PutScreenLayout(that.form.id, formData)
      } else { // 新增
        res = await PostScreenLayout(formData)
      }
      if (res.code === 0) {
        that.$message({
          type: 'success',
          message: '更新成功!'
        })
      } else {
        that.$message.warning(res.msg)
      }
    },
    onChange (file, fileList, type) {
      var _this = this
      if (type === 'logo') {
        _this.fileLogo = file.raw
      } else {
        _this.fileIonizingLogo = file.raw
      }

      // var event = event || window.event;
      // var file = event.target.files[0];
      var reader = new FileReader()
      // 转base64
      reader.onload = function (e) {
        if (type === 'logo') {
          _this.logoUrl = e.target.result // 将图片路径赋值给src
        } else {
          _this.iconUrl = e.target.result // 将图片路径赋值给src
        }
      }
      reader.readAsDataURL(file.raw)
    },

    // async getImg(type) {
    //   const that = this;
    //   let url = "";
    //   let src = "";
    //   if (type === "logo") {
    //     url = this.form.logoUrl;
    //   } else {
    //     url = this.form.iconUrl;
    //   }
    //   const imgarr = ["jpeg", "jpg", "png"];
    //   imgarr.forEach((e) => {
    //     if (url.indexOf(e) >= 0) {
    //       src = "data:image/" + e + ";base64,";
    //     }
    //   });
    //   if (this.form.id !== "") {
    //     const obj = { path: url };
    //     const res = await GetImgBase64(obj);
    //     if (res.Code === 0) {
    //       if (res.Data != null) {
    //         src += res.Data;
    //         if (type === "logo") {
    //           that.logoUrl = src;
    //         } else {
    //           that.iconUrl = src;
    //         }
    //       }
    //     }
    //   }
    // },
  },
};
</script>
<style lang='less' scoped>
.fz20 {
  font-size: 20px;
}
.collect-main {
  .bread {
    padding-left: 15px;
  }
  .table-content {
    border-bottom: none;
    position: relative;
    .el-icon-s-tools {
      width: 30px;
      height: 22px;
      line-height: 22px;
      text-align: center;
      background: rgb(242, 242, 242, 0.8);
      color: #0a70b0;
      font-size: 20px;
      position: absolute;
      right: 0px;
      top: 9px;
    }
  }
}
.div-base {
  width: 80%;
  margin-left: 10%;
  margin-top: 50px;
}
.save-btn {
  width: 100%;
  height: 50px;
  padding-left: 150px;
}
</style>
