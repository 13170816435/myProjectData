<template>
  <div style="font-size: 14px" class="collect-main collect-main_color">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>叫号系统
          <i class="iconfont iconzhankaishouqi"></i> 叫号屏管理
        </span>
      </div>
    </div>
    <div class="list-content" ref="refList">
      <div class="operate-top">
        <div style="display: flex flex: 4"></div>
        <el-button
          size="small"
          class="ml20 match-btn"
          style="margin-right: 15px"
          @click="newOne()"
          >新增屏幕</el-button
        >
      </div>
      <div
        class="table-content"
        style="
          height: calc(100vh - 135px);
          overflow: auto;
          padding: 0 15px;
          border: none !important;
        "
      >
        <el-table
          stripe
          height="calc(100vh - 200px)"
          :data="tabelData"
          v-loading="loading"
          border
          ref="multipleTable"
          style="height: calc(100vh - 200px) !important"
          :header-cell-style="{ 'background-color': '#cdd8d833' }"
        >
          <el-table-column
            show-overflow-tooltip
            prop="screen_code"
            label="屏幕编号"
            width="100px"
          ></el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="screen_name"
            label="屏幕名称"
          ></el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="screen_type"
            label="屏幕类型"
            width="100px"
          >
            <template slot-scope="scope">
              {{
                scope.row.screen_type === 1
                  ? '叫号屏'
                  : scope.row.screen_type === 10
                  ? '患者确认屏'
                  : '取报告屏'
              }}
            </template>
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="screen_type"
            label="所属机构"
            width="100px"
          >
            <template slot-scope="scope">
              {{ getInstitutionName(scope.row.organization_id) }}
            </template>
          </el-table-column>
          <el-table-column show-overflow-tooltip label="操作" width="200px">
            <template slot-scope="scope">
              <el-button
                type="text"
                style="padding: 0"
                @click="QueueOpen(scope.row)"
                >等待队列</el-button
              >
              <el-button
                type="text"
                style="padding: 0"
                @click="handleEdit(scope.row)"
                >编辑</el-button
              >

              <el-divider direction="vertical"></el-divider>
              <el-button
                type="text"
                style="padding: 0"
                class="red"
                @click="deleteSrceen(scope.row)"
                >删除</el-button
              >
            </template>
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="PacsSystem"
            :formatter="getSystemFormat"
            label="PACS系统"
          ></el-table-column>

          <el-table-column
            show-overflow-tooltip
            prop="exam_rooms"
            label="关联机房"
          ></el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="need_voice"
            label="启用语音播报"
            ><template slot-scope="scope">{{
              scope.row.need_voice == '1' ? '是' : '否'
            }}</template></el-table-column
          >
          <el-table-column
            show-overflow-tooltip
            prop="voice_generation_mode"
            label="语音合成"
            ><template slot-scope="scope">{{
              scope.row.voice_generation_mode == '1' ? '是' : '否'
            }}</template></el-table-column
          >
          <el-table-column
            show-overflow-tooltip
            prop="preset_style"
            label="预设样式"
            :formatter="getStyleFormat"
          ></el-table-column>
        </el-table>
        <div class="centerPag tc" style="margin-bottom: 0">
          <pagination-tool
            :total="total"
            :page.sync="listQuery.offset"
            :limit.sync="listQuery.limit"
            layout="prev, pager, next"
            @pagination="pagination"
          />
        </div>
      </div>
    </div>
    <el-dialog
      v-dialogDrag
      title="叫号屏设置"
      :visible.sync="editVisible"
      top="25px"
      width="840px"
      class="abow_dialog"
      :close-on-click-modal="false"
      :show-close="true"
      append-to-body
      center
    >
      <div
        style="
          width: 100%;
          margin-top: 20px;
          max-height: 700px;
          overflow-y: auto;
        "
      >
        <el-form
          :model="form"
          label-width="160px"
          ref="form"
          :rules="rules"
          style="width: 90%; margin-left: 5%; margin-top: 20px"
        >
          <el-row :span="24">
            <el-col :span="24">
              <el-form-item label="屏幕类型：" prop="screen_type" class="mt15">
                <el-select
                  v-model="form.screen_type"
                  style="width: 300px"
                  size="small"
                  @change="changeScreenType"
                >
                  <el-option
                    v-for="(item, index) in ScreenTypeList"
                    :key="index"
                    :value="item.value"
                    :label="item.label"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="24">
              <el-form-item label="PACS系统：" prop="pacs_system" class="mt15">
                <el-select
                  v-model="form.pacs_system"
                  style="width: 300px"
                  size="small"
                >
                  <el-option
                    v-for="(item, index) in PacsSystemList"
                    :key="index"
                    :value="item.id"
                    :label="item.name"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item
                label="所属机构："
                prop="organization_id"
                class="mt15"
              >
                <el-select
                  v-model="form.organization_id"
                  style="width: 300px"
                  size="small"
                >
                  <el-option
                    v-for="(item, index) in InstitutionList"
                    :key="index"
                    :value="item.id"
                    :label="item.name"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col> -->
            <el-col :span="24">
              <el-form-item
                label="基础设置："
                prop="screen_layout_id"
                class="mt15"
              >
                <el-select
                  v-model="form.screen_layout_id"
                  style="width: 300px"
                  size="small"
                >
                  <el-option
                    v-for="(item, index) in CallScreenLayoutList"
                    :key="index"
                    :value="item.id"
                    :label="item.title"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="屏幕编号：" prop="screen_code" class="mt15">
                <el-input
                  :disabled="isEdit"
                  v-model="form.screen_code"
                  style="width: 300px"
                  size="small"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="屏幕名称：" prop="screen_name" class="mt15">
                <el-input
                  size="small"
                  v-model="form.screen_name"
                  style="width: 300px"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="屏幕标题：" prop="screen_title" class="mt15">
                <el-input
                  v-model="form.screen_title"
                  style="width: 300px"
                  size="small"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col
              :span="24"
              v-if="form.screen_type === 1 || form.screen_type === 10"
            >
              <el-form-item label="关联机房：" prop="exam_rooms" class="mt15">
                <el-input
                  v-model="form.exam_rooms"
                  style="width: 300px"
                  size="small"
                ></el-input>
              </el-form-item>
              <span v-if="isEdit" style="margin-left: 160px; color: #e6a23c">
                注意：修改关联机房后请重新配置等待队列
              </span>
            </el-col>

            <!-- <el-col :span="24">
              <el-form-item label="等待队列：" prop="ExamRooms">
                <el-input
                  v-model="form.ExamRooms"
                  style="width: 300px"
                ></el-input>
              </el-form-item>
            </el-col> -->

            <el-col :span="24">
              <el-form-item label="呼叫内容：" prop="call_content" class="mt15">
                <el-input
                  type="textarea"
                  rows="6"
                  v-model="form.call_content"
                  style="width: 300px"
                  size="small"
                ></el-input>
                <div
                  style="
                    width: 200px;
                    float: right;
                    margin-right: 70px;
                    line-height: 25px;
                  "
                >
                  <span v-if="form.screen_type == 1">
                    可定制替换内容：{患者姓名}、{就诊类别}、
                    {机房名称}、{排队号}、{检查类型}、{等待 患者}等
                  </span>
                  <span v-else>
                    默认呼叫内容为：请{患者姓名}到登记台领取报告</span
                  >
                  <br />
                  <a
                    href="javasricpt:void(0)"
                    @click="openContentConfig()"
                    style="line-height: 40px; color: blue"
                  >
                    内容定制</a
                  >
                </div>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="温馨提示：" prop="reminder" class="mt15">
                <el-input
                  type="textarea"
                  rows="5"
                  v-model="form.reminder"
                  size="small"
                  style="width: 300px"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24" v-if="form.screen_type == 1">
              <el-form-item label="预设样式：" prop="preset_style" class="mt15">
                <el-select
                  v-model="form.preset_style"
                  style="width: 300px"
                  size="small"
                >
                  <el-option
                    v-for="(item, index) in PresetStyleList"
                    :key="index"
                    :value="item.value"
                    :label="item.label"
                  ></el-option>
                </el-select>
                <a
                  href="javasricpt:void(0)"
                  @click="styleVisible = true"
                  style="line-height: 40px; color: blue; margin-left: 10px"
                  >预览</a
                >
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item
                label="替换敏感字："
                prop="must_anonymity"
                class="mt15"
              >
                <el-switch
                  v-model="form.must_anonymity"
                  active-color="#13ce66"
                  inactive-color="#C4C6CF"
                  :active-value="1"
                  :inactive-value="0"
                >
                </el-switch>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item
                label="敏感字替换字符："
                prop="replace_char"
                class="mt15"
              >
                <el-select v-model="form.replace_char" style="width: 300px">
                  <el-option
                    v-for="(item, index) in ReplaceKeyList"
                    :key="index"
                    :value="item.value"
                    :label="item.label"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item
                label="生成语音："
                prop="voice_generation_mode"
                class="mt15"
              >
                <el-switch
                  v-model="form.voice_generation_mode"
                  active-color="#13ce66"
                  inactive-color="#C4C6CF"
                  :active-value="1"
                  :inactive-value="0"
                >
                </el-switch>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item
                label="启用语音播放："
                prop="need_voice"
                class="mt15"
              >
                <el-switch
                  v-model="form.need_voice"
                  active-color="#13ce66"
                  inactive-color="#C4C6CF"
                  :active-value="1"
                  :inactive-value="0"
                >
                </el-switch>
              </el-form-item>
            </el-col>
            <el-col :span="24" v-if="form.screen_type == 1">
              <el-form-item
                label="显示电离辐射标志："
                prop="show_ionizing_logo"
                class="mt15"
              >
                <el-switch
                  v-model="form.show_ionizing_logo"
                  active-color="#13ce66"
                  inactive-color="#C4C6CF"
                  :active-value="1"
                  :inactive-value="0"
                >
                </el-switch>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div class="dialog_footer mt15" style="text-align: right">
        <el-button size="small" @click="editVisible = false">取消</el-button>
        <el-button type="primary" size="small" @click="submitForm()"
          >确定</el-button
        >
      </div>
    </el-dialog>
    <el-dialog
      v-dialogDrag
      title="呼叫内容定制"
      :visible.sync="CallContentConfigVisible"
      top="25px"
      width="800px"
      class="abow_dialog"
      :close-on-click-modal="false"
      :show-close="true"
      append-to-body
      center
    >
      <div style="width: 100%; height: 500px; margin-top: 20px">
        <el-input
          type="textarea"
          ref="contentInput"
          id="contentInput"
          rows="12"
          v-model="call_content"
          style="width: 90%; margin-left: 5%; margin-top: 20px"
        ></el-input>
        <div style="width: 90%; margin-left: 5%; padding: 10px 0">
          <template v-for="(item, index) in ContentList">
            <el-button
              :key="index"
              :label="item.value"
              v-if="item.type.indexOf(form.screen_type) >= 0"
              style="margin: 10px 0 0 0"
              @click="change(item.value)"
              >{{ item.label }}</el-button
            >
          </template>
        </div>
        <!-- </el-radio-group> -->
        <div style="width: 90%; margin-left: 5%; color: orange">
          <span v-if="form.screen_type == 1"
            ><em class="el-icon-warning"></em
            >默认呼叫内容为：请{患者姓名}到{检查机房}检查，请{等待患者1}做准备</span
          >
          <span v-else
            ><em class="el-icon-warning"></em
            >默认呼叫内容为：请{患者姓名}到登记台领取报告</span
          >
        </div>
      </div>
      <div class="dialog_footer mt15" style="text-align: right">
        <el-button size="small" @click="CallContentConfigVisible = false"
          >取消</el-button
        >
        <el-button type="primary" size="small" @click="sureChange()"
          >确定</el-button
        >
      </div>
    </el-dialog>
    <el-dialog
      v-dialogDrag
      title="样式预览"
      :visible.sync="styleVisible"
      top="25px"
      width="800px"
      class="abow_dialog"
      :close-on-click-modal="false"
      :show-close="true"
      append-to-body
      center
    >
      <div style="width: 100%; height: 60px">
        <div class="img-som-div" style="height: 550px">
          <div class="slt-div">缩略图</div>
          <template>
            <div v-for="(img, index) in imgList" :key="index" class="img-item">
              <el-image
                :class="
                  img.name == selectImg.name ? 'img-som select-som' : 'img-som'
                "
                :src="img.url"
                @click="changeImg(img)"
              ></el-image>
              <div class="title-som">{{ img.name }}</div>
            </div>
          </template>
        </div>
        <div class="img-big-div">
          <el-image class="img-big" :src="selectImg.url"> </el-image>
        </div>
      </div>
      <div
        class="dialog_footer mt15"
        style="text-align: right; margin-top: 520px"
      >
        <el-button size="small" @click="styleVisible = false">取消</el-button>
        <el-button type="primary" size="small" @click="sureStyle()"
          >确定</el-button
        >
      </div>
    </el-dialog>

    <el-dialog
      v-dialogDrag
      title="合并等待队列"
      :visible.sync="QueueVisible"
      top="25px"
      width="800px"
      class="abow_dialog"
      :close-on-click-modal="false"
      :show-close="true"
      append-to-body
      center
    >
      <div
        style="
          width: 100%;
          height: 50px;
          text-align: right;
          padding-right: 20px;
          padding-top: 10px;
        "
      >
        <el-button type="primary" size="small" @click="newQueue()"
          >新增合并等待队列</el-button
        >
      </div>
      <el-table
        stripe
        height="200"
        :data="QueueList"
        border
        :header-cell-style="{ 'background-color': '#cdd8d833' }"
        align="center"
      >
        <el-table-column
          show-overflow-tooltip
          prop="Name"
          label="等待队列"
          width="180"
          align="center"
        >
          <template slot-scope="scope">
            <el-input v-model="scope.row.queue_name" disabled />
          </template>
        </el-table-column>
        <el-table-column show-overflow-tooltip label="检查机房">
          <template slot-scope="scope">
            <el-select
              v-model="scope.row.items"
              placeholder=""
              multiple
              style="width: 100%"
              :disabled="scope.row.items.lenght > 0"
            >
              <el-option
                v-for="(item, index) in QueueRoomList"
                :key="index"
                :value="item"
                :label="item"
              ></el-option>
            </el-select>
          </template>
        </el-table-column>

        <el-table-column
          show-overflow-tooltip
          label="操作"
          align="center"
          width="120"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              style="padding: 0"
              class="red"
              @click="queueDelete(scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
      <!-- <div style="width:100%;" v-for="queue in QueueList">
         <span>队列名称</span>
       <el-input v-model="queue.Name" />
       <span>关联机房</span>
       <el-select v-model="queue.Rooms">
         <option v-for="item in QueueRoomList" :value="item.ExamRoom"></option>
       </el-select>
     </div> -->
      <div class="dialog_footer mt15" style="text-align: right">
        <el-button size="small" @click="QueueVisible = false">取消</el-button>
        <el-button type="primary" size="small" @click="SaveQueueDefine()"
          >确定</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>
<script>
import paginationTool from '@/components/common/PaginationTool' // 分页
import {
  GetScreenLayoutList,
  GetScreens,
  DeleteConfig,
  PostScreenConfig,
  PutScreenConfig,
  GetScreenQueueDefineList,
  PostScreenQueueDefine,
} from '@/api/platform_costomer/call.js'
import {
  getInstitutionListLite,
  getPascList,
} from '@/api/platform_costomer/institution.js'
import { getObservationRoom } from '@/api/platform_departMent/systemSet'
import { fetchSnowId } from '@/api/commonHttp.js'
import Mgr from '@/utils/SecurityService'
export default {
  data() {
    return {
      editVisible: false,
      loading: false,
      tabelData: [],
      listQuery: {
        service_center_id: '',
        doctor_name: '',
        office_id: '',
        service_codes: [],
        limit: 1,
        offset: 1,
      },
      form: {
        id: 0,
        screen_type: 1,
        pacs_system: '',
        screen_code: '',
        screen_name: '',
        screen_title: '',
        exam_rooms: '',
        call_content: '',
        voice_generation_mode: 0,
        need_voice: 0,
        reminder: '',
        preset_style: '',
        show_ionizing_logo: 0,
        Queues: [],
        organization_id: '',
        must_anonymity: 0,
        screen_layout_id: 0,
      },
      ScreenTypeList: [
        { value: 1, label: '叫号屏' },
        { value: 2, label: '取报告屏' },
        { value: 10, label: '患者确认屏' },
      ],
      PacsSystemList: [
        { value: 'RIS', label: '放射PACS系统' },
        { value: 'ECGIS', label: '心电PACS系统' },
        { value: 'PIS', label: '病理PACS系统' },
        { value: 'UIS', label: '超声PACS系统' },
        { value: 'EIS', label: '内镜PACS系统' },
      ],
      PresetStyleList: [
        { value: 1, label: '预设样式1(单机房)' },
        { value: 2, label: '预设样式2' },
        { value: 3, label: '预设样式3' },
        { value: 4, label: '预设样式4' },
        { value: 5, label: '预设样式5' },
        { value: 6, label: '预设样式6' },
      ],
      ReplaceKeyList: [
        { value: '*', label: '*' },
        { value: '◎', label: '◎' },
        { value: '○', label: '○' },
        { value: '☆', label: '☆' },
        { value: '★', label: '★' },
      ],
      ContentList: [
        { value: '{QueueNo}', type: ['1', '2'], label: '排队号' },
        { value: '{PatientClass}', type: ['1'], label: '患者类别' },
        { value: '{PatientName}', type: ['1', '2'], label: '患者姓名' },
        { value: '{ExamineRoom}', type: ['1'], label: '检查机房' },
        { value: '{ExamineItem}', type: ['1'], label: '检查项目' },
        { value: '{WaitExamine}', type: ['1'], label: '等待患者1' },
        { value: '{WaitExamine2}', type: ['1'], label: '等待患者2' },
        { value: '{WaitExamine3}', type: ['1'], label: '等待患者3' },
      ],
      CallContentConfigVisible: false,
      radio: '',
      startPos: undefined,
      endPos: undefined,
      total: 0,
      // config: {
      //   platformService: 5,
      //   systemInstanceId: 0,
      //   views: [
      //     {
      //       DepartmentId: null,
      //       Id: "0",
      //       LastUpdateTime: "",
      //       organization_id: null,
      //       ParamCode: "",
      //       ParamDesc: null,
      //       ParamGroup: "CallScreens",
      //       ParamName: "叫号屏设置",
      //       ParamOptions: "",
      //       ParamRefModules: 5000,
      //       ParamValue: "",
      //       ParamValueType: 2,
      //       SystemInstanceId: "1340968858038571000",
      //     },
      //   ],
      // },
      call_content: '',
      styleVisible: false,
      imgList: [
        {
          code: '1',
          name: '预设样式1(单机房)',
          url: require('../../../assets/images/call/style1.png'),
        },
        {
          code: '2',
          name: '预设样式2',
          url: require('../../../assets/images/call/style2.png'),
        },
        {
          code: '3',
          name: '预设样式3',
          url: require('../../../assets/images/call/style3.png'),
        },
        {
          code: '4',
          name: '预设样式4',
          url: require('../../../assets/images/call/style4.png'),
        },
        {
          code: '5',
          name: '预设样式5',
          url: require('../../../assets/images/call/style5.png'),
        },
        {
          code: '6',
          name: '预设样式6',
          url: require('../../../assets/images/call/style6.png'),
        },
      ],
      selectImg: undefined,
      rules: {
        screen_type: [
          { required: true, message: '请选择屏幕类型', trigger: 'change' },
        ],
        screen_layout_id: [
          { required: true, message: '请选择基础设置', trigger: 'change' },
        ],
        PacsSystem: [
          { required: true, message: '请选择系统', trigger: 'change' },
        ],
        // organization_id: [
        //   { required: true, message: '请选择机构', trigger: 'change' }
        // ],
        screen_code: [
          { required: true, message: '请输入屏幕编号', trigger: 'change' },
        ],
        screen_name: [
          { required: true, message: '请输入屏幕名称', trigger: 'change' },
        ],
        exam_rooms: [
          { required: true, message: '请输入关联机房', trigger: 'change' },
        ],
        call_content: [
          { required: true, message: '请定制呼叫内容', trigger: 'change' },
        ],
        preset_style: [
          { required: true, message: '请选择预设样式', trigger: 'change' },
        ],
        voice_generation_mode: [
          { required: true, message: '请选择预设样式', trigger: 'change' },
        ],
        need_voice: [
          { required: true, message: '请选择预设样式', trigger: 'change' },
        ],
        show_ionizing_logo: [
          { required: true, message: '请选择预设样式', trigger: 'change' },
        ],
      },
      QueueVisible: false,
      QueueList: [],
      QueueRoomList: [],
      QueueCheckRooms: [],
      InstitutionList: [],
      CallScreenLayoutList: [], // 可选择的叫号屏基础设置
      roomArr: [],
      isEdit: false,
    }
  },
  components: {
    paginationTool,
  },
  created() {
    this.GetScreens()
    this.selectImg = this.imgList[0]
    // this.getPascListFn()
    this.getScreenLayoutListFn()
    // this.getInstitutionList()
    this.beganGetInspectRoom()
  },
  methods: {
    async GetScreens() {
      const that = this
      // const obj = {
      //   groupName: 'CallScreens'
      // };
      that.tabelData = []
      const res = await GetScreens()
      if (res.code === 0) {
        if (res.data != null && res.data.length > 0) {
          that.tabelData = res.data
        }
      }
    },
    async beganGetInspectRoom() {
      const manager = new Mgr()
      const user = await manager.getRole()
      const tenancy_id = sessionStorage.getItem('curTenancyId') || user.profile.tenancy_id
      var sid = tenancy_id
      const param = {
        roomState: 10,
        tenancy_id: sid,
        // organizationId: this.addExamItemParam.examination_item_attr_dto.organization_id,
        // departmentId: this.addExamItemParam.examination_item_attr_dto.department_id
      }
      const res = await getObservationRoom(param)
      if (res.code === 0) {
        this.roomArr = res.data
      }
    },

    async getPascListFn() {
      const res = await getPascList('1')
      if (res.code === 0) {
        this.PacsSystemList = res.data
      }
    },

    async getScreenLayoutListFn() {
      const res = await GetScreenLayoutList()
      if (res.code === 0) {
        this.CallScreenLayoutList = res.data
      }
    },

    async GetNewId() {
      let res = await fetchSnowId()
      return res.data
    },
    // 分页事件
    pagination(data) {
      this.listQuery.offset = data.page
      this.listQuery.limit = data.limit
    },
    handleEdit(row) {
      this.isEdit = true
      this.form = JSON.parse(JSON.stringify(row))
      this.call_content = this.form.call_content
      if (
        this.form.screen_type === 1 &&
        (!this.form.call_content || this.form.call_content === '')
      ) {
        this.form.call_content =
          '请{PatientName}到{ExamineRoom}检查，请{WaitExamine}做准备'
      } else if (
        (this.form.screen_type === 2 && !this.form.call_content) ||
        this.form.call_content === ''
      ) {
        this.form.call_content = '请{PatientName}到登记台领取报告'
      }
      this.editVisible = true
    },

    async newOne() {
      const _this = this
      _this.isEdit = false
      const id = await this.GetNewId()
      _this.editVisible = true
      _this.form = {
        id: 0,
        screen_type: 1,
        pacs_system: '',
        screen_code: '',
        screen_name: '',
        screen_title: '',
        exam_rooms: '',
        call_content:
          '请{PatientName}到{ExamineRoom}检查，请{WaitExamine}做准备',
        reminder: '',
        preset_style: '',
        voice_generation_mode: 0,
        need_voice: 0,
        show_ionizing_logo: 0,
        clientId: id, // ??
        queues: [], // ??
      }

      _this.call_content = _this.form.call_content
    },
    changeScreenType(val) {
      if (val === 1) {
        this.form.call_content =
          '请{PatientName}到{ExamineRoom}检查，请{WaitExamine}做准备'
      } else {
        this.form.call_content = '请{PatientName}到登记台领取报告'
      }
    },
    deleteSrceen(row) {
      const self = this
      this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          const param = {
            id: row.id,
          }
          DeleteConfig(param).then((result) => {
            if (result.code === 0) {
              self.$message({
                type: 'success',
                message: '删除成功!',
              })
              self.GetScreens()
            } else {
              self.$message({
                type: 'info',
                message: `${result.msg}`,
              })
            }
          })
        })
        .catch(() => {})
    },
    async SaveQueueDefine() {
      const _this = this
      let res = null
      for (const i in _this.QueueList) {
        _this.QueueList[i].group_mode = '0' // 目前默认是队列名称
        _this.QueueList[i].screen_config_id = _this.form.id
        _this.QueueList[i].group_items = _this.QueueList[i].items.join(',')
      }
      // _this.QueueList.forEach(e => {
      //   e.group_mode = 0 // 目前默认是队列名称
      //   e.screen_config_id = _this.form.id
      //   e.group_items = e.items.join(',')
      // })
      res = await PostScreenQueueDefine(_this.form.id, _this.QueueList)
      // if (this.form.id === 0) { // 新增
      //   res = await PostScreenQueueDefine(_this.form.id, this.form)
      // } else { // 修改
      //   res = await PutScreenConfig(this.form)
      // }

      if (res.code === 0) {
        this.$message.success(res.msg)
        this.GetScreens()
        this.editVisible = false
      } else {
        this.$message.error(res.msg)
      }
    },
    async submitForm(ivali = true) {
      const that = this
      // that.config.views[0].ParamGroup = "CallScreens";
      // that.config.views[0].ParamCode = that.form.screen_code;
      // this.config.views[0].Id = that.form.Id == "" ? "0" : that.form.Id;
      // that.config.views[0].ParamValue = JSON.stringify(that.form);
      // that.config.views[0].OrganizationId = that.form.OrganizationId;
      // that.config.views[0].ParamOptions = that.form.ExamRooms;
      if (ivali) {
        that.$refs.form.validate((valid) => {
          if (valid) {
            that.SaveParameterFn()
          }
        })
      } else {
        that.SaveParameterFn()
      }
    },
    async SaveParameterFn() {
      let res = null
      if (this.form.id === 0) {
        // 新增
        res = await PostScreenConfig(this.form)
      } else {
        // 修改
        res = await PutScreenConfig(this.form)
      }

      if (res.code === 0) {
        this.$message.success(res.msg)
        this.GetScreens()
        this.editVisible = false
      } else {
        this.$message.error(res.msg)
      }
    },
    async getInstitutionList() {
      //const _url = "/institutions?offset=1&limit=9999";
      const res = await getInstitutionListLite()
      if (res.code === 0) {
        this.InstitutionList = res.data
      } else {
        this.$message.error(res.msg)
      }
    },
    openContentConfig() {
      this.CallContentConfigVisible = true
      this.call_content = JSON.parse(JSON.stringify(this.form.call_content))
    },
    change(val) {
      const elinput = document.getElementById('contentInput')
      this.startPos = elinput.selectionStart
      this.endPos = elinput.selectionEnd
      this.call_content =
        this.call_content.substring(0, this.startPos) +
        val +
        this.call_content.substring(this.endPos)
    },
    sureChange() {
      this.form.call_content = this.call_content
      this.CallContentConfigVisible = false
    },
    changeImg(imgurl) {
      this.selectImg = imgurl
    },
    sureStyle() {
      this.form.preset_style = this.selectImg.code
      this.styleVisible = false
    },
    getStyleFormat(row) {
      let res = row.preset_style
      this.PresetStyleList.forEach((e) => {
        if (e.value === row.preset_style) {
          res = e.label
        }
      })
      return res
    },
    getSystemFormat(row) {
      let res = row.PacsSystem
      this.PacsSystemList.forEach((e) => {
        if (e.value === row.PacsSystem) {
          res = e.label
        }
      })
      return res
    },
    deleteTip(row) {},

    /**
     * 打开队列弹窗
     */
    async QueueOpen(row) {
      const that = this
      that.QueueList = []
      that.form = row
      that.QueueRoomList = that.form.exam_rooms.split(',')
      const res = await GetScreenQueueDefineList(row.id)
      if (res.code === 0) {
        if (res.data != null && res.data.length > 0) {
          that.QueueList = res.data
          that.QueueList.forEach((element) => {
            if (
              element.group_items !== undefined &&
              element.group_items !== null &&
              element.group_items !== ''
            ) {
              element.items = element.group_items.split(',')
            } else {
              element.items = []
            }
          })
        }
      }
      // if (this.form.Queues != undefined && this.form.Queues.length > 0) {
      //   this.QueueList = JSON.parse(JSON.stringify(this.form.Queues));
      // } else {
      //   this.QueueList = [];
      // }
      this.QueueVisible = true
    },

    /**
     * 新建队列
     */
    newQueue() {
      const that = this
      if (this.QueueList != null && this.QueueList.length > 0) {
        if (
          this.QueueList[this.QueueList.length - 1].queue_name === '' ||
          this.QueueList[this.QueueList.length - 1].items === ''
        ) {
          this.$message.warning('队列内容不能为空!')
          return
        }
      }
      let queuename = ''
      if (this.QueueList === null || this.QueueList.length === 0) {
        queuename = 'Queue1'
      } else {
        var lastname = this.QueueList[this.QueueList.length - 1].queue_name
        if (lastname && lastname !== '') {
          queuename = 'Queue' + (parseInt(lastname.replace('Queue', '')) + 1)
        }
      }
      let QueueCheckRooms = []
      that.QueueList.forEach((element) => {
        QueueCheckRooms = QueueCheckRooms.concat(element.items)
      })

      that.QueueRoomList = []
      let arr = this.form.exam_rooms.split(',')
      arr.forEach((element) => {
        let a = QueueCheckRooms.filter((f) => {
          return f === element
        })
        if (a == null || a.length === 0) {
          that.QueueRoomList.push(element)
        }
      })
      if (that.QueueRoomList.length > 0) {
        this.QueueList.push({ queue_name: queuename, items: [] })
      } else {
        this.$message.warning('机房已经全部关联')
      }
    },
    queueDelete(row) {
      const index = this.QueueList.indexOf(row)
      if (index > -1) {
        this.QueueList.splice(index, 1)
      }
    },
    sureQueue() {
      this.form.Queues = this.QueueList
      this.submitForm(false)
      this.QueueVisible = false
    },
    queueChangeName(val, oldval) {
      if (this.QueueRoomList.indexOf(val) >= 0) {
        this.$message.warning('队列编码不能与机房相同！')
        return false
      }
    },
    getInstitutionName(id) {
      let o = this.InstitutionList.filter((f) => f.id === id)
      if (o !== undefined && o.length > 0) {
        return o[0].name
      } else {
        return ''
      }
    },
  },
}
</script>
<style lang='less' scoped>
.fz20 {
  font-size: 20px;
}
.collect-main {
  .table-content {
    border-bottom: none;
    position: relative;
    .el-icon-s-tools {
      width: 30px;
      height: 22px;
      line-height: 22px;
      text-align: center;
      background: rgb(242, 242, 242, 0.8);
      color: #0a70b0;
      font-size: 20px;
      position: absolute;
      right: 0px;
      top: 9px;
    }
  }
}
.div-base {
  width: 95%;
  margin-left: 2.5%;
  //margin-top: 20px
}
::v-deep .el-card {
  margin-top: 20px;
}
.save-btn {
  width: 100%;
  height: 50px;
  padding-left: 150px;
}
.check-item {
  width: 20%;
  float: left;
  margin: 20px 0;
}
.divider {
  display: inline-block;
  margin: 10px 0;
}
.el-card__header {
  background-color: #f5f5f5;
}
.box-content {
  width: 100%;
  height: auto;
}
.btn-play {
  width: 50px;
  text-align: center;
  cursor: pointer;
  float: left;
}
.save-btn {
  width: 100%;
  height: 50px;
  margin-top: 20px;
  padding-left: 20px;
}
::v-deep .wrap_content {
  overflow: auto;
}
.abow_dialog {
  display: flex;
  justify-content: center;
  align-items: Center;
  overflow: hidden;
  .el-dialog {
    background-color: #141518;
    margin: 0 auto !important;
    height: 90%;
    overflow: hidden;
    .el-dialog__body {
      background-color: #141518;
      position: absolute;
      left: 0;
      top: 54px;
      bottom: 0;
      right: 0;
      padding: 0;
      z-index: 1;
      overflow: hidden;
      overflow-y: auto;
    }
  }
}
::v-deep .el-dialog--center .el-dialog__body {
  padding: 0;
  // border: 1px solid #3a3c42;
  border-top: none;
}
.list-content {
  height: 100%;
  .operate-top {
    padding: 5px 10px;
    display: flex;
    justify-content: space-between;
  }
  .table-content {
    position: relative;
  }
  .list-bottom {
    margin: 5px 10px;
    display: flex;
    .print-box {
      display: flex;
    }
  }
}
.img-item {
}
.img-som {
  width: 110px;
  height: 56px;
  border: 3px solid #dcdfe6;
  margin: 8px;
  margin-bottom: 0px;
  cursor: pointer;
}
.img-som-div {
  width: 130px;
  float: left;
  height: 500px;
  background: #eeeeee;
  margin: 10px;
  border-radius: 5px;
}
.img-big-div {
  width: 650px;
  float: left;
  height: 500px;
}
.img-big {
  width: 628px;
  height: 478px;
  border: 1px solid #dcdfe6;
  margin: 10px;
  margin-top: 50px;
}
.slt-div {
  width: 100%;
  height: 40px;
  line-height: 40px;
  padding-left: 40px;
  font-size: 18px;
  border-bottom: 1px solid white;
}
.title-som {
  width: 100%;
  text-align: center;
}
.select-som {
  border: 3px solid #67c23a;
}
::v-deep .el-form-item__label,
.el-form-item__content {
  font-size: 14px;
}
</style>
