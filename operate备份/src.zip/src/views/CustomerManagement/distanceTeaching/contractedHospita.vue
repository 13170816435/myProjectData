<template>
  <div class="userlist">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>远程培训
          <i class="iconfont iconzhankaishouqi"></i> 签约医院
        </span>
      </div>
      <div class="tr col">
        <span @click="AddHospital" class="function-btn bg_e6 clr_ff">
          <i class="iconfont iconxinzeng"></i>签约医院
        </span>
      </div>
    </div>
    <div class="container">
      <div class="search-bar flex_row">
        <span class="search-bar-label">教学中心 :</span>
        <el-select
          v-model="searchData.service_center_id"
          @change="changeServiceCenter"
          filterable
          class="ele-select_32 width_200_select"
          placeholder="全部"
          style="width:180px"
        >
        <el-option value="">全部</el-option>
          <el-option
            v-for="(item,index) in serviceCenterArr"
            :key="index"
            :label="item.name"
            :value="item.id"
          ></el-option>
        </el-select>
        <span class="search-bar-label margin_left_30">所属机构 :</span>
        <el-select
          v-model="searchData.institution_id"
          @change="searchContactedHospital"
          filterable
          placeholder="全部"
          class="ele-select_32 width_200_select"
          style="width:180px"
        >
        <el-option value="">全部</el-option>
          <el-option
            v-for="(item,index) in InstitutionsArr"
            :key="index"
            :label="item.name"
            :value="item.id"
          ></el-option>
        </el-select>
        <div class="operateBtnDiv">
          <el-button type="primary" size="small" @click="searchContactedHospital">查询</el-button>
          <el-button size="small" plain @click="resetSearchData">重置</el-button>
        </div>
      </div>
      <div class="table-list pageTable" v-bind:class="{'noTableDataActive':noFilingClerk,'organTableData':true,'noTableData':tableData.length==0}">
        <el-table
          v-loading="loading"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          :data="tableData"
          border
          :header-cell-style="{background: '#F2F2F2',color: '#333'}"
          highlight-current-row
          header-row-class-name="strong"
        >
          <el-table-column type="index" label="序号" width="50">
            <template slot-scope="scope">
                <span>{{(searchData.offset - 1) * searchData.limit + scope.$index + 1}}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="60">
            <template slot-scope="scope">
              <span class="clr_da pointer" @click="delThisOrgan(scope.row.institution_id, scope.row)">解约</span>
            </template>
          </el-table-column>
          <el-table-column prop="service_center_names" label="教学中心" width="300">
            <template slot-scope="scope">
              <div
              >{{scope.row.service_center_names | serviceName}}</div>
            </template>
          </el-table-column>
          <el-table-column prop="institution_name" label="机构名称" width="400"></el-table-column>
          <el-table-column prop="service_state" label="联系人">
            <template slot-scope="scope">
              <div
                class="belongToDescription"
              >{{scope.row.manager_name}} ({{scope.row.manager_phone}})</div>
            </template>
          </el-table-column>
        </el-table>

      </div>
        <div class="pageDiv">
           <pagination-tool :total="totalPage" :page.sync="searchData.offset" :limit.sync="searchData.limit" @pagination="getCooperations"/>
        </div>
    </div>
    <el-dialog title="新增签约医院" :visible.sync="showAddhospitalAlert" top="8vh" width="900px" height="732px" :close-on-click-modal="false" v-dialogDrag>
      <div class="addHospitalCon">
        <div>
           <div class="stepCon">
          <div class="ballDiv">
            <span class="ball">1</span>
          </div>
          <div class="line"></div>
          <div class="ballDiv">
            <span class="ball">2</span>
          </div>
        </div>
        <div class="serviceCenterDiv fl">
          <div class="searchLabelDiv">
            <span class="labelTit">选择教学中心</span>
            <span class="labelTip">（必选）</span>
          </div>
          <!--这里要默认选择 第一个 作为服务中心-->
          <el-select class="searchCenterSec" filterable  v-model="addInstitutionParam.service_center_id" @change="chooseServiceCenter">
            <el-option value="">请选择</el-option>
            <el-option
              v-for="(item,index) in serviceCenterArr"
              :key="index"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </div>
        <!--这里如果没有选择服务中心 就不显示-->
        <!-- <div class="serviceCenterDiv chooseServiceDiv ml20 fl" v-if="addInstitutionParam.service_center_id">
          <div class="searchLabelDiv">
            <span class="labelTit">选择签约服务</span>
            <span class="labelTip">（必选）</span>
          </div>
          <el-checkbox-group v-model="servicesArr">
              <el-checkbox v-for="(item,index) in serviceCenterService" v-bind:key="index" class="fl openModule"  v-bind:label="item.service_code" border>{{item.service_name}}</el-checkbox>
          </el-checkbox-group>
        </div> -->
        </div>
        <div class="serviceCenterDiv clear">
          <div class="searchLabelDiv">
            <span class="labelTit">选择签约医院</span>
            <span class="labelTip">（必选）</span>
          </div>
          <el-input class="searchCenterSec fl" v-on:keyup.enter.native=getAllInstitutions() v-model="allInstitutionParam.contains_name" placeholder="机构名字"></el-input>
          <el-button type="primary" size="small" class="ml20" @click="searchOneInstitutions">查询</el-button>
          <el-button size="small" plain @click="resetInstituName">重置</el-button>
        </div>
        <div class="tableDataCon">
          <div class="tableDiv">
          <div v-bind:class="{'noTableDataActive':noFilingClerk,'organTableData':true,'noTableData':allInstitutionList.length==0}">
            <template>
              <el-table
                :data="allInstitutionList"
                border
                stripe
                style="width: 100%"
                :default-sort="{prop: 'date', order: 'descending'}"
                v-bind:row-key="getRowKeys"
                v-on:selection-change="handleSeviceSelectionChange"
                ref="multipleTable"
              >
                <el-table-column type="selection" v-bind:reserve-selection="true" width="48"></el-table-column>
                <el-table-column prop="name" label="机构名称"></el-table-column>
                <el-table-column prop="admin_name" label="机构联系人">
                <!-- <template slot-scope="scope"><div class='belongToDescription'  v-bind:title="scope.row.patientId">{{scope.row.patientId}}</div></template>-->
                </el-table-column>
                <el-table-column prop="admin_phone" label="联系电话"></el-table-column>
              </el-table>
            </template>
          </div>
          <div class="blockPage">
            <pagination-tool :total="totalOrganPage" :page.sync="allInstitutionParam.offset" :limit.sync="allInstitutionParam.limit" @pagination="getAllInstitutions"/>
          </div>
        </div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" plain @click="showAddhospitalAlert = false">取 消</el-button>
        <el-button type="primary" size="small" @click="sureAddHospital">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog title="解约" :visible.sync="showEdithospitalAlert" width="640px" height="480px" :close-on-click-modal="false" v-dialogDrag>
      <div class="editOranCon">
        <div class="editOrganConItem clear" v-for="(item,index) in newCooperationsDetail" v-bind:key="index">
          <div class="contractDiv">
            <span class="contractLabel fl">机构名称：</span>
            <span class="contractName fl">{{item.institution_name}}</span>
          </div>
          <div class="organHead clear">
            <span class="organHeadLabel fl">教学中心：</span>
            <span class="organHeadName fl">{{item.service_center_name}}</span>
            <span class="delThisCenter fr" @click="delThisHospital(item.id)">解约</span>
          </div>
          <!-- <div class="serviceCon chooseServiceDiv fl">
            <span class="serviceConLabel fl">签约服务：</span>
            <el-checkbox-group v-model="item.services">
               <el-checkbox v-for="(one,index) in item.allService" @change="checked=>updateService(checked, item.id,one.service_code)" v-bind:key="index" class="fl openModule"  v-bind:label="one.service_code" border>{{one.service_name}}</el-checkbox>
            </el-checkbox-group>
          </div> -->
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" plain @click="showEdithospitalAlert = false">关 闭</el-button>
        <!-- <el-button type="primary" size="small" @click="updateHosiptal">确 定</el-button> -->
      </span>
    </el-dialog>

  </div>
</template>

<script>
import Mgr from '@/utils/SecurityService'
import PaginationTool from '@/components/common/PaginationTool' // 分页
import { getConstants } from '@/api/commonHttp'
import { DeleteTeachCenterOrgan, getCooperationsList, getInstitutions, getUseInstitutions, addCooperations, getAllServiceCenter, getCooperationsDetail, stopServiceCooperation } from '@/api/platform_costomer/telemedicine'
export default {
  components: {
    PaginationTool
    // CommonTable
  },
  data () {
    return {
      value: '',
      loading: true,
      checked1: false,
      checked2: false,
      showEdithospitalAlert: false,
      showAddhospitalAlert: false, // 添加机构弹窗
      noFilingClerk: true, // 导入后台有没有列表数据
      choosedInstituArr: [],
      currentPage1: 1,
      currentPage: 1,
      allSeviceInfor: [],
      allInstitutionList: [], // 所有机构 分页
      InstitutionsArr: [], // 所有的机构 不分页
      serviceCenterArr: [], // 所有服务中心 不分页
      coustorType: [
        { type: 0, type_str: '医联体' },
        { type: 1, type_str: '医共体' },
        { type: 2, type_str: '公立医院' },
        { type: 3, type_str: '民营医院' }
      ],
      serviceState: [
        { state: 0, state_str: '民营医院' },
        { state: 1, state_str: '启动服务' },
        { state: 2, state_str: '暂停服务' },
        { state: 3, state_str: '服务中' }
      ],
      serviceType: [
        { type: 0, type_str: '云pacs' },
        { type: 1, type_str: '影像' },
        { type: 2, type_str: '心电' },
        { type: 3, type_str: '超声' }
      ],
      totalOrganPage: 1,
      totalPage: 1,
      searchData: {
        institution_id: '',
        service_center_id: '',
        offset: 1,
        limit: 20
      },
      addInstitutionParam: {
        institution_ids: [],
        service_center_id: '',
        services: [{
          begin_date: "",
          end_date: "",
          service_code: "400",
        }]
      },
      allInstitutionParam: {
        service_center_id: '',
        contains_name: '',
        offset: 1,
        limit: 20
      },
      serviceCenterData: [],
      CooperationsDetail: [],
      newCooperationsDetail: [],
      tableData: [],
      listQuery: {
        pageIndex: 1,
        pageSize: 20
      },
      total: 10000,
      // 用户详情
      drawer: false,
      direction: 'rtl',
      currentSeviceCenterId: null,
      currentInstitution_id: 0
    }
  },
  methods: {
    objectSpanMethod ({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 4 || columnIndex === 5) {
        // 用于设置要合并的列
        if (rowIndex % 2 === 0) {
          // 用于设置合并开始的行号
          return {
            rowspan: 2,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    },
    resetSearchData () {
      this.searchData = {
        institution_id: '',
        service_center_id: '',
        offset: 1,
        limit: 20
      }
      // 重置时 得获取下所有的机构
      this.getMyInstitutions()
      this.getCooperations()
    },
    searchContactedHospital () {
      this.searchData.offset = 1
      this.searchData.limit = 20
      this.getCooperations()
    },
    // 切换服务中心
    chooseServiceCenter (val) {
      this.allInstitutionParam.service_center_id = val
      this.getAllInstitutions()
    },
    // 添加签约机构
    AddHospital () {
      const self = this
      self.showAddhospitalAlert = true
      self.allInstitutionParam = {
        service_center_id: '',
        contains_name: '',
        offset: 1,
        limit: 20
      }
      self.getAllInstitutions()
      self.addInstitutionParam.service_center_id = this.$route.query.id ? this.$route.query.id : ''
      self.choosedInstituArr = []
      self.addInstitutionParam.institution_ids = []
      self.$nextTick(function () {
        self.$refs.multipleTable.clearSelection()
      })
      this.initBallHeight()
    },
    searchOneInstitutions () {
      this.allInstitutionParam.offset = 1
      this.allInstitutionParam.limit = 20
      this.getAllInstitutions()
    },
    resetInstituName () {
      this.allInstitutionParam.contains_name = ''
      this.allInstitutionParam.offset = 1
      this.allInstitutionParam.limit = 20
      this.getAllInstitutions()
    },
    // 获取所有机构 (包括未签约的机构 分页)
    async getAllInstitutions () {
      const param = {
        offset: this.allInstitutionParam.offset,
        limit: this.allInstitutionParam.limit
      }
      if (this.allInstitutionParam.contains_name) {
        param.contains_name = this.allInstitutionParam.contains_name
      }
      if (this.allInstitutionParam.service_center_id) {
        param.service_center_id = this.allInstitutionParam.service_center_id
      }
      param.category = 2
      const res = await getUseInstitutions(param)
      if (res.code === 0) {
        this.allInstitutionList = res.data
        this.totalOrganPage = res.page.total_count
      }
    },
    // 所有机构的分页
    handleCenterSizeChange (val) {
      this.allInstitutionParam.limit = val
      this.getAllInstitutions(this.allInstitutionParam.offset, val)
    },
    handleCenterCurrentChange (val) {
      this.allInstitutionParam.offset = val
      this.getAllInstitutions(val, this.allInstitutionParam.limit)
    },
    initBallHeight () {
      this.$nextTick(function () {
        var ballObj = document.getElementsByClassName('line')[0]
        ballObj.style.height = '42px'
      })
    },
    setBallHeight () {
      this.$nextTick(function () {
        var ballObj = document.getElementsByClassName('line')[0]
        var obj = document.getElementsByClassName('chooseServiceDiv')[0]
        var height = obj.clientHeight
        ballObj.style.height = height - 60 + 31 + 'px'
      })
    },
    // 添加签约机构
    async beganAddHospital () {
      const self = this
      // 这一步 主要 是为了 给addInstitutionParam.services 数组里面的对象增加begin_date和end_date字段
      if (!self.addInstitutionParam.service_center_id) {
        self.$message({ message: '请选择教学中心', type: 'error' })
        return false
      }
      if (self.addInstitutionParam.institution_ids.length === 0) {
        self.$message({ message: '请选择签约医院', type: 'error' })
        return false
      }
      const res = await addCooperations(self.addInstitutionParam)
      if (res.code === 0) {
        self.$message({ message: '添加签约医院成功', type: 'success' })
        self.showAddhospitalAlert = false
        self.getCooperations()
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 确定新增签约机构
    sureAddHospital () {
      this.beganAddHospital()
    },
    getRowKeys (row) {
      return row.id
    },
    // 勾选中的机构
    handleSeviceSelectionChange (val) {
      this.choosedInstituArr = val
      this.addInstitutionParam.institution_ids = []
      val.forEach((item) => {
        this.addInstitutionParam.institution_ids.push(item.id)
      })
    },
    // 确定 删除(解约) 机构
    async beganDelOrgan (hospitalId) {
      const self = this
      const param = {
        id: hospitalId
      }
      const result = await DeleteTeachCenterOrgan(param)
      if (result.code === 0) {
        self.$message({
          type: 'success',
          message: '删除成功!'
        })
        self.getCooperations()
      } else {
        self.$message({
          type: 'info',
          message: `${result.msg}`
        })
      }
    },
    delThisOrgan (id, item) {
      const self = this
      if (item.service_center_names.length === 1) {
          self.$confirm('确定要解约该机构?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          customClass: 'warningAlert',
          type: 'warning'
        })
        .then(() => {
          self.beganDelOrgan(id)
        })
        .catch(() => {
        })
      } else {
        self.showEdithospitalAlert = true
        self.beganGetCooperationsDetail(item.institution_id)
      }
    },
    delThisHospital (id) {
      const self = this
      self.$confirm('确定要解约该教学中心?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        customClass: 'warningAlert',
        type: 'warning'
      })
      .then(() => {
        self.beganDelServiceCenter(id)
      })
    },
    // 确定 删除(解约) 服务中心
    async beganDelServiceCenter (id) {
      const self = this
      const param = {
        id: id
      }
      const result = await stopServiceCooperation(param)
      if (result.code === 0) {
        self.$message({
          type: 'success',
          message: '解约成功!'
        })
        self.newCooperationsDetail.forEach(function (item, i) {
          if (item.id === id) {
            self.newCooperationsDetail.splice(i, 1)
          }
        })
        if (self.newCooperationsDetail.length === 0) {
          self.showEdithospitalAlert = false
        }
        // 获取合作医疗列表
        self.getCooperations()
      } else {
        self.$message({
          type: 'info',
          message: `${result.msg}`
        })
      }
    },
    async beganGetCooperationsDetail (hospitalId) {
      this.newCooperationsDetail = []
      const param = {
        id: hospitalId
      }
      const res = await getCooperationsDetail(param)
      if (res.code === 0) {
        this.CooperationsDetail = res.data
        this.getThisServiceCenterService()
      }
    },
    async getThisServiceCenterService () {
      const self = this
      for (let i = 0; i < self.CooperationsDetail.length; i++) {
        const params = {
          agreement_id: self.CooperationsDetail[i].agreement_id,
          id: self.CooperationsDetail[i].id,
          institution_id: self.CooperationsDetail[i].institution_id,
          institution_name: self.CooperationsDetail[i].institution_name,
          service_center_id: self.CooperationsDetail[i].service_center_id,
          service_center_name: self.CooperationsDetail[i].service_center_name,
          state: self.CooperationsDetail[i].state
        }
        self.newCooperationsDetail.push(params)
      }
    },
    handleSizeChange (val) {
      this.searchData.limit = val
      this.getCaseList(this.searchData.offset, val)
    },
    handleCurrentChange (val) {
      this.searchData.offset = val
      this.getCaseList(val, this.searchData.limit)
    },
    // 切换教学中心
    changeServiceCenter () {
      this.searchData.institution_id = ''
      this.getMyInstitutions()
      this.searchContactedHospital()
    },
    // 获取已经签约的机构
    async getMyInstitutions () {
      let res
      if (this.searchData.service_center_id) {
        res = await getInstitutions({service_center_id: this.searchData.service_center_id})
      } else {
        res = await getInstitutions()
      }
      if (res.code === 0) {
        this.InstitutionsArr = res.data
      }
    },
    async getMyConstants () {
      const res = await getConstants()
      this.allSeviceInfor = res.available_service
    },
    // 获取所有的服务中心(不分页)
    async getMyAllServiceCenter () {
      const param = { category: 2 }
      const res = await getAllServiceCenter(param)
      if (res.code === 0) {
        this.serviceCenterArr = res.data
        // 查看某个服务中心下的签约机构
        if (this.$route.query.id) {
          this.searchData.service_center_id = this.$route.query.id
          this.addInstitutionParam.service_center_id = this.$route.query.id
          this.currentSeviceCenterId = this.$route.query.id
        } else {
          this.searchData.service_center_id = ''
          this.addInstitutionParam.service_center_id = ''
          this.currentSeviceCenterId = null
        }
        // 获取合作医疗列表
        this.getCooperations()
      }
    },
    // 获取 签约机构 列表
    async getCooperations () {
      const param = {
        offset: this.searchData.offset,
        limit: this.searchData.limit,
        category: 2
      }
      if (this.searchData.institution_id) {
        param.institution_id = this.searchData.institution_id
      }
      if (this.searchData.service_center_id) {
        param.service_center_id = this.searchData.service_center_id
      }
      const res = await getCooperationsList(param)
      if (res.code === 0) {
        this.loading = false
        this.tableData = res.data
        this.totalPage = res.page.total_count
      } else {
        this.loading = false
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    }
  },
  mounted () {
    this.getMyInstitutions()
    this.getMyConstants().then(() => {
    //   this.getMyAllService()
    })
    this.getMyAllServiceCenter()
  }
}
</script>
<style lang="less" scoped>
.iconxinzeng {
  padding-right: 4px;
}
.userlist {
  width: 100%;
  height: 100%;
  overflow: hidden !important;
}
.userlist {
  .container {
    height: calc(100% - 47px);
    .search-bar {
      .el-input__inner {
        //   width:200px;
        border-radius: 3px;
      }
    }
    .table-list{
         position: relative;
         height: calc(100% - 99px);
         border: 1px solid #ebeef5;
         border-bottom: none;
         ::v-deep .el-table--border {
            border: none;
        }
        .pageDiv{
          width: 100%;
          position: absolute;
          bottom: 0px;
          text-align: right;
          padding-right: 5px;
          border-top: 1px solid #ebeef5;
      }
    }
    .icon-btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      color: #fff;
      line-height: 24px;
      text-align: center;
      padding: 0px;
      cursor: pointer;
      border-radius: 3px;
      margin-right: 8px;
    }
  }
}
.margin_left_30 {
  margin-left: 30px;
  margin-bottom: 10px;
}
.operateBtnDiv {
  margin-left: 10px;
}
/**添加签约机构弹窗样式 */
.addHospitalCon {
  position: relative;
  padding-top: 10px;
  padding-bottom:10px;
  // height: 626px;
  .stepCon {
    position: absolute;
    top: 13px;
    left: 0px;
    .ballDiv {
      width: 30px;
      height: 30px;
      text-align: center;
      .ball {
        display: inline-block;
        width: 20px;
        height: 20px;
        border-radius: 10px;
        background: #0bbd87;
        color: #fff;
        font-size: 15px;
        margin-top: 5px;
      }
    }
    .line {
      height: 42px;
      width: 2px;
      background: #dcdfe6;
      margin: auto;
    }
  }

  .serviceCenterDiv {
    padding-left: 40px;
    .searchLabelDiv {
      height: 36px;
      line-height: 36px;
      .labelTit {
        font-size: 15px;
        color: #303133;
      }
      .labelTip {
        color: #909399;
        font-size: 15px;
      }
    }
    .searchCenterSec {
      width: 240px;
      .el-input__inner {
        height: 36px;
        line-height: 36px;
        border-radius: 3px;
      }
      .el-input__icon {
        line-height: 36px;
      }
    }
    .search-bar-btn{
      padding: 0px 13px;
      height: 36px;
      line-height: 35px;
      border-radius: 3px;
      border: none;
      cursor: pointer;
    }
    .res-bar-btn{
      padding: 0px 13px;
      height: 36px;
      line-height: 35px;
      border-radius: 3px;
      border: 1px solid #ddd;
      cursor: pointer;
      color: #606266;
    }
  }
  .chooseServiceDiv {
    padding-left: 0;
    float:left;
    width:calc(100% - 300px);
    .openModule {
      height: 36px;
      line-height: 36px;
      padding: 0 15px;
      border-radius: 3px;
      border: 1px solid #dcdfe6;
      margin-right: 10px;
      color: #0a70b0;
      cursor: pointer;
      margin-bottom:5px;
     ::v-deep .el-checkbox__label{
       padding-left:0px;
       color:#0a70b0!important;
     }
    }
    .openModule.el-checkbox.is-bordered.is-checked {
      background: url("../../../assets/images/common/checkboxBg.png") right
        bottom no-repeat;
    }
    ::v-deep .is-bordered {
      margin-left: 0;
    }
    .openModule {
      ::v-deep .el-checkbox__inner {
        display: none;
      }
    }
    .openModule:hover {
      background: rgba(10, 112, 176, 0.6);
      color: #fff;
    }
  }
  .tableDiv {
    margin-top: 10px;
    // border: 1px solid #dcdfe6;
    // border-bottom:none;
    .organTableData {
      height: 360px;
      ::v-deep th {
        background: #f9f9f9;
      }
      ::v-deep .el-table {
        height: 100%;
        .el-table__body-wrapper {
          height: calc(100% - 40px);
          overflow-x:hidden!important;
          overflow-y: auto!important;
        }
      }
      ::v-deep .el-table-column--selection .cell {
        padding-left: 10px;
      }
    }
    .blockPage {
      text-align: center;
      border: 1px solid #dcdfe6;
      border-top:none;
    }
  }
}
/**添加签约机构弹窗样式 结束*/
/**编辑机构弹窗样式 */
.editOranCon {
  height: 354px;
  padding: 0 15px;
  overflow-y: auto;
  .contractDiv{
    margin-top: 20px;
    height: 32px;
    line-height: 32px;
    .contractLabel {
      font-size: 15px;
      color: #606266;
      width: 80px;
    }
    .contractName {
      font-size: 15px;
      color: #303133;
      font-weight: 700;
    }
  }
  .organHead {
    height: 32px;
    line-height: 32px;
    margin-bottom: 10px;
    .organHeadLabel {
      font-size: 15px;
      color: #606266;
      width: 80px;
    }
    .organHeadName {
      font-size: 15px;
      color: #303133;
      font-weight: 700;
    }
    .delThisCenter {
      width: 56px;
      height: 32px;
      line-height: 32px;
      text-align: center;
      background: #fef0f0;
      color: #f56f6f;
      border-radius: 3px;
      cursor: pointer;
    }
    .delThisCenter:hover {
      background: #f56f6f;
      color: #fff;
    }
  }

  .serviceCon {
    .serviceConLabel {
      font-size: 15px;
      color: #606266;
      width: 80px;
    }
    ::v-deep .el-checkbox-group{
      float:left;
      width:calc(100% - 80px);
    }
  }
  .editOrganConItem {
     border-bottom: 1px dashed #dcdfe6;
  }
  .editOrganConItem:last-of-type{
    border-bottom:none;
  }
  .chooseServiceDiv {
    width:100%;
    padding-left: 0;
    padding-bottom: 20px;
    .openModule {
      height: 36px;
      line-height: 36px;
      padding: 0 15px;
      border-radius: 3px;
      border: 1px solid #dcdfe6;
      margin-right: 10px;
      color: #0a70b0!important;
      cursor: pointer;
      // width: 92px;
      text-align: center;
      margin-bottom: 5px;
      ::v-deep .el-checkbox__label{
        padding-left:0px;
        color:#0a70b0!important;
      }
    }
    .openModule.el-checkbox.is-bordered.is-checked {
      background: url("../../../assets/images/common/checkboxBg.png") right
        bottom no-repeat;
    }
    ::v-deep .is-bordered {
      margin-left: 0;
    }
    ::v-deep .el-checkbox__label {
      padding-left: 0px;
    }
    .openModule {
      ::v-deep .el-checkbox__inner {
        display: none;
      }
    }
    .openModule:hover {
      background: rgba(10, 112, 176, 0.6);
      color: #fff;
    }
    .chooseServiceDiv:last-of-type{
      border-bottom: none!important;
    }
  }
}

::v-deep .el-dialog__body{
  overflow: auto!important;
}
.instituteTip{
  font-size:13px;
  color: #ff9900;
  display:inline-block;
  margin-left:20px;
}
.tableDataCon{
  padding-left: 40px;
  padding-right: 20px;
}
::v-deep .el-dialog__body{
  overflow: auto!important;
}
.pageDiv{
  border: 1px solid #EBEEF5;
  border-top: none;
}

</style>
