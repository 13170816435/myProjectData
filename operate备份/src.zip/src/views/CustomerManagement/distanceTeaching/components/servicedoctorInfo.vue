<template>
  <div class="servicedoctorInfo" id="doctorDetail">
    <div class="servicedoctorInfo-title">
      <span class="servicedoctorInfo-titleinfo">医生详情</span>
      <span @click="closeFn" class="close-btn iconfont iconchuangjianshibai"></span>
    </div>
    <div class="contaner">
      <div class="contaner-info">
        <div class="doctorIconInfor">
          <img class="doctorIconCon doctorIcon fl mr20" v-if="currentDoctorIcon" v-bind:src="currentDoctorIcon"   :onerror="defaultImg" />
          <p class="doctorNameAndJob fl">
           <span class="doctorName">{{doctorDetail.name}}</span>
           <span class="doctorJob">{{doctorDetail.title}}</span>
            <p class="doctorHosiptal">{{doctorDetail.institution_name}}_{{doctorDetail.office_name}}</p>
            <div class="goodAtDiv">
              <span class="doctorGoodAtTit">
                <span class="goodAtLabel">擅长：</span>
                <span class="goodAtCon" v-bind:title="doctorDetail.speciality" v-html="$replaceRN(doctorDetail.speciality)"></span>
              </span>
            </div>
          </p>
        </div>
        
       <div class="introduceDiv clear mt10">
          <span class="doctorGoodAtTit" >
            <span class="goodAtLabel">简介：</span>
            <span class="goodAtCon introduceCon moreLineEllipsis moreLineAfter" v-html="$replaceRN(doctorDetail.introduction)" @click="showAll($event)"></span>
          </span>
        </div>
      </div>
      <div class="serviceContaner">
        <div class="serviceContanerHead">
          <span class="fl serviceHeadIcon"></span>
          <span class="fl serviceHeadTit">已签约服务</span>
        </div>
        <div class="allService">
          <div class="editOrganConItem clear" v-for="(item,index) in allServiceInfor" v-bind:key="index">
            <div class="organHead">
              <span class="organHeadLabel fl">教学中心：</span>
              <span class="organHeadName fl">{{item.service_center_name}}</span>
              <span class="delThisCenter fr" @click="delThisCenter(item)">解约</span>
            </div>
            <!-- <div class="serviceCon chooseServiceDiv fl">
              <span class="serviceConLabel fl">签约服务：</span>
              <el-checkbox-group v-model="item.services">
               <el-checkbox v-for="(one,index) in item.allService" @change="checked=>updateService(checked, item.id,one.service_code)" v-bind:key="index" class="fl openModule"  v-bind:label="one.service_code" border>{{one.service_name}}</el-checkbox>
              </el-checkbox-group>
            </div> -->
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { getServiceCenterSevice, getDoctorDetail, DeleteOneDoctorService, openThisDoctorService, DeleteOneDoctor } from '@/api/platform_costomer/telemedicine'
import { getUserLogo } from '@/api/commonHttp'
import { getBase64 } from '@/components/commonJs'
export default {
  props: {
    servicedoctorId: String
  },
  data () {
    return {
      // myservicedoctorInfo:JSON.parse(this.servicedoctorInfo),
      // defaultImg: 'this.src="' + require('@/assets/images/common/doctor_boy.png') + '"',
      defaultImg: require('@/assets/images/common/doctor_boy.png'),
      checked1: false,
      checked2: false,
      currentDoctorIcon: '',
      doctorDetail: {},
      allServiceInfor: [],
      serviceCenterService: [],
      CooperationsDetail: []
    }
  },
  methods: {
    // 判断是否有省略
    isOmit () {
      var oDiv = document.querySelectorAll('#doctorDetail .moreLineEllipsis')
      oDiv.forEach(item => {
        if (item.scrollHeight > item.clientHeight) {
          item.classList.remove('moreLineShowAll')
          item.classList.add('showMoreLineAfter')
        } else {
          item.classList.remove('showMoreLineAfter')
          item.classList.remove('moreLineShowAll')
        }
      })
    },
    // 显示所有
    showAll ($event) {
      if ($event.target.scrollHeight > $event.target.clientHeight) {
        // $event.target.classList.remove('showMoreLineAfter')
        $event.target.classList.remove('moreLineAfter')
        $event.target.classList.add('moreLineShowAll')
      } else {
        $event.target.classList.remove('moreLineShowAll')
        // $event.target.classList.add('showMoreLineAfter')
        $event.target.classList.add('moreLineAfter')
      }
    },
    async getMyServiceCenterSevice () {
      const self = this
      self.allServiceInfor = []
      for (let i = 0; i < self.CooperationsDetail.length; i++) {
        const params = {
          agreement_id: self.CooperationsDetail[i].agreement_id,
          id: self.CooperationsDetail[i].id,
          institution_id: self.CooperationsDetail[i].institution_id,
          institution_name: self.CooperationsDetail[i].institution_name,
          service_center_id: self.CooperationsDetail[i].service_center_id,
          service_center_name: self.CooperationsDetail[i].service_center_name,
          services: [],
          allService: '',
          state: self.CooperationsDetail[i].state
        }
        const res = await getServiceCenterSevice({ id: self.CooperationsDetail[i].service_center_id, type: 3 })
        if (res.code === 0) {
          params.allService = res.data
          // 将服务中心开通的服务services字段的值 只保留 service_code 即：services:["111","222"]
          self.CooperationsDetail[i].services.forEach(function (val) {
            params.services.push(val.service_code)
          })
          self.allServiceInfor.push(params)
        } else {
          self.$message({
            type: 'info',
            message: `${res.msg}`
          })
        }
      }
    },
    closeFn () {
      this.$emit('closeFn')
    },
    subInfor () {
      this.$message({ message: '提交成功', type: 'success' })
      this.$emit('closeFn')
    },
    // 确定 删除(解约) 服务中心
    async beganDelServiceCenter (obj) {
      const self = this
      const param = {
        id: obj.id
        // slug: ''
      }
      // const arr = []
      // obj.allService.forEach(function (val) {
      //   arr.push(val.service_code)
      // })
      // param.slug = arr.join('-')
      const result = await DeleteOneDoctor(param)
      if (result.code === 0) {
        self.$message({
          type: 'success',
          message: '解约成功!'
        })
        self.allServiceInfor.forEach(function (item, i) {
          if (item.service_center_id === obj.service_center_id) {
            self.allServiceInfor.splice(i, 1)
          }
        })
        // 没有一家签约的服务中心了
        if (self.allServiceInfor.length === 0) {
          this.$emit('updateList')
          this.$emit('closeFn')
        }
      } else {
        self.$message({
          type: 'info',
          message: `${result.msg}`
        })
      }
    },
    delThisCenter (obj) {
      const self = this
      self.$confirm(`确定要与${obj.service_center_name}进行解约？`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        customClass: 'warningAlert',
        type: 'warning'
      })
        .then(() => {
          self.beganDelServiceCenter(obj)
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消解约'
          })
        })
    },
    // 详情方法
    async searchDoctorInfo (id) {
      const self = this
      self.drawer = true
      const res = await getDoctorDetail({ id: id, category: 2, })
      if (res.code === 0) {
        self.doctorDetail = res.data
        self.CooperationsDetail = self.doctorDetail.items
        self.getMyServiceCenterSevice()
        // 获取logo 图片
        getUserLogo(self.doctorDetail.doctor_id).then((res) => {
          getBase64(res).then(resinfo => {
            if (resinfo) {
              self.currentDoctorIcon = resinfo
            } else {
              self.currentDoctorIcon = self.defaultImg
            }
            
          })
        }).catch(e => {
          //self.currentDoctorIcon = this.$options.data().currentDoctorIcon
          self.currentDoctorIcon = self.defaultImg
        })
        self.$nextTick(() => {
          self.isOmit()
        })
      } else {
        self.$message({
          type: 'error',
          message: `${res.msg}`
        })
      }
    }
  },
  mounted () {
    // this.getMyServiceCenterSevice(this.servicedoctorInfo.service_center_id)
  },
  watch: {
    servicedoctorId: {
      handler (newVal) {
        // console.log(newVal)
        if (this.servicedoctorId) {
          this.searchDoctorInfo(this.servicedoctorId)
        }
      },
      deep: true,
      immediate: true
    }
  }
}
</script>
<style lang="less" scoped>
::v-deep .el-drawer__body{
  height: 100%;
}
.servicedoctorInfo {
  width: 750px;
  height: 100%;
  padding: 0px 25px;
  .servicedoctorInfo-title {
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    .servicedoctorInfo-titleinfo {
      font-size: 16px;
      color: #303133;
      font-weight: 700;
    }
    .clr_00a {
      background: rgba(0, 173, 120, 1);
    }
    .servicedoctorInfo-title-state {
      display: inline-block;
      padding: 0px 6px;
      height: 20px;
      line-height: 20px;
      border-radius: 3px;
      color: #fff;
      margin-right: 10px;
    }
    .close-btn {
      position: absolute;
      right: 0px;
      top: 0px;
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .contaner {
    height: calc(100% - 65px);
    border: 1px solid #dcdfe6;
    overflow-y: auto;
    .failreson {
      height: 42px;
      line-height: 42px;
      padding: 0px 10px;
      background: #fff6f7;
      .clr_88 {
        color: #888888;
      }
      .clr_da {
        color: #da4a4a;
      }
    }
    .contaner-info {
      border-bottom: 1px solid #dcdfe6;
      padding-bottom: 20px;
      // min-height: 40%;
      padding: 20px 20px 15px 20px;
      background:#fefbf6;
      .doctorIconInfor{
        width:100%;
        padding-bottom:15px;
        border-bottom: 1px dashed #dcdfe6;
      }
      .doctorIconInfor::after{
        content: '';
        height: 0;
        display: block;
        clear: both;
        visibility: hidden;
      }
      .doctorIconCon{
        width: 120px;
        height: 120px;
        padding:8px;
        border-radius: 50%;
        overflow: hidden;
        background: #FFF;
        border:1px solid #d4eaff;
      }
      .doctorIcon {
        width:120px;
        display: block;
      }
      .doctorNameAndJob {
        // margin-top: 12px;
        line-height: 35px;
        text-align: left;
        width:calc(100% - 140px);
        .doctorName {
          font-size: 20px;
          color: #303133;
          font-weight: bold;
        }
        .doctorJob {
          font-size: 15px;
          color: #303133;
          padding-left: 10px;
        }
      }
      .doctorHosiptal {
        text-align: left;
        width:calc(100% - 140px);
        line-height: 30px;
        font-size: 15px;
        color: #303133;
      }
      .goodAtDiv {
        margin-top: 5px;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        display: -moz-box;
        -moz-line-clamp: 2;
        -moz-box-orient: vertical;
        word-wrap: break-word;
        word-break: break-all;
        white-space: normal; 
        .doctorGoodAtTit {
          font-size: 15px;
          color: #303133;
          position: relative;
        }
        .goodAtLabel{
          font-weight: bold;
        }
        .goodAtCon {
          font-size: 15px;
          color: #606266;
          line-height: 26px;
          text-align: justify;
        }
      }
    }
  }
  .serviceContaner {
    .serviceContanerHead {
      height: 40px;
      line-height: 40px;
      padding-left: 10px;
      .serviceHeadIcon {
        width: 2px;
        height: 16px;
        background: #0a70b0;
        margin-top: 12px;
        margin-right: 10px;
      }
    }
    .allService {
      margin-top: 8px;
      padding: 0px 20px;
      .editOrganConItem {
        border-bottom: 1px dashed #dcdfe6;
        margin-bottom: 10px;
        .organHead {
          // margin-top:20px;
          height: 32px;
          line-height: 32px;
          margin-bottom: 10px;
          .organHeadLabel {
            font-size: 15px;
            color: #606266;
            width: 80px;
          }
          .organHeadName {
            font-size: 15px;
            color: #303133;
            font-weight: 700;
          }
          .delThisCenter {
            width: 56px;
            height: 32px;
            line-height: 32px;
            text-align: center;
            background: #fef0f0;
            color: #f56f6f;
            border-radius: 3px;
            cursor: pointer;
          }
          .delThisCenter:hover {
            background: #f56f6f;
            color: #fff;
          }
        }

        .serviceCon {
          .serviceConLabel {
            font-size: 15px;
            color: #606266;
            width: 80px;
          }
        }

        .chooseServiceDiv {
          padding-left: 0;
          padding-bottom: 20px;
          width:100%;
          .openModule {
            height: 36px;
            line-height: 36px;
            padding: 0 15px;
            border-radius: 3px;
            border: 1px solid #dcdfe6;
            margin-right: 10px;
            color: #0a70b0;
            cursor: pointer;
            // width: 92px;
            text-align: center;
            margin-bottom:5px;
          }
          .openModule.el-checkbox.is-bordered.is-checked {
            background: url("../../../../assets/images/common/checkboxBg.png")
              right bottom no-repeat;
          }
          ::v-deep .is-bordered {
            margin-left: 0;
          }
          ::v-deep .el-checkbox__label {
            padding-left: 0px;
          }
          .openModule {
            ::v-deep .el-checkbox__inner {
              display: none;
            }
          }
          .openModule:hover {
            background: rgba(10, 112, 176, 0.6);
            color: #fff;
          }
        }
      }
      .editOrganConItem:last-of-type{
        border-bottom:none;
      }
      ::v-deep .el-checkbox-group{
        float: left;
        width: calc(100% - 80px);
      }
    }
  }
  .operate-btn-div {
    height: 60px;
    line-height: 52px;
    ::v-deep i {
      padding-right: 6px;
    }
  }
  .operate-btn {
    // width: 84px;
    height: 36px;
    line-height: 36px;
    border-radius: 3px;
    color: #fff;
    padding: 0px 15px;
    border: none;
  }
  .bg_e6 {
    background: #e6a23c;
  }
  .bg_f5 {
    background: #f56c6c;
  }
  .bg_0c {
    background: #0c83cd;
  }
  .bg_00 {
    background: #00ad78;
  }
}
.introduceDiv{
  min-height: 40px;
  .doctorGoodAtTit {
    font-size: 15px;
    color: #303133;
    position: relative;
  }
  .goodAtLabel{
    font-weight: bold;
    position: absolute;
    top: 0;
    left:0;
    display: inline-block;
    width: 50px;
  }
  .goodAtCon {
    font-size: 15px;
    color: #303133;
    line-height: 26px;
    text-align: justify;
    position: relative;
    padding-left:50px;
  }
}
.moreLineAfter{
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}
.moreLineEllipsis:after {
    display: none;
    position: absolute;
    bottom: 0;
    right: 0;
    font-size:15px!important;
    content: '查看更多';
    background-color: #fff;
    color: #0a70b0;
    cursor: pointer;
    text-align: right;
    font-weight: bold;
    padding-left: 13px;
}
.medIconfont{
  font-size:15px!important;
}
.introduceCon::after{
   content: '展开';
}
.moreLineShowAll:after {
    display: block;
    content: '收起';
}
.showMoreLineAfter:after {
   display: block;
}
</style>
