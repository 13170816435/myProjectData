<template>
<!-- 表格： 可通过后台返回控制table显示某列 及自定义宽度 -->
  <div>
    <template v-for="(item, index) in propData">
      <el-table-column
        v-if="item.prop == 'device_type'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template slot-scope="scope">
          <div
          >{{scope.row.device_type | deviceType}}</div>
        </template>
      </el-table-column>
      <el-table-column
        v-else-if="item.prop == 'is_enable'"
        :key="index+1"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template slot-scope="scope">
            <span class='enableStu' v-if="scope.row.is_enable">启用</span>
            <span class="stopStu" v-else>停用</span>
          </template>
      </el-table-column>
      <el-table-column
        v-else-if="item.prop == 'is_online'"
        :key="index+2"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template slot-scope="scope">
            <span class='enableStu' v-if="scope.row.is_online">在线设备</span>
            <span class="stopStu" v-else>近线设备</span>
          </template>
      </el-table-column>
      <el-table-column
        v-else-if="item.prop == 'used_size'"
        :key="index+3"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template slot-scope="scope">
          <span>{{scope.row.used_size | changeBunit }}</span>
        </template>
      </el-table-column>

      <el-table-column
        v-else-if="item.prop == 'type'"
        :key="index+4"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
          <span>{{scope.row.type  | getBusinessParamValue(allType)}}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-else-if="item.prop == 'patient_sex'"
        :key="index+5"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
          <span>{{scope.row.patient_sex === 1 ? '男' : '女'}}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-else
        :key="index+6"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
      </el-table-column>
    </template>
  </div>
</template>
<script>
import mixin from '@/utils/mixin/intelligentDiagnosis'
export default {
  name: 'CommonTable',
  props: {
    propData: Array,
    action: Number,
    systemTypeArr: Array,
    businessSystem: Array,
    allModule: Array,
    allType: Array
  },
  mixins: [mixin]
}
</script>
<style lang="less">
.clr_red{
  color:#da4a4a;
}
.enableStu{
  color:#00A367;
  font-size:14px;
  font-weight:400;
}
.stopStu{
  font-size:14px;
  font-weight:400;
  color: #da4a4a;
}
</style>
