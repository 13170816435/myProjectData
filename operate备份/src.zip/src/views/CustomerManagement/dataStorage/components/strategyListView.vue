<template>
    <div :class="{ noTableData: (tableData.length === 0) }">
        <el-table border stripe :data="tableData" style="width: 100%" :default-sort="{ prop: 'date', order: 'descending' }"
            ref="multipleTable" @selection-change="handleSelectionChange">
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column type="index" label="序号" fixed="left" width="50" v-if="showSerial"></el-table-column>
            <el-table-column label="操作" width="80">
                <template slot-scope="scope">
                    <span class="clr_0a pointer" @click="editStrategy(scope.row)">编辑</span>
                </template>
            </el-table-column>
            <!-- <common-table :propData="propData" /> -->
            <el-table-column v-if="!showSerial" prop="org_name" label="机构名称"  :show-overflow-tooltip="true"> </el-table-column>
            <el-table-column v-if="showSerial" prop="system_name" label="业务系统" :show-overflow-tooltip="true"> </el-table-column>
            <el-table-column v-if="showSerial" prop="domain_name" label="存储域" :show-overflow-tooltip="true"> </el-table-column>
            <el-table-column prop="nearline_enable" label="近线策略" width="80">
                <template slot-scope="{row}">
                    <el-switch v-model="row.nearline_enable" active-color="#409EFF" inactive-color="#DCDFE6"
                        :active-value="1" @change="switchChange(row)">
                    </el-switch>
                </template> </el-table-column>

            <el-table-column v-for="item in propData1" :key="item.index" :prop="item.prop" :label="item.label"
                :width="item.width" :formatter="item.formatter" :show-overflow-tooltip="true">

            </el-table-column>

            <el-table-column prop="offline_enable" label="离线策略" width="80">
                <template slot-scope="{row}">
                    <el-switch v-model="row.offline_enable" active-color="#409EFF" inactive-color="#DCDFE6"
                        :active-value="1" @change="switchChange(row)">
                    </el-switch>
                </template> </el-table-column>


            <el-table-column v-for="(item, index) in propData2" :key="index" :prop="item.prop" :label="item.label"
                :width="item.width" :formatter="item.formatter" :show-overflow-tooltip="true">


            </el-table-column>
        </el-table>
    </div>
</template>

<script>
import CommonTable from './CommonTable'
import moment from 'moment'

export default {
    data() {
        return {
            propData1: [
                {
                    prop: 'nearlineDes', label: '近线策略详情',  formatter: (e) => {
                        if (e.nearline_mode === 1 && e.nearline_of_space_ratio >= 0) return `近线至容量的${e.nearline_of_space_ratio}%`
                        if (e.nearline_mode === 0 && e.nearline_of_days >= 0) return `近线${e.nearline_of_days}天前的文件`
                        return ''
                    }, key: 10,
                },
                {
                    prop: 'nearlineTime', label: '近线执行时间', width: 150, formatter: (e) => {
                        let beginTime = ''
                        let endTime = ''

                        if (e.nearline_begin_perform_time) beginTime = moment(new Date(e.nearline_begin_perform_time)).format("HH:mm:ss")
                        if (e.nearline_end_perform_time) endTime = moment(new Date(e.nearline_end_perform_time)).format("HH:mm:ss")
                        return beginTime + '~' + endTime
                    }, key: 11,
                },

            ],
            propData2: [

                {
                    prop: 'offlineDes', label: '离线策略详情',  formatter: (e) => {
                        if (e.offline_mode === 1 && e.offline_of_space_ratio>=0) return `删除至容量的${e.offline_of_space_ratio}%，且最少保留${e.offline_save_days}天`
                        if (e.offline_mode === 0 && e.offline_of_days>=0) return `删除${e.offline_of_days}天前的文件`
                    }
                },
                {
                    prop: 'offlineTime', label: '删除执行时间', width: 150, formatter: (e) => {
                        let beginTime = ''
                        let endTime = ''
                        if (e.offline_begin_perform_time) beginTime = moment(new Date(e.offline_begin_perform_time)).format("HH:mm:ss")
                        if (e.offline_end_perform_time) endTime = moment(new Date(e.offline_end_perform_time)).format("HH:mm:ss")
                        return beginTime + '~' + endTime
                    }
                },
                { prop: 'update_user_name', label: '操作人', width: 120 },
                { prop: 'last_update_date', label: '操作时间',width: 160 },
            ],

        };
    },
    components: {

        CommonTable,
    },
    props:{
        tableData:{
            type:Array,
            default:[],
        },
        showSerial:Boolean,
    },
    //  ['tableData', 'showSerial'],
    computed: {},
    watch: {
        'tableData': {
            handler: function (val) {
                console.log('不会更新数据m/', val);
            },
            immediate: true
        }

    },
    methods: {
        switchChange(row) {
            row.nearline_enable = row.nearline_enable ? 1 : 0
            row.offline_enable = row.offline_enable ? 1 : 0

            this.$emit('switchChange', row)

        },
        editStrategy(row) {
            this.$emit('editStrategy', row)
        },
        handleSelectionChange(rows) {
            this.$emit('selectionChanged', rows)

        }

    },
}
</script>
<style lang='less' scoped></style>