<template>
  <div :class="{ noTableData: tableData.length === 0 }">
    <el-table
      border
      stripe
      :data="tableData"
      style="width: 100%"
      :default-sort="{ prop: 'date', order: 'descending' }"
      ref="multipleTable"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="60"></el-table-column>
      <el-table-column
        type="index"
        label="序号"
        fixed="left"
        width="50"
        v-if="showSerial"
      ></el-table-column>
      <el-table-column label="操作" width="60">
        <template slot-scope="scope">
          <span class="clr_0a pointer" @click="editStrategy(scope.row)"
            >编辑</span
          >
        </template>
      </el-table-column>
      <!-- <common-table :propData="propData" /> -->
      <el-table-column
        prop="org_name"
        label="机构名称"
        :show-overflow-tooltip="true"
      >
      </el-table-column>
      <el-table-column prop="is_enable" label="策略状态">
        <template slot-scope="{ row }">
          <el-switch
            v-model="row.is_enable"
            active-color="#409EFF"
            inactive-color="#DCDFE6"
            :active-value="1"
            :inactive-value="0"
            @change="switchChange(row)"
          >
          </el-switch>
        </template>
      </el-table-column>

      <el-table-column
        v-for="item in propData1"
        :key="item.index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
      >
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import CommonTable from "./CommonTable";
import moment from "moment";

const fileType = {
  1: "原始影像",
};

export default {
  data() {
    return {
      propData1: [
        {
          prop: "file_type",
          label: "文件类型",
          formatter: (e) => {
            return fileType[e.file_type];
          },
        },
        {
          prop: "mark_of_days",
          label: "标记策略详情",
          formatter: (e) => {
            if (!e.mark_of_days) {
              return ''
            }
            return `标记近${e.mark_of_days}天前的文件`;
          },
          key: 10,
        },
        { prop: "update_user_name", label: "操作人" },
        { prop: "last_update_date", label: "操作时间" },
      ],
    };
  },
  components: {
    CommonTable,
  },
  props: {
    tableData: {
      type: Array,
      default: [],
    },
    showSerial: Boolean,
  },
  computed: {},
  methods: {
    switchChange(row) {
      row.is_enable = row.is_enable ? 1 : 0;
      this.$emit("switchChange", row);
    },
    editStrategy(row) {
      this.$emit("editStrategy", row);
    },
    handleSelectionChange(rows) {
      this.$emit("selectionChanged", rows);
    },
  },
};
</script>
<style lang="less" scoped></style>
