<template>
  <div class="inspectRecord-query">
    <div class="search-bar">
      <div class="searchTop mb10">
        <div class="fl">
          <span class="search-bar-label fl">申请时间：</span>
          <div class="fl">
            <el-date-picker
              @change="search"
              class="chooseIntervalsPick searchTimePicker"
              v-model="timer"
              type="daterange"
              align="right"
              value-format="yyyy-MM-dd"
              unlink-panels
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :picker-options="pickerOptions"
            ></el-date-picker>
          </div>
        </div>


        <div class="fl ml10">
          <span class="search-bar-label fl">审批状态：</span>
          <el-select
              @change="search"
              clearable
              multiple
              collapse-tags
              v-model="searchData.states"
              placeholder=""
              class="ele-select_32 width_130_select"
              style="width:160px"
          >
            <el-option
              v-for="(item,index) in baseInfo.case_export_apply_item_state"
              :key="index"
              :label="item.name"
              :value="item.value"
              ></el-option>
          </el-select>
        </div>
        
        <div class="fl ml10 officeBox">
          <span class="search-bar-label fl">检查科室：</span>
          <el-select
              @change="search"
              filterable
              clearable
              multiple
              collapse-tags
              v-model="searchData.observations_dept_ids"
              placeholder=""
              class="ele-select_32 officeSelect"
              style="width:220px"
          >
              <el-option
                  v-for="dept in depmentlist"
                  :key="dept.office_id"
                  :label="`${dept.office_name}(${dept.institution_name})`"
                  :value="dept.office_id"
                >
                {{ dept.office_name }}( {{dept.institution_name}} )
              </el-option>

          </el-select>


          <span class="officeTip">
            <el-popover
              placement="top-start"
              title=""
              popper-class="powerDescPopover"
              width="200"
              trigger="hover"
            >
              <div>
                申请导出的检查所属科室
              </div>
              <el-button class="tipButton" slot="reference"><i class="iconfont tipIcon">&#xe720;</i></el-button>
            </el-popover>
           </span>
        </div>

        <div class="fl ml10" v-if="action == 2">
          <span class="search-bar-label fl">申请人：</span>
          <el-input class=""
            style="width:160px"
            v-on:keyup.enter.native=search
            v-model="searchData.keywords"
            placeholder="请输入申请人姓名">
          </el-input>
        </div>

        <div class="fl operateBtnDiv ml10">
          <el-button type="primary" size="small" @click="search"
            >查询</el-button
          >
          <el-button size="small" plain @click="resetSearch">重置</el-button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { getOfficesLite } from '@/api/commonHttp'
import { getUserAuditOfficeList, getAllAuthOfficeList } from "@/api/platform_costomer/caseExport";
// import { getBusinessModules } from '@/api/platform_costomer/systemOperation'
export default {
  props: {
    curRole: {
      type: String,
    },
    action: Number,
  },
  computed: {
    ...mapGetters({ // 获取store查询枚举条件
      baseInfo: 'enumerations'
    })
  },
  data() {
    return {
      timer: [],
      tenancy_id: "",
      system: "",
      pickerOptions: {
        shortcuts: [
          {
            text: "今天",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              // start.setTime(start.getTime() - 3600 * 1000 * 24 * 6);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近一周",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 6);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近一个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 29);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近三个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 89);
              picker.$emit("pick", [start, end]);
            },
          },
        ],
      },
      depmentlist: [],
      searchData: {
        start_time: "",
        end_time: "",
        states: [],
        observations_dept_ids: [],
        keywords: "",
        offset: 1,
        limit: 20,
        sorts: [],
      },
    };
  },
  methods: {
    // 重置
    resetSearch() {
      this.searchData = {
        start_time: "",
        end_time: "",
        states: [],
        observations_dept_ids: [],
        keywords: "",
        offset: 1,
        limit: 20,
        sorts: [],
      };
      this.timer = [];
      this.$emit("getList", this.searchData);
    },
    // 搜索
    search() {
      this.searchData.offset = 1;
      this.searchData.limit = 20;
      if (this.timer && this.timer.length !== 0) {
        this.searchData.start_time = this.timer[0];
        this.searchData.end_time = this.timer[1];
      } else {
        this.searchData.start_time = "";
        this.searchData.end_time = "";
      }
      this.$emit("getList", this.searchData);
    },
    // 获取科室列表
    async getOfficesLiteFn (id) {
      let res
      if (this.action == 1) {//申请端
        res = await getAllAuthOfficeList()
      } else { // 审核端  获取的是审核人 有哪些审核权限的科室列表
        res = await getUserAuditOfficeList()
      }
      if (res.code === 0) {
        this.depmentlist = res.data
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 获取审批状态列表 (读枚举)
    getCheckStatus () {

    },
  },
  created() {
    // 获取审批状态
    this.getCheckStatus()
    // 获取科室列表
    this.getOfficesLiteFn()
  },
  mounted() {
    this.search();
    if (this.$route.query.tenancy_id && this.$route.query.system) {
      this.tenancy_id = this.$route.query.tenancy_id;
      this.system = this.$route.query.system;
    }
  },
};
</script>
<style lang="less" scoped>
.ml24 {
  margin-left: 24px;
}
.addPd {
  padding: 0 7px;
}
.search-bar {
  line-height: initial !important;
}
.inspectRecord-query {
  padding: 10px 0px 0px 10px;
  .searchTop {
    min-height: 32px;
  }
  .search-bar .addPadding {
    padding: 0 9px;
  }
  .search-bar .statusLabel {
    width: 39px !important;
    min-width: 39px;
    text-align: left !important;
  }
  .search-bar-label {
    line-height: 32px;
    margin-right:0px;
  }
}
.timeTypeSelect {
  ::v-deep .el-input {
    line-height: 30px !important;
  }
}
.officeBox{
  position: relative;
  .officeTip{
    position:absolute;
    right: 28px;
    top: 6px;
  }
  .tipButton {
    padding: 0 !important;
    border: none;
    .tipIcon {
      font-size: 15px;
      color: #ff9900;
    }
  }
}
::v-deep .officeSelect{
  .el-select__tags{
    max-width: 175px!important;
  }
}
</style>
