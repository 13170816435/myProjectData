<template>
  <!-- 表格： 可通过后台返回控制table显示某列 及自定义宽度 -->
    <div>
      <template v-for="(item, index) in propData">
        <el-table-column
          v-if="item.prop == 'observations_depart_names'"
          :key="index"
          :prop="item.prop"
          :label="item.label"
          :width="item.width"
          :sortable="item.sortable"
          :render-header="item.renderHeader"
          :formatter="item.formatter"
          :show-overflow-tooltip="true"
          align="left">
          <template slot-scope="scope">
            <div
            >{{scope.row.observations_depart_names.join("、")}}</div>
          </template>
        </el-table-column>

        <el-table-column
          v-else-if="item.prop == 'office_names'"
          :key="index"
          :prop="item.prop"
          :label="item.label"
          :width="item.width"
          :sortable="item.sortable"
          :render-header="item.renderHeader"
          :formatter="item.formatter"
          :show-overflow-tooltip="true"
          align="left">
          <template slot-scope="scope">
            <div
            >{{scope.row.office_names.join("、")}}</div>
          </template>
        </el-table-column>


        

        <el-table-column
          v-else
          :key="index"
          :prop="item.prop"
          :label="item.label"
          :width="item.width"
          :sortable="item.sortable"
          :render-header="item.renderHeader"
          :formatter="item.formatter"
          :show-overflow-tooltip="true"
          align="left">
        </el-table-column>
      </template>
    </div>
  </template>
  <script>
  import mixin from '@/utils/mixin/intelligentDiagnosis'
  export default {
    name: 'CommonTable',
    props: {
      propData: Array,
      action: Number,
      systemTypeArr: Array,
      businessSystem: Array,
      allModule: Array,
      allType: Array
    },
    mixins: [mixin]
  }
  </script>
  <style lang="less">
  .clr_red{
    color:#da4a4a;
  }
  .enableStu{
    color:#00A367;
    font-size:14px;
    font-weight:400;
  }
  .stopStu{
    font-size:14px;
    font-weight:400;
    color: #da4a4a;
  }
  </style>
  