<template>
    <div class="forecastDays">

        <el-dialog title="存储域近30天容量使用情况" :visible.sync="dayDialogData.show" :before-close="forecastDaysClose" width="780px"
            top="10%" left>
            <div slot="title" class="dialog-title">
                <span class="f16 fff" style="color:white">
                    {{ alertTitle }}容量使用情况 </span>
            </div>

            <div class="chartItem">
                <div v-if="!dialogOptions" class="noDataContent">
                    <!-- <div class="line"></div> -->

                    <div class="noDataImg"></div>
                    <span> 暂无数据 </span>
                </div>
                <ChartItem v-else :option="dialogOptions" :shouldRefresh="shouldRefresh">
                </ChartItem>
            </div>
            <div slot="footer" class="dialog-footer mb10 fr">
                <el-button @click="forecastDaysClose" size="small" class="mr20">关
                    闭</el-button>
            </div>
        </el-dialog>

    </div>
</template>

<script>
import ChartItem from '../storageStatistics/components/ChartItem.vue'
import moment from 'moment'
import {
    getDaysUsage
} from '@/api/memorySharing/dataMemory'
export default {
    components: { ChartItem },
    props: {
        dayDialogData: {
            type: Object,
            require: true,
        }
    },
    data() {
        return {

            dataList: [],
            shouldRefresh: false,
            alertTitle: '存储域近30天',
            dialogOptions: {}

        };
    },
    computed: {},
    watch: {
        dayDialogData: {
            handler(val) {
                if (val) {
                    if (val.system_id) {
                        //获取 对应系统信息
                        this.alertTitle = val.system_name + '近30天'
                    }else   if (val.domain_id) {
                        //获取 存储域对应信息
                        this.alertTitle = val.domain_name + '近30天'
                    }  
                    
                    this.getDaysUsage(val.domain_id,val.system_id)
                }
            },
            immediate:true,
            deep: true,
        },
        dataList: {
            handler(val) {
                if (val && val.length > 0) {
                    this.getDialogOptions()
                }
            }
        }
    },
    methods: {
        getDialogOptions() {
            let colors = [
                "#1891FF",
                "#FBCD14",
                "#DCDFE6",
            ]
            let xNames = []
            let nearDatas = []
            let onlineDatas = []
            let totalDatas = []
            this.dataList.forEach(item => {
                let time = moment(item.start_statistic_date).format('MM/DD') + "~" + moment(item.end_statistic_date).format('MM/DD')
                xNames.push(time)
                onlineDatas.push(item.online_used_size)
                nearDatas.push(item.nearline_used_size)
                totalDatas.push(item.used_size)

            })
            
            let options = {
                textStyle: {
                    color: '#606266'
                },
                "color": colors,
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                legend: {
                    icon: 'circle',
                    textStyle: {
                        color: '#606266'
                    },
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [
                    {
                        type: 'category',
                        data: xNames,
                        axisLabel:{
                        interval:0,
                        },
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#606266',
                            }
                        }
                    }
                ],
                yAxis: [
                    {
                        name: '容量（TB）',
                        type: 'value',
                        show: true,
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#606266',
                            }
                        }
                    }
                ],
                series: [
                    {
                        barMaxWidth: 30,
                        name: '在线容量',
                        type: 'bar',
                        stack: 'Ad',
                        emphasis: {
                            focus: 'series'
                        },
                        data: onlineDatas
                    },
                    {
                        name: '近线容量',
                        type: 'bar',
                        stack: 'Ad',
                        emphasis: {
                            focus: 'series'
                        },
                        data: nearDatas
                    },
                    // {
                    //     name: '总容量',
                    //     type: 'bar',
                    //     stack: 'Ad',
                    //     emphasis: {
                    //         focus: 'series'
                    //     },
                    //     data: totalDatas
                    // }
                ]
            }
            // console.log('数据显示不对哦哦哦哦哦哦',options);
            this.dialogOptions = options
        },
        forecastDaysClose() {
            this.$emit('forecastDaysClose')

        },
        async getDaysUsage(domain_id,system_id) {
            let res = await getDaysUsage({domain_id ,system_id})

            if (res.code == 0) {
                this.dataList = res.data.reverse() || []
            } else {
                this.$message({ message: `${res.msg}`, type: 'error' })
            }
        }
    },
}
</script>
<style lang='less' scoped>
.noDataContent {
    min-width: 330px;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    // .line {
    //     height: 2px;
    //     width: 330px;
    //     // border-top: 5px dotted #000;
    //     border-top: 1px dashed #DCDFE6;
    //     background-color: white;
    //     border-radius: 0 0 5px 5px;
    // }

    .noDataImg {
        width: 120px;
        height: 80px;
        background-image: url('../../../../assets/images/dataStorage/noData.png');
        background-size: cover;
    }

    span {
        padding: 20px;
        font-size: 14px;
    }

}

.chartItem {
    height: 300px;
    background-color: white;
    border-radius: 0px 0px 5px 5px;

}
</style>