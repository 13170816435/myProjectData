<template>
  <div class="dialoginfo">
    
      <div class="search-bar flex_row mt10 ml10">
          <span>所属机构：</span>
          <el-select
            multiple
            filterable
            clearable
            collapse-tags
            v-model="searchData.institution_ids"
            placeholder="请选择"
            class="width_180_input"
            @change="changeInstitute"
          >
            <el-option
              v-for="item in institutelist"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
          <span class="ml10">所属科室：</span>
          <el-select
            multiple
            filterable
            clearable
            collapse-tags
            style="width: 180px;"
            :disabled="depmentlist.length === 0"
            v-model="searchData.office_ids"
            @change="serchListFn"
            placeholder="所属科室"
          >

            <el-option
                  v-for="dept in depmentlist"
                  :key="dept.office_id"
                  :label="`${dept.office_name}(${dept.institution_name})`"
                  :value="dept.office_id"
                >
                {{ dept.office_name }}( {{dept.institution_name}} )
              </el-option>
          </el-select>

          <el-select
            class="width_100_input ml10"
            v-model="s_type"
            filterable
            @change="searchData.keywords = ''"
          >
            <el-option label="姓名" value="1"></el-option>
            <el-option label="手机号码" value="2"></el-option>
          </el-select>
          <el-input
            class="width_140_input ml10"
            v-model="searchData.keywords"
            v-on:keyup.enter.native="serchListFn()"
            placeholder="关键字"
          ></el-input>
 
          <div class="ml10">
            <el-button type="primary" size="small" @click="serchListFn">查询</el-button>
            <el-button size="small" plain @click="resetSearchDataFn">重置</el-button>
          </div>
      </div>


    <div class="flex_row pl10">
     
      <div class="userListCon">
        <div class="tableDiv" v-bind:class="{ 'noTableData': userlist.length == 0 }">
          <el-table
            ref="CheckuserTable"
            class="mt10"
            border
            :data="userlist"
            style="width: 100%"
            height="100%"
            v-bind:row-key="getRowKeys"
            @select="selectCurRow"
            @selection-change="selectUserListFn"
            >
            <el-table-column type="selection" v-bind:reserve-selection="true" width="55"></el-table-column>
            <el-table-column prop="name" label="姓名" width="100"></el-table-column>
            <el-table-column prop="phone" label="联系电话" width="120"></el-table-column>
            <el-table-column prop="institution_name" label="所属机构" width="200"></el-table-column>
            <el-table-column prop="office_names" label="所属科室" >
              <template slot-scope="scope">
                <span v-if="scope.row.office_names && scope.row.office_names.length !=0">
                  {{scope.row.office_names.join("、")}}
                </span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="blockPage">
          <pagination-tool :layout="pageLayout" :total="totalUserCount" :page.sync="searchData.offset" :limit.sync="searchData.limit" @pagination="beganGetCurTenancyAllCheckUserList" />
        </div>
      </div>
      

      <div class="checksuer">
        <div class="clr_333 lh32">已选人员：</div>
        <div>
          <div class="checksueritem" v-for="item in checkeduser" :key="item.id">
            <span>{{item.name}} <span v-if="item.phone">({{item.phone}})</span></span>
            <span class="delMeal fr" v-on:click="del(item.id)">
              <i class="iconfont">&#xe63a;</i>
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import PaginationTool from '@/components/common/PaginationTool'
import { getInstitutionListLite, getOfficesLite } from '@/api/commonHttp'
import { UnshiftToArray } from '@/components/commonJs'
import { getCurTenancyAllCheckUserList } from "@/api/platform_costomer/caseExport";
export default {
  components: {
    PaginationTool
  },
  props: {
    deptOptions: Object,
  },
  data () {
    return {
      isIndeterminate: true,
      checkAll: false,
      pageLayout: 'total, prev, pager, next, jumper',
      institutelist: [],
      depmentlist: [],
      s_type: "1",
      searchData: {
        institution_ids: '',
        office_ids: '',
        keywords: '',
        offset: 1,
        limit: 20,
      },
      totalUserCount: 0,
      userlist: [],
      checkeduser: [],
    }
  },
  mounted () {
    // const self = this
    // self.$nextTick(() => {
    //   self.$refs.CheckuserTable.toggleRowSelection(self.userlist[2], true)
    // })
  },
  methods: {
    checkedTableTr () {
      const self = this
      let ids  = []
      if (self.checkeduser.length !== 0) {
        self.checkeduser.forEach((val) => {
          ids.push(val.id)
        })
      }
      self.$nextTick(() => {
      self.userlist.forEach((item) => {
        if (ids.indexOf(item.id) !== -1) {
          self.$refs.CheckuserTable.toggleRowSelection(item, true) 
        } else {
          self.$refs.CheckuserTable.toggleRowSelection(item, false)
        }
       })
      })
    },
    getRowKeys (row) {
      return row.id
    },
    // 选中某一行
    selectCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.checkeduser.forEach((item, i) => {
          if (item.id === row.id) {
            self.checkeduser.splice(i, 1);
          }
        });
      }
    },
    // 去掉数组元素 里面对象 id值相同的
    clearCommonId(arr) {
      let obj = {};
      let peon = arr.reduce((cur, next) => {
        obj[next.id] ? "" : (obj[next.id] = true && cur.push(next));
        return cur;
      }, []);
      return peon;
    },
    // 机构 select change事件
    selectUserListFn(val) {
      const self = this;
      val.forEach((item) => {
        self.checkeduser.push(item);
      });
      self.checkeduser = self.clearCommonId(
        self.checkeduser
      );
    },
    del (id) {
      const self = this;
      self.userlist.forEach((one) => {
        if (one.id === id) {
          self.$refs.CheckuserTable.toggleRowSelection(one, false);
        }
      });
      self.checkeduser.forEach((item, i) => {
        if (item.id === id) {
          self.checkeduser.splice(i, 1);
        }
      });
    },
    Institutionchagen (val) {
      this.$emit('Institutionchagen', val)
    },
    // 获取机构列表
    async getInstitutionListLiteFn() {
      const res = await getInstitutionListLite();
      if (res.code === 0) {
        this.institutelist = UnshiftToArray(res.data);
      } else {
        this.$message.error(res.msg);
      }
    },
    // 搜索用户
    changeInstitute (val) {
      const self = this
      self.serchListFn()
     // self.getOfficesLiteFn(val)
     
      self.depmentlist = []
      if (self.searchData.institution_ids.length != 0) {
        self.searchData.institution_ids.forEach(deptId => {
          self.depmentlist = self.depmentlist.concat(self.deptOptions[deptId] || []);
        });
      }

    },
    // 获取科室列表
    async getOfficesLiteFn(id) {
      var _url = "/offices/lite?institution_id=" + id;
      const res = await getOfficesLite(_url);
      if (res.code === 0) {
        this.depmentlist = UnshiftToArray(res.data); // 这个是用户列表上面查询条件里面的 科室列表
      } else {
        this.$message.error(res.msg);
      }
    },
    // 获取客户下的所有用户
    async beganGetCurTenancyAllCheckUserList () {
      const res = await getCurTenancyAllCheckUserList(this.searchData);
      if (res.code === 0) {
        this.userlist = res.data
        this.totalUserCount = res.page.total_count || 0;
        // 处理勾选过的 用户
        this.checkedTableTr()
      } else {
        this.$message.error(res.msg);
      }
    },
    // 重置查询条件
    resetSearchDataFn () {
      this.s_type = this.$options.data().s_type;
      this.searchData = this.$options.data().searchData;
      this.beganGetCurTenancyAllCheckUserList();
    },
    // 搜索机构成员
    serchListFn() {
      this.searchData.offset = 1
      this.searchData.limit = 10
      this.beganGetCurTenancyAllCheckUserList()
    },
    async initData () {
      // 获取机构列表
      await this.getInstitutionListLiteFn()
      // 获取用户列表
      await this.beganGetCurTenancyAllCheckUserList()
      // 处理勾选过的 用户
      this.checkedTableTr()
    }
  }
}
</script>

<style lang="less" scoped>
.checkalltab{
  height: 350px;
  border:1px solid rgba(220, 223, 230, 1)
}
.checkalltab_title{
  height:40px;
  line-height: 40px;
  padding: 0px 10px;
  background:rgba(249,249,249,1);
  border-bottom:1px solid rgba(220, 223, 230, 1);
}
.checkalltab_list{
  height: 300px;
  overflow-y: scroll;
}
.w_340{
  width: 340px;
}
// 权限信息
.checkbox_group{
  min-width: 18%;
  margin-bottom: 10px;
}
.userListCon{
  width:calc(100% - 210px);
}
.checksuer{
  width: 210px;
  padding: 10px;
  padding-top: 0;
  height:calc(100% - 20px);
  overflow:auto;
}
.checksueritem{
  width: 100%;
  line-height: 30px;
  padding: 0px 10px;
  background: #E6F3FF;
  border-radius: 4px;
  margin-bottom: 10px;
  cursor: pointer;
}
.checksueritem:hover .delMeal{
  display: block;
}
.delMeal{
  display: none;
}
.h500{
  height: 500px;
}
.operatebtn{
  padding: 0px 15px;
  height:32px;
  line-height: 32px;
  background:rgba(10,112,176,1);
  border:1px solid rgba(10, 112, 176, 1);
  border-radius:4px;
  color: #fff;
  margin-left: 38%;
}
::v-deep .tableDiv{
  height:400px;
  .el-table__body-wrapper{
    height:calc(100% - 40px);
    overflow-y: auto;
  }
}
</style>
