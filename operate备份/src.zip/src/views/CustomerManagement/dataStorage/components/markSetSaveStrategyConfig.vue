<style lang="less" scoped>
.dialog_content {
  white-space: pre-wrap;
}
.mr108 {
  margin-right: 108px;
}

.w260 {
  width: 260px;
}

.strategy_way {
}

.strategy_cls {
  ::v-deep .el-dialog__body {
    padding: 17px 30px 41px 30px !important;
  }

  ::v-deep .el-form-item__label,
  .el-form-item__content {
    line-height: 35px;
  }

  ::v-deep.el-form-item__label {
    padding-right: 0;
  }

  .el-radio {
    margin-right: 0;
  }

  ::v-deep.el-dialog__header {
    // height: 50px;
    line-height: 40px;
  }
}

.warningDiv {
  color: rgba(239, 137, 0, 1);
}

::v-deep .white-head .el-dialog__header {
  background-color: white;
  color: #2b354a;
}
</style>
<style lang="less">
.el-message-box {
  width: 500px;

  .el-message-box__title {
    justify-content: flex-start;

    span {
      font-size: 16px !important;
      font-weight: bold;
    }
  }

  .el-message-box__message {
    text-align: left !important;

    strong {
      font-size: 18px;
    }

    span {
      font-size: 15px;
    }
  }

  .el-message-box__btns {
    text-align: right !important;
  }
}
</style>
<template>
  <div>
    <div class="strategy_cls">
      <el-dialog
        title="标记策略设置"
        :visible.sync="SetSaveStrategyShow"
        :before-close="SetSaveStrategyClose"
        width="600px"
        top="3%"
        left
      >
        <div class="">
          <div class="of">
            <el-form
              class="of"
              label-position="right"
              :model="markSaveStrategyData"
              ref="markSaveStrategyDataForm"
              style="height: 180px; overflow-y: auto"
            >
              <div class="of fl pb10 w100">
                <div class="f18 mb20 mt10 clr_333">
                  <span class="mr20">标记策略</span>
                  <el-switch
                    v-model="markSaveStrategyData.is_enable"
                    :active-value="1"
                    :inactive-value="0"
                  >
                  </el-switch>
                </div>
                <div class="w100 mt10 clear_fixed">
                  <el-form-item
                    label="标记指定天数前的文件："
                    class="w_316 dib mr108"
                  >
                    <el-input-number
                      style="width: 100px"
                      size="medium"
                      v-model="markSaveStrategyData.mark_of_days"
                      controls-position="right"
                      :min="1"
                      @change="
                        (currentValue, oldValue, label) =>
                          daysIptNumChange(
                            currentValue,
                            oldValue,
                            'mark_of_days'
                          )
                      "
                    ></el-input-number>
                    <span class="ml10">天</span>
                  </el-form-item>
                  <br />
                  <el-form-item label="文件类型：" class="w_316 dib mr108">
                    <el-select
                      class="ele-select_32 width_280_select"
                      style="width: 180px"
                      v-model="markSaveStrategyData.file_type"
                      placeholder="请选择"
                    >
                      <el-option
                        v-for="(item, index) in fileTypes"
                        :key="index"
                        :label="item.name"
                        :value="item.code"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </div>
              </div>
            </el-form>
          </div>
        </div>

        <div slot="footer" class="dialog-footer mb10 fr">
          <el-button @click="SetSaveStrategyClose" size="small" class="mr20"
            >关 闭</el-button
          >
          <el-button
            type="primary"
            @click="ValidationStrategyRules"
            size="small"
            >保 存</el-button
          >
        </div>
      </el-dialog>
    </div>

    <div class="">
      <el-dialog
        title="提示"
        v-if="innerVisible"
        :visible.sync="innerVisible"
        width="680px"
        :show-close="false"
        :before-close="handleClose"
        @opened="openedAlertContent"
      >
        <div id="alert_content" class="dialog_content f16 ml15 mr15 mt20 mb20">
          {{ dialogContent }}
        </div>
        <div v-show="dialogTable.length" style="padding: 10px">
          <el-table :data="dialogTable" border>
            <el-table-column
              type="index"
              label="序号"
              width="60"
            ></el-table-column>
            <el-table-column prop="org_name" label="机构名称"></el-table-column>
            <el-table-column prop="index" label="近线策略状态">
              <template slot-scope="scope">
                {{ scope.row.nearline_enable ? "已开启" : "未开启" }}
              </template>
            </el-table-column>
            <el-table-column prop="index" label="近线策略参数值">
              <template slot-scope="scope">
                <span :class="{ clr_red: lineModel == 1 }"
                  >{{ scope.row.nearline_of_days }}天</span
                >
              </template>
            </el-table-column>
            <el-table-column prop="index" label="离线策略状态">
              <template slot-scope="scope">
                {{ scope.row.offline_enable ? "已开启" : "未开启" }}
              </template>
            </el-table-column>
            <el-table-column prop="index" label="离线策略参数值">
              <template slot-scope="scope">
                <span :class="{ clr_red: lineModel == 2 }"
                  >{{ scope.row.offline_of_days }}天</span
                >
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div slot="footer" class="dialog-footer">
          <!-- canSave -->
          <el-button v-if="!canSave" @click="innerVisible = false"
            >关 闭</el-button
          >

          <el-button v-if="canSave" @click="innerVisible = false"
            >取 消</el-button
          >
          <el-button v-if="canSave" type="primary" @click="updateSaveStrategy">
            确 定</el-button
          >
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import { updateMarkstrategies } from "@/api/memorySharing/dataMemory";
export default {
  data() {
    return {
      //20230222评审
      /**
       * 默认值：
       * 近线：执行时间22:00-06:00  360天 80
       * 离线：执行时间 22:00-06:00   730天 90 90天
       */
      fileTypes: [{ name: "原始影像", code: "1" }],

      markSaveStrategyData: {
        domain_id: 0,
        is_enable: 0,
        mark_of_days: 90,
        file_type: "1",
      },

      canSave: false,
      innerVisible: false,
      innerAlertHTML: "",
      dialogContent: "",
      dialogTable: [],
      lineModel: "", // 1-近线 2-离线
    };
  },

  watch: {
    // 选择的数据
    configStrategyDatas(data) {
      if (data && data.length == 1) {
        let obj = data[0];
        this.markSaveStrategyData.domain_id = obj.domain_id;
        this.markSaveStrategyData.is_enable = obj.is_enable;
        this.markSaveStrategyData.mark_of_days = obj.mark_of_days ?? 90;
        this.markSaveStrategyData.file_type = obj.file_type ?? "1";
      }
    },
  },
  props: ["configStrategyDatas", "SetSaveStrategyShow", "StrategyData"],
  methods: {
    // 关闭弹窗
    SetSaveStrategyClose(shouldRefresh) {
      this.$emit("SetSaveStrategyClose", shouldRefresh);
    },

    openedAlertContent() {
      let divDocument = document.getElementById("alert_content");
      divDocument.innerHTML = this.innerAlertHTML;
    },

    // 验证
    ValidationStrategyRules() {
      this.dialogTable = [];
      // 未启用直接保存
      if (!this.markSaveStrategyData.is_enable) {
        this.updateSaveStrategy();
        return;
      }

      // 存储策略为按整体配置
      if (this.StrategyData.strategy_type == 0) {
        let strategy = this.StrategyData.storage_strategies[0];
        if (
          (strategy.nearline_enable && this.StrategyData.nearline_mode == 1) ||
          (strategy.offline_enable && this.StrategyData.offline_enable == 1)
        ) {
          this.dialogContent = `存储域的存储策略为按容量时，不允许开启标记策略！`;
          this.canSave = false;
          this.innerVisible = true;
          return;
        }

        if (
          strategy.offline_enable &&
          strategy.offline_mode === 0 &&
          this.markSaveStrategyData.mark_of_days >= strategy.offline_of_days
        ) {
          this.dialogContent = `【标记策略】的参数值大于【离线策略】的参数值${strategy.offline_of_days}天，将导致文件先被离线，后被标记删除，不允许配置，请确保【标记策略】的参数值小于【离线策略】的参数值！`;
          this.canSave = false;
          this.innerVisible = true;
          this.lineModel = 2;
          return;
        }

        if (
          strategy.nearline_enable &&
          strategy.nearline_mode === 0 &&
          this.markSaveStrategyData.mark_of_days >= strategy.nearline_of_days
        ) {
          this.dialogContent = `【标记策略】的参数值大于【近线策略】的参数值${strategy.nearline_of_days}天，将导致文件先被近线，后被标记删除，请确认！`;
          this.canSave = true;
          this.innerVisible = true;
          this.lineModel = 1;
          return;
        }

        // 保存配置
        this.updateSaveStrategy();
        return;
      }

      // 存储策略为单独配置 1-按系统配置 2-按机构配置
      if (this.StrategyData.strategy_type != 0) {
        let capacityList = [];
        let offlineList = [];
        let nearlineList = [];
        this.configStrategyDatas.forEach((item) => {
          let strategy = this.StrategyData.storage_strategies.find((sto) => {
            return (
              sto.system_id == item.system_id && sto.org_code == item.org_code
            );
          });

          if (strategy) {
            if (
              (strategy.nearline_enable &&
                this.StrategyData.nearline_mode == 1) ||
              (strategy.offline_enable && this.StrategyData.offline_enable == 1)
            ) {
              capacityList.push(item);
            }

            if (
              strategy.offline_enable &&
              strategy.offline_mode === 0 &&
              this.markSaveStrategyData.mark_of_days >= strategy.offline_of_days
            ) {
              offlineList.push(item);
              this.dialogTable.push(strategy);
            }

            if (
              strategy.nearline_enable &&
              strategy.nearline_mode === 0 &&
              this.markSaveStrategyData.mark_of_days >=
                strategy.nearline_of_days
            ) {
              nearlineList.push(item);
              this.dialogTable.push(strategy);
            }
          }
        });

        this.dialogTable = [
          ...new Set(this.dialogTable.map((item) => JSON.stringify(item))),
        ].map((item) => JSON.parse(item));

        if (capacityList.length) {
          let orgNams = capacityList.map((item) => {
            return item.org_name;
          });
          this.dialogContent = `所属存储域的存储策略为按容量时，不允许开启标记策略！`;
          this.canSave = false;
          this.innerVisible = true;
          return;
        }

        if (offlineList.length) {
          this.dialogContent = `【标记策略】的参数值大于【离线策略】的参数值，将导致文件先被离线，后被标记删除，不允许配置，请确保【标记策略】的参数值小于【离线策略】的参数值！`;
          this.canSave = false;
          this.innerVisible = true;
          this.lineModel = 2;
          return;
        }

        if (nearlineList.length) {
          this.dialogContent = `【标记策略】的参数值大于【近线策略】的参数值，将导致文件先被近线，后被标记删除，请确认！`;
          this.canSave = true;
          this.innerVisible = true;
          this.lineModel = 1;
          return;
        }

        // 保存配置
        this.updateSaveStrategy();
      }
    },

    // 保存接口
    async updateSaveStrategy() {
      if (this.markSaveStrategyData.is_enable instanceof Boolean) {
        this.markSaveStrategyData.is_enable = this.markSaveStrategyData
          .is_enable
          ? 1
          : 0;
      }

      this.markSaveStrategyData.mark_type = 1;

      let params = [];
      this.configStrategyDatas.forEach((item) => {
        let obj = { ...item };
        obj = Object.assign({}, obj, this.markSaveStrategyData);
        params.push(obj);
      });

      const res = await updateMarkstrategies(params);
      const { code, msg } = res;
      if (code === 0) {
        this.innerVisible = false;
        this.SetSaveStrategyClose(true);
        this.$message.success(msg);

        this.configStrategyDatas.forEach((item) => {
          item.is_enable = this.markSaveStrategyData.is_enable;
          item.mark_type = this.markSaveStrategyData.mark_type;
          item.mark_of_days = this.markSaveStrategyData.mark_of_days;
        });
      } else {
        this.innerVisible = false;
        this.$message.error(msg);
      }
    },

    daysIptNumChange(currentValue, oldValue, label) {
      if (currentValue === undefined) {
        this.$nextTick(() => {
          this.markSaveStrategyData[label] = 1;
        });
      } else if (!Number.isInteger(currentValue)) {
        this.$nextTick(() => {
          this.markSaveStrategyData[label] = parseInt(currentValue);
        });
      }
    },

    handleClose() {},
  },
};
</script>
