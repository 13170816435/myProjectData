<template>
  <div class="finishCon">
    <div class="logItem">
      <span class="logLabel fl"
        ><i class="iconfont iconbitian mustIcon"></i>审批不通过原因：</span
      >
      <el-input
        class="clear fl auditTextarea"
        type="textarea"
        :resize="'none'"
        maxlength="100"
        placeholder="请输入审批不通过原因……"
        show-word-limit
        v-model="caseCheckNoPassParam.reason"
      ></el-input>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    caseCheckNoPassParam: {
      type: Object,
    },
  },
};
</script>
<style lang="less" scoped>
.finishCon {
  padding: 10px 20px 10px 20px;
  .logItem::after {
    content: "";
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  ::v-deep .logItem {
    clear: both;
    margin-bottom: 10px;
    .logLabel {
      // width: 110px;
      text-align: right;
      font-size: 15px;
      color: #303133;
      height: 36px;
      line-height: 36px;
    }
    .auditTextarea {
      width: 460px;
      height: 120px;
      .el-textarea__inner {
        height: 120px;
      }
    }
  }
}
</style>