<template>
  <div class="recordDetail" id="recordDetail">
    <div class="recordDetail-title">
      <span class="recordDetail-titleinfo">病例导出审批</span>
      <span @click="closeFn" class="close-btn iconfont iconchuangjianshibai"></span>
    </div>
    <div class="contaner">
      <div class="contaner-info">
        <div class="caseImport">
          <div class="caseImportLeft">
            <span class="statuLabel">已选中：<span class="caseNum">{{choosedTableData.length}}</span></span>
          </div>
          <div class="caseImportRight">
            <span class="statuLabel">总量：<span class="caseNum">{{allData.length}}</span></span>
            <span class="statuLabel ml10">已通过：<span class="caseNum passCheckNum">{{checkPassCount}}</span></span>
            <span class="statuLabel ml10">不通过：<span class="caseNum noPassCheckNum">{{checkNoPassCount}}</span></span>
            <el-input
              size="small"
              class="productSearchInput w260 ml10"
              v-model="searchCaseParam.keywords"
              v-on:keyup.enter.native="searchCaseList()"
              placeholder="全局检索"
            >
              <i slot="suffix" class="el-icon-search" @click.stop="searchCaseList()"></i>
            </el-input>
          </div>
        </div>
        
        <div
          class="allInspect clear"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          v-bind:class="{ noTableData: tableData.length == 0 }"
        >
          <el-table
            :data="tableData"
            border
            stripe
            height="100%"
            ref="caseDetailTable"
            highlight-current-row
            header-row-class-name="strong"
            :row-key="rowKey"
            @selection-change="handleSelectionChange"
            @sort-change="sortChange"
          >
            <el-table-column type="selection" v-bind:reserve-selection="true" :selectable='selectEnable' width="48"></el-table-column>
            <el-table-column
              fixed="left"
              align="center"
              type="index"
              label="序号"
              width="55"
            >
            </el-table-column>
            <el-table-column label="状态" prop="status" width="80" fixed="left">
              <template slot-scope="scope">
              <!----	状态(-2：已拒绝 -1：已取消 0：待审批 1：已同意 )-->
                <span class="tableStatuLabel " :class="{'waitCheckNum': scope.row.state == 0, 'passCheckNum': scope.row.state == 1,'noPassCheckNum': (scope.row.state == -1 || scope.row.state == -2)}"
                >{{scope.row.state_desc}}</span>
              </template>
            </el-table-column>
            <el-table-column label="查看" width="90" fixed="left">
              <template slot-scope="scope">
                <span class="clr_0a pointer" :class="{'noReport': !scope.row.has_report }" @click="watchReport(scope.row)">报告</span>
                <span class="clr_0a pointer pl10" :class="{'noImage': !scope.row.has_image }" @click="watchImg(scope.row)">影像</span>
              </template>
            </el-table-column>
            
          <el-table-column
            label="检查号"
            prop="accession_number"
            width="100"
            show-overflow-tooltip>
          </el-table-column>

          <el-table-column
            label="病例号"
            prop="med_rec_no"
            width="100"
            show-overflow-tooltip
          >
          </el-table-column>

          <el-table-column
            label="患者姓名"
            prop="patient_name"
            width="90"
            show-overflow-tooltip
          >
          </el-table-column>

          <el-table-column label="检查科室" prop="observations_depart_name" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="检查项目" prop="exam_item" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="项目分类" prop="exam_item_category" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="患者类型" prop="patient_type" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="检查时间" prop="exam_time" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="申请科室" prop="request_dept_name" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="检查机构" prop="observations_org_name" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="原因" prop="reason" width="160" show-overflow-tooltip></el-table-column>
          <el-table-column label="审批" prop="reviewer_name"  show-overflow-tooltip></el-table-column>
         </el-table>
          
        </div>
        
        <!------>
        <div class="operateCaseBtn">
          <span class="userListoperate-btn clr_ff bg_0a mr15" @click="importOutCase"><i class="iconfont icondaochu mr5"></i>导出</span>
          <span class="userListoperate-btn cancelBtn" @click="cancelApply">取消</span>
        </div>
      </div>
    </div>

    <div class="checkPeople">
      <div class="importTip">
          <span class="headIcon"></span>
          <span class="importTipTit">审批流程</span>
       </div>
       <div class="checkProcess">
          <div class="startProcess">
            <div class="startProcessLeft">
              <img src="@/assets/images/dataStorage/checkUser.png" alt="">
              <i class="iconfont icontianjia"></i>
            </div>
            <div class="startProcessRight">
              <div class="startProcessRightHead"><span class="processFirstStep">{{processArr.length != 0 && processArr[0].operate_type_desc}}</span><span class="importReason firstReason" :title="`导出原因:${processArr.length != 0 ? processArr[0].reason : ''}`">导出原因：{{processArr.length != 0 && processArr[0].reason}}</span></div>
              <div class="startProcessRightBottom"><span class="userName">{{processArr.length != 0 && processArr[0].operate_name}}</span>
                <!-- <span class="officeName">_内科</span> -->
                <span class="beganTime ml5">{{processArr.length != 0 && processArr[0].create_time}}</span></div>
            </div>
          </div>
          <img v-if="processArr.length > 1" class="arrowDownImg" src="@/assets/images/dataStorage/arrowDown.png" alt="">
          <!---其它审批流程-->
          <div class="otherProcess">
            <div class="oneProcess" v-for="(item,index) in processArr"  :key="index" v-if="index != 0">
              <div class="startProcess">
                <div class="startProcessLeft">
                  <img src="@/assets/images/dataStorage/checkUser.png" alt="">
                  <i class="iconfont iconzhengchang statusIcon" v-if="item.operate_type === 1"></i>
                  <i class="iconfont iconzhuxiao statusIcon" v-if="item.operate_type === -2 || item.operate_type === -1"></i>
                </div>
                <div class="startProcessRight">


                  <!---operate_type // 已通过 1  待审核 0  已取消 -1  不通过-2--->
                  <div class="startProcessRightHead">
                    <span class="processFirstStep passStatus" v-if="item.operate_type === 1">{{item.operate_type_desc}}({{item.operate_count}})</span>
                    <span class="processFirstStep noPassStatus" v-if="item.operate_type === -2">{{item.operate_type_desc}}({{item.operate_count}})</span>
                    <span class="processFirstStep cancelStatus" v-if="item.operate_type === -1">{{item.operate_type_desc}}({{item.operate_count}})</span>
                    <span class="importReason" v-if="item.reason" :title="`原因：${item.reason}`">原因：{{item.reason}}</span>
                  </div>
                  
                  <div class="startProcessRightBottom">
                    <span class="userName" v-if="item.operate_name">{{item.operate_name}}</span>
                    <!-- <span class="officeName" v-if="item.officeName">_内科</span> -->
                    <span class="beganTime" :class="{'ml5':item.operate_name}">{{item.create_time}}</span>
                  </div>
                </div>
              </div>
               <img class="arrowRightImg mr5 ml5" v-if="index != processArr.length- 1" src="@/assets/images/dataStorage/arrowRight.png" alt="">
             </div>
          </div>

       </div>
    </div>

    <!--取消申请-->
    <el-dialog
      title="取消申请"
      class="cancelApply"
      :visible.sync="showCancelApplyAlert"
      width="500px"
      :close-on-click-modal="false"
      append-to-body
      v-dialogDrag
    >
      <caseCancelApplyAlert :cancelApplyParam="cancelApplyParam"></caseCancelApplyAlert>
      <div class="dialog_footer">
        <el-button size="small" plain @click="showCancelApplyAlert = false"
          >取消</el-button
        >
        <el-button type="primary" size="small" @click="sureCancelApply"
          >确定</el-button
        >
      </div>
    </el-dialog>


  </div>
</template>
<script>
import caseMixin from '../caseMixin/case'
import caseCancelApplyAlert from './caseCancelApplyAlert'
import { getServiceOrderAllDetail, getServiceOrderImg } from '@/api/commonHttp'
import { getCaseExportListByApplyId, getCaseExportApplyLogs, exportCancelAudit, importInspect, getImportImgCount } from "@/api/platform_costomer/caseExport";
export default {
  props: {
    action: {
      type: Number
    }
  },
  components: {
    caseCancelApplyAlert
  },
  mixins: [caseMixin],
  data () {
    return {
      curApplyId: '',
      searchCaseParam: {
        keywords: '',
        sort: '',
        order_by: '',
      },
      tableData: [],
      checkPassCount: 0,// 审核通过的数量
      checkNoPassCount: 0,//审核不通过的数量
      allData: [],
      choosedTableData: [],
      processArr: [
        // {
        //   status: 0,
        //   userName: '',
        //   officeName: ''
        // },
        // {
        //   status: 1,
        //   userName: '',
        //   officeName: ''
        // },
        // {
        //   status: 2,
        //   userName: '王五',
        //   officeName: '外科'
        // },
        // {
        //   status: 2,
        //   userName: '还好',
        //   officeName: '内科'
        // },
        // {
        //   status: 2,
        //   userName: '',
        //   officeName: ''
        // },
        // {
        //   status: 2,
        //   userName: '',
        //   officeName: ''
        // },
      ],
      showCancelApplyAlert:false,
      cancelApplyParam: {
        apply_id: '',
        item_ids: [],
        reason: '',// 取消原因
      },
      importImgCount: 10,
    }
  },
  methods: {
    // 点击表格上面的排序
    sortChange (sort) {
      // console.log(sort)
      this.searchData.sort = ''
      this.searchData.order_by = ''
      if (sort.order === 'descending') {
        if (sort.prop  == 'file_size' || sort.prop == 'study_count') {
          this.searchData.order_by =  sort.prop
        }
        this.searchData.sort = 'desc'
      } else {
        if (sort.order) {
          if (sort.prop  == 'file_size' || sort.prop == 'study_count') {
            this.searchData.order_by =  sort.prop
          }
          this.searchData.sort = 'asc'
        }
      }
      this.getImageDataStatistics()
    },
    // 全局搜索
    searchCaseList () {
      const self = this
      self.tableData = []
      if (self.searchCaseParam.keywords === '') {
        self.tableData = JSON.parse(JSON.stringify(self.allData))
      } else {
        self.allData.forEach((item)=> {
          for(let key in item){
            if (item[key] && JSON.stringify(item[key]).indexOf(self.searchCaseParam.keywords) != -1) {
              self.tableData.push(item)
              break
            }
          }
        })
      }
    },
    // 表格选中
    handleSelectionChange (arr) {
      this.choosedTableData = arr
    },
    rowKey (row) {
      return row.id
    },
    selectEnable(row) {
      // 待审批的 然后当前登录人没有审批权限
      // if (row.is_audit && row.state != -2 && row.state != -1) {// 已取消和已拒绝的不允许勾选
      //   return true
      // }

      if (row.state != -2 && row.state != -1) {// 已取消和已拒绝的不允许勾选
        return true
      }
    },
    // 报告浏览
    watchReport (row) {
      if (!row.has_report) {
        return false
      }
      this.getReportUrl(row)
    },
    // 查看影像
    watchImg (row) {
      if (!row.has_image) {
        return false
      }
      this.getViewUrl(row)
    },
    verifyChooseTable () {
      if (this.choosedTableData.length == 0) {
        this.$message({ message: "请至少选择一条检查", type: "error" });
        return false; 
      }
      // if (this.choosedTableData.length > this.importImgCount) {
      //   this.$message({ message: `只允许选择${this.importImgCount}条检查,可以去导出管理界面下修改导出配置`, type: "error" });
      //   return false; 
      // }
      return true
    },
    // 取消
    cancelApply () {
      const self = this
      if (self.verifyChooseTable()) {
        self.cancelApplyParam.reason = ''
        self.cancelApplyParam.item_ids = []
        self.showCancelApplyAlert = true
      }
    },
    // 重置数据
    resetData () {
      const self = this
      self.searchCaseParam.keywords = ''
      self.$nextTick(() => {
        self.$refs.caseDetailTable.clearSelection()
      })
    },
    // 确定取消申请
    async sureCancelApply () {
      const self = this
      if (self.cancelApplyParam.reason == '') {
        this.$message({ message: "请输入取消申请的原因", type: "error" });
        return false;
      }
      self.choosedTableData.forEach((item)=>{
        if (item.state == 0) { // 待审批
          self.cancelApplyParam.item_ids.push(item.id)
        }
      })
      const res = await exportCancelAudit(self.cancelApplyParam)
      if (res.code === 0) {
        self.showCancelApplyAlert = false
        self.$message.success("取消申请成功")
        // 重新获取导出列表
        self.getCaseExportListByApplyId(this.cancelApplyParam.apply_id)
        self.$nextTick(() => {
          self.$refs.caseDetailTable.clearSelection()
        })
      } else{
        self.$message.error(res.msg)
      }
    },
    // 导出
    importOutCase () {
      const self = this
      let noCheckPassArr = [] // 待审批的
      let noImageArr = [] // 没有影像的
      if (self.verifyChooseTable()) {
        // 选择的数据里面 包含没有审核通过的
        self.choosedTableData.forEach((item) => {
          if (item.state != 1 && item.state != 2) { // 说明有 审核未通过的 不允许直接导出
            noCheckPassArr.push(item.accession_number)
          }
          if (!item.has_image)  {
            noImageArr.push(item.accession_number)
          }
        })
        
        
        if (noCheckPassArr.length != 0 && noImageArr.length == 0) { // 都有影像 但是有未审核通过的

          const patientIdStr = noCheckPassArr.join('、')
          this.$confirm(
            '当前选中'+self.choosedTableData.length+'条记录中的 <span style="color: #0099ff;padding-right:5px;">' +
            patientIdStr + 
            "</span> "+noCheckPassArr.length +" 条记录审批未通过," +
            "暂时不能导出",
          "提示",
          {
            confirmButtonText: "确认并导出其它",
            cancelButtonText: "取消",
            dangerouslyUseHTMLString: true,
            type: "warning",
          }
        )
        .then(() => {
          self.beganImportOut()
        })
        .catch(() => {});
        }  else if (noCheckPassArr.length == 0 && noImageArr.length != 0) {// 都审批通过了但是没有影像
        
            const patientIdStr = noImageArr.join('、')
            this.$confirm(
            
              '当前选中'+self.choosedTableData.length+'条记录中的 <span style="color: #0099ff;padding-right:5px;">' +
            patientIdStr + 
            "</span> "+noImageArr.length +" 条记录已经无影像文件," +
            "暂时不能导出",
            "提示",
            {
              confirmButtonText: "确认并导出其它",
              cancelButtonText: "取消",
              dangerouslyUseHTMLString: true,
              type: "warning",
            }
          )
          .then(() => {
            self.beganImportOut()
          })
          .catch(() => {});
        } else if (noCheckPassArr.length != 0 && noImageArr.length != 0) { // 既有未通过的 也存在没有影像的
          
            const noCheckPatientIdStr = noCheckPassArr.join('、')
            const patientIdStr = noImageArr.join('、')
            this.$confirm(
                '当前选中'+self.choosedTableData.length+'条记录中的 <span style="color: #0099ff;padding-right:5px;">' +
                  noCheckPatientIdStr + 
            "</span> "+noCheckPassArr.length +" 条记录审批未通过," +
            "暂时不能导出<br/>"+ 

                '当前选中'+self.choosedTableData.length+'条记录中的 <span style="color: #0099ff;padding-right:5px;">' +
              patientIdStr + 
              "</span> "+noImageArr.length +" 条记录已经无影像文件," +
              "暂时不能导出",
              "提示",
              {
                confirmButtonText: "确认并导出其它",
                cancelButtonText: "取消",
                dangerouslyUseHTMLString: true,
                type: "warning",
              }
            )
            .then(() => {
              self.beganImportOut()
            })
            .catch(() => {});

        }
        
        else { // 说明选的 既全部是通过的 也全部都有影像文件
          self.beganImportOut()
        }
      }
    },
    // 开始导出
    async beganImportOut () {
      const self = this
      const loading = self.$loading({
        lock: true,
        text: "正在导出，请稍等...",
        spinner: 'el-icon-loading',
        background: 'rgba(255, 255, 255, 0.6)'
      })
      const importParams = {
        dto_list: [],
        batch_count: self.importImgCount
      }
      importParams.dto_list = []
      self.choosedTableData.forEach((item) => {
        if (item.state == 1 && item.has_image) { // 审核通过（自动通过）的 允许导出
          importParams.dto_list.push(
            { 
              business_id:item.idcas_id,
              patient_id: item.patient_id,
              patient_name: item.patient_id+ "_" + item.patient_name,
              accession_number: item.accession_number,
              system_id:item.business_system_id,
              org_id: item.institution_id,
              org_code: item.institution_code,
            }
          )
        }
      })
      self.closeFn()
      self.caseImportOut(importParams,loading)
    },
    // 显示所有
    showAll ($event) {
      if ($event.target.scrollHeight > $event.target.clientHeight) {
        // $event.target.classList.remove('showMoreLineAfter')
        $event.target.classList.remove('moreLineAfter')
        $event.target.classList.add('moreLineShowAll')
      } else {
        $event.target.classList.remove('moreLineShowAll')
        // $event.target.classList.add('showMoreLineAfter')
        $event.target.classList.add('moreLineAfter')
      }
    },
    closeFn () {
      this.$emit('closeFn')
    },
    // 获取权限里面  设置的导出影像数
    async beganGetImportImgCount () {
      const res = await getImportImgCount()
      if (res.code === 0) {
        this.importImgCount = res.data
      } else{
        this.$message.error(res.msg)
      }
    },
    // 获取详情里面 的  审批流程
    async beganGetCaseExportApplyLogs (applyId) {
      const res = await getCaseExportApplyLogs({apply_id: applyId})
      if (res.code === 0) {
        this.processArr = res.data
      } else{
        this.$message.error(res.msg)
      }
    },
    // 获取详情  导出列表
    async getCaseExportListByApplyId (applyId) {
      const self = this
      self.curApplyId = applyId
      self.tableData = []
      self.allData = []
      self.checkPassCount = 0
      self.checkNoPassCount = 0
      const res = await getCaseExportListByApplyId({apply_id: applyId})
      if (res.code === 0) {
        const result = res.data
        if (result.length != 0) {
          result.forEach((item) => {
            if (item.state == 1) {// 审核通过
              self.checkPassCount++
            }
            if (item.state == -2) {// 审核不通过
              self.checkNoPassCount++
            }
            self.tableData.push(item)
            self.allData.push(item)
          })
        }
      } else{
        self.$message.error(res.msg)
      }
    }
  },
  created () {
  },
  mounted () {

  }
}
</script>
<style lang="less" scoped>
.recordDetail {
  width: 880px;
  height: 100%;
  .recordDetail-title {
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    padding: 0 20px;
    border-bottom: 1px solid #DCDFE6;
    .recordDetail-titleinfo {
      font-size: 16px;
      color: #303133;
      font-weight: 700;
    }
    .clr_00a {
      background: rgba(0, 173, 120, 1);
    }
    .close-btn {
      position: absolute;
      right: 20px;
      top: 0px;
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .contaner {
    padding: 0 20px;
    border-bottom: 5px solid #EBEEF5;
    height: calc(100% - 250px);
    .contaner-info{
      height: 100%;
      .caseImport{
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 48px;
        .statuLabel {
          font-size:15px;
          color:#303133;
        }
        .caseImportRight{
          display: flex;
          align-items: center;
          .w260{
            width:260px;
          }
        }
      }
      .allInspect{
        height: calc(100% - 96px);
        ::v-deep .el-table__body-wrapper{
          height: calc(100% - 40px);
          overflow: auto;
        }
      }
      .operateCaseBtn{
        display: flex;
        height: 48px;
        align-items: center;
        .userListoperate-btn {
          display: inline-block;
          width:80px;
          height: 32px;
          text-align: center;
          line-height: 32px;
          cursor: pointer;
          border-radius: 3px;
        }
        .cancelBtn{
          width:60px;
          background: #FFFFFF;
          border: 1px solid #DCDFE6;
          border-radius: 3px;
        }
      }
    }
    .failreson {
      height: 42px;
      line-height: 42px;
      padding: 0px 10px;
      background: #fff6f7;
      .clr_88 {
        color: #888888;
      }
      .clr_da {
        color: #da4a4a;
      }
    }
  }
  .caseNum{
    font-size: 15px;
    font-weight: 600;
    font-family: Arial;
  }
  .tableStatuLabel {
    font-size: 14px;
  }
  .waitCheckNum {
    color: #EF8900;
  }
  .passCheckNum{
    color:#1CB54A;
  }
  .noPassCheckNum{
    color:#FF6F6F;
  }
  .checkPeople{
    .importTip{
    display: flex;
    height: 36px;
    align-items: center;
    padding-left:20px;
    .headIcon{
      width: 3px;
      height: 16px;
      background: #0A70B0;
      border-radius: 3px;
      margin-right: 5px;
    }
    .importTipTit{
      font-weight: 700;
      font-size: 15px;
      color: #333333;
      margin-right: 5px;
    }
   }
  }

}
.addPadding7{
  padding:0 7.5px;
}
.imgShowDiv{
  width:80px;
  height:80px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  cursor: pointer;
  img {
    width:auto;
    height:auto;
    max-width: 100%;
    max-height: 100%;
  }
}
.moreLineEllipsis{
  padding-left:80px;
}
.moreLineEllipsis:after {
    display: none;
    position: absolute;
    bottom: 0;
    right: 0;
    font-size:15px!important;
    content: '查看更多';
    background-color: #fff;
    color: #0a70b0;
    cursor: pointer;
    text-align: right;
    font-weight: bold;
    padding-left: 13px;
}
.medIconfont{
  font-size:15px!important;
}
.diagnosisCon::after{
   content: '展开';
}
.moreLineShowAll:after {
    display: block;
    content: '收起';
}
.showMoreLineAfter:after {
   display: block;
}
.mh30{
  min-height: 30px;
}
.detailState{
  // padding-left:0!important;
}
.stateName{
  color:#0bbd87;
  font-size:15px;
  font-weight: 700;
}
.timeStamp{
  color: #909399;
  line-height: 1;
  font-size: 15px;
  padding-left:15px;
}
.otherState {
  color:#303133;
}
.failState{
  color: #f56c6c;
}
.curContent{
  display: block;
  width: 100%;
  border: none;
  padding:20px 30px;
  min-height: 360px;
  max-height: 450px;
  text-align: justify;
  font-size:15px;
  color:#303133;
  overflow-y: auto;
  resize: none;
}
.detailStateDiv{
  position: relative;
}
.imgPadding{
  padding: 0 15px;
}
.stateDescTip{
  color:#888;
  position: absolute;
  left: 0;
  top: 0;
}
.rateImg{
  width:100px;
  cursor: pointer;
}
.checkProcess{
  background: #F5F7FA;
  border-radius: 3px;
  padding-top:10px;
  padding-left: 10px;
  margin: 0 20px;
  height:152px;
 .startProcess{
   display: flex;
   .startProcessLeft{
     position: relative;
     .icontianjia{
       position: absolute;
       right: 0px;
       bottom: 2px;
       font-size:12px;
       color:#409EFF;
     }
   }
   .startProcessRight{
      margin-left:10px;
     .startProcessRightHead {
       display: flex;
       align-items: center;
       overflow:hidden;
       text-overflow:ellipsis;
       white-space:nowrap;
       .processFirstStep{
        padding: 0px 5px;
        font-size: 13px;
        color: #FFFFFF;
        background: #409EFF;
        border-radius: 3px;
        margin-right: 5px;
      }
      .importReason{
        font-size: 13px;
        color: #EF8900;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 130px;
      }
      .firstReason{
        max-width: 300px;
      }
     }
     .startProcessRightBottom{
       display: flex;
       align-items: center;
       .userName{
        font-weight: 700;
        font-size: 13px;
        color: #000000;
        white-space: nowrap;
       }
       .officeName {
        font-size: 13px;
        color: #303133;
        white-space: nowrap;
       }
       .beganTime{
        font-size: 13px;
        color: #303133;
        white-space: nowrap;
       }
     }
   }
 }
 .arrowDownImg{
  margin-left:15px;
 }
 .otherProcess {
   display: flex;
   align-items: center;
   overflow-x: auto;
   .oneProcess{
     display: flex;
     align-items: center;
   }
   .statusIcon{
      position: absolute;
      right: 0px;
      bottom: 2px;
      font-size: 12px;
   }
   .iconzhengchang{
     color:#1CB54A;
   }
   .iconzhuxiao{
     color:#FF6F6F;
   }
   .noPassStatus{
     background: #FF6F6F!important;
   }
   .passStatus{
     background:#1CB54A!important;
   }
   .cancelStatus{
    background:#C0C4CC!important;
   }
 }
}
.noReport,.noImage{
  font-size: 14px;
  color: #C0C4CC!important;
}
</style>
