<style lang="less" scoped>
.mr108 {
  margin-right: 108px;
}

.w260 {
  width: 260px;
}

.strategy_way {
}

.strategy_cls {
  /deep/ .el-dialog__body {
    padding: 17px 30px 41px 30px !important;
  }

  /deep/ .el-form-item__label,
  .el-form-item__content {
    line-height: 35px;
  }

  /deep/.el-form-item__label {
    padding-right: 0;
  }

  .el-radio {
    margin-right: 0;
  }

  /deep/.el-dialog__header {
    // height: 50px;
    line-height: 40px;
  }
}

.warningDiv {
  color: rgba(239, 137, 0, 1);
}

/deep/ .white-head .el-dialog__header {
  background-color: white;
  color: #2b354a;
}
</style>
<style lang="less">
.el-message-box {
  width: 500px;

  .el-message-box__title {
    justify-content: flex-start;

    span {
      font-size: 16px !important;
      font-weight: bold;
    }
  }

  .el-message-box__message {
    text-align: left !important;

    strong {
      font-size: 18px;
    }

    span {
      font-size: 15px;
    }
  }

  .el-message-box__btns {
    text-align: right !important;
  }
}
</style>
<template>
  <div>
    <div class="strategy_cls">
      <el-dialog
        title="存储策略设置"
        :visible.sync="SetSaveStrategyShow"
        :before-close="SetSaveStrategyClose"
        width="550px"
        top="3%"
        left
      >
        <!-- <div slot="title" class="dialog-title">
          <span class="f16 fff" style="color:white">
            存储策略设置
          </span>
          <el-button v-popover:popover type="text">
            <i class="iconfont" style="color:white">&#xe64c;</i>
          </el-button>
          <el-popover ref="popover" placement="right" width="300" trigger="hover">
            <div class="mr10 ml10 mt10 mb10">

              <span> 为确保正常调阅影像及数据安全，请注意：</span><br />

              <span>1、配置近线策略时，指定天数极限值为15天，磁盘容量极限值为60%。除非特殊要求，否则请确保参数大于极限值。</span><br />

              <span>2、配置离线策略时：</span><br />

              <span>（1）指定天数极限值为90天，磁盘容量极限值为80%且最少保留90天。除非特殊要求，否则请确保参数大于极限值；</span><br />

              <span>（2）删除影像时需与校对节点确认影像是否已备份，故配置校对节点后需测试连通性，测试成功方可保存。</span><br />

              <span>3、近线和离线策略同时开启，且都配置为指定天数或指定磁盘容量时，近线参数必须小于删除参数。</span><br />
            </div>

          </el-popover>
        </div> -->

        <div
          class="strategy_way"
          :class="{ bbd: !strategyWay }"
          v-if="domainConfig"
        >
          <div class="strong mb10">策略方式</div>
          <el-radio-group
            v-model="strategyWay"
            class="mb20 mt10"
            @change="strategyWayChange"
          >
            <el-radio :label="true" class="mr10">单独配置</el-radio>
            <el-radio :label="false" class="ml10">整体配置</el-radio>
          </el-radio-group>
        </div>
        <div class="" v-show="!strategyWay || !domainConfig">
          <div class="of">
            <el-form
              class="of"
              label-position="right"
              :model="saveStrategyData"
              :rules="saveStrategyRules"
              ref="saveStrategyDataForm"
              style="height: 200px; overflow-y: auto"
            >
              <!-- bbd -->
              <div class="of pb10 w100">
                <div class="f18 mb20 mt10 clr_333">
                  <span class="mr20">近线策略</span>
                  <el-switch
                    v-model="saveStrategyData.nearline_enable"
                    :active-value="1"
                    :inactive-value="0"
                    @change="nearSwitchChange"
                  >
                  </el-switch>

                  <!-- 20230306评审(赵元昊) 存在对象存储设备时，离线策略处直接展示提示文案 -->
                  <!-- <el-button v-popover:firstPop type="text" v-if="onlineObjectStorage" class="warningDiv f16 ml10">
                    <i class="iconfont">&#xe64c;</i>
                  </el-button>
                  <el-popover v-if="onlineObjectStorage" ref="firstPop" placement="right" width="300" trigger="hover">
                    <div class="mr10 ml10 mt10 mb10">
                      <span> 在线设备中有已启用的对象存储设备，只可按指定天数近线。</span>
                    </div>
                  </el-popover> -->
                </div>
                <div class="w100 mt10 clear_fixed">
                  <el-form-item class="inline" prop="nearline_mode">
                    <el-radio
                      class="dib ml70"
                      v-model="saveStrategyData.nearline_mode"
                      :label="0"
                      ><span></span
                    ></el-radio>
                  </el-form-item>
                  <el-form-item
                    label="近线指定天数前的影像文件："
                    class="w_316 dib mr108"
                  >
                    <el-input-number
                      style="width: 100px"
                      size="medium"
                      v-model="saveStrategyData.nearline_of_days"
                      controls-position="right"
                      :min="1"
                      @change="
                        (currentValue, oldValue, label) =>
                          daysIptNumChange(
                            currentValue,
                            oldValue,
                            'nearline_of_days'
                          )
                      "
                    ></el-input-number>
                    <span class="ml10">天</span>
                  </el-form-item>
                  <!-- 20230306评审(赵元昊) 在线存在对象存储设备时，此处置灰，不可选择 -->
                  <!-- <el-form-item class="inline" prop="nearline_mode">
                    <el-radio class="mt3" :disabled="onlineObjectStorage" v-model="saveStrategyData.nearline_mode"
                      :label="1"><span></span></el-radio>
                  </el-form-item>
                  <el-form-item label="近线影像文件到指定磁盘容量：" class="w_330 dib">
                    <el-input-number style="width: 100px" size="medium"
                      v-model="saveStrategyData.nearline_of_space_ratio" controls-position="right" :min="1"
                      @change="(currentValue, oldValue, label) => ratioIptNumChange(currentValue, oldValue, 'nearline_of_space_ratio')"></el-input-number>
                    <span class="ml10">%</span>
                  </el-form-item> -->
                </div>
                <div class="w100 mt10 clear_fixed">
                  <el-form-item label="近线策略执行时间：" class="ml70">
                    <el-time-picker
                      v-model="nearlinePerformTimeStart"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      placeholder="开始时间"
                      style="width: 140px"
                    >
                    </el-time-picker>
                    <span> - </span>
                    <el-time-picker
                      v-model="nearlinePerformTimeEnd"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      placeholder="结束时间"
                      style="width: 140px"
                    >
                    </el-time-picker>
                  </el-form-item>
                </div>
              </div>
              <div class="of pb10 mt10 w100" v-show="false">
                <div class="f18 mb20 clr_333">
                  <span class="mr20">离线策略</span>
                  <el-switch
                    v-model="saveStrategyData.offline_enable"
                    :active-value="1"
                    :inactive-value="0"
                    @change="offSwitchChange"
                  >
                  </el-switch>
                  <!-- 20230222评审(赵元昊) 存在对象存储设备时，离线策略处直接展示提示文案 -->
                  <!-- <span v-if="hasObjectStorage" class="warningDiv f16 ml10"> <i class="iconfont">&#xe64c;</i>

                    存储设备中有已启用的对象存储设备，只可按指定天数删除。</span> -->
                  <!-- <el-button v-popover:secondPop type="text" v-if="hasObjectStorage" class="warningDiv f16 ml10">
                    <i class="iconfont">&#xe64c;</i>
                  </el-button>
                  <el-popover v-if="hasObjectStorage" ref="secondPop" placement="right" width="300" trigger="hover">
                    <div class="mr10 ml10 mt10 mb10">
                      <span> 存储设备中有已启用的对象存储设备，只可按指定天数离线。</span>
                    </div>
                  </el-popover> -->
                </div>
                <div class="w100 mt10 clear_fixed">
                  <el-form-item class="inline" prop="offline_mode">
                    <el-radio
                      class="dib ml70"
                      v-model="saveStrategyData.offline_mode"
                      :label="0"
                      ><span></span
                    ></el-radio>
                  </el-form-item>
                  <el-form-item
                    label="离线指定天数前的影像文件："
                    class="w_316 dib mr108"
                  >
                    <el-input-number
                      style="width: 100px"
                      size="medium"
                      v-model="saveStrategyData.offline_of_days"
                      controls-position="right"
                      :min="1"
                      @change="
                        (currentValue, oldValue, label) =>
                          daysIptNumChange(
                            currentValue,
                            oldValue,
                            'offline_of_days'
                          )
                      "
                    ></el-input-number>
                    <span class="ml10">天</span>
                  </el-form-item>
                  <!-- 20230222评审(赵元昊) 存在对象存储设备时，此处置灰，不可选择 -->
                  <!-- <el-form-item class="inline" prop="offline_mode">
                    
                    <el-radio :disabled="hasObjectStorage" v-model="saveStrategyData.offline_mode"
                      :label="1"><span></span></el-radio>
                  </el-form-item>
                  <el-form-item label="离线影像文件到指定磁盘容量：" class="w_330 dib">
                    <el-input-number style="width: 100px" size="medium"
                      v-model="saveStrategyData.offline_of_space_ratio" controls-position="right" :min="1"
                      @change="(currentValue, oldValue, label) => ratioIptNumChange(currentValue, oldValue, 'offline_of_space_ratio')"></el-input-number>
                    <span class="ml10">%</span>
                  </el-form-item>
                  <el-form-item label="且最少保留" class="dib w260 ml10">
                    <el-input-number style="width: 100px" class="" size="medium"
                      v-model="saveStrategyData.offline_save_days" controls-position="right" :min="1"
                      @change="(currentValue, oldValue, label) => ratioIptNumChange(currentValue, oldValue, 'offline_save_days')"></el-input-number>
                    <span class="ml10">天</span>
                  </el-form-item> -->
                </div>
                <div class="w100 mt10 clear_fixed">
                  <el-form-item label="离线策略执行时间：" class="ml70">
                    <el-time-picker
                      v-model="offlinePerformTimeStart"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      placeholder="开始时间"
                      style="width: 140px"
                    >
                    </el-time-picker>
                    <span> - </span>
                    <el-time-picker
                      v-model="offlinePerformTimeEnd"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      placeholder="结束时间"
                      style="width: 140px"
                    >
                    </el-time-picker>
                  </el-form-item>
                </div>
              </div>
            </el-form>
          </div>
        </div>

        <div slot="footer" class="dialog-footer mb10 fr">
          <el-button @click="SetSaveStrategyClose" size="small" class="mr20"
            >关 闭</el-button
          >
          <el-button type="primary" @click="preUpdateSaveStrategy" size="small"
            >保 存</el-button
          >
        </div>
      </el-dialog>
    </div>

    <div class="white-head">
      <el-dialog
        title="提示"
        :visible.sync="innerVisible"
        width="40%"
        :show-close="false"
        :before-close="handleClose"
        @opened="openedAlertContent"
      >
        <div slot="title" class="dialog-title fff">
          <i class="iconfont clr_warn" style="font-size: 26px">&#xe64c;</i>
          <span class="f16 ml5">
            以下参数小于极限值，可能会影响影像调阅或数据安全，请确认！
          </span>
        </div>
        <div id="alert_content" class="f16 ml15"></div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="innerVisible = false">取 消</el-button>
          <el-button type="primary" @click="updateSaveStrategy">
            确 定</el-button
          >
        </span>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import moment from "moment";
import {
  updateStorageStrategiesType,
  updateStorageStrategies,
} from "@/api/memorySharing/dataMemory";
export default {
  data() {
    let modeValidator = (type, tip) => {
      return (rule, value, callback) => {
        if (this.saveStrategyData[type] === 1) {
          if (value === "") {
            callback(new Error(tip));
          } else {
            callback();
          }
        } else {
          callback();
        }
      };
    };

    return {
      strategyWay: true, //true 单独配置 false 整体配置
      //20230222评审
      /**
       * 默认值：
       * 近线：执行时间22:00-06:00  360天 80
       * 离线：执行时间 22:00-06:00   730天 90 90天
       */

      saveStrategyData: {
        domain_id: 0,
        strategy_type: 1, //	策略类型 0 整体配置 1 按照系统配置 2 按照机构配置
        nearline_enable: 0,
        nearline_mode: "",
        nearline_of_days: 360,
        nearline_of_space_ratio: 80,
        nearline_begin_perform_time: "2023-01-01 22:00:00",
        nearline_end_perform_time: "2023-01-02 06:00:00",
        offline_enable: 0,
        offline_mode: "",
        offline_of_days: 730,
        offline_of_space_ratio: 90,
        offline_save_days: 90,
        offline_begin_perform_time: "2023-01-01  22:00:00",
        offline_end_perform_time: "2023-01-02 06:00:00",
      },
      saveStrategyRules: {
        nearline_mode: [
          {
            trigger: "blur",
            validator: modeValidator("nearline_enable", "请选择近线模式"),
          },
        ],
        // offline_mode: [{
        //   trigger: 'blur',
        //   validator: modeValidator('offline_enable', '请选择离线模式')
        // }],
      },
      nearlinePerformTimeStart: "2023-01-01 22:00:00", // 近线策略开始时间
      nearlinePerformTimeEnd: "2023-01-02 06:00:00", // 近线策略执行结束时间
      offlinePerformTimeStart: "2023-01-01 22:00:00", // 离线策略执行开始时间
      offlinePerformTimeEnd: "2023-01-02 06:00:00", // 离线策略执行结束时间
      innerVisible: false,
      innerAlertHTML: "",
      // hasObjectStorage: false,//测试用，等下记得删除
    };
  },

  watch: {
    SetSaveStrategyShow(val) {
      console.log("当前对象", val, this.StrategyData);
    },
    StrategyData: {
      handler(data) {
        if (data) {
          if (data.strategy_type !== null && data.strategy_type !== undefined) {
            this.strategyWay = data.strategy_type !== 0;
          } else {
            this.strategyWay = true;
          }

          this.saveStrategyData.domain_id = data.domain_id;
          this.saveStrategyData.strategy_type = data.strategy_type;
          this.saveStrategyData.nearline_enable = data.nearline_enable;
          this.saveStrategyData.nearline_mode = data.nearline_mode;
          this.saveStrategyData.nearline_of_days = data.nearline_of_days ?? 360;
          this.saveStrategyData.nearline_of_space_ratio =
            data.nearline_of_space_ratio ?? 80;
          this.saveStrategyData.nearline_begin_perform_time =
            data.nearline_begin_perform_time || "2023-01-01 22:00:00";
          this.nearlinePerformTimeStart =
            data.nearline_begin_perform_time || "2023-01-01 22:00:00";
          this.saveStrategyData.nearline_end_perform_time =
            data.nearline_end_perform_time || "2023-01-02 06:00:00";
          this.nearlinePerformTimeEnd =
            data.nearline_end_perform_time || "2023-01-02 06:00:00";
          this.saveStrategyData.offline_enable = data.offline_enable;
          this.saveStrategyData.offline_mode = data.offline_mode;
          this.saveStrategyData.offline_of_days = data.offline_of_days ?? 730;
          this.saveStrategyData.offline_of_space_ratio =
            data.offline_of_space_ratio ?? 90;
          this.saveStrategyData.offline_save_days =
            data.offline_save_days ?? 90;
          this.saveStrategyData.offline_begin_perform_time =
            data.offline_begin_perform_time || "2023-01-01 22:00:00";
          this.offlinePerformTimeStart =
            data.offline_begin_perform_time || "2023-01-01 22:00:00";
          this.saveStrategyData.offline_end_perform_time =
            data.offline_end_perform_time || "2023-01-02 06:00:00";
          this.offlinePerformTimeEnd =
            data.offline_end_perform_time || "2023-01-02 06:00:00";
        } else {
          this.strategyWay = true;
        }
      },
      immediate: true,
    },

    nearlinePerformTimeStart(newVal) {
      if (newVal) {
        this.saveStrategyData.nearline_begin_perform_time = newVal;
      } else {
        this.saveStrategyData.nearline_begin_perform_time =
          "2023-01-01 22:00:00";
      }
    },
    nearlinePerformTimeEnd(newVal) {
      if (newVal) {
        this.saveStrategyData.nearline_end_perform_time = newVal;
      } else {
        this.saveStrategyData.nearline_end_perform_time = "2023-01-02 06:00:00";
      }
    },

    offlinePerformTimeStart(newVal) {
      if (newVal) {
        this.saveStrategyData.offline_begin_perform_time = newVal;
      } else {
        this.saveStrategyData.offline_begin_perform_time =
          "2023-01-01 22:00:00";
      }
    },
    offlinePerformTimeEnd(newVal) {
      if (newVal) {
        this.saveStrategyData.offline_end_perform_time = newVal;
      } else {
        this.saveStrategyData.offline_end_perform_time = "2023-01-02 06:00:00";
      }
    },
  },
  props: [
    "configIds",
    "domainConfig",
    "SetSaveStrategyShow",
    "hasObjectStorage",
    "onlineObjectStorage",
    "StrategyData",
  ], //
  // mounted(){
  //   this.validTime()
  // },
  methods: {
    nearSwitchChange() {
      if (
        this.saveStrategyData.nearline_enable === 1 &&
        this.saveStrategyData.nearline_mode !== 0 &&
        this.saveStrategyData.nearline_mode !== 1
      )
        this.saveStrategyData.nearline_mode = 0;
    },
    offSwitchChange() {
      if (
        this.saveStrategyData.offline_enable === 1 &&
        this.saveStrategyData.offline_mode !== 0 &&
        this.saveStrategyData.offline_mode !== 1
      )
        this.saveStrategyData.offline_mode = 0;
    },
    strategyWayChange() {
      // console.log('变成整体配置了',this.strategyWay,this.cu);
    },
    SetSaveStrategyClose(shouldRefresh) {
      this.$emit("SetSaveStrategyClose", shouldRefresh);
    },

    openedAlertContent() {
      let divDocument = document.getElementById("alert_content");
      divDocument.innerHTML = this.innerAlertHTML;
    },
    formattingTime(str) {
      let date = new Date(str);
      return "2023-01-01 " + moment(date).format("HH:mm:ss");
    },
    validTimes(begin, end) {
      let startStr = this.formattingTime(begin);
      let endStr = this.formattingTime(end);
      let timeL = new Date(endStr).getTime() - new Date(startStr).getTime();

      if (timeL >= 0 && timeL < 5 * 60 * 1000) return true;
      return false;
    },
    ValidationStrategyRules() {
      /*
      if (this.onlineObjectStorage && this.saveStrategyData.nearline_enable === 1 && this.saveStrategyData.nearline_mode == 1) {
        this.$message.error('在线设备中有已启用的对象存储设备，近线策略只可按指定天数近线！')
        return
      }
      if (this.hasObjectStorage && this.saveStrategyData.offline_enable === 1 && this.saveStrategyData.offline_mode == 1) {
        this.$message.error('存储设备中有已启用的对象存储设备，离线策略只可按指定天数离线！')
        return
      }*/
      //存储策略极限值及冲突规则提示
      // if (this.saveStrategyData.nearline_enable && this.saveStrategyData.offline_enable && this.saveStrategyData.nearline_mode === 0 && this.saveStrategyData.offline_mode === 0 && this.saveStrategyData.nearline_of_days >= this.saveStrategyData.offline_of_days) {
      //   this.$message.error(`近线策略指定天数[${this.saveStrategyData.nearline_of_days}]天，需小于离线策略指定天数[${this.saveStrategyData.offline_of_days}]天！`)
      //   return
      // }
      /*
      if (this.saveStrategyData.nearline_enable && this.saveStrategyData.offline_enable && this.saveStrategyData.nearline_mode === 1 && this.saveStrategyData.offline_mode === 1 && this.saveStrategyData.nearline_of_space_ratio >= this.saveStrategyData.offline_of_space_ratio) {
        this.$message.error(`近线策略指定磁盘容量[${this.saveStrategyData.nearline_of_space_ratio}%]，需小于离线策略指定磁盘容量[${this.saveStrategyData.offline_of_space_ratio}%]！`)
        return
      }*/

      // const timer = new Date(this.formattingTime(this.nearlinePerformTimeEnd)).getTime() - new Date(this.formattingTime(this.nearlinePerformTimeStart)).getTime()
      const timer = this.validTimes(
        this.nearlinePerformTimeStart,
        this.nearlinePerformTimeEnd
      );
      if (this.saveStrategyData.nearline_enable && timer) {
        this.$message.warning("近线策略执行时间间隔应大于5分钟");
        return;
      }
      // const timer2 = this.validTimes(this.offlinePerformTimeStart, this.offlinePerformTimeEnd)

      // const timer2 = new Date(this.formattingTime(this.offlinePerformTimeEnd)).getTime() - new Date(this.formattingTime(this.offlinePerformTimeStart)).getTime()
      // if (this.saveStrategyData.offline_enable && timer2) {
      //   this.$message.warning('离线策略执行时间间隔应大于5分钟')
      //   return
      // }
      let alertContent = "<strong>参数小于极限值:</strong><br/>";
      let count = 1;
      // 192.168.1.165 原型    近线极限值 90天 容量80%

      if (
        this.saveStrategyData.nearline_enable &&
        this.saveStrategyData.nearline_mode === 0 &&
        this.saveStrategyData.nearline_of_days < 90
      ) {
        alertContent =
          alertContent +
          `<span>${count}、近线指定天数为${this.saveStrategyData.nearline_of_days}天，小于极限值90天</span><br/>`;
        count++;
      }
      /*
      if (this.saveStrategyData.nearline_enable && this.saveStrategyData.nearline_mode === 1 && this.saveStrategyData.nearline_of_space_ratio < 80) {
        alertContent = alertContent + `<span>${count}、近线指定磁盘容量为${this.saveStrategyData.nearline_of_space_ratio}%，小于极限值80%</span><br/>`
        count++
      }*/
      // 192.168.1.165 原型    离线极限值 120天 容量80% 最少保留90天

      // if (this.saveStrategyData.offline_enable && this.saveStrategyData.offline_mode === 0 && this.saveStrategyData.offline_of_days < 120) {

      //   alertContent = alertContent + `<span>${count}、离线指定天数为${this.saveStrategyData.offline_of_days}天，小于极限值120天</span><br/>`
      //   count++
      // }
      /*
      if (this.saveStrategyData.offline_enable && this.saveStrategyData.offline_mode === 1 && this.saveStrategyData.offline_of_space_ratio < 90) {
        alertContent = alertContent + `<span>${count}、离线指定磁盘容量为${this.saveStrategyData.offline_of_space_ratio}%，小于极限值90%</span><br/>`
        count++
      }

      if (this.saveStrategyData.offline_enable && this.saveStrategyData.offline_mode === 1 && this.saveStrategyData.offline_save_days < 90) {
        alertContent = alertContent + `<span>${count}、离线最少保留天数为${this.saveStrategyData.offline_save_days}天，小于极限值90天</span><br/>`
        count++
      }

      let configCount = 0;
      let configStr = '<strong>策略配置不一致</strong><br/>'
      if (this.saveStrategyData.offline_enable && this.saveStrategyData.nearline_enable && this.saveStrategyData.offline_mode !== this.saveStrategyData.nearline_mode) {
        if (this.saveStrategyData.offline_mode === 0) {
          //删除天数、近线容量
          configStr = configStr + `近线策略为指定容量，离线策略为指定天数，两者不一致，请确认配置无误！`
        } else {
          configStr = configStr + `近线策略为指定天数，离线策略为指定容量，两者不一致，请确认配置无误！`

        }
        if (count > 1) {
          alertContent = configStr + '<br/><br/>' + alertContent;
        } else {
          alertContent = configStr;
        }
        configCount++;
      }*/

      //|| configCount > 0
      if (count > 1) {
        // this.innerAlertHTML = alertContent
        // this.innerVisible = true
        this.$confirm(
          alertContent,
          "以下设置可能会影响影像调阅或数据安全,请确认!",
          {
            confirmButtonText: "取消",
            cancelButtonText: "确认",
            type: "warning",
            center: true,
            dangerouslyUseHTMLString: true,
            distinguishCancelAndClose: true,
          }
        )
          .then((action) => {
            //取消操作不管
            // this.$message({
            //   type: 'success',
            //   message: '删除成功!'
            // });
          })
          .catch((action) => {
            if (action === "cancel") {
              //这里改为确认操作了
              this.updateSaveStrategy();
            } else {
              //取消操作不管
            }
            // this.$message({
            //   type: 'info',
            //   message: '已取消删除'
            // });
          });
      } else {
        this.updateSaveStrategy();
      }
    },
    preUpdateSaveStrategy() {
      this.$refs.saveStrategyDataForm.validate(async (valid) => {
        if (valid) {
          this.ValidationStrategyRules();
        }
      });
    },

    async updateSaveStrategy() {
      if (this.saveStrategyData.offline_enable instanceof Boolean) {
        this.saveStrategyData.offline_enable = this.saveStrategyData
          .offline_enable
          ? 1
          : 0;
      }
      if (this.saveStrategyData.nearline_enable instanceof Boolean) {
        this.saveStrategyData.nearline_enable = this.saveStrategyData
          .nearline_enable
          ? 1
          : 0;
      }

      if (this.domainConfig) {
        this.saveStrategyData.strategy_type = this.strategyWay ? 1 : 0;

        const res = await updateStorageStrategiesType(this.saveStrategyData);
        const { code, msg } = res;
        if (code === 0) {
          this.innerVisible = false;
          this.SetSaveStrategyClose(true);
          this.$message({
            type: "success",
            message: msg || "保存成功",
          });
          //更新存储策略成功！
        } else {
          this.innerVisible = false;
          //更新存储策略失败，请重试！
          this.$message.error(msg);
        }
      } else {
        this.saveStrategyData.strategy_type = 1;
        let params = this.configIds.map((e) => ({
          ...this.saveStrategyData,
          id: e,
        }));
        const res = await updateStorageStrategies(params);
        const { code, msg } = res;
        if (code === 0) {
          this.innerVisible = false;
          this.SetSaveStrategyClose(true);
          this.$message({
            type: "success",
            message: msg,
          });
          //更新存储策略成功！
        } else {
          this.innerVisible = false;
          //更新存储策略失败，请重试！
          this.$message.error(msg);
        }
      }
    },
    daysIptNumChange(currentValue, oldValue, label) {
      if (currentValue === undefined) {
        this.$nextTick(() => {
          this.saveStrategyData[label] = 1;
        });
      } else if (!Number.isInteger(currentValue)) {
        this.$nextTick(() => {
          this.saveStrategyData[label] = parseInt(currentValue);
        });
      }
    },
    ratioIptNumChange(currentValue, oldValue, label) {
      if (currentValue === undefined) {
        this.$nextTick(() => {
          if (label === "offline_save_days") {
            this.saveStrategyData[label] = 90;
          } else {
            this.saveStrategyData[label] = 0;
          }
        });
      }
    },
    handleClose() {},
  },
};
</script>
