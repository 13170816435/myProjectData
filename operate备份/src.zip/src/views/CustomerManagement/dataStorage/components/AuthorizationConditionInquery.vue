<template>
  <div>
    <el-form :inline="true" class="demo-form-inline" label-width="75px" label-position="right">
      <el-form-item label="存储域：">
        <el-select :disabled="group !== 'tenancy'" size="small" v-model="searchData.system_id" placeholder="请选择"
          style="width:180px" clearable @change="systemIdChange">
          <el-option v-for="item in systemsLiteList" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="业务系统：" label-width="75px">
        <!-- group === 'dept' -->
        <el-select
          :disabled="institutionsLiteList.length === 0 || (group !== 'tenancy' && !ksyxlbPermission && jgyxlbPermission)"
          size="small" v-model="searchData.institution_id" placeholder="请选择" clearable style="width:180px"
          @change="institutionIdChange">
          <el-option v-for="item in institutionsLiteList" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item class="ml10">
        <el-button type="primary" size="small" @click="searchCondation">查询</el-button>
        <el-button type="primary" plain size="small" @click="resetCondation">重置</el-button>
      </el-form-item>
      <br>
    </el-form>
  </div>
</template>
<script>
import { mapGetters } from "vuex";

export default {
  data() {
    return {
      searchData: {
        system_id: "",
        institution_id: "",
        modalities_in_study: "",
        start_study_date_time: "",
        end_study_date_time: "",
        observationRooms: [],//来源机房---选中的

      },
      keyValue: "patient_name",
      strValue: "",
      modalityTypeOptions: [
        {
          value: "-1",
          label: "全部",
        },
        {
          value: "CT",
          label: "CT",
        },
        {
          value: "CR",
          label: "CR",
        },
        {
          value: "MR",
          label: "MR",
        },
        {
          value: "NM",
          label: "NM",
        },
        {
          value: "PT",
          label: "PT",
        },
        {
          value: "DX",
          label: "DX",
        },
        {
          value: "DR",
          label: "DR",
        },
        {
          value: "ES",
          label: "ES",
        },
        {
          value: "MG",
          label: "MG",
        },
        {
          value: "RF",
          label: "RF",
        },
        {
          value: "SC",
          label: "SC",
        },
        {
          value: "US",
          label: "US",
        },
        {
          value: "XA",
          label: "XA",
        },
        {
          value: "OT",
          label: "OT",
        },
        {
          value: "PET",
          label: "PET",
        },
        {
          value: "ECT",
          label: "ECT",
        },
        {
          value: "OP",
          label: "OP",
        },
        {
          value: "OPM",
          label: "OPM",
        },
        {
          value: "OPT",
          label: "OPT",
        },
        {
          value: "OPV",
          label: "OPV",
        },
        {
          value: "XC",
          label: "XC",
        },
        {
          value: "OIS",
          label: "OIS",
        }
      ], // 检查类型

      clearTime: false, // 清除查询时间
      initTime: [],
      institutionsLiteList: [], // 机构名称
      sourceObservationRooms: [],//来源机房---接口获取到的
      ksyxlbPermission: false,
      jgyxlbPermission: false,
    };
  },
  props: [],
  computed: {
    // ...mapGetters(["group", "systemid", "deptInstitutionId"]),
  
  },
 
  async mounted() {
 


  },
  methods: {
    systemIdChange(val) {
      this.institutionsLiteList = [];
      this.sourceObservationRooms = [];
      this.searchData.observationRooms = [];
      this.searchData.institution_id = "";
      if (val) {
        this.getInstitutionsLiteList(val);
      }
      this.$emit('systemOrInstitutionChanged',this.searchData)
    },

    institutionIdChange(val) {
      // console.log('机构id为', val);
      this.sourceObservationRooms = [];
      this.searchData.observationRooms = [];
      if (val) {
        this.getObservationRoomsLiteList(val);
      }
      this.$emit('systemOrInstitutionChanged',this.searchData)

    },
    defaultSelectedRooms() {
    
      this.searchData.observationRooms = []
      let rooms = []
      this.room_ids.map(e => {
        let findItemIndex = this.sourceObservationRooms.findIndex(ele => e === ele.id)
        if (findItemIndex >= 0) {
          rooms.push(e)
        }
      })
      this.$nextTick(()=>{
        this.searchData.observationRooms = rooms
      })
    },
  
    searchCondation() {
      // console.log('搜索参数s', this.searchData);
      // 搜索
      const searchData = {
        ...this.searchData,
        match_state: this.match_state,
        [this.keyValue]: this.strValue,
      };
      this.$emit("search", searchData);
    },
    //ksyx  科室影像  jgyx机构影像
    async resetCondation() {

      console.log('匹配状态',this.match_state1);

      // 重置
      const setObj = JSON.parse(localStorage.getItem('setObj')) || {}
      if (this.group === "dept") {
        if (!this.ksyxlbPermission && this.jgyxlbPermission && setObj?.GeneralCliParameter_WorkInstitutionId) {
          this.searchData.institution_id = setObj.GeneralCliParameter_WorkInstitutionId

        } else {
          this.searchData.institution_id = "";
        }
      } else if (this.group === "tenancy") {
        this.searchData.system_id = "";
        this.searchData.institution_id = "";
      }
      this.keyValue = "patient_name";
      this.strValue = "";
      this.searchData.modalities_in_study = "";
      this.defaultSelectedRooms()

      if (this.searchData.institution_id) {
        //有机构id 且 机房不为空
        this.sourceObservationRooms = [];
        this.searchData.observationRooms = [];
        await this.getObservationRoomsLiteList(this.searchData.institution_id)
        this.$nextTick(() => {
          this.defaultSelectedRooms()
        })

      }
      // console.log('匹配状态',this.match_state1);

      if(this.clear_select){
        this.clearTime = true
        this.searchData.start_study_date_time = ''
        this.searchData.end_study_date_time = ''
        this.match_state1 = -1

        this.$emit('changeClear')
        const searchData = {
        ...this.searchData,
        match_state: this.match_state,
      };
      this.$emit("search", searchData);

      }else{
        this.match_state1 = "";

        setTimeout(() => {
        this.$refs.searchTimeModel.setDate();
        this.getTimes(this.$refs.searchTimeModel.time);
      }, 100);
      }
      

      this.$emit("reset");


    },
    async getInstitutionsLiteList(val) {
      if (val) {

        let res = await this.$pacsApi.pacsApi.getInstitutionsLiteList({
          system_id: val,
        });
        let { code, data } = res;
        if (code === 0) {
          this.$nextTick(() => {
            this.institutionsLiteList = data;
          });
        }
      }
    },
   
  },
 
};
</script>
<style lang="less" scoped>
/deep/ .el-form-item__label {
  padding: 0px;
}

/deep/.el-form-item {
  margin-right: 5px;
}

/deep/ .el-input--suffix .el-input__inner {
  padding-right: 30px !important;
}
</style>
