<template>
  <div style="width:100%;height:100%;">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr5"></i>数据存储
          <i class="iconfont iconzhankaishouqi"></i> 内容管理
        </span>
      </div>
    </div>
    <div class="form-container">
      <div class="form-row">
        <div class="type-select">
          <el-dropdown @command="selectDomain" placement="bottom-start">
            <span class="el-dropdown-link">
              {{ selectedDomain.id ? selectedDomain.domain_name : '请选择' }}<i
                class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item v-for="item in domains" :key="item.id" :command="item">{{ item.domain_name
              }}</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
        <div class="data-cell data-cell-wendang">
          <div class="data-cell-icon">
            <i class="iconfont iconwendangzongshu"></i>
          </div>
          <div class="data-cell-content">
            <span class="data-cell-label">文档总数：</span>
            <span class="data-cell-text">{{ domainInfo.total }}份/{{ domainInfo.total_used_size_desc }}</span>
          </div>
        </div>
        <div class="data-cell data-cell-biaoji">
          <div class="data-cell-icon">
            <i class="iconfont iconbiaojishanchu"></i>
          </div>
          <div class="data-cell-content">
            <span class="data-cell-label">标记删除：</span>
            <span class="data-cell-text">{{ domainInfo.delete_total }}份/{{ domainInfo.delete_total_used_size_desc
            }}</span>
          </div>
        </div>
      </div>
      <div class="form-row">
        <div class="form-item ">
          <div class="form-item-label">业务类型：</div>
          <el-select v-model="formData.business_type" placeholder="全部">
            <el-option value="">全部</el-option>
            <el-option v-for="item in documentBusinessTypeList" :key="item.id" :label="item.dic_name"
              :value="item.dic_code">
            </el-option>
          </el-select>
        </div>
        <div class="form-item">
          <div class="form-item-label">检查类型：</div>
          <el-select v-model="formData.modality" placeholder="全部">
            <el-option value="">全部</el-option>
            <el-option v-for="item in examineTypeList" :key="item.id" :label="item.dic_name" :value="item.dic_code">
            </el-option>
          </el-select>
        </div>
        <div class="form-item">
          <div class="form-item-label">存储设备：</div>
          <el-select v-model="formData.device_id" placeholder="全部">
            <el-option value="">全部</el-option>
            <el-option v-for="item in domainDeviceList" :key="item.id" :label="item.device_name" :value="item.id">
            </el-option>
          </el-select>
        </div>
        <div class="form-item form-item-long">
          <div class="form-item-label">上传时间：</div>
          <div style="width: 235px">
            <SearchTime ref="searchTimeModel" :clearTime="clearTime" :disableTime="'after'" @getTimes="getTimes" />
          </div>
        </div>
      </div>
      <div class="of">
        <div class="form-row fl">
          <div class="form-item">
            <div class="form-item-label">所属机构：</div>
            <el-select v-model="formData.org_code" placeholder="全部" filterable @change="orgCodeChange">
              <el-option value="">全部</el-option>
              <el-option v-for="item in institutionList" :key="item.id" :label="item.name" :value="item.code">
              </el-option>
            </el-select>
          </div>
          <div class="form-item">
            <div class="form-item-label">所属科室：</div>
            <el-select v-model="formData.depart_code" placeholder="全部">
              <el-option value="">全部</el-option>
              <el-option v-for="item in officesLite" :key="item.system_type" :label="item.name" :value="item.system_type">
              </el-option>
            </el-select>
          </div>
          <div class="form-item">
            <div class="form-item-label">删除标记：</div>
            <el-select v-model="formData.is_delete" placeholder="全部" @change="search">
              <el-option value="">全部</el-option>
              <el-option v-for="item in deleteStatus" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </div>
          <el-button type="primary" size="small" style="margin-left: 10px" @click="search">查询
          </el-button>
          <el-button size="small" @click="resetForm" plain>重置</el-button>


        </div>

        <!-- 筛选“删除标记”为已标记的数据后方可批量删除。注意，上传时间范围不得超过31天。 -->
        <div class="fr">
          <el-button @click="deleteFn" :disabled="formData.is_delete !== true" type="text" plain
            class="btnBox ml10i">删除</el-button>
          <el-button class="ml10 iconfont-btn" v-popover:popover type="text">
            <!-- <i class="iconfont" style="color:#303333">&#xe628;</i> -->
            <i class="el-icon-question clr_ef89"></i>

          </el-button>
          <el-popover ref="popover" placement="right" width="300" trigger="hover">
            <div class="mr10 ml10 mt10 mb10">
              <span> 筛选“删除标记”为已标记的数据后方可批量删除。注意，上传时间范围不得超过31天。</span>
            </div>
          </el-popover>
        </div>
      </div>

    </div>
    <div class="table-container" v-bind:class="{ 'noTableData': tableData.length == 0 }">
      <el-table ref="mytable" :data="tableData" border stripe height="calc(100% - 57px)"
        :header-cell-style="{ background: '#F2F2F2', color: '#333' }" highlight-current-row header-row-class-name="strong"
        :row-key="getRowKeys"
        v-loading="loading" element-loading-text="拼命加载中" element-loading-background="rgba(255,255,255,0.6)"
        @select="tableSignleSelection" @select-all="tableAllSelection">
        <el-table-column fixed="left" type="selection" :reserve-selection="true"></el-table-column>

        <el-table-column label="序号" min-width="80">
          <template slot-scope="scope">
            <span>{{ (page_index - 1) * page_size + scope.$index + 1 }}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="170">
          <template slot-scope="scope">
            <span class="clr_0a pointer" :class="{ 'btn-disabled': scope.row.is_delete }"
              @click="browse(scope.row)">浏览</span>
            <span class="clr_da pointer pl10" :class="{ 'btn-disabled': scope.row.is_delete }"
              @click="deleteDoc(scope.row)">删除</span>
          </template>
        </el-table-column>
        <el-table-column prop="upload_time" label="上传时间" width="180"></el-table-column>
        <el-table-column prop="file_name" label="文档名称" width="250" show-overflow-tooltip></el-table-column>
        <el-table-column prop="format_code" label="文档类型" width="100" show-overflow-tooltip></el-table-column>
        <el-table-column prop="file_size_desc" label="文档大小" width="120"></el-table-column>
        <el-table-column prop="business_type_name" label="业务类型" width="90"></el-table-column>
        <el-table-column prop="modality" label="检查类型" width="90"></el-table-column>
        <el-table-column prop="depart_name" label="所属科室" width="90"></el-table-column>
        <el-table-column prop="org_name" label="所属机构" width="200" show-overflow-tooltip></el-table-column>
        <el-table-column prop="device_name" label="存储设备" width="140"></el-table-column>
        <el-table-column prop="is_delete" label="删除标记" width="120">
          <template slot-scope="scope">
            <span :class="{ 'span-isdelete': scope.row.is_delete }">{{ scope.row.is_delete ? '已标记' : '未标记' }}</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="pageDiv">
        <pagination-tool :total="total" :page.sync="page_index" :limit.sync="page_size" @pagination="getDocuments" />
      </div>
    </div>

    <!-- 删除 -->
    <el-dialog v-el-drag-dialog v-if="delDialog" title="提示" :visible.sync="delDialog" width="580px" top="31vh"
      :before-close="handleClose">
      <div class="pt20">
        <div class="pb10 pl10" style="border-bottom: 1px dashed #cccccc;">
          <span>{{ delDialogTitle }}</span>
        </div>

      </div>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="handleClose">取消</el-button>
        <el-button size="small" type="primary" @click="handleSure">确定</el-button>
      </span>
    </el-dialog>
    <!-- 进度条 -->
    <div class="progressClass">
      <el-dialog v-el-drag-dialog v-if="delPDialog" :show-close="false" title="" :visible.sync="delPDialog" width="580px"
        top="31vh" :before-close="handleClose">
        <div class="pt10 ">
          <div class="pb10 pl10 of progressContent">
            <span class="">文档删除中</span>
            <el-progress class="progress-file " :percentage="percentage"></el-progress>

            <!-- <el-button class="" size="small" @click="progressClose">取消</el-button> -->

          </div>

        </div>
      </el-dialog>
    </div>

  </div>
</template>
<script>
import moment from 'moment'
import SearchTime from '@/components/common/SearchTime'
import PaginationTool from '@/components/common/PaginationTool' // 分页
import { getAllDomains, getDocumentListTotalize, getDomainDeviceList, getDocuments, deleteDocument, getDocumentUrl, deleteTaggedDocument,  deleteTaggedDocumentProgress } from '@/api/memorySharing/dataMemory'
import { getDistinfoByType, getInstitutionListLite, getOfficesLite } from '@/api/commonHttp'
export default {
  components: { PaginationTool, SearchTime },
  data() {
    return {
      progressInterval:null,
      front_id:'',
      percentage: 10,
      delPDialog: false,
      delDialogTitle: '确定要删除',
      delDialog: false,
      currentTableChecked: [],
      clearTime: false, // 清除查询时间
      total: 0,
      value: '',
      selectedDomain: {},
      domainInfo: {},
      domains: [],
      formData: {
        domain_id: '',
        business_type: '',
        modality: '',
        device_id: '',
        org_code: '',
        depart_code: '',
        is_delete: '',
        begin_upload_time: '',
        end_upload_time: '',
      },
      page_index: 1,
      page_size: 20,
      loading: false,
      tableData: [],
      examineTypeList: [],
      documentBusinessTypeList: [],
      institutionList: [],
      domainDeviceList: [],
      officesLite: [],
      deleteStatus: [
        {
          value: true,
          label: '已标记'
        },
        {
          value: false,
          label: '未标记'
        }
      ]
    }
  },
  watch: {
    'formData.domain_id'(val) {
      if (val) {
        this.search()
      }
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    getRowKeys (row) {
      return row.id
    },
    getUuid() {
      let _time = new Date().getTime();
      let guid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        let r = (_time + Math.random() * 16) % 16 | 0;
        _time = Math.floor(_time / 16);
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
      });

      return guid;
    },
    closeSession() {
      this.currentTableChecked = []
      this.$nextTick(() => {
        this.$refs.mytable.clearSelection()
      })
    },
    tableSignleSelection(rows, row) {
      // console.log("重新点击",rows);
      this.currentTableChecked = rows
    },
    tableAllSelection(rows) {
      this.currentTableChecked = rows

    },
    deleteFn() {
      if (this.formData.begin_upload_time === '' && this.formData.end_upload_time === '') {
        this.$message.error('请选择上传时间！')
        return
      }
      if (this.formData.begin_upload_time === '' || this.formData.end_upload_time === '') {
        this.$message.error('上传时间范围不得超过31天，请重新选择上传时间！')
        return
      }
      if (moment(this.formData.end_upload_time).diff(moment(this.formData.begin_upload_time), 'days') > 31) {
        this.$message.error('上传时间范围不得超过31天，请重新选择上传时间！')
        return
      }
      if (this.currentTableChecked.length === 0) {
        this.$message.error('请选择需要删除的数据！')
        return
      }
      let beginDate = moment(this.formData.begin_upload_time).format('yyyy-MM-DD')
      let endDate = moment(this.formData.end_upload_time).format('yyyy-MM-DD')

      if (this.currentTableChecked.length === 1) {
        this.delDialogTitle = `确认删除${this.currentTableChecked[0].file_name}吗？`

      } else {
        this.delDialogTitle = `确认删除${beginDate}至${endDate}内的${this.currentTableChecked.length}条文档吗？`
      }

let _this = this
      this.$confirm(this.delDialogTitle, '提示', {
        confirmButtonText: '确认',
        cancelButtonText: '取消',
        type: 'warning',
        // center: true,
        dangerouslyUseHTMLString: true,
        distinguishCancelAndClose: true,
      }).then((action) => {
        //确定
        _this.delPDialog = true
        _this.front_id = this.getUuid()
        let ids = _this.currentTableChecked.map(e=>e.id)
      deleteTaggedDocument({front_id:_this.front_id,documents:ids}).then(res => {
          if (res.code === 0) {
            _this.$message.success('删除请求成功')
            _this.progressInterval = setInterval(() => {
              _this.getDelDocumentProgress()
            }, 1000);
          } else {
            _this.$message.error(res.msg)
          }
        })

      }).catch((action) => {

      });

      // this.delDialog = true



    },
    getDelDocumentProgress(){
      let _this = this

      deleteTaggedDocumentProgress({front_id:this.front_id}).then(res=>{
        if (res.code === 0) {
          _this.percentage = Math.round(res.data / _this.currentTableChecked.length * 100) 
          if(res.data === _this.currentTableChecked.length){
            _this.delPDialog = false
            clearInterval(_this.progressInterval)

            _this.search()
            _this.closeSession()
            _this.percentage = 0

          }

          } else {
            this.$message.error(res.msg)
          }
      })

    },
    //deleteTaggedDocumentProgress
    handleClose() {
      this.delDialog = false

    },
    handleSure() {
      this.delDialog = false

    },
    progressClose() {
      //取消删除
      this.delPDialog = false
    },
    getTimes(val) {
      this.clearTime = false

      this.formData.begin_upload_time = val ? val[0] : "";
      this.formData.end_upload_time = val ? val[1] : "";
      this.search()
    },
    selectDomain(item) {
      this.selectedDomain = item
      this.formData.domain_id = item.id
      this.getDomainDeviceList()

    },
    resetForm() {
      const { domain_id } = this.formData
      this.formData = {
        domain_id,
        business_type: '',
        modality: '',
        device_id: '',
        org_code: '',
        depart_code: '',
        is_delete: '',
        begin_upload_time: '',
        end_upload_time: '',
      }
      this.clearTime = true
      this.search()
    },
    search() {
      this.closeSession()
      this.page_index = 1
      this.getDocumentListTotalize()
      this.getDocuments()
    },
    browse(doc) {
      // const { id, business_id, business_type_name } = doc
      // const { href } = this.$router.resolve({
      //   name: 'FileViewIndex',
      //   query: { businessId: business_id, businessType: business_type_name, id: id }
      // })
      // window.open(href, '_blank')

      
      const { id, business_id, business_type_name } = doc
      const { href } = this.$router.resolve({
        name: 'ofdViewIndex',
        query: { businessId: business_id, businessType: business_type_name, id: id }
      })
      window.open(href, '_blank')

    },
    deleteDoc(doc) {
      const { id, file_name, is_delete } = doc
      if (is_delete) {
        return
      }
      const text = `确认删除${file_name}吗？`
      this.$confirm(text, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteDocument(id).then(res => {
          if (res.code === 0) {
            this.$message.success('删除成功')
            this.getDocuments()
          } else {
            this.$message.error(res.msg)
          }
        })
      })

    },
    async init() {
      this.getDistinfoByType()
      await this.getAllDomains()
      this.getDomainDeviceList()
      this.getInstitutionListLite()
    },
    // 获取所有存储域
    getAllDomains() {
      return new Promise((resolve, reject) => {
        getAllDomains().then(res => {
          if (res.code === 0) {
            this.domains = res.data
            if (this.domains.length > 0) {
              this.selectedDomain = this.domains[0]
              this.formData.domain_id = this.domains[0].id
            }
          } else {
            this.$message.error(res.msg)
          }
          resolve()
        }).catch(error => {
          reject(error)
        })
      })
    },
    // 获取存储域详情
    getDocumentListTotalize() {
      const params = this.formData
      getDocumentListTotalize(params).then(res => {
        if (res.code === 0) {
          this.domainInfo = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 获取业务类型、检查类型字典
    getDistinfoByType() {
      const _parmas = 'ExamineType,DocumentBusinessType'
      const url = `/dict/${_parmas}`
      getDistinfoByType(url).then(res => {
        if (res.code === 0) {
          this.examineTypeList = res.data.filter(item => item.lookup_key === 'ExamineType')
          this.documentBusinessTypeList = res.data.filter(item => item.lookup_key === 'DocumentBusinessType')
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 获取存储域下的检查设备
    getDomainDeviceList() {
      const data = {
        id: this.formData.domain_id
      }
      getDomainDeviceList(data).then(res => {
        if (res.code === 0) {
          this.domainDeviceList = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 获取机构列表
    getInstitutionListLite() {
      getInstitutionListLite().then(res => {
        if (res.code === 0) {
          this.institutionList = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 改变机构选择组件的选中值
    orgCodeChange(value) {
      this.formData.depart_code = ''
      if (value) {
        this.getOfficesLite(value)
      } else {
        this.officesLite = []
      }
    },
    // 获取机构下的科室列表
    getOfficesLite(value) {
      const idx = this.institutionList.findIndex(item => item.code === value)
      let id = ''
      if (idx !== -1) {
        id = this.institutionList[idx].id
      }
      var _url = '/offices/lite?institution_id=' + id
      getOfficesLite(_url).then(res => {
        if (res.code === 0) {
          this.officesLite = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    getDocuments() {
      this.loading = true
      const page = {
        page_index: this.page_index,
        page_size: this.page_size
      }
      const params = Object.assign({}, this.formData, page)
      getDocuments(params).then(res => {
        //console.log(res)
        this.loading = false
        if (res.code === 0) {
          this.tableData = res.data || []
          this.total = res.page.total_count || 0
        }
      }).catch(error => {
        this.loading = false
      })
    }
  }
}
</script>
<style lang="less" scoped>
.form-container {
  padding: 10px 15px 0;
}

.form-row {
  display: flex;
  margin-bottom: 8px;

  &:first-child {
    margin-bottom: 15px;
  }
}

::v-deep .type-select {
  height: 40px;

  .el-dropdown {
    font-size: 15px;
    height: 40px;
    line-height: 40px;
    color: #303133;
    width: 275px;
    cursor: pointer;
  }
}

.data-cell {
  height: 40px;
  display: flex;
  align-items: center;
  margin-left: 15px;
  border-radius: 3px;

  &-wendang {
    border: 1px solid #c3e9ba;
  }

  &-wendang>&-icon {
    background: #D9F5D6;
  }

  &-wendang>&-content {
    border-left: 1px solid #c3e9ba;
  }

  &-wendang &-text {
    color: #19B955;
  }

  &-biaoji {
    border: 1px solid #ffdbb2;
  }

  &-biaoji>&-content {
    border-left: 1px solid #ffdbb2;
  }

  &-biaoji>&-icon {
    background: #FFECD6;
  }

  &-biaoji &-text {
    color: #E6A23C;
  }

  &-icon {
    width: 40px;
    height: 100%;
    line-height: 38px;
    text-align: center;
  }

  .iconwendangzongshu {
    color: #19B955;
    font-size: 20px;
  }

  .iconbiaojishanchu {
    color: #E6A23C;
    font-size: 20px;
  }

  &-content {
    min-width: 233px;
    height: 100%;
    padding: 0 15px;
    line-height: 38px;
  }

  &-label {
    color: #303133;
  }
}

.iconfont-btn {
  font-size: 18px;

  .iconfont {
    font-size: 18px;

  }
}

.progressClass {
  .progressContent {
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    align-items: center;
    min-height: 80px;
  }

  ::v-deep .el-dialog__header {
    height: 0px;
  }

  ::v-deep .el-dialog__body {
    border-radius: 10px;
  }

  .progress-file {
    margin-left: 10px;
    width: calc(100% - 150px);
  }

  .el-button {
    border: none;
    color: #0a70b0;

    &:hover,
    &:focus {
      background-color: transparent;
    }
  }
}

.btnBox {
  width: 70px;
  height: 32px;
  color: #ff6f6f;
  background-color: #fff;
  border: 1px solid #ff6f6f;
  padding: 0;

  &:hover,
  &:focus {
    border: 1px solid #ff6f6f;
    color: #ff6f6f;
    background-color: #fff;

  }
}

.form-item-long {

  width: 310px !important;
  // &-label {
  //   width: 75px;
  // }

  // &+& {
  //   margin-left: 15px;
  // }
  ::v-deep .el-date-editor--daterange {
    width: 100%;
  }
  ::v-deep .el-date-editor .el-range-input {
    width:50%;
  }
  ::v-deep .el-date-editor .el-range__close-icon{
    line-height: 26px;
  }
}

.form-item {
  display: flex;
  align-items: center;
  width: 275px;
  justify-content: space-between;

  &-label {
    width: 75px;
  }

  &+& {
    margin-left: 15px;
  }
}

.table-container {
  position: relative;
  height: calc(100% - 200px);
  margin: 0 15px;

  ::v-deep .el-table {
    overflow: auto;

    &::before {
      height: 0;
    }
  }
}

.pageDiv {
  border: 1px solid #ebeef5;
  border-top: 0;
}

.span-isdelete {
  color: #FF9900;
}

.btn-disabled {
  color: #c0c4cc;
  cursor: not-allowed;
}</style>
