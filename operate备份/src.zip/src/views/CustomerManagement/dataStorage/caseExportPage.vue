<template>
  <div class="caseExportCon">
    <div class="title-bar flex_row">
      <div class="crumbsCon">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>
          病例导出
          <i v-if="tabList.length != 0"
            class="iconfont iconzhankaishouqi"
          ></i>
        </span>
        <div class="tabCon" v-if="tabList.length != 0">
          <el-tabs v-model="tabValue">
            <el-tab-pane v-for="(item,index) in tabList" :key="index" :label="item.name" :name="item.state"></el-tab-pane>
          </el-tabs>
        </div>
      </div>
      <div class="tr col operateCon" v-if="showExportManageBtn">
        <span class="operate-btn clr_0a importInstituteBtn" @click="importOutManager()"><i class="iconfont icondaochuguanli mr5"></i>导出管理</span>
      </div>
    </div>

    <caseExportApply v-if="tabValue == '1'"></caseExportApply>
    
    <caseExport v-if="tabValue == '2'"></caseExport>

  </div> 
</template>
<script>
import caseExportApply from "./caseExportApply";
import caseExport from "./caseExport";
import { getIsCheckAuth } from "@/api/platform_costomer/caseExport";
export default {
   components: {
     caseExportApply,
     caseExport,
   },
   data () {
    return {
      tabValue: '1',
      tabList: [],
      showExportManageBtn: false,
    }
  },
  methods: {
    // 点击导入管理
    importOutManager () {
      const path = process.env.NODE_ENV === "development" ? "/" : "/operate/";
      
      let newPath = ''
      if (this.$route.name == 'caseExportAllPage') { // 客户管理员
        newPath = `${path}dataStorage/caseExportManage`
      } else {// 业务系统嵌套(不需要菜单)
        newPath = `${path}caseExportManage`
      }
      this.$router.push({
        path: newPath,
        //query: { id: row.id },
      });
    },
   // 获取 是否有审核权限
   async beganGetIsCheckAuth () {
      const self = this
      self.tabList = []
      const res = await getIsCheckAuth();
      if (res.code === 0) {
        if (res.data) {
          self.tabValue = '2'
          self.tabList.unshift({name: '我申请的',state: '1',})
          self.tabList.unshift({name: '我审批的',state: '2',}) 
        }
      } else {
        this.$message.error(res.msg);
      }
   },
  },
  mounted() {
    if (this.$route.name == 'caseExportAllPage') {
      this.showExportManageBtn = true
    }
    // 获取 是否有审核权限
    this.beganGetIsCheckAuth()
  },
  beforeDestroy() {
    localStorage.removeItem("importProgressData")
  },
}
</script>
<style lang="less" scoped>
.crumbsCon {
  display: flex;
  ::v-deep .tabCon {
    .el-tabs__item{
      padding-right: 10px;
      padding-left: 10px;
      // margin-right: 10px; // 加了margin 点击切换tab时底部的线移动会有偏差(会不包含margin)
      font-size: 14px;
      font-weight: 600;
    }
    .el-tabs__nav-wrap::after{//由于外面有加所以这里特殊去掉
      display: none;
    }
  }
}
.importInstituteBtn{
  border: 1px solid #DCDFE6;
  border-radius: 3px;
  padding: 5px 10px;
  cursor: pointer;
}
.caseExportCon{
  height:100%;
}
</style>