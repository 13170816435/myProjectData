<template>
  <div class="file-container">
    <div class="side-nav" :class="{ 'side-nav-collapse': isCollapse }">
      <div class="side-nav-header">
        <div class="side-nav-header-text" v-show="!isCollapse">
          {{ businessType
          }}{{ selectedFile.modality ? "_" + selectedFile.modality : "" }}
        </div>
        <div class="side-nav-header-btn" @click="isCollapse = !isCollapse">
          <i :class="isCollapse ? 'el-icon-s-unfold' : 'el-icon-s-fold'"></i>
        </div>
      </div>
      <el-scrollbar>
        <el-menu
          class="el-menu-vertical-demo"
          :collapse="isCollapse"
          :collapse-transition="false"
          :default-active="selectedFile.id"
          @select="selectFile"
        >
          <el-submenu
            :index="item.id"
            v-for="item in fileMenus"
            :key="item.id"
            v-if="item.children.length !== 0"
            popper-class="file-menu-popover"
          >
            <template slot="title">
              <i class="iconfont" :class="item.icon"></i>
              <span slot="title"
                >{{ item.title }}({{ item.children.length }})</span
              >
            </template>
            <el-menu-item-group>
              <el-menu-item
                v-for="file in item.children"
                :index="file.id"
                :key="file.id"
                :title="file.file_name"
              >
                {{ file.file_name }}
                <span class="downLoadBtn" @click.stop="readyDownLoadFile(file)"
                  ><i class="el-icon-download" title="下载"></i
                ></span>
              </el-menu-item>
            </el-menu-item-group>
          </el-submenu>
        </el-menu>
      </el-scrollbar>
    </div>
    <div class="iframe-container">
      <iframe :src="iframeUrl" frameborder="0"></iframe>
    </div>
  </div>
</template>
<script>
import {
  getDocumentsByBusiness,
  getDocumentUrl,
  getDocumentUrlByShortChain,
  downloadFile,
  getReportDetails,
  getDocumentId,
} from "@/api/memorySharing/dataMemory";
export default {
  data() {
    return {
      id: "",
      businessId: "",
      businessType: "",
      fileList: [],
      fileMenus: [
        {
          id: "DICOMDIR",
          title: "影像",
          icon: "iconyingxiang",
          children: [],
        },
        {
          id: "SECTION",
          title: "病理切片",
          icon: "iconbingli",
          children: [],
        },
        {
          id: "AECG",
          title: "心电波形",
          icon: "iconxindianboxing",
          children: [],
        },
        {
          id: "MP4",
          title: "视频",
          icon: "iconshipin",
          children: [],
        },
        {
          id: "JPG",
          title: "图片",
          icon: "icontupian",
          children: [],
        },
        {
          id: "other",
          title: "其他",
          icon: "iconqita",
          children: [],
        },
      ],
      iframeUrl: "",
      selectedFile: {},
      shortChain: "",
      isCollapse: false,
    };
  },
  watch: {
    selectedFile: {
      deep: true,
      handler(val) {
        const { id } = val;
        this.getDocumentUrl(id);
      },
    },
    shortChain(val) {
      const baseUrl =
        process.env.NODE_ENV === "development"
          ? window.location.host
          : configUrl.frontEndUrl;
      // this.iframeUrl = baseUrl + '/s/' + val
      this.iframeUrl = baseUrl + "/" + val;
    },
  },
  mounted() {
    this.id = this.$route.query.id;
    this.businessId = this.$route.query.businessId;
    this.businessType = this.$route.query.businessType;
    this.getDocumentsByBusiness();
    this.setBrowserTit();
  },
  methods: {
    setBrowserTit() {
      const platFormName = sessionStorage.getItem("platFormName");
      const checkName = sessionStorage.getItem("CheckMemuname");
      document.title = platFormName + "-" + checkName;
    },
    selectFile(id) {
      console.log(123);
      if (id === this.selectedFile.id) {
        return;
      }
      const idx = this.fileList.findIndex((item) => item.id === id);
      this.selectedFile = this.fileList[idx];
    },
    getDocumentsByBusiness() {
      const params = {
        businessId: this.businessId,
      };
      getDocumentsByBusiness(params).then((res) => {
        if (res.code === 0) {
          let fileMenus = this.fileMenus;
          res.data.forEach((item) => {
            let type = item.format_code;
            const idx = fileMenus.findIndex((fileMenu) => fileMenu.id === type);
            if (idx === -1) {
              fileMenus[fileMenus.length - 1].children.push(item);
            } else {
              fileMenus[idx].children.push(item);
            }
          });
          console.log(fileMenus);
          const idx = res.data.findIndex((item) => item.id === this.id);
          this.selectedFile = res.data[idx];
          this.fileMenus = fileMenus;
          this.fileList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    getDocumentUrl(id) {
      getDocumentUrl(id).then((res) => {
        if (res.code === 0) {
          //this.shortChain = res.data
          getDocumentUrlByShortChain(res.data).then((res) => {
            if (res.code === 0) {
              if (res.data.url == "") {
                // 说明该文件不能浏览
                this.$confirm(
                  '<i class="iconfont icontishi clr_e6 mr5"></i>非常抱歉，当前文件不支持浏览',
                  "浏览文件",
                  {
                    distinguishCancelAndClose: true,
                    dangerouslyUseHTMLString: true,
                    // confirmButtonText: '确定',
                    // cancelButtonText: '取消'
                  }
                ).then(() => {
                  this.sureUnBindCa();
                });
              } else {
                this.shortChain = res.data.url;
              }
            } else {
              this.$message.error(res.msg);
            }
          });
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 文件下载所需函数
    async readyDownLoadFile(row) {
      const res = await getDocumentId({
        document_id: row.id,
      });
      if (res instanceof ArrayBuffer) {
        const decoder = new TextDecoder("utf-8");
        const text = decoder.decode(new Uint8Array(res));
        try {
          // 尝试解析为 JSON
          const json = JSON.parse(text);
          // 判断是否为错误信息
          if (json && json.Msg) {
            // 这里可以拿到后台返回的错误提示
            this.$message.error(json.Msg);
            return;
          }
        } catch (e) {
          // 不是 JSON，说明是正常的二进制文件
          // 下载文件
          let blob = new Blob([res], {
            //下载的文件类型；
            type: row.mime_type,
          });
          if (window.navigator.msSaveOrOpenBlob) {
            // 兼容ie
            navigator.msSaveBlob(blob, row.file_name);
            navigator.msSaveBlob(blob);
          } else {
            var link = document.createElement("a");
            link.href = window.URL.createObjectURL(blob);
            link.download = row.file_name;
            link.click();
            window.URL.revokeObjectURL(link.href); //释放内存
          }
        }
      }
      // getDocumentUrl(row.id).then(res => {
      //   if(res.code === 0) {
      //     getDocumentUrlByShortChain(res.data).then(res => {
      //       if(res.code === 0) {
      //         if (res.data.url == '') { // 说明该文件不能浏览
      //           this.$confirm('<i class="iconfont icontishi clr_e6 mr5"></i>非常抱歉，当前文件不支持浏览', '浏览文件', {
      //           distinguishCancelAndClose: true,
      //           dangerouslyUseHTMLString: true,
      //           // confirmButtonText: '确定',
      //           // cancelButtonText: '取消'
      //         }).then(() => {
      //           //this.sureUnBindCa()
      //         })
      //         } else {
      //           this.beganGetReportDetails(res.data.hash_id,row)
      //         }
      //       } else {
      //         this.$message.error(res.msg)
      //       }
      //     })
      //   }else {
      //     this.$message.error(res.msg)
      //   }
      // })
    },
    // // 文件下载所需函数
    // async beganGetReportDetails(accessId,row) {
    //   let params = {
    //     // accessId: 'cCcMVxFadYv', // 图片
    //     accessId: accessId, // pdf
    //     bussinessId: ''
    //   }
    //   let res = await getReportDetails(params)
    //   let { Code, Data } = res
    //   if(Code === 0) {
    //     if(Data.Details.length > 0) {
    //       let { DeviceID, FilePath} = Data.Details[0]
    //       // let url = `${this.apiUrl}/api-imaging/File/Download?DeviceID=${DeviceID}&ImagePath=${FilePath}&MimeType=application/pdf`
    //       let fileRes = await downloadFile(DeviceID, FilePath,row.format_code)
    //       this.fileData = fileRes
    //       this.beganDownLoadFile(row)
    //     }else {
    //       this.$message({
    //         type: 'warning',
    //         message: '没有相关内容'
    //       })
    //     }
    //   } else {
    //     this.fileData = null
    //     this.$message({
    //       type: 'warning',
    //       message: res.Msg
    //     })
    //   }
    // },
    // // 准备下载文件
    // beganDownLoadFile (row) {
    //   if (this.fileData) {
    //     let blob = new Blob([this.fileData], {
    //       //下载的文件类型；
    //       type: `application/${row.format_code}`,
    //     });
    //     if (window.navigator.msSaveOrOpenBlob) {
    //       navigator.msSaveBlob(blob, row.file_name);
    //       navigator.msSaveBlob(blob);
    //     } else {
    //       var link = document.createElement("a");
    //       link.href = window.URL.createObjectURL(blob);
    //       link.download = row.file_name;
    //       link.click();
    //       window.URL.revokeObjectURL(link.href); //释放内存
    //     }
    //   }
    // }
  },
};
</script>
<style lang="less">
.file-menu-popover {
  .el-menu-item-group__title {
    display: none;
  }
}
</style>
<style lang="less" scoped>
.file-container {
  width: 100vw;
  height: 100vh;
  display: flex;
}
.side-nav {
  width: 240px;
  height: 100%;
  // background: #0A70B0;
  background: url("~@/assets/images/common/bg.png");
  &-collapse {
    width: 64px;
  }
  &-header {
    height: 56px;
    font-size: 22px;
    padding: 0 15px;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid rgba(255, 255, 255, 0.3);
    &-btn {
      height: 29px;
      margin-top: 2px;
      cursor: pointer;
    }
    i {
      font-size: 29px;
    }
  }
  ::v-deep .el-menu {
    background: #0a70b0;
    border-right: 0;
    .el-submenu {
      border-bottom: 1px solid rgba(255, 255, 255, 0.15);
    }
    .el-submenu__title {
      color: #fff;
      font-size: 14px;
      .iconfont {
        font-size: 20px;
        margin-right: 5px;
      }
    }
    .el-submenu__icon-arrow.el-icon-arrow-down {
      font-size: 16px;
    }
    .el-menu-item-group__title {
      display: none;
    }
    .el-menu-item {
      color: #fff !important;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
      &:focus {
        background: rgba(0, 0, 0, 0.15) !important;
      }
    }
    .el-menu-item.is-active {
      background: rgba(0, 0, 0, 0.15) !important;
      position: relative;
      &::before {
        content: "";
        position: absolute;
        left: 0;
        height: 100%;
        width: 5px;
        background: #ffa63b;
      }
    }
    .el-submenu__title:hover,
    .el-menu-item:hover {
      background: rgba(0, 0, 0, 0.15) !important;
    }
  }
}
.iframe-container {
  flex-grow: 1;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  iframe {
    width: 100%;
    height: 100%;
  }
}
.downLoadBtn {
  position: absolute;
  right: 10px;
  top: 0px;
  cursor: pointer;
}
</style>
