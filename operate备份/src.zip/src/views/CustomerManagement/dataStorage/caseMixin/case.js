import { getReportViewUrl, getViewUrl, importInspect } from "@/api/platform_costomer/caseExport";

const mixin = {
  data() {
    return {
      token: ''
    }
  },
  methods: {
    // 病例导出
    async caseImportOut (importParams,loading) {
      const self = this
      // iframe 页面 访问不到 云助手 里面window.iselectron
      window.iselectron = window.iselectron ?  window.iselectron : parent.window.iselectron
      console.log("window.iselectron",window.iselectron)
      // 测试数据
      const params = {
        "dto_list": [
            {
                "business_id": "1916414927630061568"
            },
            {
                "business_id": "1916415884736679936"
            }
        ],
        "batch_count": 1
      }
      const res = await importInspect(importParams)
      if (res.code === 0) {
        loading.close()
        const result = res.data
        // 重置导出病例 参数
        self.$store.commit('caseImport/RESET_IMPORT_OUT_PARAM')


      // for (let i = 0; i < result.length; i++) {
        
      //   // 获取导出病例进度
      //   self.$store.dispatch('caseImport/pollingGetImportOutProgressRate',
      //     { 
      //       total_count: result[i].total_count,key: result[i]&&result[i].task_key,
      //       allTotalCount: res.total_count
      //     }) // 开始轮询
      // }
      
      if (result.length != 0) {
        if (!window.iselectron) {
          await self.$store.dispatch('caseImport/pollingGetImportOutProgressRate',
          { 
            total_count: result[0].total_count,key: result[0]&&result[0].task_key,
            allTotalCount: res.total_count,
            result: result,
            isBeaganImport: true,
          }) // 开始轮询
        }
          
        // 如果是云助手环境下 新打开一个导出进度界面
        if (window.iselectron) {
          localStorage.setItem('importProgressData',JSON.stringify({ 
            total_count: result[0].total_count,
            key: result[0]&&result[0].task_key,
            allTotalCount: res.total_count,
            result: result,
            isBeaganImport: true,
            isSelectron: true,

            // total_count: 22,
            // key: "3b31401e-267f-4802-9566-1c1 d7b2a336b",
            // allTotalCount: 22,
            // result: [{task_key: "3b31401e-267f-4802-9566-1c1 d7b2a336b",total_count: 22}],
            // isBeaganImport: true,

          }))
          let basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
          let newHref = configUrl.frontEndUrl +`${basepath}/caseImportAlert`;
          window.open(newHref, "_blank");
        }
       }
      } else{
        loading.close()
        self.$message.error(res.msg)
      }
    },
    // 报告浏览
    async getReportUrl (row) {
      const res = await getReportViewUrl({type_code: 'Result',business_id: row.idcas_id});
      //const res = await getReportViewUrl({type_code: 'Result',business_id: "1910599906906869760"});
      if (res.code === 0) {
        const result = res.data
        if (result.length != 0) {
          result.forEach((item) => {
            let completeUrl = configUrl.frontEndUrl + "/s/" + item.view_url
            window.open(completeUrl)
          })
        } else {
          this.$message.error("没有找到相应的报告");
        }
      } else {
        this.$message.error(res.msg);
      }
    },
    // 获取影像浏览地址
    async getViewUrl(rowData) {
      const param = { 
        type_code: 'Image',
        business_id: rowData.idcas_id,
        patient_id: rowData.patient_id,
        accession_number: rowData.accession_number,
        has_image: true
      }
      const res = await getViewUrl(param);
      if (res.code === 0) {
        const result = res.data
        if (result) {
          let completeUrl = configUrl.frontEndUrl + "/s/" + result
          window.open(completeUrl)
        } else {
          this.$message.error("没有找到相应的影像");
        }
      } else {
        this.$message.error(res.msg);
      }
    },
  },
  mounted() {
  },
  filters: {
    // 获取含数字的字符串里面数字
    getStringNum(str) {
      if (str) {
        var num = str.replace(/[^0-9]/ig, '')
        return num
      }
    },
  }
}
export default mixin
