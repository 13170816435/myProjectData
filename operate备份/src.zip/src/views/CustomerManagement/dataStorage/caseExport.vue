<template>
  <div class="caseExportConBox">
    <!-- <div class="title-bar flex_row">
      <div class="crumbsCon">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>病例导出<i
            class="iconfont iconzhankaishouqi"
          ></i>
        </span>
        <div class="tabCon">
          <el-tabs v-model="searchData.apply_state" @tab-click="searchList">
            <el-tab-pane v-for="(item,index) in tabList" :key="index" :label="item.name" :name="item.state"></el-tab-pane>
          </el-tabs>
        </div>
      </div>
      <div class="tr col operateCon">
        <span class="operate-btn clr_0a importInstituteBtn" @click="importOutManager()"><i class="iconfont icondaochuguanli mr5"></i>导出管理</span>
      </div>
    </div> -->

    <div class="stateTab ml10 mt10">
      <el-radio-group v-model="searchData.apply_state" @change="searchList">
        <el-radio-button
          v-bind:label="item.state"
          v-for="(item, index) in tabList"
          :key="index"
          >{{ item.name }}</el-radio-button
        >
      </el-radio-group>
    </div>


    <div class="caseExportContainer">
      <caseConditionInquery :action="2" @getList="getList"></caseConditionInquery>
     <div class="caseExportContent">
      <div
        class="allInspect clear"
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-background="rgba(255,255,255,0.6)"
        v-bind:class="{ noTableData: tableData.length == 0 }"
      >
        <el-table
          :data="tableData"
          border
          stripe
          height="100%"
          ref="tableAutoScroll"
          highlight-current-row
          header-row-class-name="strong"
        >
          <el-table-column
            fixed="left"
            align="center"
            type="index"
            label="序号"
            width="55"
          >
            <template slot-scope="scope">
              <span>{{
                (searchData.offset - 1) * searchData.limit + scope.$index + 1
              }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="153" fixed="left">
            <template slot-scope="scope">
              <span class="passBtn pointer" :class="{'isCanAudit': !scope.row.is_allow_audit}"
               @click="beganCheckPass(scope.row)">通过
              </span>
              <span class="clr_da pointer pl10" :class="{'isCanAudit': !scope.row.is_allow_audit}" @click="checkNoPass(scope.row)">
                不通过
              </span>
              <span class="clr_0a pointer pl10" @click="watchExport(scope.row)">查看</span>
              <!-- <span class="clr_0a pointer pl10" :class="{'isCanExport': !scope.row.is_allow_export}" @click="beganImportOutCase(scope.row)">导出</span> -->
            </template>
          </el-table-column>
          <el-table-column
            prop="state"
            label="状态"
            :width="80"
            fixed="left"
          >
            <template slot-scope="scope">
              <span class="finishedStatu" v-if="scope.row.state === 2">{{scope.row.state | dealApplyState(baseInfo)}}</span>
              <span class="waitCheckStatu" v-else>{{scope.row.state | dealApplyState(baseInfo)}}</span>
            </template>
          </el-table-column>
          <el-table-column label="审批意见" width="180" prop="audit_reasons" fixed="left">
            <template slot-scope="scope">
                <el-tooltip
                  placement="top"
                  popper-class="reasonBox"
                >
                  <div slot="content">
                    <div class="allReason">
                      <div class="mb10" v-for="(item, index) in scope.row.audit_reasons" :key="index">
                        {{ item.name }}: {{ item.reason }}
                      </div>
                    </div>
                  </div>
                  <div class="reasonContent">
                    <span v-for="(item, index) in scope.row.audit_reasons" :key="index">
                      {{ item.name }}: {{ item.reason }}
                    </span>
                  </div>
                </el-tooltip>
            </template>
          </el-table-column>

          <common-table
            :propData="propData"
          />
        </el-table>
      </div>
      <div class="blockPage">
        <pagination-tool
          :total="totalImportOutNum"
          :page.sync="searchData.offset"
          :limit.sync="searchData.limit"
          @pagination="beganGetImportOutList"
        />
      </div>
    </div>
  </div>


    <!--审核不通过-->
    <el-dialog
      :title="checkNoPassTit"
      class="finishOrderAlert"
      :visible.sync="showCheckNoPassAlert"
      width="500px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <caseCheckNoPassAlert :caseCheckNoPassParam="caseCheckNoPassParam"></caseCheckNoPassAlert>
      <div class="dialog_footer">
        <el-button size="small" plain @click="showCheckNoPassAlert = false"
          >取消</el-button
        >
        <el-button type="primary" size="small" @click="sureCheckNoPass"
          >确定</el-button
        >
      </div>
    </el-dialog>

    <!-- 详情 -->
    <el-drawer
    size="880"
    :modal="false"
    :visible.sync="drawer"
    :show-close="false"
    :withHeader="false"
    :direction="direction"
    :before-close="handleClose"
  >
    <caseDetail
      ref="caseDetail"
      :key="key"
      @closeFn="closeFn"
    ></caseDetail>
  </el-drawer>

  </div> 
</template>
<script>
import caseMixin from './caseMixin/case'
import { mapGetters } from 'vuex'
import caseConditionInquery from "./components/caseConditionInquery";
import CommonTable from './components/caseTable'
import PaginationTool from '@/components/common/PaginationTool'
import caseDetail from './components/caseDetail'
import caseCheckNoPassAlert from './components/caseCheckNoPassAlert'
import { getAuthStateTotal,getAuditList, exportAudit, getIsHasImageData, caseCheckNoPass, checkPass } from "@/api/platform_costomer/caseExport";
export default {
   components: {
    caseConditionInquery,
    CommonTable,
    PaginationTool,
    caseDetail,
    caseCheckNoPassAlert
   },
   computed: {
    ...mapGetters({
      // 获取store查询枚举条件
      baseInfo: "enumerations",
    }),
  },
  mixins: [caseMixin],
   data () {
    return {
      tabIndex: 0,
      number: 0,
      tabList: [
        // {
        //   label: "全部",
        //   value: 1,
        // },
        // {
        //   label: "待审批",
        //   value: 2,
        // },
        // {
        //   label: "已完成",
        //   value: 3,
        // },
      ],
      loading:false,
      searchData: {
        apply_state: '',
        offset: 1,
        limit: 20,
      },
      totalImportOutNum: 0,
      tableData: [],
      // 表头字段
      propData: [
        { prop: "examine_count", label: "检查数量", width: 90 },
        { prop: "apply_user_name", label: "申请人", width: 90 },
        { prop: "reason", label: "申请事由", width: 100 },
        { prop: "create_time", label: "申请时间", width: 170 },
        { prop: "office_names", label: "申请科室", width: 80 },
        { prop: "institution_name", label: "所属机构", width: 200 },
        { prop: "observations_org_name", label: "检查机构", width: 200 },
        { prop: "observations_depart_names", label: "检查科室"}
      ],
      drawer: false,
      direction: "rtl",
      key: 0,
      checkNoPassTit: '审批不通过',
      showCheckNoPassAlert: false,
      caseCheckNoPassParam: {
        apply_id: '',
        state: -2,
        reason: '',
      },
    }
  },
  methods: {
    handleClose(done) {
      done();
    },
    closeFn() {
      this.drawer = false;
    },
    // 点击导入管理
    importOutManager () {
      const path = process.env.NODE_ENV === "development" ? "/" : "/operate/";
      this.$router.push({
        path: `${path}dataStorage/caseExportManage`,
        //query: { id: row.id },
      });
    },
    // 查看或审批
    watchExport (row) {
      const self = this
      self.drawer = true
      self.$nextTick(()=> {
        self.$refs.caseDetail.resetData()
        self.$refs.caseDetail.getCaseExportListByAuditId(row.id)
        self.$refs.caseDetail.beganGetCaseExportApplyLogs(row.id)
        self.$refs.caseDetail.beganGetImportImgCount()
      })
    },
    // 审核通过
    async beganCheckPass (row) {
      if (!row.is_allow_audit) {// 没有审核权限
        return false
      }
      const res = await exportAudit({apply_id: row.id, state: 1,});
      if (res.code === 0) {
        this.$message.success("审批已通过");
        this.beganGetImportOutList();
        this.beganGetAuthStateTotal()
      } else {
        this.$message.error(res.msg);
      }
    },
    // 审核不通过
    checkNoPass(row) {
      if (!row.is_allow_audit) {// 没有审核权限
        return false
      }
      this.caseCheckNoPassParam.apply_id = row.id
      this.caseCheckNoPassParam.reason =  ''
      this.showCheckNoPassAlert = true
    },
    // 确定审核不通过
    async sureCheckNoPass () {
      if (this.caseCheckNoPassParam.reason ==  '') {
        this.$message({ message: "请输入审批不通过的原因", type: "error" });
        return false;
      }
      const res = await exportAudit(this.caseCheckNoPassParam);
      if (res.code === 0) {
        this.showCheckNoPassAlert = false
        this.beganGetImportOutList();
        this.beganGetAuthStateTotal()
      } else {
        this.$message.error(res.msg);
      }
    },
    // 开始导出病例
    async beganImportOutCase (row) {
      const self = this
      // 不允许导出
      if (!row.is_allow_export) {
        return false
      }
      let noImageArr = [] // 没有影像的
      let exportItems = []
      const res = await getIsHasImageData({apply_id: row.id})
      if (res.code == 0) {
        const result = res.data || []
        if (result.length != 0) {
         result.forEach((item) => {
          if (item.has_image) {
            exportItems.push({business_id:item.idcas_id,patient_id: item.patient_id+ "_" + item.patient_name})
          }
          
          if (!item.has_image)  {
            noImageArr.push(item.accession_number)
          }
         })
       }

       if (exportItems.length == 0) {
          self.$message.error("没有可导出的影像文件");
          return false
        }

       if (noImageArr.length != 0) { // 都审批通过了但是没有影像
        const patientIdStr = noImageArr.join('、')
        self.$confirm(
        
          '当前记录中的 <span style="color: #0099ff;padding-right:5px;">' +
        patientIdStr + 
        "</span> "+noImageArr.length +" 条记录已经无影像文件," +
        "暂时不能导出",
        "提示",
        {
          confirmButtonText: "确认并导出其它",
          cancelButtonText: "取消",
          dangerouslyUseHTMLString: true,
          type: "warning",
        }
      )
       .then(() => {
         // 调用的是 caseMixin里面的方法
         self.caseImportOut(exportItems)
       })
       .catch(() => {});
      } else {
        // 调用的是 caseMixin里面的方法
        self.caseImportOut(exportItems)
      }


      } else {
        self.$message.error(res.msg);
      }

      

      
      // if (exportItems.length == 0) {
      //   self.$message.error("没有可导出的影像文件");
      //   return false
      // }


    },
    getList(obj) {
      this.searchData.begin_apply_time = obj.start_time;
      this.searchData.end_apply_time = obj.end_time;
      this.searchData.states = obj.states;
      this.searchData.apply_user_name = obj.keywords;
      this.searchData.observations_dept_ids = obj.observations_dept_ids
      this.searchData.offset = obj.offset;
      this.searchData.limit = obj.limit;
      if (this.$route.query.id) {
        this.searchData.id = this.$route.query.id;
      }
      this.beganGetImportOutList();
    },
    searchList () {
      this.searchData.offset = 1
      this.searchData.limit = 20
      this.beganGetImportOutList();
    },
    // 获取导出列表
    async beganGetImportOutList () {
      const self = this;
      self.loading = true
      const res = await getAuditList(self.searchData);
      if (res.code === 0) {
        self.loading = false;
        self.tableData = res.data || [];
        self.totalImportOutNum = res.page.total_count || 0;
      } else {
        self.loading = false;
        self.$message.error(res.msg);
      }
    },
    // 病例导出申请弹窗方法
    rowKey (row) {
      return row.id
    },
   // 获取状态统计
   async beganGetAuthStateTotal () {
      const self = this
      self.tabList = []
      const res = await getAuthStateTotal();
      if (res.code === 0) {
        const result = res.data
        let allCount = 0
        if (result.length != 0) {
          result.forEach((item) => {
            item.name = `${item.name}(${item.count})`
            allCount = allCount + item.count
            item.state = item.state.toString()
            self.tabList.push(item)
          })
        }
        self.tabList.unshift({name: `全部(${allCount})`,state: '',count: allCount,})
      
      } else {
        this.$message.error(res.msg);
      }
   },
  },
  mounted() {
    // 获取审核方的状态统计
    this.beganGetAuthStateTotal()
  },
  filters: {
    // 列表里面 状态的显示
    dealApplyState (val,baseInfo) {
      let stateStr = ''
      if (baseInfo && baseInfo.case_export_apply_state && baseInfo.case_export_apply_state.length != 0) {
        baseInfo.case_export_apply_state.forEach((item) => {
          if (item.value === val) {
           stateStr = item.name
          }
        })
      }
      return stateStr
    }
  }
}
</script>
<style lang="less" scoped>
.caseExportConBox{
  height: calc(100% - 56px);
}
.crumbsCon {
  display: flex;
}

::v-deep .stateTab{
  .el-radio-group {
  height: 32px;
  line-height: 30px;
  .el-radio-button__inner {
    height: 32px;
    line-height: 30px;
    // padding: 0 !important;
    // width: 56px;
    padding: 0 10px!important;
    text-align: center;
  }
   .el-radio-button__orig-radio:checked + .el-radio-button__inner {
    background-color: #0a70b0 !important;
    border-color: #0a70b0 !important;
   }
  }
}

.importInstituteBtn{
  border: 1px solid #DCDFE6;
  border-radius: 3px;
  padding: 5px 10px;
  cursor: pointer;
}
.caseExportContainer{
  height: calc(100% - 32px);
  .caseExportContent{
    padding: 0px 10px 10px 10px;
    height: calc(100% - 52px);
   .allInspect{
     height: calc(100% - 56px);
   }
   ::v-deep .el-table__body-wrapper{
    height: calc(100% - 40px);
    overflow-y: auto;
   }
 }
}
.blockPage {
  border: 1px solid #eee;
  border-top: none;
}
.passBtn{
  color:#1CB54A;
}
.finishedStatu{
  font-size: 14px;
  color: #606266;
}
.waitCheckStatu{
  font-size: 14px;
  color: #EF8900;
}
.isCanAudit,.isCanExport{
  font-size: 14px;
  color: #C0C4CC;
}
.reasonContent{
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
}
</style>