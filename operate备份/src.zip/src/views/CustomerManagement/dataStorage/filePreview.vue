<template>
  <div class="file-container">
    <div class="side-nav" :class="{ 'side-nav-collapse': isCollapse }">
      <div class="side-nav-header">
        <div
          class="side-nav-header-text ellipsis-style"
          :title="`${businessType}${
            selectedFile.modality ? '_' + selectedFile.modality : ''
          }`"
          v-show="!role && !isCollapse"
        >
          {{ businessType
          }}{{ selectedFile.modality ? "_" + selectedFile.modality : "" }}
        </div>
        <div class="side-nav-header-text" v-show="role && !isCollapse">
          平台运营
        </div>
        <div class="side-right">
          <span
            v-show="!isCollapse"
            class="download-all"
            @click.stop="downLoadAllFile"
            ><i
              v-if="!downloadLoading"
              class="el-icon-download"
              title="下载全部"
            ></i
            ><i v-else class="el-icon-loading" title="下载中..."></i
          ></span>
          <div class="side-nav-header-btn" @click="isCollapse = !isCollapse">
            <i :class="isCollapse ? 'el-icon-s-unfold' : 'el-icon-s-fold'"></i>
          </div>
        </div>
      </div>
      <el-scrollbar>
        <el-menu
          class="el-menu-vertical-demo"
          :collapse="isCollapse"
          :collapse-transition="false"
          :default-active="selectedFile.id"
          @select="selectFile"
        >
          <el-submenu
            :index="item.id"
            v-for="item in fileMenus"
            :key="item.id"
            popper-class="file-menu-popover"
            v-if="item.children.length !== 0"
          >
            <template slot="title">
              <i class="iconfont" :class="item.icon"></i>
              <span slot="title"
                >{{ item.title }}({{ item.children.length }})</span
              >
            </template>
            <el-menu-item-group>
              <el-menu-item
                v-for="file in item.children"
                :index="file.id"
                :key="file.id"
                :title="file.file_name"
                >{{ file.file_name
                }}<span class="downLoadBtn"
                  ><i
                    v-if="!downloadLoadingListMap[file.id]"
                    @click.stop="readyDownLoadFile(file)"
                    class="el-icon-download"
                    title="下载"
                  ></i
                  ><i
                    v-else
                    class="el-icon-loading"
                    title="下载中..."
                  ></i></span
              ></el-menu-item>
            </el-menu-item-group>
          </el-submenu>
        </el-menu>
      </el-scrollbar>
    </div>
    <div class="iframe-container">
      <!-- 本地实现的文件预览 -->
      <template
        v-if="
          [
            'docx',
            'xlsx',
            'pptx',
            'pdf',
            'ofd',
            'mp4',
            'bmp',
            'gif',
            'ico',
            'avi',
            'wmv',
          ].includes(fileType)
        "
      >
        <!---world docx 的预览   doc格式不支持--->
        <vue-office-docx
          v-if="fileType == 'docx'"
          :src="fileData"
          style="height: 100vh"
          @rendered="renderedHandler"
          @error="errorHandler"
        />

        <!---excel 的预览--->
        <div
          class="table-html-wrap"
          v-if="fileType == 'xlsx' && fileData && fileData.byteLength > 0"
        >
          <vue-office-excel
            :src="fileData"
            :options="excelOptions"
            style="height: 100vh"
            @rendered="renderedHandler"
            @error="errorHandler"
          />
        </div>

        <!---pptx 的预览--->
        <vue-office-pptx
          v-if="fileType == 'pptx'"
          :src="fileData"
          style="height: 100vh"
          @rendered="renderedHandler"
          @error="errorHandler"
        />

        <!---ptf 的预览--->
        <vue-office-pdf
          v-if="fileType == 'pdf'"
          :src="fileData"
          style="height: 100vh; width: 100%"
          @rendered="renderedHandler"
          @error="errorHandler"
        />

        <!---ofd 的预览--->
        <ofdView
          v-if="fileType == 'ofd'"
          :fileName="selectedFile.file_name"
          :fileId="id"
          :key="ofdKey"
        >
        </ofdView>

        <!--video的 浏览-->
        <videoView
          v-if="fileType.toLocaleLowerCase() === 'mp4'"
          :fileType="fileType"
          :key="ofdKey"
          :fileId="id"
        >
        </videoView>

        <!--其它格式的视频浏览,理论上能被ffmpeg转码的都能播放-->
        <otherVideoView
          v-if="['avi', 'wmv'].includes(fileType.toLocaleLowerCase())"
          :fileType="fileType"
          :key="ofdKey"
          :fileData="fileData"
        >
        </otherVideoView>

        <!----jpg、jpeg、png、bmp-->
        <imgView
          v-if="
            ['jpg', 'jpeg', 'png', 'bmp', 'gif', 'ico'].includes(
              fileType.toLocaleLowerCase()
            )
          "
          :fileName="selectedFile.file_name"
          :fileId="id"
          :fileType="fileType"
          :key="ofdKey"
        >
        </imgView>
      </template>
      <!-- 其他项目实现的预览 -->
      <template v-else>
        <iframe :src="iframeUrl" frameborder="0"></iframe>
      </template>
    </div>
  </div>
</template>
<script>
import ofdView from "./filePreviewComponent/ofdView";
import videoView from "./filePreviewComponent/videoView";
import otherVideoView from "./filePreviewComponent/otherVideoView";
import imgView from "./filePreviewComponent/imgView";
import { ref } from "vue";
//引入VueOfficeDocx组件
import VueOfficeDocx from "@vue-office/docx";
//引入相关样式
import "@vue-office/docx/lib/index.css";

//引入VueOfficeExcel组件
import VueOfficeExcel from "@vue-office/excel";
//引入相关样式
import "@vue-office/excel/lib/index.css";

//引入VueOfficePpt组件
import VueOfficePptx from "@vue-office/pptx";
// import '@vue-office/pptx/lib/index.css';

//引入VueOfficePdf组件
import VueOfficePdf from "@vue-office/pdf";
import {
  getDocumentsByBusiness,
  getDocumentUrl,
  getDocumentUrlByShortChain,
  getReportDetails,
  downloadFile,
  getOperateDocumentsByBusiness,
  getFileByDocumentId,
  getAllFileByBusinessId,
} from "@/api/memorySharing/dataMemory";
import { downLoadOfficialFile } from "@/api/platform_operate/systemset";
import moment from "moment";
export default {
  components: {
    VueOfficeDocx,
    VueOfficeExcel,
    VueOfficePptx,
    VueOfficePdf,
    ofdView,
    videoView,
    otherVideoView,
    imgView,
  },
  data() {
    return {
      // fileData: ref(''),
      fileData: "",
      //docx: 'http://static.shanhuxueyuan.com/test6.docx',
      docx: "http://qncdn.qkongtao.cn/lib/teamadmin/files/Hadoop2.7.1%E4%BC%AA%E5%88%86%E5%B8%83%E5%BC%8F%E9%9B%86%E7%BE%A4%E5%AE%89%E8%A3%85%E6%96%87%E6%A1%A3.docx",
      pptxUrl: "http://example.com/path/to/your/file.pptx", // 替换为 PPT 文件的实际路径
      fileType: "",
      fileUrl: "", //设置文档网络地址，可以是相对地址
      id: "",
      businessId: "",
      businessType: "",
      role: "",
      fileList: [],
      fileMenus: [
        {
          id: ["DICOMDIR"],
          title: "影像",
          icon: "iconyingxiang",
          children: [],
        },
        {
          id: ["SECTION"],
          title: "病理切片",
          icon: "iconbingli",
          children: [],
        },
        {
          id: ["AECG"],
          title: "心电波形",
          icon: "iconxindianboxing",
          children: [],
        },
        {
          id: ["MP4", "AVI", "WMV"],
          title: "视频",
          icon: "iconshipin",
          children: [],
        },
        {
          id: ["JPG"],
          title: "图片",
          icon: "icontupian",
          children: [],
        },
        {
          id: ["other"],
          title: "其他",
          icon: "iconqita",
          children: [],
        },
      ],
      iframeUrl: "",
      selectedFile: {},
      shortChain: "",
      isCollapse: false,
      excelOptions: {
        xls: false, //预览xlsx文件设为false；预览xls文件设为true
        minColLength: 0, // excel最少渲染多少列，如果想实现xlsx文件内容有几列，就渲染几列，可以将此值设置为0.
        minRowLength: 0, // excel最少渲染多少行，如果想实现根据xlsx实际函数渲染，可以将此值设置为0.
        widthOffset: 10, //如果渲染出来的结果感觉单元格宽度不够，可以在默认渲染的列表宽度上再加 Npx宽
        heightOffset: 10, //在默认渲染的列表高度上再加 Npx高
        beforeTransformData: (workbookData) => {
          return workbookData;
        }, //底层通过exceljs获取excel文件内容，通过该钩子函数，可以对获取的excel文件内容进行修改，比如某个单元格的数据显示不正确，可以在此自行修改每个单元格的value值。
        transformData: (workbookData) => {
          return workbookData;
        }, //将获取到的excel数据进行处理之后且渲染到页面之前，可通过transformData对即将渲染的数据及样式进行修改，此时每个单元格的text值就是即将渲染到页面上的内容
      },
      ofdKey: 0,
      downloadLoading: false,
      downloadLoadingListMap: {},
    };
  },
  watch: {
    selectedFile: {
      deep: true,
      handler(val) {
        const { id } = val;
        this.id = id;
        const arr = val.file_name.split(".");
        this.fileType = arr[arr.length - 1].toLocaleLowerCase();
        if (this.fileType == "xls") {
          this.excelOptions.xls = true;
        }
        this.ofdKey++;
        this.fileData = null;
        this.getDocumentUrl(id);
      },
    },
    shortChain(val) {
      const baseUrl =
        process.env.NODE_ENV === "development"
          ? window.location.host
          : configUrl.frontEndUrl;
      this.iframeUrl = baseUrl + "/" + val;
    },
  },
  created() {
    this.id = this.$route.query.id;
    this.businessId = this.$route.query.businessId;
    this.businessType = this.$route.query.businessType;
    this.fileType = this.$route.query.formatCode;
    this.role = this.$route.query.role;
    if (this.fileType == "xls") {
      this.excelOptions.xls = true;
    }
    this.getDocumentsByBusiness();
    this.setBrowserTit();
  },
  methods: {
    renderedHandler() {
      console.log("渲染完成");
    },
    errorHandler() {
      console.log("渲染失败");
    },
    setBrowserTit() {
      const platFormName = sessionStorage.getItem("platFormName");
      const checkName = sessionStorage.getItem("CheckMemuname");
      document.title = platFormName + "-" + checkName;
    },
    getRowsById(data, id) {
      let target = null;
      data.forEach((item) => {
        if (item.children.length) {
          item.children.forEach((el) => {
            if (el.id === id) {
              target = { ...el };
            }
          });
        }
      });
      return target;
    },
    selectFile(id) {
      if (id === this.selectedFile.id) {
        return;
      }
      let row = this.getRowsById(this.fileMenus, id);
      let arr = row.file_name.split(".");
      let type = arr[arr.length - 1].toLocaleLowerCase();
      if (
        ["avi", "wmv"].includes(type) &&
        window.location.protocol === "http:"
      ) {
        this.$message.warning(
          "该格式视频在http环境下无法播放，请升级到https环境，或点击下载按钮下载到本地播放。"
        );
        return;
      }
      const idx = this.fileList.findIndex((item) => item.id === id);
      this.selectedFile = this.fileList[idx];
    },
    async getDocumentsByBusiness() {
      const params = {
        businessId: this.businessId,
      };
      let res;
      if (this.$route.query.role) {
        // 运营管理的 内容管理 浏览
        res = await getOperateDocumentsByBusiness({ id: this.id });
      } else {
        res = await getDocumentsByBusiness(params);
      }
      if (res.code === 0) {
        this.downloadLoadingListMap = {};
        res.data.forEach((item) => {
          this.$set(this.downloadLoadingListMap, item.id, false);
        });
        if (this.$route.query.role) {
          // 运营返回的res.data 是个对象不是数组
          let fileMenus = this.fileMenus;
          let result = [];
          result.push(res.data);
          result.forEach((item) => {
            let type = item.format_code;
            const idx = fileMenus.findIndex((fileMenu) =>
              fileMenu.id.includes(type)
            );
            if (idx === -1) {
              fileMenus[fileMenus.length - 1].children.push(item);
            } else {
              fileMenus[idx].children.push(item);
            }
          });
          console.log(fileMenus);
          const idx = result.findIndex((item) => item.id.includes(this.id));
          this.selectedFile = result[idx];
          this.fileMenus = fileMenus;
          this.fileList = result;
        } else {
          // 客户管理
          let fileMenus = this.fileMenus;
          res.data.forEach((item) => {
            let type = item.format_code;
            const idx = fileMenus.findIndex((fileMenu) =>
              fileMenu.id.includes(type)
            );
            if (idx === -1) {
              fileMenus[fileMenus.length - 1].children.push(item);
            } else {
              fileMenus[idx].children.push(item);
            }
          });
          const idx = res.data.findIndex((item) => item.id.includes(this.id));
          this.selectedFile = res.data[idx];
          this.fileMenus = fileMenus;
          this.fileList = res.data;
        }
      } else {
        this.$message.error(res.msg);
      }
    },
    getDocumentUrl(id) {
      getDocumentUrl(id).then((res) => {
        if (res.code === 0) {
          getDocumentUrlByShortChain(res.data).then((res) => {
            if (res.code === 0) {
              if (res.data.url == "") {
                // 说明该文件不能浏览
                this.$confirm(
                  '<i class="iconfont icontishi clr_e6 mr5"></i>非常抱歉，当前文件不支持浏览',
                  "浏览文件",
                  {
                    distinguishCancelAndClose: true,
                    dangerouslyUseHTMLString: true,
                    // confirmButtonText: '确定',
                    // cancelButtonText: '取消'
                  }
                ).then(() => {
                  this.sureUnBindCa();
                });
              } else {
                this.shortChain = res.data.url;
                // 判断是不是影像，是影像的话就不用调后面的接口了，直接iframe展示
                if (res.data?.extras.includes("Image")) return;
                this.beganGetReportDetails(res.data.hash_id);
              }
            } else {
              this.$message.error(res.msg);
            }
          });
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    async beganGetReportDetails(accessId) {
      let params = {
        // accessId: 'cCcMVxFadYv', // 图片
        accessId: accessId, // pdf
        bussinessId: "",
      };
      let res = await getReportDetails(params);
      let { Code, Data } = res;
      if (Code === 0) {
        if (Data.Details.length > 0) {
          let { DeviceID, FilePath } = Data.Details[0];
          // let url = `${this.apiUrl}/api-imaging/File/Download?DeviceID=${DeviceID}&ImagePath=${FilePath}&MimeType=application/pdf`
          let fileRes = await downloadFile(DeviceID, FilePath, this.fileType);
          this.fileData = fileRes;
        } else {
          this.$message({
            type: "warning",
            message: "没有相关内容",
          });
        }
      } else {
        this.fileData = null;
        this.$message({
          type: "warning",
          message: res.Msg,
        });
      }
    },
    async readyDownLoadFile(row) {
      this.$set(this.downloadLoadingListMap, row.id, true);
      try {
        const res = await getFileByDocumentId({
          document_id: row.id,
          dicomdir: false,
        });
        this.$set(this.downloadLoadingListMap, row.id, false);
        if (res instanceof ArrayBuffer) {
          const decoder = new TextDecoder("utf-8");
          const text = decoder.decode(new Uint8Array(res));
          try {
            // 尝试解析为 JSON
            const json = JSON.parse(text);
            // 判断是否为错误信息
            if (json && json.Msg) {
              // 这里可以拿到后台返回的错误提示
              this.$message.error(json.Msg);
              return;
            }
          } catch (e) {
            // 不是 JSON，说明是正常的二进制文件
            // 下载文件
            let blob = new Blob([res], {
              //下载的文件类型；
              type: row.mime_type,
            });
            if (window.navigator.msSaveOrOpenBlob) {
              // 兼容ie
              navigator.msSaveBlob(blob, row.file_name);
              navigator.msSaveBlob(blob);
            } else {
              var link = document.createElement("a");
              link.href = window.URL.createObjectURL(blob);
              link.download = row.file_name;
              link.click();
              window.URL.revokeObjectURL(link.href); //释放内存
            }
          }
        }
      } catch (error) {
        this.$set(this.downloadLoadingListMap, row.id, false);
      }
    },
    async downLoadAllFile() {
      if (this.downloadLoading) {
        return;
      }
      this.downloadLoading = true;
      try {
        const res = await getAllFileByBusinessId([
          { business_id: this.businessId },
        ]);
        this.downloadLoading = false;
        if (res instanceof ArrayBuffer) {
          const decoder = new TextDecoder("utf-8");
          const text = decoder.decode(new Uint8Array(res));
          try {
            // 尝试解析为 JSON
            const json = JSON.parse(text);
            // 判断是否为错误信息
            if (json && json.Msg) {
              // 这里可以拿到后台返回的错误提示
              this.$message.error(json.Msg);
              return;
            }
          } catch (e) {
            // 不是 JSON，说明是正常的二进制文件
            // 下载文件
            let blob = new Blob([res], {
              //下载的文件类型；
              type: "application/zip",
            });
            if (window.navigator.msSaveOrOpenBlob) {
              // 兼容ie
              navigator.msSaveBlob(
                blob,
                `${moment().format("YYYYMMDDHHmmss")}.zip`
              );
              navigator.msSaveBlob(blob);
            } else {
              var link = document.createElement("a");
              link.href = window.URL.createObjectURL(blob);
              link.download = `${moment().format("YYYYMMDDHHmmss")}.zip`;
              link.click();
              window.URL.revokeObjectURL(link.href); //释放内存
            }
          }
        }
      } catch (error) {
        this.downloadLoading = false;
      }
    },
  },
};
</script>
<style lang="less">
.file-menu-popover {
  .el-menu-item-group__title {
    display: none;
  }
}
</style>
<style lang="less" scoped>
.file-container {
  width: 100vw;
  height: 100vh;
  display: flex;
}
.side-nav {
  width: 240px;
  height: 100%;
  // background: #0A70B0;
  background: url("~@/assets/images/common/bg.png");
  &-collapse {
    width: 64px;
  }
  &-header {
    height: 56px;
    font-size: 22px;
    padding: 0 15px;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid rgba(255, 255, 255, 0.3);
    &-btn {
      height: 29px;
      margin-top: 2px;
      cursor: pointer;
    }
    i {
      font-size: 29px;
    }
  }
  ::v-deep .el-menu {
    background: #0a70b0;
    border-right: 0;
    .el-submenu {
      border-bottom: 1px solid rgba(255, 255, 255, 0.15);
    }
    .el-submenu__title {
      color: #fff;
      font-size: 14px;
      .iconfont {
        font-size: 20px;
        margin-right: 5px;
      }
    }
    .el-submenu__icon-arrow.el-icon-arrow-down {
      font-size: 16px;
    }
    .el-menu-item-group__title {
      display: none;
    }
    .el-menu-item {
      color: #fff !important;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
      &:focus {
        background: rgba(0, 0, 0, 0.15) !important;
      }
    }
    .el-menu-item.is-active {
      background: rgba(0, 0, 0, 0.15) !important;
      position: relative;
      &::before {
        content: "";
        position: absolute;
        left: 0;
        height: 100%;
        width: 5px;
        background: #ffa63b;
      }
    }
    .el-submenu__title:hover,
    .el-menu-item:hover {
      background: rgba(0, 0, 0, 0.15) !important;
    }
  }
}
.vue-office-docx {
  width: 100%;
}
.iframe-container {
  flex-grow: 1;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  position: relative;
  .downloadFile {
    position: absolute;
    right: 20px;
    top: 5px;
    cursor: pointer;
    border-radius: 5px;
    padding: 5px 10px;
    color: #fff;
    font-size: 15px;
    background: #0a70b0;
    z-index: 1000;
  }
  iframe {
    width: 100%;
    height: 100%;
  }
}

.table-html-wrap {
  width: 100%;
  height: 100%;
  // height: 680px;
  // padding: 30px 0;
  // overflow: scroll;
  box-sizing: border-box;
  ::v-deep .x-spreadsheet-bottombar {
    height: 45px;
  }
  ::v-deep(table) {
    tr {
      &:first-child {
        td {
          &:first-child {
            background-color: #0070c0;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
          }
        }
      }
      &:nth-child(2) {
        background-color: #9cc2e5;
        color: #fd0404;
      }
      &:nth-child(3) {
        background-color: #9cc2e5;
        td {
          &:nth-child(9) {
            text-align: center;
          }
          &:nth-child(9),
          &:nth-child(10) {
            color: #fd0404;
          }
        }
      }
      td {
        border: 1px solid #000000;
        white-space: wrap;
        text-align: left;
        min-width: 150px;
        height: 30px;
        padding: 4px;
      }
    }
  }
}
.downLoadBtn {
  position: absolute;
  right: 10px;
  top: 0px;
  cursor: pointer;

  i {
    color: #fff !important;
  }
}

.side-right {
  display: flex;
  align-items: center;

  .download-all i {
    font-size: 24px;
    cursor: pointer;
  }
}

.ellipsis-style {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
</style>
