<template>
  <div class="caseExportConBox">
    <!-- <div class="title-bar flex_row">
      <div class="crumbsCon">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>病例导出
          <i class="iconfont iconzhankaishouqi"></i>
        </span>
        <div class="tabCon">
          <el-tabs v-model="searchData.apply_state" @tab-click="searchList">
            <el-tab-pane v-for="(item,index) in tabList" :key="index" :label="item.name" :name="item.state"></el-tab-pane>
          </el-tabs>
        </div>
      </div>

    </div> -->

    <div class="stateTab ml10 mt10">
      <el-radio-group v-model="searchData.apply_state" @change="searchList">
        <el-radio-button
          v-bind:label="item.state"
          v-for="(item, index) in tabList"
          :key="index"
          >{{ item.name }}</el-radio-button
        >
      </el-radio-group>
    </div>

    <div class="caseExportContainer">
      <caseConditionInquery
        :role="curRole"
        :action="1"
        @getList="getList"
      ></caseConditionInquery>
      <div class="caseExportContent">
        <div
          class="allInspect clear"
          v-loading="loading"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          v-bind:class="{ noTableData: tableData.length == 0 }"
        >
          <el-table
            :data="tableData"
            border
            stripe
            height="100%"
            ref="tableAutoScroll"
            highlight-current-row
            header-row-class-name="strong"
          >
            <el-table-column
              fixed="left"
              align="center"
              type="index"
              label="序号"
              width="55"
            >
              <template slot-scope="scope">
                <span>{{
                  (searchData.offset - 1) * searchData.limit + scope.$index + 1
                }}</span>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="100" fixed="left">
              <template slot-scope="scope">
                <span class="clr_0a pointer" @click="watchExport(scope.row)"
                  >查看</span
                >
                <!-- <span class="clr_0a pointer pl10" :class="{'isCanExport': !scope.row.is_allow_export}" @click="beganImportOutCase(scope.row)">导出</span> -->
                <span
                  class="clr_da pointer pl10"
                  :class="{ isCanCancel: !scope.row.is_allow_cancel }"
                  @click="cancelApply(scope.row)"
                  >取消</span
                >
              </template>
            </el-table-column>
            <el-table-column prop="state" label="状态" :width="80" fixed="left">
              <template slot-scope="scope">
                <span class="finishedStatu" v-if="scope.row.state === 2">{{
                  scope.row.state | dealApplyState(baseInfo)
                }}</span>
                <span class="waitCheckStatu" v-else>{{
                  scope.row.state | dealApplyState(baseInfo)
                }}</span>
              </template>
            </el-table-column>
            <common-table :propData="propData" />
          </el-table>
        </div>
        <div class="blockPage">
          <pagination-tool
            :total="totalImportOutNum"
            :page.sync="searchData.offset"
            :limit.sync="searchData.limit"
            @pagination="beganGetImportOutList"
          />
        </div>
      </div>
    </div>

    <!-- 详情 -->
    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="drawer"
      :show-close="false"
      :withHeader="false"
      :direction="direction"
      :before-close="handleClose"
    >
      <caseApplyDetail
        ref="caseApplyDetail"
        @closeFn="closeFn"
      ></caseApplyDetail>
    </el-drawer>

    <!--取消申请-->
    <el-dialog
      title="取消申请"
      class="cancelApply"
      :visible.sync="showCancelApplyAlert"
      width="500px"
      :close-on-click-modal="false"
      append-to-body
      v-dialogDrag
    >
      <caseCancelApplyAlert
        :cancelApplyParam="cancelApplyParam"
      ></caseCancelApplyAlert>
      <div class="dialog_footer">
        <el-button size="small" plain @click="showCancelApplyAlert = false"
          >取消</el-button
        >
        <el-button type="primary" size="small" @click="sureCancelApply"
          >确定</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>
<script>
import caseMixin from "./caseMixin/case";
import caseConditionInquery from "./components/caseConditionInquery";
import CommonTable from "./components/caseTable";
import PaginationTool from "@/components/common/PaginationTool";
import caseApplyDetail from "./components/caseApplyDetail";
import caseCheckNoPassAlert from "./components/caseCheckNoPassAlert";
import caseCancelApplyAlert from "./components/caseCancelApplyAlert";
import {
  getAuthApplyStateTotal,
  getCaseExportApplyList,
  exportCancelAudit,
  getIsHasImageData,
  getImportImgCount,
} from "@/api/platform_costomer/caseExport";
import { getConstants } from "@/api/commonHttp"; // 请求
import { mapGetters } from "vuex";
//import { beganShowCaseExportDialog, getCaseExportDialogStatus, addInspectDataToDialog } from 'tomtaw-forward'
export default {
  components: {
    caseConditionInquery,
    CommonTable,
    PaginationTool,
    caseApplyDetail,
    caseCheckNoPassAlert,
    caseCancelApplyAlert,
  },
  computed: {
    ...mapGetters({
      // 获取store查询枚举条件
      baseInfo: "enumerations",
    }),
  },
  mixins: [caseMixin],
  data() {
    return {
      curRole: "",
      tabList: [
        // {
        //   label: "全部",
        //   value: 1,
        // },
        // {
        //   label: "待审批",
        //   value: 2,
        // },
        // {
        //   label: "已完成",
        //   value: 3,
        // },
      ],
      loading: false,
      searchData: {
        apply_state: "",
        offset: 1,
        limit: 20,
      },
      totalImportOutNum: 0,
      tableData: [],
      // 表头字段
      propData: [
        { prop: "reason", label: "申请事由", width: 120 },
        { prop: "examine_count", label: "检查数量", width: 90 },
        { prop: "create_time", label: "申请时间", width: 180 },
        { prop: "observations_depart_names", label: "检查科室", width: 180 },
        { prop: "observations_org_name", label: "检查机构" },
      ],
      drawer: false,
      direction: "rtl",
      key: 0,
      showCancelApplyAlert: false,
      cancelApplyParam: {
        apply_id: "",
        reason: "", // 取消原因
      },
      importImgCount: 10,
    };
  },
  methods: {
    handleClose(done) {
      done();
    },
    closeFn() {
      this.drawer = false;
    },
    // 点击导入管理
    importOutManager() {
      const path = process.env.NODE_ENV === "development" ? "/" : "/operate/";
      this.$router.push({
        path: `${path}dataStorage/exportManage`,
      });
    },
    // 查看或审批
    watchExport(row) {
      const self = this;
      self.drawer = true;
      self.$nextTick(() => {
        self.$refs.caseApplyDetail.cancelApplyParam.apply_id = row.id;
        self.$refs.caseApplyDetail.resetData();
        self.$refs.caseApplyDetail.getCaseExportListByApplyId(row.id);
        self.$refs.caseApplyDetail.beganGetCaseExportApplyLogs(row.id);
        self.$refs.caseApplyDetail.beganGetImportImgCount();
      });
    },
    // 取消申请
    cancelApply(row) {
      const self = this;
      // 不可以取消
      if (!row.is_allow_cancel) {
        return false;
      }
      self.cancelApplyParam = {
        reason: "", // 取消原因
        apply_id: row.id,
      };
      self.showCancelApplyAlert = true;
      // self.$confirm(
      //   '确定要取消申请?'+
      //   "提示",
      //   {
      //     confirmButtonText: "确定",
      //     cancelButtonText: "取消",
      //     dangerouslyUseHTMLString: true,
      //     type: "warning",
      //   }
      // )
      // .then(() => {
      //   self.sureCancelExport(row.id)
      // })
      // .catch(() => {});
    },

    // 确定取消申请
    async sureCancelApply() {
      if (this.cancelApplyParam.reason == "") {
        this.$message({ message: "请输入取消申请的原因", type: "error" });
        return false;
      }
      const res = await exportCancelAudit(this.cancelApplyParam);
      if (res.code === 0) {
        this.showCancelApplyAlert = false;
        this.$message.success("取消申请成功");
        // 重新获取申请列表
        this.beganGetImportOutList();
      } else {
        this.$message.error(res.msg);
      }
    },
    // 获取权限里面  设置的导出影像数
    async beganGetImportImgCount() {
      const res = await getImportImgCount();
      if (res.code === 0) {
        this.importImgCount = res.data;
      } else {
        this.$message.error(res.msg);
      }
    },
    // 开始导出病例
    async beganImportOutCase(row) {
      const self = this;
      // 不允许导出
      if (!row.is_allow_export) {
        return false;
      }
      // 获取批次数量
      await self.beganGetImportImgCount();
      let noImageArr = []; // 没有影像的

      const importParams = {
        dto_list: [],
        batch_count: self.importImgCount,
      };

      const res = await getIsHasImageData({ apply_id: row.id });
      if (res.code == 0) {
        const result = res.data || [];
        if (result.length != 0) {
          result.forEach((item) => {
           if (item.has_image) {

            importParams.dto_list.push(
             { 
              business_id:item.idcas_id,
              patient_id: item.patient_id,
              patient_name: item.patient_id+ "_" + item.patient_name,
              accession_number: item.accession_number,
              system_id:item.business_system_id,
              org_id: item.institution_id,
              org_code: item.institution_code,
             }
            )

           }
          
           if (!item.has_image)  {
             noImageArr.push(item.accession_number)
           }
         })
        }
        if (importParams.dto_list.length == 0) {
          self.$message.error("没有可导出的影像文件");
          return false;
        }
        if (noImageArr.length != 0) {
          // 都审批通过了但是没有影像
          const patientIdStr = noImageArr.join("、");
          self
            .$confirm(
              '当前记录中的 <span style="color: #0099ff;padding-right:5px;">' +
                patientIdStr +
                "</span> " +
                noImageArr.length +
                " 条记录已经无影像文件," +
                "暂时不能导出",
              "提示",
              {
                confirmButtonText: "确认并导出其它",
                cancelButtonText: "取消",
                dangerouslyUseHTMLString: true,
                type: "warning",
              }
            )
            .then(() => {
              // 调用的是 caseMixin里面的方法
              self.caseImportOut(importParams);
            })
            .catch(() => {});
        } else {
          // 调用的是 caseMixin里面的方法
          self.caseImportOut(importParams);
        }
      } else {
        self.$message.error(res.msg);
      }
    },
    getList(obj) {
      this.searchData.begin_apply_time = obj.start_time;
      this.searchData.end_apply_time = obj.end_time;
      this.searchData.states = obj.states;
      this.searchData.observations_dept_ids = obj.observations_dept_ids;
      this.searchData.offset = obj.offset;
      this.searchData.limit = obj.limit;
      if (this.$route.query.id) {
        this.searchData.id = this.$route.query.id;
      }
      this.beganGetImportOutList();
    },
    searchList() {
      this.searchData.offset = 1;
      this.searchData.limit = 20;
      this.beganGetImportOutList();
    },
    // 获取导出列表
    async beganGetImportOutList() {
      const self = this;
      self.loading = true;
      const res = await getCaseExportApplyList(this.searchData);
      if (res.code === 0) {
        self.loading = false;
        self.tableData = res.data || [];
        self.totalImportOutNum = res.page.total_count || 0;
      } else {
        self.loading = false;
        self.$message.error(res.msg);
      }
    },
    // 获取申请方状态统计
    async beganGetApplyAuthStateTotal() {
      const self = this;
      self.tabList = [];
      const res = await getAuthApplyStateTotal();
      if (res.code === 0) {
        const result = res.data;
        let allCount = 0;
        if (result.length != 0) {
          result.forEach((item) => {
            item.name = `${item.name}(${item.count})`;
            allCount = allCount + item.count;
            item.state = item.state.toString();
            self.tabList.push(item);
          });
        }
        self.tabList.unshift({
          name: `全部(${allCount})`,
          state: "",
          count: allCount,
        });
      } else {
        this.$message.error(res.msg);
      }
    },
    // 打开申请弹窗
    openDialogAlert() {
      const applyData = [
        {
          id: "1904803984767717376",
          business_id: "1448246813877342208", //业务id  用来查询影像的
          business_system_id: "1397063816583319552", //业务系统id
          business_system_type: "RIS", //业务系统类型
          study_instance_uid: "123",
          accession_number: "118495",
          med_rec_no: "TMC124223",
          patient_id: "TMC124223",
          patient_name: "诊断符合测试",
          observations_org_id: "1866663885916897280",
          observations_org_name: "机构1211",
          observations_depart_id: "1866663892590034945",
          observations_depart_name: "超声科",
          exam_item: "头颅平扫0705", // "examination_item_name": "头颅平扫0705",
          exam_item_category: "头颅CT",
          patient_type: "优先",
          exam_time: "2025-03-26 15:54:13",
          request_org_id: "1717062745664372736",
          request_org_name: "华科大附属同济医院",
          request_dept_id: "1866663892590034945",
          request_dept_name: "放射科",
          state: 0,
        },
        {
          id: "1904803984767717376",
          business_id: "1448246813877342208", //业务id  用来查询影像的
          business_system_id: "1397063816583319552", //业务系统id
          business_system_type: "RIS", //业务系统类型
          study_instance_uid: "123",
          accession_number: "118495",
          med_rec_no: "TMC124223",
          patient_id: "TMC124223",
          patient_name: "诊断符合测试",
          observations_org_id: "1866663885916897280",
          observations_org_name: "机构1211",
          observations_depart_id: "1866663892590034946",
          observations_depart_name: "内镜科",
          exam_item: "头颅平扫0705", // "examination_item_name": "头颅平扫0705",
          exam_item_category: "头颅CT",
          patient_type: "优先",
          exam_time: "2025-03-26 15:54:13",
          request_org_id: "1717062745664372736",
          request_org_name: "华科大附属同济医院",
          request_dept_name: "内镜科",
          request_dept_id: "1866663892590034946",
          state: 1,
        },
        {
          id: "1904803984767717376",
          business_id: "1448246813877342208", //业务id  用来查询影像的
          business_system_id: "1397063816583319552", //业务系统id
          business_system_type: "RIS", //业务系统类型
          study_instance_uid: "123",
          med_rec_no: "TMC124223",
          accession_number: "TX-140547",
          patient_id: "EWQC-HEADCT-002-000030",
          patient_name: "测试",
          observations_org_id: "1866663885916897280",
          observations_org_name: "机构1211",
          observations_depart_id: "1866663892590034944",
          observations_depart_name: "放射科",
          exam_item: "头颅平扫0705", // "examination_item_name": "头颅平扫0705",
          exam_item_category: "头颅CT",
          patient_type: "优先",
          exam_time: "2025-03-26 15:54:13",
          request_org_id: "1717062745664372736",
          request_org_name: "华科大附属同济医院",
          request_dept_name: "放射科",
          request_dept_id: "1866663892590034944",
          state: 2,
        },
      ];

      beganShowCaseExportDialog({
        productCode: "operate",
        caseExportDataArr: applyData,
      });
    },

    // 获取后台枚举值--设置前端基础数据
    async getConstantsFn() {
      const res = await getConstants();
      //var item = { name: '全部', value: '' }
      this.$store.commit("app/set_enumerations", res); // 所有基础数据-------------------
    },
  },
  created() {
    // 业务系统传过来的
    if (this.$route.query) {
      this.curRole = this.$route.query.curRole;
    }
    this.getConstantsFn();
    // 获取申请方的状态统计
    this.beganGetApplyAuthStateTotal();

    // npm 包弹窗显示
    // this.openDialogAlert()
    // console.log(getCaseExportDialogStatus({productCode: 'operate'}))
  },
  filters: {
    // 列表里面 状态的显示
    dealApplyState(val, baseInfo) {
      let stateStr = "";
      if (
        baseInfo &&
        baseInfo.case_export_apply_state &&
        baseInfo.case_export_apply_state.length != 0
      ) {
        baseInfo.case_export_apply_state.forEach((item) => {
          if (item.value === val) {
            stateStr = item.name;
          }
        });
      }
      return stateStr;
    },
  },
};
</script>
<style lang="less" scoped>
.caseExportConBox {
  height: calc(100% - 56px);
}
.crumbsCon {
  display: flex;
}
::v-deep .stateTab {
  .el-radio-group {
    height: 32px;
    line-height: 30px;
    .el-radio-button__inner {
      height: 32px;
      line-height: 30px;
      // padding: 0 !important;
      // width: 56px;
      padding: 0 10px !important;
      text-align: center;
    }
    .el-radio-button__orig-radio:checked + .el-radio-button__inner {
      background-color: #0a70b0 !important;
      border-color: #0a70b0 !important;
    }
  }
}

.importInstituteBtn {
  border: 1px solid #dcdfe6;
  border-radius: 3px;
  padding: 5px 10px;
  cursor: pointer;
}
.caseExportContainer {
  height: calc(100% - 32px);
  .caseExportContent {
    padding: 0px 10px 10px 10px;
    height: calc(100% - 52px);
    .allInspect {
      height: calc(100% - 56px);
    }
    ::v-deep .el-table__body-wrapper {
      height: calc(100% - 40px);
      overflow-y: auto;
    }
  }
}
.blockPage {
  border: 1px solid #eee;
  border-top: none;
}
.finishedStatu {
  font-size: 14px;
  color: #606266;
}
.waitCheckStatu {
  font-size: 14px;
  color: #ef8900;
}
.isCanExport,
.isCanCancel {
  font-size: 14px;
  color: #c0c4cc;
}
</style>
