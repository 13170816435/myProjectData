<template>
        <!--病例导出 进度条展示页面----->
      <div class="progressContent" :class="{'activeProgress':caseImportAlertShow}">
        <transition name="slide-fade">
         <div
          v-if="caseImportAlertShow"
          class="importOutCaseAlert"
         >
          <div class="caseProgressCon">
            <img class="importImg" src="@/assets/images/dataStorage/importOut.png" alt="">
            
             <i class="iconfont iconzhengchang finishIcon" v-if="importOutPercentage>=100"></i>
             <span class="progressTit" v-else>病例导出中，请耐心等待…</span>
             <el-progress
                v-if="importOutPercentage<100"
                :percentage="importOutPercentage"
                :format="caseImportFormat"
                class="progressBox mt20 mb20"
                :text-inside="true"
                :stroke-width="18"
              ></el-progress>
              
              <span v-else class="importOutSucTip mb10">病例导出成功</span>


              <el-button v-if="importOutPercentage<100" class="importOutBtn stopBtn" @click="hideCaseImportOutAlert" type="text">终止导出</el-button>
              <el-button v-else class="importOutBtn closeProgressBtn" @click="hideCaseImportOutAlert" type="text">关闭弹窗</el-button>
          </div>
        </div>
      </transition>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
  computed: {
    ...mapGetters(['caseImportAlertShow','importOutProgressCount']),
      // 病例导出
    importOutPercentage() {
      if (this.importOutProgressCount == 0) {
        return 0
      } else {
        // console.log(Math.floor(parseFloat(this.importOutProgressCount)))
        return Math.floor(
          parseFloat(this.importOutProgressCount)
        )
      }
    },
  },
  data () {
    return {

    }
  },
  methods: {
    caseImportFormat(percentage) {
      return `${percentage}%`
    },
    hideCaseImportOutAlert() {
      this.$store.commit('caseImport/RESET_IMPORT_OUT_PARAM')
      window.close()
    },
  },
  mounted(){
    this.$store.dispatch('caseImport/pollingGetImportOutProgressRate',JSON.parse(localStorage.getItem('importProgressData'))) // 开始轮询
  },
}
</script>
<style lang="less" scoped>
.progressContent {
  height:180px;
  position: absolute;
  right:-1000px;
  transition: all 0.3s;
 /***病例导出 进度展示***/
.importOutCaseAlert{
  width: 450px;
  height: 180px;
  background: linear-gradient(0deg, #F3FAFF 1%, #D1ECFF 100%);
  border: 2px solid #FFFFFF;
  box-shadow: 0 4px 24px 0 #0000004d;
  border-radius: 16px;
  .caseProgressCon{
    height: 100%;
    position: relative;
    display: flex;
    flex-flow: column;
    align-items: center;
    justify-content: center;
    .finishIcon{
      font-size: 40px;
      color: #1CB54A;
    }
    .importImg{
      position: absolute;
      top:-20px;
      left:3px;
    }
    .progressTit{
      font-size: 18px;
      color: #303133;
      line-height: 24px;
    }
    .importOutSucTip{
      font-weight: 700;
      font-size: 18px;
      color: #303133;
    }
    .progressBox{
      width: 366px;
      height: 18px;
      background: #B9E1FF;
      border: 1px solid #FFFFFF;
      border-radius: 10px;
      display: flex;
      align-items: center;
    }
    .importOutBtn{
      display: flex;
      align-items: center;
      justify-content: center;
      width: 88px;
      height: 32px;
      line-height: 30px!important;
      border-radius: 16px;
      font-size: 14px;
      color: #FFFFFF;
      cursor: pointer;
    }
    .closeProgressBtn{
      background: #0A70B0;
      border: 1px solid #0A70B0;
    }
    .stopBtn{
      background: #fff;
      border: 1px solid #FF6F6F; 
      color:#FF6F6F;
    }
  }
  ::v-deep .el-progress-bar__inner {
    background:#409EFF;
  }
  .el-progress-bar__innerText{
    color:#fff!important;
  }
 }
}
.activeProgress{
  position: absolute;
  right: 20px;
  bottom: 30px;
  z-index: 1000000;
}
.fade-enter-active, .fade-leave-active { transition: all 0.3s; }
.fade-enter, .fade-leave-to {
  opacity: 0;
  // transform: translateX(460px);
}
</style>