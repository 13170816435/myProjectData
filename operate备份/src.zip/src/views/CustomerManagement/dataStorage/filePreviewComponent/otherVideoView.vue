<template>
  <div class="video-box">
    <div v-if="loading" class="loading-box">
      <div>
        <i class="el-icon-loading f30"></i>
      </div>
      <div class="mt10">加载中...</div>
    </div>
    <video
      ref="videoRef"
      id="videoBox"
      :src="videoUrl"
      muted
      autoplay
      controls
    ></video>
  </div>
</template>
<script>
import { createFFmpeg, fetchFile } from "@ffmpeg/ffmpeg";

const base =
  process.env.NODE_ENV === "development" ? "/" : process.env.BASE_URL || "/";

export default {
  props: {
    // fileName: String,
    // fileId: String,
    fileType: String,
    fileData: ArrayBuffer,
  },
  data() {
    return {
      videoUrl: "",
      firstChunkDuration: 6, // 首个分片的时长
      loading: false,
      ffmpeg: null, // ffmpeg 实例
    };
  },
  watch: {
    async fileData(newVal) {
      if (newVal) {
        // 切换新视频时，先中断上一次转码
        if (this.ffmpeg) {
          try {
            await this.ffmpeg.exit(); // 终止上一次 ffmpeg
          } catch (e) {}
          this.ffmpeg = null;
        }
        this.getFileBlob(newVal);
      }
    },
  },
  methods: {
    // 通过ffmpeg.wasm 的日志输出来捕获截取出视频时长（更快，但不一定100%准确）
    async getDurationByFFmpegLog(file) {
      if (this.ffmpeg) {
        try {
          await this.ffmpeg.exit();
        } catch (e) {}
      }
      this.ffmpeg = createFFmpeg({
        log: true,
        corePath: `${base}ffmpeg/ffmpeg-core.js`,
      });
      const ffmpeg = this.ffmpeg;
      const inputName = `input.${this.fileType}`;
      await ffmpeg.load();
      ffmpeg.FS("writeFile", inputName, await fetchFile(file));
      // 用 Promise 包裹日志监听
      const duration = await new Promise(async (resolve, reject) => {
        let resolved = false;
        ffmpeg.setLogger(({ message }) => {
          const match = message.match(/Duration: (\d+):(\d+):(\d+\.\d+)/);
          if (match && !resolved) {
            const [, h, m, s] = match;
            const dur = parseInt(h) * 3600 + parseInt(m) * 60 + parseFloat(s);
            resolved = true;
            resolve(dur);
          }
        });
        try {
          await ffmpeg.run("-i", inputName);
          setTimeout(() => {
            // if (!resolved) reject(new Error("未能解析到时长"));
          }, 2000); // 2000ms后还没解析到就报错
        } catch (e) {
          reject(e);
        }
      });
      ffmpeg.setLogger(() => {}); // 关闭日志捕获
      ffmpeg.FS("unlink", inputName);
      return duration;
    },
    async play(file) {
      if (this.ffmpeg) {
        try {
          await this.ffmpeg.exit();
        } catch (e) {}
      }
      this.loading = true;
      this.ffmpeg = createFFmpeg({
        log: true,
        corePath: `${base}ffmpeg/ffmpeg-core.js`,
      });
      const ffmpeg = this.ffmpeg;
      // 添加进度和日志监控
      // ffmpeg.setLogger(({ type, message }) => {
      //   console.log(`[FFmpeg] ${type}: ${message}`);
      // });

      // ffmpeg.setProgress(({ ratio }) => {
      //   console.log(`转码进度: ${(ratio * 100).toFixed(2)}%`);
      //   percentage.value = Number((ratio * 100).toFixed(2));
      // });
      await ffmpeg.load();
      const inputName = `input.${this.fileType}`;
      // 写入文件到FFmpeg文件系统
      ffmpeg.FS("writeFile", inputName, await fetchFile(file));
      // 执行转码命令
      await ffmpeg.run(
        "-i",
        inputName, // 输入文件
        "-vf",
        "scale=trunc(iw/2)*2:trunc(ih/2)*2", // 自动调整尺寸为2的倍数
        "-c:v",
        "libx264", // 视频编码器
        "-preset",
        "fast", // 编码速度/质量平衡
        "-crf",
        "5", // 质量参数(0-51，越小质量越高)
        "-c:a",
        "aac", // 音频编码器
        "-b:a",
        "128k", // 音频比特率
        "-movflags",
        "faststart", // 使视频可以流式播放
        "output.mp4" // 输出文件
      );
      const data = ffmpeg.FS("readFile", "output.mp4");
      this.videoUrl = URL.createObjectURL(
        new Blob([data.buffer], { type: "video/mp4" })
      );
      ffmpeg.FS("unlink", inputName);
      this.$nextTick(() => {
        this.loading = false;
      });
    },
    async fragmentationPlay(file, duration) {
      if (this.ffmpeg) {
        try {
          await this.ffmpeg.exit();
        } catch (e) {}
      }
      this.loading = true;
      // 计算每个分片的时长（按递减的方式优化流式加载，）
      let chunkDurations = [];
      let remain = duration;
      let curChunk = this.firstChunkDuration;
      while (remain > 0) {
        let d = Math.min(curChunk, remain);
        chunkDurations.push(d);
        remain -= d;
        // 递减，最小1秒
        curChunk = Math.max(curChunk * 0.8, 1);
      }

      // 初始化
      const mediaSource = new MediaSource();
      this.videoUrl = URL.createObjectURL(mediaSource);

      mediaSource.addEventListener("sourceopen", async () => {
        this.ffmpeg = createFFmpeg({
          log: true,
          corePath: `${base}ffmpeg/ffmpeg-core.js`,
        });
        const ffmpeg = this.ffmpeg;
        // 添加进度和日志监控
        // ffmpeg.setLogger(({ type, message }) => {
        //   console.log(`[FFmpeg] ${type}: ${message}`)
        // })
        // ffmpeg.setProgress(({ ratio }) => {
        //   console.log(`转码进度: ${(ratio * 100).toFixed(2)}%`)
        // })
        await ffmpeg.load();
        const sourceBuffer = mediaSource.addSourceBuffer(
          'video/mp4; codecs="avc1.42E01E, mp4a.40.2"'
        );
        sourceBuffer.mode = "sequence";
        const inputName = `input.${this.fileType}`;
        ffmpeg.FS("writeFile", inputName, await fetchFile(file));
        let start = 0;
        for (let i = 0; i < chunkDurations.length; i++) {
          // 只能进行时间分片，不能文件分片，不然MSE只会播放第一个
          const chunk = chunkDurations[i];
          await ffmpeg.run(
            "-ss",
            String(start), //起始时间，保证每个分片的时间戳是递增的
            "-t",
            String(chunk), // 持续时间
            "-i",
            inputName,
            "-vf",
            "scale=trunc(iw/2)*2:trunc(ih/2)*2", // 自动调整尺寸为2的倍数
            "-movflags",
            "frag_keyframe+empty_moov+default_base_moof", // 这里一定要输出为fMP4（带 moof/moov）
            "-f",
            "mp4", // 明确指定输出格式
            "-c:v",
            "libx264",
            "-c:a",
            "aac",
            "output.mp4"
          );
          const data = ffmpeg.FS("readFile", "output.mp4");
          await new Promise((resolve) => {
            function append() {
              if (!sourceBuffer.updating && mediaSource.readyState === "open") {
                sourceBuffer.appendBuffer(data.buffer);
              } else {
                sourceBuffer.addEventListener("updateend", append, {
                  once: true,
                });
                return;
              }
              sourceBuffer.addEventListener("updateend", () => resolve(), {
                once: true,
              });
            }
            append();
          });
          if (i === 0) {
            this.loading = false;
          }
          // 4. 清理临时文件
          ffmpeg.FS("unlink", "output.mp4");
          start += chunk;
        }
        ffmpeg.FS("unlink", inputName);
        if (mediaSource.readyState === "open") {
          // 每次append后关闭MediaSource
          mediaSource.endOfStream();
        }
      });
    },
    // 获取文件流
    async getFileBlob(fileRes) {
      // 获取视频时长
      const duration = await this.getDurationByFFmpegLog(fileRes);
      if (duration <= 8) {
        // 不分片
        this.play(fileRes);
      } else {
        // 分片转码
        this.fragmentationPlay(fileRes, duration);
      }
    },
  },
};
</script>
<style lang="less" scoped>
.video-box {
  width: 100%;
  height: 100%;

  video {
    width: 100%;
    height: 100%;
  }
}

.loading-box {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 0.05);
}
</style>
