<template>
    <div class="video-container">
      <!-- 播放器容器 -->
      <video-player 
        ref="videoPlayer"
        class="vjs-custom-skin"
        :options="playerOptions"
        @ready="onPlayerReady"
        @error="onPlayerError"
      />
    </div>
  </template>
  
  <script>
  import 'video.js/dist/video-js.css'
  import { videoPlayer } from 'vue-video-player'
  
  export default {
    components: { videoPlayer },
    data() {
      return {
        playerOptions: {
          autoplay: false,      // 禁止自动播放（部分浏览器限制）
          controls: true,       // 显示控制条
          preload: 'auto',      // 预加载策略
          fluid: true,         // 自适应容器
          muted: false,        // 取消静音
          sources: [{
            type: 'video/mp4', // 必须明确指定MIME类型
            src: 'https://media.w3.org/2010/05/sintel/trailer.mp4' // 可用的测试视频
          }],
          poster: 'https://via.placeholder.com/800x450', // 封面图
          notSupportedMessage: '当前浏览器不支持视频播放' // 错误提示
        }
      }
    },
    computed: {
      player() {
        return this.$refs.videoPlayer.player
      }
    },
    methods: {
      // 播放器准备就绪
      onPlayerReady() {
        console.log('Player ready')
      },
      // 错误处理
      onPlayerError(error) {
        console.error('播放错误:', this.player.error())
      }
    },
    beforeDestroy() {
      // 销毁播放器实例
      if (this.player) {
        this.player.dispose()
      }
    }
  }
  </script>
  
  <style scoped>
  .video-container {
    max-width: 800px;
    margin: 20px auto;
    width:100%;
    height:100%;
  }
  /* 自定义皮肤 */
  .vjs-custom-skin {
    background-color: #000;
  }
  </style>
  