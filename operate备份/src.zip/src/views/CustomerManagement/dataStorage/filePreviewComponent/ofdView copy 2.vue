<template>
  <div>
    <OfdView
      :file="ofdFile"
      :mem="ofd"
      :secret="secret"
      :digest="digest" 
      :canDownload="true"
      :canPrint="true"
      @onDownloadFinishEvent="handleDownloadFinish"
      @onPrintFinishEvent="handlePrintFinish"
    />
  </div>
</template>

<script>
import {getDocumentsByBusiness, getDocumentUrl, getDocumentUrlByShortChain, getReportDetails, downloadFile, getOperateDocumentsByBusiness, } from '@/api/memorySharing/dataMemory'
export default {
  data() {
    return {
      ofd: require('parser_x.js'),
      // ofdFile: "https://ofd.xdocin.com/demo/fapiao.ofd" // OFD 文件路径或 ArrayBuffer
      ofdFile:'',
      secret: 'Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6Ijc5OEY4NTk0MTExMzE5NjE2NjEzOThCMkJGRTAyNTc1ODRCODY2N0IiLCJ0eXAiOiJhdCtqd3QiLCJ4NXQiOiJlWS1GbEJFVEdXRm1FNWl5di1BbGRZUzRabnMifQ.eyJuYmYiOjE3NDE0ODM1OTksImV4cCI6MTc0MTUyNjc5OSwiaXNzIjoiaHR0cDovL29wZXJhdGUtb2F1dGgtY2VudGVyLmV3b3JsZGNsb3VkOjkwMTAvb2F1dGgiLCJhdWQiOlsiYXBpLW9wZXJhdGUiLCJhcGktY2xvdWRwYWNzIiwiYXBpLW1paXMiLCJhcGktcGlzIiwiYXBpLW5taXMiLCJhcGktZXBpcyIsImFwaS1ld2NzcyIsImFwaS1jYWxsaW5nIiwiYXBpLWRtcyIsImFwaS1pbWFnaW5nIiwiYXBpLWFyY2hpdmUiLCJhcGktYXNpcyIsImFwaS10ZWxlbWVkIiwiYXBpLXRlYWNoIiwiYXBpLWlkY2FzIiwiYXBpLXF1YWxpdHkiLCJhcGktaW1nYmQiLCJhcGktYWJpbGl0eSIsImFwaS1pbSIsImFwaS1wYWNzLWNvbW1vbiIsImFwaS1hc2lzLWFkbWluIiwiYXBpLWNvbXBhbnktd2Vic2l0ZSIsImFwaS1kZXZvcHMiLCJhcGktcnRpcyIsImFwaS1wb3J0YWwiLCJhcGktYWkiLCJhcGktY3NtcyIsImFwaS1jdWlzIl0sImNsaWVudF9pZCI6ImV3b3JsZC5zcGEuaW1hZ2VjbG91ZCIsInN1YiI6IjEyODg3MjA4NjM4NDMwNjE3NjAiLCJhdXRoX3RpbWUiOjE3NDE0ODM1OTksImlkcCI6ImxvY2FsIiwibmFtZSI6IuW8oOW4hSIsImF2YXRhcl9pZCI6IjE4NjY4MDg3NTQ4OTUzNTU5MDQiLCJ0ZW5hbmN5X2lkIjoiMTI4ODcyMDg2MzY5NjI2MTEyMCIsImNhdGVnb3J5IjoiMTI0IiwidGlkIjoiRUJCN0ZDNkZDNjZGODExNUU3MkU1RkEwMkZERjUwQzYiLCJjbGllbnRfYWdlbnQiOiJVbmtub3duIiwic2NvcGUiOlsib3BlbmlkIiwicHJvZmlsZSIsImFwaS1vcGVyYXRlIiwiYXBpLWNsb3VkcGFjcyIsImFwaS1taWlzIiwiYXBpLXBpcyIsImFwaS1ubWlzIiwiYXBpLWVwaXMiLCJhcGktZXdjc3MiLCJhcGktY2FsbGluZyIsImFwaS1kbXMiLCJhcGktaW1hZ2luZyIsImFwaS1hcmNoaXZlIiwiYXBpLWFzaXMiLCJhcGktdGVsZW1lZCIsImFwaS10ZWFjaCIsImFwaS1pZGNhcyIsImFwaS1xdWFsaXR5IiwiYXBpLWltZ2JkIiwiYXBpLWFiaWxpdHkiLCJhcGktaW0iLCJhcGktcGFjcy1jb21tb24iLCJhcGktYXNpcy1hZG1pbiIsImFwaS1jb21wYW55LXdlYnNpdGUiLCJhcGktZGV2b3BzIiwiYXBpLXJ0aXMiLCJhcGktcG9ydGFsIiwiYXBpLWFpIiwiYXBpLWNzbXMiLCJhcGktY3VpcyJdLCJhbXIiOlsicHdkIl19.iBFNyEecJkrzS8omejaaW_Nobd2T8hGLvnOtE4emjyzMEpYbyegpj7c-tTFmaxEdoTeZJ3UXIir0m3FcksJUHw2dXp2G_SsSC5eSAATpel07tXl3SkZOL3iXjWT23JqvGUOVysfvsAiOFxz0dYlw78SvRXPBS7bYHoa5FtcMQ_Bos1i0QrUCpr0FCYItw69EKirMIdQvdgCoic34xuY8ocfX1B7BuWyL5kuL2yxGwSIvQoWcVwi0fqxc81IiQIYzKDwmVfmMh7psl3kQKX_Plsb3bH7o8ingcK4HjNzUmmIOCpqh1PbBbsKU6qkABOg-RxPuDjFuphyfs-HhEH57-A',
      digest: '87736474a4fffee6aee2d46d76376011',
    };
  },
  created () {
    this.getDocumentUrl(this.$route.query.id)
  },
  methods: {
    handleDownloadFinish() {
      console.log("下载完成");
    },
    handlePrintFinish() {
      console.log("打印完成");
    },
    getDocumentUrl(id) {
      getDocumentUrl(id).then(res => {
        if(res.code === 0) {
          //this.shortChain = res.data
          getDocumentUrlByShortChain(res.data).then(res => {
            if(res.code === 0) {
              if (res.data.url == '') { // 说明该文件不能浏览
                this.$confirm('<i class="iconfont icontishi clr_e6 mr5"></i>非常抱歉，当前文件不支持浏览', '浏览文件', {
                distinguishCancelAndClose: true,
                dangerouslyUseHTMLString: true,
                // confirmButtonText: '确定',
                // cancelButtonText: '取消'
              }).then(() => {
                this.sureUnBindCa()
              })
              } else {
                this.shortChain = res.data.url
                this.beganGetReportDetails(res.data.hash_id,)
              }
            } else {
              this.$message.error(res.msg)
            }
          })
        }else {
          this.$message.error(res.msg)
        }
      })
    },
    async beganGetReportDetails(accessId) {
      let params = {
        // accessId: 'cCcMVxFadYv', // 图片
        accessId: accessId, // pdf
        bussinessId: ''
      }
      let res = await getReportDetails(params)
      let { Code, Data } = res
      if(Code === 0) {
        if(Data.Details.length > 0) {
          let { DeviceID, FilePath} = Data.Details[0]
          // let url = `${this.apiUrl}/api-imaging/File/Download?DeviceID=${DeviceID}&ImagePath=${FilePath}&MimeType=application/pdf`
          let fileRes = await downloadFile(DeviceID, FilePath)
          this.ofdFile = fileRes
        }else {
          this.$message({
            type: 'warning',
            message: '没有相关内容'
          })
        }
      } else {
        this.fileData = null
        this.$message({
          type: 'warning',
          message: res.Msg
        })
      }
    }
  }
};
</script>