  <template>
   <div class="imgBox">
    <img :src="imgSrc" id="prewImg">
  </div>
  </template>
  <script>
  import {getDocumentUrl, getDocumentUrlByShortChain, getReportDetails, downloadOfdFile, } from '@/api/memorySharing/dataMemory'
  export default {
    props: {
      fileName: String,
      fileId: String,
      fileType:String,
    },
    data() {
      return {
        imgSrc: '', 
      }
    },
    methods: {
        getDocumentUrl(id) {
      getDocumentUrl(id).then(res => {
        if(res.code === 0) {
          //this.shortChain = res.data
          getDocumentUrlByShortChain(res.data).then(res => {
            if(res.code === 0) {
              if (res.data.url == '') { // 说明该文件不能浏览
                this.$confirm('<i class="iconfont icontishi clr_e6 mr5"></i>非常抱歉，当前文件不支持浏览', '浏览文件', {
                distinguishCancelAndClose: true,
                dangerouslyUseHTMLString: true,
                // confirmButtonText: '确定',
                // cancelButtonText: '取消'
              }).then(() => {
                this.sureUnBindCa()
              })
              } else {
                this.shortChain = res.data.url
                this.beganGetReportDetails(res.data.hash_id,)
              }
            } else {
              this.$message.error(res.msg)
            }
          })
        }else {
          this.$message.error(res.msg)
        }
      })
    },
    async beganGetReportDetails(accessId) {
      let params = {
        // accessId: 'cCcMVxFadYv', // 图片
        accessId: accessId, // pdf
        bussinessId: ''
      }
      let res = await getReportDetails(params)
      let { Code, Data } = res
      if(Code === 0) {
        if(Data.Details.length > 0) {
          let { DeviceID, FilePath} = Data.Details[0]
          let fileRes = await downloadOfdFile(DeviceID, FilePath)
          
          this.imgSrc = URL.createObjectURL(fileRes)
 
          // if (this.fileType != 'gif') { // 不是gif图片
          //   this.imgSrc = URL.createObjectURL(fileRes)
          // }
          // else {
          //   const img = document.getElementById('prewImg');
          //   const reader = new FileReader();
          //   reader.onload = (e) => {
          //     img.src = e.target.result;
          //     console.log('DataURL 加载成功');
          //   };
          //   reader.onerror = () => {
          //     console.error('DataURL 转换失败');
          //   };
          //   reader.readAsDataURL(fileRes);
          // }
        }else {
          this.$message({
            type: 'warning',
            message: '没有相关内容'
          })
        }
      } else {
        this.fileData = null
        this.$message({
          type: 'warning',
          message: res.Msg
        })
      }
    },

    },
    created() {
      this.getDocumentUrl(this.fileId)
    },
    beforeDestroy() {
     this.imgSrc = ''
    }
  };
  </script>
  <style lang="less" scoped>
  .video-container{
    width:100%;
    height:100%;
    // display:flex;
    // justify-content: center;
    // align-items: center;
    ::v-deep .vjs-big-play-button {
      left:50%;
      top:50%;
    }
  }
  .loadingVideo{
    width:100%;
    height:100%;
    display:flex;
    justify-content: center;
    align-items: center;
  }
  </style>