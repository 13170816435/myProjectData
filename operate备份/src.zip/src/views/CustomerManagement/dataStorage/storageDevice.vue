<template>
  <div class="userlist">
    <div class="title-bar flex_row cardHeader">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr5"></i>数据管理
          <i class="iconfont iconzhankaishouqi"></i> 存储设备
        </span>
      </div>
      <div class="tr col">
        <span @click="addStorage" class="function-btn bg_e6 clr_ff">
          <i class="iconfont iconxinzeng"></i>平台存储域
        </span>
      </div>
    </div>
    <div class="DeviceCon" :class="containerClass">
      <div class="allDevice mt10" v-show="DomainsArr.length !== 0">
        <div class="oneDevice chartCon" v-for="(item, index) in DomainsArr" :key="index"
          @click="chooseStorage($event, index, item)" @mouseenter="showDomainOperate($event)"
          @mouseleave="hideDomainOperate($event)" v-bind:class="{ activeChart: currentDomainIndex === index }">
          <div class="deviceHead" v-bind:title="item.domain_name">
            {{ item.domain_name }}
          </div>
          <div class="deviceContent">
            <div class="usedTit">
              <span class="fl">已使用({{ item.usedSize.unit }})</span><span class="fr">总容量(TB)</span>
            </div>
            <div class="usedNum clear">
              <span class="fl">{{ item.usedSize.value }}</span><span class="fr noFontWeight">{{ item.domain_size }}</span>
            </div>
            <!-- <el-progress class="clear" :text-inside="true" :stroke-width="15" :percentage="50" status="exception"></el-progress> -->
            <el-progress class="clear" :text-inside="true" :stroke-width="15" :percentage="item.usedRate"
              :color="processColorFn(item.usedRate)"></el-progress>
          </div>
          <div class="operateBtn">
            <span @click="delDomain(item.id, index)" class="delDomainIcon"><i class="iconfont iconshanchu1"></i></span>
            <span @click="editDomain(item)" class="mr8 editDomainIcon"><i class="iconfont iconbianji2"></i></span>
          </div>
        </div>
      </div>
      <div class="listTit clear" v-show="DomainsArr.length !== 0">
        <span class="listTitIcon fl"></span><span class="fl loadDeviceTit">{{ currentDomainName }}下挂接的存储设备</span>
        <span class="fl color_orange ml10" style="font-size: 13px;"> <i
            class="iconfont mr5">&#xe646;</i>为避免数据安全风险，请勿和影像存档系统共用存储设备！</span>

        <span @click="AddDevice" class="function-btn bg_e6 clr_ff fr">
          <i class="iconfont iconxinzeng mr5"></i>添加设备
        </span>
        <!-- <span @click="AddStrategy" class="function-btn bg_0a clr_ff fr mr15">
          <i class="iconfont iconzongheshezhi mr5"></i>策略管理
        </span> -->
      </div>
      <div class="deviceList clear" v-show="DomainsArr.length !== 0">
        <div class="tableDiv">
          <div class="organTableData" v-bind:class="{ noTableData: allDeviceList.length == 0 }">
            <template>
              <el-table
                border
                stripe
                :data="allDeviceList"
                style="width: 100%"
                :default-sort="{ prop: 'date', order: 'descending' }"
                ref="deviceListTable"
              >
                <el-table-column
                  type="index"
                  label="序号"
                  width="50"
                  fixed="left"
                ></el-table-column>
                <el-table-column label="操作" width="130" fixed="left">
                  <template slot-scope="scope">
                    <span class="clr_0a pointer" @click="watchDeviceDetail(scope.row)">编辑</span>
                    <span class="clr_f56c pointer pl10" v-if="scope.row.is_enable"
                      @click="DisableDevice(scope.row)">停用</span>
                    <span class="clr_00 pointer pl10" v-if="!scope.row.is_enable"
                      @click="DisableDevice(scope.row)">启用</span>
                    <span class="clr_da pointer pl10" @click.stop="delAuthorize(scope.row.id)">删除</span>
                  </template>
                </el-table-column>
                <!-- <el-table-column prop="device_type" label="设备类型" width="120"></el-table-column>
                <el-table-column prop="is_enable" label="设备状态" width="80"></el-table-column>
                <el-table-column prop="is_online" label="是否热存储" width="100"></el-table-column>
                <el-table-column prop="device_name" label="设备名称" width="170"></el-table-column>
                <el-table-column prop="device_host" label="设备主机" width="170"></el-table-column>
                <el-table-column prop="device_path" label="存储路径" width="170"></el-table-column>
                <el-table-column prop="org_name" label="关联机构" width="170"></el-table-column>
                <el-table-column prop="update_user_name" label="最后操作人" width="120"></el-table-column>
                <el-table-column prop="last_update_time" label="操作时间" width="200"></el-table-column>
                <el-table-column prop="device_size" label="总容量(TB)" width="200"></el-table-column>
                <el-table-column prop="used_size" label="已用容量" width="160"></el-table-column>
                <el-table-column prop="sort_no" label="排序号"></el-table-column> -->
                <common-table :propData="propData" />

              </el-table>
            </template>
          </div>
        </div>
      </div>
    </div>

    <el-dialog class="addDeviceAlert" :title="deviceTit" :visible.sync="showAddDeviceAlert" width="500px" height="auto"
      :close-on-click-modal="false" v-dialogDrag top="10vh">
      <div class="addDeviceCon">
        <div class="oneDeviceInfo">
          <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>存储设备名称：</span>
          <input v-model="addDeviceParam.device_name" type="text" class="fl input_280" />
        </div>

        <div class="oneDeviceInfo clear">
          <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>设备类型：</span>
          <div class="oneLogVal fl">
            <el-select v-model="addDeviceParam.device_type" filterable placeholder="请选择"
              class="ele-select_32 width_280_select" style="width:180px">
              <el-option v-for="(item, index) in deviceClassArr" :key="index" :label="item.name"
                :value="item.id"></el-option>
            </el-select>
          </div>
        </div>
        <div class="oneDeviceInfo">
          <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>存储类型：</span>
          <el-radio-group v-model="addDeviceParam.is_online">
            <el-radio :label="true">在线存储</el-radio>
            <el-radio :label="false">近线存储</el-radio>
          </el-radio-group>
        </div>
        <div class="oneDeviceInfo">
          <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>容量大小：</span>
          <div class="oneLogVal fl">
            <input v-model="addDeviceParam.device_size" class="fl input_190 numberInput" type="number" /><span
              class="unitTip fl">( 单位:T )</span>
          </div>
        </div>
        <div class="oneDeviceInfo" v-if="addDeviceParam.device_type !== 7 && addDeviceParam.device_type !== 9
          ">
          <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>访问ID：</span>
          <div class="oneLogVal fl">
            <input v-model="addDeviceParam.access_id" type="text" class="fl input_280" />
          </div>
        </div>
        <div class="oneDeviceInfo" v-if="addDeviceParam.device_type !== 7">
          <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>访问KEY：</span>
          <div class="oneLogVal fl">
            <!-- <input
              v-model="addDeviceParam.access_key"
              type="text"
              class="fl input_280"
            /> -->

            <el-input :type="psdType" size="medium" placeholder="请输入访问密钥"
                  style="width:280px;" v-model="addDeviceParam.access_key" autocomplete="off">
                  <span slot="suffix" v-if="psdType == 'password'" class="suffix_iconfont" @click="()=>{this.psdType='text'}"><i
                      class="icon iconfont el-input__icon">&#xe8ab;</i></span>
                  <span slot="suffix" v-else class="suffix_iconfont" @click="()=>{this.psdType='password'}"><i
                      class="icon  iconfont el-input__icon">&#xe8ac;</i></span>
                </el-input>
          </div>
        </div>
        <div class="oneDeviceInfo" v-if="addDeviceParam.device_type !== 6 && addDeviceParam.device_type !== 7
          ">
          <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>设备主机：</span>
          <div class="oneLogVal fl">
            <input v-model="addDeviceParam.device_host" type="text" class="fl input_280" />
          </div>
        </div>
        <div class="oneDeviceInfo" v-if="addDeviceParam.device_type !== 6 &&
          addDeviceParam.device_type !== 7 &&
          addDeviceParam.device_type !== 9
          ">
          <span class="oneDeviceInfoLabel fl">设备路径：</span>
          <div class="oneLogVal fl">
            <input v-model="addDeviceParam.device_path" type="text" class="fl input_280" />
          </div>
        </div>
        <div class="oneDeviceInfo">
          <span class="oneDeviceInfoLabel fl">访问token：</span>
          <div class="oneLogVal fl">
            <input v-model="addDeviceParam.token" type="text" class="fl input_280" />
          </div>
        </div>
        <div class="oneDeviceInfo" v-if="addDeviceParam.device_type === 6 || addDeviceParam.device_type === 7
          ">
          <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>存储路径：</span>
          <div class="oneLogVal fl">
            <input v-model="addDeviceParam.device_path" type="text" class="fl input_280" />
          </div>
        </div>
        <div class="oneDeviceInfo clear">
          <span class="oneDeviceInfoLabel fl">关联机构：</span>
          <div class="oneLogVal fl">
            <el-select class="ele-select_32 width_280_select" style="width:180px" filterable multiple collapse-tags
              @change="changeInstitute" v-model="addDeviceParam.org_code" placeholder="请选择">
              <el-option v-for="item in institutionList" :key="item.id" :label="item.name" :value="item.code"></el-option>
            </el-select>
          </div>
        </div>
        <div class="oneDeviceInfo clear">
          <span class="oneDeviceInfoLabel fl">关联科室：</span>
          <div class="oneLogVal fl">
            <el-select class="ele-select_32 width_280_select" style="width:180px" filterable multiple collapse-tags
             v-model="addDeviceParam.depart_code" placeholder="请选择">
              <el-option v-for="(item,officeIndex) in officeTypeArr"
                :key="item.dic_code"
                :label="item.dic_name"
                :value="item.dic_code">
              </el-option>
            </el-select>
          </div>
        </div>
        <div class="oneDeviceInfo clear">
          <span class="oneDeviceInfoLabel fl">存储文档：</span>
          <div class="oneLogVal fl">
            <el-select class="ele-select_32 width_280_select" style="width:180px" multiple collapse-tags clearable
               v-model="addDeviceParam.file_type" placeholder="全部">
              <el-option v-for="(item,typeIndex) in fileTypes" :key="typeIndex" :label="item.description" :value="item.value"></el-option>
            </el-select><br/>
            <span class="storageDocumentTip f14 clr_oarange">没有选择就是全部类型,选择了就是指定了选择的类型</span>
          </div>
        </div>
        <div class="oneDeviceInfo clear">
          <span class="oneDeviceInfoLabel fl">排序号：</span>
          <div class="oneLogVal fl">
            <el-input-number v-model="addDeviceParam.sort_no" class="dictionaryDesc width_280_input fl"
              controls-position="right" :min="1"></el-input-number>
          </div>
        </div>
        <!--
        <div class="oneDeviceInfo clear">
          <span class="oneDeviceInfoLabel fl">存储文档：</span>
          <div class="oneLogVal fl">
            <el-select class="ele-select_32 width_280_select" style="width:180px" clearable
               v-model="addDeviceParam.file_type" placeholder="请选择">
              <el-option v-for="item in fileTypes" :key="item.id" :label="item.name" :value="item.code"></el-option>
            </el-select>
          </div>
        </div>-->
        <!-- <div class="oneDeviceInfo" v-if="addDeviceParam.device_type===6">
          <span class="oneDeviceInfoLabel fl">子目录：</span>
           <div class="oneLogVal fl">
               <input v-model="addDeviceParam.device_path" type="text" class="fl input_280" />
          </div>
        </div> -->
        <!-- <div class="oneDeviceInfo clear">
          <span class="oneDeviceInfoLabel fl">使用机构：</span>
          <div class="oneLogVal fl">
              <el-select
              multiple
             v-model="addDeviceParam.deviceName"
            placeholder="请选择"
            class="ele-select_32 width_280_select"
            style="width:180px">
            <el-option
              v-for="item in coustorType"
              :key="item.type"
              :label="item.type_str"
              :value="item.type"
            ></el-option>
          </el-select>
          </div>
        </div>
        <div class="oneDeviceInfo">
          <span class="oneDeviceInfoLabel fl">备注：</span>
           <div class="oneLogVal fl">
               <input v-model="addDeviceParam.deviceName" type="text" class="fl input_280" />
          </div>
        </div> -->
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showAddDeviceAlert = false">取 消</el-button>
        <el-button type="primary" v-if="isUpdateDevice" @click="sureUpdateDevice('commit')">提 交</el-button>
        <el-button type="primary" v-if="!isUpdateDevice" @click="sureAddDevice">提 交</el-button>
      </span>
    </el-dialog>
    <el-dialog :title="DomainTit" :visible.sync="showAddStorageAlert" width="530px" height="250px"
      :close-on-click-modal="false" v-dialogDrag>
      <div class="AddDictionaryCon">
        <div class="dictionaryItem">
          <span class="dictionaryLabel fl"><i class="iconfont iconbitian mustIcon"></i>存储域名称：</span>
          <el-input class="dictionaryInput width_300_input fl" type="text"
            v-model="AddStorageDomainVo.domain_name"></el-input>
        </div>
        <div class="dictionaryItem subPeoDiv">
          <span class="dictionaryLabel fl"><i class="iconfont iconbitian mustIcon"></i>分配容量：</span>
          <el-input class="dictionaryInput width_300_input fl numberInput" type="number" min="1"
            v-model="AddStorageDomainVo.domain_size" placeholder="分配容量"></el-input>
          <span class="unit">单位:(T)</span>
          <div class="domainSizeTip">分配容量必须是大于0的整数</div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showAddStorageAlert = false">取 消</el-button>
        <el-button type="primary" v-if="!isUpdateDomain" @click="sureAddDomain">确 定</el-button>
        <el-button type="primary" v-if="isUpdateDomain" @click="sureUpdateDomain">确 定</el-button>
      </span>
    </el-dialog>
    <!--策略-->
    <el-dialog :title="currentDomainName + '策略管理'" :visible.sync="showStrategyAlert" width="500px"
      :close-on-click-modal="false" v-dialogDrag>
      <div class="StrategyDiv">
        <!-- <div class="listTit"><span class="listTitIcon fl"></span><span class="fl">{{currentDomainName}}的管理策略</span>
             </div> -->
        <div class="allStrategy">
          <div class="oneStrategy">
            <div class="StrategyClass">
              <span>近线策略</span>
              <el-switch v-model="strategy.nearLineStrategy.status">
              </el-switch>
            </div>
            <div class="radioDiv">
              <el-radio v-model="strategy.nearLineStrategy.stratrgy_type" :label="2">近线指定天数前的影像文件：</el-radio>
              <el-input-number v-model="strategy.nearLineStrategy.timeSlot" controls-position="right"
                :min="1"></el-input-number>
              天
            </div>
            <div class="radioDiv">
              <el-radio v-model="strategy.nearLineStrategy.stratrgy_type" :label="1">近线影像文件到指定存储域容量：</el-radio>
              <el-input-number v-model="strategy.nearLineStrategy.storagePercentage" controls-position="right" :min="1"
                :max="99"></el-input-number>
              %
            </div>
            <div class="timeChooseDiv">
              <span class="fl">近线策略执行时间：</span>
              <el-time-picker class="chooseTimePicker searchTimePicker"
                v-model="strategy.nearLineStrategy.execExpressionStart" value-format="HH:mm:ss" placeholder="开始时间">
              </el-time-picker>
              <span class="timeChooseSpan">-</span>
              <el-time-picker class="chooseTimePicker searchTimePicker"
                v-model="strategy.nearLineStrategy.execExpressionEnd" value-format="HH:mm:ss" placeholder="结束时间">
              </el-time-picker>
            </div>
          </div>
          <div class="oneStrategy">
            <div class="StrategyClass">
              <span>离线策略</span>
              <el-switch v-model="value1" active-text="" inactive-text="">
              </el-switch>
            </div>
            <div class="radioDiv">
              <el-radio v-model="radio" label="1">删除指定天数前的影像文件：</el-radio>
              <el-input-number v-model="num" controls-position="right" @change="handleChange" :min="1"
                :max="10"></el-input-number>
              天
            </div>
            <div class="radioDiv">
              <el-radio v-model="radio" label="1">删除影像文件到指定存储域容量：</el-radio>
              <el-input-number v-model="num" controls-position="right" @change="handleChange" :min="1"
                :max="100"></el-input-number>
              %
            </div>
            <div class="timeChooseDiv">
              <span class="fl">离线策略执行时间：</span>
              <el-time-picker class="chooseTimePicker searchTimePicker" v-model="value1" value-format="HH:mm:ss"
                placeholder="开始时间">
              </el-time-picker>
              <span class="timeChooseSpan">-</span>
              <el-time-picker class="chooseTimePicker searchTimePicker" v-model="value1" value-format="HH:mm:ss"
                placeholder="结束时间">
              </el-time-picker>
            </div>
          </div>
          <div class="oneStrategy clearBorderRight">
            <div class="StrategyClass">
              <span>压缩策略</span>
              <el-switch v-model="value1" active-text="" inactive-text="">
              </el-switch>
            </div>
            <div class="radioDiv">
              <el-radio v-model="radio" label="1">压缩指定天数前的影像文件：</el-radio>
              <el-input-number v-model="num" controls-position="right" @change="handleChange" :min="1"
                :max="10"></el-input-number>
              天
            </div>
            <div class="radioDiv reduceDiv">
              <el-radio class="firstRadio" v-model="reduceWay" label="1">无损压缩</el-radio>
              <el-radio class="twoRadio" v-model="reduceWay" label="2">定制压缩</el-radio>
              <el-button type="primary" size="small" @click="chooseMade">定 制</el-button>
            </div>
            <div class="timeChooseDiv">
              <span class="fl">压缩策略执行时间：</span>
              <el-time-picker class="chooseTimePicker searchTimePicker" v-model="value1" value-format="HH:mm:ss"
                placeholder="开始时间">
              </el-time-picker>
              <span class="timeChooseSpan">-</span>
              <el-time-picker class="chooseTimePicker searchTimePicker" v-model="value1" value-format="HH:mm:ss"
                placeholder="结束时间">
              </el-time-picker>
            </div>
          </div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showStrategyAlert = false">取 消</el-button>
        <el-button type="primary" @click="confirm">确 定</el-button>
      </span>
    </el-dialog>
    <!--压缩定制-->
    <el-dialog :title="'定制压缩编码'" :visible.sync="showMadeAlert" width="500px" :close-on-click-modal="false" v-dialogDrag>
      <div class="reduceTableData" v-bind:class="{ noTableData: allDeviceList.length == 0 }">
        <template>
          <el-table :data="reduceArr" style="width: 100%" :default-sort="{ prop: 'date', order: 'descending' }"
            ref="multipleTable">
            <el-table-column fixed="left" align="center" type="index" label="序号" width="55">
            </el-table-column>
            <el-table-column prop="image_type" label="影像类型" width="90">
            </el-table-column>
            <el-table-column prop="reduce_code" label="压缩编码">
              <template slot-scope="scope">
                <el-select filterable v-model="scope.row.reduce_code" class="ele-select_32 width_100_select"
                  placeholder="请选择" style="width:300px">
                  <!-- <el-option value="">全部</el-option> -->
                  <el-option v-for="(item, index) in reduce_codeArr" :key="index" :label="item.name"
                    :value="item.code"></el-option>
                </el-select>
              </template>
            </el-table-column>
          </el-table>
        </template>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showMadeAlert = false">取 消</el-button>
        <el-button type="primary" @click="sureMade">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 添加设备异常提示 -->
    <div class="">
      <el-dialog title="提示" :visible.sync="innerVisible" width="40%" :show-close="false"
        :before-close="handleStrategyClose" @opened="openedAlertContent">
        <div slot="title" class="dialog-title fff">
          <i class="iconfont clr_warn" style="font-size: 20px;">&#xe64c;</i>
          <span class="f18 ml5 clr_ff">
            {{ strategyTitle }}
          </span>
        </div>
        <div id="alert_content" class="f16 ml15 mt20 mb20 ml20 mr20">

          <div class="mt10 mb10 " v-for="item in strategyAlertContent">
            <span> <span class="clr_oa">{{ item.name }}</span>已启用按容量{{ item.type }}，若需{{alertType}}{{ addDeviceParam.is_online ?
              '在线' : '近线' }}类型的对象存储设备，请至【存储策略】页面将该存储域的{{ item.type }}策略更改为按天数！
            </span>
            <br>
          </div>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="innerVisible = false">取 消</el-button>
          <el-button type="primary" @click="toSetFn">
            去设置</el-button>
        </span>
      </el-dialog>
      <!---编辑时 如果存储类型 修改了---->
       <el-dialog title="风险提醒" :visible.sync="showRiskTipAlert" width="530px" :close-on-click-modal="false" v-dialogDrag>
          <div class="riskTipContainer">
            <div class="riskTipCon">
              <i class="iconfont iconzhuyi"></i>
              <span class="tipText">
                注意：该设备中已经存储了文件,变更存储类型后需要更新文件的存储<br/>
                <span class="tipTextStatus">状态,否则将导致数据统计错误!</span>
              </span>
            </div>
            <div class="anotherTip">请联系研发中心-测试部的同事,获取详细的处理方式!</div>
          </div>
          <span slot="footer" class="dialog-footer">
            <!-- <el-button type="primary" @click="sureUpdateStorageType">确定变更存储类型</el-button> -->
            <el-button type="primary" @click="sureUpdateDevice('sureChangeStorageType')">确定变更存储类型</el-button>
            <el-button class="cancelBtn" @click="showRiskTipAlert = false">取 消</el-button>
          </span>
        </el-dialog>
    </div>
  </div>
</template>
<script>
import Mgr from '@/utils/SecurityService'
import CommonTable from './components/CommonTable'
import { getInstitutionListLite } from '@/api/platform_costomer/institution'
import {
  getAllDomains,
  addDomains,
  getDomainDeviceList,
  getAllDevices,
  addDevices,
  updateDevice,
  updateDomain,
  delOneDomain,
  addDomainDevice,
  delOneDevice,
  updateDomainDeviceStu,
  saveStorageTrategies,
  getCurrentDomainStrategies,
  getStorageFileType,
} from '@/api/memorySharing/dataMemory'
import { getDistinfoByType,} from "@/api/commonHttp";
import { mapGetters } from 'vuex'
import {encryptData,decryptUsing3DES} from '@/utils/desEncrypt'

export default {
  components: {
    CommonTable
  },
  data() {
    return {
      psdType:'password',
      alertType:'添加',
      strategyAlertContent: [],
      innerVisible: false,
      strategyTitle: '对象存储与存储域【存储域名称】已启用的策略冲突，请调整策略！',
      pickerOptions: {
        shortcuts: [
          {
            text: '今天',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              // start.setTime(start.getTime() - 3600 * 1000 * 24 * 6);
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 6)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 29)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 89)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      requestOver: false,
      allDeviceList: [],
      getDeviceListParam: {
        Device_type: '',
        Device_name: '',
        Is_online: true,
        Is_enable: true,
        Page_index: 1,
        Page_size: 1000
      },
      currentDomainStrategies: {},
      currentDomainName: '',
      currentDomainIndex: 0,
      isUpdateDomain: false,
      isUpdateDevice: false,
      currentDomainId: '',
      deviceTit: '添加设备',
      DomainTit: '新增存储域',
      AddStorageDomainVo: {
        domain_name: '',
        domain_size: '',
      },
      addDeviceParam: {
        device_name: '',
        device_type: '',
        device_host: '',
        device_path: '',
        is_online: true,
        is_enable: true,
        device_size: '',
        sort_no: 0,
        access_id: '',
        access_key: '',
        org_code: [],
        org_name: '',
        depart_code: [],
        token: '',
        file_type:[],
      },
      // fileTypes:[{id:121212,name:'原始影像',code:'1'}],
      fileTypes: [],
      currentDeviceId: '',
      DomainsArr: [],
      timer: [],
      value1: false,
      num: 0,
      radio: 1,
      showAddDeviceAlert: false,
      showAddStorageAlert: false,
      showMadeAlert: false,
      showStrategyAlert: false,
      searchData: {
        citys: '',
        serviceState_value: '',
        coustorType_value: '',
        serviceType_value: '',
        key_value: '',
        moreDevice: []
      },
      deviceClassArr: [
        {
          id: 0,
          name: '亚马逊S3'
        },
        {
          id: 1,
          name: '阿里云OSS'
        },
        {
          id: 2,
          name: '华为云OSS'
        },
        {
          id: 3,
          name: '腾讯云OSS'
        },
        {
          id: 4,
          name: '电信云OSS'
        },
        {
          id: 5,
          name: '移动云OSS'
        },
        {
          id: 6,
          name: 'NAS存储'
        },
        {
          id: 7,
          name: 'SAN本地存储'
        },
        {
          id: 8,
          name: 'FTP'
        },
        {
          id: 9,
          name: '浙江省移动OSS'
        },
        {
          id: 10,
          name: '互盟OSS'
        },
        {
          id: 11,
          name: '国寿云OSS'
        },
      ],
      reduceWay: 0,
      reduce_codeArr: [
        {
          name: 'RLE Lossless',
          code: 'Lossless'
        },
        {
          name: 'JPEG Lossless',
          code: 'JPEG Lossless'
        },
        {
          name: 'JPEG2000 Lossless',
          code: 'JPEG2000 Lossless'
        },
        {
          name: 'JPEGLossy',
          code: 'JPEGLossy'
        },
        {
          name: 'MPEG2',
          code: 'MPEG2'
        }
      ],
      reduceArr: [
        {
          id: 0,
          image_type: 'CR',
          reduce_code: ''
        },
        {
          id: 1,
          image_type: 'CT',
          reduce_code: ''
        },
        {
          id: 2,
          image_type: 'DX',
          reduce_code: ''
        },
        {
          id: 3,
          image_type: 'RF',
          reduce_code: ''
        },
        {
          id: 4,
          image_type: 'MG',
          reduce_code: ''
        },
        {
          id: 5,
          image_type: 'MR',
          reduce_code: ''
        },
        {
          id: 6,
          image_type: 'PX',
          reduce_code: ''
        },
        {
          id: 7,
          image_type: 'XA',
          reduce_code: ''
        },
        // {
        //   id: 8,
        //   name: 'FTP'
        // },
        {
          id: 9,
          image_type: 'US',
          reduce_code: ''
        }
      ],
      addDomainDevice: {
        domain_id: '',
        device_id: '',
        is_enable: true
      },
      addDictInfoParams: {
        dic_code: '',
        dic_name: '',
        dic_extend: ''
      },
      tenancyId: '',
      institutionList: [],
      coustorType: [
        { type: 0, type_str: '医联体' },
        { type: 1, type_str: '医共体' },
        { type: 2, type_str: '公立医院' },
        { type: 3, type_str: '民营医院' }
      ],
      propData: [
        { prop: 'device_type', label: '设备类型', width: 120 },
        { prop: 'is_enable', label: '设备状态', width: 80 },
        { prop: 'is_online', label: '存储类型', width: 100 },
        { prop: 'device_name', label: '设备名称', width: 170 },
        { prop: 'device_host', label: '设备主机', width: 170 },
        { prop: 'device_path', label: '存储路径', width: 170 },
        { prop: 'org_name', label: '关联机构', width: 170 },
        { prop: 'update_user_name', label: '最后操作人', width: 120 },
        { prop: 'last_update_time', label: '操作时间', width: 200 },
        { prop: 'device_size', label: '总容量(TB)', width: 160 },
        { prop: 'used_size', label: '已用容量', width: 160 },
        { prop: 'sort_no', label: '排序号' }
      ],
      strategy: {
        nearLineStrategy: {},
        deleteStrategy: {},
        compressionStrategy: {}
      },
      officeTypeArr: [],
      showRiskTipAlert: false,//风险提示的弹窗
    }
  },
  methods: {
    // 获取字典列表
    async getDistinfoFn() {
      const self = this
      var _parmas = "ExamDept";
      var _url = `/dict/${_parmas}`;
      const res = await getDistinfoByType(_url);
      if (res.code !== 0 || res.data.length === 0) {
        return;
      }
      self.officeTypeArr = [];
      res.data.forEach((item) => {
        if (item.lookup_key === "ExamDept") {
          self.officeTypeArr.push(item);
        }
      });
      console.log(self.officeTypeArr)
    },
    // 获取存储文档
    async beganGetStorageFileType() {
      const res = await getStorageFileType();
      if (res.code == 0) {
        this.fileTypes = res.data
      } else {
        this.$message.error(res.msg)
      }
    },
    // 设置进度条背景颜色
    processColorFn(val) {
      if (val < 50) {
        return '#1ab44a'
      } else if (val > 50 && val < 80) {
        return '#e6a23c'
      } else {
        return '#f56c6c'
      }
    },
    confirm() {
      const temp = JSON.parse(JSON.stringify(this.strategy.nearLineStrategy))
      if (
        (temp.execExpressionStart && !temp.execExpressionEnd) ||
        (temp.execExpressionEnd && !temp.execExpressionStart)
      ) {
        this.$message.error('请选择近线策略执行时间!')
        return
      }
      if (!temp.stratrgy_type && temp.status) {
        this.$message.error('请选择近线策略!')
        return
      }
      if (temp.stratrgy_type === 2 && !temp.timeSlot) {
        this.$message.error('请指定天数!')
        return
      }
      if (temp.stratrgy_type === 1 && !temp.storagePercentage) {
        this.$message.error('请指定存储域容量!')
        return
      }
      if (
        (!temp.execExpressionStart || !temp.execExpressionEnd) &&
        temp.status
      ) {
        this.$message.error('请选择近线策略执行时间!')
        return
      }
      temp.exec_expression =
        temp.execExpressionStart + '-' + temp.execExpressionEnd
      temp.storage_percentage = temp.storagePercentage / 100
      temp.time_slot = temp.timeSlot
      delete temp.execExpression
      delete temp.storagePercentage
      delete temp.timeSlot
      const data = {
        domain_id: this.addDomainDevice.domain_id,
        strategies: []
      }
      data.strategies.push(temp)
      saveStorageTrategies(data).then(res => {
        if (res.code === 0) {
          this.$message.success('保存成功')
          this.showStrategyAlert = false
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    chooseMade() {
      this.showMadeAlert = true
    },

    // 确定定制
    sureMade() { },
    getTenancyId() {
      const self = this
      var manager = new Mgr()
      manager.getRole().then(function (logindata) {
        self.tenancyId = sessionStorage.getItem('curTenancyId') || logindata.profile.tenancy_id
      })
    },
    showDomainOperate(e) {
      const obj = e.currentTarget
      const spanObj = obj.getElementsByClassName('operateBtn')[0]
      spanObj.style.display = 'block'
    },
    hideDomainOperate(e) {
      const obj = e.currentTarget
      const spanObj = obj.getElementsByClassName('operateBtn')[0]
      spanObj.style.display = 'none'
    },
    // 字节byte转换为TB
    changeTbUnit(limit) {
      var size = ''
      // size = ( limit/( 1024 * 1024 * 1024 * 1024)). toFixed( 2) + "TB"
      size = Number((limit / (1024 * 1024 * 1024 * 1024)).toFixed(2))
      var sizeStr = size + '' // 转成字符串
      var index = sizeStr.indexOf('.') // 获取小数点处的索引
      var dou = sizeStr.substr(index + 1, 2) // 获取小数点后两位的值
      if (dou == '00') {
        // 判断后两位是否为00，如果是则删除00
        return Number(
          sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2)
        )
      }
      return size
    },
    // 切换存储域
    chooseStorage(e, index, domainObj) {
      const obj = e.currentTarget
      const chartArr = document.getElementsByClassName('chartCon')
      for (let i = 0; i < chartArr.length; i++) {
        chartArr[i].classList.remove('activeChart')
      }
      obj.classList.add('activeChart')
      this.currentDomainName = domainObj.domain_name
      this.addDomainDevice.domain_id = domainObj.id
      if (this.currentDomainIndex !== index) {
        this.getMyDomainDetail(domainObj.id)
      }
      this.getCurrentDomainStrategies(domainObj.id)
      this.currentDomainIndex = index
    },
    // 切换机构
    changeInstitute(codeArr) {
      const self = this
      const instituteNameArr = []
      self.institutionList.forEach(item => {
        codeArr.forEach(val => {
          if (item.code === val) {
            instituteNameArr.push(item.name)
          }
        })
      })
      self.addDeviceParam.org_name = instituteNameArr.toString()
    },
    // 获取机构列表
    async getInstitutionListLiteFn() {
      const url = '?tenancy_id=' + this.tenancyId
      const res = await getInstitutionListLite(url)
      if (res.code === 0) {
        this.institutionList = res.data
      }
    },
    // 添加设备
    AddDevice() {
      this.psdType = 'password'
      this.deviceTit = '添加设备'
      this.isUpdateDevice = false
      this.showAddDeviceAlert = true
      this.psdType = 'password'
      this.addDeviceParam = {
        device_name: '',
        device_type: '',
        device_host: '',
        device_path: '',
        is_online: true,
        is_enable: true,
        device_size: '',
        sort_no: 0,
        access_id: '',
        access_key: '',
        org_code: [],
        org_name: '',
        depart_code: [],
        token: '',
        file_type:[],
      }
    },
    async beganDelDomain(id, index) {
      const param = {
        id: id
      }
      const res = await delOneDomain(param)
      if (res.code === 0) {
        this.$message({ message: '删除存储域成功', type: 'success' })
        if (this.currentDomainIndex === index) {
          // 删除当前选中的那个的话 默认恢复选中第一个存储域
          this.currentDomainIndex = 0
        }
        this.getMyAllDomains()
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 删除存储域
    delDomain(id, index) {
      const self = this
      self
        .$confirm('确定要删除该存储域?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          customClass: 'warningAlert',
          type: 'warning'
        })
        .then(() => {
          self.beganDelDomain(id, index)
        })
        .catch(() => { })
    },
    async beganDelDevice(id) {
      const param = {
        id: id
      }
      const res = await delOneDevice(param)
      if (res.code === 0) {
        this.$message({ message: '删除设备成功', type: 'success' })
        this.getMyDomainDetail(this.addDomainDevice.domain_id)
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    delAuthorize(id) {
      const self = this
      self
        .$confirm('确定要删除该设备?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          customClass: 'warningAlert',
          type: 'warning'
        })
        .then(() => {
          self.beganDelDevice(id)
        })
        .catch(() => { })
    },
    // 添加存储域
    addStorage() {
      this.DomainTit = '新增存储域'
      this.isUpdateDomain = false
      this.showAddStorageAlert = true
      this.AddStorageDomainVo = {
        domain_name: '',
        domain_size: '',
      }
    },
    watchDeviceDetail(obj) {
      this.deviceTit = '编辑设备'
      this.isUpdateDevice = true
      this.showAddDeviceAlert = true
      this.psdType = 'password'

      this.currentDeviceId = obj.id
      this.psdType = 'password'
      this.addDeviceParam = {
        device_name: obj.device_name,
        device_type: obj.device_type,
        device_host: obj.device_host,
        device_path: obj.device_path,
        is_online: obj.is_online,
        is_enable: obj.is_enable,
        device_size: obj.device_size,
        sort_no: obj.sort_no,
        access_id: obj.access_id,
        access_key: decryptUsing3DES(obj.access_key),
        org_code: (obj.org_code && obj.org_code.length != 0) ? obj.org_code.split(',') : [],
        org_name: obj.org_name,
        depart_code: (obj.depart_code&&obj.depart_code.length != 0) ? obj.depart_code.split(',') : [],
        token: obj.token,
        file_type:(obj.file_type&&obj.file_type.length != 0) ? obj.file_type.split(',') : [],
      }
    },
    verifyAddDomains () {
      if (!this.AddStorageDomainVo.domain_name) {
        this.$message({ message: '请输入存储域名称', type: 'error' })
        return false
      }
      var regNumber = /^\+?[1-9][0-9]*$/
      if (this.AddStorageDomainVo.domain_size === '') {
        this.$message({ message: '请输入分配容量', type: 'error' })
        return false
      }
      if (
        regNumber.test(Number(this.AddStorageDomainVo.domain_size)) == false
      ) {
        this.$message({ message: '分配容量必须是大于0的整数', type: 'error' })
        return false
      }
      this.AddStorageDomainVo.domain_size = String(this.AddStorageDomainVo.domain_size)
      // this.AddStorageDomainVo.domain_size = parseInt(this.AddStorageDomainVo.domain_size)
      return true
    },
    verifyAddDevice(id) {
      if (!this.addDeviceParam.device_name) {
        this.$message({ message: '请输入存储设备名称', type: 'error' })
        return false
      }
      if (this.addDeviceParam.device_type === '') {
        this.$message({ message: '请选择存储类型', type: 'error' })
        return false
      }
      if (this.addDeviceParam.device_size === '') {
        this.$message({ message: '请输入容量大小', type: 'error' })
        return false
      }
      if (
        !this.addDeviceParam.access_id &&
        this.addDeviceParam.device_type !== 7 &&
        this.addDeviceParam.device_type !== 9
      ) {
        this.$message({ message: '请输入访问ID', type: 'error' })
        return false
      }
      if (
        !this.addDeviceParam.access_key &&
        this.addDeviceParam.device_type !== 7
      ) {
        this.$message({ message: '请输入访问KEY', type: 'error' })
        return false
      }
      if (
        !this.addDeviceParam.device_path &&
        (this.addDeviceParam.device_type === 6 ||
          this.addDeviceParam.device_type === 7)
      ) {
        this.$message({ message: '请输入存储路径', type: 'error' })
        return false
      }
      if (
        !this.addDeviceParam.device_host &&
        this.addDeviceParam.device_type !== 6 &&
        this.addDeviceParam.device_type !== 7
      ) {
        this.$message({ message: '请输入设备主机', type: 'error' })
        return false
      }
      const idx = this.allDeviceList.findIndex(item => {
        return item.sort_no === this.addDeviceParam.sort_no && item.id !== id
      })
      //console.log(this.allDeviceList, this.addDeviceParam.sort_no, id)
      if (idx !== -1) {
        this.$message({ message: '排序号不能相同', type: 'error' })
        return false
      }

      //if(this.addDeviceParam.file_type != 1)this.addDeviceParam.file_type = null

      return this.verifyDeviceDomainStrategy()

      return true
    },
    verifyDeviceDomainStrategy() {
      if (this.addDeviceParam.device_type >= 6) return true

      //判断存储策略中是否有按照容量配置的且当前为对象存储设备
      // if (this.currentDomainStrategies && this.currentDomainStrategies.strategy_type != 2) {

      //   let titles = this.dealStrategyData(this.currentDomainStrategies.strategy_type, this.currentDomainStrategies.storage_strategies||[], this.addDeviceParam.is_online)

      //   if (titles.length > 0) {
      //     //有异常情况
      //     // if (this.currentDomainStrategies.strategy_type == 0) {

      //     // } else {

      //     // }
      //     this.strategyAlertContent = titles
      //     this.innerVisible = true


      //     return false
      //   }
      // }
      return true

    },

    handleStrategyClose() {
      this.innerVisible = false
    },
    toSetFn() {
      this.$router.push({ path: 'storageStrategy' })
    },
    openedAlertContent() {

    },
    dealStrategyData(strategy_type, list, online) {

      //online == true 在线存储 近线存储
      let titles = []

      if (strategy_type != 0) {
        this.strategyTitle = `对象存储与业务系统已启用的策略冲突，请调整策略！`

      } else {
        this.strategyTitle = `对象存储与存储域【${this.currentDomainName}】已启用的策略冲突，请调整策略！`

        if (!online) {
          titles.push({
            name: '',
            type: '离线'
          })
          return titles
        }
      }

      if (online) {

        let twoConfigList = list.filter(item => item.nearline_enable && item.offline_enable && item.nearline_mode == 1 && item.offline_mode == 1)
        let nearConfigList = list.filter(item => item.nearline_enable && item.nearline_mode == 1 && !twoConfigList.includes(item))
        let offConfigList = list.filter(item => item.offline_enable && item.offline_mode == 1 && !twoConfigList.includes(item))

        if (strategy_type == 0) {
          if (twoConfigList.length > 0) {
            titles.push({
              name: '',
              type: '近线、离线'
            })
          }
          if (nearConfigList.length > 0) {
            titles.push({
              name: '',
              type: '近线'
            })
          }
          if (offConfigList.length > 0) {
            titles.push({
              name: '',
              type: '离线'
            })
          }
          return titles


        } else {
          let twoSystemNames = twoConfigList.map(item => `【${item.system_name}】`)
          let nearSystemNames = nearConfigList.map(item => `【${item.system_name}】`)
          let offSystemNames = offConfigList.map(item => `【${item.system_name}】`)
          if (twoSystemNames.length > 0) {
            //离线、近线都开启按照容量配置策略

            titles.push({
              name: twoSystemNames.join(''),
              type: '近线、离线'
            })
          }
          if (nearSystemNames.length > 0) {
            //离线、近线都开启按照容量配置策略

            titles.push({
              name: nearSystemNames.join(''),
              type: '近线'
            })
          }
          if (offSystemNames.length > 0) {
            //离线、近线都开启按照容量配置策略

            titles.push({
              name: offSystemNames.join(''),
              type: '离线'
            })
          }

          return titles
        }


      } else {
        //近线类型只需要判断离线策略是否按照容量配置
        let systemNames = list.filter(item => item.offline_enable && item.offline_mode == 1).map(item => `【${item.system_name}】`)
        if (systemNames.length > 0) {
          titles.push({
            name: systemNames.join(''),
            type: '离线'
          })
        }
        return titles
      }
      return []

    },
    // 确定添加存储设备
    async sureAddDevice() {
      this.alertType = '添加'
      const self = this
      if (self.verifyAddDevice()) {
        // self.addDeviceParam.org_code = self.addDeviceParam.org_code.toString()
        // self.addDeviceParam.depart_code = self.addDeviceParam.depart_code.toString()
        // let params = {...self.addDeviceParam}

        let params = JSON.parse(JSON.stringify(self.addDeviceParam))
        params.org_code = params.org_code.toString()
        params.depart_code = params.depart_code.toString()
        params.file_type = params.file_type.toString()
        params.domain_id = this.addDomainDevice.domain_id;
        const res = await addDevices(params)
        if (res.code === 0) {
          self.showAddDeviceAlert = false
          self.$message({ message: '添加设备成功', type: 'success' })
          self.addDomainDevice.device_id = res.data
          self.addOneDomainDevice()
        } else {
          self.$message({ message: `${res.msg}`, type: 'error' })
        }
      }
    },
    // 添加存储域存储设备关联关系
    async addOneDomainDevice() {
      const res = await addDomainDevice(this.addDomainDevice)
      if (res.code === 0) {
        this.getMyDomainDetail(this.addDomainDevice.domain_id)
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 编辑存储域
    editDomain(obj) {
      this.DomainTit = '修改存储域'
      this.isUpdateDomain = true
      this.showAddStorageAlert = true
      this.currentDomainId = obj.id
      this.AddStorageDomainVo = {
        domain_name: obj.domain_name,
        domain_size: parseInt(obj.domain_size),
      }
    },
    // 确定修改存储域
    async sureUpdateDomain() {
      if (this.verifyAddDomains()) {
        const res = await updateDomain(
          this.AddStorageDomainVo,
          this.currentDomainId
        )
        if (res.code === 0) {
          this.showAddStorageAlert = false
          this.$message({ message: '修改存储域成功', type: 'success' })
          this.getMyAllDomains()
        } else {
          this.$message({ message: `${res.msg}`, type: 'error' })
        }
      }
    },
    // 确定添加存储域
    async sureAddDomain() {

      if (this.verifyAddDomains()) {
        const res = await addDomains(this.AddStorageDomainVo)
        if (res.code === 0) {
          this.showAddStorageAlert = false
          this.$message({ message: '添加存储域成功', type: 'success' })
          this.getMyAllDomains()
        } else {
          this.$message({ message: `${res.msg}`, type: 'error' })
        }
      }
    },

    async sureUpdateDevice(type) {
      this.alertType = '变更为'

      if (this.verifyAddDevice(this.currentDeviceId)) {
        // this.addDeviceParam.org_code = this.addDeviceParam.org_code.toString()
        // this.addDeviceParam.depart_code = this.addDeviceParam.depart_code.toString()

        let params = JSON.parse(JSON.stringify(this.addDeviceParam))
        params.ignore_online_change = 0
        if (type == 'sureChangeStorageType') { // 改变了存储类型 然后变更前的存储设备里面 还有数据
          params.ignore_online_change = 1
        }

        // params.id = this.currentDeviceId
        params.org_code = params.org_code.toString()
        params.depart_code = params.depart_code.toString()
        params.file_type = params.file_type.toString()
        const res = await updateDevice(
          params,
          this.currentDeviceId
        )
        if (res.code === 0) {
          this.showAddDeviceAlert = false
          if (type == 'sureChangeStorageType') {
            this.showRiskTipAlert = false
          }
          this.$message({ message: '修改设备成功', type: 'success' })
          this.getMyDomainDetail(this.addDomainDevice.domain_id)
        } else {
          if (res.code == -2) {
            this.showRiskTipAlert = true
          } else {
            this.$message({ message: `${res.msg}`, type: 'error' })
          }
        }
      }
    },
    // 对存储设备按照排序号进行排序
    sortData(property) {
      return function (a, b) {
        var value1 = a[property]
        var value2 = b[property]
        return value1 - value2
      }
    },
    // 获取存储设备列表
    async getDeviceList () {
      const self = this
      const res = await getAllDevices(self.getDeviceListParam)
      if (res.code === 0) {
        self.allDeviceList = res.data
        // self.allDeviceList = self.allDeviceList.sort(self.sortData('sort_no'))
        self.$nextTick(() => {
          if (self.$refs.deviceListTable && self.$refs.deviceListTable.doLayout) {
            self.$refs.deviceListTable.doLayout();
          }
        })
      } else {
        self.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 获取存储域详情
    async getMyDomainDetail (id) {
      const self = this
      const res = await getDomainDeviceList({ id: id })
      if (res.code === 0) {
        self.allDeviceList = res.data
        self.allDeviceList = self.allDeviceList.sort(self.sortData('sort_no'))
        self.$nextTick(() => {
          self.$refs.deviceListTable.doLayout()
        })
      } else {
        self.requestOver = true
        self.$message({ message: `${res.msg}`, type: 'error' })
      }
    },

    async getCurrentDomainStrategies(id) {
      //获取当前存储域下的存储策略
      const res = await getCurrentDomainStrategies({ domain_id: id })
      if (res.code === 0) {
        this.currentDomainStrategies = res.data
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },

    setTableHeight() {
      const self = this
      self.$nextTick(() => {
        var DeviceConObj = document.getElementsByClassName('DeviceCon')[0]
        var deviceListObj = document.getElementsByClassName('deviceList')[0]
        var allDeviceObj = document.getElementsByClassName('allDevice')[0]
        var allDeviceMarginTop = 10
        // versionHead 40px 、inspectRecord-query 51px、blockPage 57px
        if (deviceListObj) {
          deviceListObj.style.height =
            DeviceConObj.clientHeight -
            allDeviceObj.clientHeight -
            allDeviceMarginTop -
            58 +
            'px'
        }
      })
    },
    getByteSize(val, unit) {
      const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
      const i = sizes.findIndex(item => item === unit)
      const k = 1024
      return val * Math.pow(1024, i)
    },
    bytesToSize(btyes) {
      if (btyes === 0) {
        return '0B'
      }
      const k = 1024
      const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
      let i = Math.floor(Math.log(btyes) / Math.log(k))
      if (i < 2) {
        i = 2
      }
      const num = btyes / Math.pow(k, i)
      const value = num.toFixed(3) / 1
      const unit = sizes[i]
      const text = `${value}${unit}`
      return {
        value,
        unit,
        text
      }
    },
    // 乘(处理 0.0039*100 不等于 0.39的精度丢失问题)
    floatMultiply(arg1, arg2) {
      if (arg1 == null || arg2 == null) {
        return null;
      }
      var n1, n2;
      var r1, r2; // 小数位数
      try {
        r1 = arg1.toString().split(".")[1].length;
      } catch (e) {
        r1 = 0;
      }
      try {
        r2 = arg2.toString().split(".")[1].length;
      } catch (e) {
        r2 = 0;
      }
      n1 = Number(arg1.toString().replace(".", ""));
      n2 = Number(arg2.toString().replace(".", ""));
      return n1 * n2 / Math.pow(10, r1 + r2);
    },
    // 获取所有的存储域
    async getMyAllDomains() {
      const self = this
      const res = await getAllDomains({ returnDevice: true })
      if (res.code === 0) {
        self.DomainsArr = []
        if (res.data.length !== 0) {

          if (self.currentDomainIndex >= res.data?.length) {
            self.currentDomainIndex = 0;
          }
          self.currentDomainName =
            res.data[self.currentDomainIndex].domain_name;
          self.addDomainDevice.domain_id = res.data[self.currentDomainIndex].id;
          self.getMyDomainDetail(res.data[self.currentDomainIndex].id);
          this.getCurrentDomainStrategies(res.data[self.currentDomainIndex].id)



          res.data.forEach(val => {
            const domainSize = this.getByteSize(val.domain_size, 'TB')
            val.usedSize = this.bytesToSize(val.used_size)
            if (val.used_size === 0) {
              val.usedRate = 0
            } else {
              var percentNum = (
                val.used_size / domainSize
              ).toFixed(4)
              val.usedRate = self.floatMultiply(percentNum, 100)
            }
            //  val.usedDesc = val.used_size + 'T/' + val.domain_size + 'T'
            self.DomainsArr.push(val)
          })
          self.setTableHeight()
        } else {
          self.allDeviceList = []
          self.requestOver = true
          self.setTableHeight()
        }
      } else {
        self.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    async beganDisableDevice(obj) {
      const param = {
        domain_id: this.addDomainDevice.domain_id,
        device_id: obj.id,
        is_enable: !obj.is_enable
      }
      const res = await updateDomainDeviceStu(param)
      if (res.code === 0) {
        if (obj.is_enable) {
          this.$message({ message: '禁用设备成功', type: 'success' })
        } else {
          this.$message({ message: '启用设备成功', type: 'success' })
        }
        this.getMyDomainDetail(this.addDomainDevice.domain_id)
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    DisableDevice(obj) {
      if (!obj.is_enable ) {
        this.alertType = '启用'
        if(!this.verifyDeviceDomainStrategy(obj.id))return
      }

      const self = this
      let messageTip = ''
      if (obj.is_enable) {
        messageTip = '确定要禁用该设备吗?'
      } else {
        messageTip = '确定要启用该设备吗?'
      }
      self
        .$confirm(messageTip, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          customClass: 'warningAlert',
          type: 'warning'
        })
        .then(() => {
          self.beganDisableDevice(obj)
        })
        .catch(() => { })
    },
    handleChange() { }
  },
  mounted() {
    const self = this
    self.getInstitutionListLiteFn()
    self.getTenancyId()
    self.getMyAllDomains()
    window.onresize = function () {
      self.setTableHeight()
    }
    // 获取检查科室
    self.getDistinfoFn()
    // 获取存储文档列表
    self.beganGetStorageFileType()

  },
  computed: {

    ...mapGetters(['cardStyle']),
    containerClass() {
      if (this.requestOver && this.DomainsArr.length === 0 && this.cardStyle) {
        return 'noDomain cardContainer'
      } else if ((this.requestOver && this.DomainsArr.length === 0) || this.cardStyle) {
        return this.cardStyle ? 'cardContainer' : 'noDomain'
      }
      return ''
    }

  }
}
</script>
<style lang="less" scoped>


.clr_warn {
  color: rgba(239, 137, 0, 1);
}

.clr_oa {
  color: #0a70b0;
}

/deep/ .white-head .el-dialog__header {
  background-color: white;
  color: #2b354a;
}

/deep/ .el-table__fixed-body-wrapper {
  height: calc(100% - 40px);
}
.userlist {
  height: 100%;
  background-color: #EBEEF5;

}
.suffix_iconfont {
  .iconfont {
    font-size: 10px;
  }
}

.cardHeader {
  background-color: white;
}

.noDomain {
  background: url('../../../assets/images/common/noStorage.png') no-repeat center;
}

.cardContainer {
  margin: 10px !important;
  border-radius: 5px !important;
  height: calc(100% - 47px - 20px) !important;

}

.DeviceCon {
  background-color: white;
  height: calc(100% - 46px);

  .allDevice {
    width: 100%;
    float: left;
    display: grid;
    padding: 0 15px;
    grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
    border-bottom: 1px solid #dcdfe6;
    max-height: 50%;

    .oneDevice {
      // width:270px;
      width: calc(100% - 15px);
      height: 126px;
      border: 1px solid rgba(10, 112, 176, 0.25);
      margin: 0 15px 12px 0;
      float: left;
      cursor: pointer;
      border-radius: 4px;
      position: relative;

      .deviceHead {
        height: 40px;
        line-height: 40px;
        font-size: 15px;
        color: #303133;
        // text-align: center;
        border-bottom: 1px solid rgba(10, 112, 176, 0.25);
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        word-break: break-all;
        font-weight: bold;
        padding: 0 15px;
      }

      .deviceContent {
        padding: 0 15px;
      }

      .usedTit {
        margin-top: 8px;
        float: left;
        width: 100%;

        span {
          font-size: 14px;
          color: #909399;
          line-height: 20px;
        }
      }

      .usedNum {
        float: left;
        width: 100%;

        span {
          line-height: 30px;
          font-size: 20px;
          color: #303133;
          font-family: Arial;
          font-weight: bold;
        }

        .noFontWeight {
          font-weight: initial;
        }
      }

      ::v-deep .el-progress-bar__innerText {
        position: relative;
        top: -2px;
      }

      .operateBtn {
        position: absolute;
        right: 8px;
        top: 6px;
        display: none;

        .editDomainIcon {
          float: right;

          i {
            font-size: 16px !important;
            background: #0a70b0;
            border-radius: 3px;
            color: #fff !important;
            display: block;
            width: 28px;
            height: 28px;
            line-height: 28px;
            text-align: center;
          }
        }

        .delDomainIcon {
          float: right;

          i {
            font-size: 16px !important;
            background: #da4a4a;
            border-radius: 3px;
            color: #fff !important;
            display: block;
            width: 28px;
            height: 28px;
            line-height: 28px;
            text-align: center;
          }
        }
      }
    }

    .oneDevice:hover {
      border-color: rgba(90, 134, 161, 0.5);
      background: #ebf5ff;
    }

    .activeChart {
      border-color: rgba(90, 134, 161, 0.5);
      background: #ebf5ff;
      box-shadow: 0px 2px 6px 0px rgba(25, 25, 25, 0.1);
    }
  }

  .domainCon {
    height: 300px;
    overflow: auto;
    position: relative;
  }

  .chartCon {
    width: 370px;
    height: 280px;
    cursor: pointer;
    border-radius: 4px;
    margin-right: 30px;
    position: relative;

    // box-shadow:1px 0px 6px 0px rgba(0,0,0,0.1);
    .w370 {
      width: 370px;
    }

    .h250 {
      height: 250px;
    }

    .addImgCon {
      width: 80px;
      height: 80px;
      cursor: pointer;
      margin: 0 auto;
      margin-top: 95px;
    }

    .chartState {
      width: 100%;
      text-align: center;
      position: absolute;
      bottom: 0px;
      line-height: 52px;
      font-size: 18px;
    }
  }

  .listTit {
    height: 48px;
    line-height: 48px;
    font-size: 16px;
    color: #303133;
    font-weight: 700;
    padding: 0 15px;

    .color_orange {
      color: #ff9a50;
    }

    .listTitIcon {
      width: 3px;
      height: 16px;
      background: #0a70b0;
      margin-right: 12px;
      margin-top: 16px;
    }

    .function-btn {
      font-weight: initial;
      margin-top: 9px;
    }

    .loadDeviceTit {
      font-size: 15px;
    }
  }

  .deviceList {
    padding: 0 15px;

    .tableDiv {
      height: 100%;
      // margin-bottom:20px;
      border: 1px solid #dcdfe6;

      .organTableData {
        // min-height: 160px;
        height: 100%;

        ::v-deep th {
          background: #f9f9f9;
          color: rgb(51, 51, 51);
        }

        .el-table {
          height: 100%;
          border: none;

          ::v-deep .el-table__body-wrapper {
            min-height: 120px;
            height: calc(100% - 40px);
            overflow: auto !important;
          }
        }

        ::v-deep .el-table-column--selection .cell {
          padding-left: 10px;
        }
        ::v-deep .el-table__fixed-body-wrapper{
          height: calc(100% - 56px)!important;
        }

      }

      .blockPage {
        text-align: center;
      }
    }
  }
}

.enableStu {
  color: #00a367;
  font-size: 14px;
  font-weight: 400;
}

.stopStu {
  font-size: 14px;
  font-weight: 400;
  color: #da4a4a;
}

.chooseTimePicker {
  width: 130px;
}

.timeChooseSpan {
  margin: 0 10px;
}

.addDeviceCon {
  padding-top: 25px;
  padding: 25px;

  .oneDeviceInfo {
    height: 36px;
    line-height: 35px;
    margin-bottom: 20px;

    .oneDeviceInfoLabel {
      width: 120px;
      text-align: right;
    }

    .input_190 {
      width: 190px;
      height: 36px;
      line-height: 36px;
      border: none;
      border: 1px solid #dcdfe6;
      border-radius: 3px;
      padding-left: 8px;
    }

    .unitTip {
      width: 90px;
      color: #303133;
      text-align: center;
    }

    .input_280 {
      width: 280px;
      height: 36px;
      line-height: 36px;
      border: none;
      border: 1px solid #dcdfe6;
      border-radius: 3px;
      padding-left: 8px;
    }

    .width_280_select {
      width: 280px !important;

      ::v-deep .el-input__inner {
        height: 36px!important;
        line-height: 36px;
      }

      ::v-deep .el-input__icon {
        line-height: 36px;
      }
    }

    /**必填的图标样式*/
    .iconbitian {
      color: #da4a4a;
      font-size: 10px;
    }
  }
}

/**新增存储域弹窗样式 */
.AddDictionaryCon {
  padding-top: 25px;
  height: 160px;

  .dictionaryItem {
    height: 36px;
    margin-bottom: 20px;

    .dictionaryLabel {
      width: 120px;
      height: 36px;
      text-align: right;
      line-height: 36px;
    }

    .dictionaryInput {
      height: 36px;
      line-height: 35px;

      ::v-deep .el-input__inner {
        height: 36px;
        line-height: 36px;
        border-radius: 3px;
      }
    }

    .domainSizeTip {
      color: #e6a23c;
      font-size: 15px;
      line-height: 36px;
      margin-left: 120px;
    }
  }
}

.numberInput {
  ::v-deep .el-input__inner {
    padding-right: 0px;
  }
}

.noTableData {
  background: none !important;
}

.editDomainIcon {
  i {
    font-size: 16px !important;
    color: #0c83cd;
  }
}

.delDomainIcon {
  i {
    font-size: 16px !important;
    color: #f56c6c;
  }
}

.unit {
  line-height: 36px;
}

::v-deep .el-table__empty-text {
  display: none;
}

.width_280_input {
  width: 280px;
}

.dictionaryDesc {
  ::v-deep .el-input__inner {
    height: 36px !important;
    line-height: 34px !important;
  }

  ::v-deep .el-input-number__decrease {
    bottom: 2px !important;
    line-height: 17px !important;
  }

  ::v-deep .el-input-number__increase {
    top: 2px !important;
    line-height: 17px !important;
  }
}

.reduceTableData {
  padding: 15px;
  width: 100%;

  ::v-deep .el-table {
    border: 1px solid #dcdfe6;
    border-bottom: none;
  }
}

/*策略管理弹窗样式 */
.StrategyDiv {
  padding: 15px 20px;

  .allStrategy {
    border: 1px solid #dcdfe6;
    width: 100%;
    border: 1px solid #dcdfe6;
    border-bottom: none;

    .oneStrategy {
      padding-left: 20px;
      border-bottom: 1px solid #dcdfe6;

      .StrategyClass {
        height: 40px;
        line-height: 40px;

        // margin-bottom: 8px;
        span {
          padding-right: 8px;
          font-size: 16px;
          color: #303133;
          font-weight: 700;
        }

        ::v-deep .el-switch {
          position: relative;
          top: -4px;
        }
      }

      .reduceDiv {
        .firstRadio {
          margin-right: 40px;
        }

        .twoRadio {
          margin-right: 12px;
        }
      }

      .timeChooseDiv {
        font-size: 15px;
        height: 32px;
        line-height: 32px;
        color: #303133;
        margin-bottom: 20px;
      }
    }

    .clearBorderRight {
      border-right: none;
    }
  }
}

::v-deep .radioDiv {
  margin-bottom: 12px;
  color: #303133;

  .el-radio__label {
    color: #303133;
  }

  .el-radio {
    margin-right: 0px;
  }

  .el-input-number {
    width: 145px;
    line-height: 31px;

    .el-input-number__decrease {
      line-height: 15px;
    }

    .el-input-number__increase {
      line-height: 15px;
    }
  }
}

/***进线策略样式结束****/
.riskTipContainer{
  padding: 20px;
  .riskTipCon{
    .iconzhuyi{
      font-size:18px;
      color:#ff9a50;
    }
    .tipText{
      font-size:15px;
      color:#ff9a50;
    }
    .tipTextStatus{
      padding-left:20px;
    }
  }
  .anotherTip{
    padding-left:20px;
    margin-top:15px;
    font-size:15px;
    color:#303133;
  }
}
.cancelBtn{
  background:#fff!important;
  border: 1px solid #DCDFE6;
  border-color: #DCDFE6!important;
  color: #606266;
}
.cancelBtn:hover{
  color: #0a70b0;
  border-color: #b6d4e7!important;
  background-color: #e7f1f7!important;;
}
.storageDocumentTip{
  position: relative;
  top: -7px;
}
</style>
