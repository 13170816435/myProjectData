<template>
  <el-dialog
    title="文件下载"
    :visible.sync="showPropress"
    width="400px"
    destroy-on-close
    @close="closeHandle"
  >
    <div class="propress-box">
      <div v-if="fileName">{{ fileName }}</div>
      <el-progress :percentage="percentage"></el-progress>
    </div>
  </el-dialog>
</template>
<script>
export default {
  props: {
    showPropress: {
      type: Boolean,
      default: false,
    },
    fileName: String,
    percentage: Number,
  },
  data() {
    return {};
  },
  methods: {
    closeHandle() {
      this.$emit("close");
    },
  },
};
</script>
<style lang="less" scoped>
.propress-box {
  padding: 20px;
}
</style>
