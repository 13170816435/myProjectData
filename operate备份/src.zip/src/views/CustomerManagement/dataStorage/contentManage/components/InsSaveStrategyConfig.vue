<style lang="less" scoped>
.ml50 {
  margin-left: 50px;
}

.mr108 {
  margin-right: 108px;
}

.w260 {
  width: 260px;
}

.strategy_way {}

.strategy_cls{
  padding-top:20px;
  ::v-deep .el-form{
    max-height: 570px;
    overflow: auto;
  }
  ::v-deep .el-dialog__footer{
    height: auto;
    line-height: initial;
  }
}
.flex{
  display: flex;
  align-items: center;
}
.bb_dashed {
  border-bottom: 1px dashed #dcdfe6;
}
::v-deep .dealSomeFileBox{
 .el-form-item{
    display: flex;
    align-items: center;
    margin-bottom: 0;
  }
}
::v-deep .lastFormItem{
  .el-form-item{
    margin-bottom: 0!important;
  }  
}
.mr5{margin-right: 5px;}
.ml60{ margin-left:60px;}
.clr_orange{
  font-size: 16px;
  color: #ff9900;  
}
.dialog-footer {
  padding-right: 0px;
  display: flex;
  justify-content: flex-end;
  align-items: center;
}

.systemStrategyFooter{
  height: 70px;
  border-top: none;
  line-height: initial;
  justify-content: space-between;
  ::v-deep .saveTip{
    font-size:14px;
    margin-left:50px;
    text-align: left;
    .el-checkbox__label{
      color:#da4a4a;
    }
  }
}

// .strategy_cls {
//   /deep/ .el-dialog__body {
//     padding: 17px 30px 41px 30px !important;
//   }

//   /deep/ .el-form-item__label,
//   .el-form-item__content {
//     line-height: 35px;
//   }

//   /deep/.el-form-item__label {
//     padding-right: 0;
//   }

//   .el-radio {
//     margin-right: 0;
//   }

//   /deep/.el-dialog__header {
//     // height: 50px;
//     line-height: 40px;
//   }
// }

.warningDiv {
  color: rgba(239, 137, 0, 1);
}

/deep/ .white-head .el-dialog__header {
  background-color: white;
  color: #2b354a;
}
</style>
<style lang="less">
.el-message-box {
  width: 500px;

  .el-message-box__title {
    justify-content: flex-start;

    span {
      font-size: 16px !important;
      font-weight: bold;

    }
  }

  .el-message-box__message {
    text-align: left !important;

    strong {
      font-size: 18px;
    }

    span {
      font-size: 15px;

    }

  }

  .el-message-box__btns {
    text-align: right !important;
  }



}
</style>
<template>
  <div>
    <!-- 机构设置策略只支持按照天数 -->
    <div class="strategy_cls">
      <el-dialog title="存储策略设置" :visible.sync="SetSaveStrategyShow" :before-close="SetSaveStrategyClose" width="980px"
        top="3%" left>
        <div class="pb20">

          <div class="of ">
            <el-form class="of" label-position="right" :model="saveStrategyData" :rules="saveStrategyRules"
              ref="saveStrategyDataForm" style="padding-left:20px; overflow-y: auto;">
              <div class="pb10 w100 bb_dashed">
                <div class="f18 mb20 mt20 clr_333 ">
                  <span class="mr20 ">近线策略</span>
                  <el-switch v-model="saveStrategyData.nearline_enable" :active-value="1" :inactive-value="0"
                    @change="nearSwitchChange">
                  </el-switch>



                  <!-- 20230306评审(赵元昊) 存在对象存储设备时，离线策略处直接展示提示文案 -->
                  <!-- <span v-if="onlineObjectStorage" class="warningDiv f16 ml10"> <i class="iconfont">&#xe64c;</i>
                    在线设备中有已启用的对象存储设备，只可按指定天数删除。</span> -->
                  <el-button v-popover:firstPop type="text" v-if="onlineObjectStorage" class="warningDiv f16 ml10">
                    <i class="iconfont">&#xe64c;</i>
                  </el-button>
                  <el-popover v-if="onlineObjectStorage" ref="firstPop" placement="right" width="300" trigger="hover">
                    <div class="mr10 ml10 mt10 mb10">
                      <span> 在线设备中有已启用的对象存储设备，只可按指定天数近线。</span>
                    </div>
                  </el-popover>
                </div>

                <div class="w100 mt10 clear_fixed flex ml30">
                  <el-form-item class="inline" prop="nearline_mode">
                    <el-radio class="dib ml70" v-model="saveStrategyData.nearline_mode"
                      :label="0"><span></span></el-radio>
                  </el-form-item>
                  <el-form-item label="近线指定天数前的影像文件：" class="flex">
                    <el-input-number style="width: 100px" size="medium" v-model="saveStrategyData.nearline_of_days"
                      controls-position="right" :min="1"
                      @change="(currentValue, oldValue, label) => daysIptNumChange(currentValue, oldValue, 'nearline_of_days')"></el-input-number>
                    <span class="ml10">天</span>
                  </el-form-item>
                </div>

                <div class="w100 clear_fixed ml30">
                  <el-form-item label="近线策略执行时间：" class="ml70">
                    <el-time-picker v-model="nearlinePerformTimeStart" value-format="yyyy-MM-dd HH:mm:ss"
                      placeholder="开始时间" style="width: 140px">
                    </el-time-picker>
                    <span> - </span>
                    <el-time-picker v-model="nearlinePerformTimeEnd" value-format="yyyy-MM-dd HH:mm:ss"
                      placeholder="结束时间" style="width: 140px">
                    </el-time-picker>
                  </el-form-item>
                </div>
              </div>

          <div class="of w100 bb_dashed">
            <div class="f18 mt10 clr_333 ml30">
              <div class="w100 mt10 clear_fixed">
                <el-form-item label="指定需要近线的在线设备：" class="">
                  <el-select
                    v-model="saveStrategyData.nearline_from_device"
                    size="small"
                    class="w240"
                    clearable
                    collapse-tags
                    filterable
                    :multiple="true"
                  >
                    <el-option
                      v-for="(item, index) in onlineDeviceArr"
                      :key="index"
                      :value="item.id"
                      :label="
                        item.is_main_backup == 1
                          ? `(主备份)${item.device_name}`
                          : item.device_name
                      "
                    >
                    </el-option>
                  </el-select>
                  
                  <span class="ml60">指定近线设备：</span>
                  <el-select
                    v-model="saveStrategyData.nearline_to_device"
                    size="small"
                    class="w240"
                    filterable
                    clearable
                  >
                    <el-option
                      v-for="(item, index) in nearlineDeviceArr"
                      :key="index"
                      :value="item.id"
                      :label="
                        item.is_main_backup == 1
                          ? `(主备份)${item.device_name}`
                          : item.device_name
                      "
                    >
                    </el-option>
                  </el-select>
                </el-form-item>

              </div>
            </div>
          </div>

              <!-- 暂时隐藏离线策略 -->
              <div class="of mt10 w100 bb_dashed">
                <div class="f18 mb20 clr_333">
                  <span class="mr20">离线策略</span>
                  <el-switch v-model="saveStrategyData.offline_enable" :active-value="1" :inactive-value="0"
                    @change="offSwitchChange">
                  </el-switch>
                  <!-- 20230222评审(赵元昊) 存在对象存储设备时，离线策略处直接展示提示文案 -->
                  <!-- <span v-if="hasObjectStorage" class="warningDiv f16 ml10"> <i class="iconfont">&#xe64c;</i>

                    存储设备中有已启用的对象存储设备，只可按指定天数删除。</span> -->
                  <el-button v-popover:secondPop type="text" v-if="hasObjectStorage" class="warningDiv f16 ml10">
                    <i class="iconfont">&#xe64c;</i>
                  </el-button>
                  <el-popover v-if="hasObjectStorage" ref="secondPop" placement="right" width="300" trigger="hover">
                    <div class="mr10 ml10 mt10 mb10">
                      <span> 存储设备中有已启用的对象存储设备，只可按指定天数离线。</span>
                    </div>
                  </el-popover>
                </div>
                <div class="w100 mt10 clear_fixed flex ml30">
                  <el-form-item class="inline" prop="offline_mode">
                    <el-radio class="dib ml70" v-model="saveStrategyData.offline_mode"
                      :label="0"><span></span></el-radio>
                  </el-form-item>
                  <el-form-item label="离线指定天数前的影像文件：" class="flex">
                    <el-input-number style="width: 100px" size="medium" v-model="saveStrategyData.offline_of_days"
                      controls-position="right" :min="1"
                      @change="(currentValue, oldValue, label) => daysIptNumChange(currentValue, oldValue, 'offline_of_days')"></el-input-number>
                    <span class="ml10">天</span>
                  </el-form-item>
                </div>
                <div class="w100 clear_fixed ml30">
                  <el-form-item label="离线策略执行时间：" class="ml70">
                    <el-time-picker v-model="offlinePerformTimeStart" value-format="yyyy-MM-dd HH:mm:ss"
                      placeholder="开始时间" style="width: 140px">
                    </el-time-picker>
                    <span> - </span>
                    <el-time-picker v-model="offlinePerformTimeEnd" value-format="yyyy-MM-dd HH:mm:ss"
                      placeholder="结束时间" style="width: 140px">
                    </el-time-picker>
                  </el-form-item>
                </div>
              </div>
             
              <div class="of w100 bb_dashed">
                <div class="f18 mt10 clr_333 ml30">
                   <div class="w100 mt10 clear_fixed">
                    <el-form-item label="离线指定设备的文件：" class="">
                        <el-select
                        v-model="saveStrategyData.offline_detail.device_ids"
                        size="small"
                        class="w240"
                        clearable
                        collapse-tags
                        :multiple="true"
                        >
                        <el-option
                            v-for="(item, index) in deviceList"
                            :key="index"
                            :value="item.id"
                            :label="
                            item.is_main_backup == 1
                                ? `(主备份)${item.device_name}`
                                : item.device_name
                            "
                        >
                        </el-option>
                        </el-select>
                    </el-form-item>
                   </div>  
                </div>
              </div>

              <div class="of w100">
                <div class="f18 mt10 clr_333">
                   <div class="mt10 clear_fixed flex mb15 dealSomeFileBox ml30">
                    <el-checkbox class="mr5" v-model="dealSomeFileChecked"></el-checkbox>
                    <el-form-item label="处理指定文件：" class="">
                       <el-radio-group v-model="saveStrategyData.offline_detail.filter_mode" :disabled="!dealSomeFileChecked">
                        <el-radio :label="1">保留</el-radio>
                        <el-radio :label="2">离线</el-radio>
                       </el-radio-group>
                       <span class="clr_orange ml60" v-if="saveStrategyData.offline_detail.filter_mode==1">
                         保留指定科室、指定格式、指定类型的文件,离线其他文件。
                        </span>
                        <span class="clr_orange ml60" v-else>
                         只离线指定科室、指定格式、指定类型的文件，保留其他文件
                        </span>
                    </el-form-item>
                   </div>  
                </div>
              </div>

              
              <div class="of w100 lastFormItem ml30">
                <div class="f18 clr_333">
                  <div class="w100 clear_fixed dealSomeFileBox">
                     
                    <el-form-item class="">
                      <el-checkbox class="mr5" v-model="enableDepart" :disabled="!dealSomeFileChecked"></el-checkbox> 
                      <span class="strategyLabel">指定科室：</span>
                      <el-select
                        v-model="saveStrategyData.offline_detail.depart_codes"
                        :disabled="!dealSomeFileChecked"
                        size="small"
                        class="w240"
                        clearable
                        collapse-tags
                        :multiple="true"
                      >
                        <el-option v-for="item in officeTypeArr"
                            :key="item.dic_code"
                            :label="item.dic_name"
                            :value="item.dic_code">
                        </el-option>
                      </el-select>

                      <el-checkbox class="ml30 mr5" v-model="enableCompositeFileTypes" :disabled="!dealSomeFileChecked"></el-checkbox>
                      <span class="strategyLabel ">指定类型：</span>
                      <el-select
                        v-model="saveStrategyData.offline_detail.composite_file_types"
                        :disabled="!dealSomeFileChecked"
                        size="small"
                        class="w240"
                        clearable
                        collapse-tags
                        :multiple="true"
                        >
                        <el-option v-for="item in compositeFileTypesArr"
                          :key="item.value"
                          :label="item.description"
                          :value="item.value">
                        </el-option>
                      </el-select>


                    <el-checkbox class="ml30 mr5" v-model="enableFileType" :disabled="!dealSomeFileChecked"></el-checkbox>
                    <span class="strategyLabel ">指定格式：</span>
                    <el-select
                        v-model="saveStrategyData.offline_detail.file_types"
                        :disabled="!dealSomeFileChecked"
                        size="small"
                        class="w240"
                        clearable
                        collapse-tags
                        :multiple="true"
                        >
                        <el-option v-for="item in fileFormatArr"
                            :key="item.dic_code"
                            :label="item.dic_name"
                            :value="item.dic_code">
                          </el-option>
                        </el-select>
                      </el-form-item>
                   </div>  
                </div>
              </div>

            </el-form>

          </div>
        </div>



        <div slot="footer" class="dialog-footer systemStrategyFooter">

          <div class="saveTip">
            <el-checkbox v-model="saveSystemStrategyChecked">您已确认系统中不存在索引采集生成的记录，否则离线将导致文件丢失!</el-checkbox>
            <el-checkbox v-model="saveSystemStrategyOtherChecked">如果系统中存在索引采集生成的记录，您确认已使用存储共享系统的索引修复工具进行修复，否则离线将导致文件丢失!</el-checkbox>
          </div>


          <el-button @click="SetSaveStrategyClose" size="small" class="">关
            闭</el-button>
          <el-button type="primary" @click="preUpdateSaveStrategy" size="small">保
            存</el-button>
        </div>
      </el-dialog>
    </div>

    <div class="white-head">
      <el-dialog title="提示" :visible.sync="innerVisible" width="40%" :show-close="false" :before-close="handleClose"
        @opened="openedAlertContent">
        <div slot="title" class="dialog-title fff">
          <i class="iconfont clr_warn" style="font-size: 26px;">&#xe680;</i>
          <span class="f16 ml5">
            以下参数小于极限值，可能会影响影像调阅或数据安全，请确认！
          </span>
        </div>
        <div id="alert_content" class="f16 ml15">

        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="innerVisible = false">取 消</el-button>
          <el-button type="primary" @click="updateSaveStrategy">
            确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import moment from 'moment'
import {
  updateStorageStrategiesType,
  getStorageFileType,
  getDicomDeviceList,
  updateStorageStrategies
} from '@/api/memorySharing/dataMemory'
import { getDistinfoByType } from "@/api/commonHttp";
export default {
  data() {
    let modeValidator = (type, tip) => {
      return (rule, value, callback) => {
        if (this.saveStrategyData[type] === 1) {
          if (value === '') {
            callback(new Error(tip))
          } else {
            callback()
          }
        } else {
          callback()
        }
      }
    }

    return {

      //20230222评审
      /**
       * 默认值：
       * 近线：执行时间22:00-06:00  360天 80
       * 离线：执行时间 22:00-06:00   730天 90 90天
       */

      saveStrategyData: {
        //system_id: "1288724283689799680",
        system_id:"",
        domain_id: 0,
        strategy_type: 1,//	策略类型 0 整体配置 1 按照系统配置 2 按照机构配置
        nearline_enable: 0,
        nearline_mode: '',
        nearline_of_days: 360,
        nearline_of_space_ratio: 80,
        nearline_begin_perform_time: '2023-01-01 22:00:00',
        nearline_end_perform_time: '2023-01-02 06:00:00',
        offline_enable: 0,
        offline_mode: '',
        offline_of_days: 730,
        offline_of_space_ratio: 90,
        offline_save_days: 90,
        offline_begin_perform_time: '2023-01-01  22:00:00',
        offline_end_perform_time: '2023-01-02 06:00:00',
        offline_detail: {
          filter_mode: 1,
          device_ids:[],
          file_types: [],
          depart_codes: [],
          composite_file_types: [],
        },
        nearline_from_device: [],
        nearline_to_device: '',
      },
      saveStrategyRules: {
        nearline_mode: [{
          trigger: 'blur',
          validator: modeValidator('nearline_enable', '请选择近线模式')
        }],
        offline_mode: [{
          trigger: 'blur',
          validator: modeValidator('offline_enable', '请选择离线模式')
        }],

      },
      nearlinePerformTimeStart: "2023-01-01 22:00:00", // 近线策略开始时间
      nearlinePerformTimeEnd: '2023-01-02 06:00:00', // 近线策略执行结束时间
      offlinePerformTimeStart: "2023-01-01 22:00:00", // 离线策略执行开始时间
      offlinePerformTimeEnd: '2023-01-02 06:00:00', // 离线策略执行结束时间
      innerVisible: false,
      innerAlertHTML: '',
      dealSomeFileChecked: false,
      enableDepart: false, //是否启用指定科室
      enableCompositeFileTypes: false, // 是否启用指定类型
      enableFileType: false,//是否启用文件格式
      dealSomeFileWayVal: 1,
      officeTypeArr: [],
      compositeFileTypesArr: [],
      fileFormatArr: [],
      // hasObjectStorage: false,//测试用，等下记得删除
      pageInfo: {
        total_count: 0,
        page_index: 1,
        page_size: 10,
      },
      // StrategyData: {},
      saveSystemStrategyChecked:false,
      saveSystemStrategyOtherChecked: false,
      onlineDeviceArr: [],// 在线设备
      nearlineDeviceArr: [],// 近线设备
    }
  },

  watch: {
    StrategyData: {
      handler(data) {
        if (data) {
          this.saveStrategyData.domain_id = data.domain_id
          this.saveStrategyData.strategy_type = data.strategy_type
          this.saveStrategyData.nearline_enable = data.nearline_enable
          this.saveStrategyData.nearline_mode = data.nearline_mode
          this.saveStrategyData.nearline_of_days = data.nearline_of_days ?? 360
          this.saveStrategyData.nearline_of_space_ratio = data.nearline_of_space_ratio ?? 80
          this.saveStrategyData.nearline_begin_perform_time = data.nearline_begin_perform_time || "2023-01-01 22:00:00"
          this.nearlinePerformTimeStart = data.nearline_begin_perform_time || "2023-01-01 22:00:00"
          this.saveStrategyData.nearline_end_perform_time = data.nearline_end_perform_time || '2023-01-02 06:00:00'
          this.nearlinePerformTimeEnd = data.nearline_end_perform_time || '2023-01-02 06:00:00'
          
          this.saveStrategyData.nearline_from_device = data.nearline_from_device || []
          if (data.nearline_to_device && data.nearline_to_device.length != 0) {
            const nearline_to_device = data.nearline_to_device
            this.saveStrategyData.nearline_to_device = nearline_to_device[0] || ''
          } else {
            this.saveStrategyData.nearline_to_device = ''
          }

          this.saveStrategyData.offline_enable = data.offline_enable
          this.saveStrategyData.offline_mode = data.offline_mode
          this.saveStrategyData.offline_of_days = data.offline_of_days ?? 730
          this.saveStrategyData.offline_of_space_ratio = data.offline_of_space_ratio ?? 90
          this.saveStrategyData.offline_save_days = data.offline_save_days ?? 90
          this.saveStrategyData.offline_begin_perform_time = data.offline_begin_perform_time || "2023-01-01 22:00:00"
          this.offlinePerformTimeStart = data.offline_begin_perform_time || "2023-01-01 22:00:00"
          this.saveStrategyData.offline_end_perform_time = data.offline_end_perform_time || '2023-01-02 06:00:00'
          this.offlinePerformTimeEnd = data.offline_end_perform_time || '2023-01-02 06:00:00'
          this.saveStrategyData.offline_detail = data.offline_detail || {
            filter_mode: 1,
            device_ids: [],
            file_types: [],
            composite_file_types: [],
            depart_codes: [],
          };
          if (
            this.saveStrategyData.offline_detail &&
            this.saveStrategyData.offline_detail.depart_codes.length != 0
          ) {
            // 说明有选择 指定科室
            this.dealSomeFileChecked = true;
            this.enableDepart = true;
          }

          if (
            this.saveStrategyData.offline_detail &&
            this.saveStrategyData.offline_detail.composite_file_types.length != 0
          ) {
            // 说明有选择 指定文件类型(存储文档)
            this.dealSomeFileChecked = true;
            this.enableCompositeFileTypes = true;
          }

          
          if (
            this.saveStrategyData.offline_detail &&
            this.saveStrategyData.offline_detail.file_types.length != 0
          ) {
            // 说明有选择 指定文件类型
            this.dealSomeFileChecked = true;
            this.enableFileType = true;
          }

        } else {// 没有值说明 机构列表里面选择了多个机构来 配置策略
          this.saveStrategyData.domain_id = 0
          this.saveStrategyData.strategy_type = 2
          this.saveStrategyData.nearline_enable = 0
          this.saveStrategyData.nearline_mode = ''
          this.saveStrategyData.nearline_of_days = 360
          this.saveStrategyData.nearline_of_space_ratio = 80
          this.saveStrategyData.nearline_begin_perform_time = '2023-01-01 22:00:00'
          this.saveStrategyData.nearline_end_perform_time = '2023-01-02 06:00:00'
          this.saveStrategyData.offline_enable = 0
          this.saveStrategyData.offline_mode = ''
          this.saveStrategyData.offline_of_days = 730
          this.saveStrategyData.offline_of_space_ratio = 90
          this.saveStrategyData.offline_save_days = 90
          this.saveStrategyData.offline_begin_perform_time = '2023-01-01  22:00:00'
          this.saveStrategyData.offline_end_perform_time = '2023-01-02 06:00:00'
          this.saveStrategyData.offline_detail = {
            filter_mode: 1,
            device_ids: [],
            file_types: [],
            composite_file_types: [],
            depart_codes: [],
          };
          this.dealSomeFileChecked = false;
          this.enableDepart = false;
          this.enableCompositeFileTypes = false;
          this.enableFileType = false;
        }

      },
      immediate:true,
    },

    nearlinePerformTimeStart(newVal) {
      if (newVal) {
        this.saveStrategyData.nearline_begin_perform_time = newVal;
      } else {
        this.saveStrategyData.nearline_begin_perform_time = "2023-01-01 22:00:00"
      }
    },
    nearlinePerformTimeEnd(newVal) {
      if (newVal) {
        this.saveStrategyData.nearline_end_perform_time = newVal;
      } else {
        this.saveStrategyData.nearline_end_perform_time = '2023-01-02 06:00:00'
      }
    },

    offlinePerformTimeStart(newVal) {
      if (newVal) {

        this.saveStrategyData.offline_begin_perform_time = newVal;
      } else {
        this.saveStrategyData.offline_begin_perform_time = "2023-01-01 22:00:00"
      }
    },
    offlinePerformTimeEnd(newVal) {
      if (newVal) {
        this.saveStrategyData.offline_end_perform_time = newVal;
      } else {
        this.saveStrategyData.offline_end_perform_time = '2023-01-02 06:00:00'
      }
    },


  },
  props: ['configIds', 'batchConf', 'deviceList', 'SetSaveStrategyShow', 'hasObjectStorage', 'onlineObjectStorage', 'StrategyData'],//
  // mounted(){
  //   this.validTime()
  // },
  methods: {
    // 获取按系统配置里面的 设备列表、科室列表、文件格式列表
    async initData () {
      if (this.$route?.query?.system_id) {
        this.saveStrategyData.system_id = this.$route.query.system_id;
      }
      // 获取在线 近线设备
      await this.getOnlineOrNearlineDevice()
      await this.getDistinfoFn()
      await this.beganGetStorageFileType()
    },
    // 获取在线 近线 设备
    async getOnlineOrNearlineDevice () {
      const self = this
      self.onlineDeviceArr = []
      self.nearlineDeviceArr = []
      const res = await getDicomDeviceList({system_id:self.saveStrategyData.system_id});
      if (res.code === 0) {
        if (res.data.length !== 0) {
          const result = res.data
          result.forEach((item) => {
            if (item.is_online) {//在线设备
              self.onlineDeviceArr.push(item)
            }
            if (!item.is_online) {//近线设备
              self.nearlineDeviceArr.push(item)
            }
          })
        } else {
          this.$message({ message: "请先去授权", type: "error" });
        }
      } else {
        this.requestOver = true;
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // 获取字典列表
    async getDistinfoFn() {
      const self = this
      var _parmas = "ExamDept,FileTypes";
      var _url = `/dict/${_parmas}`;
      const res = await getDistinfoByType(_url);
      if (res.code !== 0 || res.data.length === 0) {
        return;
      }
      self.officeTypeArr = [];
      self.fileFormatArr = []
      res.data.forEach((item) => {
        if (item.lookup_key === "ExamDept") {//指定科室
          self.officeTypeArr.push(item);
        } else if (item.lookup_key === "FileTypes") {// 文件格式
          self.fileFormatArr.push(item)
        }
      });
    },
    // 获取存储文档
    async beganGetStorageFileType() {
      const res = await getStorageFileType();
      if (res.code == 0) {
        this.compositeFileTypesArr = res.data
      } else {
        this.$message.error(res.msg)
      }
    },
    nearSwitchChange() {
      if (this.saveStrategyData.nearline_enable === 1 && this.saveStrategyData.nearline_mode !== 0 && this.saveStrategyData.nearline_mode !== 1)
        this.saveStrategyData.nearline_mode = 0

    },
    offSwitchChange() {
      if (this.saveStrategyData.offline_enable === 1 && this.saveStrategyData.offline_mode !== 0 && this.saveStrategyData.offline_mode !== 1)
        this.saveStrategyData.offline_mode = 0
    },

    SetSaveStrategyClose(shouldRefresh) {
      this.$emit('SetSaveStrategyClose', shouldRefresh,2)
    },

    openedAlertContent() {

      let divDocument = document.getElementById('alert_content')
      divDocument.innerHTML = this.innerAlertHTML
    },
    formattingTime(str) {
      let date = new Date(str)
      return '2023-01-01 ' + moment(date).format("HH:mm:ss")
    },
    validTimes(begin, end) {
      let startStr = this.formattingTime(begin)
      let endStr = this.formattingTime(end)
      let timeL = new Date(endStr).getTime() - new Date(startStr).getTime()

      if (timeL >= 0 && timeL < 5 * 60 * 1000) return true
      return false
    },
    ValidationStrategyRules() {

      // if (this.onlineObjectStorage && this.saveStrategyData.nearline_enable === 1 && this.saveStrategyData.nearline_mode == 1) {
      //   this.$message.error('在线设备中有已启用的对象存储设备，近线策略只可按指定天数近线！')
      //   return
      // }
      // if (this.hasObjectStorage && this.saveStrategyData.offline_enable === 1 && this.saveStrategyData.offline_mode == 1) {
      //   this.$message.error('存储设备中有已启用的对象存储设备，离线策略只可按指定天数离线！')
      //   return
      // }
      //存储策略极限值及冲突规则提示

      // if (this.saveStrategyData.nearline_enable && this.saveStrategyData.offline_enable && this.saveStrategyData.nearline_mode === 0 && this.saveStrategyData.offline_mode === 0 && this.saveStrategyData.nearline_of_days >= this.saveStrategyData.offline_of_days) {
      //   this.$message.error(`近线策略指定天数[${this.saveStrategyData.nearline_of_days}]天，需小于离线策略指定天数[${this.saveStrategyData.offline_of_days}]天！`)
      //   return
      // }
      // if (this.saveStrategyData.nearline_enable && this.saveStrategyData.offline_enable && this.saveStrategyData.nearline_mode === 1 && this.saveStrategyData.offline_mode === 1 && this.saveStrategyData.nearline_of_space_ratio >= this.saveStrategyData.offline_of_space_ratio) {
      //   this.$message.error(`近线策略指定磁盘容量[${this.saveStrategyData.nearline_of_space_ratio}%]，需小于离线策略指定磁盘容量[${this.saveStrategyData.offline_of_space_ratio}%]！`)
      //   return
      // }


      // const timer = new Date(this.formattingTime(this.nearlinePerformTimeEnd)).getTime() - new Date(this.formattingTime(this.nearlinePerformTimeStart)).getTime()
      const timer = this.validTimes(this.nearlinePerformTimeStart, this.nearlinePerformTimeEnd)
      if (this.saveStrategyData.nearline_enable && timer) {
        this.$message.warning('近线策略执行时间间隔应大于5分钟')
        return
      }
      // const timer2 = this.validTimes(this.offlinePerformTimeStart, this.offlinePerformTimeEnd)

      // // const timer2 = new Date(this.formattingTime(this.offlinePerformTimeEnd)).getTime() - new Date(this.formattingTime(this.offlinePerformTimeStart)).getTime()
      // if (this.saveStrategyData.offline_enable && timer2) {
      //   this.$message.warning('离线策略执行时间间隔应大于5分钟')
      //   return
      // }
      let alertContent = '<strong>参数小于极限值:</strong><br/>'
      let count = 1
      // 192.168.1.165 原型    近线极限值 90天 容量80%

      if (this.saveStrategyData.nearline_enable && this.saveStrategyData.nearline_mode === 0 && this.saveStrategyData.nearline_of_days < 90) {
        alertContent = alertContent + `<span>${count}、近线指定天数为${this.saveStrategyData.nearline_of_days}天，小于极限值90天</span><br/>`
        count++
      }
      // if (this.saveStrategyData.nearline_enable && this.saveStrategyData.nearline_mode === 1 && this.saveStrategyData.nearline_of_space_ratio < 80) {

      //   alertContent = alertContent + `<span>${count}、近线指定磁盘容量为${this.saveStrategyData.nearline_of_space_ratio}%，小于极限值80%</span><br/>`
      //   count++
      // }
      // 192.168.1.165 原型    离线极限值 120天 容量80% 最少保留90天

      // if (this.saveStrategyData.offline_enable && this.saveStrategyData.offline_mode === 0 && this.saveStrategyData.offline_of_days < 120) {

      //   alertContent = alertContent + `<span>${count}、离线指定天数为${this.saveStrategyData.offline_of_days}天，小于极限值120天</span><br/>`
      //   count++
      // }
      // if (this.saveStrategyData.offline_enable && this.saveStrategyData.offline_mode === 1 && this.saveStrategyData.offline_of_space_ratio < 90) {
      //   alertContent = alertContent + `<span>${count}、离线指定磁盘容量为${this.saveStrategyData.offline_of_space_ratio}%，小于极限值90%</span><br/>`
      //   count++
      // }

      // if (this.saveStrategyData.offline_enable && this.saveStrategyData.offline_mode === 1 && this.saveStrategyData.offline_save_days < 90) {
      //   alertContent = alertContent + `<span>${count}、离线最少保留天数为${this.saveStrategyData.offline_save_days}天，小于极限值90天</span><br/>`
      //   count++
      // }

      // let configCount = 0;
      // let configStr = '<strong>策略配置不一致</strong><br/>'
      // if (this.saveStrategyData.offline_enable && this.saveStrategyData.nearline_enable && this.saveStrategyData.offline_mode !== this.saveStrategyData.nearline_mode) {
      //   if (this.saveStrategyData.offline_mode === 0) {
      //     //删除天数、近线容量
      //     configStr = configStr + `近线策略为指定容量，离线策略为指定天数，两者不一致，请确认配置无误！`
      //   } else {
      //     configStr = configStr + `近线策略为指定天数，离线策略为指定容量，两者不一致，请确认配置无误！`

      //   }
      //   if (count > 1) {
      //     alertContent = configStr + '<br/><br/>' + alertContent;
      //   } else {
      //     alertContent = configStr;
      //   }
      //   configCount++;
      // }

      if (this.dealSomeFileChecked) {
        // 勾选了处理指定文件
        if (
          this.enableDepart &&
          this.saveStrategyData.offline_detail.depart_codes &&
          this.saveStrategyData.offline_detail.depart_codes.length == 0
        ) {
          this.$message.error("请选择指定科室");
          return;
        }
      
      if (
          this.enableCompositeFileTypes &&
          this.saveStrategyData.offline_detail.composite_file_types &&
          this.saveStrategyData.offline_detail.composite_file_types.length == 0
        ) {
          this.$message.error("请选择指定类型");
          return;
        }

        if (
          this.enableFileType &&
          this.saveStrategyData.offline_detail.file_types &&
          this.saveStrategyData.offline_detail.file_types.length == 0
        ) {
          this.$message.error("请选择指定格式");
          return;
        }
      }
      if (!this.saveSystemStrategyChecked || !this.saveSystemStrategyOtherChecked) {
        this.$message.warning("请阅读风险说明，并勾选！");
        return; 
      }

      if (count > 1) {
        // this.innerAlertHTML = alertContent
        // this.innerVisible = true
        this.$confirm(alertContent, '以下设置可能会影响影像调阅或数据安全,请确认!', {
          confirmButtonText: '取消',
          cancelButtonText: '确认',
          type: 'warning',
          center: true,
          dangerouslyUseHTMLString: true,
          distinguishCancelAndClose: true,
        }).then((action) => {

          //取消操作不管
          // this.$message({
          //   type: 'success',
          //   message: '删除成功!'
          // });
        }).catch((action) => {
          if (action === 'cancel') {
            //这里改为确认操作了
            this.updateSaveStrategy();
          } else {
            //取消操作不管
          }
          // this.$message({
          //   type: 'info',
          //   message: '已取消删除'
          // });
        });


      } else {
        this.updateSaveStrategy()
      }

    },
    preUpdateSaveStrategy() {

      this.$refs.saveStrategyDataForm.validate(async (valid) => {

        if (valid) {

          this.ValidationStrategyRules()
        }
      })
    },

    async updateSaveStrategy() {
      if (this.saveStrategyData.offline_enable instanceof Boolean) {
        this.saveStrategyData.offline_enable = this.saveStrategyData.offline_enable ? 1 : 0
      }
      if (this.saveStrategyData.nearline_enable instanceof Boolean) {
        this.saveStrategyData.nearline_enable = this.saveStrategyData.nearline_enable ? 1 : 0
      }

      const newParams = JSON.parse(JSON.stringify(this.saveStrategyData));
      if (!this.dealSomeFileChecked) {
        // 如果没有勾选处理指定文件  什么指定科室 指定文件格式配置无效
        newParams.offline_detail.filter_mode = 1;
        newParams.offline_detail.depart_codes = [];
        newParams.offline_detail.composite_file_types = [];
        newParams.offline_detail.file_types = [];
      }
      // newParams.strategy_type = this.curStrategyType
      if (!this.enableDepart) {
        // 没有开启指定科室
        newParams.offline_detail.depart_codes = [];
      }
      
      if (!this.enableCompositeFileTypes) {
        // 没有开启指定类型(存储文档)
        newParams.offline_detail.composite_file_types = [];
      }

      if (!this.enableFileType) {
        // 没有开启指定文件
        newParams.offline_detail.file_types = [];
      }
      if (this.saveStrategyData.nearline_to_device) {
        newParams.nearline_to_device = []
        newParams.nearline_to_device.push(this.saveStrategyData.nearline_to_device)
      }
      
      let params = this.configIds.map(e => ({ ...newParams, id: e }))

      
      const res = await updateStorageStrategies(params)
      const { code, msg } = res
      if (code === 0) {
        this.innerVisible = false
        this.SetSaveStrategyClose(true)
        this.$message({
          type: 'success',
          message: msg
        })
        //更新存储策略成功！
      } else {
        this.innerVisible = false
        //更新存储策略失败，请重试！
        this.$message.error(msg)
      }


    },
    daysIptNumChange(currentValue, oldValue, label) {
      if (currentValue === undefined) {
        this.$nextTick(() => {
          this.saveStrategyData[label] = 1
        })
      } else if (!Number.isInteger(currentValue)) {
        this.$nextTick(() => {
          this.saveStrategyData[label] = parseInt(currentValue)
        })
      }
    },
    ratioIptNumChange(currentValue, oldValue, label) {
      if (currentValue === undefined) {
        this.$nextTick(() => {
          if (label === 'offline_save_days') {
            this.saveStrategyData[label] = 90
          } else {
            this.saveStrategyData[label] = 0
          }
        })
      }
    },
    handleClose() {

    }
  }
}
</script>
