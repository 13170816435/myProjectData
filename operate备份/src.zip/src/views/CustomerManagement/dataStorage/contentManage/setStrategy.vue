<template>
  <div class="userlist">
    <div class="title-bar flex_row cardHeader">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei "></i>数据管理
          <i class="iconfont iconzhankaishouqi "></i>存储管理
          <i class="iconfont iconzhankaishouqi"></i> 策略设置
        </span>
      </div>

      <div class="tr btnBox">
        <a href="#" @click="backToContent" class="back"
          ><i class="iconfont f14 iconfanhui"></i> 返回</a
        >
      </div>
    </div>

    <!-- v-if="system_id" -->
    <!-- <div  class="pt10 pl10">
      <el-button-group>
        <el-button
          @click="btnIndex = 0"
          :type="btnIndex == 0 ? 'primary' : ''"
          size="small"
          >存储策略</el-button
        >
        <el-button
          @click="btnIndex = 1"
          :type="btnIndex == 1 ? 'primary' : ''"
          size="small"
          >标记策略</el-button
        >
      </el-button-group>
    </div> -->

    <div v-show="btnIndex == 0 && currentStrategyData && (!currentStrategyData.strategy_type || currentStrategyData.strategy_type === 2)" class="DeviceCon" :class="containerClass">
      <div class="topCon of">
        <el-form class="fl row" :model="formData" label-width="auto">
          <el-form-item label="机构名称:">
            <el-select
              v-model="formData.org_code"
              placeholder="全部"
              filterable>
              <el-option value="">全部</el-option>
              <el-option
                v-for="item in institutionList"
                :key="item.code"
                :label="item.name"
                :value="item.code">
              </el-option>
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-button
              type="primary"
              size="small"
              style="margin-left: 10px"
              @click="search"
              >查询
            </el-button>
            <el-button size="small" @click="resetForm" plain>重置</el-button>
          </el-form-item>
        </el-form>
        <el-button
          class="fr mr15"
          size="small"
          @click="StrategyConfiguration"
          plain
          >策略设置</el-button
        >
        <el-button
          class="fr mr15"
          size="small"
          @click="StrategyWay"
          plain
          >策略方式</el-button
        >
      </div>

      <div class="deviceList clear">
        <div
          class="tableDiv"
          v-bind:class="{ noTableData: tableData.length === 0 }">
          <el-table
            border
            stripe
            :data="tableData"
            height="100%"
            style="width: 100%;height:100%;"
            :default-sort="{ prop: 'date', order: 'descending' }"
            ref="strategyTable"
            @selection-change="tableSelectionChanged">
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column
              type="index"
              label="序号"
              fixed="left"
              width="50">
            
              <template slot-scope="scope">
              <span>{{
                (pageInfo.page_index - 1) * pageInfo.page_size + scope.$index + 1
              }}</span>
            </template>
            </el-table-column>
            <el-table-column label="操作" width="80">
              <template slot-scope="scope">
                <span class="clr_0a pointer" @click="editStrategy(scope.row)"
                  >编辑</span
                >
              </template>
            </el-table-column>
            <el-table-column
              prop="org_name"
              label="机构名称"
              :show-overflow-tooltip="true">
            </el-table-column>

            <el-table-column prop="nearline_enable" label="近线策略" width="80">
              <template slot-scope="{ row }">
                <el-switch
                  v-model="row.nearline_enable"
                  active-color="#409EFF"
                  inactive-color="#DCDFE6"
                  :active-value="1"
                  :inactive-value="0"
                  @change="switchChange(row)">
                </el-switch>
              </template>
            </el-table-column>

            <el-table-column
              v-for="item in propData1"
              :key="item.index"
              :prop="item.prop"
              :label="item.label"
              :width="item.width"
              :formatter="item.formatter"
              :show-overflow-tooltip="true">
            </el-table-column>

            <el-table-column prop="offline_enable" label="离线策略" width="80">
            <template slot-scope="{row}">
                <el-switch v-model="row.offline_enable" active-color="#409EFF" inactive-color="#DCDFE6" :inactive-value="0"
                    :active-value="1" @change="switchChange(row)">
                </el-switch>
            </template> </el-table-column>

            <el-table-column
              v-for="(item, index) in propData2"
              :key="index"
              :prop="item.prop"
              :label="item.label"
              :width="item.width"
              :formatter="item.formatter"
              :show-overflow-tooltip="true">
            </el-table-column>
          </el-table>
        </div>
      </div>
      <div class="pageDiv">
        <pagination-tool
          :total="pageInfo.total_count"
          :page.sync="pageInfo.page_index"
          :limit.sync="pageInfo.page_size"
          @pagination="searchList" />
      </div>
      <InsSaveStrategyConfig
        v-if="SetSaveStrategyShow"
        :configIds="configIds"
        :batchConf="batchConf"
        :deviceList="deviceList"
        ref="InsSaveStrategyConfig"
        :SetSaveStrategyShow="SetSaveStrategyShow"
        :hasObjectStorage="hasObjectStorage"
        :onlineObjectStorage="onlineObjectStorage"
        :StrategyData="currentListStrategyData"
        @SetSaveStrategyClose="SetSaveStrategyClose" />

    </div>

    <!--策略方式 按系统分配--->
    <div class="DeviceCon systemStrategyContainer" v-show="btnIndex == 0 && currentStrategyData && currentStrategyData.strategy_type === 1">
      <div class="topCon of">
         <el-button
          class="fr mr15"
          size="small"
          @click="StrategyWay"
          plain
          >策略方式</el-button
        >
      </div>
      <div class="systemStorageStrategyCon">
         <div class="strategyItem bb">
            <div class="strategyTitCon"><span class="strategyTit">近线策略</span>
             <span class="strategyStatus" v-if="currentStrategyData.nearline_enable">已启用</span>
             <span class="strategyStatus strategyErrorStatus" v-else>未启用</span>
            </div>
            <div class="strategyBasicInfor">
              <div class="strategyBasicItem"><span>近线指定天数前的文件：</span><span class="days">{{currentStrategyData.nearline_of_days}}</span>天</div>
              <div class="strategyBasicItem">
                <span>执行时间：</span>
                <i class="timeIcon el-icon-time"></i>
                <span class="timeVal">{{currentStrategyData.nearline_begin_perform_time}}</span>
                <span>~</span>
                <span class="timeVal">{{currentStrategyData.nearline_end_perform_time}}</span>
              </div>

              <div class="strategyBasicItem" v-if="currentStrategyData.nearline_from_device && currentStrategyData.nearline_from_device.length != 0">
                <span>指定需要近线的在线设备: </span>
                <span class="strategyBasicItemVal" v-for="(device,index) in currentStrategyData.nearline_from_device" :key="index">
                  <span v-if="index != 0">、</span> {{device | showDeviceName(onlineDeviceArr)}}
                </span>
              </div>
              <div class="strategyBasicItem" v-if="currentStrategyData.nearline_to_device && currentStrategyData.nearline_to_device.length != 0">
                <span>指定近线设备: </span>
                <span class="strategyBasicItemVal" v-for="(device,index) in currentStrategyData.nearline_to_device" :key="index">
                  <span v-if="index != 0">、</span> {{device | showDeviceName(nearlineDeviceArr)}}
                </span>
              </div>


            </div>
         </div>

         <div class="strategyItem mt20">
            <div class="strategyTitCon"><span class="strategyTit">离线策略</span>
             <span class="strategyStatus" v-if="currentStrategyData.offline_enable">已启用</span>
             <span class="strategyStatus strategyErrorStatus" v-else>未启用</span>
            </div>
            <!---按指定时间配置---->
            <div class="strategyBasicInfor" v-if="currentStrategyData.offline_mode === 0">
              <div class="strategyBasicItem"><span>删除指定天数前的文件：</span><span class="days">{{currentStrategyData.offline_of_days}}</span>天</div>
              <div class="strategyBasicItem">
                <span>执行时间：</span>
                <i class="timeIcon el-icon-time"></i>
                <span class="timeVal">{{currentStrategyData.offline_begin_perform_time}}</span>
                <span>~</span>
                <span class="timeVal">{{currentStrategyData.offline_end_perform_time}}</span>
              </div>
            </div>
          <!---按容量配置---->
           <div class="strategyBasicInfor" v-if="currentStrategyData.offline_mode === 1">
              <div class="strategyBasicItem">
                <span>离线文件到系统配额容量的: </span><span class="days">{{currentStrategyData.offline_of_space_ratio}}</span>%
                <span class="ml40">且最少保留 </span><span class="days">{{currentStrategyData.offline_save_days}}</span>天
              </div>
              <div class="strategyBasicItem">
                <span>离线指定设备中的文件: </span>
                <span class="strategyBasicItemVal" v-for="(device,index) in currentStrategyData.offline_detail.device_ids" :key="index">
                  <span v-if="index != 0">、</span> {{device | showDeviceName(deviceList)}}
                </span>
              </div>

              

              <div class="strategyBasicItem" v-if="currentStrategyData.offline_detail.depart_codes.length !== 0">
                <span v-if="currentStrategyData.offline_detail.filter_mode==1">保留指定科室的文件: </span>
                <span v-else>离线指定科室的文件: </span>
                <span class="strategyBasicItemVal" v-for="(departCode,index) in currentStrategyData.offline_detail.depart_codes" :key="index">
                  <span v-if="index != 0">、</span> {{departCode | showDepartName(officeTypeArr)}}
                </span>
              </div>

              
              <div class="strategyBasicItem" v-if="currentStrategyData.offline_detail.composite_file_types.length !== 0">
                <span v-if="currentStrategyData.offline_detail.filter_mode==1">保留指定类型的文件: </span>
                <span v-else>离线指定类型的文件: </span>
                <span class="strategyBasicItemVal" v-for="(compositeFileType,index) in currentStrategyData.offline_detail.composite_file_types" :key="index">
                  <span v-if="index != 0">、</span> {{compositeFileType | showCompositeFileTypeName(compositeFileTypesArr)}}
                </span>
              </div>

              <div class="strategyBasicItem" v-if="currentStrategyData.offline_detail.file_types.length !== 0 ">
                <span v-if="currentStrategyData.offline_detail.filter_mode==1">保留指定格式的文件: </span>
                <span v-else>离线指定格式的文件: </span>
                <span class="strategyBasicItemVal" v-for="(fileType,index) in currentStrategyData.offline_detail.file_types" :key="index">
                  <span v-if="index != 0">、</span> {{fileType}}
                </span>文件
              </div>

              <div class="strategyBasicItem">
                <span>执行时间：</span>
                <i class="timeIcon el-icon-time"></i>
                <span class="timeVal">{{currentStrategyData.offline_begin_perform_time}}</span>
                <span>~</span>
                <span class="timeVal">{{currentStrategyData.offline_end_perform_time}}</span>
              </div>
            </div>

         </div>
      </div>
    </div>

    <!-- v-if="system_id" -->
    <markStrategy v-show="btnIndex == 1" ></markStrategy>

   <!--选择 按系统配置 或按机构的  策略方式--->
   <!-- <el-dialog :append-to-body="true" class="stateDesAlert"  v-bind:title="'策略方式'"  :visible.sync="showSystemStrategyWayAlert" width="1020px" height="500px" :close-on-click-modal="false" v-dialogDrag>
      <systemStrategy ref="systemStrategy" @cancelSetSystemStrategy="cancelSetSystemStrategy"></systemStrategy>
    </el-dialog> -->
    <systemStrategy ref="systemStrategy" :deviceList="deviceList" v-if="showSystemStrategyWayAlert" @cancelSetSystemStrategy="cancelSetSystemStrategy" @SetSaveStrategyClose="SetSaveStrategyClose"></systemStrategy>
  </div>

</template>

<script>
  import moment from 'moment';

  import { mapGetters } from 'vuex';
  import CommonTable from '../components/CommonTable';
  import InsSaveStrategyConfig from './components/InsSaveStrategyConfig.vue';
  import PaginationTool from '@/components/common/PaginationTool'; // 分页
  import markStrategy from '../markStrategy';
  import systemStrategy from '../components/systemStrategy'
  import {
    getDomainDeviceList,
    getAllInstitutionStrategies,
    // getCurrentDomainStrategies,
    getStorageFileType,
    updateStorageStrategies,
    getDicomDeviceList,
    updateStorageStrategiesType,
  } from '@/api/memorySharing/dataMemory';
  import { getInstitutionListLite, getDistinfoByType } from '@/api/commonHttp';
  export default {
    components: {
      CommonTable,
      InsSaveStrategyConfig,
      PaginationTool,
      markStrategy,
      systemStrategy,
    },
    data() {
      return {
        btnIndex: 0,
        //system_id: '1288724283689799680',
        system_id: '',
        system_type: '',
        batchConf: false,
        pageInfo: {
          total_count: 0,
          page_index: 1,
          page_size: 15,
        },
        deviceList: [],
        officeTypeArr: [],
        tableData: [],
        propData1: [
          {
            prop: 'nearlineDes',
            label: '近线策略详情',
            formatter: (e) => {
              if (e.nearline_mode === 1 && e.nearline_of_space_ratio >= 0)
                return `近线至容量的${e.nearline_of_space_ratio}%`;
              if (e.nearline_mode === 0 && e.nearline_of_days >= 0)
                return `近线${e.nearline_of_days}天前的文件`;
              return '';
            },
            key: 10,
          },
          {
            prop: 'nearlineTime',
            label: '近线执行时间',
            width: 150,
            formatter: (e) => {
              let beginTime = '';
              let endTime = '';

              if (e.nearline_begin_perform_time)
                beginTime = moment(
                  new Date(e.nearline_begin_perform_time)
                ).format('HH:mm:ss');
              if (e.nearline_end_perform_time)
                endTime = moment(new Date(e.nearline_end_perform_time)).format(
                  'HH:mm:ss'
                );
              return beginTime + '~' + endTime;
            },
            key: 11,
          },
        ],
        propData2: [
          {
              prop: 'offlineDes', label: '离线策略详情', formatter: (e) => {
                  if (e.offline_mode === 1 && e.offline_of_space_ratio >= 0) return `删除至容量的${e.offline_of_space_ratio}%，且最少保留${e.offline_save_days}天`
                  if (e.offline_mode === 0 && e.offline_of_days >= 0) return `删除${e.offline_of_days}天前的文件`
              }
          },
          {
              prop: 'offlineTime', label: '离线执行时间', width: 150, formatter: (e) => {
                  let beginTime = ''
                  let endTime = ''
                  if (e.offline_begin_perform_time) beginTime = moment(new Date(e.offline_begin_perform_time)).format("HH:mm:ss")
                  if (e.offline_end_perform_time) endTime = moment(new Date(e.offline_end_perform_time)).format("HH:mm:ss")
                  return beginTime + '~' + endTime
              }
          },
          { prop: 'update_user_name', label: '操作人', width: 120 },
          { prop: 'last_update_date', label: '操作时间', width: 160 },
        ],
        formData: { org_code: '' },
        institutionList: [],
        configIds: [],
        currentListStrategyData: {},// 机构列表里面选中的机构策略
        currentStrategyType: 0,
        currentStrategyData: {}, //整体配置、当前存储策略
        currentStrategyWay: false, //false 单独配置 true 整体配置
        shareSystemShow: false, // 共享系统使用时 多级
        SetSaveStrategyShow: false,
        hasObjectStorage: false,
        onlineObjectStorage: false,
        selectedData: [],
        requestOver: false,
        allSystemStrategyList: [],
        allStrategyList: [],
        currentDomain: {},
        currentDomainIndex: 0,
        showStrategyAlert: false,
        strategy: {
          nearLineStrategy: {},
          deleteStrategy: {},
          compressionStrategy: {},
        },
        showSystemStrategyWayAlert: false,
        compositeFileTypesArr: [],
        onlineDeviceArr: [],
        nearlineDeviceArr:[],
      };
    },
    methods: {
      init() {
        if (this.$route?.query?.system_id)
          this.system_id = this.$route.query.system_id;
        if (this.$route?.query?.system_type)
          this.system_type = this.$route.query.system_type;

        const self = this;
        self.getAllInstitutionStrategies();
        self.getInstitutionListLite();
      },
    // 获取备份设备
     async getDevices() {
      const res = await getDomainDetail({id: this.currentDomain.domain_id})
      if (res.code != 0) {
        this.$message.error(res.data)
        return
      }
      const result =  res.data
      if (result.length != 0) {
        this.deviceList = result.filter((item) => {
          if (item.device_type == 0) {
            return item.local_is_stopped == 0
          } else if ([1, 3].includes(item.device_type)) {
            return item.oos_is_stopped == 0
          } else if (item.device_type == 4) {
            return item.dicom_is_stopped == 0
          } else if (item.device_type == 7) {
            return item.is_enable == true
          }
       })
      }
     },
    // 获取字典列表（获取科室）
    async getDistinfoFn() {
      const self = this
      var _parmas = "ExamDept";
      var _url = `/dict/${_parmas}`;
      const res = await getDistinfoByType(_url);
      if (res.code !== 0 || res.data.length === 0) {
        return;
      }
      self.officeTypeArr = [];
      res.data.forEach((item) => {
        if (item.lookup_key === "ExamDept") {//指定科室
          self.officeTypeArr.push(item);
        }
      });
    },
    // 获取存储文档
    async beganGetStorageFileType() {
      const res = await getStorageFileType();
      if (res.code == 0) {
        this.compositeFileTypesArr = res.data
      } else {
        this.$message.error(res.msg)
      }
    },
    // 获取在线 近线 设备
    async getOnlineOrNearlineDevice () {
      const self = this
      self.onlineDeviceArr = []
      self.nearlineDeviceArr = []
      const res = await getDicomDeviceList({system_id:self.system_id});
      if (res.code === 0) {
        if (res.data.length !== 0) {
          const result = res.data
          result.forEach((item) => {
            if (item.is_online) {//在线设备
              self.onlineDeviceArr.push(item)
            }
            if (!item.is_online) {//近线设备
              self.nearlineDeviceArr.push(item)
            }
          })
        } else {
          this.$message({ message: "请先去授权", type: "error" });
        }
      } else {
        this.requestOver = true;
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
      backToContent() {
        var path = process.env.NODE_ENV === 'development' ? '/' : '/operate/';
        this.$router.push({
          path: `${path}dataStorage/contentManage`,
          query: { system_id: this.system_id, system_type: this.system_type },
        });
      },
      // 获取机构列表
      getInstitutionListLite() {
        getInstitutionListLite({system_id: this.system_id}).then((res) => {
          if (res.code === 0) {
            this.institutionList = res.data;
          } else {
            this.$message.error(res.msg);
          }
        });
      },
      searchList () {
        this.getAllInstitutionStrategies();
      },
      search() {
        this.pageInfo.page_index = 1
        this.pageInfo.page_size = 15
        this.getAllInstitutionStrategies();
      },
      resetForm() {
        this.pageInfo.page_index = 1
        this.pageInfo.page_size = 15
        this.formData.org_code = '';
        this.search();
      },
      //

      tableSelectionChanged(rows) {
        this.selectedData = rows;
      },
      editStrategy(row) {
        const self = this
        self.batchConf = false;
        self.configIds = [row.id];

        //是否需要显示策略方式？
        self.SetSaveStrategyShow = true;
        self.$nextTick(() => {
          self.$refs.InsSaveStrategyConfig.initData()
          self.currentListStrategyData = row;
        })
      },
      switchChange(row) {
        row.nearline_enable = row.nearline_enable ? 1 : 0;
        row.offline_enable = row.offline_enable ? 1 : 0;
        this.updateStorageStrategies(row);
      },
      async updateStorageStrategies(row) {
        const res = await updateStorageStrategies([row]);
        const { code, msg } = res;
        if (code === 0) {
          this.$message({
            type: 'success',
            message: msg || '更新存储策略成功！',
          });
        } else {
          this.$message.error(msg || '更新存储策略失败，请重试！');
        }
      },
      StrategyStyle() {
        const self = this
        //策略方式修改
        self.SetSaveStrategyShow = true;
        self.$nextTick(() => {
          self.$refs.InsSaveStrategyConfig.initData()
        })
      },
      StrategyConfiguration() {
        const self = this
        //批量配置
        if (self.selectedData.length === 0) {
          self.$message.error('请选择需要设置策略的机构');
          return;
        }
        self.batchConf = true;
        self.configIds = self.selectedData.map((e) => e.id);
        self.SetSaveStrategyShow = true;
        self.$nextTick(() => {
          self.$refs.InsSaveStrategyConfig.initData()
          if (self.selectedData.length == 1) {
            self.currentListStrategyData = self.selectedData[0];
          } else {
            self.currentListStrategyData = null;
          }
        })
      },
      // 策略方式的选择
      StrategyWay () {
        const self = this
        self.showSystemStrategyWayAlert = true
        self.$nextTick(() => {
          self.$refs.systemStrategy.curStrategyType = self.currentStrategyData.strategy_type
          if (self.currentStrategyData && self.currentStrategyData.strategy_type === 1) {// 当前是按系统分配
            self.$refs.systemStrategy.initData()
          }
        })
      },
      // 取消配置系统策略
      cancelSetSystemStrategy () {
        this.showSystemStrategyWayAlert = false
      },
      SetSaveStrategyClose(res,strategy_type) {
        //保存？
        this.SetSaveStrategyShow = false;
        this.showSystemStrategyWayAlert =  false
        this.currentListStrategyData = {}
        if (res == true) {
          this.getAllInstitutionStrategies(strategy_type);
        }
      },

      // 获取所有的存储域
      async getAllInstitutionStrategies(strategy_type) {
        const self = this
        const page = {
          page_index: self.pageInfo.page_index,
          page_size: self.pageInfo.page_size,
        };
        if (strategy_type) {
          page.strategy_type = strategy_type
        }
        const params = { ...self.formData, ...page, system_id: self.system_id };
        const res = await getAllInstitutionStrategies(params);
        if (res.code === 0) {
          self.tableData = res.data || [];
          if (res.data.length !== 0) {
            self.currentStrategyData = JSON.parse(JSON.stringify(res.data[0]));
            // 获取设备
            self.getMyDomainDetail(self.currentStrategyData.domain_id)
            if (self.currentStrategyData.strategy_type == 1) { // 按系统分配策略
              // 根据字段 获取科室
              self.getDistinfoFn()
              // 获取指定类型
              self.beganGetStorageFileType()
              // 获取近线策略下的 指定在线设备 和指定近线设备
              self.getOnlineOrNearlineDevice()
            }
            self.$nextTick(() => {
              self.$refs.strategyTable.doLayout()
            })
          } else {
            self.$message({ message: '请先去授权', type: 'error' });
          }
          self.pageInfo = res.page;
          console.log('数据哦', self.tableData);

          // self.DomainsStrategies = []
          // if (res.data.length !== 0) {
          //     if (self.currentDomainIndex < res.data.length) {
          //         self.currentDomain = res.data[self.currentDomainIndex]
          //     } else {
          //         self.currentDomain = res.data[0]
          //     }
          //     self.getMyDomainDetail(self.currentDomain.domain_id)
          //     self.DomainsStrategies = res.data
          //     if (self.currentDomain?.storage_strategies && self.currentDomain.storage_strategies.length > 0) {
          //         self.currentStrategyData = self.currentDomain.storage_strategies[0]
          //     } else {
          //         self.currentStrategyData = {}
          //     }
          // } else {
          //     self.allStrategyList = []
          //     self.requestOver = true
          // }
        } else {
          self.requestOver = true;
          self.$message({ message: `${res.msg}`, type: 'error' });
        }
      },

      // 获取存储域详情
      async getMyDomainDetail(id) {
        const res = await getDomainDeviceList({ id: id });
        if (res.code === 0) {
          this.hasObjectStorage = res.data.some((e) => e.device_type < 6);
          this.onlineObjectStorage = res.data.some(
            (e) => e.is_online && e.device_type < 6
          );
          // 设备列表
          this.deviceList = res.data
        } else {
          this.requestOver = true;
          this.$message({ message: `${res.msg}`, type: 'error' });
        }
      },
      handleChange() {},
    },
    mounted() {
      console.log('获取参数', this.$route);
      this.init();
    },
    activated() {
      this.init();
    },
    computed: {
      ...mapGetters(['cardStyle']),

      containerClass() {
        if (this.requestOver && this.tableData.length === 0 && this.cardStyle) {
          return 'noDomain cardContainer';
        } else if (
          (this.requestOver && this.tableData.length === 0) ||
          this.cardStyle
        ) {
          return this.cardStyle ? 'cardContainer' : 'noDomain';
        }

        return '';
      },
    },
    watch: {},
    filters: {
     // 显示设备名称
     showDeviceName(id, deviceList) {
       let deviceName = "";
       if (deviceList.length === 0) {
         return deviceName
       }
       deviceList.forEach((item) => {
        if (item.id === id) {
          deviceName = item.device_name;
        }
       });
       return deviceName;
     },
     // 显示科室名称
     showDepartName(dic_code, officeArr) {
       let officeName = "";
       if (officeArr.length === 0) {
         return officeName
       }
       officeArr.forEach((item) => {
        if (item.dic_code === dic_code) {
          officeName = item.dic_name;
        }
       });
       return officeName;
     },
     // 显示指定类型
    showCompositeFileTypeName(value, compositeFileTypesArr) {
       let typeName = "";
       if (compositeFileTypesArr.length === 0) {
         return typeName
       }
       compositeFileTypesArr.forEach((item) => {
        if (item.value === value) {
          typeName = item.description;
        }
       });
       return typeName;
     },

   },
  };
</script>
<style lang="less" scoped>
  .btnBox {
    // position: absolute;
    // right: 20px;
    // top: 95px;
    // margin-bottom: 20px;
    button {
      width: 70px;
      height: 32px;
      background-color: #fff;
      border: 1px solid #dcdfe6;
      padding: 0;
    }
  }

  .userlist {
    display: flex;
    flex-direction: column;
    height: 100%;
    background-color: #ebeef5;

    .icon-span-green {
      color: #1cb54a;
      border: 1px solid #1cb54a;
      font-size: 13px;
      text-align: center;
      padding: 3px;
      border-radius: 3px;
    }

    .icon-span-red {
      color: #f56c6c;
      border: 1px solid #f56c6c;
      font-size: 13px;
      text-align: center;
      padding: 3px;
      border-radius: 3px;
    }
  }

  .no-strategy {
    min-height: 150px;
    margin: 15px;
    padding: 20px;
    border: 1px dashed #dcdfe6;
    border-radius: 5px;
  }

  .cardHeader {
    background-color: white;
  }

  .back {
    color: #0a70b0;
    font-weight: 400;
    font-size: 14px;
  }

  .cardContainer {
    margin: 10px !important;
    border-radius: 5px !important;
    // height: calc(100% - 47px - 20px) !important;
  }

  .DeviceCon {
    background-color: white;
    flex: 1;
    height: 0;

    .topCon {
      padding-top: 10px;
      padding-left: 10px;
    }

    .strategyContent {
      padding: 10px;
      border-top: 1px dashed #dcdfe6;
      font-weight: 500;

      &-title {
        font-weight: 400;
        border-radius: 5px;
        padding: 10px;
        width: 380px;
        border: 1px dashed #dcdfe6;
      }
    }

    .deviceList {
      padding: 0 15px;
      height: calc(100% - 120px);

      .tableDiv {
        height: 100%;
        // margin-bottom:20px;
        // border: 1px solid #dcdfe6;
        ::v-deep .el-table__body-wrapper {
          height: calc(100% - 40px)!important;
          overflow-y: auto !important;
        } 
        .organTableData {
          // min-height: 160px;
          height: 100%;

          // ::v-deep th {
          //     background: #f9f9f9;
          //     color: rgb(51, 51, 51);
          // }

          .el-table {
            height: 100%;
            border: none;

            ::v-deep .el-table__body-wrapper {
              min-height: 120px;
              height: calc(100% - 40px);
              // overflow-x:hidden!important;
              overflow-y: auto !important;
            }
          }

          ::v-deep .el-table-column--selection .cell {
            padding-left: 10px;
          }
        }
      }
    }
  }
.systemStorageStrategyCon{
  padding: 0 20px;
  margin-top:30px;
  .strategyItem{
    padding: 0 20px 20px 20px;
    .strategyTitCon{
      margin-bottom: 10px;
        .strategyTit{
          font-size:16px;
          font-weight: 700;
          color:#303133;
        }
        .strategyStatus{
          padding: 2px 8px;
          margin-left:15px;
          text-align: center;
          background: #F6FFED;
          border: 1px solid #D9F7BE;
          border-radius: 4px;
          font-size: 12px;
          color: #1CB54A;
        }
        .strategyErrorStatus{
          background: #FFF1F0;
          border-color: #FFCCC7;
          color:#F56C6C;
        }
      }
    .strategyBasicInfor{
      padding-left:20px;
      .strategyBasicItem{
        line-height: 36px;
        display: flex;
        align-items: center;
        .days{
          font-size:18px;
          font-weight: 700;
          color:#0a70b0;
          font-family: Arial;
          margin: 0 10px;
        }
        .timeIcon{
          font-size:16px;
          color:#0a70b0;
        }
        .timeVal,.strategyBasicItemVal{
          font-size:16px;
          color:#0a70b0;
          margin: 0 5px;
        }
      }
    }

  }
  .bb{
    border-bottom: 1px solid #dcdfe6;
  }
}
</style>
