<template>
  <div class="contentManage">
    <div v-if="!hasAuthority" class="noAuthority">
      <div class="noAuthorityImg"></div>
      <span>
        存储域暂未授权，请联系管理员至客户管理系统-数据管理菜单-存储授权页面，对当前系统进行授权！
      </span>
    </div>
    <div v-else class="contentManageBox" style="width: 100%; height: 100%">
      <div
        v-show="navState"
        class="title-bar flex_row"
        style="background: #fff"
      >
        <div class="tl col">
          <span class="title-name clr_303">
            <i class="iconfont icondingwei mr10"></i>数据管理
            <i class="iconfont iconzhankaishouqi"></i> 内容管理
          </span>
        </div>
      </div>
      <div class="container" :class="{ cardContainer: cardStyle }">
        <div ref="topContainer" class="form-container">
          <div class="form-row">
            <!-- 客户管理员 -->
            <div v-if="system_type === 0" class="system_overview_kehu">
              <div class="data-cell data-cell-wendang fl">
                <div class="data-cell-icon">
                  <i class="iconfont iconwendangzongshu1"></i>
                </div>
                <div class="data-cell-content">
                  <span class="data-cell-label">文档总数：</span>
                  <span class="data-cell-text"
                    >{{ domainInfo.total }}份/{{
                      domainInfo.total_used_size_desc
                    }}</span
                  >
                </div>
              </div>
              <div class="data-cell data-cell-online fl">
                <div class="data-cell-icon">
                  <i class="iconfont iconzaixianwendang"></i>
                </div>
                <div class="data-cell-content">
                  <span class="data-cell-label">在线文档：</span>
                  <span class="data-cell-text"
                    >{{ domainInfo.online_total }}份/{{
                      domainInfo.online_total_used_size_desc
                    }}</span
                  >
                </div>
              </div>
              <div class="data-cell data-cell-nearline fl">
                <div class="data-cell-icon">
                  <i class="iconfont iconjinxianwendang"></i>
                </div>
                <div class="data-cell-content">
                  <span class="data-cell-label">近线文档：</span>
                  <span class="data-cell-text"
                    >{{ domainInfo.nearline_total }}份/{{
                      domainInfo.nearline_total_used_size_desc
                    }}</span
                  >
                </div>
              </div>
              <div class="data-cell data-cell-shanchucelue fl">
                <div class="data-cell-icon">
                  <i class="iconfont iconcelveshanchuwendang"></i>
                </div>
                <div class="data-cell-content">
                  <span class="data-cell-label">策略离线文档：</span>
                  <span class="data-cell-text"
                    >{{ domainInfo.offline_total }}份/{{
                      domainInfo.offline_total_used_size_desc
                    }}</span
                  >
                </div>
              </div>
              <div class="data-cell data-cell-biaoji fl">
                <div class="data-cell-icon">
                  <i class="iconfont iconbiaojishanchuwendang"></i>
                </div>
                <div class="data-cell-content">
                  <span class="data-cell-label">标记删除：</span>
                  <span class="data-cell-text"
                    >{{ domainInfo.delete_total }}份/{{
                      domainInfo.delete_total_used_size_desc
                    }}</span
                  >
                  <!-- <span class="clr_1cb ml5">删除任务执行中</span> -->
                </div>
              </div>
            </div>
            <!-- 存储共享-主索引 -->
            <div
              v-else-if="system_type == 2"
              class="system_overview data-cell-share"
            >
              <div class="system_overview_left fl">
                <div class="system_overview_head of">
                  <div class="fl ml10 f14 clr_33 system_overview_head_title">
                    {{ systemUsageData.system_name }}
                  </div>
                </div>
                <div class="system_overview_left_content_top of">
                  <div class="fl left">
                    <div>
                      <div class="fl">
                        <div class="mt10 mb5 f12 clr_606">已使用(TB)</div>
                        <div class="f16 clr_333">
                          {{ systemUsageData.used_size || "--" }}TB
                        </div>
                      </div>

                      <div class="fr">
                        <div class="mt10 mb5 f12 clr_606">总容量(TB)</div>
                        <div class="f16 clr_333">
                          {{ systemUsageData.total_size || "--" }}TB
                        </div>
                      </div>
                    </div>
                    <el-progress
                      class="clear"
                      :text-inside="true"
                      :stroke-width="15"
                      :percentage="systemPercentage"
                      :color="processColorFn(systemPercentage)"
                    ></el-progress>
                  </div>
                  <div class="fl right f14">
                    <div class="right_top">
                      <span class="right-cell-label">预计可用：</span>
                      <span class="clr_ef89">{{
                        getSpecificDateWithDays(systemUsageData.days_until_full)
                      }}</span>
                    </div>

                    <div class="right_bottom">
                      <span class="right-cell-label">文档总数：</span>
                      <span class="right-cell-text clr_0a"
                        >{{ systemUsageData.total }}份/{{
                          systemUsageData.total_used_size_desc
                        }}</span
                      >
                    </div>
                  </div>
                </div>
              </div>
              <div class="system_overview_right fl ml10">
                <div class="system_overview_head of">
                  <div class="fl ml10 f14 clr_33 system_overview_head_title">
                    系统数据概览
                  </div>
                  <div class="fr">
                    <span
                      @click="SetStrategy"
                      class="function-btn f14 clr_0a fr mr15"
                      :class="{ clr_8f: strategyData.strategy_type == 0 }"
                    >
                      <i class="iconfont iconzongheshezhi mr5"></i>策略设置
                    </span>
                  </div>
                </div>
                <div class="system_overview_content">
                  <!-- <div class="data-cell data-cell-wendang fl">
              <div class="data-cell-icon">
                <i class="iconfont iconwendangzongshu1"></i>
              </div>
              <div class="data-cell-content">
                <span class="data-cell-label">文档总数：</span>
                <span class="data-cell-text">{{ domainInfo.total }}份/{{ domainInfo.total_used_size_desc }}</span>
              </div>
            </div> -->

                  <div class="data-cell data-cell-nearline fl">
                    <div class="data-cell-icon">
                      <i class="iconfont iconjinxianwendang"></i>
                    </div>
                    <div class="data-cell-content">
                      <span class="data-cell-label">近线文档：</span>
                      <span class="data-cell-text"
                        >{{ domainInfo.nearline_total }}份/{{
                          domainInfo.nearline_total_used_size_desc
                        }}</span
                      >
                    </div>
                  </div>
                  <!-- <div
                    class="data-cell data-cell-shanchucelue fl"
                    v-show="false"
                  >
                    <div class="data-cell-icon">
                      <i class="iconfont iconcelveshanchuwendang"></i>
                    </div>
                    <div class="data-cell-content">
                      <span class="data-cell-label">策略离线文档：</span>
                      <span class="data-cell-text"
                        >{{ domainInfo.offline_total }}份/{{
                          domainInfo.offline_total_used_size_desc
                        }}</span
                      >
                    </div>
                  </div> -->
                  <div class="data-cell data-cell-biaoji fl">
                    <div class="data-cell-icon">
                      <i class="iconfont iconbiaojishanchuwendang"></i>
                    </div>
                    <div class="data-cell-content">
                      <span class="data-cell-label">标记删除：</span>
                      <span class="data-cell-text"
                        >{{ domainInfo.delete_total }}份/{{
                          domainInfo.delete_total_used_size_desc
                        }}</span
                      >
                      <!-- <span class="clr_1cb ml5">删除任务执行中</span> -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- 系统 -->
            <div v-else class="system_overview_xitong data-cell-system">
              <div class="system_overview_left fl">
                <div class="system_overview_head of">
                  <div class="fl ml10 f14 clr_33 system_overview_head_title">
                    {{ systemUsageData.system_name }}
                  </div>
                </div>
                <div class="system_overview_left_content of">
                  <div class="system_overview_left_content_top">
                    <div class="fl left">
                      <div>
                        <div class="fl">
                          <div class="mt10 mb5 f12 clr_606">已使用(TB)</div>
                          <div class="f16 clr_333">
                            {{ systemUsageData.used_size || "--" }}TB
                          </div>
                        </div>

                        <div class="fr">
                          <div class="mt10 mb5 f12 clr_606">总容量(TB)</div>
                          <div class="f16 clr_333">
                            {{ systemUsageData.total_size || "--" }} TB
                          </div>
                        </div>
                      </div>
                      <el-progress
                        class="clear"
                        :text-inside="true"
                        :stroke-width="15"
                        :percentage="systemPercentage"
                        :color="processColorFn(systemPercentage)"
                      ></el-progress>
                    </div>
                    <div class="fl right f14">
                      <div class="right_top">
                        <span class="right-cell-label">预计可用：</span>
                        <span class="clr_ef89">{{
                          getSpecificDateWithDays(
                            systemUsageData.days_until_full
                          )
                        }}</span>
                      </div>

                      <div class="right_bottom">
                        <span class="right-cell-label">文档总数：</span>
                        <span class="right-cell-text clr_0a"
                          >{{ systemUsageData.total }}份/{{
                            systemUsageData.total_used_size_desc
                          }}</span
                        >
                      </div>
                    </div>
                  </div>

                  <div class="system_overview_left_content_bottom">
                    <div class="system_overview_left_content_bottom_title">
                      数据范围
                    </div>
                    <div v-if="dataRangeList.length == 0" class="noDataContent">
                      <div class="noDataImg"></div>
                      <span> 暂无数据 </span>
                    </div>
                    <div class="pr20" v-else>
                      <dataRangeLine
                        class="data_line mr10"
                        :data-list="dataRangeList"
                        :contentPage="true"
                      >
                      </dataRangeLine>
                    </div>
                  </div>
                </div>
              </div>
              <div class="system_overview_right fl ml10">
                <div class="system_overview_head of">
                  <div class="fl ml10 f14 clr_33 system_overview_head_title">
                    系统数据概览
                  </div>
                  <div class="fr">
                    <span
                      @click="SetStrategy"
                      class="function-btn f14 clr_0a fr mr15"
                      :class="{ clr_8f: strategyData.strategy_type == 0 }"
                    >
                      <i class="iconfont iconzongheshezhi mr5"></i>策略设置
                    </span>
                  </div>
                </div>
                <div class="system_overview_content">
                  <div class="data-cell data-cell-online">
                    <div class="data-cell-icon">
                      <i class="iconfont iconzaixianwendang"></i>
                    </div>
                    <div class="data-cell-content">
                      <div>
                        <span class="data-cell-label">在线文档：</span>
                        <span class="data-cell-text"
                          >{{ domainInfo.online_total }}份/{{
                            domainInfo.online_total_used_size_desc
                          }}</span
                        >
                      </div>
                    </div>
                  </div>
                  <div class="data-cell data-cell-nearline fl">
                    <div class="data-cell-icon">
                      <i class="iconfont iconjinxianwendang"></i>
                      <div class="data-cell-label lh40 f14 clr_303">
                        <span v-if="strategyData.nearline_mode === 0"
                          >近线<span class="clr_0a">{{
                            strategyData.nearline_of_days
                          }}</span
                          >天数前的文件</span
                        >
                        <span v-else-if="strategyData.nearline_mode === 1">
                          近线至在线容量的
                          <span class="clr_0a"
                            >{{ strategyData.nearline_of_space_ratio }} %</span
                          ></span
                        >
                      </div>
                    </div>
                    <div class="data-cell-content">
                      <div>
                        <span class="data-cell-label">近线策略：</span>
                        <span
                          class="clr_1cb icon-span-green"
                          v-if="strategyData.nearline_enable"
                          >已启用 <i class="iconfont iconqiyong"></i
                        ></span>
                        <span class="clr_ff6f6f" v-else
                          >未启用 <i class="iconfont iconliebiao_yichu"></i
                        ></span>
                      </div>
                      <div>
                        <span class="data-cell-label">执行时间：</span>
                        <span class="data-cell-label">
                          <span class="">{{ nearlineTimeRange }}</span>
                        </span>
                      </div>
                      <div>
                        <span class="data-cell-label">近线文档：</span>
                        <span class="data-cell-text"
                          >{{ domainInfo.nearline_total }}份/{{
                            domainInfo.nearline_total_used_size_desc
                          }}</span
                        >
                      </div>
                    </div>
                  </div>
                  <div
                    class="data-cell data-cell-shanchucelue fl"
                    v-show="false"
                  >
                    <div class="data-cell-icon">
                      <i class="iconfont iconcelveshanchuwendang"></i>
                      <div class="data-cell-label">
                        <span v-if="strategyData.offline_mode === 0">
                          离线
                          <span class="clr_0a">{{
                            strategyData.offline_of_days
                          }}</span
                          >天数前的文件</span
                        >

                        <span v-else-if="strategyData.offline_mode === 1">
                          离线至至容量的
                          <span class="clr_0a"
                            >{{ strategyData.offline_of_space_ratio }}%</span
                          >
                          且最少保留
                          <span class="clr_0a"
                            >{{ strategyData.offline_save_days }}天</span
                          ></span
                        >
                      </div>
                    </div>
                    <div class="data-cell-content">
                      <div>
                        <span class="data-cell-label">离线策略：</span>
                        <span
                          class="clr_1cb icon-span-green"
                          v-if="strategyData.offline_enable"
                          >已启用 <i class="iconfont iconqiyong"></i
                        ></span>
                        <span class="clr_ff6f6f" v-else
                          >未启用 <i class="iconfont iconliebiao_yichu"></i
                        ></span>
                      </div>
                      <div>
                        <span class="data-cell-label">执行时间：</span>
                        <span class="data-cell-label"
                          ><span class="">{{ offlineTimeRange }}</span>
                        </span>
                      </div>
                      <div>
                        <span class="data-cell-label">离线文档：</span>
                        <span class="data-cell-text"
                          >{{ domainInfo.offline_total }}份/{{
                            domainInfo.offline_total_used_size_desc
                          }}</span
                        >
                      </div>
                    </div>
                  </div>
                  <div class="data-cell data-cell-biaoji fl">
                    <div class="data-cell-icon">
                      <i class="iconfont iconbiaojishanchuwendang"></i>
                    </div>
                    <div class="data-cell-content">
                      <div>
                        <span class="data-cell-label">标记删除：</span>
                        <span class="data-cell-text"
                          >{{ domainInfo.delete_total }}份/{{
                            domainInfo.delete_total_used_size_desc
                          }}</span
                        >
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="of">
            <div class="form-row fl">
              <div class="form-item" v-if="system_type === 0">
                <div class="form-item-label">存储域：</div>
                <el-select
                  v-model="formData.domain_id"
                  placeholder="全部"
                  @change="selectDomain"
                >
                  <el-option value="">全部</el-option>
                  <el-option
                    v-for="item in domains"
                    :key="item.id"
                    :label="item.domain_name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </div>
              <div class="form-item" v-if="system_type === 0">
                <div class="form-item-label">业务系统：</div>
                <el-select
                  v-model="formData.system_id"
                  placeholder="全部"
                  filterable
                >
                  <el-option value="">全部</el-option>
                  <el-option
                    v-for="item in systemArr"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </div>
              <div class="form-item" v-if="system_type == 0">
                <div class="form-item-label">业务类型：</div>
                <el-select v-model="formData.business_type" placeholder="全部">
                  <el-option value="">全部</el-option>
                  <el-option
                    v-for="item in documentBusinessTypeList"
                    :key="item.id"
                    :label="item.dic_name"
                    :value="item.dic_code"
                  >
                  </el-option>
                </el-select>
              </div>
              <div class="form-item">
                <div class="form-item-label">检查类型：</div>
                <el-select v-model="formData.modality" placeholder="全部">
                  <el-option value="">全部</el-option>
                  <el-option
                    v-for="item in examineTypeList"
                    :key="item.id"
                    :label="item.dic_name"
                    :value="item.dic_code"
                  >
                  </el-option>
                </el-select>
              </div>

              <div class="form-item form-item-long">
                <div class="form-item-label">上传时间：</div>
                <div style="width: 235px">
                  <SearchTime
                    ref="searchTimeModel"
                    :clearTime="clearTime"
                    :disableTime="'after'"
                    @getTimes="getTimes"
                    :initTime="initTime"
                  />
                </div>
              </div>
              <div
                class="form-item"
                v-if="system_type == 2 || system_type == 3"
              >
                <div class="form-item-label">删除标记：</div>
                <el-select v-model="formData.is_delete" placeholder="全部">
                  <el-option value="">全部</el-option>
                  <el-option
                    v-for="item in deleteStatus"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </div>
              <div class="form-item" v-if="system_type != 0">
                <el-button
                  type="primary"
                  size="small"
                  style="margin-left: 10px"
                  @click="search"
                  >查询</el-button
                >
                <el-button size="small" @click="resetForm" plain
                  >重置</el-button
                >
              </div>
            </div>
            <!-- 筛选“删除标记”为已标记的数据后方可批量删除。注意，每次最多只能删除31天的数据。 -->
            <div class="form-row fr" v-if="system_type == 2">
              <el-button
                @click="deleteFn"
                :disabled="formData.is_delete !== true"
                type="text"
                plain
                class="btnBox ml10i"
                >删除</el-button
              >
              <el-button
                class="ml10 iconfont-btn"
                v-popover:popover
                type="text"
              >
                <!-- <i class="iconfont" style="color:#303333">&#xe628;</i> -->
                <i class="el-icon-question clr_ef89"></i>
              </el-button>
              <el-popover
                ref="popover"
                placement="right"
                width="300"
                trigger="hover"
              >
                <div class="mr10 ml10 mt10 mb10">
                  <span>
                    筛选“删除标记”为已标记的数据后方可批量删除。注意，上传时间范围不得超过31天。</span
                  >
                </div>
              </el-popover>
            </div>
          </div>
          <div class="of" v-if="system_type < 2">
            <div class="form-row fl">
              <div class="form-item" v-if="system_type == 0">
                <div class="form-item-label">存储设备：</div>
                <el-select v-model="formData.device_id" placeholder="全部">
                  <el-option value="">全部</el-option>
                  <el-option
                    v-for="item in domainDeviceList"
                    :key="item.id"
                    :label="item.device_name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </div>
              <div class="form-item" v-if="system_type < 2">
                <div class="form-item-label">所属机构：</div>
                <el-select
                  v-model="formData.org_code"
                  placeholder="全部"
                  filterable
                  @change="orgCodeChange"
                >
                  <el-option value="">全部</el-option>
                  <el-option
                    v-for="item in institutionList"
                    :key="item.code"
                    :label="item.name"
                    :value="item.code"
                  >
                  </el-option>
                </el-select>
              </div>
              <div class="form-item" v-if="system_type == 0">
                <div class="form-item-label">所属科室：</div>
                <el-select v-model="formData.depart_code" placeholder="全部">
                  <el-option value="">全部</el-option>
                  <el-option
                    v-for="item in officesLite"
                    :key="item.system_type"
                    :label="item.name"
                    :value="item.system_type"
                  >
                  </el-option>
                </el-select>
              </div>
              <div class="form-item" v-if="system_type == 0">
                <div class="form-item-label">删除标记：</div>
                <el-select v-model="formData.is_delete" placeholder="全部">
                  <el-option value="">全部</el-option>
                  <el-option
                    v-for="item in deleteStatus"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </div>

              <el-button
                type="primary"
                size="small"
                style="margin-left: 10px"
                @click="search"
                >查询</el-button
              >
              <el-button size="small" @click="resetForm" plain>重置</el-button>
            </div>
            <!-- 筛选“删除标记”为已标记的数据后方可批量删除。注意，每次最多只能删除31天的数据。 -->
            <div class="form-row fr">
              <el-button
                @click="deleteFn"
                :disabled="formData.is_delete !== true"
                type="text"
                plain
                class="btnBox ml10i"
                >删除</el-button
              >
              <el-button
                class="ml10 iconfont-btn"
                v-popover:popover
                type="text"
              >
                <!-- <i class="iconfont" style="color:#303333">&#xe628;</i> -->
                <i class="el-icon-question clr_ef89"></i>
              </el-button>
              <el-popover
                ref="popover"
                placement="right"
                width="300"
                trigger="hover"
              >
                <div class="mr10 ml10 mt10 mb10">
                  <span>
                    筛选“删除标记”为已标记的数据后方可批量删除。注意，上传时间范围不得超过31天。</span
                  >
                </div>
              </el-popover>
            </div>
          </div>
        </div>
        <div
          class="table-container"
          v-bind:class="{ noTableData: tableData.length == 0 }"
        >
          <el-table
            ref="mytable"
            :data="tableData"
            border
            stripe
            height="100%"
            :header-cell-style="{ background: '#F2F2F2', color: '#333' }"
            :row-key="getRowKeys"
            highlight-current-row
            header-row-class-name="strong"
            v-loading="loading"
            element-loading-text="拼命加载中"
            element-loading-background="rgba(255,255,255,0.6)"
            @select="tableSignleSelection"
            @select-all="tableAllSelection"
          >
            <el-table-column
              fixed="left"
              type="selection"
              :reserve-selection="true"
            ></el-table-column>
            <el-table-column label="序号" width="80">
              <template slot-scope="scope">
                <span>{{
                  (page_index - 1) * page_size + scope.$index + 1
                }}</span>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="170">
              <template slot-scope="scope">
                <span
                  class="clr_0a pointer"
                  :class="{ 'btn-disabled': scope.row.is_delete }"
                  @click="browse(scope.row)"
                  >浏览</span
                >
                <!-- <span
                  class="clr_0a pointer pl10"
                  :class="{ 'btn-disabled': scope.row.is_delete }"
                  v-if="canDownloadType.indexOf(scope.row.format_code) !== -1"
                  @click="getDocumentUrl(scope.row)"
                  >下载</span
                > -->

                <span
                  v-if="!scope.row.downloadLoading"
                  class="clr_0a pointer pl10"
                  :class="{ 'btn-disabled': scope.row.is_delete }"
                  @click="getDocumentUrl(scope.row)"
                  >下载</span
                >
                <span v-else class="clr_0a pointer pl10" title="下载中...">
                  <i class="el-icon-loading"></i>
                </span>

                <span
                  class="clr_da pointer pl10"
                  :class="{ 'btn-disabled': scope.row.is_delete }"
                  @click="deleteDoc(scope.row)"
                  >删除</span
                >
              </template>
            </el-table-column>
            <el-table-column
              prop="upload_time"
              label="上传时间"
              width="180"
            ></el-table-column>
            <el-table-column
              prop="file_name"
              label="文档名称"
              width="250"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="format_code"
              label="文档类型"
              width="100"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="file_size_desc"
              label="文档大小"
              width="120"
            ></el-table-column>
            <el-table-column
              prop="business_type_name"
              label="业务类型"
            ></el-table-column>
            <el-table-column prop="modality" label="检查类型"></el-table-column>
            <el-table-column
              prop="depart_name"
              label="所属科室"
              width="90"
            ></el-table-column>

            <el-table-column
              prop="org_name"
              label="所属机构"
              width="200"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="device_name"
              label="存储设备"
              width="140"
            ></el-table-column>
            <el-table-column prop="is_delete" label="删除标记" width="120">
              <template slot-scope="scope">
                <span :class="{ 'span-isdelete': scope.row.is_delete }">{{
                  scope.row.is_delete ? "已标记" : "未标记"
                }}</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="pageDiv">
          <pagination-tool
            :total="total"
            :page.sync="page_index"
            :limit.sync="page_size"
            @pagination="getDocuments"
          />
        </div>
      </div>
    </div>

    <!-- 删除 -->
    <el-dialog
      v-el-drag-dialog
      v-if="delDialog"
      :title="delteTitle"
      :visible.sync="delDialog"
      width="560px"
      :before-close="handleClose"
    >
      <div class="pt20 pl10">
        <div class="pb10 pl10">
          <div class="clr_ef8900 mb10">
            <i class="iconfont mr5">&#xe646;</i>
            <span v-if="deleteType == 1">
              该操作将彻底删除文件，涉及数据安全风险，请慎重处理！</span
            >
            <span v-else>
              该操作将给记录打上删除标记，计划任务开启时，将彻底删除此类记录和文件，涉及数据安全风险，请慎重处理！</span
            >
          </div>
          <div class="mb10">
            如果该条数据是通过跨客户的索引注册方式生成，则删除该条数据，会导致被采集客户处的源文件被删除，造成数据丢失，请慎重处理！
          </div>
          <div class="mb10">{{ delDialogTitle }}</div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <div v-if="deleteStep != 2">
          <el-button size="small" @click="handleClose">取消</el-button>
          <el-button size="small" type="primary" @click="handleSure"
            >确定</el-button
          >
        </div>
        <div v-else>
          <el-button size="small" @click="handleSure">确定</el-button>
          <el-button size="small" type="primary" @click="handleClose"
            >取消</el-button
          >
        </div>
      </span>
    </el-dialog>
    <!-- 进度条 -->
    <div class="progressClass">
      <el-dialog
        v-el-drag-dialog
        v-if="delPDialog"
        :show-close="false"
        title=""
        :visible.sync="delPDialog"
        width="580px"
        top="31vh"
        :before-close="handleClose"
      >
        <div class="pt10">
          <div class="pb10 pl10 of progressContent">
            <span class="">文档删除中</span>
            <el-progress
              class="progress-file"
              :percentage="percentage"
            ></el-progress>

            <el-button class="" size="small" @click="progressClose"
              >取消</el-button
            >
          </div>
        </div>
      </el-dialog>
    </div>
    <!-- 存储策略设置 -->
    <SetSaveStrategyConfigVue
      :SetSaveStrategyShow="SetSaveStrategyShow"
      :configIds="configIds"
      :hasObjectStorage="hasObjectStorage"
      :onlineObjectStorage="onlineObjectStorage"
      :StrategyData="strategyData"
      @SetSaveStrategyClose="SetSaveStrategyClose"
    />
  </div>
</template>
<script>
import moment from "moment";
import SearchTime from "@/components/common/SearchTime";
import { getSystemsList } from "@/api/user";
import SetSaveStrategyConfigVue from "../components/SetSaveStrategyConfig.vue";
import { mapGetters, mapMutations } from "vuex";
import dataRangeLine from "../storageStatistics/components/dataRangeLine.vue";
import PaginationTool from "@/components/common/PaginationTool"; // 分页
import {
  getAllDomains,
  getDocumentListTotalize,
  getDomainDeviceList,
  getDocuments,
  deleteDocument,
  getDocumentUrl,
  getAuthorityMessage,
  deleteTaggedDocument,
  deleteTaggedDocumentProgress,
  getCurrentSystemStrategies,
  getSystemDataRange,
  getCurrentSystemUsages,
  getDocumentUrlByShortChain,
  getReportDetails,
  downloadFile,
  getFileByDocumentId,
} from "@/api/memorySharing/dataMemory";

import {
  getDistinfoByType,
  getInstitutionListLite,
  getOfficesLite,
} from "@/api/commonHttp";
import Mgr from "@/utils/SecurityService";
import markStrategy from "../markStrategy";

export default {
  components: {
    PaginationTool,
    dataRangeLine,
    SearchTime,
    SetSaveStrategyConfigVue,
    markStrategy,
  },
  data() {
    return {
      initTime: this.$getDefaultTime(0, 0),
      delId: "",
      deleteType: 0, //0默认是打标记1删除
      deleteStep: 1, //删除提示第几步
      tableContainerStyle: {},
      tableHeight: "calc(100% - 57px)",
      SetSaveStrategyShow: false,
      hasObjectStorage: false,
      onlineObjectStorage: false,
      systemPercentage: 0,
      systemUsageData: {},
      strategyData: {},
      configIds: [],

      dataRangeList: [],
      progressInterval: null,
      front_id: "",
      percentage: 10,
      delPDialog: false,
      delDialogTitle: "确定要删除",
      delDialog: false,
      currentTableChecked: [],
      clearTime: false, // 清除查询时间
      system_id: null,
      systemArr: [],
      hasAuthority: false,
      roleType: 0, //0客户管理员
      system_type: 0, //0客户管理员 1放射系统 2影像主索引（存储共享系统？）3质控系统 其他系统
      total: 0,
      value: "",
      domainInfo: {},
      domains: [],
      formData: {
        domain_id: "",
        system_id: "",
        business_type: "",
        modality: "",
        device_id: "",
        org_code: "",
        depart_code: "",
        is_delete: "",
        begin_upload_time: "",
        end_upload_time: "",
      },
      page_index: 1,
      page_size: 20,
      loading: false,
      tableData: [],
      examineTypeList: [],
      documentBusinessTypeList: [],
      institutionList: [],
      domainDeviceList: [],
      officesLite: [],
      deleteStatus: [
        {
          value: true,
          label: "已标记",
        },
        {
          value: false,
          label: "未标记",
        },
      ],
      navState: true,
      fileData: "",
      canDownloadType: [
        "docx",
        "xlsx",
        "pptx",
        "pdf",
        "ofd",
        "MP4",
        "bmp",
        "gif",
        "jpeg",
        "png",
        "jpg",
      ],
    };
  },
  watch: {
    "formData.domain_id"(val) {
      if (val) {
        this.search();
      }
    },
    system_type: {
      handler(val) {
        console.log("啥情况？system_type", val);
        if (parseInt(val) > 0) {
          this.SetShowMenuHeader(false);
        } else {
          this.SetShowMenuHeader(true);
        }
        if (parseInt(val) > 0) {
          //获取系统用量
          this.getCurrentSystemUsages();
          //获取存储策略
          this.getCurrentSystemStrategies();
          if (parseInt(val) != 2) {
            //获取数据范围
            this.getSystemDataRange();
          }
          //获取当前系统数据容量信息
          this.setTableHeigth();
        }
      },
    },
  },
  computed: {
    ...mapGetters(["cardStyle", "loginTokenInfo"]),

    delteTitle() {
      if (this.deleteStep == 3) {
        return "最终提示";
      } else {
        return `第${this.deleteStep}次提示`;
      }
    },
    nearlineTimeRange() {
      let beginTime = "";
      let endTime = "";
      if (this.strategyData.nearline_begin_perform_time)
        beginTime = moment(
          new Date(this.strategyData.nearline_begin_perform_time)
        ).format("HH:mm:ss");
      if (this.strategyData.nearline_end_perform_time)
        endTime = moment(
          new Date(this.strategyData.nearline_end_perform_time)
        ).format("HH:mm:ss");
      return beginTime + "~" + endTime;
    },
    offlineTimeRange() {
      let beginTime = "";
      let endTime = "";
      if (this.strategyData.offline_begin_perform_time)
        beginTime = moment(
          new Date(this.strategyData.offline_begin_perform_time)
        ).format("HH:mm:ss");
      if (this.strategyData.offline_end_perform_time)
        endTime = moment(
          new Date(this.strategyData.offline_end_perform_time)
        ).format("HH:mm:ss");
      return beginTime + "~" + endTime;
    },
  },
  mounted() {
    this.init();
  },

  methods: {
    ...mapMutations({ SetShowMenuHeader: "dataStorage/SET_SHOWMENUHEADER" }),
    setTableHeigth() {
      this.$nextTick(() => {
        let topHeight = this?.$refs?.topContainer?.offsetHeight;
        topHeight = topHeight + 20;
        this.tableHeight = `calc(100% - 56px)`;
        this.tableContainerStyle = { height: `calc(100% - ${topHeight}px)` };
      });
    },
    getSpecificDateWithDays(day) {
      if (!day) return "--";
      if (day == "∞") return "--";
      // console.log('这是个啥类型的数据哦？',day,typeof(day));
      if (day < 30) {
        return day + "天";
      } else if (day < 365) {
        let month = Math.floor(day / 30);
        let days = Math.round((day / 30 - month) * 30);
        // if (days == 0) {
        return month + "月";
        // } else {
        //     return month + '月' + days
        //     // + '天'
        // }
      } else {
        let year = Math.floor(day / 365);
        let month = Math.floor(((day / 365 - year) * 365) / 30);
        let days = Math.round((((day / 365 - year) * 365) / 30 - month) * 30);

        if (year > 3) {
          return "3年以上";
        } else {
          if (month == 0 && days == 0) {
            return year + "年";
          } else {
            return year + "年" + month + "月";
          }
        }
      }
    },
    SetSaveStrategyClose(res) {
      this.SetSaveStrategyShow = false;
      //更新存储策略
      if (res == true) {
        this.getCurrentSystemStrategies();
      }
    },
    floatMultiply(arg1, arg2, forChart = false) {
      if (arg1 == null || arg2 == null) {
        return null;
      }
      var n1, n2;
      var r1, r2; // 小数位数
      try {
        r1 = arg1.toString().split(".")[1].length;
      } catch (e) {
        r1 = 0;
      }
      try {
        r2 = arg2.toString().split(".")[1].length;
      } catch (e) {
        r2 = 0;
      }
      n1 = Number(arg1.toString().replace(".", ""));
      n2 = Number(arg2.toString().replace(".", ""));
      // console.log('比例为0', n1 * n2 / Math.pow(10, r1 + r2));
      let results = (n1 * n2) / Math.pow(10, r1 + r2);
      if (forChart && results == 0) return 0.01;
      return results;
    },
    //getCurrentSystemUsages
    async getCurrentSystemUsages(id) {
      //获取当前存储域下的存储策略
      const res = await getCurrentSystemUsages({ system_id: this.system_id });
      if (res.code === 0) {
        this.systemUsageData = res.data;
        if (res.data.total_size > 0) {
          let num = res.data.used_size / res.data.total_size;
          let percent = Number(num.toString().match(/^\d+(?:\.\d{0,4})?/));
          this.systemPercentage = this.floatMultiply(percent, 100);
        }
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    async getCurrentSystemStrategies(id) {
      //获取当前存储域下的存储策略
      const res = await getCurrentSystemStrategies({
        system_id: this.system_id,
      });
      if (res.code === 0) {
        if (res?.data?.length > 0) {
          this.strategyData = res.data[0];
          this.configIds = [this.strategyData.id];
          if (this.strategyData.strategy_type == 0) {
            //按照存储域配置 ===== 不支持配置策略
          } else {
            console.log("没有域名id", this.strategyData.domain_id);
            this.getDomainDeviceList(this.strategyData.domain_id);
          }
        }
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },

    dealDataRangeData(list) {
      if (list.length > 2) {
        let waitSortArr = list.map((e) => {
          return { ...e, date_value: Number(e.date_string.replace("-", "")) };
        });
        let descArr = waitSortArr.sort((a, b) => {
          return b.date_value - a.date_value;
        });
        let results = this.dealSameState(0, descArr);

        this.dataRangeList = results;
      } else {
        this.dataRangeList = list;
      }
    },

    //默认最近的以近线数据
    dealSameState(state = 0, descArr, results = []) {
      // debugger
      let waitSortArr = descArr.map((e) => {
        return { ...e, date_value: Number(e.date_string.replace("-", "")) };
      });
      if (
        descArr.filter((e) => {
          e.data_state == state;
        }).length == descArr.length
      ) {
        let item = descArr[0];
        item.last_date_title = descArr[descArr.length - 1].date_string;
        results.push(item);
        return results;
      }

      let ascArr = waitSortArr.sort((a, b) => {
        return a.date_value - b.date_value;
      });

      let firstIndex = descArr.findIndex((e) => e.data_state == state);
      let lastIndex = ascArr.findIndex((e) => e.data_state == state);
      // debugger
      if (firstIndex > -1) {
        let item = descArr[firstIndex];

        if (lastIndex > -1) {
          let index = descArr.length - lastIndex - 1;
          let arr1 = descArr.splice(0, index + 1);
          // debugger
          results.push(this.getOneDataItem(state, arr1));

          if (lastIndex == 0) {
            return results;
          } else {
            if (state == 2) return results;
            return this.dealSameState(state + 1, descArr, results);
          }
          //都存在
        } else {
          //只有一个对应状态
          if (firstIndex != 0) {
            let arr1 = descArr.splice(0, firstIndex + 1);
            results.push(this.getOneDataItem(state, arr1));
            if (descArr.length > 0) {
              if (state == 2) return results;

              return this.dealSameState(state + 1, descArr, results);
            } else {
              return results;
            }
          } else {
            // debugger
            let item = descArr[0];
            item.last_date_title = descArr[descArr.length - 1].date_string;
            results.push(item);
            return results;
          }
        }
      } else {
        //没有数据？？
        if (state == 2) return results;
        return this.dealSameState(state + 1, descArr, results);
      }
    },
    getAbnormalOneItem(state, list, results = []) {
      let abnormalArr = list.filter((e) => e.data_state != state);
      // debugger
      if (abnormalArr.length == 0) return results;
      if (abnormalArr.length < 2) {
        results.push({
          ...abnormalArr[0],
          date_range: abnormalArr[0].date_string,
        });
        return results;
      }

      let firstAbIndex = list.findIndex((e) => e.data_state != state);
      let abnormalFirstItem = {};
      if (firstAbIndex > -1) {
        abnormalFirstItem = list[firstAbIndex];
        // debugger
        let arr = list.splice(0, firstAbIndex + 1);
        // debugger
        let otherAbItemIndex = list.findIndex(
          (e) => e.data_state != abnormalFirstItem.data_state
        );

        if (otherAbItemIndex > -1) {
          abnormalFirstItem.date_range = abnormalFirstItem.date_string;
          if (otherAbItemIndex != 0) {
            let abnormalLastItem = list[otherAbItemIndex - 1];
            abnormalFirstItem.date_range =
              abnormalLastItem.date_string +
              "~" +
              abnormalFirstItem.date_string;
          }
          results.push(abnormalFirstItem);
          // debugger
          if (list[otherAbItemIndex].data_state == state) {
            list.splice(0, otherAbItemIndex + 1);
          } else {
            list.splice(0, otherAbItemIndex);
          }
          if (list.length == 0) {
            return results;
          } else {
            return this.getAbnormalOneItem(state, list, results);
          }
        } else {
          let abnormalLastItem = list[list.length - 1];
          abnormalFirstItem.date_range =
            abnormalLastItem.date_string + "~" + abnormalFirstItem.date_string;
          results.push(abnormalFirstItem);
        }
      } else {
      }

      return results;
    },
    getOneDataItem(state, list) {
      let item = list.find((e) => e.data_state == state) || list[0];
      item.last_date_title = list[list.length - 1].date_string;

      item.date_string = list[0].date_string;
      item.abnormal_list = [];
      let abnormalArr = list.filter((e) => e.data_state != item.data_state);
      if (abnormalArr.length == 0) return item;
      item.abnormal_list = this.getAbnormalOneItem(state, list);

      return item;
    },
    dealAbnormalListData(list) {
      return list.map((e) => {
        let groups = e.abnormals.reduce((group, item) => {
          const key = item.data_state;
          if (!group[key]) {
            group[key] = { list: [] };
          }
          group[key].list.push(item);
          return group;
        }, {});
        let results = Object.values(groups).map((e) => {
          let item = e?.list[0];
          e.list.sort((a, b) => {
            return (
              moment(a.last_date_title).valueOf() -
              moment(b.last_date_title).valueOf()
            );
          });
          return { data_state: item.data_state, list: e.list };
        });
        e.abnormals = results;
        return e;
      });
    },
    async getSystemDataRange(id) {
      this.dataRangeList = [];
      const res = await getSystemDataRange({ systemId: this.system_id });
      if (res.code === 0) {
        this.dataRangeList = this.dealAbnormalListData(res.data);
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    getRowKeys(row) {
      return row.id;
    },
    getUuid() {
      let _time = new Date().getTime();
      let guid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
        /[xy]/g,
        function (c) {
          let r = (_time + Math.random() * 16) % 16 | 0;
          _time = Math.floor(_time / 16);
          return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
        }
      );

      return guid;
    },
    closeSession() {
      this.currentTableChecked = [];
      this.$nextTick(() => {
        this.$refs.mytable.clearSelection();
      });
    },
    tableSignleSelection(rows, row) {
      // console.log("重新点击",rows);
      this.currentTableChecked = rows;
    },
    tableAllSelection(rows) {
      this.currentTableChecked = rows;
    },
    deleteFn() {
      if (
        this.formData.begin_upload_time === "" &&
        this.formData.end_upload_time === ""
      ) {
        this.$message.error("请选择上传时间！");
        return;
      }
      if (
        this.formData.begin_upload_time === "" ||
        this.formData.end_upload_time === ""
      ) {
        this.$message.error("上传时间范围不得超过31天，请重新选择上传时间！");
        return;
      }
      if (
        moment(this.formData.end_upload_time).diff(
          moment(this.formData.begin_upload_time),
          "days"
        ) > 31
      ) {
        this.$message.error("上传时间范围不得超过31天，请重新选择上传时间！");
        return;
      }
      if (this.currentTableChecked.length === 0) {
        this.$message.error("请选择需要删除的数据！");
        return;
      }
      let beginDate = moment(this.formData.begin_upload_time).format(
        "yyyy-MM-DD"
      );
      let endDate = moment(this.formData.end_upload_time).format("yyyy-MM-DD");

      if (this.currentTableChecked.length === 1) {
        this.delDialogTitle = `确认删除${this.currentTableChecked[0].file_name}吗？`;
      } else {
        this.delDialogTitle = `确认删除${beginDate}至${endDate}内的${this.currentTableChecked.length}条文档吗？`;
      }
      this.deleteStep = 1;
      this.deleteType = 1;

      // this.delDialog = true
      // let _this = this;
      // this.$confirm(this.delDialogTitle, "提示", {
      //   confirmButtonText: "确认",
      //   cancelButtonText: "取消",
      //   type: "warning",
      //   // center: true,
      //   dangerouslyUseHTMLString: true,
      //   distinguishCancelAndClose: true,
      // })
      //   .then((action) => {
      //     //确定
      //     _this.delPDialog = true;
      //     _this.front_id = this.getUuid();
      //     let ids = _this.currentTableChecked.map((e) => e.id);
      //     deleteTaggedDocument({
      //       front_id: _this.front_id,
      //       documents: ids,
      //     }).then((res) => {
      //       if (res.code === 0) {
      //         _this.$message.success("删除请求成功");
      //         _this.progressInterval = setInterval(() => {
      //           _this.getDelDocumentProgress();
      //         }, 100);
      //       } else {
      //         _this.$message.error(res.msg);
      //       }
      //     });
      //   })
      //   .catch((action) => {});

      this.delDialog = true;
    },
    sureDeleteFn() {
      let _this = this;
      //确定
      _this.delPDialog = true;
      _this.front_id = this.getUuid();
      let ids = _this.currentTableChecked.map((e) => e.id);
      deleteTaggedDocument({
        front_id: _this.front_id,
        documents: ids,
      }).then((res) => {
        if (res.code === 0) {
          _this.$message.success("删除请求成功");
          _this.progressInterval = setInterval(() => {
            _this.getDelDocumentProgress();
          }, 100);
        } else {
          _this.$message.error(res.msg);
        }
      });
    },
    getDelDocumentProgress() {
      let _this = this;

      deleteTaggedDocumentProgress({ front_id: this.front_id }).then((res) => {
        if (res.code === 0) {
          _this.percentage = Math.round(
            (res.data / _this.currentTableChecked.length) * 100
          );
          if (res.data === _this.currentTableChecked.length) {
            _this.delPDialog = false;
            clearInterval(_this.progressInterval);

            _this.search();
            _this.closeSession();
            _this.percentage = 0;
          }
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    //deleteTaggedDocumentProgress
    handleClose() {
      this.deleteStep = 1;
      this.delDialog = false;
    },
    handleSure() {
      this.deleteStep++;
      if (this.deleteStep == 4) {
        this.delDialog = false;
        this.deleteStep = 1;
        if (this.deleteType == 1) {
          this.sureDeleteFn();
        } else {
          this.sureMarkDeleteFn();
        }
      }
    },
    progressClose() {
      //取消删除
      this.delPDialog = false;
    },
    getTimes(val) {
      this.clearTime = false;

      this.formData.begin_upload_time = val ? val[0] : "";
      this.formData.end_upload_time = val ? val[1] : "";
      this.search();
    },
    async getAuthorityMessage() {
      if (this.roleType == 0) {
        this.hasAuthority = true;
        return;
      }

      let res = await getAuthorityMessage({ system_id: this.system_id });
      if (
        res.code === 0 &&
        (res?.data?.system_permissions === 0 ||
          res?.data?.system_permissions === 1)
      ) {
        //有权限
        this.hasAuthority = true;
      } else {
        //无权限
        this.hasAuthority = false;
      }
      console.log("是否有权限？", this.hasAuthority);
    },

    async getMySystemsList() {
      const self = this;
      self.systemArr = [];
      const res = await getSystemsList();
      if (res.code === 0) {
        self.systemArr = res.data;
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    processColorFn(val) {
      if (val < 50) {
        return "#73DEB3";
      } else if (val > 50 && val < 80) {
        return "#e6a23c";
      } else {
        return "#f56c6c";
      }
    },
    SetStrategy() {
      //存储域整体配置的，不支持系统级别配置
      if (this.strategyData.strategy_type == 0) return;
      if (this.system_type == 2) {
        //存储共享系统策略设置
        var path = process.env.NODE_ENV === "development" ? "/" : "/operate/";
        this.$router.push({
          path: `${path}dataStorage/setStrategy`,
          query: { system_id: this.system_id, system_type: this.system_type },
        });
      } else {
        //策略设置
        //复用功能
        this.SetSaveStrategyShow = true;
      }
    },
    selectDomain(item) {
      this.formData.domain_id = item;
      this.formData.system_id = "";
      this.formData.device_id = "";
      this.getDomainDeviceList();
    },
    resetForm() {
      // const { domain_id } = this.formData
      this.formData = {
        domain_id: "",
        system_id: this.system_id,
        business_type: "",
        modality: "",
        device_id: "",
        org_code: "",
        depart_code: "",
        is_delete: "",
        begin_upload_time: "",
        end_upload_time: "",
      };
      this.clearTime = true;
      this.search();
    },
    search() {
      this.closeSession();
      this.page_index = 1;
      this.getDocumentListTotalize();
      this.getDocuments();
    },
    browse(doc) {
      if (doc.is_delete) return;
      if (["avi", "wmv"].includes(doc.format_code.toLocaleLowerCase()) && window.location.protocol === 'http:') {
        this.$message.warning('该格式视频在http环境下无法播放，请升级到https环境，或点击下载按钮下载到本地播放。');
        return;
      }
      const { id, business_id, business_type_name, format_code } = doc;
      // 统一全部进filePreview页面，在里面再区分是本地实现预览还是iframe嵌别的项目中的预览
      const { href } = this.$router.resolve({
        name: "filePreviewIndex",
        query: {
          businessId: business_id,
          businessType: business_type_name,
          id: id,
          // formatCode: format_code,
        },
      });
      window.open(href, "_blank");
      // 苗哥的图片预览可支持 jpeg  jpg  png
      // if (
      // [
      //   "docx",
      //   "xlsx",
      //   "pptx",
      //   "pdf",
      //   "ofd",
      //   "mp4",
      //   "bmp",
      //   "gif",
      //   "ico",
      //   "avi",
      //   "wmv",
      // ].includes(doc.format_code.toLocaleLowerCase())
      // ) {
      //   const { href } = this.$router.resolve({
      //     name: "filePreviewIndex",
      //     query: {
      //       businessId: business_id,
      //       businessType: business_type_name,
      //       id: id,
      //       formatCode: format_code,
      //     },
      //   });
      //   window.open(href, "_blank");
      // }
      // else if (doc.format_code === 'ofd') {
      //   const { href } = this.$router.resolve({
      //   name: "ofdViewIndex",
      //     query: {
      //       businessId: business_id,
      //       businessType: business_type_name,
      //       id: id,
      //       formatCode:format_code,
      //     },
      //   });

      //  window.open(href, "_blank");
      // }
      // else {
      //   const { href } = this.$router.resolve({
      //     name: "FileViewIndex",
      //     query: {
      //       businessId: business_id,
      //       businessType: business_type_name,
      //       id: id,
      //     },
      //   });

      //   window.open(href, "_blank");
      // }
    },
    deleteDoc(doc) {
      const { id, file_name, is_delete } = doc;
      if (is_delete) {
        return;
      }
      // const text = `确认删除${file_name}吗？`;
      this.deleteType = 0;
      this.delDialogTitle = `确定对“${file_name}”打删除标记吗？`;
      this.deleteStep = 1;
      this.delDialog = true;
      this.delId = id;

      // this.$confirm(text, "提示", {
      //   confirmButtonText: "确定",
      //   cancelButtonText: "取消",
      //   type: "warning",
      // }).then(() => {
      //   deleteDocument(id).then((res) => {
      //     if (res.code === 0) {
      //       this.$message.success("删除成功");
      //       this.getDocuments();
      //     } else {
      //       this.$message.error(res.msg);
      //     }
      //   });
      // });
    },
    sureMarkDeleteFn() {
      deleteDocument(this.delId).then((res) => {
        if (res.code === 0) {
          this.$message.success("标记成功");
          this.getDocuments();
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    //获取业务系统相关信息
    getSystemInfo() {
      let val = parseInt(this.system_type);
      if (val > 0) {
        this.SetShowMenuHeader(false);
        //获取系统用量
        this.getCurrentSystemUsages();
        //获取存储策略
        this.getCurrentSystemStrategies();
        // if (val != 2) {
        //获取数据范围
        this.getSystemDataRange();
        // }
        //获取当前系统数据容量信息
        this.setTableHeigth();
      } else {
        this.SetShowMenuHeader(true);
      }
    },
    async init() {
      if (this.$route.query.system_id) {
        this.system_id = this.$route.query.system_id;
        this.formData.system_id = this.system_id;
      }
      if (this.$route.query.system_type) {
        this.system_type = this.$route.query.system_type;
      }
      // console.log('传过来的数据哦',this.$route.query.system_type);
      // console.log('系统类型是啊啥哦',this.system_type);

      if (this.$route.meta.hideNav) {
        this.navState = false;
      }

      // this.system_id = '1275347957465485312'//心电系统
      // this.system_id = '1278586236218380288'
      // //存储共享系统
      //  this.system_id = '1744628639713611776'
      // '1281159422571188211'
      // this.system_type = 2
      this.getRoleType();
      this.getSystemInfo();
      this.getMySystemsList();
      this.getDistinfoByType();
      if (!this.system_id) {
        await this.getAllDomains();
      } else {
        await this.getMySystemsList();
      }

      this.getDomainDeviceList();
      this.getInstitutionListLite();
      this.search();
    },
    //获取当前权限
    async getRoleType() {
      let user;
      if (this.loginTokenInfo) {
        user = JSON.parse(JSON.stringify(this.loginTokenInfo));
      } else {
        const manager = new Mgr();
        user = await manager.getRole();
      }
      const prmCode = user.profile.prm_codes;
      //Operation运营管理员 Tenancy客户管理员
      if (prmCode.match(/organ_nrgl/i)) {
        this.roleType = 0;
        this.hasAuthority = true;
      } else {
        this.roleType = 1;
      }

      console.log("roleType,", this.roleType);
      this.getAuthorityMessage();
    },
    // 获取所有存储域
    getAllDomains() {
      return new Promise((resolve, reject) => {
        getAllDomains()
          .then((res) => {
            if (res.code === 0) {
              this.domains = res.data;
              if (this.domains.length > 0) {
                this.formData.domain_id = this.domains[0].id;
              }
            } else {
              this.$message.error(res.msg);
            }
            resolve();
          })
          .catch((error) => {
            reject(error);
          });
      });
    },
    // 获取存储域详情
    getDocumentListTotalize() {
      const params = this.formData;
      getDocumentListTotalize(params).then((res) => {
        if (res.code === 0) {
          this.domainInfo = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 获取业务类型、检查类型字典
    getDistinfoByType() {
      const _parmas = "ExamineType,DocumentBusinessType";
      const url = `/dict/${_parmas}`;
      getDistinfoByType(url).then((res) => {
        if (res.code === 0) {
          this.examineTypeList = res.data.filter(
            (item) => item.lookup_key === "ExamineType"
          );
          this.documentBusinessTypeList = res.data.filter(
            (item) => item.lookup_key === "DocumentBusinessType"
          );
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 获取存储域下的检查设备
    getDomainDeviceList(domain_id) {
      const data = {
        id: this.formData.domain_id,
      };
      if (domain_id) data.id = domain_id;
      if (!data.id) return;
      getDomainDeviceList(data).then((res) => {
        if (res.code === 0) {
          this.domainDeviceList = res.data;
          if (domain_id) {
            this.hasObjectStorage = res.data.some((e) => e.device_type < 6);
            this.onlineObjectStorage = res.data.some(
              (e) => e.is_online && e.device_type < 6
            );
          } else {
            this.hasObjectStorage = false;
            this.onlineObjectStorage = false;
          }
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 获取机构列表
    getInstitutionListLite() {
      getInstitutionListLite().then((res) => {
        if (res.code === 0) {
          this.institutionList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 改变机构选择组件的选中值
    orgCodeChange(value) {
      this.formData.depart_code = "";
      if (value) {
        this.getOfficesLite(value);
      } else {
        this.officesLite = [];
      }
    },
    // 获取机构下的科室列表
    getOfficesLite(value) {
      const idx = this.institutionList.findIndex((item) => item.code === value);
      let id = "";
      if (idx !== -1) {
        id = this.institutionList[idx].id;
      }
      var _url = "/offices/lite?institution_id=" + id;
      getOfficesLite(_url).then((res) => {
        if (res.code === 0) {
          this.officesLite = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    getDocuments() {
      this.loading = true;
      const page = {
        page_index: this.page_index,
        page_size: this.page_size,
      };
      const params = Object.assign({}, this.formData, page);
      getDocuments(params)
        .then((res) => {
          //console.log(res)
          this.loading = false;
          if (res.code === 0) {
            this.tableData =
              res.data.map((item) => ({
                ...item,
                downloadLoading: false,
              })) || [];
            this.total = res.page.total_count || 0;
            this.setTableHeigth();
          }
        })
        .catch((error) => {
          this.loading = false;
        });
    },
    // 文件下载所需函数
    async getDocumentUrl(row) {
      row.downloadLoading = true;
      try {
        const res = await getFileByDocumentId({
          document_id: row.id,
          dicomdir: false,
        });
        row.downloadLoading = false;
        if (res instanceof ArrayBuffer) {
          const decoder = new TextDecoder("utf-8");
          const text = decoder.decode(new Uint8Array(res));
          try {
            // 尝试解析为 JSON
            const json = JSON.parse(text);
            // 判断是否为错误信息
            if (json && json.Msg) {
              // 这里可以拿到后台返回的错误提示
              this.$message.error(json.Msg);
              return;
            }
          } catch (e) {
            // 不是 JSON，说明是正常的二进制文件
            // 下载文件
            let blob = new Blob([res], {
              //下载的文件类型；
              type: row.mime_type,
            });
            if (window.navigator.msSaveOrOpenBlob) {
              // 兼容ie
              navigator.msSaveBlob(blob, row.file_name);
              navigator.msSaveBlob(blob);
            } else {
              var link = document.createElement("a");
              link.href = window.URL.createObjectURL(blob);
              link.download = row.file_name;
              link.click();
              window.URL.revokeObjectURL(link.href); //释放内存
            }
          }
        }
      } catch (error) {
        row.downloadLoading = false;
      }
    },
    // 文件下载所需函数
    // async beganGetReportDetails(accessId, row) {
    //   let params = {
    //     // accessId: 'cCcMVxFadYv', // 图片
    //     accessId: accessId, // pdf
    //     bussinessId: "",
    //   };
    //   let res = await getReportDetails(params);
    //   let { Code, Data } = res;
    //   if (Code === 0) {
    //     if (Data.Details.length > 0) {
    //       let { DeviceID, FilePath } = Data.Details[0];
    //       // let url = `${this.apiUrl}/api-imaging/File/Download?DeviceID=${DeviceID}&ImagePath=${FilePath}&MimeType=application/pdf`
    //       let fileRes = await downloadFile(DeviceID, FilePath, row.format_code);
    //       this.fileData = fileRes;
    //       this.beganDownLoadFile(row);
    //     } else {
    //       this.$message({
    //         type: "warning",
    //         message: "没有相关内容",
    //       });
    //     }
    //   } else {
    //     this.fileData = null;
    //     this.$message({
    //       type: "warning",
    //       message: res.Msg,
    //     });
    //   }
    // },
    // 准备下载文件
    // beganDownLoadFile(row) {
    //   if (this.fileData) {
    //     let blob = new Blob([this.fileData], {
    //       //下载的文件类型；
    //       type: `application/${row.format_code}`,
    //     });
    //     if (window.navigator.msSaveOrOpenBlob) {
    //       navigator.msSaveBlob(blob, row.file_name);
    //       navigator.msSaveBlob(blob);
    //     } else {
    //       var link = document.createElement("a");
    //       link.href = window.URL.createObjectURL(blob);
    //       link.download = row.file_name;
    //       link.click();
    //       window.URL.revokeObjectURL(link.href); //释放内存
    //     }
    //   }
    // },
  },
};
</script>
<style lang="less" scoped>
.contentManageBox {
  display: flex;
  flex-direction: column;

  .container {
    display: flex;
    flex-direction: column;
    height: 0;
    flex: 1;
  }
}
.clr_ef8900 {
  color: #ef8900;
}
.wrap_content_0 {
  .container {
    // padding: 10px 15px;

    background: #fff;
    height: 100%;
    // position: relative;
  }

  .cardContainer {
    // margin: 10px !important;
    // border-radius: 5px !important;
    // height: 100% !important;
  }
}

.contentManage {
  background-color: #ebeef5;
  overflow: hidden !important;
  width: 100%;
  height: 100%;

  .container {
    // padding: 10px 15px;

    background: #fff;
    height: calc(100% - 47px);
    // position: relative;
  }

  .cardContainer {
    // margin: 10px;
    // border-radius: 5px;
    height: calc(100% - 47px - 20px);
  }

  .noAuthority {
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    .noAuthorityImg {
      width: 480px;
      height: 320px;
      background-image: url("../../../../assets/images/dataStorage/noAuthority.png");
      background-size: cover;
    }

    span {
      padding: 20px;
      font-size: 20px;
    }
  }
}

.form-container {
  padding: 10px 15px 0;
}

.form-row {
  display: flex;
  flex-wrap: wrap;
  margin-bottom: 8px;

  &:first-child {
    margin-bottom: 15px;
  }
}

::v-deep .type-select {
  height: 40px;

  .el-dropdown {
    font-size: 15px;
    height: 40px;
    line-height: 40px;
    color: #303133;
    width: 275px;
    cursor: pointer;
  }
}

.clr_ff6f6f {
  color: #ff6f6f;
}

.system_overview {
  width: 100%;
  height: 120px;

  &_left {
    width: 30%;
    height: 100%;

    // background-color: red;
    &_content {
      display: flex;
      flex-direction: column;
    }

    &_content_top {
      // height: 80px;
      border-left: 1px solid #dcdfe6;
      border-right: 1px solid #dcdfe6;
      border-bottom: 1px solid #dcdfe6;
      // border-radius: 0px 0px 3px 3px;
      height: calc(100% - 30px);

      // background-color: yellow;
      .left {
        padding: 0 10px;
        height: 100%;
        width: 50%;
        // background-color: red;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        color: #333;
        border-right: 1px solid #dcdfe6;
      }

      .right {
        padding: 20px 10px 20px;
        width: 50%;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }
    }

    &_content_bottom {
      // height: 100px;
      border-left: 1px solid #dcdfe6;
      border-right: 1px solid #dcdfe6;
      border-bottom: 1px solid #dcdfe6;
      // border-radius: 0px 0px 3px 3px;
      position: relative;

      .system_overview_left_content_bottom_title {
        position: absolute;
        top: 1px;
        left: 10px;
        font-weight: 400;
        font-size: 12px;
        color: #606266;
      }
    }

    .data_line {
      padding: 30px 0px 0px 30px;
      height: 70px;
      background-color: #fff;
    }
  }

  &_right {
    height: 100%;
    width: calc(70% - 10px);
  }

  &_head {
    height: 30px;
    // border-radius: 3px 3px 0px 0px;
    background-color: #f0f3f7;
    border: 1px solid #dcdfe6;

    &_title {
      text-align: center;
      line-height: 30px;
    }
  }

  &_content {
    height: calc(100% - 30px);
  }
}

.system_overview_content {
  display: flex;
  height: calc(100% - 30px);
  width: 100%;
}

.system_overview_kehu {
  display: flex;
  height: 100px;
  width: 100%;

  .data-cell {
    border-top: 1px solid #dcdfe6;
    flex: 1;

    &-wendang {
      // border-radius: 3px 0px 0px 3px;
    }

    &-biaoji {
      // border-radius: 0px 3px 0px 3px;
    }
  }
}

.data-cell-online .data-cell-icon {
  background: rgba(0, 173, 120, 0.12);
}

.system_overview_xitong {
  width: 100%;
  display: flex;
  .system_overview_left_content_top {
    border-left: 1px solid #dcdfe6;
    border-right: 1px solid #dcdfe6;
    border-radius: 0px;
  }
  .data-cell {
    // width: 50%;
    height: 100%;
    display: flex;
    align-items: center;
    flex-direction: column;
    padding: 10px;
    border-left: 1px solid #dcdfe6;
    border-bottom: 1px solid #dcdfe6;
    &-wendang > &-icon {
      background: rgba(28, 181, 74, 0.12);
    }
    &-wendang &-text {
      color: rgba(28, 181, 74, 1);
    }
    &-nearline > &-icon {
      background: rgba(28, 139, 228, 0.12);
    }

    &-nearline &-text {
      color: rgba(28, 139, 228, 1);
    }
    &-shanchucelue > &-icon {
      background: rgba(255, 111, 111, 0.12);
    }

    &-shanchucelue &-text {
      color: rgba(255, 111, 111, 1);
    }

    &-biaoji {
      border-right: 1px solid #dcdfe6;
    }

    &-biaoji > &-icon {
      background: rgba(239, 137, 0, 0.12);
      border-radius: 4px;
    }

    &-biaoji &-text {
      color: #ef8900;
    }

    &-icon {
      padding: 5px;
      width: 100%;
      height: 45px;
      display: flex;
      flex-direction: row;
      // align-items: ;
      justify-content: space-between;
      border-radius: 4px;
      font-weight: 400;
    }

    .iconwendangzongshu1 {
      color: rgba(28, 181, 74, 1);
      font-size: 20px;
    }

    .iconjinxianwendang {
      color: #1c8be4;
      font-size: 20px;
    }

    .iconcelveshanchuwendang {
      color: #ff6f6f;
      font-size: 20px;
    }

    .iconbiaojishanchuwendang {
      color: #e6a23c;
      font-size: 20px;
    }

    &-content {
      // min-width: 25%;
      padding: 0px;
      width: 100%;
      height: 100%;
      text-align: left;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      justify-content: space-evenly;
    }

    &-label {
      color: #333;
      font-size: 14px;
    }
  }
}

.data-cell {
  width: 25%;
  height: 100%;
  display: flex;
  align-items: center;
  padding: 10px;
  // margin-left: 15px;
  // border-radius: 3px;
  border-left: 1px solid #dcdfe6;
  border-bottom: 1px solid #dcdfe6;

  &-wendang {
    // border-radius: 0px 0px 0px 3px;
  }

  &-wendang > &-icon {
    background: rgba(28, 181, 74, 0.12);
  }

  &-wendang &-text {
    color: rgba(28, 181, 74, 1);
  }

  // &-nearline {
  //   border-radius: 0px 0px 0px 3px;
  // }

  &-nearline > &-icon {
    background: rgba(28, 139, 228, 0.12);
  }

  &-nearline &-text {
    color: rgba(28, 139, 228, 1);
  }

  // &-shanchucelue {
  //   border-radius: 0px 0px 0px 3px;
  // }

  &-shanchucelue > &-icon {
    background: rgba(255, 111, 111, 0.12);
  }

  &-shanchucelue &-text {
    color: rgba(255, 111, 111, 1);
  }

  &-biaoji {
    flex: 1;
    border-right: 1px solid #dcdfe6;
    // border-radius: 0px 0px 3px 0px;
  }

  &-biaoji > &-icon {
    background: rgba(239, 137, 0, 0.12);
    border-radius: 4px;
  }

  &-biaoji &-text {
    color: #ef8900;
  }

  &-icon {
    width: 45px;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
  }

  .iconwendangzongshu1 {
    color: rgba(28, 181, 74, 1);
    font-size: 20px;
  }

  .iconzaixianwendang {
    color: #00ad78;
    font-size: 20px;
  }

  .iconjinxianwendang {
    color: #1c8be4;
    font-size: 20px;
  }

  .iconcelveshanchuwendang {
    color: #ff6f6f;
    font-size: 20px;
  }

  .iconbiaojishanchuwendang {
    color: #e6a23c;
    font-size: 20px;
  }

  &-content {
    // min-width: 25%;
    height: 100%;
    padding: 0 15px;
    // line-height: 38px;
    // line-height: 60px;
    display: flex;
    align-items: center;
    // justify-content:;
  }

  &-label {
    color: #303133;
  }
}

.iconfont-btn {
  font-size: 20px;
  // height: 30px;
  padding: 0px !important;

  .iconfont {
    font-size: 20px;
  }
}

.icon-span-green {
  color: #1cb54a;
  // border: 1px solid #1CB54A;
  font-size: 13px;
  text-align: center;
  padding: 3px;
  border-radius: 3px;
}

.progressClass {
  .progressContent {
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    align-items: center;
    min-height: 80px;
  }

  ::v-deep .el-dialog__header {
    height: 0px;
  }

  ::v-deep .el-dialog__body {
    border-radius: 10px;
  }

  .progress-file {
    margin-left: 10px;
    width: calc(100% - 150px);
  }

  .el-button {
    border: none;
    color: #0a70b0;

    &:hover,
    &:focus {
      background-color: transparent;
    }
  }
}

.btnBox {
  width: 70px;
  height: 32px;
  color: #ff6f6f;
  background-color: #fff;
  border: 1px solid #ff6f6f;
  padding: 0;

  &:hover,
  &:focus {
    border: 1px solid #ff6f6f;
    color: #ff6f6f;
    background-color: #fff;
  }
}

.form-item-small {
  width: 160px !important;

  ::v-deep .el-select {
    width: 85px !important;
  }
}

.form-item-medium {
  width: 230px !important;

  ::v-deep .el-select {
    width: 155px !important;
  }
}

.form-item-long {
  width: 310px !important;

  // &-label {
  //   width: 75px;
  // }

  // &+& {
  //   margin-left: 15px;
  // }
  ::v-deep .el-date-editor--daterange {
    width: 235px;
  }

  ::v-deep .el-date-editor .el-range-input {
    width: 50% !important;
  }

  ::v-deep .el-date-editor .el-range__close-icon {
    line-height: 26px;
  }
}

.form-item {
  display: flex;
  align-items: center;
  // width: 275px;
  justify-content: space-between;

  &-label {
    width: 80px;
    flex-shrink: 0;
  }

  & + & {
    margin-left: 15px;
  }
}

.table-container {
  position: relative;
  flex: 1;
  height: 0;
  margin: 0 15px;

  ::v-deep .el-table {
    //overflow: auto;

    &::before {
      height: 0;
    }
  }
}

.pageDiv {
  border: 1px solid #ebeef5;
  border-top: 0;
}

.span-isdelete {
  color: #ff9900;
}

.noDataContent {
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  .noDataImg {
    width: 60px;
    height: 40px;
    background-image: url("../../../../assets/images/dataStorage/noData.png");
    background-size: cover;
  }

  span {
    padding: 5px;
    font-size: 10px;
  }
}

.btn-disabled {
  color: #c0c4cc;
  cursor: not-allowed;
}
</style>
