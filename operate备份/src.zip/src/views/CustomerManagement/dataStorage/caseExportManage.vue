<template>
  <div class="caseExportCon">
    <div class="title-bar flex_row">
      <div class="crumbsCon">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr5"></i>病例导出
          <i class="iconfont iconzhankaishouqi"></i> 导出管理
        </span>
      </div>
      <div class="tr col">
        <span @click="goBack" class="clr_0a pointer">
          <i class="iconfont iconfanhui pr5"></i>返回
        </span>
      </div>
    </div>
  
    
    <div class="caseExportContainer">
      <div class="importTip">
        <span class="headIcon"></span>
        <span class="importTipTit">导出授权</span>
        <span class="importTipText">病例导出默认需要管理员审批，以下配置条件下数据允许用户申请后导出，无需等待审批；权限控制重复时，优先按照更小权限，其次按照配置顺序生效。</span>
      </div>
      <div class="searchQuery flex_row" >
         <div class="queryCon ml10" v-if="!isUpdate">
          <span class="search-bar-label">医疗机构：</span>
          <el-select
              @change="searchAuthList"
              filterable
              clearable
              v-model="searchData.name"
              placeholder=""
              class="ele-select_32 width_130_select"
              style="width:200px"
          >
              <el-option
              v-for="(item,index) in orgOptions"
              :key="index"
              :label="item.name"
              :value="item.name"
              ></el-option>
          </el-select>

          <span class="search-bar-label ml10">检查科室：</span>
          <el-select
              @change="searchAuthList"
              filterable
              clearable
              v-model="searchData.office_id"
              placeholder=""
              class="ele-select_32 width_130_select"
              style="width:200px"
          >
              <el-option
                  v-for="dept in allOfficeList"
                  :key="dept.office_id"
                  :label="`${dept.office_name}(${dept.institution_name})`"
                  :value="dept.office_id"
                >
                {{ dept.office_name }}( {{dept.institution_name}} )
              </el-option>

          </el-select>
          <span class="search-bar-label ml10">审批人：</span>
          <el-input class=""
            style="width:160px"
            v-on:keyup.enter.native=searchAuthList
            v-model="searchData.user_name"
            placeholder="请输入审批人姓名">
          </el-input>
         </div>
         
         <div class="operateBtnCon flex_1 tr">
          <span
            class="userListoperate-btn clr_ff bg_0a mr10"
            @click="updatePermission"
            v-if="!isUpdate"
            ><i class="iconfont iconbianji mr5"></i>编辑</span
          >
         
          <span
            class="userListoperate-btn clr_ff bg_f5 mr10"
            @click="cancelUpdatePermission"
            v-if="isUpdate"
            ><i class="iconfont iconliebiao_shenhebutongguo mr5"></i>取消</span
          >

          <span
            class="userListoperate-btn clr_ff bg_0a mr10"
            @click="savePermissionSet"
            v-if="isUpdate"
            ><i class="iconfont iconliebiao_shenhetongguo mr5"></i>保存</span
          >

          <span
            class="userListoperate-btn clr_ff bg_e6 mr10"
            @click="addConfig"
            v-if="isUpdate"
            ><i class="iconfont iconxinzeng mr5"></i>新增</span
          >
         </div>

      </div>
     <!--- 非编辑状态 --->
      <div class="caseExportContent" v-show="!isUpdate">
        <div
          class="allInspect tableCon clear"
          v-loading="loading"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          v-bind:class="{ noTableData: authList.length == 0 }"
        >
          <el-table
            :data="authList"
            border
            stripe
            height="100%"
            row-key="id"
            ref="tableAutoScroll"
            highlight-current-row
            header-row-class-name="strong"
          >
          <el-table-column
              align="center"
              type="index"
              label="序号"
              width="55"
            >
            </el-table-column>
            <el-table-column label="操作" width="60">
              <template slot-scope="scope">
                <span class="clr_da pointer" @click="deleteThisPowerSet(scope.row,scope.$index)"
                  >删除</span
                >
              </template>
            </el-table-column>
          <el-table-column
            label="科室"
            width="400"
            prop="office_name"
            show-overflow-tooltip
          ></el-table-column>

          <el-table-column
            label="审批"
            width="100"
            prop="state"
            show-overflow-tooltip
          >
            <template slot-scope="scope">
              <span class="needCheck" v-if="scope.row.state">需审批</span>
              <span class="noNeedCheck" v-else>无需审批</span>
            </template>
        
          </el-table-column>

          <el-table-column
            label="审批人"
            prop="user_name"
            show-overflow-tooltip
          >
        
          <template slot-scope="scope">
              <span v-if="scope.row.state">{{ scope.row.user_name }}</span>
              <span v-else></span>
            </template>
          </el-table-column>
          
          </el-table>
        </div>

        <div class="importTip pl0">
          <span class="headIcon"></span>
          <span class="importTipTit">导出配置</span>
          <span class="importTipText">带宽限制，根据院内服务器性能和文件大小，配置每批次最大下载影像量，注意:配置过大可能回导致服务器崩溃。</span>
        </div>
        <div class="downloadNumSet">
          <span class="downloadLabel">每批次下载影像数：</span>
          <el-input-number size="small" disabled class="width_180_input" v-model="importImgCount" :min="1"></el-input-number>
        </div>
      </div>

     <!--- 编辑状态 -->
     <div class="caseExportContent updatePermissionCon" v-show="isUpdate">
      <div
        class="allInspect clear"
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-background="rgba(255,255,255,0.6)"
        v-bind:class="{ noTableData: configList.length == 0 }"
      >
        <el-table
          :data="configList"
          border
          stripe
          height="100%"
          ref="editAuthTable"
          highlight-current-row
          header-row-class-name="strong"
        >
          <el-table-column
            align="center"
            type="index"
            label="序号"
            width="55"
          >
          </el-table-column>
          <el-table-column label="操作" width="60">
            <template slot-scope="scope">
              <span class="clr_da pointer" @click="deleteThisPowerSet(scope.row,scope.$index)"
                >删除</span
              >
            </template>
          </el-table-column>
          
          <el-table-column
          label="机构"
          width="340"
        >
          <template slot-scope="scope">
          <!---el-select  :disabled="isDeptDisabled(scope.$index)"  --->
            <el-select
            v-model="configList[scope.$index].institution_ids"
            multiple
            filterable
            clearable
            collapse-tags
            placeholder="请选择机构"
            @change="handleDeptChange(scope.$index)"
            style="width: 329px;"
          >
            <el-option
              v-for="dept in availableDepts"
              :key="dept.id"
              :label="dept.name"
              :value="dept.id"
              :disabled="isDeptDisabledInOptions(dept)"
            />
            </el-select>
          </template>
        </el-table-column>

        <el-table-column
          label="科室"
          width="300"
        >
          <template slot-scope="scope" >
           

            <el-select
            v-model="configList[scope.$index].office_ids"
            :filter-method="query => filterOffice(scope.$index, query)"
            @focus="loadOffices(scope.$index)"
            @change="handleOfficeChange(scope.$index)"
            popper-class="officeSelect"
            multiple
            filterable
            clearable
            collapse-tags
            placeholder="选择科室"
            style="width:289px;"
          >
              <el-option
                  v-for="dept in filteredOffices[scope.$index]"
                  :key="dept.office_id"
                  :label="`${dept.office_name}(${dept.institution_name})`"
                  :value="dept.office_id"
                  :disabled="isOfficeDisabled(dept)"
                >
                {{ dept.office_name }}( {{dept.institution_name}} )
              </el-option>


            <!-- <el-option
              v-for="dept in getAvailableDepts(scope.row)"
              :key="dept.office_id"
              :label="`${dept.office_name}(${dept.institution_name})`" 
              :value="dept.office_id"
            >
            {{ dept.office_name }}( {{dept.institution_name}} )
              </el-option> -->


              <div class="select_up pl20">
                <el-button type="text" v-on:click="(val) => selectAllFiltered(scope.$index)">全选</el-button>
                <!-- <el-button type="text" v-on:click="(val) => selectReverse(val,scope.$index)">反选</el-button> -->
                <el-button type="text" v-on:click="(val) => removeAll(val,scope.$index)">清空</el-button>
              </div>
          </el-select>


          </template>
        </el-table-column>

        <el-table-column
          label="审批"
          width="200"
        >
          <template slot-scope="scope">
            <el-radio-group v-if="isUpdate" v-model="scope.row.state" class="radioBox" size="medium">
              <el-radio :label="true">需审批</el-radio>
              <el-radio :label="false">无需审批</el-radio>
           </el-radio-group>
          </template>
        </el-table-column>


        <el-table-column
          label="审批人"
        >
          <template slot-scope="scope">

            <el-select
              v-if="scope.row.state"
              filterable
              clearable
              multiple
              collapse-tags
              v-model="scope.row.user_ids"
              placeholder=""
              class="ele-select_32 width_130_select"
              style="width:300px;"
              >
              <el-option
              v-for="(item,index) in scope.row.users"
              :key="index"
              :label="`${item.name}(${item.phone})`"
              :value="item.id"
              >
              {{ item.name }}( {{item.phone}} )
            </el-option>
           </el-select>

           <el-tooltip placement="top" v-if="scope.row.state">
            <div slot="content">添加审批人</div>
            <span class="addAddress dib ml10" @click="showAddCheckUserAlert(scope.row,scope.$index)">
              <i class="el-icon-plus f16"></i>
            </span>
          </el-tooltip>


            <!-- <el-input
              size="small"
              class="productSearchInput w260 ml10"
              v-model="scope.row.user_ids"
              @focus="showAddCheckUserAlert(scope.row)"
              placeholder="全局检索"
            >
            </el-input> -->
          </template>
        </el-table-column>

        </el-table>
      </div>
      <!-- <div class="blockPage">
        <pagination-tool
          :total="totalImportOutNum"
          :page.sync="searchData.offset"
          :limit.sync="searchData.limit"
          @pagination="beganGetExportAuthEditList"
        />
      </div> -->


      <div class="importTip">
        <span class="headIcon"></span>
        <span class="importTipTit">导出配置</span>
        <span class="importTipText">带宽限制，根据院内服务器性能和文件大小，配置每批次最大下载影像量，注意:配置过大可能回导致服务器崩溃。</span>
      </div>
      <div class="downloadNumSet">
        <span class="downloadLabel">每批次下载影像数：</span>
        <el-input-number size="small" class="width_180_input" v-model="importImgCount" :min="1"></el-input-number>
      </div>
    </div>
  </div>


  <el-dialog
      v-if="showCaseCheckChoosePeopleAlert"
      title="新增成员"
      :visible.sync="showCaseCheckChoosePeopleAlert"
      :close-on-click-modal="false"
      width="950px"
      v-dialogDrag
    >
        <caseCheckPeopleChoose
          ref="caseCheckPeopleChoose"
          :deptOptions="deptOptions"
        ></caseCheckPeopleChoose>

        <div class="dialog_footer">
          <el-button size="small" plain @click="showCaseCheckChoosePeopleAlert = false"
            >取消</el-button
          >
          <el-button type="primary" size="small" @click="sureAddCheckPeople"
            >确定</el-button
          >
        </div>
    </el-dialog>

  </div> 
</template>
<script>
import { UnshiftToArray} from '@/components/commonJs'
import caseConditionInquery from "./components/caseConditionInquery";
import CommonTable from '@/components/common/CommonTable'
import PaginationTool from '@/components/common/PaginationTool'
import caseCheckPeopleChoose from "./components/caseCheckPeopleChoose";

import { getInstitutionListLite, getOfficesLite } from '@/api/commonHttp'
import { getExportAuthList, getCaseExportAuthEditList,deleteExportAuth,getAllAuthOfficeList, getAllAuditUsersList, getImportDetail, saveImoprtPermission,getImportImgCount } from "@/api/platform_costomer/caseExport";

let configId = 0
export default {
   components: {
    caseConditionInquery,
    CommonTable,
    PaginationTool,
    caseCheckPeopleChoose,
   },
   data () {
    return {
      allAuthList: [],
      authList: [],
      loading:false,
      searchData: {
        name: "",
        office_id: "",
        user_name: "",
      },
      curEditIndex: -1,
      // 表头字段
      propData: [
        { prop: "institute_name", label: "机构", width: 400 },
        { prop: "inspect_office", label: "科室", width: 240 },
        { prop: "inspect_num", label: "审批", width: 200 },
        { prop: "operator_name", label: "审批人", },
      ],
      allOfficeList: [],// 所有科室列表
      additUsersList: [],
      isUpdate: false,
      orgOptions: [],
      deptOptions: {},
      // 配置列表
      configList: [],
      filteredOffices: {},
      searchQueries: {},
      showCaseCheckChoosePeopleAlert: false,
      importImgCount: 10,
    }
  },
  computed: {
    // 所有已选科室ID（全局）
    allSelectedOffices() {
      const selected = new Set();
      this.configList.forEach(config => {
        config.office_ids.forEach(id => selected.add(id));
      });
      return selected;
    },

    // 可用机构列表（过滤掉科室全选的机构）
    availableDepts() {
      return this.orgOptions.filter(dept => {
        const total = this.deptOptions[dept.id]?.length || 0;
        const selected = [...this.allSelectedOffices].filter(id =>
          this.deptOptions[dept.id]?.some(o => o.office_id === id)
        ).length;
        // return selected < total;
        return selected <= total;
      });
    },
  },
  methods: {
    addConfig() {
      this.configList.push({
        institution_ids: [],
        office_ids: [],
        state: '',
        user_ids: [],
        users: [],
      });
      this.$set(this.filteredOffices, this.configList.length - 1, []);
      this.$set(this.searchQueries, this.configList.length - 1, '');
    },

    deleteConfig(index) {
      this.configList.splice(index, 1);
      this.$delete(this.filteredOffices, index);
      this.$delete(this.searchQueries, index);
    },

    // 机构选择变化处理
    handleDeptChange(index) {
      this.configList[index].office_ids = [];
      this.loadOffices(index);
    },

    // 加载科室数据
    loadOffices(index) {
      const institution_ids = this.configList[index].institution_ids;
      let offices = [];
      institution_ids.forEach(deptId => {
        offices = offices.concat(this.deptOptions[deptId] || []);
      });
      this.$set(this.filteredOffices, index, offices);
    },

    // 科室搜索过滤
    filterOffice(index, query) {
      this.searchQueries[index] = query.toLowerCase();
      this.$set(this.filteredOffices, index, [
        ...this.getBaseOffices(index).filter(office =>
          office.office_name.toLowerCase().includes(this.searchQueries[index])
        ),
      ]);
    },

    // 获取基础科室列表（未过滤）
    getBaseOffices(index) {
      const institution_ids = this.configList[index].institution_ids;
      let offices = [];
      institution_ids.forEach(deptId => {
        offices = offices.concat(this.deptOptions[deptId] || []);
      });
      return offices;
    },

    // 全选过滤后的科室
    selectAllFiltered(index) {
      const filtered = this.filteredOffices[index]
        .filter(office => !this.isOfficeDisabled(office))
        .map(office => office.office_id);
      
      const current = new Set(this.configList[index].office_ids);
      filtered.forEach(id => current.add(id));
      this.configList[index].office_ids = [...current];
    },

    // 判断机构是否在选项中禁用
    isDeptDisabledInOptions(dept) {
      const total = this.deptOptions[dept.id]?.length || 0;
      const selected = [...this.allSelectedOffices].filter(id =>
        this.deptOptions[dept.id]?.some(o => o.office_id === id)
      ).length;
      return selected >= total;
    },

    // 判断科室是否禁用
    isOfficeDisabled(office) {
      return this.allSelectedOffices.has(office.office_id);
    },

    // 判断机构选择框是否禁用
    isDeptDisabled(index) {
      return this.configList[index].office_ids.length > 0;
    },

    // 科室选择变化处理
    handleOfficeChange(index) {
      // 自动移除已选机构中科室全选的机构
      const currentDepts = [...this.configList[index].institution_ids];
      const validDepts = currentDepts.filter(deptId => {
        const total = this.deptOptions[deptId]?.length || 0;
        const selected = [...this.allSelectedOffices].filter(id =>
          this.deptOptions[deptId]?.some(o => o.office_id === id)
        ).length;
        // return selected < total;
        return selected <= total;
      });
      this.configList[index].institution_ids = validDepts;
    },
    goBack() {
      this.$router.go(-1);
    },
    // 编辑
    async updatePermission () {
      const self = this
      self.isUpdate = true
      // 获取所有审批人员
      await self.beganGetAllAuditUsersList()
      self.$nextTick(()=> {
        // 获取权限列表
        self.beganGetExportAuthEditList()
        self.$refs.editAuthTable.doLayout()
      })
    },
    // 取消编辑
    cancelUpdatePermission () {
      this.isUpdate = false
      this.beganGetExportAuthList()
    },
    // 保存权限设置
    async savePermissionSet () {
      const self = this
      const params = {
        //tenancy_id: '',
        max_download_number: self.importImgCount,
        auth: [],
      }
      let validateSub = true
      let msgText = ''
      self.configList.forEach((item) => {
        let obj = {
          state: item.state,
          offices: [],
          user_ids: item.user_ids,
        }
        if (item.state === '') {
          msgText = '请选择审批'
          validateSub = false
        }
        if (item.state === true && item.user_ids.length === 0) {
          msgText = '请选择审批人'
          validateSub = false
        }
        if (item.institution_ids.length != 0 && item.office_ids.length == 0) {
          msgText = '请选择相应的科室'
          validateSub = false
        }
        if (item.office_ids.length != 0) {
          item.office_ids.forEach((one) => {
            let officeObj = {
              institution_id: self.getInstituteId(one),
              office_id: one,
            }
            obj.offices.push(officeObj)
          })
        }
        
        params.auth.push(obj)
      })
      
      // 验证失败
      if (!validateSub) {
        this.$message.error(msgText);
        return false
      }

      const res = await saveImoprtPermission(params);
      if (res.code === 0) {
        this.$message({type: "success",message: "保存成功！",});
        this.isUpdate = false
        // 保存成功后 重新获取
        this.beganGetExportAuthList()
      } else {
        this.$message.error(res.msg);
      }
    },
    // 删除某条导出申请
    deleteThisPowerSet (row,index) {
      if (this.isUpdate) {
        this.configList.splice(index,1)
        return false
      }
      this.$confirm(
        '<i class="iconfont icontishi clr_e6 mr5"></i>确定要删除该审批配置？',
        "删除用户",
        {
          distinguishCancelAndClose: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
        }
      ).then(() => {
        this.beganDelPowerSet(row.id);
      });
    },
    // 删除导出权限配置
    async beganDelPowerSet (id) {
      const res = await deleteExportAuth({id: id});
      if (res.code === 0) {
        // 保存成功后 重新获取
        this.$message({type: "success",message: "删除成功！",});
        this.beganGetExportAuthList()
      } else {
        this.$message.error(res.msg);
      }
    },
    // 先加载每一行对应的科室下拉列表
    dealOfficeList (arr) {
      const self = this
      if (arr.length != 0) {
        arr.forEach((item,i) =>{
          self.loadTrOffices(item.institution_ids,i)
        })
      }
    },
    // 加载table 每一行对应的科室数据
    loadTrOffices(institution_ids,index) {
      let offices = [];
      if(institution_ids.length != 0) {
        institution_ids.forEach(deptId => {
          offices = offices.concat(this.deptOptions[deptId] || []);
        }); 
      }
      this.$set(this.filteredOffices, index, offices);
    },
    // 获取权限里面  设置的导出影像数
    async beganGetImportImgCount () {
      const res = await getImportImgCount()
      if (res.code === 0) {
        this.importImgCount = res.data
      } else{
        this.$message.error(res.msg)
      }
    },
    // 获取授权编辑列表
    async beganGetExportAuthEditList () {
      const self = this;
      self.loading = true
      self.configList = []
      const res = await getCaseExportAuthEditList();
      if (res.code === 0) {
        self.loading = false;
        const result = res.data
        // 先赋值table 每一行 对应的科室下拉列表
        await self.dealOfficeList(result)
        if (result.length != 0) {
          self.$nextTick(() => {
            result.forEach((item) => {
              const obj = {}
              obj.state = item.state
              obj.user_ids = item.users.map((item) => item.id)
              obj.users = item.users
              obj.id = ++configId
              obj.institution_ids = item.institution_ids
              obj.office_ids = item.office_ids
              self.configList.push(obj)
            });
          })
        }
      } else {
        self.loading = false;
        self.$message.error(res.msg);
      }
    },
    // 改变医疗机构
    changeInstitute (val) {
      this.beganGetExportAuthEditList()
    },
   // 获取机构列表
   async getInstitutionListLiteFn() {
    const self = this
    self.deptOptions = {}
    const res = await getInstitutionListLite();
    if (res.code === 0) {
      self.orgOptions = res.data;
      if (self.orgOptions.length != 0) {
        self.orgOptions.forEach((item)=> {
          self.deptOptions[item.id] = []
        })
      }
    } else {
      self.$message.error(res.msg);
    }
   },
   // 获取机构的名字
   getInstituteName (instituteId) {
    let instituteName = ''
    this.orgOptions.forEach((item)=> {
      if (item.id == instituteId) {
        instituteName = item.name
      }
    })
    return instituteName
   },
   // 通过科室id 去找机构id
   getInstituteId (officeId) {
    let instituteId = ''
    this.allOfficeList.forEach((item)=> {
      if (item.office_id == officeId) {
        instituteId = item.institution_id
      }
    })
    return instituteId
   },
   // 获取授权所有科室
   async beganGetAllAuthOfficeList () {
    const self = this
    const res = await getAllAuthOfficeList()
    if (res.code === 0) {
      self.allOfficeList = res.data
      if (self.allOfficeList.length != 0) {
        self.allOfficeList.forEach((item) => {
          self.deptOptions[item.institution_id].push(item)
        })
      }

    } else {
      self.$message({ message: `${res.msg}`, type: 'error' })
    }
   },
  // 科室下拉方法结束
  visibleChange(bol,index) {
    console.log('option',index)
    //this.configList[index].officeList = this.configList[index].officeCopyList
  },
  // 全选
  selectAll(e,row,index) {
    const self = this
    self.configList[index].office_ids = []
    const selectedOrgIds = new Set(row.institution_ids);
      // 检查每个机构是否所有科室都被选中
      selectedOrgIds.forEach(orgId => {
        const allDepts = JSON.parse(JSON.stringify(self.deptOptions[orgId]));
        allDepts.forEach((item) => {
          if (!self.isDeptDisabled(item.office_id,row)) {// 是否是不能选的科室
            self.configList[index].office_ids.push(item.office_id)
          }
        })
      })
  },
  // 反选
  selectReverse(e,tableIndex) {
    let arr = []
    this.configList[index].officeList.map(item=> {
      let index = this.configList[tableIndex].office_ids.indexOf(item.office_id)
      if(index!==-1) {

      } else {
        arr.push(item.office_id)
      }
    })
    this.configList[tableIndex].office_ids = arr
  },
  removeAll(e,index) {
    this.configList[index].office_ids = []
  },
    // 获取可用科室
    getAvailableDepts(row,value) {
      let orgDepts = this.deptOptions.filter(d => 
        row.institution_ids.includes(d.institution_id)
      )
    

      if(value) {
        orgDepts = orgDepts.filter((item) => {
        if (!!~item.office_name.indexOf(value) || !!~item.office_name.toUpperCase().indexOf(value.toUpperCase())  || !!~item.institution_name.indexOf(value) || !!~item.institution_name.toUpperCase().indexOf(value.toUpperCase())) {
          return true
        }
      })

      return orgDepts
    } else {
      return orgDepts.filter(d => !this.lockedDepts.has(d.office_id))
    }

     //return orgDepts.filter(d => !this.lockedDepts.has(d.office_id))
    },
    // 检查机构是否禁用
    checkOrgDisabled(orgId) {
      const total = this.getOrgDeptCount(orgId)
      const used = this.getLockedDeptCount(orgId)
      return used >= total
    },
    // 获取机构科室总数
    getOrgDeptCount(orgId) {
      return this.deptOptions.filter(d => d.institution_id === orgId).length
    },
    // 获取已锁定科室数
    getLockedDeptCount(orgId) {
      return Array.from(this.lockedDepts).filter(id => {
        const dept = this.deptOptions.find(d => d.office_id === id)
        console.log('dept',dept)
        return dept?.institution_id === orgId
      }).length
    },

   // 获取授权所有审核用户
   async beganGetAllAuditUsersList () {
     const res = await getAllAuditUsersList()
     if (res.code === 0) {
       this.additUsersList = res.data
     } else {
       this.$message({ message: `${res.msg}`, type: 'error' })
     }
    },
    // 搜索授权列表
    searchAuthList () {
      const self = this
      if (self.allAuthList.length != 0) {
        self.authList = self.allAuthList.filter(item =>
         (item.office_name.toLowerCase().includes(this.searchData.name))
           && (this.searchData.office_id == '' || item.office_ids.indexOf(this.searchData.office_id) != -1)
           && (item.user_name.toLowerCase().includes(this.searchData.user_name) )
         )
      }
    },
    // 获取授权列表 非编辑下
    async beganGetExportAuthList () {
      const res = await getExportAuthList()
      if (res.code === 0) {
       this.authList = res.data
       this.allAuthList = res.data
      } else {
       this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 添加审批人
    showAddCheckUserAlert (row,index) {
      const self = this
      self.curEditIndex = index
      self.showCaseCheckChoosePeopleAlert = true
      self.$nextTick(() => {
        if (row.users.length !=0 ) {
          const users =  row.users.filter((item) => {
            if (row.user_ids.indexOf(item.id) != -1) {
              return item
            }
          })
          self.$refs.caseCheckPeopleChoose.checkeduser = users
        }
        self.$refs.caseCheckPeopleChoose.initData()
      })
    },
    // 确定添加审批人
    sureAddCheckPeople () {
      const self = this
      if (self.configList.length != 0) {
        self.configList.forEach((item,i) => {
          if ( i == self.curEditIndex) {
            // 重新赋值 对应那条配置的  审批人
            let choosePeopleIds = []
            if(self.$refs.caseCheckPeopleChoose.checkeduser.length != 0) {
              self.$refs.caseCheckPeopleChoose.checkeduser.forEach((item) => {
                choosePeopleIds.push(item.id)
              })
            }
            self.$set(item,'user_ids',choosePeopleIds)
            self.$set(item,'users',self.$refs.caseCheckPeopleChoose.checkeduser)
            self.showCaseCheckChoosePeopleAlert = false
          }
        })
      }
      
    },
    async initData () {
      // 获取机构
      await this.getInstitutionListLiteFn()
      // 获取所有科室
      await this.beganGetAllAuthOfficeList()
      // 获取权限列表
      this.beganGetExportAuthList()
      // 获取限制  导出检查数
      this.beganGetImportImgCount()
    }
  },
  created () {
    this.initData()
  },
}
</script>
<style lang="less" scoped>
.crumbsCon {
  display: flex;
}
.importTip{
  display: flex;
  height: 40px;
  align-items: center;
  padding-left:10px;
  .headIcon{
    width: 3px;
    height: 16px;
    background: #0A70B0;
    border-radius: 3px;
    margin-right: 5px;
  }
  .importTipTit{
    font-weight: 700;
    font-size: 15px;
    color: #333333;
    margin-right: 5px;
  }
  .importTipText{
    font-size: 14px;
    color: #EF8900;  
  }
}
.pl0 {
  padding-left:0px!important;
}
.downloadNumSet {
  ::v-deep .el-input.is-disabled .el-input__inner{
    color:#303133;
  }
}
.queryCon{
  display: flex;
  align-items: center;
  .search-bar-label{
    font-size: 14px;
    color: #333333;   
  }
}
.userListoperate-btn {
  display: inline-block;
  width:80px;
  height: 32px;
  text-align: center;
  line-height: 32px;
  cursor: pointer;
  border-radius: 3px;
}
.caseExportCon{
  height:100%;
}
.caseExportContainer{
  height: calc(100% - 46px);
  .caseExportContent{
    padding: 10px;
    height: calc(100% - 72px);
    ::v-deep .allInspect{
     height: 100%;
     .el-table .cell{
       padding-left: 5px!important;
       padding-right: 5px!important;  
     }
     .el-table__body-wrapper{
        height: calc(100% - 40px)!important;
        overflow-y: auto;
      }
      .radioBox{
       .el-radio__inner{
        width:16px;
        height: 16px;
       }
       .el-radio__inner::after{
         width:6px!important;
         height: 6px!important;
       }
      }
   }
   .tableCon{
     height: calc(100% - 228px);
   }
 }
 .updatePermissionCon{
   height: calc(100% - 300px);
   .importTip{
     padding-left:0px;
   }
   .downloadNumSet{
     .downloadLabel{
       font-size:14px;
       color: #303133;
     }
     .width_180_input{
       width:180px;
     }
   }
 }
}
.blockPage {
  border: 1px solid #eee;
  border-top: none;
}
.pt70{
  padding-bottom: 70px;
}
.select_up {
  position: absolute;
  background: #fff;
  width: calc(100% - 20px);
  bottom: 0;
}
.needCheck{
  font-size:14px;
  color:#EF8900;
}
.noNeedCheck{
  font-size:14px;
  color:#C0C4CC; 
}
::v-deep .addAddress {
  width: 32px;
  height: 32px;
  line-height: 32px;
  text-align: center;
  border: 1px solid #dcdfe6;
  border-radius: 2px;
  color: #0a70b0;
  cursor: pointer;

  &:hover {
    border-color: #0a70b0;
    background: #0a70b0;
    color: #fff;
  }
}
</style>