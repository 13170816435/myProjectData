<template>
    <div class="dataStatistics">

        <div class="title-bar flex_row cardHeader">
            <div class="tl col">
                <span class="title-name clr_303">
                    <i class="iconfont icondingwei mr10"></i>数据管理
                    <i class="iconfont iconzhankaishouqi"></i> 存储统计
                </span>
            </div>
        </div>
        <div class="container" :class="{ 'cardContainer': cardStyle }">
            <el-tabs v-model="activeName" @tab-click="handleClick">
                <el-tab-pane label="存储容量" name="second">
                    <storageMemoryVue :shouldRefresh="shouldRefresh"></storageMemoryVue>
                </el-tab-pane>
                <el-tab-pane label="机构用量" name="third" v-if="AllOrgDosage.org_count != 1">
                    <institutionDosageVue></institutionDosageVue>
                </el-tab-pane>
                <el-tab-pane label="数据范围" name="first">
                    <dataRangeVue></dataRangeVue>
                </el-tab-pane>
            </el-tabs>

        </div>
    </div>
</template>

<script>
import dataRangeVue from './dataRange.vue';
import institutionDosageVue from './institutionDosage.vue';
import storageMemoryVue from './storageMemory.vue';
import { getAllInstitutionDosage } from '@/api/memorySharing/dataMemory'
import { mapGetters } from 'vuex'

export default {
    components: {
        dataRangeVue,
        institutionDosageVue,
        storageMemoryVue,
    },
    data() {
        return {
            shouldRefresh: false,
            activeName: 'first',
            AllOrgDosage: { org_count: 0, },
        };
    },
    computed: {
        ...mapGetters(['cardStyle']),
    },
    watch: {},
    methods: {
        handleClick(tab, event) {
            if (tab.name === 'second') this.shouldRefresh = true

        },
        // 获取机构总数
        async getAllInstitutionDosage() {
            let res = await getAllInstitutionDosage({ org_codes: this.institutionList })
            if (res.code == 0) {
                this.AllOrgDosage = res.data
            }
        },
    },
    mounted() {
        this.getAllInstitutionDosage()
    },
}
</script>
<style lang='less' scoped>
.dataStatistics {
    width: 100%;
    height: 100%;
    overflow: hidden !important;
    background-color: #EBEEF5;

    .cardContainer {
        margin: 10px !important;
        border-radius: 5px !important;
        height: calc(100% - 47px - 20px) !important;

    }

    .container {
        padding: 10px 15px;
        background: #fff;
        height: calc(100% - 47px);
        // position: relative;
    }

}

.cardHeader {
    background-color: white;
}
</style>