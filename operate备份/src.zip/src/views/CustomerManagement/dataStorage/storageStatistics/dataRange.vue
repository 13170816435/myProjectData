<template>
    <div class="classRange pb10 pt10" :class="{ cardClassRange: cardStyle }">
        <el-tabs v-model="currentDomainId" type="card" @tab-click="handleTabClick">
            <el-tab-pane v-for="(item, index) in DomainsArr" :key="index" :label="item.domain_name" :name="item.id">
            </el-tab-pane>
        </el-tabs>
        <div class="contentC">
            <div class="domain_content" v-loading="requestDomainLoading">
                <div class="des_top">
                    <div class="des_line bg_0a"></div>
                    <div class="des_title ml5 clr_303">存储域整体数据范围</div>
                </div>

                <div v-if="domainDataList.length == 0 && !requestDomainLoading" class="noDataContent">
                    <div class="noDataImg"></div>
                    <span> 暂无数据 </span>
                </div>
                <dataRangeLine v-else class="mt10 data_line" :dataList="domainDataList"></dataRangeLine>
                <!--  -->
            </div>
            <div class="system_content" v-loading="requestSystemLoading">
                <div class="des_top">
                    <div class="des_line bg_0a"></div>
                    <div class="des_title ml5 clr_303">系统整体数据范围</div>
                </div>
                <div v-if="systemList.length == 0 && !requestSystemLoading" class="noDataContent">
                    <div class="noDataImg"></div>
                    <span> 暂无数据 </span>
                </div>
                <div class="all_system" v-else>
                    <div class="one_system" v-for=" item in systemList">
                        <div class="one_system_head">{{ item.name }}</div>
                        <div v-if="item && item.list && item.length == 0" class="noDataContent">
                            <div class="noDataImg"></div>
                            <span> 暂无数据 </span>
                        </div>
                        <dataRangeLine v-else class="data_line" :dataList="item.list || []"></dataRangeLine>
                    </div>

                </div>
                <!-- -->

            </div>

        </div>
    </div>
</template>

<script>
import dataRangeLine from './components/dataRangeLine.vue';
import {
    getAllDomains,
    getStatisticDataRange,

} from '@/api/memorySharing/dataMemory'
import moment from 'moment';
import { mapGetters } from 'vuex';
export default {
    data() {
        return {
            DomainsArr: [],
            currentDomainId: '',
            systemList: [],
            domainDataList: [],
            requestDomainLoading: false,
            requestSystemLoading: false,

        };
    },
    components: {
        dataRangeLine,
    },
    computed: {
        ...mapGetters(['cardStyle']),

    },
    mounted() {
        this.getMyAllDomains()
    },
    watch: {},
    methods: {

        // 获取所有的存储域
        async getMyAllDomains() {
            const self = this
            const res = await getAllDomains({ returnDevice: true })
            if (res.code === 0) {
                self.DomainsArr = []
                if (res.data.length !== 0) {

                    self.getStatisticDataRange(res.data[0].id)
                    self.$nextTick(() => {
                        self.currentDomainId = res.data[0].id
                    })
                    self.DomainsArr = res.data
                } else {
                    self.requestOver = true
                }
            } else {
                self.$message({ message: `${res.msg}`, type: 'error' })
            }
        },

        handleTabClick({ name }) {
            this.getStatisticDataRange(name)
        },

        dealAbnormalListData(list) {


            return list.map(e => {

                let groups = e.abnormals.reduce((group, item) => {
                    const key = item.data_state
                    if (!group[key]) { group[key] = { list: [] } }
                    group[key].list.push(item)
                    return group

                }, {})
                let results = Object.values(groups).map(e => {
                    let item = e?.list[0]
                    e.list.sort((a, b) => {
                        return moment(a.last_date_title).valueOf() - moment(b.last_date_title).valueOf()
                    })
                    return { data_state: item.data_state, list: e.list }
                })
                e.abnormals = results;
                return e

            })
        },
        // dealDomainData(list) {
        //     if (list.length > 2) {
        //         let waitSortArr = list.map(e => {
        //             return { ...e, date_value: Number(e.first_date_title.replace('-', '')) }
        //         })
        //         let descArr = waitSortArr.sort((a, b) => {
        //             return b.date_value - a.date_value
        //         })
        //         let results = this.dealSameState(0, descArr)
        //         console.log('处理好的数据', results);
        //         this.domainDataList = results
        //     } else {
        //         this.domainDataList = list
        //     }

        // },

        //默认最近的以近线数据
        dealSameState(state = 0, descArr, results = []) {
            // debugger
            let waitSortArr = descArr.map(e => {
                return { ...e, date_value: Number(e.first_date_title.replace('-', '')) }
            })
            if (descArr.filter(e => { e.data_state == state }).length == descArr.length) {
                let item = descArr[0]
                item.last_date_title = descArr[descArr.length - 1].first_date_title
                results.push(item)
                return results
            }

            let ascArr = waitSortArr.sort((a, b) => {
                return a.date_value - b.date_value
            })

            let firstIndex = descArr.findIndex(e => e.data_state == state)
            let lastIndex = ascArr.findIndex(e => e.data_state == state)
            // debugger
            if (firstIndex > -1) {
                let item = descArr[firstIndex]

                if (lastIndex > -1) {
                    let index = descArr.length - lastIndex - 1
                    let arr1 = descArr.splice(0, index + 1)
                    // debugger
                    results.push(this.getOneDataItem(state, arr1))

                    if (lastIndex == 0) {
                        return results
                    } else {
                        if (state == 2) return results
                        return this.dealSameState(state + 1, descArr, results)
                    }
                    //都存在
                } else {
                    //只有一个对应状态
                    if (firstIndex != 0) {
                        let arr1 = descArr.splice(0, firstIndex + 1)
                        results.push(this.getOneDataItem(state, arr1))
                        if (descArr.length > 0) {
                            if (state == 2) return results

                            return this.dealSameState(state + 1, descArr, results)
                        } else {
                            return results
                        }

                    } else {
                        // debugger
                        let item = descArr[0]
                        item.last_date_title = descArr[descArr.length - 1].first_date_title
                        results.push(item)
                        return results
                    }
                }
            } else {
                //没有数据？？
                if (state == 2) return results
                return this.dealSameState(state + 1, descArr, results)

            }

        },
        getAbnormalOneItem(state, list, results = []) {

            let abnormalArr = list.filter(e => e.data_state != state)
            // debugger
            if (abnormalArr.length == 0) return results
            if (abnormalArr.length < 2) {
                results.push({ ...abnormalArr[0], date_range: abnormalArr[0].first_date_title })
                return results
            }

            let firstAbIndex = list.findIndex(e => e.data_state != state)
            let abnormalFirstItem = {}
            if (firstAbIndex > -1) {
                abnormalFirstItem = list[firstAbIndex]
                // debugger
                let arr = list.splice(0, firstAbIndex + 1)
                // debugger
                let otherAbItemIndex = list.findIndex(e => e.data_state != abnormalFirstItem.data_state)

                if (otherAbItemIndex > -1) {
                    abnormalFirstItem.date_range = abnormalFirstItem.first_date_title
                    if (otherAbItemIndex != 0) {
                        let abnormalLastItem = list[otherAbItemIndex - 1]
                        abnormalFirstItem.date_range = abnormalLastItem.first_date_title + "~" + abnormalFirstItem.first_date_title
                    }
                    results.push(abnormalFirstItem)
                    // debugger
                    if (list[otherAbItemIndex].data_state == state) {
                        list.splice(0, otherAbItemIndex + 1)
                    } else {
                        list.splice(0, otherAbItemIndex)
                    }
                    if (list.length == 0) {
                        return results
                    } else {
                        return this.getAbnormalOneItem(state, list, results)

                    }


                } else {

                    let abnormalLastItem = list[list.length - 1]
                    abnormalFirstItem.date_range = abnormalLastItem.first_date_title + "~" + abnormalFirstItem.first_date_title
                    results.push(abnormalFirstItem)
                }
            } else {

            }


            return results
        },
        getOneDataItem(state, list) {

            let item = list.find(e => e.data_state == state) || list[0]
            item.last_date_title = list[list.length - 1].first_date_title

            item.first_date_title = list[0].first_date_title
            item.abnormal_list = []
            let abnormalArr = list.filter(e => e.data_state != item.data_state)
            if (abnormalArr.length == 0) return item
            item.abnormal_list = this.getAbnormalOneItem(state, list)

            return item
        },
        // dealAllSystemData(list) {
        //     // data_list
        //     // return






        //     this.systemList = list.map(systemItem => {
        //         if (systemItem.list.length > 2) {
        //             let waitSortArr = systemItem.list.map(e => {
        //                 return { ...e, date_value: Number(e.first_date_title.replace('-', '')) }
        //             })
        //             let descArr = waitSortArr.sort((a, b) => {
        //                 return b.date_value - a.date_value
        //             })
        //             let results = this.dealSameState(0, descArr)
        //             return { ...systemItem, list: results }

        //         } else {
        //             return { ...systemItem, list: systemItem.list }
        //         }

        //     })

        //     // console.log('系统有数据哦',this.systemList);



        // },
        // dealSystemList
        //获取对应存储域下数据范围
        async getStatisticDataRange(id) {
            this.systemList = []
            this.domainList = []
            this.domainDataList = []
            this.requestDomainLoading = true
            this.requestSystemLoading = true

            getStatisticDataRange({ domainId: id }).then(res => {
                if (res.code === 0) {
                    let domainList = res.data.filter(e => e.type == 0)//type==0为存储域
                    let allSystemList = res.data.filter(e => e.type != 0)//type!=0为系统
                    if (allSystemList.length > 0) {


                        let groups = allSystemList.reduce((group, item) => {
                            const key = item.system_id
                            if (!group[key]) { group[key] = { list: [], name: item.system_name } }
                            group[key].list.push(item)
                            return group
                        }, {})

                        let systems = Object.values(groups)
                        systems.map(e => {
                            e.list = this.dealAbnormalListData(e.list)
                            return e
                        })
                        this.systemList = systems
                        this.requestSystemLoading = false

                        // this.dealAllSystemData(Object.values(groups))
                    }else{
                        this.requestSystemLoading = false
                    }

                    this.domainDataList = this.dealAbnormalListData(domainList)
                    this.requestDomainLoading = false

                } else {
                    this.$message({ message: `${res.msg}`, type: 'error' })
                    this.requestDomainLoading = false
                    this.requestSystemLoading = false


                }
            }).catch(err => {
                this.requestDomainLoading = false
                this.requestSystemLoading = false

            })


        },
    },
}
</script>
<style lang='less' scoped>
.icon.iconTrans {
    display: inline-block;
    animation: move 1.5s linear infinite;
    -webkit-animation: move 1.5s linear infinite;
    font-size: 20px !important;
}

@keyframes move {
    100% {
        transform: rotate(360deg);
    }
}

.noDataContent {
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    .noDataImg {
        width: 120px;
        height: 80px;
        background-image: url('../../../../assets/images/dataStorage/noData.png');
        background-size: cover;
    }

    span {
        padding: 20px;
        font-size: 14px;
    }

}


.classRange {
    height: calc(100vh - 180px);
}

.cardClassRange {
    height: calc(100vh - 200px);
}

.contentC {
    height: calc(100% - 50px);
    // background-color: red;
}

.des_top {
    height: 30px;
    border-bottom: 1px dashed #DCDFE6;
    display: flex;
    align-items: center;
}

.des_line {
    width: 4px;
    height: 14px;
}

.des_title {
    font-size: 14px;
}

.data_line {
    background: #F5F7FA;

    height: 110px;
    padding: 40px 20px 20px 20px;
}

.domain_content {
    height: 160px;
    // background-color: blue;
}

.system_content {
    padding: 10px;
    height: calc(100% - 190px);
}

.all_system {
    margin-top: 10px;
    width: 100%;
    height: 100%;
    // height: 300px;
    float: left;
    display: grid;
    padding: 0 15px;
    grid-template-columns: repeat(auto-fill, minmax(45%, 1fr));
    // max-height: 50%;
    overflow-y: auto;

    .one_system {
        // width:270px;
        width: calc(100% - 15px);
        height: 150px;
        margin: 0 15px 12px 0;
        float: left;
        cursor: pointer;
        border-radius: 4px;
        position: relative;

        .one_system_head {
            height: 40px;
            line-height: 40px;
            font-size: 15px;
            color: #303133;

            font-weight: bold;
        }

        .deviceContent {
            padding: 0 15px;
        }

        .usedTit {
            margin-top: 8px;
            float: left;
            width: 100%;

            span {
                font-size: 14px;
                color: #909399;
                line-height: 20px;
            }
        }

        .usedNum {
            float: left;
            width: 100%;

            span {
                line-height: 30px;
                font-size: 20px;
                color: #303133;
                font-family: Arial;
                font-weight: bold;
            }

            .noFontWeight {
                font-weight: initial;
            }
        }

        ::v-deep .el-progress-bar__innerText {
            position: relative;
            top: -2px;
        }

        .operateBtn {
            position: absolute;
            right: 8px;
            top: 6px;
            display: none;

            .editDomainIcon {
                float: right;

                i {
                    font-size: 16px !important;
                    background: #0a70b0;
                    border-radius: 3px;
                    color: #fff !important;
                    display: block;
                    width: 28px;
                    height: 28px;
                    line-height: 28px;
                    text-align: center;
                }
            }

            .delDomainIcon {
                float: right;

                i {
                    font-size: 16px !important;
                    background: #da4a4a;
                    border-radius: 3px;
                    color: #fff !important;
                    display: block;
                    width: 28px;
                    height: 28px;
                    line-height: 28px;
                    text-align: center;
                }
            }
        }
    }

}
</style>
