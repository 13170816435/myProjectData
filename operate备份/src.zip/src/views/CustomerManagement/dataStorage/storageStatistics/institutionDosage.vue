<template>
  <div class="institutionDosage" :class="{ cardInstitutionDosage: cardStyle }">
    <div class="conditionContainer">
      <div class="form-row">

        <div class="item-cell item-cell-jigou">
          <div class="item-cell-icon item-cell-jigou-icon">
          </div>
          <div class="item-cell-content">
            <div class="item-cell-label">医疗机构(家)</div>
            <div class="item-cell-text mt5">{{ AllOrgDosage.org_count }}</div>
          </div>
        </div>
        <div class="item-cell item-cell-online">
          <div class="item-cell-icon item-cell-total-icon">
          </div>
          <div class="item-cell-content">
            <div class="item-cell-label">总容量(TB)</div>
            <div class="item-cell-text">{{ AllOrgDosage.used_size }}</div>
          </div>
        </div>
        <div class="item-cell item-cell-online">
          <div class="item-cell-icon item-cell-online-icon">
          </div>
          <div class="item-cell-content">
            <div class="item-cell-label">在线容量(TB)</div>
            <div class="item-cell-text">{{ AllOrgDosage.online_used_size }}</div>
          </div>
        </div>
        <div class="item-cell item-cell-offline">
          <div class="item-cell-icon item-cell-offline-icon">
          </div>
          <div class="item-cell-content">
            <div class="item-cell-label">近线容量(TB)</div>
            <div class="item-cell-text">{{ AllOrgDosage.nearline_used_size }}</div>
          </div>
        </div>
      </div>
      <el-form :inline="true" class="demo-form-inline" label-width="65px" label-position="right">

        <el-form-item label="机构名称：" label-width="90px">
          <el-input class="" v-on:keyup.enter.native=searchCondation v-model="searchData.name"
            placeholder="请输入机构" clearable></el-input>

          <!-- <el-select :disabled="institutionList.length === 0" size="small" v-model="listQuery.institutionId"
            placeholder="请选择" clearable style="width:200px">
            <el-option v-for="item in institutionList" :key="item.id" :label="item.name" :value="item.id"></el-option>
          </el-select> -->
        </el-form-item>
        <el-form-item label="地区：">
          <el-cascader ref="cascaderAddr" :style="{ width: '300px' }" v-model="cityParmas.cityValue"
            :options="cityParmas.cityJson" :key="1" @change="getCityCodeFn" @active-item-change="childrenCity" clearable>
          </el-cascader>
        </el-form-item>
        <el-form-item class="ml10 includePlainButton">
          <el-button type="primary" size="small" @click="searchCondation">查询</el-button>
          <el-button type="primary" plain size="small" @click="resetCondation">重置</el-button>
        </el-form-item>

      </el-form>
    </div>
    <div class="deviceTableList clear" :class="tableClass">
      <el-table :data="tableData" border stripe :header-cell-style="{ background: '#F2F2F2', color: '#333' }"
        highlight-current-row header-row-class-name="strong" v-loading="loading" element-loading-text="拼命加载中"
        element-loading-background="rgba(255,255,255,0.6)">
        <el-table-column type="index" label="序号" width="50">
          <template slot-scope="scope">
            <span>{{ orderNum + scope.$index + 1 }}</span>
          </template>
        </el-table-column>



        <el-table-column v-for="(item,index) in propData" :key="index" :label="item.label" :width="item.width" :prop="item.prop">
          <template slot-scope="scope">
            <span>{{ scope.row[item.prop] }}</span>
          </template>
        </el-table-column>
        <!-- <common-table :propData="propData" /> -->


      </el-table>
      <div class="pageDiv">
        <pagination-tool :total="totalPage" :page.sync="listQuery.page_index" :limit.sync="listQuery.page_size"
          @pagination="getInstitutionDosageList" />
      </div>
    </div>

  </div>
</template>

<script>

import CommonTable from '../components/CommonTable.vue'
import { getInstitution } from '@/api/platform_costomer/institution'
import { getSystemsList } from '@/api/user'
import PaginationTool from '@/components/common/PaginationTool' // 分页
import { getInstitutionDosageList, getAllInstitutionDosage } from '@/api/memorySharing/dataMemory'
import { mapGetters } from 'vuex'
import { getCityJson } from '@/api/commonHttp'

export default {
  components: { CommonTable, PaginationTool },
  data() {
    return {
      AllOrgDosage: {},
      cityParmas: {
        cityValue: [],
        cityJson: [],
        city_parmas: {
          parent_code: '1',
          level: 1
        }
      },
      searchData: {
        name: "",
        offset: 1,
        limit: 300,
        province_code: "",
        city_code: "",
        district_code: "",
      },
      listQuery: {
        page_index: 0,
        page_size: 10,
        org_codes: [],

      },
      institutionName: '',
      loading: false,
      totalPage: 0,
      tableData: [],
      areaList: [],
      institutionList: [],
      propData: [
        { prop: 'org_name', label: '机构名称', width: 180 },
        // { prop: 'org_region', label: '地区', width: 180 },
        { prop: 'domain_name', label: '存储域', width: 150 },
        { prop: 'used_size', label: '总容量（TB）',width:150 },
        { prop: 'online_used_size', label: '在线容量（TB）', },
        { prop: 'nearline_used_size', label: '近线容量（TB）', },

      ],
    };
  },
  computed: {

    ...mapGetters(['cardStyle']),

    orderNum() {
      if (this.listQuery.page_index === 0) {
        return 0
      } else {
        return (this.listQuery.page_index-1) * this.listQuery.page_size
      }
    },
    tableClass() {

      return this.tableData.length == 0 ? 'noTableData' : ''
    },
  },
  mounted() {
    this.getInstitutionList()

    this.getCityJsonFn(this.cityParmas.city_parmas)

  },
  watch: {},
  methods: {

    async getAllInstitutionDosage() {
      let res = await getAllInstitutionDosage({ org_codes: this.institutionList })
      if (res.code == 0) {
        this.AllOrgDosage = res.data
      }

    },
    async getInstitutionDosageList() {
      let res = await getInstitutionDosageList(this.listQuery)
      if (res.code == 0) {
        this.totalPage = res.page.total_count

        this.tableData = res.data || []
        this.tableData.forEach(e=>{
          console.log(e.used_size);
        })
      }
    },

    resetCondation() {
      this.cityParmas.cityValue = ''
      this.searchData = {
        name: "",
        offset: 1,
        limit: 300,
        province_code: "",
        city_code: "",
        district_code: "",
      }
      this.listQuery = {
        page_index: 0,
        page_size: 10,
        org_codes: [],
      }
      this.getInstitutionList()

    },
    searchCondation() {
      //先获取机构list
      this.getInstitutionList()

    },
    async getInstitutionList() {


      let res = await getInstitution(this.searchData)
      if (res.code == 0) {
        let arr = res.data.map(e => e.code)
        this.institutionList = [...new Set(arr)]
        this.listQuery.org_codes = this.institutionList
        this.getInstitutionDosageList()
        this.getAllInstitutionDosage()

      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }

    },
    // 获取城市json
    async getCityJsonFn(params) {
      const res = await getCityJson(params)
      var arr = []
      res.data.forEach(item => {
        var info = {
          label: '',
          value: ''
        }
        if (params.level < 3) {
          info.children = []
        }
        info.label = item.name
        info.value = item.code
        arr.push(info)
      })
      if (params.level === 1) {
        this.cityParmas.cityJson = arr
      } else if (params.level === 2) {
        this.cityParmas.cityJson.forEach(item => {
          if (item.value === params.parent_code) {
            item.children = arr
          }
        })
      } else if (params.level === 3) {
        this.cityParmas.cityJson.forEach(itemlevel => {
          itemlevel.children.forEach(item => {
            if (item.value === params.parent_code) {
              item.children = arr
            }
          })
        })
      }
    },
    async childrenCity(val) {
      val.forEach((item, i) => {
        this.cityParmas.city_parmas.parent_code = item
        this.cityParmas.city_parmas.level = i + 2
      })
      await this.getCityJsonFn(this.cityParmas.city_parmas)
    },
    getCityCodeFn(val) {
    
        this.searchData.province_code = ''
        this.searchData.city_code = ''
        this.searchData.district_code = ''

  
      var arr = this.getCascaderObj(val, this.cityParmas.cityJson)
      arr.forEach((item, i) => {
        if (i === 0) {
          // this.customerInfo.province_code = item.value
          // this.customerInfo.province = item.label
          this.searchData.province_code = item.value
        } else if (i === 1) {
          // this.customerInfo.city_code = item.value
          // this.customerInfo.city = item.label
          this.searchData.city_code = item.value

        } if (i === 2) {
          // this.customerInfo.district_code = item.value
          // this.customerInfo.district = item.label
          this.searchData.district_code = item.value

        }
      })
    },
    getCascaderObj(val, opt) {
      return val.map(function (value, index, array) {
        for (var itm of opt) {
          if (itm.value === value) { opt = itm.children; return itm }
        }
        return null
      })
    },
    // 回显城市联动
    async echoCityinfo(province, city, district) {
      var _provinceparmas = {
        parent_code: province,
        level: 1
      }
      var _cityparmas = {
        parent_code: city,
        level: 2
      }
      var _districtparmas = {
        parent_code: district,
        level: 3
      }
      var _provincejson = []
      var _cityjson = []
      var _districtjson = []
      // 一级
      const _provinceres = await getCityJson(_provinceparmas)
      _provinceres.data.forEach(item => {
        var info = {
          label: '',
          value: ''
        }
        info.children = []
        info.label = item.name
        info.value = item.code
        _provincejson.push(info)
      })
      this.cityParmas.cityJson = _provincejson
      // 二级
      const _cityres = await getCityJson(_cityparmas)
      _cityres.data.forEach(item => {
        var info = {
          label: '',
          value: ''
        }
        info.children = []
        info.label = item.name
        info.value = item.code
        _cityjson.push(info)
      })
      this.cityParmas.cityJson.forEach(item => {
        if (item.value === _provinceparmas.parent_code) {
          item.children = _cityjson
        }
      })
      // 三级
      const _districtres = await getCityJson(_districtparmas)
      _districtres.data.forEach(item => {
        var info = {
          label: '',
          value: ''
        }
        info.label = item.name
        info.value = item.code
        _districtjson.push(info)
      })
      this.cityParmas.cityJson.forEach(itemlevel => {
        itemlevel.children.forEach(item => {
          if (item.value === _cityparmas.parent_code) {
            item.children = _districtjson
          }
        })
      })
    },

  },
}
</script>
<style lang='less' scoped>
.institutionDosage {
  height: calc(100vh - 180px);
}

.cardInstitutionDosage {
  height: calc(100vh - 200px) !important;

}

.form-row {
  display: flex;
  margin-bottom: 8px;

  &:first-child {
    margin-bottom: 15px;
  }
}


.noTableData {
  background: none !important;
}

.item-cell {
  height: 70px;
  display: flex;
  align-items: center;
  margin-left: 15px;
  padding-right: 20px;
  border-radius: 3px;
  border: 1px dashed #DCDFE6;

  &-jigou {
    &-icon {
      background: url('../../../../assets/images/dataStorage/iconinstitution.png');
    }
  }

  &-total {
    &-icon {
      background: url('../../../../assets/images/dataStorage/icontotal.png');
    }
  }

  &-online {
    &-icon {
      background: url('../../../../assets/images/dataStorage/icononline.png');
    }
  }

  &-offline {
    &-icon {
      background: url('../../../../assets/images/dataStorage/iconoffline.png');
    }
  }

  &-icon {
    margin: 10px;
    width: 50px;
    height: 50px;
    background-size: contain;
  }

  &-content {
    margin: 10px;
  }

  &-label {
    font-weight: 400;
    font-size: 14px;
    color: #606266;
  }

  &-text {
    font-weight: bold;
    font-size: 20px;
    color: #303133;
  }
}


.conditionContainer {
  // background-color: blue;
}





.deviceTableList {
  position: relative;
  // border: 1px solid #ebeef5;
  height: calc(100% - 140px);
  border-bottom: none;
  background-color: red;

  //   height: 500px;
  ::v-deep .el-table {
    height: 100%;
  }

  ::v-deep.el-table--border {
    border: none;
  }

  ::v-deep .el-table__body-wrapper {
    height: calc(100% - 98px);
    overflow-y: auto;
  }
}

// .table-list {
//   position: relative;
//   border: 1px solid #ebeef5;
//   height: calc(100% - 100px);
//   ::v-deep.el-table--border {
//     border: none;
//   }
// }
.pageDiv {
  width: 100%;
  position: absolute;
  bottom: 0px;
  text-align: right;
  border-top: 1px solid #ebeef5;
  border-left: 1px solid #ebeef5;

}

.selectDiv::-ms-expand {
  display: none;
}

/* --火狐、谷歌清除--*/
.selectDiv {
  border: none;
  // appearance:none;
  // -moz-appearance:none;
  // -webkit-appearance:none;
}

.addDeviceCon {
  padding-top: 30px;
  padding-right: 30px;
  height: 370px;

  .oneDeviceInfo {
    height: 36px;
    line-height: 35px;
    margin-bottom: 20px;

    .oneDeviceInfoLabel {
      width: 120px;
      text-align: right;
    }

    .input_300 {
      width: 300px;
      height: 36px;
      line-height: 36px;
      border: none;
      border: 1px solid #DCDFE6;
      border-radius: 3px;
      padding-left: 8px;
    }

    .width_300_select {
      ::v-deep .el-input__inner {
        height: 36px;
        line-height: 36px;
      }

      ::v-deep .el-input__icon {
        line-height: 36px;
      }
    }

    /**必填的图标样式*/
    .iconbitian {
      color: #da4a4a;
      font-size: 10px;
    }
  }
}
</style>