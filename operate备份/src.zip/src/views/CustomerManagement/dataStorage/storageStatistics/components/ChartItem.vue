<template>
  <div class="chart-container" ref="chartContainer">

  </div>
</template>
<script>
import * as echarts from 'echarts'
export default {
  props: {
    option: {
      type: Object,
      require: true
    },
    shouldRefresh: {
      type: Boolean,
      require: true
    },

  },
  data() {
    return {
      charObj: null
    }
  },
  watch: {
    shouldRefresh: {
      handler() {
        
        if (this.shouldRefresh) {
          this.$nextTick(() => {
            this.chartResize()
          })
        }

      }
    },

    option: {
      handler() {
        // console.log('有没有更新哦', this.option);
        this.charObj = this.charObj || echarts.init(this.$refs.chartContainer)
        const option = this.option
        option && this.charObj.setOption(option, { notMerge: true })
        option && this.$nextTick(() => {
          this.chartResize()
        })



      }
    }
  },
  mounted() {
    if (this.option) {
      this.charObj = echarts.init(this.$refs.chartContainer)
      this.charObj.setOption(this.option, { notMerge: true })
      this.$nextTick(() => {
        this.chartResize()
      })
    }
    window.addEventListener('resize', this.chartResize);
  },
  destroyed() {
    window.removeEventListener('resize', this.chartResize);
  },
  methods: {
    chartResize() {
      if (this.charObj && this.option) {
        this.charObj.resize()
      }
    }
  }

}
</script>
<style lang="less" scoped>
.chart-container {
  width: 100%;
  height: 100%;
}
</style>