<template>
    <div class="data_content">

        <div class="data_timeline">
            <div class="data_timeline_item" v-for="(item, index) in dataList">
                <!-- {{ item.first_date_title }} -->
                <div class="data_circle " :class="lineClass(item)">
                    <div class="data_circle_title">{{ item.first_date_title }}</div>
                </div>
                <div class="data_group " :class="lineClass(item)">
                    <el-popover :ref="`pop${index}`" placement="bottom" width="300" trigger="hover">
                        <div class="abnormal_content">
                            <div v-for="abItem in item.abnormals">

                                    <div class="abnormal_content_title  mt10" :class="dataStateColor(abItem)">{{
                                    dataStateTitle(abItem) }}异常：</div>
                                <div v-for="nItem in abItem.list" class="abnormal_content_des"> {{  nItem && nItem.first_date_title }}~{{ nItem && nItem.last_date_title
                                }} 数据{{ (nItem && nItem.data_state == 0)? '仍' : '被' }}{{ dataStateTitle(nItem) }}</div>
                                


                            </div>
                        </div>
                    </el-popover>
                    <button class="data_abnormal" v-popover="`pop${index}`" v-if="item && item.abnormals && item.abnormals.length > 0"></button>
                    <div class="data_group_title" :class="dataStateColor(item, 1)">{{ stateTitle(item) }}</div>
                </div>
                <div class="data_circle " v-if="index == dataList.length - 1" :class="lineClass(item)">
                    <div class="data_circle_title">{{ item.last_date_title }}</div>
                </div>
            </div>

            <!-- <div class="data_timeline_item">
                <div class="data_circle bclr_fbc">
                    <div class="data_circle_title">2023/09/16</div>
                </div>
                <div class="data_group bclr_fbc">

                    <button class="data_abnormal" v-popover:nearlinePop></button>
                    <el-popover ref="nearlinePop" placement="bottom" width="300" trigger="hover">
                        <div class="abnormal_content">
                            <div>
                                <div class="abnormal_content_title clr_14c mt10">在线异常：</div>
                                <div class="abnormal_content_des"> 2023/09/19~2023/09/26 数据仍在线</div>
                            </div>
                            <div>
                                <div class="abnormal_content_title clr_ef8">离线异常：</div>
                                <div class="abnormal_content_des"> 2023/09/19~2023/09/26 数据被离线</div>
                            </div>

                        </div>
                    </el-popover>


                    <div class="data_group_title clr_fbc">近线数据</div>

                </div>
            </div>
            <div class="data_timeline_item">
                <div class="data_circle bclr_ef8">
                    <div class="data_circle_title">2023/09/16</div>

                </div>
                <div class="data_group bclr_ef8">
                    <button class="data_abnormal" v-popover:offlinePop></button>

                    <el-popover ref="offlinePop" placement="bottom" width="300" trigger="hover">
                        <div class="abnormal_content">
                            <div>
                                <div class="abnormal_content_title clr_14c mt10">在线异常：</div>
                                <div class="abnormal_content_des"> 2023/09/19~2023/09/26 数据仍在线</div>
                            </div>
                            <div>
                                <div class="abnormal_content_title clr_fbc">近线异常：</div>
                                <div class="abnormal_content_des"> 2023/09/19~2023/09/26 数据被近线</div>
                            </div>

                        </div>
                    </el-popover>
                    <div class="data_group_title clr_ef8">离线数据</div>

                </div>

            </div> -->
            <!-- <div class="right_arrow" :class="arrowClass"></div> -->
        </div>



    </div>
</template>

<script>

export default {
    data() {
        return {
            onlineVisible: false,
            // dataList: [
            //     {
            //         'data_state': 0,
            //         'first_date_title': '2019',
            //         'abnormals': [
            //             { 'data_state': 1, 'date_range': '2021~2022' },
            //             { 'data_state': 2, 'date_range': '2022~2023' }
            //         ],
            //     },
            //     {
            //         'data_state': 1,
            //         'first_date_title': '2022',
            //         'abnormals': [
            //             { 'data_state': 1, 'date_range': '2021~2022' },
            //             { 'data_state': 2, 'date_range': '2022~2023' }
            //         ],
            //     }, {
            //         'data_state': 2,
            //         'first_date_title': '2023',
            //         'abnormals': [
            //             { 'data_state': 1, 'date_range': '2021~2022' },
            //             { 'data_state': 2, 'date_range': '2022~2023' }
            //         ],
            //     }

            // ]

        };
    },
    props: {
        dataList: {
            type: Array,
            default: () => {
                return [
                    {
                        'data_state': 0,
                        'first_date_title': '2023',
                        'abnormals': [
                            { 'data_state': 1, 'date_range': '2021~2022' },
                            { 'data_state': 2, 'date_range': '2022~2023' }
                        ],
                    },

                    {
                        'data_state': 1,
                        'first_date_title': '2022',
                        'abnormals': [
                            { 'data_state': 1, 'date_range': '2021~2022' },
                            { 'data_state': 2, 'date_range': '2022~2023' }
                        ],
                    }, {
                        'data_state': 2,
                        'first_date_title': '2019',
                        'abnormals': [
                            { 'data_state': 1, 'date_range': '2021~2022' },
                            { 'data_state': 2, 'date_range': '2022~2023' }
                        ],
                    },

                ]
            },
        },
        contentPage: {
            type: Boolean,
            default: false,
        },
    },
    computed: {
        arrowClass() {
            if (this.dataList.length > 0) {
                let item = this.dataList[this.dataList.length - 1]
                if (item.data_state == 0) {
                    return 'right_arrow_clr_14c'
                } else if (item.data_state == 1) {
                    return 'right_arrow_clr_fbc'
                } else if (item.data_state == 2) {
                    return 'right_arrow_clr_ef8'
                }

            }
        }
    },
    watch: {},
    methods: {
        getCurrentAbnormalItem(key,item){
            
            // console.log('数据不对哦',item.abnormals[key]?.list);
            if(item.abnormals[key]?.list?.length > 0){
                let e =  item.abnormals[key].list[0]
                console.log('不会返回数据吗？',e);
                return e 
            }


        },
        dataStateTitle(item) {
            if (!item) return ''
            if (item.data_state == 0) {
                return '在线'
            } else if (item.data_state == 1) {
                return '近线'
            } else if (item.data_state == 2) {
                return '离线'
            }
            return ''
        },
        dataStateColor(item, index) {
            let className = this.contentPage ? 'bottom10' : 'bottom20'
            if (!item) return '' + className

            if (item.data_state == 0) {
                return 'clr_14c' + ' ' + className
            } else if (item.data_state == 1) {
                return 'clr_fbc' + ' ' + className
            } else if (item.data_state == 2) {
                return 'clr_ef8' + ' ' + className
            }
            return '' + className
        },
        lineClass(item) {
            if (!item) return ''
            // console.log('最后的数据',item.last_date_title);

            if (item.data_state == 0) {
                return 'bclr_14c'
            } else if (item.data_state == 1) {
                return 'bclr_fbc'
            } else if (item.data_state == 2) {
                return 'bclr_ef8'
            }
            return ''

        },
        stateTitle(item) {
            if (!item) return ''

            //在线数据
            if (item.data_state == 0) {
                return '在线数据'
            } else if (item.data_state == 1) {
                return '近线数据'
            } else if (item.data_state == 2) {
                return '离线数据'
            }
            return ''
        }

    },
}
</script>
<style lang='less' scoped>
.data_content_title {
    display: inline;
}

.data_content {
    width: 100%;
    height: 100%;
    // padding: 20px;
    border-radius: 4px;
}

.data_timeline {
    // width: calc(100% - 150px);
    // margin: 20px;
    // margin-right: 20px;
    // height: 100px;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    width: calc(100% - 13px);
    flex: 1;
    // background-color: red;

    &_item {
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
    }

    // &_item:nth-child(0) {
    //     width: 100%;
    // }
    // &_item:nth-child(1) {
    //     width: 100%;
    // }
    // &_item:nth-child(2) {
    //     width: 100%;
    // }

}


.right_arrow {
    border-left: 13px solid #EF8900;
    border-top: 13px solid transparent;
    border-bottom: 13px solid transparent;
    /* border-radius: 5px; */
    width: 0;
    height: 0;

    &_clr_14c {
        border-left: 13px solid #14C3C3;
    }

    &_clr_fbc {
        border-left: 13px solid #FBCD14;
    }

    &_clr_ef8 {
        border-left: 13px solid #EF8900;
    }

}

.data_circle_node_title {
    height: 30px;
}

.data_circle {
    width: 16px;
    height: 16px;
    border-radius: 16px;
    z-index: 60;
    margin-left: -5px;
    border: 3px solid white;
    position: relative;

}

.data_circle_title {
    position: absolute;
    top: 16px;
    right: -50px;
    width: 100px;
    text-align: center;

}

.data_des {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.data_group {
    width: calc(100% - 8px);
    // calc(33% - 16px);
    height: 10px;
    margin-left: -5px;
    z-index: 50;
    position: relative;

}

.data_group_title {
    position: absolute;
    left: 0px;
    right: 0px;
    text-align: center;

}

.bottom20 {
    bottom: 20px;
}

.bottom10 {
    bottom: 10px;
}

.clr_14c {
    color: #14C3C3;
}

.clr_fbc {
    color: #FBCD14;
}

.clr_ef8 {
    color: #EF8900;
}

.bclr_14c {
    background-color: #14C3C3;
}

.bclr_fbc {
    background-color: #FBCD14;
}

.bclr_ef8 {
    background-color: #EF8900;
}

.data_abnormal {
    background-color: red;
    height: inherit;
    width: 10%;
    left: 45%;
    position: absolute;
    border: none;
}

// .data_abnormal_button {
//     height: inherit;
//     background-color: #14C3C3;

// }

.abnormal_content {}

.abnormal_content_title {
    // color: red;
    font-weight: 500;
    font-size: 16px;
    letter-spacing: 0;
}

.abnormal_content_des {
    font-weight: 400;
    font-size: 14px;
    color: #303133;
    letter-spacing: 0;
    text-align: justify;
    line-height: 22px;
}</style>