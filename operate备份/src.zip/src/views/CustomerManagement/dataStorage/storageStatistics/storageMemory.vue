<template>
    <div class="saveMemory" :class="{ cardSaveMemory: cardStyle }">
        <el-tabs v-model="currentDomainId" type="card">
            <el-tab-pane v-for="(item, index) in DomainsArr" :key="index" :label="item.domain_name" :name="item.id">
            </el-tab-pane>
        </el-tabs>
        <div v-loading="currentDomainLoading" class="saveMemoryContent">
            <div v-if="!currentDomain && !currentDomainLoading" class="noDataContent">
                <div class="noDataImg"></div>
                <span> 暂无数据 </span>
            </div>
            <div v-else class="domainDetail of">

                <div class="domainDetail-left" v-loading="leftLoading">
                    <div class="domainDetail-left-detail mb10 pb10">
                        <span class="domainDetail-left-detail-title"> 存储域总体使用情况 </span>
                        <div class="line"></div>
                        <div class=" mt10 mb5 f12 clr_606">已使用/总容量</div>
                        <div class="f24 clr_1c"> {{ currentDomain && currentDomain.used_size }} <span class="f12">TB</span> / {{
        currentDomain.total_size }} <span class="f12">TB</span> </div>
                        <div class=" mt10 mb5 f12 clr_606">剩余容量</div>
                        <div class="f24 clr_ef89"> {{ currentDomain.remaining_size }} <span class="f12">TB</span> </div>
                        <div class=" mt10 mb5 f12 clr_606">预计可用</div>
                        <el-button @click="() => { expectedDays(currentDomain.id, 0) }" class="f24"
                            :class="getDaysColor(currentDomain.days_until_full)" style="text-decoration: underline;"
                            type="text">{{ getSpecificDateWithDays(currentDomain.days_until_full) }}
                            <!-- <span class="f12">天</span> -->
                        </el-button>
                        <div class="of top_line">
                            <div class="fl ">
                                <div class=" mt10 mb5 f12 clr_606">已使用(TB)</div>
                                <div class="f16 clr_333"> {{ currentDomain.used_size }}</div>
                            </div>

                            <div class="fr">
                                <div class=" mt10 mb5 f12 clr_606">总容量(TB)</div>
                                <div class="f16 clr_333"> {{ currentDomain.total_size }} </div>
                            </div>

                        </div>
                    </div>
                    <div v-if="!leftOptionsData" class="noDataContent">
                        <!-- <div class="line"></div> -->

                        <div class="noDataImg"></div>
                        <span> 暂无数据 </span>
                    </div>
                    <div v-else class="domainDetail-left-chart mt10">
                        <div class="line"></div>
                        <ChartItem :option="leftOptionsData" :shouldRefresh="shouldRefresh"></ChartItem>
                    </div>
                </div>
                <div class="domainDetail-middle"></div>
                <div class="domainDetail-right" >
                    <div v-if="currentDomain && currentDomain.system_usages && currentDomain.system_usages.length == 0" class="noDataContent">
                        <div class="noDataImg"></div>
                        <span> 暂无数据 </span>
                    </div>

                    <div v-else class="allCharts">
                        <div class="oneChart" v-for="(item, index) in currentDomain.system_usages" :key="index">
                            <div class="chartHead of row_space_between">

                                <el-tooltip placement="top" :disabled="tooltipShouldDisabled(item.system_name)">
                                    <div slot="content">{{ item.system_name }}</div>
                                    <div class=" clr_33 f14 system_name_content">{{ item.system_name }}</div>

                                </el-tooltip>

                                <div class=" clr_606 f12 " v-if="item && item.total_size > 0">预计可用<el-button size="small"
                                        @click="expectedDays(item, 1)" class="f24 "
                                        :class="getDaysColor(item.days_until_full)" style="text-decoration: underline;"
                                        type="text">{{
        getSpecificDateWithDays(item.days_until_full) }}
                                        <!-- <span class="f12">天</span> -->
                                    </el-button>
                                </div>
                            </div>
                            <div class="chartContent of">
                                <div class="fl ">
                                    <div class=" mt10 mb5 f12 clr_606">已使用(TB)</div>
                                    <div class="f16 clr_333"> {{ item.used_size }} </div>
                                </div>

                                <div class="fr mb10" style=" text-align: right;" v-if="item.total_size > 0">
                                    <div class=" mt10 mb5 f12 clr_606">分配总容量(TB)</div>
                                    <div class="f16 clr_333"> {{ item.total_size }} </div>
                                </div>
                                <el-progress v-if="item.total_size > 0" class="clear" :text-inside="true"
                                    :stroke-width="15" :percentage="getSystemUsedPercentage(item)"
                                    :color="processColorFn(getSystemUsedPercentage(item))"></el-progress>

                            </div>
                            <div v-if="!getShareChartObj(item)" class="noDataContent">
                                <!-- <div class="line"></div> -->

                                <div class="noDataImg"></div>
                                <span> 暂无数据 </span>
                            </div>
                            <div v-else class="chartItem">
                                <ChartItem :option="getShareChartObj(item)" :shouldRefresh="shouldRefresh">
                                </ChartItem>

                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
     <ForecastDays v-if="dayDialogData.show" :forecastDaysShow="dayDialogData.show" :dayDialogData="dayDialogData" @forecastDaysClose="forecastDaysClose"></ForecastDays>
   </div>
</template>

<script>
import {
    getAllDomains,
    getCurrentDomainUsages,
} from '@/api/memorySharing/dataMemory'
import ChartItem from './components/ChartItem.vue'
import ForecastDays from '../components/ForecastDays.vue';
import { mapGetters } from 'vuex'

export default {
    data() {
        return {
            dayDialogData: {
                domain_id: null,
                system_id: null,
                show: false
            },
            leftOptionsData: {},
            currentDomainId: '',
            DomainsArr: [],
            currentDomain: '',
            currentDomainLoading: false,
            allStrategyList: [],
            leftOptions: {
                textStyle: {
                    color: '#DCDFE6'
                },
                // height:'200px',  #DCDFE6
                tooltip: {
                    trigger: 'axis',
                    position: function (pos, params, dom, rect, size) {
                        // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                        var obj = { top: 40 };
                        obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                        return obj;
                    },
                    axisPointer: {
                        // Use axis to trigger tooltip
                        type: 'shadow' // 'shadow' as default; can also be 'line' or 'shadow'
                    },
                    formatter: (params) => {
                        //    console.log('数据不太对哦',params ，relVal);
                        var relVal = ''
                        // params[0].name;
                        for (let i = 0; i < params.length; i++) {
                            relVal = relVal + (i != 0 ? '<br/>' : '') + params[i].marker + params[i].seriesName + '  ' + params[i].value + ' ' + ('人次')
                        }
                        return relVal

                    }
                    // formatter:(val)=>{
                    //     console.log('这里是全部的吧？',val);
                    //     return val
                    // }
                },
                legend: {
                    itemWidth: 9,
                    itemHeight: 9,
                    orient: 'vertical',
                    left: 'left',
                    top: 50,
                    bottom: 0,
                    icon: 'circle',
                    align: 'left',
                    textStyle: {
                        width: 350, rich: {

                            a: { color: '#333333', width: 170, },
                            b: { color: '#333333', width: 90, },
                            c: { color: '#333333', },
                            x: { color: '#333333', width: 30, }
                        },
                    },


                },
                grid: {
                    left: '0%',
                    right: '0%',
                    backgroundColor: 'green',
                    height: 30,
                    width: 330,
                    top: '0%',
                },
                xAxis: {
                    type: 'value',
                    show: false,
                },
                yAxis: {
                    type: 'category',
                    show: false,

                },
                series: [
                    {
                        name: 'Direct',
                        type: 'bar',
                        stack: 'total',
                        barMaxWidth: 20,
                        // label: {
                        //     show: true
                        // },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [320,],
                        itemStyle: {
                            borderRadius: [5, 0, 0, 5],
                        },
                        backgroundStyle: {},
                        // showBackground: true,
                        // backgroundStyle:{

                        //   borderWidth:5,
                        //   borderColor:'#000',
                        //   borderRadius:10,
                        // }
                    },
                    {
                        name: 'Mail Ad',
                        type: 'bar',
                        stack: 'total',
                        // label: {
                        //     show: true
                        // },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [120,],
                        backgroundStyle: {},
                    },
                    {
                        name: 'Affiliate Ad',
                        type: 'bar',
                        stack: 'total',
                        // label: {
                        //     show: true
                        // },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [220,],
                        backgroundStyle: {},
                    },
                    {
                        name: 'Video Ad',
                        type: 'bar',
                        stack: 'total',
                        // label: {
                        //     show: true
                        // },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [150,],
                        backgroundStyle: {},
                    },
                    {
                        name: 'Search Engine',
                        type: 'bar',
                        stack: 'total',
                        // label: {
                        //     show: true
                        // },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [820,],
                        backgroundStyle: {},
                        itemStyle: {
                            borderRadius: [0, 5, 5, 0],
                        },
                    }
                ]
            },
            leftLoading: false,
            rightLoading: false,

        };
    },
    props: ['shouldRefresh'],
    computed: {
        ...mapGetters(['cardStyle']),

    },
    components: {
        ChartItem,
        ForecastDays
    },
    watch: {
        'currentDomainId': {
            handler(val) {
                if (val && val != 0) {

                    this.currentDomain = null
                    this.leftOptionsData = null
                    this.getCurrentDomainUsages(val)
                }

            },
        },
        'currentDomain': {
            handler(val) {
                if (val) {
                    this.leftOptionsData = null
                    this.leftLoading = true
                    this.$nextTick(() => {
                        this.leftOptionsData = this.getLeftOptionsData()
                        this.leftLoading = false

                    })

                }

            },
            deep: true,
        }

    },
    mounted() {
        this.getMyAllDomain()
    },

    methods: {
        getSpecificDateWithDays(day) {

            if (day == '∞') return ''
            // console.log('这是个啥类型的数据哦？',day,typeof(day));
            if (day < 30) {
                return day + '天'
            } else if (day < 365) {
                let month = Math.floor(day / 30);
                let days = Math.round((day / 30 - month) * 30)
                // if (days == 0) {
                return month + '月'
                // } else {
                //     return month + '月' + days 
                //     // + '天'
                // }
            } else {
                let year = Math.floor(day / 365);
                let month = Math.floor((day / 365 - year) * 365 / 30);
                let days = Math.round(((day / 365 - year) * 365 / 30 - month) * 30)

                if (year > 3) {
                    return '3年以上'
                } else {
                    if (month == 0 && days == 0) {
                        return year + '年'
                    } else {
                        return year + '年' + month + '月'
                    }
                }



            }
        },

        tooltipShouldDisabled(val) {
            if (!val) return true
            if (val.length > 11) {
                console.log('大于11', val);
                return false
            }
            return true
        },
        getDaysColor(days) {
            if (days < 30) {
                return 'clr_ff00'
            } else if (days < 365) {
                return 'clr_ef89'
            } else {
                return 'clr_1cb54a'
            }
        },
        getShareChartObj(item) {
            let colors = [
                "#1891FF",
                "#FBCD14",
                "#DCDFE6",
            ]
            let datas = [
                { name: '已使用在线容量', value: item.online_used_size },
                { name: '已使用近线容量', value: item.nearline_used_size },
            ]
            if (item.total_size > 0) {
                //保留小数点后三位就可以
                //item.total_size - item.used_size
                //toFixed会四舍五入
                let num = item.total_size - item.used_size

                let value = Number(num.toString().match(/^\d+(?:\.\d{0,3})?/))

                // (0.000600012).toFixed(3)
                datas.push({ name: '剩余容量', value, })

            }

            let options = {
                textStyle: {
                    color: '#DCDFE6'
                },
                "color": colors,
                // "tooltip": {
                //     "trigger": "item",
                // },
                legend: {
                    itemWidth: 9,
                    itemHeight: 9,
                    orient: "vertical",
                    left: "left",
                    top: "bottom",
                    icon: "circle",
                    // formatter: (name) => {
                    //     let target;
                    //     for (let i = 0; i < datas.length; i++) {
                    //         if (datas[i].name === name) {
                    //             target = datas[i].value + 'TB'
                    //         }
                    //     }
                    //     // if(name == '其他')return ''
                    //     console.log('数据是啥样子的哦----------', target);

                    //     // console.log('当前是哪一个？name',name);
                    //     return `{a|${name}}` + ' ' + `{b|${target}}`

                    // },
                    textStyle: {
                        width: 350, rich: {

                            a: { color: '#333333', width: 170, },
                            b: { color: '#333333', width: 90, },
                        },
                    },
                },
                tooltip: {
                    trigger: 'item',
                    position: function (pos, params, dom, rect, size) {
                        // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                        var obj = { top: 40 };
                        obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                        return obj;
                    },
                    axisPointer: {
                        // Use axis to trigger tooltip
                        type: 'shadow' // 'shadow' as default; can also be 'line' or 'shadow'
                    },
                    formatter: (params) => {

                        var relVal = ''
                        // params[0].name;
                        // for (let i = 0; i < params.length - 1; i++) {
                        // if(i < params.length - 1)
                        relVal = relVal + params.marker + params.name + '  ' + params.value + 'TB'
                        // }
                        return relVal

                    }
                },
                "series": [
                    {
                        "label": {
                            "position": "outside",
                            "formatter": (params) => {
                                if (params) {
                                    let name = params.data.value + 'TB' + '\n' + params.percent + '%'
                                    if (params.dataIndex == 0) {
                                        return `{a|${name}}`
                                    } else if (params.dataIndex == 1) {
                                        return `{b|${name}}`
                                    } else {
                                        return `{c|${name}}`
                                    }
                                }
                            },
                            rich: {
                                a: {
                                    fontSize: 14,
                                    color: colors[0]
                                },
                                b: {
                                    fontSize: 14,
                                    color: colors[1]
                                },
                                c: {
                                    fontSize: 14,
                                    color: colors[2]
                                }

                            }

                        },
                        "name": "",
                        "type": "pie",
                        left: '0%',
                        right: '0%',
                        top: '0%',
                        // width:300,
                        height: 200,
                        "radius": [
                            "30%",
                            "50%"
                        ],
                        "data": datas
                        ,
                        "emphasis": {
                            "itemStyle": {
                                "shadowBlur": 10,
                                "shadowOffsetX": 0,
                                "shadowColor": "rgba(0, 0, 0, 0.5)"
                            }
                        }
                    }
                ]
            }
            return options
        },
        getSystemUsedPercentage(item) {
            if (!item.total_size) return 0
            if (!item.used_size) return 0

            let num = item.used_size * 100 / item.total_size
            let percent = Number(num.toString().match(/^\d+(?:\.\d{0,4})?/))
            // lo
            return percent
        },
        getLeftOptionsData() {

            let colors = [
                "#14C3C3",
                "#FBCD14",
                "#F14664",
                "#223272",
                "#8544DF",
                "#3436C7",
                "#1891FF",
                "#2EC35A",
                "#FBCFBC",
                "#F34F34",
                "#FFF666",
                "#857857",
                "#343343",
                "#180FFF",
                "#2EC2EC",
            ]
            let options = this.leftOptions
            this.currentDomain.system_usages.forEach(item => {
                let usedRate = 0
                if (item.used_size === 0) {
                    usedRate = 0
                } else {
                    // var percentNum = (
                    //     item.used_size / this.currentDomain.total_size
                    // ).toFixed(4)
                    let num = item.used_size / this.currentDomain.total_size
                    let percent = Number(num.toString().match(/^\d+(?:\.\d{0,4})?/))
                    usedRate = this.floatMultiply(percent, 100)
                }
                item.usedRate = usedRate

            })
            colors = colors.filter((e, index) => index < this.currentDomain.system_usages.length)
            colors.push("#E4E7ED")
            // this.currentDomain.system_usages = this.currentDomain.system_usages.sort((a, b) => { return b.used_size - a.used_size })
            let lastItem = { name: '未使用', text: this.currentDomain.remaining_size, usedRate: 0 }
            let lastUsedRate = 0
            if (this.currentDomain.remaining_size === 0) {
                lastUsedRate = 0
            } else {
                // var percentNum = .toFixed(4)
                let num = this.currentDomain.remaining_size / this.currentDomain.total_size

                let percent = Number(num.toString().match(/^\d+(?:\.\d{0,4})?/))
                lastUsedRate = this.floatMultiply(percent, 100)
            }
            lastItem.usedRate = lastUsedRate

            let datas = this.currentDomain.system_usages.map(item => ({
                name: item.system_name,
                text: item.used_size,
                usedRate: item.usedRate,
                value: item.usedRate
            }))
            datas.push(lastItem)

            //统一长度
            datas.forEach(e => e.value = e.usedRate * 100 / this.currentDomain.total_size)

            options.tooltip.formatter = (params) => {

                var relVal = ''
                // params[0].name;
                for (let i = 0; i < params.length - 1; i++) {
                    // if(i < params.length - 1)
                    relVal = relVal + (i != 0 ? '<br/>' : '') + params[i].marker + params[i].seriesName + '  ' + datas[i].text + 'TB'
                }
                return relVal

            }

            options.legend.formatter = (name) => {
                let target, rate;
                for (let i = 0; i < datas.length; i++) {
                    if (datas[i].name === name) {
                        target = datas[i].text + 'TB'
                        rate = datas[i].usedRate
                    }
                }
                // if(name == '其他')return ''

                // console.log('当前是哪一个？name',name);
                return `{a|${name}}` + ' ' + `{b|${target}}` + ' ' + `{x|${rate}%}` + ' '

            }
            options.series = []
            datas.forEach((item, index) => {
                let value = item.value
                // if (value != 0) {
                //     let minValue = 0.6
                //     value = value < minValue ? minValue : item.usedRate
                // }

                let serieData = {
                    name: item.name,
                    type: 'bar',
                    stack: 'total',
                    // label: {
                    //     show: true
                    // },
                    emphasis: {
                        focus: 'series'
                    },
                    data: [value],
                }
                if (index == 0) {
                    //第一个
                    serieData.itemStyle = { borderRadius: [2, 0, 0, 2], }
                    if (index == datas.length - 1) {
                        //最后一个
                        serieData.itemStyle = { borderRadius: 2, }
                    }
                } else if (index == datas.length - 1) {
                    //最后一个
                    serieData.itemStyle = { borderRadius: [0, 2, 2, 0], }
                } else {
                    serieData.itemStyle = {}
                }
                serieData.backgroundStyle = { color: 'rgba(180, 180, 180, 0.2)' }

                options.series.push(serieData)
            })
            // this.shouldRefresh = true
            // debugger
            options.color = colors
            return options
        },


        processColorFn(val) {
            if (val < 50) {
                return '#1ab44a'
            } else if (val > 50 && val < 80) {
                return '#e6a23c'
            } else {
                return '#f56c6c'
            }
        },
        expectedDays(item, index) {
            // debugger
            this.dayDialogData.domain_id = this.currentDomain.domain_id
            this.dayDialogData.domain_name = this.currentDomain.domain_name

            if (index == 0) {
                //存储域的

                this.dayDialogData.system_id = null
                this.dayDialogData.system_name = null

            } else {
                //系统的
                this.dayDialogData.system_id = item.system_id
                this.dayDialogData.system_name = item.system_name
            }
            //0 总量
            this.$nextTick(() => {
                this.dayDialogData.show = true
            })

        },
        forecastDaysClose() {
            this.dayDialogData.show = false
        },
        getByteSize(val, unit) {
            const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
            const i = sizes.findIndex(item => item === unit)
            const k = 1024
            return val * Math.pow(1024, i)
        },
        bytesToSize(btyes) {
            if (btyes === 0) {
                return '0B'
            }
            const k = 1024
            const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
            let i = Math.floor(Math.log(btyes) / Math.log(k))
            if (i < 2) {
                i = 2
            }
            const num = btyes / Math.pow(k, i)
            const value = num.toFixed(3) / 1
            const unit = sizes[i]
            const text = `${value}${unit}`
            return {
                value,
                unit,
                text
            }
        },
        bytesToSizeForChart(btyes) {
            if (btyes === 0) {
                return '0B'
            }
            const k = 1024
            const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
            let i = Math.floor(Math.log(btyes) / Math.log(k))
            const num = btyes / Math.pow(k, i)
            const value = num.toFixed(3) / 1
            const unit = sizes[i]
            const text = `${value}${unit}`
            return {
                value,
                unit,
                text
            }
        },
        bytesToTB(btyes) {
            if (btyes === 0) {
                return 0
            }
            const k = 1024
            const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
            let i = Math.floor(Math.log(btyes) / Math.log(k))
            if (i < 3) {
                i = 3
            }
            let allLenght = Math.pow(k, i)
            const num = btyes / allLenght
            console.log('数据哦', num);
            const value = num.toFixed(3) / 1
            if (value == 0) return 0.05
            console.log('对应数据', value);
            return value

        },
        // 乘(处理 0.0039*100 不等于 0.39的精度丢失问题)
        floatMultiply(arg1, arg2, forChart = false) {
            if (arg1 == null || arg2 == null) {
                return null;
            }
            var n1, n2;
            var r1, r2; // 小数位数
            try {
                r1 = arg1.toString().split(".")[1].length;
            } catch (e) {
                r1 = 0;
            }
            try {
                r2 = arg2.toString().split(".")[1].length;
            } catch (e) {
                r2 = 0;
            }
            n1 = Number(arg1.toString().replace(".", ""));
            n2 = Number(arg2.toString().replace(".", ""));
            // console.log('比例为0', n1 * n2 / Math.pow(10, r1 + r2));
            let results = n1 * n2 / Math.pow(10, r1 + r2)
            if (forChart && results == 0) return 0.01
            return results;
        },
        // 获取所有的存储域
        async getMyAllDomain() {
            const self = this
            const res = await getAllDomains({ returnDevice: true })
            if (res.code === 0) {
                self.DomainsArr = []
                if (res.data.length !== 0) {
                    self.$nextTick(() => {
                        self.currentDomainId = res.data[0].id
                        self.DomainsArr = res.data
                    })
                } else {
                    self.allStrategyList = []
                    self.requestOver = true
                }
            } else {
                self.$message({ message: `${res.msg}`, type: 'error' })
            }
        },

        getCurrentDomainUsages(domain_id) {
            this.currentDomainLoading = true
            getCurrentDomainUsages({ domainId: domain_id }).then(res => {
                this.currentDomainLoading = false
                if (res.code === 0) {
                    this.$nextTick(() => {
                        if(res.data.domain_id != 0){
                            this.currentDomain = res.data
                        }
                    })
                } else {
                    this.currentDomain = null
                    this.$message({ message: `${res.msg}`, type: 'error' })
                }
            }).catch(err => {
                this.currentDomainLoading = false
                this.currentDomain = null
                this.$message({ message: `${err}`, type: 'error' })

            })

        },
        // 切换存储域
        // chooseStorage(index) {
        //     let domainObj = this.DomainsArr[index]
        //     this.currentDomain = domainObj


        // },


        // handleTabClick(tab, event) {
        //     // this.leftOptionsData = null
        //     this.chooseStorage(tab.index)
        // },

    },
}
</script>
<style lang='less' scoped>
.system_name_content {

    white-space: nowrap;
    /* 确保文本在一行内显示 */
    overflow: hidden;
    /* 隐藏超出容器的文本 */
    text-overflow: ellipsis;
    /* 使用省略号表示文本被截断 */
    max-width: 150px;
    /* 设置容器宽度 */

}

.clr_ef89 {
    color: #EF8900 !important;
}

.clr_1cb54a {
    color: #1CB54A !important;
}

.clr_ff00 {
    color: #FF0000 !important;
}

.topRadioGroup {

    width: 200%;
}

.saveMemory {
    width: 100%;
    height: calc(100vh - 180px);
    // ::v-deep .el-tabs__item.is-active {
    //     background-color: #0a70b0;
    //     color: white;
    // }

    .saveMemoryContent {
        height: 100%;
    }


}

.cardSaveMemory {

    height: calc(100vh - 200px) !important;

}

.noDataContent {
    min-width: 330px;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    // .line {
    //     height: 2px;
    //     width: 330px;
    //     // border-top: 5px dotted #000;
    //     border-top: 1px dashed #DCDFE6;
    //     background-color: white;
    //     border-radius: 0 0 5px 5px;
    // }

    .noDataImg {
        width: 120px;
        height: 80px;
        background-image: url('../../../../assets/images/dataStorage/noData.png');
        background-size: cover;
    }

    span {
        padding: 20px;
        font-size: 14px;
    }

}

.row_space_between {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.lh14 {
    line-height: 40px;
}

.domainDetail {
    display: flex;
    width: 100%;
    height: calc(100% - 60px);
    margin: 0px;
    // height: calc(100% - 250px);
    // background-color: yellow;
    // background: #EBEEF5;
    border: 1px solid #DCDFE6;
    border-radius: 5px;


    // .noDataContent {
    //     min-width: 330px;
    //     height: 300px;
    //     display: flex;
    //     flex-direction: column;
    //     justify-content: center;
    //     align-items: center;

    //     // .line {
    //     //     height: 2px;
    //     //     width: 330px;
    //     //     // border-top: 5px dotted #000;
    //     //     border-top: 1px dashed #DCDFE6;
    //     //     background-color: white;
    //     //     border-radius: 0 0 5px 5px;
    //     // }

    //     .noDataImg {
    //         width: 120px;
    //         height: 80px;
    //         background-image: url('../../../../assets/images/dataStorage/noData.png');
    //         background-size: cover;
    //     }

    //     span {
    //         padding: 20px;
    //         font-size: 14px;
    //     }

    // }

    &-middle {
        width: 5px;
        height: calc(100% - 20px);
        margin-top: 10px;
        background: #EBEEF5;

    }

    &-left {
        padding: 0 10px 0;
        height: 100%;
        // width: 300px;
        // height: 300px;
        // background-color: blue;
        background-color: white;
        border-radius: 5px 0 0 5px;

        ::v-deep .el-button--text,
        ::v-deep .el-button--text:hover {
            color: #EF8900;
        }

        &-detail {
            position: relative;

            &-title {

                line-height: 40px;
                font-family: PingFangSC-Medium;
                font-weight: 500;
                font-size: 14px;
                color: #333333;
            }


            .top_line {
                border-top: 1px dashed #DCDFE6;

            }

        }



        &-chart {
            width: 330px;
            height: 500px;
            // background-color: red;
            position: relative;


        }


    }

    &-right {
        margin-top: 10px;
        margin-left: 10px;
        width: calc(100% - 370px);
        overflow-y: auto;
        background-color: white;

        ::v-deep .el-button--text,
        ::v-deep .el-button--text:hover {
            color: #1C8BE4;
        }



        .allCharts {
            width: 100%;
            float: left;
            display: grid;
            padding: 0 15px;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            min-height: 50%;

            .oneChart {
                // width: 270px;
                width: calc(100% - 15px);
                // height: 126px;
                border: 1px solid rgba(10, 112, 176, 0.25);
                margin: 0 15px 12px 0;
                float: left;
                cursor: pointer;
                border-radius: 4px;
                position: relative;
                flex-shrink: 0;

                .chartHead {
                    height: 40px;
                    line-height: 40px;
                    font-size: 15px;
                    color: #303133;
                    // text-align: center;
                    border-bottom: 1px solid rgba(10, 112, 176, 0.25);
                    white-space: nowrap;
                    text-overflow: ellipsis;
                    overflow: hidden;
                    word-break: break-all;
                    font-weight: bold;
                    padding: 0 15px;
                    border-radius: 5px 5px 0px 0px;
                    background-color: #f5f5f5;

                    .el-button {
                        height: 34px;
                        padding: 0px;
                    }
                }

                .chartContent {
                    padding: 0px 15px 10px;

                    border-bottom: 1px dashed #DCDFE6;
                    background-color: white;

                }

                .chartItem {
                    height: 300px;
                    background-color: white;
                    border-radius: 0px 0px 5px 5px;

                }



                ::v-deep .el-progress-bar__innerText {
                    position: relative;
                    top: -1px;
                    // line-height: 15px;
                }

            }

        }



    }

    .line {
        position: absolute;
        top: 40px;
        left: 0px;
        right: 0px;
        height: 2px;
        width: 330px;
        // border-top: 5px dotted #000;
        border-top: 1px dashed #DCDFE6;
        background-color: white;
        border-radius: 0 0 5px 5px;

    }
}

.clr_1c {
    color: #1C8BE4;
}
</style>