<template>
    <div class="userlist">


        <div class="title-bar flex_row cardHeader">
            <div class="tl col">
                <span class="title-name clr_303">
                    <i class="iconfont icondingwei mr5"></i>数据管理
                    <i class="iconfont iconzhankaishouqi"></i> 存储策略
                </span>
            </div>
        </div>

        <div class="DeviceCon" :class="containerClass">
            <div class="allDevice mt10" v-show="DomainsStrategies.length !== 0">
                <div class="oneDevice chartCon" v-for="(item, index) in DomainsStrategies" :key="index"
                    @click="chooseStorage($event, index, item)"
                    v-bind:class="{ activeChart: currentDomainIndex === index }">
                    <div class="deviceHead activeDeviceHead" v-bind:title="item.domain_name">
                        {{ item.domain_name }}
                    </div>
                    <div class="deviceContent activeDeviceContent">
                        <div>策略方式：{{ item.strategy_type === 0 ? '整体' : '单独' }}配置</div>
                    </div>
                </div>
            </div>
            <div class="listTit clear" v-show="DomainsStrategies.length !== 0">
                <span class="listTitIcon fl"></span><span class="fl loadDeviceTit">{{ currentDomain.domain_name }}<span
                        v-if="!currentStrategyWay">下各系统的策略列表</span> </span>
                <el-radio-group v-model="tabPosition"  class='fl  ml10 mt10' size='small' v-if="!currentStrategyWay">
                    <el-radio-button label="other" > 业务系统({{ otherSystemStrategyList.length ? otherSystemStrategyList.length : 0}}) </el-radio-button>
                    <el-radio-button label="share">存储共享系统({{ shareSystemStrategyList.length?shareSystemStrategyList.length:0 }})</el-radio-button>

                </el-radio-group>
                <span v-show="!currentStrategyWay" @click="StrategyConfiguration" class="function-btn clr_0a  fr">
                    <!-- <i class="iconfont iconzongheshezhi mr5"></i> -->
                    批量配置
                </span>
                <!-- <span @click="StrategyStyle" class="function-btn clr_0a  fr mr15">
                    策略方式
                </span> -->
            </div>
            <div  v-if="!currentDomain.storage_strategies" class="noDataContent">
                <div class="noDataImg"></div>
                <span> 暂无授权业务系统 </span>
            </div>
            <div v-else>
                <div v-if="currentStrategyWay">
                <!-- <div class="no-strategy"
                        v-if="!currentStrategyData.nearline_enable && !currentStrategyData.offline_enable">
                        暂未配置存储策略
                    </div> -->
                <div class="strategyContent">
                    <div class="fl">
                        <div class="lh40 f14 clr_303">近线策略
                            <span class="icon-span-green" v-if="currentStrategyData.nearline_enable">已启用</span>
                            <span class="icon-span-red" v-else>未启用</span>
                        </div>
                        <div class="strategyContent-title">
                            <div class="lh40 f14 clr_303" v-if="currentStrategyData.nearline_mode === 0">近线指定天数前的文件：
                                <span class="f20 clr_0a">{{ currentStrategyData.nearline_of_days }} 天</span>
                            </div>
                            <div class="lh40 f14 clr_303" v-else-if="currentStrategyData.nearline_mode === 1">
                                近线文件到指定在线容量：
                                <span class="f20 clr_0a">{{ currentStrategyData.nearline_of_space_ratio }} %</span>
                            </div>

                            <div class="lh40 f14 clr_303">执行时间： <span class="f20 clr_0a">{{
            nearlineTimeRange }}</span> </div>
                        </div>
                    </div>
                    <div class="fl ml20">
                        <div class="lh40 f14 clr_303">离线策略
                            <span class="icon-span-green" v-if="currentStrategyData.offline_enable">已启用</span>
                            <span class="icon-span-red" v-else>未启用</span>

                        </div>
                        <div class="strategyContent-title">
                            <div class="lh40 f14 clr_303" v-if="currentStrategyData.offline_mode === 0">离线指定天数前的文件：
                                <span class="f20 clr_0a">{{ currentStrategyData.offline_of_days }}天</span>
                            </div>
                            <div class="lh40 f14 clr_303" v-else-if="currentStrategyData.offline_mode === 1">
                                离线文件到指定存储容量：
                                <span class="f20 clr_0a">{{ currentStrategyData.offline_of_space_ratio }}%</span>
                                且最少保留
                                <span class="f20 clr_0a">{{ currentStrategyData.offline_save_days }}天</span>
                            </div>
                            <div class="lh40 f14 clr_303">执行时间： <span class="f20 clr_0a">{{
            offlineTimeRange }}</span> </div>
                        </div>
                    </div>
                </div>
            </div>

            <div v-else class="deviceList clear" v-show="DomainsStrategies.length !== 0">
                <div class="tableDiv">
                    <div class="organTableData"
                        v-bind:class="{ noTableData: (shareSystemStrategyList.length === 0 && otherSystemStrategyList.length === 0) }">
                        <template>
                            <el-table v-if="tabPosition  == 'share'" border stripe :data="shareSystemStrategyList"
                                style="width: 100%" :default-sort="{ prop: 'date', order: 'descending' }"
                                ref="multipleTable">
                                <el-table-column type="expand">
                                    <template slot-scope="{row}">
                                        <!-- <span>{{ row }}</span> -->
                                        <strategyListViewVue class="demo-table-expand" :showSerial="false"
                                            :tableData='row.children || []' @selectionChanged="tableSelectionChanged"
                                            @editStrategy="editStrategy" @switchChange="switchChange" />
                                    </template>
                                </el-table-column>
                                <el-table-column type="index" label="序号" width="50"></el-table-column>
                                <el-table-column prop="system_name" label="业务系统"></el-table-column>
                                <el-table-column prop="domain_name" label="存储域"></el-table-column>
                            </el-table>
                            <strategyListViewVue v-else :showSerial="true"
                                :tableData='otherSystemStrategyList || []'
                                @selectionChanged="tableSelectionChanged" @editStrategy="editStrategy"
                                @switchChange="switchChange" />
                        </template>
                    </div>
                </div>
            </div>
            </div>
          
        </div>
        <SetSaveStrategyConfigVue v-if="SetSaveStrategyShow" :configIds="configIds" :domainConfig="domainConfig"
            :SetSaveStrategyShow="SetSaveStrategyShow" :hasObjectStorage="hasObjectStorage"
            :onlineObjectStorage="onlineObjectStorage" :StrategyData="currentStrategyData"
            @SetSaveStrategyClose="SetSaveStrategyClose" />

        <InsSaveStrategyConfig v-if="InsSetSaveStrategyShow" :configIds="configIds" :batchConf="batchConf"
            :SetSaveStrategyShow="InsSetSaveStrategyShow" :hasObjectStorage="hasObjectStorage"
            :onlineObjectStorage="onlineObjectStorage" :StrategyData="currentStrategyData"
            @SetSaveStrategyClose="SetSaveStrategyClose" />
    </div>

    <!--  -->
</template>

<script>
import moment from 'moment'

import { mapGetters } from 'vuex';
import CommonTable from './components/CommonTable'
import strategyListViewVue from './components/strategyListView.vue'
import SetSaveStrategyConfigVue from './components/SetSaveStrategyConfig.vue'
import InsSaveStrategyConfig from './contentManage/components/InsSaveStrategyConfig.vue';
import {
    getDomainDeviceList,
    getAllDomainStrategies,
    // getCurrentDomainStrategies,
    updateStorageStrategies,
} from '@/api/memorySharing/dataMemory'
export default {
    components: {
        CommonTable,
        SetSaveStrategyConfigVue,
        strategyListViewVue,
        InsSaveStrategyConfig,
    },
    data() {
        return {
            tabPosition:'other',
            batchConf: false,
            configIds: [],
            domainConfig: false,
            currentStrategyType: 0,
            currentStrategyData: {},//整体配置、当前存储策略
            currentStrategyWay: false,//false 单独配置 true 整体配置
            shareSystemShow: false, // 共享系统使用时 多级
            SetSaveStrategyShow: false,
            InsSetSaveStrategyShow: false,
            hasObjectStorage: false,
            onlineObjectStorage: false,
            selectedData: [],
            requestOver: false,
            shareSystemStrategyList: [],
            otherSystemStrategyList: [],
            allStrategyList: [],
            currentDomain: {},
            currentDomainIndex: 0,
            DomainsStrategies: [],
            showStrategyAlert: false,

        }
    },
    methods: {
        //
        showTimeRange(e, index) {
            let beginTime = ''
            let endTime = ''
            if (index == 0) {
                //近线


                if (e.nearline_begin_perform_time) beginTime = moment(new Date(e.nearline_begin_perform_time)).format("HH:mm:ss")
                if (e.nearline_end_perform_time) endTime = moment(new Date(e.nearline_end_perform_time)).format("HH:mm:ss")

                return beginTime + '~' + endTime
            } else {

                if (e.offline_begin_perform_time) beginTime = moment(new Date(e.offline_begin_perform_time)).format("HH:mm:ss")
                if (e.offline_end_perform_time) endTime = moment(new Date(e.offline_end_perform_time)).format("HH:mm:ss")
                return beginTime + '~' + endTime
            }



        },
        tableSelectionChanged(rows) {
            this.selectedData = rows
        },
        editStrategy(row) {

            this.currentStrategyData = row
            this.domainConfig = false
            this.configIds = [row.id]
            if (row.strategy_type == 2) {
                //当前是机构配置---不支持按照容量设置策略
                this.InsSetSaveStrategyShow = true
            } else {
                //是否需要显示策略方式？
                this.SetSaveStrategyShow = true
            }

        },
        switchChange(row) {

            this.updateStorageStrategies(row)

        },
        async updateStorageStrategies(row) {
            const res = await updateStorageStrategies([row])
            const { code, msg } = res
            if (code === 0) {
                this.$message({
                    type: 'success',
                    message: msg || '更新存储策略成功！'
                })
            } else {
                this.$message.error(msg || '更新存储策略失败，请重试！')
            }
        },
        StrategyStyle() {

            //策略方式修改
            this.domainConfig = true
            this.SetSaveStrategyShow = true
        },
        StrategyConfiguration() {
            this.domainConfig = false

            //批量配置
            if (this.selectedData.length === 0) {
                this.$message.error('请选择系统或机构')
                return
            }
            this.configIds = this.selectedData.map(e => e.id)

            //判断机构还是系统批量配置
            if(this.selectedData[0].strategy_type == 2){
                this.InsSetSaveStrategyShow = true

            }else {
                this.SetSaveStrategyShow = true

            }

            //
        },
        SetSaveStrategyClose(res) {
            //保存？
            this.SetSaveStrategyShow = false
            this.InsSetSaveStrategyShow = false

            if (res == true) {

                this.getAllDomainStrategies()

                // if (this.domainConfig) {
                //     this.domainConfig = false
                //     this.getAllDomainStrategies()
                // } else {
                //     //更新当前存储域信息哦
                //     this.getCurrentDomainStrategies(this.currentDomain.domain_id)
                // }

            }

        },

        // 切换存储域
        chooseStorage(e, index, domainObj) {
            //is_enable
            const obj = e.currentTarget
            this.currentDomain = domainObj
            if (this.currentDomainIndex !== index) {
                this.getMyDomainDetail(domainObj.domain_id)
            }
            this.currentDomainIndex = index
        },



        // async getCurrentDomainStrategies(id) {
        //     //获取当前存储域下的存储策略 
        //     const res = await getCurrentDomainStrategies({ domain_id: id })
        //     if (res.code === 0) {
        //         this.currentDomain = res.data
        //     } else {
        //         this.$message({ message: `${res.msg}`, type: 'error' })
        //     }
        // },
        // 获取所有的存储域
        async getAllDomainStrategies() {
            const self = this
            const res = await getAllDomainStrategies()
            if (res.code === 0) {
                self.DomainsStrategies = []
                if (res.data.length !== 0) {
                    if (self.currentDomainIndex < res.data.length) {
                        self.currentDomain = res.data[self.currentDomainIndex]
                    } else {
                        self.currentDomain = res.data[0]
                    }
                    self.getMyDomainDetail(self.currentDomain.domain_id)
                    self.DomainsStrategies = res.data
                    if (self.currentDomain?.storage_strategies && self.currentDomain.storage_strategies.length > 0) {
                        self.currentStrategyData = self.currentDomain.storage_strategies[0]
                    } else {
                        self.currentStrategyData = {}
                    }
                } else {
                    // self.allStrategyList = []
                    self.shareSystemStrategyList = []
                    self.otherSystemStrategyList = []
                    self.requestOver = true
                }
            } else {
                this.requestOver = true
                self.$message({ message: `${res.msg}`, type: 'error' })
            }
        },

        // 获取存储域详情
        async getMyDomainDetail(id) {
            const res = await getDomainDeviceList({ id: id })
            if (res.code === 0) {
                this.hasObjectStorage = res.data.some(e => e.device_type < 6)
                this.onlineObjectStorage = res.data.some(e => e.is_online && e.device_type < 6)
            } else {
                this.requestOver = true
                this.$message({ message: `${res.msg}`, type: 'error' })
            }
        },
        handleChange() { }
    },
    mounted() {



        const self = this
        self.getAllDomainStrategies()

    },
    computed: {
        ...mapGetters(['cardStyle']),
        nearlineTimeRange() {
            let beginTime = ''
            let endTime = ''
            if (this.currentStrategyData.nearline_begin_perform_time) beginTime = moment(new Date(this.currentStrategyData.nearline_begin_perform_time)).format("HH:mm:ss")
            if (this.currentStrategyData.nearline_end_perform_time) endTime = moment(new Date(this.currentStrategyData.nearline_end_perform_time)).format("HH:mm:ss")
            return beginTime + '~' + endTime
        },
        offlineTimeRange() {
            let beginTime = ''
            let endTime = ''
            if (this.currentStrategyData.offline_begin_perform_time) beginTime = moment(new Date(this.currentStrategyData.offline_begin_perform_time)).format("HH:mm:ss")
            if (this.currentStrategyData.offline_end_perform_time) endTime = moment(new Date(this.currentStrategyData.offline_end_perform_time)).format("HH:mm:ss")
            return beginTime + '~' + endTime

        },
        containerClass() {
            if (this.requestOver && this.DomainsStrategies.length === 0 && this.cardStyle) {
                return 'noDomain cardContainer'
            } else if ((this.requestOver && this.DomainsStrategies.length === 0) || this.cardStyle) {
                return this.cardStyle ? 'cardContainer' : 'noDomain'
            }

            return ''
        }
    },
    watch: {
        currentDomain(val) {
// debugger
            if (val) {
                this.currentStrategyWay = val.strategy_type === 0 || !val.strategy_type
                this.currentStrategyType = val.strategy_type

                if (val.storage_strategies && val.storage_strategies.length > 0)
                    {
                        this.currentStrategyData = val?.storage_strategies[0] || {}
                        // if (val.strategy_type === 2) {
                this.otherSystemStrategyList = val.storage_strategies.filter(e => e.strategy_type == 1)
                let system_ids = Array.from(new Set(val.storage_strategies.filter(e => e.strategy_type == 2).map(e => e.system_id)))
                
                this.shareSystemStrategyList = system_ids.map(item => {
                    let children = val.storage_strategies.filter(e => e.system_id === item)
                    let system_name = ''
                    let domain_name = ''
                    if (children.length > 0) {
                        system_name = children[0].system_name
                        domain_name = children[0].domain_name
                    }
                    return { system_name, domain_name, children }
                    // return 
                })||[]
                if(this.otherSystemStrategyList.length>0){
                    this.tabPosition = 'other'
                }else  if(this.shareSystemStrategyList.length>0){
                    this.tabPosition = 'share'
                }
                // console.log('数据不对哦？========',this.otherSystemStrategyList,this.shareSystemStrategyList);

                //     this.shareSystemShow = true
                // } else {
                //     this.allStrategyList = val.storage_strategies || []
                //     this.shareSystemShow = false

                // }
                    }else{
                        this.currentStrategyData = {}
                this.shareSystemStrategyList = []
                this.otherSystemStrategyList = []
                    }
                
                    

                
            } else {

                this.currentStrategyData = {}
                this.shareSystemStrategyList = []
                this.otherSystemStrategyList = []

            }
        }
    },

}
</script>
<style lang='less' scoped>
.userlist {
    height: 100%;
    background-color: #EBEEF5;


  ::v-deep  .el-radio-button__orig-radio:checked + .el-radio-button__inner {
    color:#0a70b0;
    background-color:   #FFFFFF;
    border-color: #0a70b0;
    -webkit-box-shadow: -1px 0 0 0 #0a70b0;
    box-shadow: -1px 0 0 0 #0a70b0;
}
::v-deep .el-radio-button__inner {
    width: 118px;
}

    .icon-span-green {
        color: #1CB54A;
        border: 1px solid #1CB54A;
        font-size: 13px;
        text-align: center;
        padding: 3px;
        border-radius: 3px;
    }

    .icon-span-red {
        color: #F56C6C;
        border: 1px solid #F56C6C;
        font-size: 13px;
        text-align: center;
        padding: 3px;
        border-radius: 3px;
    }
}

.no-strategy {
    min-height: 150px;
    margin: 15px;
    padding: 20px;
    border: 1px dashed #DCDFE6;
    border-radius: 5px;
}
.noDataContent {
    min-width: 330px;
    height: calc(100% - 200px);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    // .line {
    //     height: 2px;
    //     width: 330px;
    //     // border-top: 5px dotted #000;
    //     border-top: 1px dashed #DCDFE6;
    //     background-color: white;
    //     border-radius: 0 0 5px 5px;
    // }

    .noDataImg {
        width: 120px;
        height: 80px;
        background-image: url('../../../assets/images/dataStorage/noData.png');
        background-size: cover;
    }

    span {
        padding: 20px;
        font-size: 14px;
    }

}

.cardHeader {
    background-color: white;
}

.cardContainer {
    margin: 10px !important;
    border-radius: 5px !important;
    height: calc(100% - 47px - 20px) !important;

}

.DeviceCon {

    background-color: white;

    height: calc(100% - 46px);

    .allDevice {
        width: 100%;
        float: left;
        padding: 0 15px;
        display: flex;
        // display: grid;
        // grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
        border-bottom: 1px solid #dcdfe6;
        max-height: 50%;
        overflow-x: auto;

        .oneDevice {
            min-width: 200px;
            max-width: 250px;

            // width: calc(100% - 15px);
            height: 90px;
            border: 1px solid rgba(10, 112, 176, 0.25);
            margin: 0 15px 12px 0;
            float: left;
            cursor: pointer;
            border-radius: 4px;
            position: relative;

            .deviceHead {
                height: 40px;
                line-height: 40px;
                font-size: 15px;
                color: #303133;
                // text-align: center;
                border-bottom: 1px solid rgba(10, 112, 176, 0.25);
                white-space: nowrap;
                text-overflow: ellipsis;
                overflow: hidden;
                word-break: break-all;
                font-weight: bold;
                padding: 0 15px;
                border-radius: 5px 5px 0px 0px;
                background-color: #f5f5f5;
            }


            .deviceContent {
                padding: 0 15px;
                line-height: 50px;

            }


        }

        .oneDevice:hover {
            border-color: rgba(90, 134, 161, 0.5);
            background: #ebf5ff;
        }

        .activeChart {
            border-color: rgba(90, 134, 161, 0.5);
            background: #ebf5ff;
            box-shadow: 0px 2px 6px 0px rgba(25, 25, 25, 0.1);

            .activeDeviceHead {
                background-color: #0A70B0;
                color: #f5f5f5;

            }

            .activeDeviceContent {
                color: #0A70B0;

            }
        }

    }

    .domainCon {
        height: 300px;
        overflow: auto;
        position: relative;
    }

    .chartCon {
        width: 370px;
        height: 280px;
        cursor: pointer;
        border-radius: 4px;
        margin-right: 30px;
        position: relative;

        // box-shadow:1px 0px 6px 0px rgba(0,0,0,0.1);
        .w370 {
            width: 370px;
        }

        .h250 {
            height: 250px;
        }

        .addImgCon {
            width: 80px;
            height: 80px;
            cursor: pointer;
            margin: 0 auto;
            margin-top: 95px;
        }

        .chartState {
            width: 100%;
            text-align: center;
            position: absolute;
            bottom: 0px;
            line-height: 52px;
            font-size: 18px;
        }
    }

    .listTit {
        height: 48px;
        line-height: 48px;
        font-size: 16px;
        color: #303133;
        font-weight: 700;
        padding: 0 15px;

        .listTitIcon {
            width: 3px;
            height: 16px;
            background: #0a70b0;
            margin-right: 12px;
            margin-top: 16px;
        }

        .function-btn {
            font-weight: initial;
            margin-top: 9px;
            border: 1px solid #DCDFE6;
            font-weight: 400;
            font-size: 14px;
        }

        .loadDeviceTit {
            font-size: 15px;
        }
    }

    .strategyContent {
        padding: 10px;
        border-top: 1px dashed #dcdfe6;
        font-weight: 500;

        &-title {
            font-weight: 400;
            border-radius: 5px;
            padding: 10px;
            width: 380px;
            border: 1px dashed #dcdfe6;

        }

    }

    .deviceList {
        padding: 0 15px;
        height: calc(100% - 200px);

        .tableDiv {
            height: 100%;
            // margin-bottom:20px;
            border: 1px solid #dcdfe6;

            .organTableData {
                // min-height: 160px;
                height: 100%;

                ::v-deep th {
                    background: #f9f9f9;
                    color: rgb(51, 51, 51);
                }

                .el-table {
                    height: 100%;
                    border: none;

                    ::v-deep .el-table__body-wrapper {
                        min-height: 120px;
                        height: calc(100% - 40px);
                        // overflow-x:hidden!important;
                        overflow-y: auto !important;
                    }
                }

                ::v-deep .el-table-column--selection .cell {
                    padding-left: 10px;
                }
            }

            .blockPage {
                text-align: center;
            }
        }
    }
}
</style>
