<template>
  <div class="userlist">
    <div class="title-bar flex_row cardHeader">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr5"></i>数据管理
          <i class="iconfont iconzhankaishouqi"></i> 存储授权
        </span>
      </div>

    </div>
    <div class="serviceDoctorCon container" :class="{ 'cardContainer': cardStyle }">
      <div class="conditionContainer">
        <el-form :inline="true" class="demo-form-inline" label-width="65px" label-position="right">

          <el-form-item label="业务系统：" label-width="90px">
            <el-select  :disabled="systemArr.length === 0" size="small" v-model="getAuthorizationListParam.system_id"
              placeholder="请选择" filterable clearable style="width:200px">
              <el-option v-for="item in systemArr" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="存储域：">
            <el-select :disabled="DomainsArr.length == 0" size="small" v-model="getAuthorizationListParam.domain_id"
              placeholder="请选择" style="width:200px" filterable clearable>
              <el-option v-for="item in DomainsArr" :key="item.id" :label="item.domain_name" :value="item.id"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item class="ml10 includePlainButton">
            <el-button type="primary" size="small" @click="searchCondation">查询</el-button>
            <el-button type="primary" plain size="small" @click="resetCondation">重置</el-button>
          </el-form-item>
          <div class="fr">
            <el-button type="primary" size="small" @click="addAuthorize"><i
                class="iconfont iconxinzeng pr4 clr_ff"></i>添加授权</el-button>
            <!-- <span @click="addAuthorize" class="function-btn bg_0c83 clr_ff">
              <i class="iconfont iconxinzeng pr4"></i>添加授权
            </span> -->
          </div>
          <br>
        </el-form>
      </div>
      <div class="deviceTableList clear" :class="tableClass">
        <el-table :data="tableData" border stripe :header-cell-style="{ background: '#F2F2F2', color: '#333' }"
          highlight-current-row header-row-class-name="strong" v-loading="loading" element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)">
          <el-table-column type="index" label="序号" width="50">
            <template slot-scope="scope">
              <span>{{ orderNum + scope.$index + 1 }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="100">
            <template slot-scope="scope">
              <!-- <span
                class="icon-btn bg_0c83"
                @click="watchAuthDetail(scope.row)"
                type="text"
                size="small"
                title="编辑"
              >
               <i class="iconfont iconxiugaihuobianji"></i>
              </span>
              <span @click.stop="delAuthorize(scope.row.id)" class="icon-btn bg_f5" type="text" size="small" title="删除">
                <i class="iconfont iconshanchu"></i>
              </span> -->
              <span class="clr_0a pointer" @click="watchAuthDetail(scope.row)">编辑</span>
              <span class="clr_da pointer pl10" @click.stop="delAuthorize(scope.row.id)">删除</span>
            </template>
          </el-table-column>
          <el-table-column v-for="(item, index) in propData" :key="index" :prop="item.prop" :label="item.label"
            :width="item.width" :formatter="item.formatter" :show-overflow-tooltip="true">
          </el-table-column>
          <!-- <el-table-column prop="access_key" label="访问KEY"></el-table-column> -->
        </el-table>
        <div class="pageDiv">
          <pagination-tool :total="totalPage" :page.sync="getAuthorizationListParam.page_index"
            :limit.sync="getAuthorizationListParam.page_size" @pagination="getMyAuthorizationList" />
        </div>
      </div>

      <el-dialog class="addDeviceAlert" :title="authorizationTit" :visible.sync="showaddAuthorizeAlert" width="500px"
        height="600px" :close-on-click-modal="false" v-dialogDrag>
        <div class="addDeviceCon">
          <div class="oneDeviceInfo clear">
            <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>业务系统：</span>
            <div class="oneLogVal fl">
              <el-select v-model="addAuthorizationInfoParam.system_id" filterable placeholder="请选择"
                class="ele-select_32 width_300_select" style="width:180px" :disabled="authorizationTit.indexOf('编辑') !== -1">
                <el-option v-for="(item, index) in systemArr" :key="index" :label="item.name"
                  :value="item.id"></el-option>
              </el-select>
            </div>
          </div>
          <div class="oneDeviceInfo">
            <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>存储域：</span>
            <div class="oneLogVal fl">
              <el-select v-model="addAuthorizationInfoParam.domain_id" filterable placeholder="请选择"
                class="ele-select_32 width_300_select" style="width:180px" >
                <el-option v-for="(item, index) in DomainsArr" :key="index" :label="item.domain_name"
                  :value="item.id"></el-option>
              </el-select>
            </div>
          </div>
          <div class="oneDeviceInfo">
            <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>访问权限：</span>
            <el-radio v-model="addAuthorizationInfoParam.system_permissions" :label="0">读写</el-radio>
            <el-radio v-model="addAuthorizationInfoParam.system_permissions" :label="1">只读</el-radio>
            <!-- <el-radio v-model="addAuthorizationInfoParam.system_permissions" :label="2">只写</el-radio> -->
          </div>
          <!-- <div class="oneDeviceInfo">
           <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>访问KEY：</span>
           <input v-model="addAuthorizationInfoParam.access_key" type="password" class="fl input_300" />
        </div> -->
          <div class="oneDeviceInfo">
            <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian mustIcon"></i>容量配额：</span>
            <el-radio :disabled="addAuthorizationInfoParam.system_permissions === 1" v-model="rlpe"
              :label="0">是</el-radio>
            <el-radio :disabled="addAuthorizationInfoParam.system_permissions === 1" v-model="rlpe"
              :label="1">否</el-radio>
          </div>
          <div class="oneDeviceInfo onlineStorage">
            <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian"></i>在线容量：</span>
            <el-input-number :disabled="rlpe === 1" :class="{'inputError': maxStorageTip}" style="width: 100px" size="medium"
              v-model="addAuthorizationInfoParam.online_size" controls-position="right" :min="0"></el-input-number>
            <span class="ml10">TB</span>
            <div class="maxStorageTip clear" v-if="maxStorageTip">{{maxStorageTip}}</div>
          </div>
          
          <div class="oneDeviceInfo">
            <span class="oneDeviceInfoLabel fl"><i class="iconfont iconbitian"></i>近线容量：</span>
            <el-input-number :disabled="rlpe === 1" style="width: 100px" size="medium"
              v-model="addAuthorizationInfoParam.nearline_size" controls-position="right" :min="0"></el-input-number>
            <span class="ml10">TB</span>
          </div>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button size="small" plain @click="showaddAuthorizeAlert = false">取 消</el-button>
          <el-button type="primary" size="small" v-if="!isUpdateAuthorizationInfor" @click="sureAddAuthorizationInfor">确
            定</el-button>
          <el-button type="primary" size="small" v-if="isUpdateAuthorizationInfor" @click="sureUpdateAuthorizationInfor">确
            定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import { getSystemsList } from '@/api/user'
import PaginationTool from '@/components/common/PaginationTool' // 分页
import { getAuthorizationList, addAuthorizationInfo, updateAuthorizationInfo, getAllDomains, delOneAuthInfor } from '@/api/memorySharing/dataMemory'
import { mapGetters } from 'vuex'
export default {
  components: {
    PaginationTool,

  },
  watch: {
    'addAuthorizationInfoParam.system_permissions': {
      handler: function (val) {
        if (val === 1) {
          this.rlpe = 1
          this.addAuthorizationInfoParam.online_size = ''
          this.addAuthorizationInfoParam.nearline_size = ''
        }

      },
      immediate: true,
    },
  },
  computed: {
    ...mapGetters(['cardStyle']),
    orderNum() {
      if (this.getAuthorizationListParam.page_index === 1) {
        return 0
      } else {
        return (this.getAuthorizationListParam.page_index - 1) * this.getAuthorizationListParam.page_size
      }
    },
    tableClass() {

      // if(this.tableData.length == 0 && this.cardStyle){
      //   return 'noTableData cardDeviceTableList'
      // }
      //   if(this.tableData.length==0 || this.cardStyle){
      //     return this.tableData.length==0 ? 'noTableData' : 'cardDeviceTableList'
      //   }

      return this.tableData.length == 0 ? 'noTableData' : ''
    },
  },
  data() {
    return {
      // cardStyle:true,
      propData: [
        { prop: 'system_name', label: '业务系统', },
        { prop: 'domain_name', label: '存储域', },
        {
          prop: 'system_permissions', label: '访问权限', width: 100, formatter: (row) => {
            switch (row.system_permissions) {
              case 0:
                return '读写'
                break;
              case 1:
                return '只读'
                break;
              case 2:
                return '只写'
                break;
              default: ''
                break;
            }
          }
        },
        {
          prop: 'rlpe', label: '容量配额', width: 80, formatter: (row) => {
            if (row?.online_size || row?.nearline_size) return '是'
            return '否'
          }
        },
        { prop: 'online_size', label: '在线容量', width: 170, formatter: (row) => row?.online_size ? (row.online_size + ' TB') : '' },
        { prop: 'nearline_size', label: '近线容量', width: 170, formatter: (row) => row?.nearline_size ? (row.nearline_size + ' TB') : '' },

      ],
      totalPage: 0,
      isDefend: 1,
      value1: '',
      timer: [],
      showaddAuthorizeAlert: false,
      DomainsArr: [],
      systemArr: [],
      rlpe: 1,
      addAuthorizationInfoParam: {
        domain_id: 0,
        domain_name: '',
        system_id: 0,
        system_name: '',
        system_type: '',

        system_permissions: 0,
        access_key: '',
      },
      loading: false,
      getAuthorizationListParam: {
        system_id: '',
        system_name: '',
        domain_id: '',
        domain_name: '',
        page_index: 1,
        page_size: 20
      },
      authorizationTit: '新增存储域授权',
      isUpdateAuthorizationInfor: false,
      serviceState: [
        { state: 0, state_str: '民营医院' },
        { state: 1, state_str: '启动服务' },
        { state: 2, state_str: '暂停服务' },
        { state: 3, state_str: '服务中' }
      ],
      currentPage: 1,
      defendTable: [],
      tableData: [],
      maxStorageTip: '',
    }
  },
  methods: {

    //TODO:
    searchCondation() {
      this.getAuthorizationListParam.page_index = 1
      this.getMyAuthorizationList()
    },
    resetCondation() {
      this.getAuthorizationListParam.domain_id = ''
      this.getAuthorizationListParam.domain_name = ''
      this.getAuthorizationListParam.system_id = ''
      this.getAuthorizationListParam.system_name = ''
      this.getAuthorizationListParam.system_type = ''

      this.getMyAuthorizationList()

    },

    watchAuthDetail(obj) {
      const self = this
      self.maxStorageTip = ''
      self.isUpdateAuthorizationInfor = true
      self.authorizationTit = '编辑存储域授权信息'
      self.showaddAuthorizeAlert = true
      self.currentAuthId = obj.id
      if ((obj.online_size || obj.nearline_size)) {
        self.rlpe = 0
      } else {
        self.rlpe = 1
      }
      
      self.addAuthorizationInfoParam = {
        domain_id: obj.domain_id,
        domain_name: obj.domain_name,
        system_id: obj.system_id,
        system_name: obj.system_name,
        system_type: obj.system_type,
        system_permissions: obj.system_permissions,
        online_size: obj.online_size,
        nearline_size: obj.nearline_size,

      }

      let isHasThisSystem = false
      self.systemArr.forEach(function (val) {
        if (val.id === obj.system_id) {
          isHasThisSystem = true
        }
      })
      if (!isHasThisSystem) {
        self.addAuthorizationInfoParam.system_id = null
        self.addAuthorizationInfoParam.system_name = ''
        self.addAuthorizationInfoParam.system_type = ''

      }
    },
    addAuthorize() {
      this.isUpdateAuthorizationInfor = false
      this.authorizationTit = '新增存储域授权信息'
      this.showaddAuthorizeAlert = true
      this.maxStorageTip = ''
      this.addAuthorizationInfoParam = {
        domain_id: null,
        domain_name: '',
        system_id: null,
        system_name: '',
        system_type: '',
        system_permissions: 0,
        access_key: '',
        online_size: '',
        nearline_size: '',
      }
    },
    async beganDelAuth(id) {
      const param = {
        id: id
      }
      const res = await delOneAuthInfor(param)
      if (res.code === 0) {
        this.$message({ message: '删除授权信息成功', type: 'success' })
        this.getMyAuthorizationList()
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 禁用
    delAuthorize(id) {
      const self = this
      self.$confirm('确定要删除该授权信息?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        customClass: 'warningAlert',
        type: 'warning'
      })
        .then(() => {
          self.beganDelAuth(id)
        })
        .catch(() => {
        })
    },
    verifyAddAuthorizationInfor() {
      const self = this
      if (!self.addAuthorizationInfoParam.system_id) {
        self.$message({ message: '请选择业务系统', type: 'error' })
        return false
      }
      if (!self.addAuthorizationInfoParam.domain_id) {
        self.$message({ message: '请选择存储域', type: 'error' })
        return false
      }
      // if (!self.addAuthorizationInfoParam.system_permissions) {
      //   self.$message({ message: '请选择访问权限', type: 'error' })
      //   return false
      // }
      // if (!self.addAuthorizationInfoParam.access_key) {
      //   self.$message({ message: '请输入访问KEY', type: 'error' })
      //   return false
      // }

      //TODO
      //1、点击确定时，需判断当前业务系统是否已授权其他存储域，若已授权，toast“业务系统已授权认证其它存储域”。（逻辑已存在，需修改提示文案）
      //1、点击确定时，不允许存储共享系统与其他业务系统共用同个存储域，否则toast“业务系统与存储共享系统不得共用同个存储域！”


      if (self.addAuthorizationInfoParam.system_permissions !== 1
        && self.rlpe !== 1
        && (self.addAuthorizationInfoParam.nearline_size + self.addAuthorizationInfoParam.online_size == 0)) {
        //容量配额已选中
        //yjr:在线容量和近线容量不能同时为0  和产品确认过 2023-09-19 qq zyh
        //在线容量和近线容量不能同时为空？？ 请输入在线容量或近线容量？
        self.$message({ message: '在线容量和近线容量不能同时为空', type: 'error' })
        return false


      }


      self.systemArr.forEach(function (val) {
        if (val.id === self.addAuthorizationInfoParam.system_id) {
          self.addAuthorizationInfoParam.system_name = val.name
          self.addAuthorizationInfoParam.system_type = val.type

        }
      })
      self.DomainsArr.forEach(function (val) {
        if (val.id === self.addAuthorizationInfoParam.domain_id) {
          self.addAuthorizationInfoParam.domain_name = val.domain_name
        }
      })
      return true
    },
    // 确定添加存储域信息
    async sureAddAuthorizationInfor() {
      if (this.verifyAddAuthorizationInfor()) {
        if (this.rlpe === 1) {// 不设置容量配额
          this.addAuthorizationInfoParam.online_size = null
          this.addAuthorizationInfoParam.nearline_size = null
        } else {// 设置了容量配额
          this.addAuthorizationInfoParam.online_size = String(this.addAuthorizationInfoParam.online_size)
          this.addAuthorizationInfoParam.nearline_size = String(this.addAuthorizationInfoParam.nearline_size)
        }
        // this.addAuthorizationInfoParam.online_size = this.addAuthorizationInfoParam.online_size?String(this.addAuthorizationInfoParam.online_size):null
        // this.addAuthorizationInfoParam.nearline_size = this.addAuthorizationInfoParam.nearline_size?String(this.addAuthorizationInfoParam.nearline_size):null
        const res = await addAuthorizationInfo(this.addAuthorizationInfoParam)
        if (res.code === 0) {
          this.maxStorageTip = ''
          this.showaddAuthorizeAlert = false
          this.$message({ message: '添加存储域授权信息成功', type: 'success' })
          this.getMyAuthorizationList()
        } else {
          if (res.code === 100) {
            this.maxStorageTip = res.msg
          } else {
            this.maxStorageTip = ''
            this.$message({ message: `${res.msg}`, type: 'error' })
          }
          
        }
      }
    },
    // 确定修改存储域的信息
    async sureUpdateAuthorizationInfor() {
      if (this.verifyAddAuthorizationInfor()) {
        let param = {
          domain_id: this.addAuthorizationInfoParam.domain_id,
          domain_name: this.addAuthorizationInfoParam.domain_name,
          system_id: this.addAuthorizationInfoParam.system_id,
          system_name: this.addAuthorizationInfoParam.system_name,
          system_permissions: this.addAuthorizationInfoParam.system_permissions,
          online_size: null,
          //近线容量
          nearline_size: null,
        }
        if (this.rlpe === 1) {// 不设置容量配额
          param.online_size = null
          param.nearline_size = null
        } else {// 设置了容量配额
          param.online_size = String(this.addAuthorizationInfoParam.online_size)
          param.nearline_size = String(this.addAuthorizationInfoParam.nearline_size)
        }

        const res = await updateAuthorizationInfo(param, this.currentAuthId)
        if (res.code === 0) {
          this.maxStorageTip = ''
          this.showaddAuthorizeAlert = false
          this.$message({ message: '修改存储域授权信息成功', type: 'success' })
          this.getMyAuthorizationList()
        } else {
          if (res.code === 100) {
            this.maxStorageTip = res.msg
          } else {
            this.maxStorageTip = ''
            this.$message({ message: `${res.msg}`, type: 'error' })
          }
        }
      }
    },
    async getMyAuthorizationList() {
      this.loading = true
      const res = await getAuthorizationList(this.getAuthorizationListParam)
      if (res.code === 0) {
        this.loading = false
        if (res.data) {
          this.tableData = res.data
        } else {
          this.tableData = []
        }
        if (res.page) {
          this.totalPage = res.page.total_count
        } else {
          this.totalPage = 0
        }
      } else {
        this.loading = false
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 获取所有的存储域
    async getMyAllDomains() {
      const self = this
      self.DomainsArr = []
      const res = await getAllDomains({ returnDevice: true })
      if (res.code === 0) {
        res.data.forEach(function (val) {
          self.DomainsArr.push(val)
        })
        self.DomainsArr.unshift({ domain_name: '请选择', id: null })
      } else {
        self.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    async getMySystemsList() {
      const self = this
      self.systemArr = []
      const res = await getSystemsList()
      if (res.code === 0) {
        res.data.forEach(function (val) {
          self.systemArr.push(val)
        })
        self.systemArr.unshift({ name: '请选择', id: null })
      } else {
        self.$message({ message: `${res.msg}`, type: 'error' })
      }
    }
  },
  mounted() {
    this.getMyAllDomains()
    this.getMySystemsList()
    this.getMyAuthorizationList()
  }
}
</script>

<style lang="less" scoped>
.userlist {
  width: 100%;
  height: 100%;
  overflow: hidden !important;
}

.cardHeader {
  background-color: white;
}

.userlist {
  background-color: #EBEEF5;

  .cardContainer {
    margin: 10px !important;
    border-radius: 5px !important;
    height: calc(100% - 47px - 20px) !important;

  }

  .container {
    padding: 10px 15px;
    background: #fff;
    height: calc(100% - 47px);
    position: relative;

    .iconfont {
      margin: 0px;
    }

    .icon-btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      color: #fff;
      line-height: 24px;
      text-align: center;
      padding: 0px;
      cursor: pointer;
      border-radius: 3px;
      margin-right: 8px;
    }

    .deviceTableList {
      position: relative;
      border: 1px solid #ebeef5;
      height: calc(100% - 50px);
      border-bottom: none;

      ::v-deep .el-table {
        height: 100%;
      }

      ::v-deep.el-table--border {
        border: none;
      }

      ::v-deep .el-table__body-wrapper {
        height: calc(100% - 98px);
        overflow-y: auto;
      }
    }

    // .table-list {
    //   position: relative;
    //   border: 1px solid #ebeef5;
    //   height: calc(100% - 100px);
    //   ::v-deep.el-table--border {
    //     border: none;
    //   }
    // }
    .pageDiv {
      width: 100%;
      position: absolute;
      bottom: 0px;
      text-align: right;
      border-top: 1px solid #ebeef5;
    }
  }
}

.selectDiv::-ms-expand {
  display: none;
}

/* --火狐、谷歌清除--*/
.selectDiv {
  border: none;
  // appearance:none;
  // -moz-appearance:none;
  // -webkit-appearance:none;
}

.addDeviceCon {
  padding-top: 30px;
  // padding-right: 30px;
  height: 370px;

  .oneDeviceInfo {
    height: 36px;
    line-height: 35px;
    margin-bottom: 20px;

    .oneDeviceInfoLabel {
      width: 120px;
      text-align: right;
    }

    .input_300 {
      width: 300px;
      height: 36px;
      line-height: 36px;
      border: none;
      border: 1px solid #DCDFE6;
      border-radius: 3px;
      padding-left: 8px;
    }

    .width_300_select {
      ::v-deep .el-input__inner {
        height: 36px;
        line-height: 36px;
      }

      ::v-deep .el-input__icon {
        line-height: 36px;
      }
    }

    /**必填的图标样式*/
    .iconbitian {
      color: #da4a4a;
      font-size: 10px;
    }
  }
}

.noTableData {
  background: none !important;
}
.onlineStorage{
  position: relative;
}
.maxStorageTip{
  font-size: 12px;
  color: #da4a4a;
  line-height: 20px;
  margin-left: 120px;
}
::v-deep .inputError{
  .el-input__inner{
    border-color:#da4a4a!important;
  }
  .el-input__inner:hover{
    border-color:#da4a4a!important;
  }
}
</style>
