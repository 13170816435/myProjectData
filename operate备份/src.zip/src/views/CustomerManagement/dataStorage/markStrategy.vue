<template>
  <div class="userlist pb10">
    <!-- <div class="title-bar flex_row cardHeader">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>数据管理
          <i class="iconfont iconzhankaishouqi"></i> 标记策略
        </span>
      </div>
    </div> -->

    <div class="DeviceCon" :class="containerClass">
      <div class="allDevice mt10">
        <div
          class="oneDevice chartCon"
          v-for="(item, index) in markStrategies"
          :key="index"
          @click="chooseStorage(index, item)"
          v-bind:class="{ activeChart: currentDomainIndex === index }">
          <div
            class="deviceHead activeDeviceHead"
            v-bind:title="item.domain_name">
            {{ item.domain_name }}
          </div>
          <div class="deviceContent activeDeviceContent">
            <div>标记方式：单独配置</div>
          </div>
        </div>
      </div>
      <div class="listTit clear">
        <span class="listTitIcon fl"></span
        ><span class="fl loadDeviceTit"
          >{{ currentDomain.domain_name }}<span>下各系统的标记策略列表</span>
        </span>
        <span @click="StrategyConfiguration" class="function-btn clr_0a fr">
          <!-- <i class="iconfont iconzongheshezhi mr5"></i> -->
          批量配置
        </span>
      </div>

      <div class="deviceList clear">
        <div class="tableDiv">
          <div
            v-if="!system_id"
            class="organTableData"
            :class="{
              noTableData: dominMarkList.length === 0,
            }">
            <template>
              <el-table
                border
                stripe
                :data="dominMarkList"
                style="width: 100%"
                :default-sort="{ prop: 'date', order: 'descending' }"
                ref="multipleTable">
                <el-table-column type="expand" width="60">
                  <template slot-scope="{ row }">
                    <markStrategyListView
                      class="demo-table-expand"
                      :showSerial="false"
                      :tableData="row.children || []"
                      @selectionChanged="tableSelectionChanged"
                      @editStrategy="editStrategy"
                      @switchChange="switchChange" />
                  </template>
                </el-table-column>
                <el-table-column
                  type="index"
                  label="序号"
                  width="60"></el-table-column>
                <el-table-column
                  prop="system_name"
                  label="业务系统"></el-table-column>
                <el-table-column
                  prop="domain_name"
                  label="存储域"></el-table-column>
              </el-table>
            </template>
          </div>
          <div v-else class="organTableData">
            <markStrategyListView
              class="demo-table-expand"
              :showSerial="false"
              :tableData="expandTableData"
              @selectionChanged="tableSelectionChanged"
              @editStrategy="editStrategy"
              @switchChange="switchChange" />
          </div>
        </div>
      </div>
    </div>
    <markSetSaveStrategyConfigVue
      :configStrategyDatas="configStrategyDatas"
      :SetSaveStrategyShow="SetSaveStrategyShow"
      :StrategyData="currentStrategy"
      @SetSaveStrategyClose="SetSaveStrategyClose" />
  </div>

  <!--  -->
</template>

<script>
  import moment from 'moment';

  import { mapGetters } from 'vuex';
  import CommonTable from './components/CommonTable';
  import markStrategyListView from './components/markStrategyListView.vue';
  import markSetSaveStrategyConfigVue from './components/markSetSaveStrategyConfig.vue';
  import {
    getMarkstrategies,
    getMarkstrategiesAll,
    updateMarkstrategies,
    getCurrentDomainStrategies,
  } from '@/api/memorySharing/dataMemory';
  export default {
    components: {
      CommonTable,
      markSetSaveStrategyConfigVue,
      markStrategyListView,
    },
    data() {
      return {
        batchConf: false,
        configStrategyDatas: [],
        SetSaveStrategyShow: false,

        selectedData: [],
        requestOver: false,
        dominMarkList: [],
        currentDomain: {},
        currentDomainIndex: 0,
        currentStrategy: {},
        markStrategies: [],
        showStrategyAlert: false,
        strategy: {
          nearLineStrategy: {},
          deleteStrategy: {},
          compressionStrategy: {},
        },
        system_id: '',
        expandTableData: []
      };
    },
    methods: {
      //
      showTimeRange(e, index) {
        let beginTime = '';
        let endTime = '';
        if (index == 0) {
          //近线

          if (e.nearline_begin_perform_time)
            beginTime = moment(new Date(e.nearline_begin_perform_time)).format(
              'HH:mm:ss'
            );
          if (e.nearline_end_perform_time)
            endTime = moment(new Date(e.nearline_end_perform_time)).format(
              'HH:mm:ss'
            );

          return beginTime + '~' + endTime;
        } else {
          if (e.offline_begin_perform_time)
            beginTime = moment(new Date(e.offline_begin_perform_time)).format(
              'HH:mm:ss'
            );
          if (e.offline_end_perform_time)
            endTime = moment(new Date(e.offline_end_perform_time)).format(
              'HH:mm:ss'
            );
          return beginTime + '~' + endTime;
        }
      },
      // 选择事件
      tableSelectionChanged(rows) {
        this.selectedData = rows;
      },
      // 编辑
      editStrategy(row) {
        this.configStrategyDatas = [row];
        this.SetSaveStrategyShow = true;
      },

      switchChange(row) {
        if (!row.mark_of_days && row.is_enable == 1) {
          row.is_enable = 0;
          this.editStrategy(row);
          return;
        }
        this.updateMarkstrategies(row);
      },

      // 更新标记策略
      async updateMarkstrategies(row) {
        const res = await updateMarkstrategies([row]);
        const { code, msg } = res;
        if (code === 0) {
          this.$message.success(msg);
        } else {
          this.$message.error(msg);
        }
      },

      //批量配置
      StrategyConfiguration() {
        if (this.selectedData.length === 0) {
          this.$message.error('请选择机构');
          return;
        }
        this.configStrategyDatas = this.selectedData;
        this.SetSaveStrategyShow = true;
      },
      SetSaveStrategyClose(res) {
        this.SetSaveStrategyShow = false;

        // if (res == true) {
        //   this.getMarkstrategiesAll();
        // }
      },

      // 切换存储域
      chooseStorage(index, domainObj) {
        this.currentDomain = domainObj;
        this.currentDomainIndex = index;
        this.selectedData = [];
        this.expandTableData = [];

        if (this.system_id) {
          domainObj.storage_mark_strategies.forEach(item => {
            this.expandTableData = this.expandTableData.concat(item.children);
          })
        }

        this.dominMarkList = domainObj.storage_mark_strategies || [];
        this.getCurrentDomainStrategies(domainObj.domain_id);
      },
      // 获取所有的标记策略
      async getMarkstrategiesAll() {
        const res = await getMarkstrategiesAll();
        if (res.code != 0) {
          this.$message.error(res.msg);
          return;
        }

        this.markStrategies = [];
        // 数据分类
        res.data.forEach((item) => {
          let systemObj = {};
          if (this.system_id) {
            item.storage_mark_strategies = item.storage_mark_strategies.filter(
              (storage) => {
                return (storage.system_id = this.system_id);
              }
            );
          }

          item.storage_mark_strategies.forEach((storage) => {
            storage.is_enable = storage.is_enable ? 1 : 0;
            if (systemObj[storage.system_id]) {
              systemObj[storage.system_id].children.push(storage);
            } else {
              systemObj[storage.system_id] = {
                system_id: storage.system_id,
                system_name: storage.system_name,
                domain_id: item.domain_id,
                domain_name: item.domain_name,
                children: [storage],
              };
            }
          });
          item.storage_mark_strategies = Object.values(systemObj);
        });

        this.markStrategies = res.data;

        if (this.markStrategies.length) {
          this.currentDomain = this.markStrategies[this.currentDomainIndex];
          this.chooseStorage(this.currentDomainIndex, this.currentDomain);
        }
      },
      // 获取存储域的存储策略
      async getCurrentDomainStrategies(id) {
        let res = await getCurrentDomainStrategies({
          domain_id: id,
        });
        if (res.code != 0) {
          this.$message.error(res.msg);
          return;
        }
        this.currentStrategy = res.data;
      },
    },
    mounted() {
      if (this.$route.query.system_id) {
        this.system_id = this.$route.query.system_id;
      }
      this.getMarkstrategiesAll();
    },
    computed: {
      ...mapGetters(['cardStyle']),
      containerClass() {
        if (
          this.requestOver &&
          this.markStrategies.length === 0 &&
          this.cardStyle
        ) {
          return 'noDomain cardContainer';
        } else if (
          (this.requestOver && this.markStrategies.length === 0) ||
          this.cardStyle
        ) {
          return this.cardStyle ? 'cardContainer' : 'noDomain';
        }

        return '';
      },
    },
    watch: {},
  };
</script>
<style lang="less" scoped>
  .userlist {
    height: 100%;
    background-color: #ebeef5;
    display: flex;
    flex-direction: column;

    .icon-span-green {
      color: #1cb54a;
      border: 1px solid #1cb54a;
      font-size: 13px;
      text-align: center;
      padding: 3px;
      border-radius: 3px;
    }

    .icon-span-red {
      color: #f56c6c;
      border: 1px solid #f56c6c;
      font-size: 13px;
      text-align: center;
      padding: 3px;
      border-radius: 3px;
    }
  }

  .no-strategy {
    min-height: 150px;
    margin: 15px;
    padding: 20px;
    border: 1px dashed #dcdfe6;
    border-radius: 5px;
  }

  .cardHeader {
    background-color: white;
  }

  .cardContainer {
    margin: 10px 10px 0 10px !important;
    border-radius: 5px !important;
    flex: 1;
    height: 0;
  }

  .DeviceCon {
    background-color: white;

    .allDevice {
      width: 100%;
      float: left;
      padding: 0 15px;
      display: flex;
      // display: grid;
      // grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
      border-bottom: 1px solid #dcdfe6;
      max-height: 50%;
      overflow-x: auto;

      .oneDevice {
        min-width: 200px;
        max-width: 250px;

        // width: calc(100% - 15px);
        height: 90px;
        border: 1px solid rgba(10, 112, 176, 0.25);
        margin: 0 15px 12px 0;
        float: left;
        cursor: pointer;
        border-radius: 4px;
        position: relative;

        .deviceHead {
          height: 40px;
          line-height: 40px;
          font-size: 15px;
          color: #303133;
          // text-align: center;
          border-bottom: 1px solid rgba(10, 112, 176, 0.25);
          white-space: nowrap;
          text-overflow: ellipsis;
          overflow: hidden;
          word-break: break-all;
          font-weight: bold;
          padding: 0 15px;
          border-radius: 5px 5px 0px 0px;
          background-color: #f5f5f5;
        }

        .deviceContent {
          padding: 0 15px;
          line-height: 50px;
        }
      }

      .oneDevice:hover {
        border-color: rgba(90, 134, 161, 0.5);
        background: #ebf5ff;
      }

      .activeChart {
        border-color: rgba(90, 134, 161, 0.5);
        background: #ebf5ff;
        box-shadow: 0px 2px 6px 0px rgba(25, 25, 25, 0.1);

        .activeDeviceHead {
          background-color: #0a70b0;
          color: #f5f5f5;
        }

        .activeDeviceContent {
          color: #0a70b0;
        }
      }
    }

    .domainCon {
      height: 300px;
      overflow: auto;
      position: relative;
    }

    .chartCon {
      width: 370px;
      height: 280px;
      cursor: pointer;
      border-radius: 4px;
      margin-right: 30px;
      position: relative;

      // box-shadow:1px 0px 6px 0px rgba(0,0,0,0.1);
      .w370 {
        width: 370px;
      }

      .h250 {
        height: 250px;
      }

      .addImgCon {
        width: 80px;
        height: 80px;
        cursor: pointer;
        margin: 0 auto;
        margin-top: 95px;
      }

      .chartState {
        width: 100%;
        text-align: center;
        position: absolute;
        bottom: 0px;
        line-height: 52px;
        font-size: 18px;
      }
    }

    .listTit {
      height: 48px;
      line-height: 48px;
      font-size: 16px;
      color: #303133;
      font-weight: 700;
      padding: 0 15px;

      .listTitIcon {
        width: 3px;
        height: 16px;
        background: #0a70b0;
        margin-right: 12px;
        margin-top: 16px;
      }

      .function-btn {
        font-weight: initial;
        margin-top: 9px;
        border: 1px solid #dcdfe6;
        font-weight: 400;
        font-size: 14px;
      }

      .loadDeviceTit {
        font-size: 15px;
      }
    }

    .strategyContent {
      padding: 10px;
      border-top: 1px dashed #dcdfe6;
      font-weight: 500;

      &-title {
        font-weight: 400;
        border-radius: 5px;
        padding: 10px;
        width: 380px;
        border: 1px dashed #dcdfe6;
      }
    }

    .deviceList {
      padding: 0 15px;
      height: calc(100% - 180px);

      .tableDiv {
        height: 100%;
        // margin-bottom:20px;
        border: 1px solid #dcdfe6;

        .organTableData {
          // min-height: 160px;
          height: 100%;

          ::v-deep th {
            background: #f9f9f9;
            color: rgb(51, 51, 51);
          }

          .el-table {
            height: 100%;
            border: none;

            ::v-deep .el-table__body-wrapper {
              min-height: 120px;
              height: calc(100% - 40px);
              // overflow-x:hidden!important;
              overflow-y: auto !important;
            }
          }

          ::v-deep .el-table-column--selection .cell {
            padding-left: 10px;
          }
        }

        .blockPage {
          text-align: center;
        }
      }
    }
  }
</style>
