<template>
  <div class="jurisdictionlist">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303"
          ><i class="iconfont icondingwei mr10"></i>智能诊断系统</span
        >
      </div>
      <div class="tr flex_1">
        <span @click="isShowinfoFn('add')" class="function-btn bg_e6 clr_ff">
          <i class="iconfont iconxinzeng"></i>新增系统
        </span>
      </div>
    </div>
    <div
      class="pacsContainer"
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-background="rgba(255,255,255,0.6)"
      v-bind:class="{ noTableData: systemList.length === 0 }"
    >
      <el-table
        :data="systemList"
        border
        stripe
        height="100%"
        ref="tableAutoScroll"
        highlight-current-row
        header-row-class-name="strong"
      >
        <el-table-column align="center" type="index" label="序号" width="50">
          <!-- <template slot-scope="scope">
                <span>{{(searchData.offset - 1) * searchData.limit + scope.$index + 1}}</span>

                </template> -->
        </el-table-column>
        <!-- <el-table-column width="180" align="left" prop="id" label="系统ID" :show-overflow-tooltip="true">
        </el-table-column> -->
        <el-table-column width="260" align="left" label="系统名称" :show-overflow-tooltip="true">
          <template slot-scope="scope">
            <img
              class="system_img"
              :src="AIM"
            />
            <span class="system_name">{{ scope.row.name }}</span>
          </template>
        </el-table-column>
           <el-table-column
          width="210"
          align="left"
          prop="admin_name"
          label="管理员"
          :show-overflow-tooltip="true"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.admin_name }}</span>
            <span> ( {{ scope.row.admin_phone }} )</span>
          </template>
        </el-table-column>
        <el-table-column
          width="320"
          align="left"
          prop="institution_names"
          label="使用机构"
          :show-overflow-tooltip="true"
        >
          <template slot-scope="scope">
            <div class="institutionName">
              <span
                v-for="(itemname, index) in scope.row.institution_names"
                :key="itemname"
                ><span v-if="index != 0">、</span>{{ itemname }}</span
              >
            </div>
          </template>
        </el-table-column>
        <el-table-column align="left" label="操作">
          <template slot-scope="scope">
            <span
              class="operateBtn manageBtn mr10"
              v-if="isShowManageBtn"
              @click="isShowinfoFn('operate', scope.row)"
              ><i class="iconfont">&#xe667;</i>管理</span
            >
            <span class="operateBtn mr10" @click="isShowinfoFn('edit', scope.row)"
              ><i class="iconfont">&#xe63d;</i>编辑</span
            >
            <span v-if="isSetUdi" class="operateBtn" @click="isShowinfoFn('aboutSystem', scope.row)"
              ><i class="iconfont">&#xe84e;</i>关于系统</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="isAiminfo"
      :show-close="false"
      :withHeader="false"
      :wrapperClosable="this.operateSystemInfo.title === '编辑' ? true : false"
      :direction="direction"
      :before-close="handleClose"
    >
      <aim-info
        ref="info"
        :pacsinfo="operateSystemInfo"
        :pageInfo="InstitutionPage"
        @closeFn="closeFn"
        @selectInstitionListFn="selectInstitionListFn"
        @selectCurRowFn="selectCurRow"
        @delInstitutionFn="delInstitutionFn"
        @changePhone="changePhone"
        @serchListFn="serchListFn"
        @getSerchName="getSerchName"
        @getAdminNameFn="getAdminNameFn"
        @pageSizeChangeFn="pageSizeChangeFn"
        @CheckOfficeidsFn="CheckOfficeidsFn"
        @submitForm="submitForm"
        @isAddInstution="isAddInstution"
        @getRowKeys="getRowKeys"
        @instclose="instclose"
      ></aim-info>
    </el-drawer>
  </div>
</template>

<script>
import Vue from "vue";
import Mgr from '@/utils/SecurityService'
import aboutSystem from 'tomtaw-system-about'
import JSEncrypt from "jsencrypt";
import { mapGetters } from "vuex";
import aimInfo from "./aimInfo"
import {
  addPacsSystems,
  getInstitutionList,
  getintellingenceOfficeList,
  getPacsSystemsInfoByid,
  putPacsSystems,
  getPasServicecList,
  getServiceTypePower,
  getCallingService,
} from "@/api/platform_costomer/institution";
import { getLoginName, getConfigurations, getLoginUserInfor, ownMenu } from "@/api/commonHttp";
export default {
  components: {
    aimInfo,
  },
  computed: {
    ...mapGetters(['isSetUdi','isShowManageBtn']),
  },
  data() {
    return {
      AIM: require("../../../assets/images/AIM.png"), // 智能诊断
      info: "",
      loading: true,
      isAiminfo: false,
      direction: "rtl",
      systemList: [],
      isactive: "",
      operateSystemInfo: {
        title: "新增智能诊断系统",
        serchName: "",
        activesystem: "",
        systemList: [{ code: "", name: "" }], // 授权产品
        isAdminname: false,
        product_name: "",
        providersObj: {
          app_id: '',
          app_secret: '',
          provider_name: 'WeChat'
        },
        formInfo: {
          type: 9,
          product_code: "AIM",
          name: "",
          admin_phone: "",
          admin_name: "",
          service_codes: [],
          providers: []
        },
        rules: {
          product_code: [
            { required: true, message: "请选择产品名称", trigger: "change" },
          ],
          name: [
            { required: true, message: "请输入系统名称", trigger: "blur" },
          ],
          admin_phone: [
            { required: true, message: "请输入管理员电话", trigger: "change" },
          ],
          admin_name: [
            { required: true, message: "请输入管理员姓名", trigger: "change" },
          ],
        },
        isChioseOrgan: false,
        institutionList: [], // 机构列表
        deplist: [],
        multipleSelection: [], // 机构列表选中机构
      },
      searchAimData: {
        contains_name: '',
        admin_info: '',
        type: 9,
      },
      isUpdate: false,
      isFirstChange: true,
      InstitutionPage: {
        eof: 1,
        page_index: 1,
        page_size: 10,
        total_count: 0,
        total_pages: 1,
      },
    };
  },
  mounted() {
    const self = this;
    self.$nextTick(() => {
      this.getAimListFn();
      // 加密函数
      this.getConfigurationsFn();
    });
  },
  methods: {
    async getConfigurationsFn() {
      const res = await getConfigurations("TransmissionSecurity.RSA.PublicKey");
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) {
          // 注册方法
          const pubKey = res.data; // ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt();
          encryptStr.setPublicKey(pubKey); // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()); // 进行加密
          return data;
        };
      }
    },
    changePhone() {
      if (this.isUpdate) {
        // 是否是第一次改变
        if (this.isFirstChange) {
          this.operateSystemInfo.formInfo.admin_phone = "";
          this.operateSystemInfo.formInfo.admin_name = "";
        }
        this.isFirstChange = false;
      }
    },
    // 系统列表
    async getAimListFn() {
      const res = await getintellingenceOfficeList(this.searchAimData);
      if (res.code === 0) {
        this.loading = false;
        this.systemList = res.data;
      } else {
        this.loading = false;
        this.$message({ type: "error", message: res.msg });
      }
    },
    isAddInstution() {
      if (!this.operateSystemInfo.formInfo.product_code) {
        this.$message({
          type: "warning",
          message: "请选择授权产品！",
        });
        return;
      }
      this.InstitutionPage.page_index = 1;
      this.InstitutionPage.page_size = 10;
      this.getInstitutionListFn();
      this.operateSystemInfo.isChioseOrgan = true;
    },
    // 点击管理处理跳转
    dealSkip(id) {
      const href = configUrl.frontEndUrl + '/intelligentDiagnosis/accessManagement/dataOverview'
      sessionStorage.setItem("system_id", id);
      window.open(href, "_blank");
      // 请求菜单的方式
      //  sessionStorage.setItem("system_id", id);
      //  this.getOwnMenu(id).then((url) => {
      //     var dev = process.env.NODE_ENV === 'development' ? true : false
      //     if (dev) {
      //       url = url.replace('/operate', '')
      //     }
      //     const {href} = this.$router.resolve({path: url, query: {system_id: id}})
      //     window.open(href, '_blank')
      //   })
    },
    // 获取菜单
    getOwnMenu(id) {
      return new Promise((resolve) => {
        ownMenu().then(res => {
          if (res.code != 0) {
            this.$message.error(res.msg)
            return
          }
          let arr = res.data.filter(item => {
            return item.system_id == id
          })
          let url
          if (arr[0].children[0].children.length != 0) {
            url = arr[0].children[0].path + arr[0].children[0].children[0].path
          } else {
            url = arr[0].children[0].path
          }
          resolve(url)
        })
      })
    },
    // 操作按钮
    isShowinfoFn(type, obj) {
      const self = this
      var id;
      var code;
      var isopen;
      if (obj) {
        id = obj.id;
        code = obj.product_code;
        isopen = obj.is_jump;
      }
      if (type === "add") {
        self.isAiminfo = true;
        self.isUpdate = false;
        self.operateSystemInfo = self.$options.data().operateSystemInfo;
        self.$nextTick(() => {
          self.$refs.info.page = 1
          self.$refs.info.size = 10
          self.$refs.info.tableData = []
          self.$refs.info.choosedInstituteArr = [];
          self.$refs.info.getTabelData2();
          self.$refs.info.$refs.qualityInstituTable.doLayout();
        });
      } else if (type === "operate") {
        // if (obj.type === 1 && !isopen) {
        //   // 只有云pacs 才需要判断
        //   self.$message({
        //     type: "error",
        //     message: "新增的系统，如需管理，请重新登录!",
        //   });
        //   return;
        // }
        if (code) {
          sessionStorage.setItem("currentSystemClass", code);
        }
        if (id) {
          sessionStorage.setItem("lastname", id);
        }
        self.dealSkip(id);
      } else if (type === "aboutSystem") { // 关于系统
           var manager = new Mgr()
         manager.getRole().then(function (item) {
          if (item) {
            aboutSystem('aim',item)
          }
         })
       }
      else {
        self.isactive = id;
        self.isAiminfo = true;
        self.isUpdate = true;
        self.isFirstChange = true;
        self.operateSystemInfo.title = "编辑";
        const responce = getPacsSystemsInfoByid(id); // 详情接口
        self.operateSystemInfo.multipleSelection = [];
        responce.then((res) => {
          if (res.code === 0) {
            self.operateSystemInfo.product_name = res.data.product_name;
            self.operateSystemInfo.formInfo.product_code =
              res.data.product_code;
            self.operateSystemInfo.formInfo.id = res.data.id;
            self.operateSystemInfo.formInfo.name = res.data.name;
            self.operateSystemInfo.formInfo.admin_phone = res.data.admin_phone;
            self.operateSystemInfo.formInfo.admin_name = res.data.admin_name;
            self.operateSystemInfo.multipleSelection = res.data.institutions;
            self.operateSystemInfo.institution_count = res.data.institution_count;
            self.operateSystemInfo.formInfo.service_codes = res.data.service_codes;
            self.operateSystemInfo.isAdminname = true;
            if (res.data.providers.length != 0) {
              self.operateSystemInfo.providersObj = res.data.providers[0];
            }
            // 获取已绑定的机构 和初始化分页
            self.$refs.info.page = 1
            self.$refs.info.size = 10
            self.$refs.info.choosedInstituteArr = res.data.institutions;
            self.$refs.info.getTabelData2();
            self.$nextTick(() => {
              self.$refs.info.$refs.qualityInstituTable.doLayout();
            });
          }
        });
      }
    },
    // 手机号姓名匹配
    async getAdminNameFn() {
      var _phone = this.operateSystemInfo.formInfo.admin_phone;
      var phoneReg = /^1[3456789]\d{9}$/;
      if (!phoneReg.test(_phone)) {
        return;
      }
      var url = `/users/lite/${_phone}`;
      var res = await getLoginName(url);
      if (res.code === 0) {
        this.operateSystemInfo.formInfo.admin_name = res.data
          ? res.data.name
          : "";
        this.operateSystemInfo.isAdminname = true;
      } else {
        this.operateSystemInfo.isAdminname = false;
        this.operateSystemInfo.formInfo.admin_name = "";
      }
    },
    handleClose(done) {
      done();
    },
    // 关闭 选择机构
    instclose() {
      this.operateSystemInfo.institutionList.forEach((item) => {
        this.$nextTick(() => {
          this.$refs.info.$refs.institutions.toggleRowSelection(item, false);
        });
      });
      this.operateSystemInfo.isChioseOrgan = false;
    },
    closeFn() {
      var info = {
        type: "cancel",
        refs: this.$refs["info"].$refs,
        formName: "formInfo",
      };
      this.submitForm(info);
    },
    // 获取机构列表
    async getInstitutionListFn() {
      const self = this;
      let filter_system_id = "";
      if (this.operateSystemInfo.title !== "新增智能诊断系统") {
        filter_system_id = "&filter_system_id=" + this.isactive;
      }
      // 机构的获取 云pacs 跟 集中预约有区别的
        const _url =
        "/institutions?is_show_office=true" +
        "&offset=" +
        this.InstitutionPage.page_index +
        "&limit=" +
        this.InstitutionPage.page_size +
        "&name=" +
        this.operateSystemInfo.serchName +
        filter_system_id;
      const res = await getInstitutionList(_url);
      self.$nextTick(() => {
        self.$refs.info.$refs.institutions.clearSelection();
      })
      if (res.code === 0) {
        res.data.forEach((item) => {
          item.office_ids = [];
          if (item.offices.length === 1) {
            item.office_ids[0] = item.offices[0].id;
          }
        });
        self.operateSystemInfo.institutionList = res.data;
        self.InstitutionPage = res.page;
        if (self.operateSystemInfo.title === "编辑") {
          // 勾上已选中的
          res.data.forEach((itemids) => {
            self.operateSystemInfo.multipleSelection.forEach((item) => {
              if (itemids.id === item.id) {
                self.$nextTick(() => {
                  self.$refs.info.$refs.institutions.toggleRowSelection(
                    itemids,
                    true
                  );
                });
                itemids.office_ids = item.office_ids;
              }
            });
          });
        }
      }
    },
    getRowKeys(row) {
      return row.id;
    },
    // 分页
    pageSizeChangeFn(info) {
      this.InstitutionPage.page_index = info.page;
      this.InstitutionPage.page_size = info.limit;
      this.getInstitutionListFn();
    },
    // 选中某一行
    selectCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === row.id) {
            self.operateSystemInfo.multipleSelection.splice(i, 1);
          }
        });
      }
    },
    // 去掉数组元素 里面对象 id值相同的
    clearCommonId(arr) {
      let obj = {};
      let peon = arr.reduce((cur, next) => {
        obj[next.id] ? "" : (obj[next.id] = true && cur.push(next));
        return cur;
      }, []);
      return peon;
    },
    handleInstituSelectionChange(val) {
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    // 机构 select change事件
    selectInstitionListFn(val) {
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    CheckOfficeidsFn(val) {
      // console.log(val)
    },
    delInstitutionFn(id) {
      this.$confirm("是否删除这条机构信息？", "删除信息", {
        distinguishCancelAndClose: true,
        confirmButtonText: "删除",
        cancelButtonText: "取消",
      }).then(() => {
        this.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === id) {
            if (this.operateSystemInfo.institutionList.length > 0) {
              this.$refs.info.$refs.institutions.toggleRowSelection(
                item,
                false
              );
            }
            this.operateSystemInfo.multipleSelection.splice(i, 1);
            this.$message({
              type: "success",
              message: "删除成功",
            });
          }
        });
      });
    },
    async addAimSystemsFn() {
      const loading = this.$loading({
        lock: true,
        text: this.operateSystemInfo.formInfo.id ? "正在编辑，请稍等..." : "正在新增，请稍等...",
        spinner: "el-icon-loading",
        background: "rgba(255, 255, 255, 0.6)",
      });
      const _params = this.operateSystemInfo.formInfo;
      var _institutionList = [];
      this.operateSystemInfo.multipleSelection.forEach((item) => {
        var info = {};
        info.id = item.id;
        info.office_ids = item.office_ids;
        _institutionList.push(info);
      });
      _params.institutions = _institutionList;
      _params.providers = []
      _params.providers.push(this.operateSystemInfo.providersObj)
      // 对手机号加密
      var adminPhone = _params.admin_phone;
      _params.admin_phone = this.$getRsaCode(_params.admin_phone);
      var res = null;
      var tipmsg = "新增智能诊断系统成功！";

      if (_params.id) {
        delete _params['type']
        res = await putPacsSystems(_params);
        tipmsg = "修改智能诊断系统成功！";
      } else {
        res = await addPacsSystems(_params);
      }
      loading.close();
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: tipmsg,
        });
        this.isAiminfo = false;
        this.getAimListFn();
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      } else {
        this.operateSystemInfo.formInfo.admin_phone = adminPhone;
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    getSerchName(val) {
      this.operateSystemInfo.serchName = val;
    },
    // 选择机构页面 查询按钮
    async serchListFn() {
      const _url =
        "/institutions?office_type=2&product_code=" +
        this.operateSystemInfo.formInfo.product_code +
        "&offset=1" +
        "&limit=" +
        this.InstitutionPage.page_size +
        "&name=" +
        this.operateSystemInfo.serchName;
      const res = await getInstitutionList(_url);
      if (res.code === 0) {
        this.operateSystemInfo.institutionList = res.data;
      }
    },
    submitForm(info) {
      if (info.type === "commit") {
        if (!this.operateSystemInfo.formInfo.name) {
          this.$message({ type: "error", message: "请输入系统名称" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.admin_phone) {
          this.$message({ type: "error", message: "请输入管理员电话" });
          return;
        }
        var phoneReg = /^1[3456789]\d{9}$/;
        // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
        if (!this.isUpdate || (this.isUpdate && !this.isFirstChange)) {
          if (!phoneReg.test(this.operateSystemInfo.formInfo.admin_phone)) {
            this.$message({
              message: "请输入正确的手机号码!",
              type: "warning",
            });
            return false;
          }
        }
        if (!this.operateSystemInfo.formInfo.admin_name) {
          this.$message({ type: "error", message: "请输入管理员姓名" });
          return;
        }
        if (info.hasOwnProperty('choosedInstituteArr')) { // 智能诊断
          this.operateSystemInfo.multipleSelection = JSON.parse(JSON.stringify(info.choosedInstituteArr));
        }
        this.addAimSystemsFn();
      } else {
        this.isAiminfo = false;
        this.isactive = "";
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      }
    },
  },
};
</script>

<style lang="less" scoped>
.jurisdictionlist {
  height: 100%;
  .pacsContainer {
    height: calc(100% - 47px);
    padding: 10px 15px;
    overflow: auto;
    position: relative;
    ::v-deep .el-table__body-wrapper {
      height: calc(100% - 40px) !important;
      overflow: auto;
    }
    .system_img {
      width: 36px;
      float: left;
      margin-right: 10px;
    }
    .system_name {
      line-height: 36px;
      font-size: 16px;
      color: #303133;
    }
    .operateBtn {
      display: inline-block;
      cursor: pointer;
      height: 32px;
      line-height: 30px;
      padding: 0 10px;
      font-size: 15px;
      color: #0a70b0;
      border: 1px solid #ebeef5;
      border-radius: 3px;
      i {
        padding-right: 4px;
      }
    }
    .manageBtn {
      background: #0a70b0;
      color: #fff;
      border: 1px solid #0a70b0;
    }
  }
}
.adminInfor {
  width: 50%;
  max-width: 170px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.institutionName {
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
@media screen and (max-width: 1500px) {
  .list-item {
    width: calc(50% - 20px) !important;
  }
}
.borderNone {
  border: none !important;
}
</style>
