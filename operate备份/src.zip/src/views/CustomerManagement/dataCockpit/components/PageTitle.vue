<template>
  <div class="title">
    <div class="title-input" v-if="titleInputVisible">
      <el-input
        v-model="localTitle"
        placeholder="请输入内容"
        @blur="changeTitle"
        v-focus
      ></el-input>
    </div>
    <div class="title-text" :style="autoStyle" v-else @click="titleInputVisible = true">
      {{ localTitle }}
    </div>
    <!-- <div class="remark">(注: 本屏非真实数据)</div> -->
  </div>
</template>
<script>
export default {
  directives: {
    focus: {
      inserted(el) {
        const input = el.childNodes[1]
        input.focus()
      }
    }
  },
  props: {
    title: {
      type: String,
      required: true
    },
    initSize: {
      type: Number
    },
    initMax: {
      type: Number
    },
    width: {
      type: Number
    },
    letterSpace: {
      type: Number
    }
  },
  data(){
    return {
      titleInputVisible: false,
      localTitle: this.title
    }
  },
  computed: {
    autoStyle() {
      // const length = this.title.length
      // const initMax = this.initMax
      // const initSize = this.initSize
      // let fontSize = initSize

      // if(length > initMax) {
      //   fontSize = Math.floor((this.width-this.letterSpace *length) / length)
      //   if(fontSize < 24) {
      //     fontSize = 24
      //   }
      // }
      // return {
      //   fontSize: fontSize + 'px'
      // }


    }
  },
  watch: {
    title(value) {
      this.localTitle = value
    }
  },
  methods: {
    changeTitle() {
      if(this.localTitle === '') {
        this.$message.error('大屏名称不能为空')
        return
      }
      this.titleInputVisible = false
      this.$emit('updateTitle', this.localTitle)
    }
  }
}
</script>
<style lang="less" scoped>
.title{
  position: relative;
}
.title-text {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
.remark{
  font-size: 14px;
  position: absolute;
  line-height: 24px;
  bottom: 2px;
  text-align: center;
  width: 100%;
}
::v-deep .title-input {
  width: 100%;
  height: 100%;
  .el-input {
    width: 100%;
    height: 100%;
    vertical-align: top;
    input {
      width: 100%;
      height: 50px;
      line-height: 50px;
      font-size: 22px;
    }
  }
}
</style>
