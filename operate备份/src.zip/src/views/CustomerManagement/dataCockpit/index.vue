<template>
  <div>
    <component v-bind:is="dataCockpitName"></component>
  </div>
</template>
<script>
// import Mgr from '@/utils/SecurityService'

export default {
  components: {
    'anji': () => import('./index/anji'),
    'jinhua1': () => import('./index/jinhua1'),
    'jinhua2': () => import('./index/jinhua2'),
    'wuhanertong': () => import('./index/wuhanertong'),
    'wuhanzhongxin': () => import('./index/wuhanzhongxin'),
    'wuhanyiliaoyun': () => import('./index/wuhanyiliaoyun'),
    'wuhanyiliaoyunStatic': () => import('./index/wuhanyiliaoyunStatic'),
    'yinzhouzhikong': () => import('./index/yinzhouzhikong'),
   },
  data() {
    return {
      dataCockpitName: ''
    }
  },
  created () {
  },
  async mounted() {
    var tenancy_id
    tenancy_id = this.$route.query.tenancy_id
    // var manager = new Mgr()
    // const item = await manager.getRole()
    // if (item && item.profile && item.profile.tenancy_id) {
    //   tenancy_id = sessionStorage.getItem('curTenancyId') || item.profile.tenancy_id
    // }
    let dataCockpitName = ''
    switch (_dataCockpitName){
      case 'anji':
        dataCockpitName = 'anji'
        break
      case 'jinhua':
        if(tenancy_id === '1386931148638130176') {
          dataCockpitName = 'jinhua1'
        }else if( tenancy_id === '1386934797309317120') {
          dataCockpitName= 'jinhua2'
        } 
        else if (tenancy_id === '1288720863696261120') { // 自己测试加的 对应的是15600000000帐号
          dataCockpitName = 'jinhua1'
        }
        break
      case 'wuhanertong':
        dataCockpitName = 'wuhanertong'
        break
      case 'wuhanzhongxin':
        dataCockpitName = 'wuhanzhongxin'
        break
      case 'wuhanyiliaoyun':
        dataCockpitName = 'wuhanyiliaoyun'
        break
      case 'wuhanyiliaoyunStatic':
        dataCockpitName = 'wuhanyiliaoyunStatic'
        break
      case 'yinzhouzhikong':
      dataCockpitName = 'yinzhouzhikong'
        break
    }
    this.dataCockpitName = dataCockpitName
    // this.dataCockpitName = 'jinhua2'
    document.title = '客户管理-数据驾驶舱'
  }
}
</script>
