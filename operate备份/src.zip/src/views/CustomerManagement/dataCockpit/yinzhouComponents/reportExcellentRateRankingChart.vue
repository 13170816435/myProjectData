<template>
  <common-box :title="headTit" subTitle="">
    <div slot="chart" class="chart" ref="chart"></div>
  </common-box>
</template>

<script>
import * as echarts from "echarts";
import commonBox from "./commonBox.vue";
import { dynamicInvoke } from "@/api/dataapi";
import Big from "big.js";
export default {
  components: {
    commonBox,
  },
  props: {
    params: {
      type: Object,
      default: () => {},
    },
    bussinessType: String,
    activeBtnValue: String,
  },
  data() {
    return {
      headTit: '报告阳性率',
      myChart: null,
      chartData: [],
      lineColorArr: [
        "#61C178",
        "#FEB822",
        "#3BA1FF",
        "#DB6BCF",
        "#FA8B54",
        "#4435FF",
        "#1D9ED1",
        "#FF4500",
        "#EB4185",
        "#327039",
        "#00D87F",
        "#DA4A4A",
        "#67C23A",
        "#2FB8FC",
      ],
      moreLineColorArr: [
        { textColor: "#61C178", areaColor: "255,193,120" },
        { textColor: "#FEB822", areaColor: "255,184,34" },
        { textColor: "#3BA1FF", areaColor: "59,161,255" },
        { textColor: "#DB6BCF", areaColor: "219,107,207" },
        { textColor: "#FA8B54", areaColor: "250,139,84" },
        { textColor: "#4435FF", areaColor: "68,53,255" },
        { textColor: "#1D9ED1", areaColor: "29,158,209" },
        { textColor: "#FF4500", areaColor: "255,69,0" },
        { textColor: "#EB4185", areaColor: "235,65,133" },
        { textColor: "#327039", areaColor: "50,112,57" },
        { textColor: "#00D87F", areaColor: "0,216,127" },
        { textColor: "#DA4A4A", areaColor: "218,74,74" },
        { textColor: "#67C23A", areaColor: "103,194,58" },
        { textColor: "#2FB8FC", areaColor: "47,184,252" },
      ],
    };
  },
  created () {
    if (this.bussinessType == 'reportYXRate') {
      this.headTit = '报告阳性率'
    } else if (this.bussinessType == 'imageRate') {
      this.headTit = '影像优良率'
    } else{
      this.headTit = '诊断符合率'
    }
  },
  mounted() {},
  methods: {
    initMoreLineChartSeries(item, nth) {
      const self = this
      var index = 0
      if (nth>=14) {
        index = Math.floor(Math.random()*14)
      } else {
        index = nth
      }
      //console.log(index,self.moreLineColorArr[index].areaColor)
      return {
        name: item.name || item.label,
        type: "line",
        data: item.data,
        symbolSize: 8,
        symbol: "emptyCircle",
        lineStyle: {
          width: 2,
          // color: "#2E9DE1",
        },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            {
              offset: 0,
              color: `rgba(${self.moreLineColorArr[index].areaColor},0)`,
            },
            {
              offset: 1,
              color: `rgba(${self.moreLineColorArr[index].areaColor},0.5)`,
            },
          ]),
        },
      };
    },
    // 将orgName相同的归类
    dealArray (list, key) {
      var keysArr = list.map(item=>item[key])
      var keys = [...new Set(keysArr)]
      var newList = keys.map(item=> {
        return {
          [key]: item,
          list: list.filter(i=>i[key] == item)
        }
      })
      return newList
    },
    async refreshChart() {
      const self = this;
      let res = null
      if (self.activeBtnValue == 'RIS') { // 放射
        if (self.bussinessType == 'reportYXRate') { // 有了
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1001',self.params)
        }
        else if (self.bussinessType == 'imageRate') { // 有了
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1002',self.params)
        }
      } else if (self.activeBtnValue == 'UIS' || self.activeBtnValue == 'EIS') { // 超声和内镜
        if (self.bussinessType == 'imageRate') { // 用回放射的接口
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1002',self.params)
        }
      }
      let yData = []
      let xData = []
      //res = {"code":0,"msg":"请求成功","data":[{"itemType":"CR","orgName":"其它","reportNum":"2517","badnessNum":"1043","ratio":"0.4144"},{"itemType":"CR","orgName":"鄞州二院医共体","reportNum":"3421","badnessNum":null,"ratio":"0.0"},{"itemType":"CR","orgName":"鄞州人民医院医共体","reportNum":"2","badnessNum":"1","ratio":"0.5"},{"itemType":"CT","orgName":"其它","reportNum":"182648","badnessNum":"140070","ratio":"0.7669"},{"itemType":"CT","orgName":"鄞州二院医共体","reportNum":"703132","badnessNum":"439623","ratio":"0.6252"},{"itemType":"CT","orgName":"鄞州人民医院医共体","reportNum":"113974","badnessNum":"86891","ratio":"0.7624"},{"itemType":"DR","orgName":"其它","reportNum":"285585","badnessNum":"137080","ratio":"0.48"},{"itemType":"DR","orgName":"鄞州二院医共体","reportNum":"707826","badnessNum":"204047","ratio":"0.2883"},{"itemType":"DR","orgName":"鄞州人民医院医共体","reportNum":"257889","badnessNum":"116136","ratio":"0.4503"},{"itemType":"DSA","orgName":"鄞州二院医共体","reportNum":"1648","badnessNum":"1403","ratio":"0.8513"},{"itemType":"DXA","orgName":"鄞州二院医共体","reportNum":"5502","badnessNum":"2886","ratio":"0.5245"},{"itemType":"MG","orgName":"鄞州二院医共体","reportNum":"3123","badnessNum":"2911","ratio":"0.9321"},{"itemType":"MR","orgName":"其它","reportNum":"11334","badnessNum":"9631","ratio":"0.8497"},{"itemType":"MR","orgName":"鄞州二院医共体","reportNum":"58689","badnessNum":"41049","ratio":"0.6994"},{"itemType":"PX","orgName":"其它","reportNum":"356","badnessNum":"171","ratio":"0.4803"},{"itemType":"RF","orgName":"其它","reportNum":"37","badnessNum":"7","ratio":"0.1892"},{"itemType":"RF","orgName":"鄞州二院医共体","reportNum":"1186","badnessNum":"922","ratio":"0.7774"}],"page":null}
      if (res && res.code == 0) {

        // if (self.bussinessType == 'reportRate') {
        //   let result = []
        //   if (activeBtnValue == 'RIS') {
        //     result = [{"itemType":"CT","orgName":"百丈街道社区卫生服务中心","reportNum":"52","badnessNum":"44","ratio":"0.8462"},{"itemType":"CT","orgName":"东柳街道社区卫生服务中心","reportNum":"4428","badnessNum":"3750","ratio":"0.8469"},{"itemType":"CT","orgName":"宋诏桥医院","reportNum":"6620","badnessNum":"5496","ratio":"0.8302"},{"itemType":"CT","orgName":"明楼街道社区卫生服务中心","reportNum":"1100","badnessNum":"983","ratio":"0.8936"},{"itemType":"DR","orgName":"潘火社区卫生服务中心","reportNum":"24877","badnessNum":"11593","ratio":"0.466"},{"itemType":"CT","orgName":"潘火社区卫生服务中心","reportNum":"11671","badnessNum":"9240","ratio":"0.7917"},{"itemType":"DR","orgName":"百丈街道社区卫生服务中心","reportNum":"13625","badnessNum":"7653","ratio":"0.5617"},{"itemType":"PX","orgName":"宁波市鄞州区第三医院","reportNum":"266","badnessNum":"123","ratio":"0.4624"},{"itemType":"DR","orgName":"东柳街道社区卫生服务中心","reportNum":"16973","badnessNum":"5696","ratio":"0.3356"},{"itemType":"DR","orgName":"云龙镇卫生院","reportNum":"12601","badnessNum":"4698","ratio":"0.3728"},{"itemType":"CT","orgName":"咸祥中心卫生院","reportNum":"32141","badnessNum":"26067","ratio":"0.811"},{"itemType":"MR","orgName":"宁波市钱湖医院","reportNum":"10740","badnessNum":"9163","ratio":"0.8532"},{"itemType":"CT","orgName":"白鹤街道社区卫生服务中心","reportNum":"241","badnessNum":"219","ratio":"0.9087"},{"itemType":"CT","orgName":"宁波市鄞州区第三医院","reportNum":"75980","badnessNum":"60139","ratio":"0.7915"},{"itemType":"DR","orgName":"咸祥中心卫生院","reportNum":"44988","badnessNum":"19329","ratio":"0.4296"},{"itemType":"CT","orgName":"鄞州区首南街道社区卫生服务中心","reportNum":"2202","badnessNum":"1881","ratio":"0.8542"},{"itemType":"CT","orgName":"瞻岐镇卫生院","reportNum":"17664","badnessNum":"15192","ratio":"0.8601"},{"itemType":"DR","orgName":"塘溪镇卫生院","reportNum":"11275","badnessNum":"6570","ratio":"0.5827"},{"itemType":"DR","orgName":"白鹤街道社区卫生服务中心","reportNum":"19368","badnessNum":"10021","ratio":"0.5174"},{"itemType":"DR","orgName":"东部新城社区卫生服务中心","reportNum":"15747","badnessNum":"5587","ratio":"0.3548"},{"itemType":"CT","orgName":"宁波市钱湖医院","reportNum":"68727","badnessNum":"48575","ratio":"0.7068"},{"itemType":"DR","orgName":"邱隘中心卫生院","reportNum":"33607","badnessNum":"17328","ratio":"0.5156"},{"itemType":"DR","orgName":"瞻岐镇卫生院","reportNum":"11140","badnessNum":"5560","ratio":"0.4991"},{"itemType":"CR","orgName":"宁波市钱湖医院","reportNum":"332","badnessNum":"95","ratio":"0.2861"},{"itemType":"DR","orgName":"宁波市鄞州区第三医院","reportNum":"101505","badnessNum":"44016","ratio":"0.4336"},{"itemType":"RF","orgName":"宁波市鄞州区第三医院","reportNum":"39","badnessNum":"7","ratio":"0.1795"}]
        //   }
        //   if (activeBtnValue == 'ECG') {
        //     result = [{"itemType":"DR","orgName":"鄞州区首南街道社区卫生服务中心","reportNum":"3752","badnessNum":"2071","ratio":"0.552"},,{"itemType":"MR","orgName":"宁波市鄞州区第三医院","reportNum":"508","badnessNum":"410","ratio":"0.8071"},{"itemType":"CR","orgName":"百丈街道社区卫生服务中心","reportNum":"3","badnessNum":"3","ratio":"1.0"},]
        //   }
          
        //   var newList = self.dealArray(result, 'orgName')
        // } else {
        //   var newList = self.dealArray(res.data, 'orgName')
        // }

        var newList = self.dealArray(res.data, 'orgName')
        if (newList.length != 0) {
          var firstItemList = newList[0].list
          if (firstItemList.length != 0) {
            xData = firstItemList.map((nth) => {
              if (this.bussinessType != 'diagnosisRate') {
                return nth.itemType
              }
              else {
                return nth.patientType
              }
            })
          }
          let otherObj = null
          newList.forEach((one) => {
            let obj = {
              name: one.orgName,
              data: one.list.map((item)=> {
                return  Big(item.ratio).times(100).toString()
              })
            }
            // 目的就是把机构 "其它" 放到最后面去
            if (one.orgName == '其它') {
              otherObj = JSON.parse(JSON.stringify(obj))
            } else {
              yData.push(obj)
            }
          })
          // 目的就是把机构 "其它" 放到最后面去
          if (otherObj) {
            yData.push(otherObj)
          }
          // console.log(yData)
        }
      } else {
        self.$message.error(res.msg);
      }
      if (!self.myChart) {
        self.myChart = echarts.init(self.$refs.chart, "dark");
      }
      let series = [];
    
      // const xData = ["2022-08", "2022-09", "2022-10", "2022-11", "2022-12"];
      // const yData = [
      //   { data: ['10', '20', '30', '20', '50'], name: "放射科" },
      //   { data: ['5', '10', '20', '10', '30'], name: "心电科" },
      //   { data: ['20', '50', '40', '40', '60'], name: "超声科" },
      // ];
      yData.forEach((item, index) => {
        let seriesItem = self.initMoreLineChartSeries(item, index); //初始化 series里面的配置和赋值相应的数据
        series.push(seriesItem);
      });

      const option = {
        color: [],
        backgroundColor: "",
        legend: {
          icon: "circle",
          top: "0%",
          right: "0%",
          itemWidth: 12,
          // itemGap: 40,
          textStyle: {
            color: "#fff",
          },
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            label: {
              show: true,
              backgroundColor: "#fff",
              color: "#556677",
              borderColor: "rgba(0,0,0,0)",
              shadowColor: "rgba(0,0,0,0)",
              shadowOffsetY: 0,
            },
            lineStyle: {
              width: 0,
            },
          },
          backgroundColor: "#fff",
          textStyle: {
            color: "#5c6c7c",
          },
          padding: [10, 10],
          extraCssText: "box-shadow: 1px 0 2px 0 rgba(163,163,163,0.5)",
          // formatter:function(params){
          //   var res = '';
          //   for(var i = 0; i < params.length; i++){
          //       res += params[i].seriesName + '(' + params[i].name + ')：' + params[i].value+ '%'  + '\n';
          //   }
          //   return res;
          // },
        },
        grid: {
          top: "35px",
          left: "0px",
          right: "0px",
          bottom: "0px",
          containLabel: true,
        },
        xAxis: [
          {
            type: "category",
            //boundaryGap: false,// 该参数就是控制区域面积是否延申到y轴
            data: xData,
            axisLabel: {
              interval: 0,
              color: "#fff",
              align: "center",
            },
            axisTick: {
              show: false,
            },
            axisLine: {
              //y轴线的颜色以及宽度
              show: true,
              lineStyle: {
                color: "rgba(255,255,255,.1)",
                width: 1,
                type: "solid",
              },
            },
          },
        ],
        yAxis: [
          {
            min: 0,
            max: 100,
            type: "value",
            axisTick: {
              show: false,
            },
            axisLabel: {
              textStyle: {
                color: "rgba(255,255,255,.5)",
              },
              formatter: "{value}%",
            },
            splitLine: { show: false },
            axisLine: {
              //y轴线的颜色以及宽度
              show: true,
              lineStyle: {
                color: "rgba(255,255,255,.1)",
                width: 1,
                type: "solid",
              },
            },
          },
        ],
        series: series,
        // series: [
        //   {
        //     name: "所得税",
        //     type: "line",
        //     data: ['40', '30', '60','50'],
        //     symbolSize: 8,
        //     symbol: "emptyCircle",
        //     lineStyle: {
        //       width: 2,
        //       color: "#2E9DE1",
        //     },
        //     areaStyle: {
        //       color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
        //         {
        //           offset: 0,
        //           color: "#0098F7",
        //         },
        //         {
        //           offset: 1,
        //           color: "rgba(0,0,0,0)",
        //         },
        //       ]),
        //     },
        //     itemStyle: {
        //       normal: {
        //         color: "#2E9DE1",
        //         borderColor: "#2E9DE1",
        //       },
        //     },
        //   },
        //   {
        //     name: "增值税",
        //     type: "line",
        //     data: ['25', '40', '30','60',],
        //     symbolSize: 8,
        //     symbol: "emptyCircle",
        //     lineStyle: {
        //       width: 2,
        //       color: "#F8DC66",
        //     },
        //     areaStyle: {
        //       color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
        //         {
        //           offset: 0,
        //           color: "#C69A0A",
        //         },
        //         {
        //           offset: 1,
        //           color: "rgba(255,255,255,0)",
        //         },
        //       ]),
        //     },
        //     itemStyle: {
        //       normal: {
        //         color: "#F8DC66",
        //         borderColor: "#F8DC66",
        //       },
        //     },
        //   },
        //   {
        //     name: "工资税",
        //     type: "line",
        //     data: ['25', '20', '50','28',],
        //     symbol: "emptyCircle",
        //     lineStyle: {
        //       width: 2,
        //       color: "#F8DC66",
        //     },
        //     areaStyle: {
        //       color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
        //         {
        //           offset: 0,
        //           color: "#C69A0A",
        //         },
        //         {
        //           offset: 1,
        //           color: "rgba(203,255,255,0)",
        //         },
        //       ]),
        //     },
        //     itemStyle: {
        //       normal: {
        //         color: "#F8DC66",
        //         borderColor: "#F8DC66",
        //       },
        //     },
        //   },
        // ],
      };
      option.color = self.lineColorArr;
      option && this.myChart.setOption(option,{ notMerge: true });
    },
  },
  destroyed() {
    if (!this.myChart) {
      return;
    }
    this.myChart.dispose();
    this.myChart = null;
  },
};
</script>

<style lang="scss" scoped>
.chart {
  width: 100%;
  height: 100%;
}
</style>
