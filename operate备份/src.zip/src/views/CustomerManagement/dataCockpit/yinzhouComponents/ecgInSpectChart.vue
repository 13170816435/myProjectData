<template>
  <common-box :title="headTit" subTitle="">
    <div slot="chart" class="chart" ref="chart"></div>
  </common-box>
</template>

<script>
import * as echarts from "echarts";
import commonBox from "./commonBox.vue";
import { dynamicInvoke } from "@/api/dataapi";
import Big from "big.js";
import { relativeTimeRounding } from "moment";
export default {
  components: {
    commonBox,
  },
  props: {
    params: {
      type: Object,
      default: () => {},
    },
    inspectType: String,
    activeBtnValue: String,
  },
  data() {
    return {
      headTit: '预约检查人次(人次)',
      myChart: null,
      chartData: [],
    };
  },
  created () {
    if (this.activeBtnValue == 'ECG') { // 心电
      if (this.inspectType == 'inspectWait') {
        this.headTit = '检查等待平均耗时(分钟)'
      }
      if (this.inspectType == 'inspectReport'){
        this.headTit = '检查报告平均耗时(分钟)'
      }
    }
    
  },
  mounted() {
    
  },
  methods: {
    initMoreBarChartSeries(item, nth, xdataLength) {
      var colorArr = [
        {
          top: '#1BB54A',//绿色
          bottom: '#11D4B6',
        },
        {
          top: '#FDB200',//黄色
          bottom: '#FFE800'
        },
        {
          top: '#004CFF',//蓝色
          bottom: '#1CDAE4'
        },
        {
          top: '#ff6958',//蓝色
          bottom: '#ff7d6f'
        }
      ];
      var index = 0
      if (nth>=4) {
        index = Math.floor(Math.random()*4)
      } else {
        index = nth
      }
      let barWidth = 30
      if (xdataLength==4) {
        barWidth = 28
      }
      if (xdataLength>=5) {
        barWidth = 25
      }
      return {
        name: item.name || item.label,
            type: "bar",
            emphasis: {
              focus: "series",
            },
            barWidth: barWidth,
            // barGap: 20, 
            label: {
              normal: {
                show: true,
                position: "top",
                formatter: function (data) {
                  // return data.value + "分钟";
                  return data.value;
                },
                color: colorArr[index].bottom,
                fontFamily: "PingFangSC-Medium",
                fontWeight: 500,
              },
            },
            data: item.data,
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
                { offset: 1, color: colorArr[index].bottom },
                { offset: 0, color: colorArr[index].top },
              ]),
            },
      };
    },
    // 将orgName相同的归类
    dealArray (list, key) {
      var keysArr = list.map(item=>item[key])
      var keys = [...new Set(keysArr)]
      var newList = keys.map(item=> {
        return {
          [key]: item,
          list: list.filter(i=>i[key] == item)
        }
      })
      return newList
    },
    async refreshChart() {
      const self = this
      //echarts.init(self.$refs.chart).dispose() 
      let res = null
      let option = null
      if (self.inspectType == 'inspectWait') {
        res = await dynamicInvoke('YZ-Area-Quality-YWScreen-ECG_1005',self.params)
      }
      if (self.inspectType == 'inspectReport') {
        res = await dynamicInvoke('YZ-Area-Quality-YWScreen-ECG_1006',self.params)
      }
      let yData = []
      let xData = []
      if (res.code == 0) {
        var newList = self.dealArray(res.data, 'orgName')
        if (newList.length != 0) {
          var firstItemList = newList[0].list
          if (firstItemList.length != 0) {
            xData = firstItemList.map((nth) => {
              if(self.inspectType == 'inspectWait') {
                return nth.patientType
              }
              else if ( self.inspectType == 'inspectReport') {// 检查报告
                return nth.itemClass
              }
              else if (self.inspectType == 'inspectOrder') { //检查预约
                return nth.state 
              }
              else if (self.inspectType == 'criticaValue') { // 危急值通报
                return nth.critState 
              }
            })
          }
          let otherObj = null
          newList.forEach((one) => {
            let obj = {
              name: one.orgName,
              data: one.list.map((item)=> {
                if(self.inspectType == 'inspectWait') {
                  return item.examTime
                } else if (self.inspectType == 'inspectReport') {
                  return item.reportTime
                } else if (self.inspectType == 'inspectOrder') {
                  return item.totalNum 
                } else if (self.inspectType == 'criticaValue') {
                  return item.totalNum 
                }
                
              })
            }
            // 目的就是把机构 "其它" 放到最后面去
            if (one.orgName == '其它') {
              otherObj = JSON.parse(JSON.stringify(obj))
            } else {
              yData.push(obj)
            }
          })
          // 目的就是把机构 "其它" 放到最后面去
          if (otherObj) {
            yData.push(otherObj)
          }
        }
      } else {
        self.$message.error(res.msg);
      }
      if (!self.myChart) {
        self.myChart = echarts.init(self.$refs.chart, "dark");
      }
      let series = [];
      // const xData = ["门诊", "住院",'test1','未知'];
      // const yData = [
      //   { data: [188, 180,160, 40,30], name: "宁波第六医院" },
      //   { data: [33, 20,40,30,60], name: "鄞州区第二医院" },
      //   { data: [33, 20,80,50,80], name: "其它" },
      // ];
      yData.forEach((item, index) => {
        let seriesItem = self.initMoreBarChartSeries(item, index, xData.length); //初始化 series里面的配置和赋值相应的数据
        series.push(seriesItem);
      });
      option = {
        backgroundColor: "",
        tooltip: {// 提示里面 的圆圈颜色有点偏淡 是因为柱状图设置了渐变色
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        legend: {
          itemWidth: 10,
          itemHeight: 10,
          top: "0%",
          right: "0%",
        },
        grid: {
          top: "35px",
          left: "0px",
          right: "0px",
          bottom: "0px",
          containLabel: true,
        },
        xAxis: [
          {
            type: "category",
            data: xData,
            axisLabel: {
              interval: 0,
              color: "#fff",
            },
            axisTick: {
              show: false,
            },
            axisLine: {
              //y轴线的颜色以及宽度
              show: true,
              lineStyle: {
                color: "rgba(255,255,255,.1)",
                width: 1,
                type: "solid",
              },
            },
          },
        ],
        yAxis: [
          {
            type: "value",
            // min: 0,
            // name: "分钟",
            nameTextStyle: {
              nameLocation: "start",
            },
            axisLabel: {
              textStyle: {
                color: "rgba(255,255,255,.5)",
              },
            },
            splitLine: { show: false },
            axisLine: {
              //y轴线的颜色以及宽度
              show: true,
              lineStyle: {
                color: "rgba(255,255,255,.1)",
                width: 1,
                type: "solid",
              },
            },
          },
        ],
        series: series,
        // series: [
        //   {
        //     name: "对外收入",
        //     type: "bar",
        //     emphasis: {
        //       focus: "series",
        //     },
        //     barWidth: 40,
        //     label: {
        //       normal: {
        //         show: true,
        //         position: "top",
        //         formatter: function (data) {
        //           return data.value + "分钟";
        //         },
        //         color: "#11D4B6",
        //         fontFamily: "PingFangSC-Medium",
        //         fontWeight: 500,
        //       },
        //     },
        //     data: [188.82, 180, 200, 260],
        //     itemStyle: {
        //       color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
        //         { offset: 1, color: "#11D4B6" },
        //         { offset: 0, color: "#1BB54A" },
        //       ]),
        //     },
        //   },
        //   {
        //     name: "对内收入",
        //     type: "bar",
        //     stack: "Ad",
        //     emphasis: {
        //       focus: "series",
        //     },
        //     barWidth: 40,
        //     label: {
        //       normal: {
        //         show: true,
        //         position: "top",
        //         formatter: function (data) {
        //           return data.value + "分钟";
        //         },
        //         color: "#FFE700",
        //         fontFamily: "PingFangSC-Medium",
        //         fontWeight: 500,
        //       },
        //     },
        //     data: [33.45, 20, 50, 100],
        //     itemStyle: {
        //       color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
        //         { offset: 1, color: "#FFE800" },
        //         { offset: 0, color: "#FDB200" },
        //       ]),
        //     },
        //   },
        // ],
      };
      option && this.myChart.setOption(option,{ notMerge: true });
    },
  },
  destroyed() {
    if (!this.myChart) {
      return;
    }
    this.myChart.dispose();
    this.myChart = null;
  },
};
</script>

<style lang="scss" scoped>
.chart {
  width: 100%;
  height: 100%;
}
</style>
