<template>
  <common-box :title="headTit" subTitle="">
    <div v-if="curOrgObj.orgName" slot="headerRight" class="curTenancyNameCon">
      <span class="curTenancyName">({{curOrgObj.orgName}})</span>
      <span class="returnBtn" @click="returnPreChart">返回</span>
    </div>
    <div slot="chart" class="chart" ref="chart"></div>
  </common-box>
</template>

<script>
import * as echarts from 'echarts'
import commonBox from './commonBox.vue'
import { dynamicInvoke } from '@/api/dataapi'
import Big from 'big.js'
export default {
  components: {
    commonBox
  },
  props: {
    params: {
      type: Object,
      default: () => {}
    },
    inspectType: String,
    activeBtnValue: String,
  },
  data() {
    return {
      headTit: '报告优良率',
      myChart: null,
      chartData: [],
      curOrgObj: {
        orgName: '',
      },
      chartDetailData: [],

      singleBarOption: {
        backgroundColor: '',
        grid: {
          top: '35px',
          left: '0px',
          right: '0px',
          bottom: '0px',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: [],
          // 强制显示所有标签
          axisLabel: {
            interval: 0,
            color: '#fff'
          },
          axisTick: {
            show: false
          },
          axisLine: {
            //x轴线的颜色以及宽度
            show: true,
            lineStyle: {
              color: 'rgba(255,255,255,.1)',
              width: 1,
              type: "solid",
            },
          },
        },
        yAxis: {
          type: 'value',
          show: true,
          min: 0,
          max: 100,
          axisLabel: {
            formatter: '{value}%',
            textStyle: {
              color: 'rgba(255,255,255,.5)',
            },
          },
          splitLine: { show: false },
          axisLine: {
            //y轴线的颜色以及宽度
            show: true,
            lineStyle: {
              color: 'rgba(255,255,255,.1)',
              width: 1,
              type: "solid",
            },
          },
          axisTick: {
            show: false
          }
        },
        series: [
          {
            data: [],
            type: 'bar',
            name: '上报数据',
            barWidth: '30%',
            label: {
              show: true,
              position: 'top',
              formatter: '{c}%',// 如果下面一行再定义normal的话 那这里就会不生效 不会显示 100% 等
              // normal: {
              //   show: true,
              //   position: "top",
              //   color: function(params) {
              //     let num = colorArr.length;
              //     return colorArr[params.dataIndex % num].top
              //   },
              //   fontFamily: "PingFangSC-Medium",
              //   fontWeight: 500,
              // },
            },
            itemStyle: {
              normal: {
                color: function(params) {
                  // let num = colorArr.length;
                  // return new echarts.graphic.LinearGradient(0, 1, 0, 0,[{
                  //     offset: 0,
                  //     color: colorArr[index].top // 0% 处的颜色
                  // },{//可根据具体情况决定哪根柱子显示哪种颜色
                  //     offset: 1,
                  //     color: colorArr[index].bottom // 100% 处的颜色
                  // }],false)
                },
              }
            }
          }
        ]
      }
    }
  },
  created () {
    if (this.activeBtnValue == 'RIS') { // 放射
      if (this.inspectType == 'reportYLRate') {
        this.headTit = '报告优良率'
      }
      if (this.inspectType == 'reportYXRate') {
        this.headTit = '报告阳性率'
      }
    } else if (this.activeBtnValue == 'UIS' || this.activeBtnValue == 'EIS') { // 超声和内镜
      if (this.inspectType == 'inspectOrder') {
        this.headTit = '预约人次(人次)'
      }
      if (this.inspectType == 'reportYXRate') {
        this.headTit = '报告阳性率'
      }
      if (this.inspectType == 'inspectPeople') {
        this.headTit = '检查人次(人次)'
      }
    }
    
  },
  mounted() {

  },
  methods: {
    // 点击某根柱子后 展现其机构下的 检查类型 数据
    async drawInspectTypeChart (index,inspectType) {
      const self = this
      // self.myChart.dispose()
      // self.myChart = null
      let option  = null
      let res = null
      const newParams = Object.assign({}, self.params, self.curOrgObj)
      if (inspectType == 'reportYLRate') { // 报告优良率
        res = await dynamicInvoke('QC_1175',newParams)
      }
      if (self.activeBtnValue == 'RIS' && inspectType == 'reportYXRate') { // 报告阳性率
        res = await dynamicInvoke('QC_1176',newParams)
      }
      
      if (res.code == 0) {
        // self.chartDetailData = [
        //   {
        //     name: 'CT',
        //     value: 80,
        //     orgName: 'TEST'
        //   },
        //   {
        //     name: 'XR',
        //     value: 60,
        //     orgName: 'TEST2'
        //   },
        // ]
        self.chartDetailData = res.data.map((item) => {
          item.ratio = item.ratio || 0
          return {
            name: item.itemType,
            value: Big(item.ratio)
              .times(100)
              .toString(),
            ...item
          }
        })
      } else {
        self.$message.error(res.msg)
      }
      if (!self.myChart) {
        self.myChart = echarts.init(self.$refs.chart, 'dark')
      }
      var colorArr = [
        {
          top: '#1BB54A',//绿色
          bottom: '#11D4B6',
        },
        {
          top: '#FDB200',//黄色
          bottom: '#FFE800'
        },
        {
          top: '#004CFF',//蓝色
          bottom: '#1CDAE4'
        },
        {
          top: '#ff6958',//蓝色
          bottom: '#ff7d6f'
        }
      ];
      option = JSON.parse(JSON.stringify(this.singleBarOption));
      const xData = self.chartDetailData.map((item) => item.name);
      option.xAxis.data = xData;
      //option.series[0].data = self.chartDetailData;
      const yData = self.chartDetailData.map((item) => {
        return {
          value: item.value,
          label:{textStyle: { color: colorArr[index].top }}// 设置柱子上数值的颜色
        }
       })
      option.series[0].data = yData;
      option.series[0].itemStyle.normal.color = function(params) {
        return new echarts.graphic.LinearGradient(0, 1, 0, 0,[{
            offset: 0,
            color: colorArr[index].top // 0% 处的颜色
        },{//可根据具体情况决定哪根柱子显示哪种颜色
            offset: 1,
            color: colorArr[index].bottom // 100% 处的颜色
        }],false)
      }
      option && self.myChart.setOption(option,{ notMerge: true })
      self.myChart.getZr().off('click')
    },
    returnPreChart () {
      this.refreshChart()
    },
    async refreshChart() {
      const self = this
      let option  = null
      let res = null
      if (self.curOrgObj.orgName) {
        self.curOrgObj.orgName = ''
        self.myChart.clear();
      }
      if (self.activeBtnValue == 'RIS') {
        if (self.inspectType == 'reportYLRate') { // 报告优良率
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1003',self.params)
        }

        if (self.inspectType == 'reportYXRate') { // 报告阳性率
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1001',self.params)
        }

      } else if (self.activeBtnValue == 'UIS' || self.activeBtnValue == 'EIS') {  // 超声和内镜
        if (self.inspectType == 'reportYLRate') { // 报告优良率
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1003',self.params)
        }
        else if (self.inspectType == 'reportYXRate') {// 报告阳性率
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen-XIS_1003',self.params)
        }
        else if (self.inspectType == 'inspectOrder') { // 预约人次
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen-XIS_1001',self.params)
        }
        else if (self.inspectType == 'inspectPeople') { // 检查人次
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen-XIS_1002',self.params)
        }
      }
      
      if (res.code == 0) {
        // self.chartData = [
        //   {
        //     name: 'CT',
        //     value: 80,
        //     orgName: 'TEST'
        //   },
        //   {
        //     name: 'XR',
        //     value: 60,
        //     orgName: 'TEST2'
        //   },
        // ]
        self.chartData = res.data.map((item) => {
          item.ratio = item.ratio || 0
          if (self.inspectType == 'reportYXRate') { // 报告阳性率
            return {
              name: item.orgName,
              value: Big(item.ratio)
                .times(100)
                .toString(),
              ...item
            }
          } else {
            return {
            name: item.examType,
            value: Big(item.ratio)
              .times(100)
              .toString(),
            ...item
             }
          }
          
        })
       // console.log('self.chartData',self.chartData)
      } else {
        self.$message.error(res.msg)
      }
      if (!self.myChart) {
        self.myChart = echarts.init(self.$refs.chart, 'dark')
      }
      var colorArr = [
        {
          top: '#1BB54A',//绿色
          bottom: '#11D4B6',
        },
        {
          top: '#FDB200',//黄色
          bottom: '#FFE800'
        },
        {
          top: '#004CFF',//蓝色
          bottom: '#1CDAE4'
        },
        {
          top: '#ff6958',//蓝色
          bottom: '#ff7d6f'
        }
      ];


      option = JSON.parse(JSON.stringify(this.singleBarOption));
      const xData = self.chartData.map((item) => item.orgName);
      option.xAxis.data = xData;
      const yData = self.chartData.map((item,i) => {
        return {
          value: item.value,
          label:{textStyle: { color: colorArr[i].top }}
        }
       })
      option.series[0].data = yData;

      // option.series[0].label.normal.color = function(params) {
      //   let num = colorArr.length;
      //   return colorArr[params.dataIndex % num].top
      // }
      option.series[0].itemStyle.normal.color = function(params) {
        let num = colorArr.length;
        return new echarts.graphic.LinearGradient(0, 1, 0, 0,[{
            offset: 0,
            color: colorArr[params.dataIndex % num].top // 0% 处的颜色
        },{//可根据具体情况决定哪根柱子显示哪种颜色
            offset: 1,
            color: colorArr[params.dataIndex % num].bottom // 100% 处的颜色
        }],false)
      }
      option && self.myChart.setOption(option,{ notMerge: true })
      if (self.inspectType == 'reportYXRate' && (self.activeBtnValue == 'UIS' || self.activeBtnValue == 'EIS')) {// 超声、内镜 报告阳性率没有下钻
        self.myChart.getZr().off('click')
      }

      // 给报告优良率 柱状图 增加点击事件
      if ((self.inspectType == 'reportYLRate' || self.inspectType == 'reportYXRate') && !self.curOrgObj.orgName && self.activeBtnValue === 'RIS') {
          self.myChart.getZr().on('click', function(params) {

          if (self.inspectType == 'reportYXRate' && (self.activeBtnValue == 'UIS' || self.activeBtnValue == 'EIS')) {// 超声、内镜 报告阳性率没有下钻
            return
          }

          let pointInPixel = [params.offsetX, params.offsetY]
          if (self.myChart.containPixel('grid', pointInPixel)) {
            let xIndex = self.myChart.convertFromPixel({ seriesIndex: 0 }, [params.offsetX, params.offsetY])[0]
            //console.log(xIndex)
            //console.log(params)
            self.myChart.dispatchAction({
              type:'select',
                seriesIndex: xIndex,//这行不能省
            })
            //self.$emit('clickChartFunc',xIndex, self.inspectType)
            if (!self.curOrgObj.orgName) {
              self.curOrgObj.orgName = self.chartData[xIndex].orgName
              self.drawInspectTypeChart(xIndex, self.inspectType)
            }
            
          }
        })
      }
    }
  },
  destroyed() {
    if (!this.myChart) {
      return
    }
    this.myChart.dispose()
    this.myChart = null
  }
}
</script>

<style lang="scss" scoped>
.chart {
  width: 100%;
  height: 100%;
}
.curTenancyNameCon{
 flex:1;
 display: flex;
 justify-content: space-between;
  .curTenancyName{
    color: #fff;
    font-size: vh(16);
    margin-left: vw(15);
  }
  .returnBtn{
    color: #fff;
    font-size: vh(16);
    cursor: pointer;
  }
}
</style>
