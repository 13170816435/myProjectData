<template>
  <ecgCommonBox :title="headTit" subTitle="" class="twoChartCon">
    <div slot="chart" class="chart" ref="chart"></div>
    <div slot="anotherChart" class="anotherChart" ref="anotherChart"></div>
  </ecgCommonBox>
</template>

<script>
import * as echarts from 'echarts'
import ecgCommonBox from './ecgCommonBox.vue'
import { dynamicInvoke } from '@/api/dataapi'
import Big from 'big.js'
export default {
  components: {
    ecgCommonBox
  },
  props: {
    params: {
      type: Object,
      default: () => {}
    },
    inspectType: String,
    activeBtnValue: String,
  },
  data() {
    return {
      headTit: '报告优良率',
      myChart: null,
      chartData: [],
      anotherChart: null,
    }
  },
  created () {
    if (this.inspectType == 'inspectPeople') {
      this.headTit = '检查人次(人次)'
    }
    if (this.inspectType == 'inspectFee') {
      this.headTit = '检查费用'
    }
  },
  mounted() {

  },
  methods: {
    async refreshChart() {
      let option  = null
      let res = null
      if (this.inspectType == 'inspectPeople') {   // 检查人次
        res = await dynamicInvoke('YZ-Area-Quality-YWScreen-ECG_1001',this.params)
      }
      if (this.inspectType == 'inspectFee') {   // 检查费用
        res = await dynamicInvoke('YZ-Area-Quality-YWScreen-ECG_1002',this.params)
      }
      
      if (res.code == 0) {
        // this.chartData = [
        //   {
        //     name: 'CT',
        //     value: 80,
        //     orgName: 'TEST'
        //   },
        //   {
        //     name: 'XR',
        //     value: 60,
        //     orgName: 'TEST2'
        //   },
        // ]
        if (this.inspectType == 'inspectPeople') {// 检查人次
          this.chartData = res.data.map((item) => {
            item.totalNum = item.totalNum || 0
            return {
              name: item.orgName,
              value: item.totalNum,
              ...item
            }
          })
        }
        if (this.inspectType == 'inspectFee') {// 检查费用
          this.chartData = res.data.map((item) => {
            item.money = item.money || 0
            return {
              name: item.orgName,
              value: item.money,
              ...item
            }
          })
        }

        
      } else {
        this.$message.error(res.msg)
      }
      if (!this.myChart) {
        this.myChart = echarts.init(this.$refs.chart, 'dark')
      }
      var colorArr = [
        {
          top: '#1BB54A',//绿色
          bottom: '#11D4B6',
        },
        {
          top: '#004CFF',//蓝色
          bottom: '#1CDAE4'
        },
        {
          top: '#FDB200',//黄色
          bottom: '#FFE800'
        },
        {
          top: '#ff6958',//蓝色
          bottom: '#ff7d6f'
        }
      ];
      const yData = this.chartData.map((item,i) => {
        return {
          value: item.value,
          label:{textStyle: { color: colorArr[i].top }}
        }
       })
      option = {
        backgroundColor: '',
        grid: {
          top: '35px',
          left: '0px',
          right: '0px',
          bottom: '0px',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: this.chartData.map((item) => item.orgName),
          // 强制显示所有标签
          axisLabel: {
            interval: 0,
            color: '#fff'
          },
          axisTick: {
            show: false
          },
          axisLine: {
            //x轴线的颜色以及宽度
            show: true,
            lineStyle: {
              color: 'rgba(255,255,255,.1)',
              width: 1,
              type: "solid",
            },
          },
        },
        yAxis: {
          type: 'value',
          show: true,
          min: 0,
        //   max: 100,
        //   axisLabel: {
        //     formatter: '{value}%',
        //     textStyle: {
        //       color: 'rgba(255,255,255,.5)',
        //     },
        //   },
          splitLine: { show: false },
          axisLine: {
            //y轴线的颜色以及宽度
            show: true,
            lineStyle: {
              color: 'rgba(255,255,255,.1)',
              width: 1,
              type: "solid",
            },
          },
          axisTick: {
            show: false
          }
        },
        series: [
          {
            data: yData,
            type: 'bar',
            name: '上报数据',
            barWidth: '30%',
            label: {
              show: true,
              position: 'top',
              formatter: '{c}',
              // normal: {
              //   show: true,
              //   position: "top",
              //   color: function(params) {
              //     let num = colorArr.length;
              //     return colorArr[params.dataIndex % num].top
              //   },
              //   fontFamily: "PingFangSC-Medium",
              //   fontWeight: 500,
              // },
            },
            itemStyle: {
              normal: {
                color: function(params) {
                  let num = colorArr.length;
                  return new echarts.graphic.LinearGradient(0, 1, 0, 0,[{
                      offset: 0,
                      color: colorArr[params.dataIndex % num].top // 0% 处的颜色
                  },{//可根据具体情况决定哪根柱子显示哪种颜色
                      offset: 1,
                      color: colorArr[params.dataIndex % num].bottom // 100% 处的颜色
                  }],false)
                },
              }
            }
          }
        ]
      }
      option && this.myChart.setOption(option,{ notMerge: true })
    },
    async refreshPieChart() {
      let option  = null
      let res = null
      if (this.inspectType == 'inspectPeople') {   // 检查人次
        res = await dynamicInvoke('YZ-Area-Quality-YWScreen-ECG_1001',this.params)
      }
      if (this.inspectType == 'inspectFee') {   // 检查费用
        res = await dynamicInvoke('YZ-Area-Quality-YWScreen-ECG_1002',this.params)
      }
      
      if (res.code == 0) {
        var colorList = ['#3FD097','#009CFF','#DDC80B','#ff6958','#66DE69', '#CBD26D', '#0AE3F4', '#1483FF', '#a814ff', '#41CBAB', '#7BDD43', '#FFC653', '#FF6519', '#EE3939', '#FFAFDA', '#00FFFF'];
        // this.chartData = [
        //     {
        //         name: '玉米',
        //         value: 3200,
        //         percent: 5.01,
        //         itemStyle: {
        //             normal: {
        //                 color: colorList[0],
        //             },
        //         },
        //     },
        //     {
        //         name: '土豆',
        //         value: 1400,
        //         percent: 5.12,
        //         itemStyle: {
        //             normal: {
        //                 color: colorList[1],
        //             },
        //         },
        //     },
        //     {
        //         name: '大豆',
        //         value: 3400,
        //         percent: 1.87,
        //         itemStyle: {
        //             normal: {
        //                 color: colorList[2],
        //             },
        //         },
        //     },
        //     {
        //         name: '番茄',
        //         value: 3400,
        //         percent: 1.87,
        //         itemStyle: {
        //             normal: {
        //                 color: colorList[3],
        //             },
        //         },
        //     },
        //     {
        //         name: '茄子',
        //         value: 3000,
        //         percent: 0.87,
        //         itemStyle: {
        //             normal: {
        //                 color: colorList[4],
        //             },
        //         },
        //     }
        //     ];  
        
        var total = 0
        res.data.map((item,) => {
           item.totalNum = item.totalNum || item.money
           total=total+ item.totalNum
        })
        if (this.inspectType == 'inspectPeople') {// 检查人次
          this.chartData = res.data.map((item,i) => {
            item.totalNum = item.totalNum || 0
            return {
              name: item.orgName,
              value: item.totalNum,
              itemStyle: {
                normal: {
                  color: colorList[i],
                },
              },
              ...item
            }
          })
        }
        if (this.inspectType == 'inspectFee') {// 检查费用
          this.chartData = res.data.map((item,i) => {
            item.money = item.money || 0
            return {
              name: item.orgName,
              value: item.money,
              itemStyle: {
                normal: {
                  color: colorList[i],
                },
              },
              ...item
            }
          })
        }

      } else {
        this.$message.error(res.msg)
      }
      if (!this.anotherChart) {
        this.anotherChart = echarts.init(this.$refs.anotherChart, 'dark')
      }
      
      option = {
        backgroundColor: '',
        grid: {
          top: '10%',
          left: '70%',
          right: '10%',
          bottom: '10%',
        //   borderWidth: 1,
        },
        tooltip: {
            trigger: "item",
            formatter: "{b}<br/>{c} ({d}%)",
            textStyle: {
              fontSize: 15,
            },
        },
        series: {
          type: 'pie',
          center: ['45%', '45%'],
          radius: ['25%', '50%'],
          clockwise: true,
          //startAngle: 50,
          avoidLabelOverlap: true,
          hoverOffset: 15,
          itemStyle: {
            normal: {
              color: function (params) {
                return colorList[params.dataIndex];
              },
            },
          },
          label: {
            show: true,
            position: 'outside',
            formatter: function (data) {
              //console.log('data',data)
              return (
                '{name|' + data.name + ':' + '\n}' + ' \n{value|' + data.percent.toFixed(0) + '%}'
              );
            },
            rich: {
              name: {
                fontSize: 10,
                color: '#ffffff',
              },
              value: {
                fontSize: 10,
                color: '#ffffff',
              },
            },
          },
          labelLine: {
            show: false,
            normal: {
              length: 5,
              length2: 20,
              align: 'right',
              lineStyle: {
                width: 1,
              },
            },
          },
          data: this.chartData,
          seriesIndex: 0,
        },
      };
      option && this.anotherChart.setOption(option,{ notMerge: true })
    }
  },
  destroyed() {
    if (!this.myChart || !this.anotherChart) {
      return
    }
    this.myChart.dispose()
    this.myChart = null

    this.anotherChart.dispose()
    this.anotherChart = null
  }
}
</script>

<style lang="scss" scoped>
.twoChartCon {
  display: flex;
}
.chart {
  width: vw(520);
  height: 100%;
}
.anotherChart{
  width: vw(410);
  height: 100%;   
}
</style>
