<template>
  <common-box title="报告优良率" subTitle="">
    <div slot="chart" class="chart" ref="chart"></div>
  </common-box>
</template>

<script>
import * as echarts from 'echarts'
import commonBox from './commonBox.vue'
import { dynamicInvoke } from '@/api/dataapi'
import Big from 'big.js'
export default {
  components: {
    commonBox
  },
  props: {
    params: {
      type: Object,
      default: () => {}
    },
  },
  data() {
    return {
      myChart: null,
      chartData: []
    }
  },
  mounted() {

  },
  methods: {
    initMoreBarChartSeries(item,index) {
      var colorArr = [
        {
          top: '#1BB54A',//绿色
          bottom: '#11D4B6',
        },
        {
          top: '#004CFF',//蓝色
          bottom: '#1CDAE4'
        },
        {
          top: '#FDB200',//黄色
          bottom: '#FFE800'
        },
        {
          top: '#ff6958',//蓝色
          bottom: '#ff7d6f'
        }
      ];
      return           {
            data: item,
            type: 'bar',
            name: item.name,
            barWidth: '30',
            // label: {
            //   normal: {
            //     show: true,
            //     position: "top",
            //     formatter: '{c}%',
            //     color: colorArr[index].bottom,
            //     fontFamily: "PingFangSC-Medium",
            //     fontWeight: 500,
            //   },
            // },
            // itemStyle: {
            //   normal: {
            //     color: function(params) {
            //       let num = colorArr.length;
            //       return new echarts.graphic.LinearGradient(0, 1, 0, 0,[{
            //           offset: 0,
            //           color: colorArr[index].top // 0% 处的颜色
            //       },{//可根据具体情况决定哪根柱子显示哪种颜色
            //           offset: 1,
            //           color: colorArr[index].bottom // 100% 处的颜色
            //       }],false)
            //     },
            //   }
            // }
        }
    },
    async refreshChart() {
      const self = this
      const res = await dynamicInvoke(
        'YZ-Area-Quality-YWScreen_1003',
        self.params
      )
      if (res.code == 0) {
        self.chartData = res.data.map((item) => {
          item.ratio = item.ratio || 0
          return {
            name: item.examType,
            value: Big(item.ratio)
              .times(100)
              .toString(),
            ...item
          }
        })
      } else {
        self.$message.error(res.msg)
      }
      if (!self.myChart) {
        self.myChart = echarts.init(self.$refs.chart, 'dark')
      }
      let series = [
        {
          type: 'bar',
          ///name: item.name,
          barWidth: '30',
          data: []
        }
      ]
      var colorArr = [
        {
          top: '#1BB54A',//绿色
          bottom: '#11D4B6',
        },
        {
          top: '#004CFF',//蓝色
          bottom: '#1CDAE4'
        },
        {
          top: '#FDB200',//黄色
          bottom: '#FFE800'
        },
        {
          top: '#ff6958',//蓝色
          bottom: '#ff7d6f'
        }
      ];
      if (self.chartData.length != 0) {
        self.chartData.forEach((item, index) => {
          let obj = {
             value: item.value,
             label: {
              normal: {
                show: true,
                position: "top",
                formatter: '{c}%',
                color: colorArr[index].bottom,
                fontFamily: "PingFangSC-Medium",
                fontWeight: 500,
              },
            },
            itemStyle: {
              color: colorArr[index].top
              // normal: {
              //   color: function(params) {
              //     let num = colorArr.length;
              //     return new echarts.graphic.LinearGradient(0, 1, 0, 0,[{
              //         offset: 0,
              //         color: colorArr[index].top // 0% 处的颜色
              //     },{//可根据具体情况决定哪根柱子显示哪种颜色
              //         offset: 1,
              //         color: colorArr[index].bottom // 100% 处的颜色
              //     }],false)
              //   },
              // }
            }
          }
          series[0].data.push(obj)
        });
      }
      const option = {
        backgroundColor: '',
        grid: {
          top: '20px',
          left: '0px',
          right: '0px',
          bottom: '0px',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: self.chartData.map((item) => item.orgName),
          // 强制显示所有标签
          axisLabel: {
            interval: 0,
            color: '#fff'
          },
          axisTick: {
            show: false
          },
          axisLine: {
            //x轴线的颜色以及宽度
            show: true,
            lineStyle: {
              color: 'rgba(255,255,255,.1)',
              width: 1,
              type: "solid",
            },
          },
        },
        yAxis: {
          type: 'value',
          show: true,
          min: 0,
          max: 100,
          axisLabel: {
            formatter: '{value}%',
            textStyle: {
              color: 'rgba(255,255,255,.5)',
            },
          },
          splitLine: { show: false },
          axisLine: {
            //y轴线的颜色以及宽度
            show: true,
            lineStyle: {
              color: 'rgba(255,255,255,.1)',
              width: 1,
              type: "solid",
            },
          },
          axisTick: {
            show: false
          }
        },
        series: series
      }
      option && this.myChart.setOption(option)
    }
  },
  destroyed() {
    if (!this.myChart) {
      return
    }
    this.myChart.dispose()
    this.myChart = null
  }
}
</script>

<style lang="scss" scoped>
.chart {
  width: 100%;
  height: 100%;
}
</style>
