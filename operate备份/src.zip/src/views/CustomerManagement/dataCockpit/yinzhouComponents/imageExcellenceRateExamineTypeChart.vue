<template>
  <common-box :title="headTit" subTitle="">
    <div v-if="curOrgObj.orgName" slot="headerRight" class="curTenancyNameCon">
      <span class="curTenancyName">({{curOrgObj.orgName}})<span class="ml10">({{curOrgObj.patientType}})</span></span>
      <span class="returnBtn" @click="returnPreChart">返回</span>
    </div>
    <div slot="chart" class="chart" ref="chart"></div>
  </common-box>
</template>

<script>
import * as echarts from "echarts";
import commonBox from "./commonBox.vue";
import { dynamicInvoke } from "@/api/dataapi";
import Big from "big.js";
import { relativeTimeRounding } from "moment";
export default {
  components: {
    commonBox,
  },
  props: {
    params: {
      type: Object,
      default: () => {},
    },
    inspectType: String,
    activeBtnValue: String,
  },
  data() {
    return {
      headTit: '预约检查人次(人次)',
      myChart: null,
      chartData: [],
      chartXData: [],
      chartYData: [],
      curOrgObj: {
        orgName: '',
        patientType: '',
      },
      chartDetailData: [],
      singleBarOption: {
        backgroundColor: '',
        grid: {
          top: '35px',
          left: '0px',
          right: '0px',
          bottom: '0px',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: [],
          // 强制显示所有标签
          axisLabel: {
            interval: 0,
            color: '#fff'
          },
          axisTick: {
            show: false
          },
          axisLine: {
            //x轴线的颜色以及宽度
            show: true,
            lineStyle: {
              color: 'rgba(255,255,255,.1)',
              width: 1,
              type: "solid",
            },
          },
        },
        yAxis: {
          type: 'value',
          show: true,
          min: 0,
          // max: 100,
          // axisLabel: {
          //   formatter: '{value}%',
          //   textStyle: {
          //     color: 'rgba(255,255,255,.5)',
          //   },
          // },
          splitLine: { show: false },
          axisLine: {
            //y轴线的颜色以及宽度
            show: true,
            lineStyle: {
              color: 'rgba(255,255,255,.1)',
              width: 1,
              type: "solid",
            },
          },
          axisTick: {
            show: false
          }
        },
        series: [
          {
            data: [],
            type: 'bar',
            name: '上报数据',
            barWidth: '30%',
            label: {
              show: true,
              position: 'top',
              formatter: '{c}%',
              normal: {
                show: true,
                position: "top",
                color: function(params) {
                  let num = colorArr.length;
                  return colorArr[params.dataIndex % num].top
                },
                fontFamily: "PingFangSC-Medium",
                fontWeight: 500,
              },
            },
            itemStyle: {
              normal: {
                color: function(params) {
                  // let num = colorArr.length;
                  // return new echarts.graphic.LinearGradient(0, 1, 0, 0,[{
                  //     offset: 0,
                  //     color: colorArr[index].top // 0% 处的颜色
                  // },{//可根据具体情况决定哪根柱子显示哪种颜色
                  //     offset: 1,
                  //     color: colorArr[index].bottom // 100% 处的颜色
                  // }],false)
                },
              }
            }
          }
        ]
      },
    };
  },
  created () {
    if (this.activeBtnValue == 'RIS') { // 放射
      if (this.inspectType == 'inspectOrder') {
        this.headTit = '预约检查人次(人次)'
      } else if (this.inspectType == 'inspectReport'){
        this.headTit = '检查报告平均耗时(分钟)'
      } else if (this.inspectType == 'criticaValue'){
        this.headTit = '危急值通报处理人次(人次)'
      }
    } else if (this.activeBtnValue == 'UIS' || this.activeBtnValue == 'EIS') { // 超声和内镜
      if (this.inspectType == 'criticaValue') {
        this.headTit = '危急值通报处理人次(人次)'
      } else if (this.inspectType == 'inspectWait') {
        this.headTit = '检查等待平均耗时(分钟)'
      } else if (this.inspectType == 'inspectReport'){
        this.headTit = '检查报告平均耗时(分钟)'
      }
      
    } else if (this.activeBtnValue == 'ECG') { // 心电
      if (this.inspectType == 'inspectWait') {
        this.headTit = '检查等待平均耗时(分钟)'
      }
      if (this.inspectType == 'inspectReport'){
        this.headTit = '检查报告平均耗时(分钟)'
      }
    }
    
  },
  mounted() {
    
  },
  methods: {
    // 点击某根柱子后 展现其机构下的 检查类型 数据
    async drawInspectTypeChart (index,inspectType,) {
      const self = this
      // self.myChart.dispose()
      // self.myChart = null
      let option  = null
      let res = null
      if (inspectType == 'inspectReport') { // 影像优良率
        const newParams = Object.assign({}, self.params, self.curOrgObj)
        res = await dynamicInvoke('QC_1173',newParams)
      }
      if (res.code == 0) {
        if (inspectType == 'inspectReport') {
          self.chartDetailData = res.data.map((item) => {
          item.reportTime = item.reportTime || 0
            return {
              name: item.itemType,
              value: item.reportTime,
              ...item
            }
          })
        }
        
      } else {
        self.$message.error(res.msg)
      }
      if (!self.myChart) {
        self.myChart = echarts.init(self.$refs.chart, 'dark')
      }
      var colorArr = [
        {
          top: '#1BB54A',//绿色
          bottom: '#11D4B6',
        },
        {
          top: '#FDB200',//黄色
          bottom: '#FFE800'
        },
        {
          top: '#004CFF',//蓝色
          bottom: '#1CDAE4'
        },
        {
          top: '#ff6958',//蓝色
          bottom: '#ff7d6f'
        }
      ];
      option = JSON.parse(JSON.stringify(this.singleBarOption));
      const xData = self.chartDetailData.map((item) => item.name);
      option.xAxis.data = xData;
      option.series[0].data = self.chartDetailData;
      option.series[0].label.normal.color = function(params) {
        return colorArr[index].top
      }
      option.series[0].itemStyle.normal.color = function(params) {
        return new echarts.graphic.LinearGradient(0, 1, 0, 0,[{
            offset: 0,
            color: colorArr[index].top // 0% 处的颜色
        },{//可根据具体情况决定哪根柱子显示哪种颜色
            offset: 1,
            color: colorArr[index].bottom // 100% 处的颜色
        }],false)
      }
      option && self.myChart.setOption(option,{ notMerge: true })
    },
    initMoreBarChartSeries(item, nth, xdataLength) {
      var colorArr = [
        {
          top: '#1BB54A',//绿色
          bottom: '#11D4B6',
        },
        {
          top: '#FDB200',//黄色
          bottom: '#FFE800'
        },
        {
          top: '#004CFF',//蓝色
          bottom: '#1CDAE4'
        },
        {
          top: '#ff6958',//蓝色
          bottom: '#ff7d6f'
        }
      ];
      var index = 0
      if (nth>=4) {
        index = Math.floor(Math.random()*4)
      } else {
        index = nth
      }
      let barWidth = 30
      if (xdataLength==4) {
        barWidth = 28
      }
      if (xdataLength>=5) {
        barWidth = 25
      }
      return {
        name: item.name || item.label,
            type: "bar",
            emphasis: {
              focus: "series",
            },
            barWidth: barWidth,
            // barGap: 20, 
            label: {
              normal: {
                show: true,
                position: "top",
                formatter: function (data) {
                  // return data.value + "分钟";
                  return data.value;
                },
                color: colorArr[index].bottom,
                fontFamily: "PingFangSC-Medium",
                fontWeight: 500,
              },
            },
            data: item.data,
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
                { offset: 1, color: colorArr[index].bottom },
                { offset: 0, color: colorArr[index].top },
              ]),
            },
      };
    },
    // 将orgName相同的归类
    dealArray (list, key) {
      var keysArr = list.map(item=>item[key])
      var keys = [...new Set(keysArr)]
      var newList = keys.map(item=> {
        return {
          [key]: item,
          list: list.filter(i=>i[key] == item)
        }
      })
      return newList
    },
    // 点击返回
    returnPreChart () {
      this.refreshChart()
    },
    async refreshChart() {
      const self = this
      //echarts.init(self.$refs.chart).dispose() 
      let res = null
      let option = null
      if (self.curOrgObj.orgName) {
        self.curOrgObj.orgName = ''
        self.curOrgObj.patientType = ''
        self.myChart.clear();
      }
      if (self.activeBtnValue == 'RIS') { // 放射
        if (self.inspectType == 'inspectOrder') {
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1026',self.params)
        }
        else if (self.inspectType == 'inspectReport') {
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1006',self.params)
        }
        else if (self.inspectType == 'criticaValue') {
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1025',self.params)
        }
      } else if (self.activeBtnValue == 'UIS' || self.activeBtnValue == 'EIS') {// 超声和内镜
        if (self.inspectType == 'criticaValue') {
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen-XIS_1006',self.params)
        }
        else if (self.inspectType == 'inspectWait') {
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen-XIS_1004',self.params)
        }
        else if (self.inspectType == 'inspectReport') {
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen-XIS_1005',self.params)
        }
        
      } else if (self.activeBtnValue == 'ECG') { // 心电
        if (self.inspectType == 'inspectWait') {
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen-ECG_1005',self.params)
        }
        if (self.inspectType == 'inspectReport') {
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen-ECG_1006',self.params)
        }
      }
      let yData = []
      self.chartYData = []
      let xData = []
      self.chartXData = []
      if (res.code == 0) {
        var newList = self.dealArray(res.data, 'orgName')
        if (newList.length != 0) {
          var firstItemList = newList[0].list
          if (firstItemList.length != 0) {
            xData = firstItemList.map((nth) => {
              if(self.inspectType == 'inspectWait' || self.inspectType == 'inspectReport') {
                return nth.patientType
              }
              else if (self.inspectType == 'inspectOrder') { //检查预约
                return nth.state 
              }
              else if (self.inspectType == 'criticaValue') { // 危急值通报
                return nth.critState 
              }
            })
            self.chartXData = JSON.parse(JSON.stringify(xData))
          }
          let otherObj = null
          newList.forEach((one) => {
            let obj = {
              name: one.orgName,
              data: one.list.map((item)=> {
                if(self.inspectType == 'inspectWait') {
                  return item.examTime
                } else if (self.inspectType == 'inspectReport') {
                  return item.reportTime
                } else if (self.inspectType == 'inspectOrder') {
                  return item.totalNum 
                } else if (self.inspectType == 'criticaValue') {
                  return item.totalNum 
                }
                
              })
            }
            // 目的就是把机构 "其它" 放到最后面去
            if (one.orgName == '其它') {
              otherObj = JSON.parse(JSON.stringify(obj))
            } else {
              yData.push(obj)
              self.chartYData.push(obj)
            }
          })
          // 目的就是把机构 "其它" 放到最后面去
          if (otherObj) {
            yData.push(otherObj)
            self.chartYData.push(otherObj)
          }
        }
      } else {
        self.$message.error(res.msg);
      }
      if (!self.myChart) {
        self.myChart = echarts.init(self.$refs.chart, "dark");
      }
      let series = [];
      // const xData = ["门诊", "住院",'test1','未知'];
      // const yData = [
      //   { data: [188, 180,160, 40,30], name: "宁波第六医院" },
      //   { data: [33, 20,40,30,60], name: "鄞州区第二医院" },
      //   { data: [33, 20,80,50,80], name: "其它" },
      // ];
      yData.forEach((item, index) => {
        let seriesItem = self.initMoreBarChartSeries(item, index, xData.length); //初始化 series里面的配置和赋值相应的数据
        series.push(seriesItem);
      });
      option = {
        backgroundColor: "",
        tooltip: {// 提示里面 的圆圈颜色有点偏淡 是因为柱状图设置了渐变色
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        legend: {
          itemWidth: 10,
          itemHeight: 10,
          top: "0%",
          right: "0%",
        },
        grid: {
          top: "35px",
          left: "0px",
          right: "0px",
          bottom: "0px",
          containLabel: true,
        },
        xAxis: [
          {
            type: "category",
            data: xData,
            axisLabel: {
              interval: 0,
              color: "#fff",
            },
            axisTick: {
              show: false,
            },
            axisLine: {
              //y轴线的颜色以及宽度
              show: true,
              lineStyle: {
                color: "rgba(255,255,255,.1)",
                width: 1,
                type: "solid",
              },
            },
          },
        ],
        yAxis: [
          {
            type: "value",
            // min: 0,
            // name: "分钟",
            nameTextStyle: {
              nameLocation: "start",
            },
            axisLabel: {
              textStyle: {
                color: "rgba(255,255,255,.5)",
              },
            },
            splitLine: { show: false },
            axisLine: {
              //y轴线的颜色以及宽度
              show: true,
              lineStyle: {
                color: "rgba(255,255,255,.1)",
                width: 1,
                type: "solid",
              },
            },
          },
        ],
        series: series,
        // series: [
        //   {
        //     name: "对外收入",
        //     type: "bar",
        //     emphasis: {
        //       focus: "series",
        //     },
        //     barWidth: 40,
        //     label: {
        //       normal: {
        //         show: true,
        //         position: "top",
        //         formatter: function (data) {
        //           return data.value + "分钟";
        //         },
        //         color: "#11D4B6",
        //         fontFamily: "PingFangSC-Medium",
        //         fontWeight: 500,
        //       },
        //     },
        //     data: [188.82, 180, 200, 260],
        //     itemStyle: {
        //       color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
        //         { offset: 1, color: "#11D4B6" },
        //         { offset: 0, color: "#1BB54A" },
        //       ]),
        //     },
        //   },
        //   {
        //     name: "对内收入",
        //     type: "bar",
        //     stack: "Ad",
        //     emphasis: {
        //       focus: "series",
        //     },
        //     barWidth: 40,
        //     label: {
        //       normal: {
        //         show: true,
        //         position: "top",
        //         formatter: function (data) {
        //           return data.value + "分钟";
        //         },
        //         color: "#FFE700",
        //         fontFamily: "PingFangSC-Medium",
        //         fontWeight: 500,
        //       },
        //     },
        //     data: [33.45, 20, 50, 100],
        //     itemStyle: {
        //       color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
        //         { offset: 1, color: "#FFE800" },
        //         { offset: 0, color: "#FDB200" },
        //       ]),
        //     },
        //   },
        // ],
      };
      // option = JSON.parse(JSON.stringify(this.moreBarChartOption));
      // option.xAxis[0].data = xData;
      // option.series = series;
      option && this.myChart.setOption(option,{ notMerge: true });
      // 给影像阳性率 柱状图 增加点击事件
      if (self.inspectType == 'inspectReport' && !self.curOrgObj.orgName) {
        self.myChart.getZr().on('click', function(params) {
          
          
          let pointInPixel = [params.offsetX, params.offsetY]
          if (self.myChart.containPixel('grid', pointInPixel)) {

            const actionObj = params.target
            console.log('actionObj', actionObj)
            const myKey = Object.keys(actionObj).sort().filter(_ => _.indexOf('ec_inner') !== -1)[0]
            console.log('myKey', myKey)
            const res = actionObj[myKey]
            console.log(`当前点击了第${res.dataIndex}组数据中的第${res.seriesIndex}个柱子`)

            let xIndex = self.myChart.convertFromPixel({ seriesIndex: 0 }, [params.offsetX, params.offsetY])[0]
            //console.log(xIndex)
            //console.log(params)
            self.myChart.dispatchAction({
              type:'select',
				        seriesIndex: xIndex,//这行不能省
            })
            //self.$emit('clickChartFunc',xIndex, self.inspectType)
            console.log('series',series)
            if (!self.curOrgObj.orgName) {
              self.curOrgObj.orgName = self.chartYData[res.seriesIndex].name
              self.curOrgObj.patientType = self.chartXData[res.dataIndex]
              self.drawInspectTypeChart(res.seriesIndex, self.inspectType)
            }
            
          }
        })
      }
    },
  },
  destroyed() {
    if (!this.myChart) {
      return;
    }
    this.myChart.dispose();
    this.myChart = null;
  },
};
</script>

<style lang="scss" scoped>
.chart {
  width: 100%;
  height: 100%;
}
.curTenancyNameCon{
 flex:1;
 display: flex;
 justify-content: space-between;
  .curTenancyName{
    color: #fff;
    font-size: vh(16);
    margin-left: vw(15);
  }
  .returnBtn{
    color: #fff;
    font-size: vh(16);
    cursor: pointer;
  }
}
</style>
