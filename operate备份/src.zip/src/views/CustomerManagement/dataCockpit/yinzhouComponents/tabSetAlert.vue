<template>
  <div class="tabSetCon">
    <div class="setHeader">
        <span>基础设置</span>
        <i class="iconfont" @click="closeTabSetAlert">&#xe766;</i>
    </div>
    <div class="tabSetBox">
        <div class="screenTitleCon">
          <div class="titleLabel">大屏标题</div>
          <el-input class="subPeopleInput"  v-model="tabSetParams.screenTitle"></el-input>
        </div>
        <div class="bussessTypeBox mt5">
          <div class="bussessTypeLabel">业务类型</div>
          <div class="bussessTypeList">
            <div class="bussessTypeItem" v-for="(item, index) in tabSetParams.bussessType" :key="index">
                <div class="enableBox">
                    <span class="bussessTypeVal">{{item.label}}：</span>
                    <el-switch
                    @change="changeEnablePacs(item)"
                    class="switchStyle"
                    active-color="#235D8A"
                    inactive-color="#585980"
                    active-text="启用"
                    inactive-text="禁用"
                    :active-value="true"
                    :inactive-value="false"
                    v-model="item.enable"
                ></el-switch>
                </div>
                <el-checkbox v-model="item.default" :true-label="'1'" :false-label="'0'" :disabled="!item.enable" class="defaultCheckBox"
                :class="{'noChooseCheck':!item.enable}"
                @change="changeDefaultPacs(item)">默认选择</el-checkbox>
                <!-- <el-radio v-model="item.default" label="1" @change="changeDefaultPacs(item)">默认选择</el-radio> -->
            </div>
          </div>
        </div>

        <div class="bussessTypeBox">
        <div class="bussessTypeLabel">统计周期</div>
        <div class="bussessTypeList">
            <div class="bussessTypeItem" v-for="(item, index) in tabSetParams.timeArr" :key="index">
                <div class="enableBox">
                    <span class="bussessTypeVal">{{item.label}}：</span>
                    <el-switch
                    @change="changeEnableTime(item)"
                    class="switchStyle"
                    active-color="#235D8A"
                    inactive-color="#585980"
                    active-text="启用"
                    inactive-text="禁用"
                    :active-value="true"
                    :inactive-value="false"
                    v-model="item.enable"
                ></el-switch>
                </div>
                
                <el-checkbox v-model="item.default" :true-label="'1'" :false-label="'0'" :disabled="!item.enable" class="defaultCheckBox"
                :class="{'noChooseCheck':!item.enable}"
                @change="changeDefaultTime(item)">默认选择</el-checkbox>
                <!-- <el-radio v-model="item.default" label="1" @change="changeDefaultTime(item)">默认选择</el-radio> -->
            </div>
        </div>
        </div>
        
    </div>
    <span slot="footer" class="dialog-footer">
            <el-button class="operateBtn cancelBtn" size="small" plain @click="closeTabSetAlert">取 消</el-button>
            <el-button class="operateBtn saveBtn" size="small" type="primary" @click="sureSaveTabSet">保 存</el-button>
        </span>
  </div>
</template>
<script>
import { getCurScreenTit } from '@/api/dataapi'
export default {
  data () {
    return {
      screenTitle: '',
      isChecked: false,
      radio: '1',
      tabSetParams: {
        screenTitle: '',
        bussessType: [
        {
          label: '放射',
          value: 'RIS',
          enable: false,
          default: '0',
        },
        {
          label: '超声',
          value: 'UIS',
          enable: false,
          default: '0',
        },
        {
          label: '内镜',
          value: 'EIS',
          enable: false,
          default: '0',
        },
        {
          label: '心电',
          value: 'ECG',
          enable: false,
          default: '0',
        },
        {
          label: '病理',
          value: 'PIS',
          enable: false,
          default: '0',
        }
        ],
        timeArr: [
          {
           label: '本周',
           value: 0,
           enable: false,
           default: '0',
          },
          {
           label: '本月',
           value: 1,
           enable: false,
           default: '0',
          },
          {
           label: '本年',
           value: 2,
           enable: false,
           default: '0',
          },
          {
           label: '近两年',
           value: 3,
           enable: false,
           default: '0',
          },
        ]
      }
    }
  },
  methods:{
    closeTabSetAlert() {
      this.$emit('closeFn')
    },
    // 获取大屏标题和tab配置
    getScreenTit () {
      const self = this
      getCurScreenTit({key: '0',dicTypeCode: 'YZ-Quality-Screen-Title'}).then((res) => {
        if (res.code == 0) {
          const result = res.data[0]
          if (JSON.parse(result.dicDefineValue)) {
            self.tabSetParams = JSON.parse(result.dicDefineValue)
          } 
        }else {
          self.$message.error(res.msg)
        }
      })
    },
    // 启用或不启用某个pacs
    changeEnablePacs (item) {
      const self = this
      const bussessType = this.tabSetParams.bussessType
      bussessType.forEach((one,i) => {
        if (item.value == one.value && item.enable == false) {
          self.$set(this.tabSetParams.bussessType[i],'default', '0')
        }
      })
    },
    // 改变默认的pacs
    changeDefaultPacs (item) {
      const self = this
      const bussessType = this.tabSetParams.bussessType
      bussessType.forEach((one,i) => {
        if (item.value != one.value) {
          self.$set(this.tabSetParams.bussessType[i],'default', '0')
        }
      })
    },
    // 改变默认时间
    changeDefaultTime (item) {
      const self = this
      const timeArr = this.tabSetParams.timeArr
      timeArr.forEach((one,i) => {
        if (item.value != one.value) {
          self.$set(this.tabSetParams.timeArr[i],'default', '0')
        }
      })
    },
    // 启用或不启用某个time选项
    changeEnableTime (item) {
      const self = this
      const timeArr = this.tabSetParams.timeArr
      timeArr.forEach((one,i) => {
        if (item.value == one.value && item.enable == false) {
          self.$set(this.tabSetParams.timeArr[i],'default', '0')
        }
      })
    },
    sureSaveTabSet () {
      const self = this
      // 如果没有默认选择一个pacs的话 默认选择第一个
      const bussessType = this.tabSetParams.bussessType
      let enableBussessArr = []
      let hasDefaultBussess = false
      bussessType.forEach((one,i) => {
        if (one.enable == true) {
          enableBussessArr.push(one)
        }
      })
      if (enableBussessArr.length != 0) {
        enableBussessArr.forEach((item) => {
          if (item.default == '1') {
            hasDefaultBussess = true
          }
        })
      }
      if (!hasDefaultBussess && enableBussessArr.length != 0) {
        bussessType.forEach((one,i) => {
        if (one.value == enableBussessArr[0].value) {
          self.$set(self.tabSetParams.bussessType[i],'default', '1')
         }
       })
      }

      // 如果没有默认选择一个time的话 默认选择第一个
      const allTimeArr = this.tabSetParams.timeArr
      let enableTimeArr = []
      let hasDefaultTime = false
      allTimeArr.forEach((one,i) => {
        if (one.enable == true) {
          enableTimeArr.push(one)
        }
      })
      if (enableTimeArr.length != 0) {
        enableTimeArr.forEach((item) => {
          if (item.default == '1') {
            hasDefaultTime = true
          }
        })
      }
      if (!hasDefaultTime && enableTimeArr.length != 0) {
        allTimeArr.forEach((one,i) => {
        if (one.value == enableTimeArr[0].value) {
          self.$set(self.tabSetParams.timeArr[i],'default', '1')
         }
       })
      }

      self.$emit('sureSaveTabSet',self.tabSetParams)
    },
  },
  mounted () {

  }
}
</script>
<style lang="less" scoped>
.tabSetCon {
  width: 410px;
  height: 100%;
  background:#1D1F54;
  .setHeader{
    height: 50px;
    font-size:16px;
    color:#00FFF6;
    border-bottom:2px solid rgba(255,255,255,.2);
    padding:0 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    i{
      font-size: 18px;
      color:rgba(0, 255, 246, .5);
      cursor: pointer;
    }
  }
  .tabSetBox{
    padding: 0px 20px;
    height:calc(100% - 110px);
  }
  .screenTitleCon{
    .titleLabel{
      line-height: 44px;
      font-size:16px;
      color:#00FFF6;
    }
    ::v-deep .subPeopleInput{
      width: 360px;
      height: 40px;
      background: #1D1F54;
      border: 1px solid #00D3FF;
      border-radius: 4px;
      .el-input__inner{
        background: initial;
        border: none;
        height: 40px;
        line-height: 40px;
        color:#00FFF6;
      }
    }
  }
  .bussessTypeBox{
    .bussessTypeLabel{
      line-height: 44px;
      font-size:16px;
      color:#00FFF6;
      border-bottom:1px dashed rgba(255, 255, 255, .2);
    }
    .bussessTypeList{
        margin-top:15px;
      .bussessTypeItem{
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 15px;
        .enableBox{
          display: flex;
        }
        .bussessTypeVal{
          width: 60px;
        //   border-radius: 3px;
          margin-right:15px;
          color:#fff;
          font-size: 14px;
        }
        ::v-deep .el-switch__label {
         position: absolute;
         display: none;
         color: #fff;
        }
        ::v-deep .el-switch__label--left {
            z-index: 9;
            left: 19px;
        }
        ::v-deep .el-switch__label--right {
            z-index: 9;
            left: -6px;
        }
        ::v-deep .el-switch__label.is-active {
            display: block;
        }
        ::v-deep .el-switch .el-switch__core {
            width: 50px !important;
        }
        ::v-deep .el-switch .el-switch__label {
            width: 50px !important;
        }
        ::v-deep .el-switch__label * {
            font-size: 12px !important;
        }
        ::v-deep .el-radio__label{
          font-size: 14px;
          color:#fff;
        }
        ::v-deep .el-radio.is-checked{
          .el-radio__inner{
            border-color:#00FFF6;
            background:#00FFF6;
          }
          .el-radio__label{
            color:#00FFF6;
          }
        }
        ::v-deep .defaultCheckBox{
          .el-checkbox__inner{
            background:initial;
            width:18px;
            height:18px;
          }
          .el-checkbox__label{
            color:#fff;
          }
          .el-checkbox__input.is-checked + .el-checkbox__label{
            color:#00FFF6;
          }
          .el-checkbox__input.is-checked .el-checkbox__inner::after{
            display: none;
          }
          .el-checkbox__input.is-checked .el-checkbox__inner{
            border-color: #00FFF6;
            background: url("../../../../assets/images/common/checkBoxChoose.png") center no-repeat;
          }
        }
        ::v-deep .noChooseCheck{
          .el-checkbox__inner{
            border-color:#585980;
          }
          .el-checkbox__label{
            color:#585980;
          }  
        }
      }  
    }
  }
  .dialog-footer{
    display: flex;
    justify-content: space-between;
    padding: 0 20px;
    .operateBtn{
      width: 68px;
      height: 40px;
      border-radius: 4px;
      color:#25F5FF;
      background:#1D1F54;
      border: 1px solid;
      border-image:-webkit-linear-gradient(left, #25F5FF 0%,  #215AFF 100%) 5;
    }
  }
}
</style>