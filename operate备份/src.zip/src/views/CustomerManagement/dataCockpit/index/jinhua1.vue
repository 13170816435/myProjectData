<template>
  <div class="container-bg">
    <div class="header-content">
      <page-title :title="title" :initSize="32" :initMax="18" :width="650" :letterSpace="4" @updateTitle="updateTitle"></page-title>
      <div class="time">
        <span style="margin-right: 25px;">更新日期：{{ updateTime }}</span>
        <update-data @updateData="updateData"></update-data>
      </div>
    </div>
    <div class="charts-container">
      <div class="charts-section mt27 w600">
        <div class="charts-block">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="charts-title">
            <img
              class="icon-square"
              src="@/assets/images/dataCockpit/jinhua/icon-square.png"
              alt=""
            />
            <div class="charts-title-text">{{this.year}}年检查数据质量分析</div>
            <div class="charts-title-tip">（非空值率）</div>
          </div>
          <div class="charts-content">
            <div class="charts-strip w560 mt20 ml10">
              <div class="charts-strip-text">市级</div>
            </div>
            <div class="charts-row charts-row-flex h180">
              <div class="charts-item">
                <div class="chart-bar" style="width:160px;height:160px">
                  <chart-item :option="iDNumberByCityOption"></chart-item>
                </div>
                <div class="chart-name">身份证</div>
              </div>
              <div class="charts-item">
                <div class="chart-bar" style="width:160px;height:160px">
                  <chart-item :option="phoneNumberByCityOption"></chart-item>
                </div>
                <div class="chart-name">电话号码</div>
              </div>
              <div class="charts-item">
                <div class="chart-bar" style="width:160px;height:160px">
                  <chart-item :option="birthDayByCityOption"></chart-item>
                </div>
                <div class="chart-name">出生日期</div>
              </div>
            </div>
            <div class="charts-strip w560 mt20 ml10">
              <div class="charts-strip-text">区县</div>
            </div>
            <div class="charts-row charts-row-flex h180">
              <div class="charts-item">
                <div class="chart-bar" style="width:160px;height:160px">
                  <chart-item :option="iDNumberByCountyOption"></chart-item>
                </div>
                <div class="chart-name">身份证</div>
              </div>
              <div class="charts-item">
                <div class="chart-bar" style="width:160px;height:160px">
                  <chart-item :option="phoneNumberByCountyOption"></chart-item>
                </div>
                <div class="chart-name">电话号码</div>
              </div>
              <div class="charts-item">
                <div class="chart-bar" style="width:160px;height:160px">
                  <chart-item :option="birthDayByCountyOption"></chart-item>
                </div>
                <div class="chart-name">出生日期</div>
              </div>
            </div>
          </div>
        </div>
        <div class="charts-block mt50">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="charts-title pdr40">
            <img
              class="icon-square"
              src="@/assets/images/dataCockpit/jinhua/icon-square.png"
              alt=""
            />
            <div class="charts-title-text">{{this.year}}年省平台下载量和调阅量</div>
          </div>
          <div class="charts-content">
            <div class="chart-bar" style="width:100%;height:300px">
              <chart-item :option="downloadOption"></chart-item>
            </div>
          </div>
        </div>
      </div>
      <div class="charts-section w600">
        <div class="card-list">
          <div class="card-item">
            <div class="border-icon border-icon-lt"></div>
            <div class="border-icon border-icon-lb"></div>
            <div class="border-icon border-icon-rt"></div>
            <div class="border-icon border-icon-rb"></div>
            <div class="card-content">
              <div class="card-data clr-hz">{{ summaryInfo.patient_num }}</div>
              <div class="card-text">(人次)</div>
              <div class="card-text">总患者人数</div>
            </div>
          </div>
          <div class="card-item">
            <div class="border-icon border-icon-lt"></div>
            <div class="border-icon border-icon-lb"></div>
            <div class="border-icon border-icon-rt"></div>
            <div class="border-icon border-icon-rb"></div>
            <div class="card-content">
              <div class="card-data clr-jc">{{ summaryInfo.exam_num }}</div>
              <div class="card-text">(人次)</div>
              <div class="card-text">注册检查数</div>
            </div>
          </div>
          <div class="card-item">
            <div class="border-icon border-icon-lt"></div>
            <div class="border-icon border-icon-lb"></div>
            <div class="border-icon border-icon-rt"></div>
            <div class="border-icon border-icon-rb"></div>
            <div class="card-content">
              <div class="card-data clr-dy">{{ summaryInfo.view_num }}</div>
              <div class="card-text">(人次)</div>
              <div class="card-text">共享调阅</div>
            </div>
          </div>
        </div>
        <div class="charts-block mt35">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="charts-content charts-content-flex">
            <div class="charts-content-flex-item">
              <div class="charts-strip w270 mt20 ml10">
                <div class="charts-strip-text">
                  接入医院
                  <span class="charts-strip-data">{{
                    distributeInfo.org_sum
                  }}</span>
                  家
                </div>
              </div>
              <div class="text-content">
                <div class="text-item bg-shi">
                  市级 {{ distributeInfo.org_num_city }} 家
                </div>
                <div class="text-item bg-xian">
                  区县 {{ distributeInfo.org_num_county }} 家
                </div>
              </div>
              <div class="charts-strip w270 mt20 ml10">
                <div class="charts-strip-text">
                  {{this.year}}年检查阳性率
                </div>
              </div>
              <div class="charts-row charts-row-flex">
                <div class="charts-item">
                  <div class="chart-bar" style="width:160px;height:160px">
                    <chart-item
                      :option="positiveRatioByCityOption"
                    ></chart-item>
                  </div>
                </div>
                <div class="charts-item">
                  <div class="chart-bar" style="width:160px;height:160px">
                    <chart-item
                      :option="positiveRatioByCountyOption"
                    ></chart-item>
                  </div>
                </div>
              </div>
            </div>
            <div class="charts-content-flex-item">
              <div id="map"></div>
            </div>
          </div>
        </div>
        <div class="charts-block mt50">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="charts-title pdr40">
            <img
              class="icon-square"
              src="@/assets/images/dataCockpit/jinhua/icon-square.png"
              alt=""
            />
            <div class="charts-title-text">{{this.year}}年调阅量走势</div>
          </div>
          <div class="charts-content">
            <div class="chart-bar" style="width:100%;height:300px">
              <chart-item :option="viewNumOption"></chart-item>
            </div>
          </div>
        </div>
      </div>
      <div class="charts-section mt27 w600">
        <div class="charts-block">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="charts-title pdr40">
            <img
              class="icon-square"
              src="@/assets/images/dataCockpit/jinhua/icon-square.png"
              alt=""
            />
            <div class="charts-title-text">{{this.year}}年检查量情况</div>
          </div>
          <div class="charts-content">
            <div class="charts-strip w560 mt50 ml10">
              <div class="charts-strip-text">市级分布
                <span class="charts-strip-tip">(人次)</span>
              </div>
            </div>
            <div class="chart-bar" style="width:100%;height:300px">
              <chart-item :option="examNumByCityOption"></chart-item>
            </div>
            <div class="charts-strip w560 mt50 ml10">
              <div class="charts-strip-text">区县分布
                <span class="charts-strip-tip">(人次)</span>

              </div>
            </div>
            <div class="chart-bar" style="width:100%;height:390px">
              <chart-item :option="examNumByCountyOption"></chart-item>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import * as echarts from "echarts";
import ChartItem from "@/components/dataCockpit/ChartItem.vue";
import PageTitle from "@/components/dataCockpit/PageTitle.vue";
import UpdateData from '@/components/dataCockpit/UpdateData.vue'
import utils from "@/utils/PIScommonMethod";
// import Mgr from "@/utils/SecurityService";
import {
  getIDNumberByCity,
  getPhoneNumberByCity,
  getBirthDayByCity,
  getIDNumberByCounty,
  getPhoneNumberByCounty,
  getBirthDayByCounty,
  getDownLoad,
  getSummary,
  getOrgDistribute,
  getPositiveRatioByCity,
  getPositiveRatioByCounty,
  getViewNum,
  getExamNumByCity,
  getExamNumByCounty,
  getPageTitle,
  updatePageTitle
} from "@/api/dataCockpit/jinhua/index";
export default {
  components: { ChartItem, PageTitle, UpdateData },
  data() {
    return {
      isDev: false,
      updateTime: "",
      title: '',
      pageName: '',
      defaultTitle: '金华市区域云影像智慧医疗平台驾驶舱',
      // 饼图公共图表样式
      pieSharedOption: {
        tooltip: {
          show: false
        },
        title: {
          text: "0%",
          top: "center",
          left: "center",
          textStyle: {
            fontSize: 22,
            color: "#fff",
            fontWeight: "normal"
          }
        },
        series: [
          {
            name: "data",
            type: "pie",
            radius: ["60%", "75%"],
            center: ["50%", "50%"],
            label: {
              show: false
            },
            data: [
              {
                value: 0,
                name: "b",
                itemStyle: {
                  color: "transparent"
                }
              },
              {
                value: 0,
                name: "a",
                itemStyle: {
                  color: "#5d7092"
                }
              }
            ]
          },
          {
            name: "data",
            type: "pie",
            radius: ["60%", "80%"],
            center: ["50%", "50%"],
            label: {
              show: false
            },
            data: [
              {
                value: 0,
                name: "b",
                itemStyle: {
                  color: ""
                }
              },
              {
                value: 0,
                name: "a",
                itemStyle: {
                  color: "transparent"
                }
              }
            ]
          }
        ]
      },
      iDNumberByCityInfo: {},
      phoneNumberByCityInfo: {},
      birthDayByCityInfo: {},
      iDNumberByCountyInfo: {},
      phoneNumberByCountyInfo: {},
      birthDayByCountyInfo: {},
      // 下载量和调阅量
      downloadList: [],
      // 各维度总数
      summaryInfo: {},
      // 机构分布
      distributeInfo: {},
      positiveRatioByCity: 0,
      positiveRatioByCounty: 0,
      viewNumList: [],
      examNumByCityList: [],
      examNumByCountyList: [],
      barSharedOption: {
        grid: {
          left: "3%",
          right: "10%",
          bottom: "3%",
          top: "5%",
          containLabel: true
        },
        xAxis: {
          type: "value",
          boundaryGap: [0, 0.01],
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false
          }
        },
        yAxis: {
          type: "category",
          data: [],
          axisTick: {
            show: false
          },
          axisLine: {
            show: false
          },
          axisLabel: {
            color: "rgba(255,255,255,0.8)",
            fontSize: 20
          },
        },
        series: [
          {
            type: "bar",
            label: {
              show: true,
              position: "right",
              color: "#fff",
              fontSize: 22
            },
            data: [],
            barMaxWidth: 20,
            itemStyle: {
                color: new echarts.graphic.LinearGradient(
                    1, 0, 0, 0,
                    [
                        {offset: 1, color: '#93BAFB'},
                        {offset: 0, color: '#6298F4'}
                    ]
                )
            },
          }
        ]
      }
    };
  },
  computed: {
    ...mapGetters(['year']),
    iDNumberByCityOption() {
      let option = null;
      const info = this.iDNumberByCityInfo;
      if (info.hasOwnProperty("ratio")) {
        option = JSON.parse(JSON.stringify(this.pieSharedOption));
        const value = info.ratio;
        const minorValue = parseFloat((100 - value).toFixed(2));
        option.title.text = value + "%";
        option.series[0].data[0].value = value;
        option.series[0].data[1].value = minorValue;
        option.series[1].data[0].value = value;
        option.series[1].data[1].value = minorValue;
        option.series[1].data[0].itemStyle.color = "#6298f4";
      }
      return option;
    },
    phoneNumberByCityOption() {
      let option = null;
      const info = this.phoneNumberByCityInfo;
      if (info.hasOwnProperty("ratio")) {
        option = JSON.parse(JSON.stringify(this.pieSharedOption));
        const value = info.ratio;
        const minorValue = parseFloat((100 - value).toFixed(2));
        option.title.text = value + "%";
        option.series[0].data[0].value = value;
        option.series[0].data[1].value = minorValue;
        option.series[1].data[0].value = value;
        option.series[1].data[1].value = minorValue;
        option.series[1].data[0].itemStyle.color = "#6298f4";
      }
      return option;
    },
    birthDayByCityOption() {
      let option = null;
      const info = this.birthDayByCityInfo;
      if (info.hasOwnProperty("ratio")) {
        option = JSON.parse(JSON.stringify(this.pieSharedOption));
        const value = info.ratio;
        const minorValue = parseFloat((100 - value).toFixed(2));
        option.title.text = value + "%";
        option.series[0].data[0].value = value;
        option.series[0].data[1].value = minorValue;
        option.series[1].data[0].value = value;
        option.series[1].data[1].value = minorValue;
        option.series[1].data[0].itemStyle.color = "#6298f4";
      }
      return option;
    },
    iDNumberByCountyOption() {
      let option = null;
      const info = this.iDNumberByCountyInfo;
      if (info.hasOwnProperty("ratio")) {
        option = JSON.parse(JSON.stringify(this.pieSharedOption));
        const value = info.ratio;
        const minorValue = parseFloat((100 - value).toFixed(2));
        option.title.text = value + "%";
        option.series[0].data[0].value = value;
        option.series[0].data[1].value = minorValue;
        option.series[1].data[0].value = value;
        option.series[1].data[1].value = minorValue;
        option.series[1].data[0].itemStyle.color = "#f6bd16";
      }
      return option;
    },
    phoneNumberByCountyOption() {
      let option = null;
      const info = this.phoneNumberByCountyInfo;
      if (info.hasOwnProperty("ratio")) {
        option = JSON.parse(JSON.stringify(this.pieSharedOption));
        const value = info.ratio;
        const minorValue = parseFloat((100 - value).toFixed(2));
        option.title.text = value + "%";
        option.series[0].data[0].value = value;
        option.series[0].data[1].value = minorValue;
        option.series[1].data[0].value = value;
        option.series[1].data[1].value = minorValue;
        option.series[1].data[0].itemStyle.color = "#f6bd16";
      }
      return option;
    },
    birthDayByCountyOption() {
      let option = null;
      const info = this.birthDayByCountyInfo;
      if (info.hasOwnProperty("ratio")) {
        option = JSON.parse(JSON.stringify(this.pieSharedOption));
        const value = info.ratio;
        const minorValue = parseFloat((100 - value).toFixed(2));
        option.title.text = value + "%";
        option.series[0].data[0].value = value;
        option.series[0].data[1].value = minorValue;
        option.series[1].data[0].value = value;
        option.series[1].data[1].value = minorValue;
        option.series[1].data[0].itemStyle.color = "#f6bd16";
      }
      return option;
    },
    downloadOption() {
      const list = this.downloadList;
      let option = null;
      if (list.length === 0) {
        return option;
      }
      const xAxisData = list.map(x => x.month + "月");
      const dowLoadData = list.map(x => x.down_num);
      const viewNumData = list.map(x => x.view_num);
      option = {
        grid: {
          containLabel: true,
          bottom: "13%",
          left: 10,
          right: "10%",
          top: "25%"
        },
        legend: {
          data: ["下载量", "调阅量"],
          bottom: 0,
          textStyle: {
            color: "rgba(255,255,255,0.7)",
            fontSize: 16
          },
          itemGap: 20
        },
        xAxis: [
          {
            type: "category",
            data: xAxisData,
            axisPointer: {
              type: "shadow"
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              color: "rgba(255,255,255,0.5)",
              fontSize: 18,
              interval: 0
            }
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "下载量(人次)",
            nameTextStyle: {
              color: "rgba(255,255,255,0.5)",
              fontSize: 18
            },

            axisLabel: {
              color: "rgba(255,255,255,0.5)",
              fontSize: 18
            },
            splitLine: {
              lineStyle: {
                color: "rgba(255,255,255,.3)"
              }
            }
          },
          {
            type: "value",
            name: "调阅量(人次)",
            nameTextStyle: {
              color: "rgba(255,255,255,0.5)",
              fontSize: 18
            },
            axisLabel: {
              color: "rgba(255,255,255,0.5)",
              fontSize: 18
            },
            splitLine: {
              lineStyle: {
                color: "rgba(255,255,255,.3)"
              }
            }
          }
        ],
        series: [
          {
            name: "下载量",
            type: "bar",
            data: dowLoadData
          },
          {
            name: "调阅量",
            type: "bar",
            yAxisIndex: 1,
            data: viewNumData
          }
        ]
      };
      return option;
    },
    positiveRatioByCityOption() {
      let option = null;
      const value = this.positiveRatioByCity;
      option = JSON.parse(JSON.stringify(this.pieSharedOption));
      const minorValue = parseFloat((100 - value).toFixed(2));
      option.title.text = value + "%";
      option.title.subtext = "市级";
      option.title.subtextStyle = { fontSize: 16 };
      option.series[0].data[0].value = value;
      option.series[0].data[1].value = minorValue;
      option.series[1].data[0].value = value;
      option.series[1].data[1].value = minorValue;
      option.series[1].data[0].itemStyle.color = "#e8684a";
      return option;
    },
    positiveRatioByCountyOption() {
      let option = null;
      const value = this.positiveRatioByCounty;
      option = JSON.parse(JSON.stringify(this.pieSharedOption));
      const minorValue = parseFloat((100 - value).toFixed(2));
      option.title.text = value + "%";
      option.title.subtext = "县区";
      option.title.subtextStyle = { fontSize: 16 };
      option.series[0].data[0].value = value;
      option.series[0].data[1].value = minorValue;
      option.series[1].data[0].value = value;
      option.series[1].data[1].value = minorValue;
      option.series[1].data[0].itemStyle.color = "#e8684a";
      return option;
    },
    viewNumOption() {
      const list = this.viewNumList;
      let option = null;
      if (list.length === 0) {
        return option;
      }
      const xAxisData = Array.from(new Set(list.map(x => x.month)));
      const y1 = list.filter(x => x.user_type === "患者").map(x => x.view_num);
      const y2 = list.filter(x => x.user_type === "医生").map(x => x.view_num);
      option = {
        legend: {
          bottom: 0,
          textStyle: {
            color: "rgba(255,255,255,0.7)",
            fontSize: 16
          },
          itemGap: 20
        },
        grid: {
          containLabel: true,
          bottom: "13%",
          left: 10,
          right: "10%",
          top: "25%"
        },
        xAxis: [
          {
            type: "category",
            axisLine: {
              show: false,
              color: "#A582EA"
            },

            axisLabel: {
              color: "rgba(255,255,255,0.5)",
              fontSize: 18,
              formatter: "{value}月",
              interval: 0
            },
            splitLine: {
              show: false
            },
            boundaryGap: false,
            data: xAxisData
          }
        ],

        yAxis: [
          {
            type: "value",
            minInterval: 1,
            splitLine: {
              show: true,
              lineStyle: {
                color: "#00BFF3",
                opacity: 0.23
              }
            },
            axisLine: {
              show: false
            },
            axisLabel: {
              color: "rgba(255,255,255,0.5)",
              fontSize: 18
            },
            axisTick: {
              show: false
            }
          }
        ],
        series: [
          {
            name: "移动端患者调阅量",
            type: "line",
            showAllSymbol: true,
            symbol: "circle",
            symbolSize: 10,
            lineStyle: {
              color: "#F6BD16",
              width: 1
            },
            itemStyle: {
              color: "#F6BD16",
              borderColor: "#fff",
              borderWidth: 2
            },
            areaStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(
                  0,
                  0,
                  0,
                  1,
                  [
                    {
                      offset: 0,
                      color: "rgba(246,189,22,0)"
                    },
                    {
                      offset: 1,
                      color: "rgba(246,189,22,0.5)"
                    }
                  ],
                  false
                )
              }
            },
            data: y1 //data.values
          },
          {
            name: "PC端医生调阅量",
            type: "line",
            showAllSymbol: true,
            symbol: "circle",
            symbolSize: 10,
            lineStyle: {
              color: "#5AD8A6",
              width: 1
            },
            itemStyle: {
              color: "#5AD8A6",
              borderColor: "#fff",
              borderWidth: 2
            },
            areaStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(
                  0,
                  0,
                  0,
                  1,
                  [
                    {
                      offset: 0,
                      color: "rgba(90,216,166,0)"
                    },
                    {
                      offset: 1,
                      color: "rgba(90,216,166,0.5)"
                    }
                  ],
                  false
                )
              }
            },
            data: y2 //data.values
          }
        ]
      };
      return option;
    },
    examNumByCityOption() {
      let list = this.examNumByCityList;
      let option = null;
      if (list.length === 0) {
        return option;
      }
      list = list.reverse()
      option = JSON.parse(JSON.stringify(this.barSharedOption));
      const yAxisData = list.map(x => x.org_name)
      const s1 = list.map( x=> x.exam_num)
      option.yAxis.data = yAxisData
      option.series[0].data = s1
      return option
    },
    examNumByCountyOption() {
      let list = this.examNumByCountyList;
      let option = null;
      if (list.length === 0) {
        return option;
      }
      list = list.reverse()
      option = JSON.parse(JSON.stringify(this.barSharedOption));
      const yAxisData = list.map(x => x.county_name)
      const s1 = list.map( x=> x.exam_num)
      option.yAxis.data = yAxisData
      option.series[0].data = s1
      return option
    },
  },
  mounted() {
    this.pageName = this.$route.name
    this.getPageTitle()
    this.initRequest()
  },
  methods: {
    // 更新数据
    updateData() {
      this.initRequest();
    },
    // 查询页面标题
    getPageTitle() {
      const params = {
        title_flag: this.pageName
      }
      getPageTitle(params).then(res => {
        if(res.code === 0) {
          if(res.data.title_name) {
            this.title = res.data.title_name
          }else {
            this.title = this.defaultTitle
          }
        }else {
          this.title = this.defaultTitle
        }
      }).catch(() => {
          this.title = this.defaultTitle
      })
    },
    // 修改页面标题
    updateTitle(title) {
      if(title !== this.title) {
        const params = {
          title_flag: this.pageName,
          title_name: title
        }
        updatePageTitle(params).then(res => {
          if(res.code === 0) {
            this.title = title
          }else {
            this.$message.error(res.msg)
          }
        })
      }
    },
    // 获取api请求的统一参数 客戶id
    getBaseParams() {
      return new Promise((resolve, reject) => {
        // 客戶ID
        // var manager = new Mgr();
        // manager.getRole().then(item => {
        //   if (item) {
        //     this.tenancy_id = sessionStorage.getItem('curTenancyId') || item.profile.tenancy_id;
        //     this.baseParams = {
        //       tenancy_id: this.isDev
        //         ? "1386931148638130176"
        //         : this.tenancy_id
        //     };
        //     resolve();
        //   } else {
        //     reject();
        //   }
        // });
        if (this.$route.query.tenancy_id) {
          this.tenancy_id = this.$route.query.tenancy_id;
          this.baseParams = {
            tenancy_id: this.isDev
              ? "1386931148638130176"
              : this.tenancy_id
          };
          resolve();
        } else {
          reject();
        }
        
      });
    },
    async initRequest() {
      const _date = new Date();
      this.updateTime = utils.dateFormat(_date, 1);
      await this.getBaseParams();
      // 市级 身份证
      this.getIDNumberByCity();
      // 市级 电话号码
      this.getPhoneNumberByCity();
      // 市级 出生日期
      this.getBirthDayByCity();
      // 区县 身份证
      this.getIDNumberByCounty();
      // 区县 电话号码
      this.getPhoneNumberByCounty();
      // 区县 出生日期
      this.getBirthDayByCounty();
      // 省平台下载量
      this.getDownLoad();
      // 各维度总数
      this.getSummary();
      // 机构分布
      this.getOrgDistribute();
      // 市级 放射检查阳性率
      this.getPositiveRatioByCity();
      // 区县 放射检查阳性率
      this.getPositiveRatioByCounty();
      // 调阅量走势
      this.getViewNum();
      // 市级 检查量
      this.getExamNumByCity();
      // 区县 检查量
      this.getExamNumByCounty();
    },
    // 市级 身份证
    getIDNumberByCity() {
      const data = this.baseParams;
      getIDNumberByCity(data).then(res => {
        if (res.code === 0) {
          this.iDNumberByCityInfo = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 市级 电话号码
    getPhoneNumberByCity() {
      const data = this.baseParams;
      getPhoneNumberByCity(data).then(res => {
        if (res.code === 0) {
          this.phoneNumberByCityInfo = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 市级 出生日期
    getBirthDayByCity() {
      const data = this.baseParams;
      getBirthDayByCity(data).then(res => {
        if (res.code === 0) {
          this.birthDayByCityInfo = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 区县 身份证
    getIDNumberByCounty() {
      const data = this.baseParams;
      getIDNumberByCounty(data).then(res => {
        if (res.code === 0) {
          this.iDNumberByCountyInfo = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 区县 电话号码
    getPhoneNumberByCounty() {
      const data = this.baseParams;
      getPhoneNumberByCounty(data).then(res => {
        if (res.code === 0) {
          this.phoneNumberByCountyInfo = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 区县 出生日期
    getBirthDayByCounty() {
      const data = this.baseParams;
      getBirthDayByCounty(data).then(res => {
        if (res.code === 0) {
          this.birthDayByCountyInfo = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 省平台下载量
    getDownLoad() {
      const data = this.baseParams;
      getDownLoad(data).then(res => {
        if (res.code === 0) {
          this.downloadList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 各维度总数
    getSummary() {
      const data = this.baseParams;
      getSummary(data).then(res => {
        if (res.code === 0) {
          this.summaryInfo = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 机构分布
    getOrgDistribute() {
      const data = this.baseParams;
      getOrgDistribute(data).then(res => {
        if (res.code === 0) {
          this.distributeInfo = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 市级 放射检查阳性率
    getPositiveRatioByCity() {
      const data = this.baseParams;
      getPositiveRatioByCity(data).then(res => {
        if (res.code === 0) {
          this.positiveRatioByCity = res.data.ratio;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 区县 放射检查阳性率
    getPositiveRatioByCounty() {
      const data = this.baseParams;
      getPositiveRatioByCounty(data).then(res => {
        if (res.code === 0) {
          this.positiveRatioByCounty = res.data.ratio;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 调阅量走势
    getViewNum() {
      const data = this.baseParams;
      getViewNum(data).then(res => {
        if (res.code === 0) {
          this.viewNumList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 市级 检查量
    getExamNumByCity() {
      const data = this.baseParams;
      getExamNumByCity(data).then(res => {
        if (res.code === 0) {
          this.examNumByCityList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 区县 检查量
    getExamNumByCounty() {
      const data = this.baseParams;
      getExamNumByCounty(data).then(res => {
        if (res.code === 0) {
          this.examNumByCountyList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.f1 {
  flex: 1;
}
.mt20 {
  margin-top: 20px;
}
.mt50 {
  margin-top: 50px;
}
.mt27 {
  margin-top: 27px;
}
.mt35 {
  margin-top: 35px;
}
.ml10 {
  margin-left: 10px;
}
.w270 {
  width: 270px;
}
.w560 {
  width: 560px;
}
.w595 {
  width: 595px;
}
.w600 {
  width: 600px;
}
.h180 {
  height: 180px;
}
.pdr40 {
  padding-right: 40px;
}
.clr-hz {
  color: #5ad8a6;
}
.clr-jc {
  color: #f6bd16;
}
.clr-dy {
  color: #e8684a;
}
.bg-shi {
  background: #6298f4;
}
.bg-xian {
  background: #5ad8a6;
}
.text-content {
  margin-top: 20px;
  margin-left: 10px;
  overflow: hidden;
}
.text-item {
  height: 40px;
  line-height: 40px;
  color: #fff;
  font-size: 20px;
  float: left;
  padding: 0 7px;
  border-radius: 4px;
  & + & {
    margin-left: 20px;
  }
}
#map {
  width: 264px;
  height: 337px;
  background: url("~@/assets/images/dataCockpit/jinhua/map.png") no-repeat center;
}
.container-bg {
  width: 1920px;
  height: 1080px;
  background: url("~@/assets/images/dataCockpit/jinhua/bg.png");
}
.header-content {
  width: 100%;
  height: 76px;
  position: relative;
  padding: 0 20px;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  background: url("~@/assets/images/dataCockpit/jinhua/header.png") no-repeat center;
  .time {
    color: #00d3ff;
    font-size: 16px;
    padding: 5px 0;
    display: flex;
    align-items: center;
  }
  ::v-deep .title {
    width: 650px;
    font-size: 32px;
    line-height: 66px;
    color: #fff;
    font-weight: 700;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    text-align: center;
    letter-spacing: 4px;
    cursor: pointer;
  }
}
.card {
  &-list {
    width: 100%;
    display: flex;
    justify-content: space-between;
  }
  &-item {
    width: 130px;
    height: 120px;
    padding: 8px;
    position: relative;
    text-align: center;
    border: 1px solid rgba(90, 150, 253, 0.5);
  }
  &-content {
    width: 100%;
    height: 100%;
    background: rgba(78, 78, 78, 0.15);
    border: 1px solid rgba(78, 78, 78, 0.16);
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  &-data {
    font-size: 18px;
    margin-top: 15px;
    margin-bottom: 3px;
  }
  &-text {
    font-size: 14px;
    color: #fff;
    & + & {
      margin-top: 3px;
    }
  }
}

.chart {
  &-name {
    color: #fff;
    font-size: 14px;
    text-align: center;
  }
}
.charts {
  &-container {
    margin: 20px 40px;
    display: flex;
    justify-content: space-between;
  }
  &-block {
    border: 1px solid rgba(90, 150, 253, 0.5);
    padding: 8px;
    position: relative;
  }
  &-row {
    &-flex {
      display: flex;
      justify-content: space-around;
      align-items: center;
    }
  }
  &-title {
    height: 40px;
    position: absolute;
    top: -26px;
    left: 8px;
    background: linear-gradient(
      to left,
      rgba(83, 146, 253, 0.3),
      rgba(83, 146, 253, 0)
    );
    &-text {
      font-size: 24px;
      color: #fff;
      font-weight: 600;
      margin-left: 15px;
      margin-top: 5px;
      float: left;
    }
    &-tip {
      font-size: 14px;
      color: #fff;
      float: right;
      margin-left: 20px;
      margin-top: 20px;
    }
  }
  &-content {
    width: 100%;
    background: rgba(78, 78, 78, 0.15);
    border: 1px solid rgba(78, 78, 78, 0.16);
    padding-bottom: 20px;
    &-flex {
      display: flex;
      justify-content: space-between;
    }
  }
  &-strip {
    height: 33px;
    background: linear-gradient(
      to left,
      rgba(83, 146, 253, 0.15),
      rgba(83, 146, 253, 0)
    );
    &-text {
      font-size: 24px;
      color: #fff;
    }
    &-data {
      color: #6298f4;
      margin: 0 10px;
    }
    &-tip {
      color: #fff;
      font-size: 14px;
      float: right;
      line-height: 31px;
      margin-right: 20px;
    }
  }
}
.icon-square {
  float: left;
}
.border-icon {
  width: 10px;
  height: 10px;
  &-lt {
    position: absolute;
    top: -3px;
    left: -3px;
    background: url("~@/assets/images/dataCockpit/jinhua/border-lt.png");
  }
  &-lb {
    position: absolute;
    bottom: -3px;
    left: -3px;
    background: url("~@/assets/images/dataCockpit/jinhua/border-lb.png");
  }
  &-rt {
    position: absolute;
    top: -3px;
    right: -3px;
    background: url("~@/assets/images/dataCockpit/jinhua/border-rt.png");
  }
  &-rb {
    position: absolute;
    bottom: -3px;
    right: -3px;
    background: url("~@/assets/images/dataCockpit/jinhua/border-rb.png");
  }
}
</style>
