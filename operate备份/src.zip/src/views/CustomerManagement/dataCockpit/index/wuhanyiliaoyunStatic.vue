<template>
  <div class="container-bg">
    <div class="header-content">
      <div class="navbar">
        <!-- <div
          class="navbar-item"
          :class="{ 'navbar-item-selected': navbarIndex === item.value }"
          v-for="item in navbarList"
          :key="item.value"
          @click="selectNavbar(item)"
        >
          {{ item.name }}
        </div> -->
        <span class="addInstitute timeChoose fl">
          <el-radio-group
            v-model="searchData.time_type"
            @change="initRequest()"
          >
            <el-radio-button
              :label="item.value"
              v-for="(item, index) in navbarList"
              :key="index"
              >{{ item.name }}</el-radio-button
            >
          </el-radio-group>
        </span>
        <span class="addInstitute timeChoose fr ml10">
          <el-radio-group
            v-model="searchData.institution_type"
            @change="initRequest()"
          >
            <el-radio-button
              :label="item.value"
              v-for="(item, index) in institutionTypeArr"
              :key="index"
              >{{ item.name }}</el-radio-button
            >
          </el-radio-group>
        </span>
      </div>
      <page-title
        :title="title"
        :initSize="32"
        :initMax="19"
        :width="680"
        :letterSpace="3"
        @updateTitle="updateTitle"
      ></page-title>
      <div class="time">
        <!-- <span class="updateTimeLabel" style="margin-right: 25px">更新日期：{{ updateTime }}</span> -->
        <span class="updateTimeLabel" style="margin-right: 25px">日期:{{ updateTime }}</span>
        <update-data class="updateTimeCon" @updateData="updateData"></update-data>
      </div>
    </div>
    <div class="charts-container">
      <div class="section-container chartSection h970">
        <div class="charts-section w580 h480">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/wuhanzhongxin/icon_img.png"
                alt=""
              />
              <!-- <span>{{this.year}}远程诊断</span> -->
              <span>【影像诊断】趋势图/申请量TOP5</span>
            </div>
            <span class="charts-header-tip">单位:人次</span>
          </div>
          <div class="twoChartCon">

            <div
              v-if="searchData.institution_type != 4"
              class="chart-bar"
              v-bind:class="{
                noData: telemedicineTotalObj.radiology_apply && telemedicineTotalObj.radiology_apply.length == 0,
              }"
              style="width: 100%; height: 50%; position: relative"
            >
              <chart-item
                :option="imgDiagnosisLineOption"
                v-show="imgDiagnosisLineOption"
              ></chart-item>
            </div>
           <!--共建+自建-->
           <div
              v-else
              class="chart-bar"
              v-bind:class="{
                noData: telemedicineTotalObj.radiology_applyObj&&telemedicineTotalObj.radiology_applyObj.gjData.length == 0 && telemedicineTotalObj.radiology_applyObj.zjData.length,
              }"
              style="width: 100%; height: 50%; position: relative"
            >
              <chart-item
                :option="imgDiagnosisLineOption"
                v-show="imgDiagnosisLineOption"
              ></chart-item>
            </div>
           <!--影像诊断检查类型图-->
            <div
              v-if="searchData.institution_type != 4"
              class="chart-bar charts-item-bt barAndPieChart"
              v-bind:class="{ noData: image_inspect_class.length == 0 }"
              style="width: 100%; height: 50%"
            >
              <chart-item
                :option="diagnosisTypeBarOption"
                :action="'consult'"
                v-show="diagnosisTypeBarOption"
              ></chart-item>
            </div>
            
            <div
              v-else
              class="chart-bar charts-item-bt barAndPieChart"
              v-bind:class="{ noData: image_inspect_class.length == 0 }"
              style="width: 100%; height: 50%"
            >
              <chart-item
                :option="diagnosisTypeBarOption"
                :action="'consult'"
                v-show="diagnosisTypeBarOption"
              ></chart-item>
            </div>
          </div>
        </div>
     <!--共建+自建-->
        <div class="charts-section w580 bottomChart">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/wuhanzhongxin/icon_pis.png"
                alt=""
              />
              <!-- <span>{{this.year}}远程诊断</span> -->
              <span>【病理诊断】趋势图/申请量TOP5</span>
            </div>
            <span class="charts-header-tip">单位:人次</span>
          </div>
          <div class="twoChartCon">
            <!--病理折线图-->
            <div
             v-if="searchData.institution_type != 4"
              class="chart-bar"
              v-bind:class="{
                noData: telemedicineTotalObj.pis_apply &&telemedicineTotalObj.pis_apply.length == 0,
              }"
              style="width: 100%; height: 50%; position: relative"
            >
              <chart-item
                :option="pisDiagnosisLineOption"
                v-show="pisDiagnosisLineOption"
              ></chart-item>
            </div>

           <!--共建+自建-->
           <div
              v-else
              class="chart-bar"
              v-bind:class="{
                noData: telemedicineTotalObj.pis_applyObj && telemedicineTotalObj.pis_applyObj.zjData.length == 0&& telemedicineTotalObj.pis_applyObj.gjData.length == 0,
              }"
              style="width: 100%; height: 50%; position: relative"
            >
              <chart-item
                :option="pisDiagnosisLineOption"
                v-show="pisDiagnosisLineOption"
              ></chart-item>
            </div>
            <div
              class="charts-item-bt chart-bar"
              v-bind:class="{
                noData: telemedicineTotalObj.pis_institution_apply.length == 0,
              }"
              style="width: 100%; height: 50%"
            >
              <chart-item
                :option="pisProgressOption"
                v-show="pisProgressOption"
              ></chart-item>
              <!-- <chart-item
                        :option="progressShareOption"
                        v-show="progressShareOption"
                    ></chart-item> -->
            </div>
          </div>
        </div>
      </div>
      <div class="section-container h970 ml10">
        <div class="charts-section w700 h480">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>

          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon mr10"
                src="@/assets/images/dataCockpit/yunshangfuyou/ptgl.png"
                alt=""
              />
              <span>平台概览</span>
            </div>
          </div>
          <div class="charts-cards">
            <div class="charts-card charts-card-jg">
              <div class="charts-card-content">
                <div class="charts-card-title">应接机构</div>
                <div class="charts-card-data blueNum">
                  {{
                    telemedicineTotalObj.platform_overview &&
                    telemedicineTotalObj.platform_overview.receive_institution_num
                  }}
                </div>
              </div>
            </div>
            <div class="charts-card charts-card-jg">
              <div class="charts-card-content">
                <div class="charts-card-title">接入机构</div>
                <div class="charts-card-data blueNum">
                  {{
                    telemedicineTotalObj.platform_overview &&
                    telemedicineTotalObj.platform_overview.join_institution_num
                  }}
                </div>
              </div>
            </div>
            <div class="charts-card charts-card-yh">
              <div class="charts-card-content">
                <div class="charts-card-title">医护人员</div>
                <div class="charts-card-data greenNum">
                  {{
                    telemedicineTotalObj.platform_overview &&
                    telemedicineTotalObj.platform_overview.doctor_num
                  }}
                </div>
              </div>
            </div>
            <div class="charts-card charts-card-zx">
              <div class="charts-card-content">
                <div class="charts-card-title">应接服务中心</div>
                <div class="charts-card-data orangeNum">
                  {{
                    telemedicineTotalObj.platform_overview &&
                    telemedicineTotalObj.platform_overview.receive_service_center_num
                  }}
                </div>
              </div>
            </div>
            <div class="charts-card charts-card-zx">
              <div class="charts-card-content">
                <div class="charts-card-title">接入服务中心</div>
                <div class="charts-card-data orangeNum">
                  {{
                    telemedicineTotalObj.platform_overview &&
                    telemedicineTotalObj.platform_overview.join_service_center_num
                  }}
                </div>
              </div>
            </div>
          </div>
          <div class="flex-content">
            <div class="flex-item">
              <div class="charts-item">
                <div class="news-container">
                  <div class="news-container-title tfont">业务动态</div>
                  <div class="news-item imgTotal">
                    <span>
                      <span class="news-item-title bussessModelName"
                        >影像诊断</span
                      >
                      <span class="news-item-num">{{
                        telemedicineTotalObj.platform_overview &&
                        telemedicineTotalObj.platform_overview.radiology_num
                      }}</span>
                    </span>
                    <span class="news-item-title mr10">人次</span>
                  </div>
                  <div class="news-item ecgTotal">
                    <span>
                      <span class="news-item-title bussessModelName"
                        >心电诊断</span
                      >
                      <span class="news-item-num">{{
                        telemedicineTotalObj.platform_overview &&
                        telemedicineTotalObj.platform_overview.ecg_num
                      }}</span>
                    </span>
                    <span class="news-item-title mr10">人次</span>
                  </div>
                  <div class="news-item pisTotal">
                    <span>
                      <span class="news-item-title bussessModelName"
                        >病理诊断</span
                      >
                      <span class="news-item-num">{{
                        telemedicineTotalObj.platform_overview &&
                        telemedicineTotalObj.platform_overview.pis_num
                      }}</span>
                    </span>
                    <span class="news-item-title mr10">人次</span>
                  </div>
                  <div class="news-item usTotal">
                    <span>
                      <span class="news-item-title bussessModelName"
                        >超声诊断</span
                      >
                      <span class="news-item-num">{{
                        telemedicineTotalObj.platform_overview &&
                        telemedicineTotalObj.platform_overview.uis_num
                      }}</span>
                    </span>
                    <span class="news-item-title mr10">人次</span>
                  </div>
                  <div class="news-item consultTotal">
                    <span>
                      <span class="news-item-title bussessModelName"
                        >远程会诊</span
                      >
                      <span class="news-item-num">{{
                        telemedicineTotalObj.platform_overview &&
                        telemedicineTotalObj.platform_overview.consult_num
                      }}</span>
                    </span>
                    <span class="news-item-title mr10">人次</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="flex-item mapContainer">
              <div class="card-map"></div>
            </div>
          </div>
        </div>
        <div class="charts-section mt10 w700 bottomChart">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/wuhanzhongxin/icon_consult.png"
                alt=""
              />
              <span>【远程会诊】分布图/申请量TOP5</span>
            </div>
            <span class="charts-header-tip">单位:人次</span>
          </div>
          <div class="twoChartCon">
            <div
              class="chart-bar"
              v-bind:class="{ noData: consultList.length == 0 }"
              style="width: 100%; height: 50%; position: relative"
            >
              <clickChartItem
                :option="consultBarOption"
                :action="'consult'"
                v-show="consultBarOption"
                @clickChartFunc="clickChartFunc"
              ></clickChartItem>
            </div>
            <!--会诊折线图-->
            <div
              v-if="searchData.institution_type != 4"
              class="chart-bar charts-item-bt"
              v-bind:class="{ noData: consult_bussess_list.length == 0 }"
              style="width: 100%; height: 50%"
            >
              <chart-item
                :option="consultLineOption"
                v-show="consultLineOption"
              ></chart-item>
            </div>
            <div
              v-else
              class="chart-bar charts-item-bt"
              v-bind:class="{ noData: consult_bussess_listObj&&consult_bussess_listObj.gjData.length == 0 && consult_bussess_listObj.zjData.length == 0 }"
              style="width: 100%; height: 50%"
            >
              <chart-item
                :option="consultLineOption"
                v-show="consultLineOption"
              ></chart-item>
            </div>
          </div>
        </div>
      </div>
      <div class="section-container chartSection h970 ml10">
        <div class="charts-section w580 h480">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/wuhanzhongxin/icon_ecg.png"
                alt=""
              />
              <!-- <span>{{this.year}}远程诊断</span> -->
              <span>【心电诊断】趋势图/申请量TOP5</span>
            </div>
            <span class="charts-header-tip">单位:人次</span>
          </div>
          <div class="twoChartCon">
            <!--心电折线图-->
            <div
              v-if="searchData.institution_type != 4"
              class="chart-bar"
              v-bind:class="{
                noData: telemedicineTotalObj.ecg_apply.length == 0,
              }"
              style="width: 100%; height: 50%; position: relative"
            >
              <chart-item
                :option="ecgDiagnosisLineOption"
                v-show="ecgDiagnosisLineOption"
              ></chart-item>
            </div>
            <!--共建+自建-->
            <div
              v-else
              class="chart-bar"
              v-bind:class="{
                noData: telemedicineTotalObj.ecg_applyObj && telemedicineTotalObj.ecg_applyObj.gjData.length == 0 && telemedicineTotalObj.ecg_applyObj.zjData.length == 0,
              }"
              style="width: 100%; height: 50%; position: relative"
            >
              <chart-item
                :option="ecgDiagnosisLineOption"
                v-show="ecgDiagnosisLineOption"
              ></chart-item>
            </div>
            <div
              class="chart-bar charts-item-bt barAndPieChart"
              v-bind:class="{
                noData: telemedicineTotalObj.ecg_institution_apply.length == 0,
              }"
              style="width: 100%; height: 50%"
            >
              <chart-item
                :option="ecgProgressOption"
                v-show="ecgProgressOption"
              ></chart-item>
            </div>
          </div>
        </div>

        <div class="charts-section w580 bottomChart">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/wuhanzhongxin/icon_us.png"
                alt=""
              />
              <!-- <span>{{this.year}}远程诊断</span> -->
              <span>【超声诊断】趋势图/申请量TOP5</span>
            </div>
            <span class="charts-header-tip">单位：人次</span>
          </div>
          <div class="twoChartCon">
            <!--超声折线图-->
            <div
              v-if="searchData.institution_type != 4"
              class="chart-bar"
              v-bind:class="{
                noData: telemedicineTotalObj.uis_apply.length == 0,
              }"
              style="width: 100%; height: 50%; position: relative"
            >
              <chart-item
                :option="usDiagnosisLineOption"
                v-show="usDiagnosisLineOption"
              ></chart-item>
            </div>
            <!--自建+共建-->
            <div
              v-else
              class="chart-bar"
              v-bind:class="{
                noData: telemedicineTotalObj.uis_applyObj && telemedicineTotalObj.uis_applyObj.gjData.length == 0  && telemedicineTotalObj.uis_applyObj.zjData.length == 0,
              }"
              style="width: 100%; height: 50%; position: relative"
            >
              <chart-item
                :option="usDiagnosisLineOption"
                v-show="usDiagnosisLineOption"
              ></chart-item>
            </div>
            <div
              class="charts-item-bt chart-bar"
              v-bind:class="{
                noData: telemedicineTotalObj.uis_institution_apply.length == 0,
              }"
              style="width: 100%; height: 50%"
            >
              <chart-item
                :option="usProgressOption"
                v-show="usProgressOption"
              ></chart-item>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import axios from "axios";
import { mapGetters } from "vuex";
import * as echarts from "echarts";
import ChartItem from "@/components/dataCockpit/ChartItem.vue";
import clickChartItem from "../components/ChartItem.vue";
import PageTitle from "../components/PageTitle.vue";
import UpdateData from "@/components/dataCockpit/UpdateData.vue";
import utils from "@/utils/PIScommonMethod";
import Mgr from "@/utils/SecurityService";
import {
  getTelemedicineTotal,
  updatePageTitle,
} from "@/api/dataCockpit/wuhanzhongxin/index";
export default {
  components: { ChartItem, PageTitle, UpdateData, clickChartItem },
  data() {
    return {
      isDev: false,
      title: "",
      pageName: "",
      defaultTitle: "医疗救治应用服务(远程监管)总览",
      tenancy_id: "",
      baseParams: null,
      updateTime: "",
      searchData: {
        time_type: 1,
        institution_type: 1,
      },
      telemedicineTotalObj: {
        consult: [],
        diagnostic_apply_date: [],
        ecg_apply: [],
        ecg_institution_apply: [],
        pis_apply: [],
        pis_institution_apply: [],
        platform_overview: {
          consult_num: 0,
          doctor_num: 0,
          ecg_num: 0,
          institution_num: 0,
          pis_num: 0,
          radiology_num: 0,
          service_center_num: 0,
          uis_num: 0,
          use_amount: "0GB",
        },
        radiology_apply: [],
        radiology_instituion_apply: [],
        uis_apply: [],
        uis_institution_apply: [],
      },
      totalUnit: "",
      navbarList: [
        { name: "本月", value: 1 },
        { name: "本年", value: 2 },
        // { name: '近3月', value: 3 },
        // { name: '近6月', value: 4 },
        // { name: '近1年', value: 5 }
      ],
      institutionTypeArr: [
        { name: "全部", value: 1 },
        { name: "自建", value: 2 },
        { name: "共建", value: 3 },
        { name: "自建+共建", value: 4 },
      ],
      navbarIndex: 1,
      consult_bussess_listObj: {
        gjData: [],
        zjData: []
      },
      // 会诊业务折线图数据
      consult_bussess_list: [],
      // 远程诊断分布统计
      diagnosisList: [],
      // 影像检查类型
      image_inspect_class: [],
      // 远程会诊分布统计
      consultList: [],
      // 会诊机构分布情况
      consultProgressList: [],
      // 双y轴柱状图图表共享使用的option
      barDoubleYOption: {
        tooltip: {
          trigger: "item",
          triggerOn: "click",
          alwaysShowContent: true,
          axisPointer: {
            type: "cross",
            crossStyle: {
              color: "#999",
            },
          },
        },
        legend: {
          data: [],
          orient: "horizontal",
          icon: "rect",
          show: true,
          textStyle: {
            //图例文字的样式
            color: "#fff",
            fontSize: 14,
          },
          itemWidth: 12, // 设置宽度
          itemHeight: 12, // 设置高度
          itemGap: 13, // 设置间距
          right: "10px",
          top: "0px",
        },
        grid: {
          left: "15px",
          right: "15px",
          top: "20px",
          bottom: "15px",
          containLabel: true,
        },
        xAxis: [
          {
            type: "category",
            data: [],
            axisPointer: {
              type: "shadow",
            },
            axisLabel: {
              color: "#00d3ff",
              width: 20,
            },
          },
        ],
        yAxis: [
          {
            type: "value",
            splitLine: {
              lineStyle: {
                //坐标线样式
                type: "dashed",
                color: "#00d3ff",
                opacity: 0.3,
              },
            },
            axisLabel: {
              //y轴上的 刻度值样式
              color: "#00d3ff",
            },
          },
        ],
        series: [
          {
            name: "诊断量",
            type: "bar",
            data: [],
            itemStyle: {
              normal: {
                //柱图高亮渐变色
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#6298f4",
                  },
                  {
                    offset: 1,
                    color: "#93BAFB",
                  },
                ]),
                barBorderRadius: [2, 2, 0, 0],
              },
            },
          },
          {
            name: "申请量",
            type: "bar",
            data: [],
            itemStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#19A576",
                  },
                  {
                    offset: 1,
                    color: "#20C88E",
                  },
                ]),
                //圆角
                barBorderRadius: [2, 2, 0, 0],
              },
            },
          },
        ],
      },
      // 双折线图共用option
      twoLineShareOption: {
        backgroundColor: "rgba(40,46,72,0)",
        grid: {
          left: "15px",
          right: "15px",
          top: "20px",
          bottom: "15px",
          containLabel: true,
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "line",
            lineStyle: {
              // color:'rgba(50, 216, 205, 1)'
              color: "#4992ff",
            },
          },
        },
        legend: {
          data: [],
          orient: "horizontal",
          icon: "rect",
          show: true,
          textStyle: {
            //图例文字的样式
            color: "#fff",
            fontSize: 14,
          },
          itemWidth: 12, // 设置宽度
          itemHeight: 12, // 设置高度
          itemGap: 13, // 设置间距
          right: "10px",
          top: "0px",
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: 1,
            axisLine: {
              show: false,
            },
            axisLabel: {
              color: "#00d3ff",
            },
            splitLine: {
              show: false,
            },
            axisTick: {
              show: false,
            },
            data: [],
          },
        ],
        yAxis: [
          {
            type: "value",
            splitLine: {
              lineStyle: {
                //坐标线样式
                type: "dashed",
                color: "#00d3ff",
                opacity: 0.3,
              },
            },
            axisLabel: {
              //y轴上的 刻度值样式
              color: "#00d3ff",
            },
          },
        ],
        // yAxis: [
        //   {
        //     type: "value",
        //     name: "",
        //     min: 0,
        //     max: 100,
        //     interval: 20,
        //     axisLabel: {
        //       formatter: "{value} ",
        //     },
        //     axisLabel: {
        //       textStyle: {
        //         //坐标轴颜色
        //         color: "rgba(36, 173, 254, 1)",
        //         fontSize: "1rem",
        //       },
        //     },
        //     //坐标轴线样式
        //     splitLine: {
        //       show: true,
        //       lineStyle: {
        //         type: "solid", //solid实线;dashed虚线
        //         color: "rgba(36, 173, 254, 0.2)",
        //       },
        //     },
        //   },
        //   {
        //     type: "value",
        //     name: "",
        //     min: 0,
        //     max: 100,
        //     interval: 20,
        //     axisLabel: {
        //       formatter: "{value}",
        //     },
        //     axisLabel: {
        //       textStyle: {
        //         //坐标轴颜色
        //         color: "rgba(36, 173, 254, 1)",
        //         fontSize: "1rem",
        //       },
        //     },
        //     //坐标轴线样式
        //     splitLine: {
        //       show: true,
        //       lineStyle: {
        //         type: "solid",
        //         color: "rgba(36, 173, 254, 0.2)",
        //       },
        //     },
        //   },
        // ],
        series: [
          {
            name: "共建",
            data: [],
            type: "line",
            smooth: true, //true曲线; false折线
            symbolSize: 5,
            showSymbol: false,
            itemStyle: {
              normal: {
                //柱图高亮渐变色
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#6298f4",
                  },
                  {
                    offset: 1,
                    color: "#93BAFB",
                  },
                ]),
                barBorderRadius: [2, 2, 0, 0],
              },
            },
            areaStyle: {
              //折线图颜色半透明
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(98,152,244, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(98,152,244, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
            },
          },
          {
            name: "自建",
            data: [],
            type: "line",
            smooth: true, //true曲线; false折线
            symbolSize: 5,
            showSymbol: false,
            itemStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#19A576",
                  },
                  {
                    offset: 1,
                    color: "#20C88E",
                  },
                ]),
                //圆角
                barBorderRadius: [2, 2, 0, 0],
              },
            },
            areaStyle: {
              //折线图颜色半透明
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(25,165,118, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(25,165,118, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
            },
          },
        ],
      },
      // 折线图共用option
      lineShareOption: {
        backgroundColor: "rgba(40,46,72,0)",
        grid: {
          left: "15px",
          right: "15px",
          top: "20px",
          bottom: "15px",
          containLabel: true,
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "line",
            lineStyle: {
              // color:'rgba(50, 216, 205, 1)'
              color: "#4992ff",
            },
          },
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: 1,
            axisLine: {
              show: false,
            },
            axisLabel: {
              color: "#00d3ff",
            },
            splitLine: {
              show: false,
            },
            axisTick: {
              show: false,
            },

            //data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
            data: [],
          },
        ],
        yAxis: [
          {
            type: "value",
            name: "",
            padding: 5,
            // max: 1000,
            splitLine: {
              show: true,
              lineStyle: {
                color: "#0e3868",
                type: "dashed",
              },
            },
            axisLine: {
              show: false,
            },
            axisLabel: {
              show: true,
              margin: 5,
              textStyle: {
                color: "#00d3ff",
              },
            },
            axisTick: {
              show: false,
            },
          },
        ],
        series: [
          {
            name: "今日",
            type: "line",
            smooth: true,
            stack: "总量",
            symbolSize: 5,
            showSymbol: false,
            itemStyle: {
              normal: {
                color: "#4992ff",
                lineStyle: {
                  color: "#4992ff",
                  width: 2,
                },
              },
            },
            areaStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(
                  0,
                  0,
                  0,
                  1,
                  [
                    {
                      offset: 0,
                      color: "rgba(73,164,255,0.5)",
                    },
                    {
                      offset: 1,
                      color: "rgba(73,164,255,0)",
                    },
                  ],
                  false
                ),
              },
            },
            // data: [220, 182, 191, 234, 290, 330, 310, 201, 154, 190, 330, 410]
            data: [],
          },
        ],
      },
      // 进度条option
      progressShareOption: {
        tooltip: {
          showContent: true,
          trigger: "axis",
          backgroundColor: "rgba(8,36,68,.7)",
          color: "#fff",
          textStyle: {
            color: "#fff",
          },
        },
        grid: {
          left: "15px",
          right: "15px",
          top: "20px",
          bottom: "0px",
          containLabel: true,
        },
        xAxis: [
          {
            splitLine: {
              show: false,
            },
            type: "value",
            show: false,
          },
        ],
        yAxis: [
          {
            splitLine: {
              show: false,
            },
            axisLine: {
              //y轴
              show: false,
            },
            type: "category",
            axisTick: {
              show: false,
            },
            inverse: true,
            data: [],
            axisLabel: {
              color: "#00D3FF",
              fontSize: 14,
              margin: 10,
              show: true,
              formatter: function (value) {
                console.log("value", value);
                if (value.length > 10) {
                  return value.substring(0, 10) + "...";
                } else {
                  return value;
                }
              },
            },
          },
          {
            type: "category",
            inverse: true,
            axisTick: "none",
            axisLine: "none",
            show: true,
            axisLabel: {
              textStyle: {
                color: "#00D3FF",
                fontSize: "14",
              },
            },
            // data: value,
            // data: [900, 380, 360, 340, 11320],
            data: [],
          },
        ],
        series: [
          {
            name: "申请量",
            type: "bar",
            barWidth: 16, // 柱子宽度
            showBackground: true,
            MaxSize: 0,
            backgroundStyle: {
              color: "#1a224a",
              borderRadius: [0, 8, 8, 0],
            },
            label: {
              show: false,
              // color: '#A7D6F4',
              // fontSize: 14,
              // distance: 20, // 距离
              // formatter: '{c} ', // 这里是数据展示的时候显示的数据
              // align: "center",
              // position: [290, 0]
            }, // 柱子上方的数值
            itemStyle: {
              barBorderRadius: [0, 8, 8, 0], // 圆角（左上、右上、右下、左下）
              color: new echarts.graphic.LinearGradient(
                1,
                0,
                0,
                0,
                [
                  {
                    offset: 0,
                    color: "#6298f4",
                  },
                  {
                    offset: 1,
                    color: "#93bafb",
                  },
                ],
                false
              ), // 渐变
            },
            //data: [900, 380, 360, 340, 320],
            data: [],
          },
        ],
      },
    };
  },
  computed: {
    ...mapGetters(["year"]),
    // 影像诊断分布图表
    imgDiagnosisLineOption() {
      let option = null;
      // 单线
      if (this.searchData.institution_type !== 4) {
        let list = [];
        if (this.telemedicineTotalObj.radiology_apply) {
          list = this.telemedicineTotalObj.radiology_apply;
        }
        if (list.length === 0 || typeof list === "string") {
          return option;
        }
        option = JSON.parse(JSON.stringify(this.lineShareOption));
        const xData = this.telemedicineTotalObj.diagnostic_apply_date;
        const yData = this.telemedicineTotalObj.radiology_apply;
        option.xAxis[0].data = xData;
        // 设置x轴 刻度显示的个数
        let xNum = this.dealXdata();
        option.xAxis[0].axisLabel.formatter = function (value, i) {
          if ((i + 2) % xNum == 0) return value;
          else return "";
        };
        option.series[0].data = yData;
        option.series[0].barWidth = 20;
        option.series[0].name = "申请量";
        option.tooltip.axisPointer.lineStyle.color = "#2564f7"; // 鼠标放上去 竖线提示的颜色
        option.series[0].itemStyle = {
        normal: {
          color: "#2564f7", // 鼠标放上去 圆圈的颜色
          lineStyle: {
            color: "#2564f7",
            width: 2,
          },
        },
      };
      option.series[0].areaStyle = {
        normal: {
          color: new echarts.graphic.LinearGradient(
            0,
            0,
            0,
            1,
            [
              {
                offset: 0,
                color: "rgba(37,100,247,0.5)",
              },
              {
                offset: 1,
                color: "rgba(37,100,247,0)",
              },
            ],
            false
          ),
        },
      };

        // 设置单折线图的颜色 在不同tab下的颜色
        // 自建
        if (this.searchData.institution_type == 2) {
          option.series[0].itemStyle = {
            normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#19A576",
                  },
                  {
                    offset: 1,
                    color: "#20C88E",
                  },
                ]),
                //圆角
                barBorderRadius: [2, 2, 0, 0],
              },
          }
          option.series[0].areaStyle = {
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(25,165,118, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(25,165,118, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
            }
        } 
        // 共建
        else if (this.searchData.institution_type == 3) {
          option.series[0].itemStyle = {
            normal: {
                //柱图高亮渐变色
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#6298f4",
                  },
                  {
                    offset: 1,
                    color: "#93BAFB",
                  },
                ]),
                barBorderRadius: [2, 2, 0, 0],
              },
          };        
          option.series[0].areaStyle = {
            color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(98,152,244, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(98,152,244, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
          }
        }
        
      } else {
        // 双线图
        let list = {};
        if (this.telemedicineTotalObj.radiology_applyObj) {
          list = this.telemedicineTotalObj.radiology_applyObj;
        }
        if (!list) {
          return option;
        }
        option = JSON.parse(JSON.stringify(this.twoLineShareOption));
        const xData = this.telemedicineTotalObj.diagnostic_apply_date;
        option.legend.data = ['共建','自建']
        option.xAxis[0].data = xData;
        // 设置x轴 刻度显示的个数
        let xNum = this.dealXdata();
        option.xAxis[0].axisLabel.formatter = function (value, i) {
          if ((i + 2) % xNum == 0) return value;
          else return "";
        };
        // let firstIndustry = [
        //   10, 20, 25, 40, 35, 40, 30, 20, 40, 30, 20, 30, 20, 20, 40, 30, 20, 10,
        // ]; //共建
        // let thirdIndustry = [
        //   10, 20, 25, 30, 20, 40, 30, 20, 10, 40, 20, 30, 20, 20, 40, 30, 20, 10,
        // ]; //自建
        if (this.telemedicineTotalObj.radiology_applyObj) {
          option.series[0].data = this.telemedicineTotalObj.radiology_applyObj.gjData;
          option.series[1].data = this.telemedicineTotalObj.radiology_applyObj.zjData;
        }
      }
      return option;
    },
    // 会诊折线图
    consultLineOption() {
      let option = null;
      // 单线
      if (this.searchData.institution_type !== 4) {
        let list = [];
        if (this.consult_bussess_list) {
          list = this.consult_bussess_list;
        }
        if (list.length === 0 || typeof list === "string") {
          return option;
        }
        option = JSON.parse(JSON.stringify(this.lineShareOption));
        //   const xData = list.map(x => x.name);
        //   const yData = list.map(x => x.num);
        const xData = this.telemedicineTotalObj.diagnostic_apply_date;
        const yData = this.consult_bussess_list;
        option.xAxis[0].data = xData;
        // 设置x轴 刻度显示的个数
        let xNum = this.dealXdata();
        option.xAxis[0].axisLabel.formatter = function (value, i) {
          if ((i + 2) % xNum == 0) return value;
          else return "";
        };
        option.series[0].data = yData;
        option.series[0].barWidth = 20;
        option.series[0].name = "申请量";
        // 设置单折线图的颜色 在不同tab下的颜色
        // 自建
        if (this.searchData.institution_type == 2) {
          option.series[0].itemStyle = {
            normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#19A576",
                  },
                  {
                    offset: 1,
                    color: "#20C88E",
                  },
                ]),
                //圆角
                barBorderRadius: [2, 2, 0, 0],
              },
          }
          option.series[0].areaStyle = {
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(25,165,118, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(25,165,118, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
            }
        } 
        // 共建
        else if (this.searchData.institution_type == 3) {
          option.series[0].itemStyle = {
            normal: {
                //柱图高亮渐变色
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#6298f4",
                  },
                  {
                    offset: 1,
                    color: "#93BAFB",
                  },
                ]),
                barBorderRadius: [2, 2, 0, 0],
              },
          };        
          option.series[0].areaStyle = {
            color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(98,152,244, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(98,152,244, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
          }
        }
      } else {
        // 双线图
        let list = {};
        if (this.consult_bussess_listObj) {
          list = this.consult_bussess_listObj;
        }
        if (!list) {
          return option;
        }
        option = JSON.parse(JSON.stringify(this.twoLineShareOption));
        const xData = this.telemedicineTotalObj.diagnostic_apply_date;
        option.legend.data = ['共建','自建']
        option.xAxis[0].data = xData;
        // 设置x轴 刻度显示的个数
        let xNum = this.dealXdata();
        option.xAxis[0].axisLabel.formatter = function (value, i) {
          if ((i + 2) % xNum == 0) return value;
          else return "";
        };
        if (this.consult_bussess_listObj) {
          option.series[0].data = this.consult_bussess_listObj.gjData;
          option.series[1].data = this.consult_bussess_listObj.zjData;
        }
      }
      
      return option;
    },
    // 影像诊断进度条
    imgProgressOption() {
      let option = null;
      //const list = [{name:'武汉中医附属医院医院',num:900},{name:'武汉市妇幼保健院医院',num:380},{name:'武汉第二附属医院医院',num:360},{name:'武汉市人民医院医院',num:340},{name:'武汉市第一医院医院',num:320}]
      let list = [];
      if (this.telemedicineTotalObj.radiology_instituion_apply) {
        list = this.telemedicineTotalObj.radiology_instituion_apply;
      }
      if (list.length === 0 || typeof list === "string") {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.progressShareOption));
      option.yAxis[0].axisLabel.formatter = function (value) {
        if (value.length > 10) {
          return value.substring(0, 10) + "...";
        } else {
          return value;
        }
      };
      let xData = [];
      list.forEach((val, index) => {
        if (val.hasOwnProperty("name")) {
          xData.push(val.name);
        }
      });
      let imgDiagnosisData = [];
      list.forEach((val, index) => {
        if (val.hasOwnProperty("name")) {
          imgDiagnosisData.push(val.subtotal);
        }
      });
      // const imgDiagnosisData = list.map(x => x.subtotal);
      option.yAxis[0].data = xData;
      option.yAxis[1].data = imgDiagnosisData;
      option.series[0].data = imgDiagnosisData;
      //  option.series[0].name='影像诊断'
      return option;
    },
    // 病理诊断分布图表option
    pisDiagnosisLineOption() {
      let option = null;
      // 单线
      if (this.searchData.institution_type !== 4) {
       let list = [];
      if (this.telemedicineTotalObj.pis_apply) {
        list = this.telemedicineTotalObj.pis_apply;
      }
      if (list.length === 0 || typeof list === "string") {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.lineShareOption));
      const xData = this.telemedicineTotalObj.diagnostic_apply_date;
      const yData = this.telemedicineTotalObj.pis_apply;
      option.tooltip.axisPointer.lineStyle.color = "#e86e4a";
      option.xAxis[0].data = xData;
      // 设置x轴 刻度显示的个数
      let xNum = this.dealXdata();
      option.xAxis[0].axisLabel.formatter = function (value, i) {
        if ((i + 2) % xNum == 0) return value;
        else return "";
      };
      option.series[0].data = yData;
      option.series[0].barWidth = 20;
      option.series[0].name = "申请量";
      option.series[0].itemStyle = {
        normal: {
          color: "#e86e4a",
          lineStyle: {
            color: "#e86e4a",
            width: 2,
          },
        },
      };
      option.series[0].areaStyle = {
        normal: {
          color: new echarts.graphic.LinearGradient(
            0,
            0,
            0,
            1,
            [
              {
                offset: 0,
                color: "rgba(227,102,74,0.5)",
              },
              {
                offset: 1,
                color: "rgba(227,102,74,0)",
              },
            ],
            false
          ),
        },
      };
        // 设置单折线图的颜色 在不同tab下的颜色
        // 自建
        if (this.searchData.institution_type == 2) {
          option.series[0].itemStyle = {
            normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#19A576",
                  },
                  {
                    offset: 1,
                    color: "#20C88E",
                  },
                ]),
                //圆角
                barBorderRadius: [2, 2, 0, 0],
              },
          }
          option.series[0].areaStyle = {
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(25,165,118, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(25,165,118, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
            }
        } 
        // 共建
        else if (this.searchData.institution_type == 3) {
          option.series[0].itemStyle = {
            normal: {
                //柱图高亮渐变色
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#6298f4",
                  },
                  {
                    offset: 1,
                    color: "#93BAFB",
                  },
                ]),
                barBorderRadius: [2, 2, 0, 0],
              },
          };        
          option.series[0].areaStyle = {
            color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(98,152,244, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(98,152,244, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
          }
        }

      } else {
        // 双线图
        let list = {};
        if (this.telemedicineTotalObj.pis_applyObj) {
          list = this.telemedicineTotalObj.pis_applyObj;
        }
        if (!list) {
          return option;
        }
        option = JSON.parse(JSON.stringify(this.twoLineShareOption));
        const xData = this.telemedicineTotalObj.diagnostic_apply_date;
        option.legend.data = ['共建','自建']
        option.xAxis[0].data = xData;
        // 设置x轴 刻度显示的个数
        let xNum = this.dealXdata();
        option.xAxis[0].axisLabel.formatter = function (value, i) {
          if ((i + 2) % xNum == 0) return value;
          else return "";
        };
        // let firstIndustry = [
        //   10, 20, 25, 40, 35, 40, 30, 20, 40, 30, 20, 30, 20, 20, 40, 30, 20, 10,
        // ]; //共建
        // let thirdIndustry = [
        //   10, 20, 25, 30, 20, 40, 30, 20, 10, 40, 20, 30, 20, 20, 40, 30, 20, 10,
        // ]; //自建
        if (this.telemedicineTotalObj.pis_applyObj) {
          option.series[0].data = this.telemedicineTotalObj.pis_applyObj.gjData;
          option.series[1].data = this.telemedicineTotalObj.pis_applyObj.zjData;
        }
      }
      
      return option;
    },
    // 病理诊断进度条
    pisProgressOption() {
      let option = null;
      //const list = [{name:'武汉中医附属医院医院',num:900},{name:'武汉市妇幼保健院医院',num:380},{name:'武汉第二附属医院医院',num:360},{name:'武汉市人民医院医院',num:340},{name:'武汉市第一医院医院',num:320}]
      let list = [];
      if (this.telemedicineTotalObj.pis_institution_apply) {
        list = this.telemedicineTotalObj.pis_institution_apply;
      }
      if (list.length === 0 || typeof list === "string") {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.progressShareOption));
      option.yAxis[0].axisLabel.formatter = function (value) {
        if (value.length > 10) {
          return value.substring(0, 10) + "...";
        } else {
          return value;
        }
      };
      //const xData = list.map(x => x.name);
      let xData = [];
      list.forEach((val, index) => {
        if (val.hasOwnProperty("name")) {
          xData.push(val.name);
        }
      });
      let pisDiagnosisData = [];
      list.forEach((val, index) => {
        if (val.hasOwnProperty("name")) {
          pisDiagnosisData.push(val.subtotal);
        }
      });
      //const pisDiagnosisData = list.map(x => x.subtotal);
      option.yAxis[0].data = xData;
      option.yAxis[1].data = pisDiagnosisData;
      option.series[0].data = pisDiagnosisData;
      //   option.series[0].name='病理诊断'
      option.series[0].itemStyle = {
        barBorderRadius: [0, 8, 8, 0], // 圆角（左上、右上、右下、左下）
        color: new echarts.graphic.LinearGradient(
          1,
          0,
          0,
          0,
          [
            {
              offset: 0,
              color: "#e8684a",
            },
            {
              offset: 1,
              color: "#ff8468",
            },
          ],
          false
        ), // 渐变
      };
      return option;
    },
    // 心电诊断分布图表option
    ecgDiagnosisLineOption() {
      let option = null;
      // 单线
      if (this.searchData.institution_type !== 4) {
        let list = [];
      if (this.telemedicineTotalObj.ecg_apply) {
        list = this.telemedicineTotalObj.ecg_apply;
      }
      if (list.length === 0 || typeof list === "string") {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.lineShareOption));
      const xData = this.telemedicineTotalObj.diagnostic_apply_date;
      const yData = this.telemedicineTotalObj.ecg_apply;
      option.tooltip.axisPointer.lineStyle.color = "#fa708c";
      option.xAxis[0].data = xData;
      // 设置x轴 刻度显示的个数
      let xNum = this.dealXdata();
      option.xAxis[0].axisLabel.formatter = function (value, i) {
        if ((i + 2) % xNum == 0) return value;
        else return "";
      };
      option.series[0].data = yData;
      option.series[0].barWidth = 20;
      option.series[0].name = "申请量";
      option.series[0].itemStyle = {
        normal: {
          color: "#fa708c",
          lineStyle: {
            color: "#fa708c",
            width: 2,
          },
        },
      };
      option.series[0].areaStyle = {
        normal: {
          color: new echarts.graphic.LinearGradient(
            0,
            0,
            0,
            1,
            [
              {
                offset: 0,
                color: "rgba(250,112,140,0.5)",
              },
              {
                offset: 1,
                color: "rgba(250,112,140,0)",
              },
            ],
            false
          ),
        },
      };

       // 设置单折线图的颜色 在不同tab下的颜色
        // 自建
        if (this.searchData.institution_type == 2) {
          option.series[0].itemStyle = {
            normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#19A576",
                  },
                  {
                    offset: 1,
                    color: "#20C88E",
                  },
                ]),
                //圆角
                barBorderRadius: [2, 2, 0, 0],
              },
          }
          option.series[0].areaStyle = {
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(25,165,118, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(25,165,118, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
            }
        } 
        // 共建
        else if (this.searchData.institution_type == 3) {
          option.series[0].itemStyle = {
            normal: {
                //柱图高亮渐变色
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#6298f4",
                  },
                  {
                    offset: 1,
                    color: "#93BAFB",
                  },
                ]),
                barBorderRadius: [2, 2, 0, 0],
              },
          };        
          option.series[0].areaStyle = {
            color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(98,152,244, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(98,152,244, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
          }
        }

      } else {
         // 双线图
        let list = {};
        if (this.telemedicineTotalObj.ecg_applyObj) {
          list = this.telemedicineTotalObj.ecg_applyObj;
        }
        if (!list) {
          return option;
        }
        option = JSON.parse(JSON.stringify(this.twoLineShareOption));
        const xData = this.telemedicineTotalObj.diagnostic_apply_date;
        option.legend.data = ['共建','自建']
        option.xAxis[0].data = xData;
        // 设置x轴 刻度显示的个数
        let xNum = this.dealXdata();
        option.xAxis[0].axisLabel.formatter = function (value, i) {
          if ((i + 2) % xNum == 0) return value;
          else return "";
        };
        // let firstIndustry = [
        //   10, 20, 25, 40, 35, 40, 30, 20, 40, 30, 20, 30, 20, 20, 40, 30, 20, 10,
        // ]; //共建
        // let thirdIndustry = [
        //   10, 20, 25, 30, 20, 40, 30, 20, 10, 40, 20, 30, 20, 20, 40, 30, 20, 10,
        // ]; //自建
        if (this.telemedicineTotalObj.ecg_applyObj) {
          option.series[0].data = this.telemedicineTotalObj.ecg_applyObj.gjData;
          option.series[1].data = this.telemedicineTotalObj.ecg_applyObj.zjData;
        }
      }
      
      return option;
    },
    // 心电诊断进度条
    ecgProgressOption() {
      let option = null;
      //const list = [{name:'武汉中医附属医院医院',num:900},{name:'武汉市妇幼保健院医院',num:380},{name:'武汉第二附属医院医院',num:360},{name:'武汉市人民医院医院',num:340},{name:'武汉市第一医院医院',num:320}]
      let list = [];
      if (this.telemedicineTotalObj.ecg_institution_apply) {
        list = this.telemedicineTotalObj.ecg_institution_apply;
      }
      if (list.length === 0 || typeof list === "string") {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.progressShareOption));
      option.yAxis[0].axisLabel.formatter = function (value) {
        if (value.length > 10) {
          return value.substring(0, 10) + "...";
        } else {
          return value;
        }
      };
      let xData = [];
      list.forEach((val, index) => {
        if (val.hasOwnProperty("name")) {
          xData.push(val.name);
        }
      });
      let ecgDiagnosisData = [];
      list.forEach((val, index) => {
        if (val.hasOwnProperty("name")) {
          ecgDiagnosisData.push(val.subtotal);
        }
      });
      //const ecgDiagnosisData = list.map(x => x.subtotal);
      option.yAxis[0].data = xData;
      option.yAxis[1].data = ecgDiagnosisData;
      option.series[0].data = ecgDiagnosisData;
      //option.series[0].name='心电诊断'
      option.series[0].itemStyle = {
        barBorderRadius: [0, 8, 8, 0], // 圆角（左上、右上、右下、左下）
        color: new echarts.graphic.LinearGradient(
          1,
          0,
          0,
          0,
          [
            {
              offset: 0,
              color: "#ed4869",
            },
            {
              offset: 1,
              color: "#fa708c",
            },
          ],
          false
        ), // 渐变
      };
      return option;
    },
    // 超声诊断分布图表option
    usDiagnosisLineOption() {
      let option = null;
      // 单线
      if (this.searchData.institution_type !== 4) {
        let list = [];
      if (this.telemedicineTotalObj.uis_apply) {
        list = this.telemedicineTotalObj.uis_apply;
      }
      if (list.length === 0 || typeof list === "string") {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.lineShareOption));
      //   const xData = list.map(x => x.name);
      //   const yData = list.map(x => x.num);
      const xData = this.telemedicineTotalObj.diagnostic_apply_date;
      const yData = this.telemedicineTotalObj.uis_apply;
      option.tooltip.axisPointer.lineStyle.color = "#DE9000";
      option.xAxis[0].data = xData;
      // 设置x轴 刻度显示的个数
      let xNum = this.dealXdata();
      option.xAxis[0].axisLabel.formatter = function (value, i) {
        if ((i + 2) % xNum == 0) return value;
        else return "";
      };
      option.series[0].data = yData;
      option.series[0].barWidth = 20;
      option.series[0].name = "申请量";
      option.series[0].itemStyle = {
        normal: {
          color: "#DE9000",
          lineStyle: {
            color: "#DE9000",
            width: 2,
          },
        },
      };
      option.series[0].areaStyle = {
        normal: {
          color: new echarts.graphic.LinearGradient(
            0,
            0,
            0,
            1,
            [
              {
                offset: 0,
                color: "rgba(222,114,0,0.5)",
              },
              {
                offset: 1,
                color: "rgba(222,114,0,0)",
              },
            ],
            false
          ),
        },
      };
        // 设置单折线图的颜色 在不同tab下的颜色
        // 自建
        if (this.searchData.institution_type == 2) {
          option.series[0].itemStyle = {
            normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#19A576",
                  },
                  {
                    offset: 1,
                    color: "#20C88E",
                  },
                ]),
                //圆角
                barBorderRadius: [2, 2, 0, 0],
              },
          }
          option.series[0].areaStyle = {
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(25,165,118, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(25,165,118, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
            }
        } 
        // 共建
        else if (this.searchData.institution_type == 3) {
          option.series[0].itemStyle = {
            normal: {
                //柱图高亮渐变色
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: "#6298f4",
                  },
                  {
                    offset: 1,
                    color: "#93BAFB",
                  },
                ]),
                barBorderRadius: [2, 2, 0, 0],
              },
          };        
          option.series[0].areaStyle = {
            color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "rgba(98,152,244, 0.3)", // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: "rgba(98,152,244, 0)", // 100% 处的颜色
                  },
                ],
                global: false, // 缺省为 false
              },
          }
        }
      } else {
         // 双线图
        let list = {};
        if (this.telemedicineTotalObj.uis_applyObj) {
          list = this.telemedicineTotalObj.uis_applyObj;
        }
        if (!list) {
          return option;
        }
        option = JSON.parse(JSON.stringify(this.twoLineShareOption));
        const xData = this.telemedicineTotalObj.diagnostic_apply_date;
        option.legend.data = ['共建','自建']
        option.xAxis[0].data = xData;
        // 设置x轴 刻度显示的个数
        let xNum = this.dealXdata();
        option.xAxis[0].axisLabel.formatter = function (value, i) {
          if ((i + 2) % xNum == 0) return value;
          else return "";
        };
        // let firstIndustry = [
        //   10, 20, 25, 40, 35, 40, 30, 20, 40, 30, 20, 30, 20, 20, 40, 30, 20, 10,
        // ]; //共建
        // let thirdIndustry = [
        //   10, 20, 25, 30, 20, 40, 30, 20, 10, 40, 20, 30, 20, 20, 40, 30, 20, 10,
        // ]; //自建
        if (this.telemedicineTotalObj.uis_applyObj) {
          option.series[0].data = this.telemedicineTotalObj.uis_applyObj.gjData;
          option.series[1].data = this.telemedicineTotalObj.uis_applyObj.zjData;
        }
      }
      
      return option;
    },
    // 超声诊断进度条
    usProgressOption() {
      let option = null;
      //const list = [{name:'武汉中医附属医院医院',num:900},{name:'武汉市妇幼保健院医院',num:380},{name:'武汉第二附属医院医院',num:360},{name:'武汉市人民医院医院',num:340},{name:'武汉市第一医院医院',num:320}]
      let list = [];
      if (this.telemedicineTotalObj.uis_institution_apply) {
        list = this.telemedicineTotalObj.uis_institution_apply;
      }
      if (list.length === 0 || typeof list === "string") {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.progressShareOption));
      option.yAxis[0].axisLabel.formatter = function (value) {
        if (value.length > 10) {
          return value.substring(0, 10) + "...";
        } else {
          return value;
        }
      };
      let xData = [];
      list.forEach((val, index) => {
        if (val.hasOwnProperty("name")) {
          xData.push(val.name);
        }
      });
      let usDiagnosisData = [];
      list.forEach((val, index) => {
        if (val.hasOwnProperty("name")) {
          usDiagnosisData.push(val.subtotal);
        }
      });
      //const usDiagnosisData = list.map(x => x.subtotal);
      option.yAxis[0].data = xData;
      option.yAxis[1].data = usDiagnosisData;
      option.series[0].data = usDiagnosisData;
      //option.series[0].name='超声诊断'
      option.series[0].itemStyle = {
        barBorderRadius: [0, 8, 8, 0], // 圆角（左上、右上、右下、左下）
        color: new echarts.graphic.LinearGradient(
          1,
          0,
          0,
          0,
          [
            {
              offset: 0,
              color: "#de9000",
            },
            {
              offset: 1,
              color: "#fdab13",
            },
          ],
          false
        ), // 渐变
      };
      return option;
    },
    // 诊断类型分布图表option
    diagnosisTypeBarOption() {
      let option = null;
      if (this.searchData.institution_type !== 4) {
        // 单柱状图(共建)
        const list = this.image_inspect_class;
        if (list.length === 0 || typeof list === "string") {
          return option;
        }
        option = JSON.parse(JSON.stringify(this.barDoubleYOption));
        option.legend.data = ['共建']
        const xData = list.map((x) => {
          if (x.name) {
            return x.name;
          }
        });
        const consultCountArr = list.map((x) => x.zj_num);
        const applyCountArr = list.map((x) => x.apply_num);
        option.xAxis[0].data = xData;
        option.series.pop()
        option.series[0].data = consultCountArr;
        option.series[0].barWidth = 20;
        option.tooltip = {},
        option.series[0].itemStyle = {     //上方显示数值
          normal: {
              label: {
                  show: true, //开启显示
                  position: 'top', //在上方显示
                  textStyle: { //数值样式
                      color: '#fff',
                      fontSize: 14
                  }
              },
              //柱图高亮渐变色
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "#2564f7",
              },
              {
                offset: 1,
                color: "#298fff",
              },
            ]),
            barBorderRadius: [2, 2, 0, 0],
          }
        }
        // 设置单柱状图的颜色 在不同tab下的颜色
        // 自建
        if (this.searchData.institution_type == 2) {
          option.series[0].itemStyle.normal.color = new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "#6298f4",
              },
              {
                offset: 1,
                color: "#93BAFB",
              },
            ])
        }
        //共建
        else if (this.searchData.institution_type == 3) {
          option.series[0].itemStyle.normal.color = new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "#19A576",
              },
              {
                offset: 1,
                color: "#20C88E",
              },
            ])
        }
      } else {
        const list = this.image_inspect_class;
        if (list.length === 0 || typeof list === "string") {
          return option;
        }
        option = JSON.parse(JSON.stringify(this.barDoubleYOption));
        const consultlegendData = ["共建", "自建"];
        const xData = list.map((x) => {
          if (x.name) {
            return x.name;
          }
        });
        const consultCountArr = list.map((x) => x.diagnosis_num);
        const applyCountArr = list.map((x) => x.apply_num);
        option.legend.data = consultlegendData;
        option.xAxis[0].data = xData;
        option.series[0].data = consultCountArr;
        option.series[0].barWidth = 20;
        option.series[0].name = "共建";
        option.series[1].name = "自建";
        option.series[1].data = applyCountArr;
        option.series[1].barWidth = 20;
      }
      
      
      return option;
    },
    // 远程会诊分布图表option
    consultBarOption() {
      let option = null;
      if (this.searchData.institution_type !== 4) {
        // 单柱状图(共建)
        const list = this.consultList;
        if (list.length === 0 || typeof list === "string") {
          return option;
        }
        option = JSON.parse(JSON.stringify(this.barDoubleYOption));
        option.legend.data = ['共建']
        const xData = list.map((x) => {
          if (x.name) {
            return x.name;
          }
        });
        const consultCountArr = list.map((x) => x.zj_num);
        const applyCountArr = list.map((x) => x.apply_num);
        option.xAxis[0].data = xData;
        option.series.pop()
        option.series[0].data = consultCountArr;
        option.series[0].barWidth = 20;
        option.tooltip = {},
        option.series[0].itemStyle = {    //上方显示数值
          normal: {
              label: {
                  show: true, //开启显示
                  position: 'top', //在上方显示
                  textStyle: { //数值样式
                      color: '#fff',
                      fontSize: 14
                  }
              },
              //柱图高亮渐变色
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "#2564f7",
              },
              {
                offset: 1,
                color: "#298fff",
              },
            ]),
            barBorderRadius: [2, 2, 0, 0],
          }
        }
        // 设置单柱状图的颜色 在不同tab下的颜色
        // 自建
        if (this.searchData.institution_type == 2) {
          option.series[0].itemStyle.normal.color = new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "#6298f4",
              },
              {
                offset: 1,
                color: "#93BAFB",
              },
            ])
        }
        //共建
        else if (this.searchData.institution_type == 3) {
          option.series[0].itemStyle.normal.color = new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "#19A576",
              },
              {
                offset: 1,
                color: "#20C88E",
              },
            ])
        }
      }else{
        // 双柱状图
        const list = this.consultList;
        if (list.length === 0 || typeof list === "string") {
          return option;
        }
        option = JSON.parse(JSON.stringify(this.barDoubleYOption));
        const consultlegendData = ["共建", "自建"];
        //const xData = list.map(x => x.name);
        const xData = list.map((x) => {
          if (x.name) {
            return x.name;
          }
        });
        const consultCountArr = list.map((x) => x.diagnosis_num);
        const applyCountArr = list.map((x) => x.apply_num);
        // const maxValue = list[0].exam_num;
        //const maxData = new Array(list.length).fill(maxValue);
        option.legend.data = consultlegendData;
        option.xAxis[0].data = xData;
        option.series[0].data = consultCountArr;
        option.series[0].barWidth = 20;
        option.tooltip = {
          trigger: "item",
          triggerOn: "click",
          alwaysShowContent: true,
          axisPointer: {
            type: "cross",
            crossStyle: {
              color: "#999",
            },
          },
        },
        option.series[0].name = "共建";
        option.series[1].data = applyCountArr;
        option.series[1].barWidth = 20;
        option.series[1].name = "自建";
      }
      
      return option;
    },
    // 会诊进度条
    consultProgressOption() {
      let option = null;
      //const list = [{name:'武汉中医附属医院医院',num:900},{name:'武汉市妇幼保健院医院',num:380},{name:'武汉第二附属医院医院',num:360},{name:'武汉市人民医院医院',num:340},{name:'武汉市第一医院医院',num:320}]
      const list = this.consultProgressList;
      if (list.length === 0 || typeof list === "string") {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.progressShareOption));
      option.yAxis[0].axisLabel.formatter = function (value) {
        if (value.length > 10) {
          return value.substring(0, 10) + "...";
        } else {
          return value;
        }
      };
      let xData = [];
      list.forEach((val, index) => {
        if (val.hasOwnProperty("name")) {
          xData.push(val.name);
        }
      });
      let consultDiagnosisData = [];
      list.forEach((val, index) => {
        if (val.hasOwnProperty("name")) {
          consultDiagnosisData.push(val.subtotal);
        }
      });
      //const consultDiagnosisData = list.map(x => x.subtotal);
      option.yAxis[0].data = xData;
      option.yAxis[1].data = consultDiagnosisData;
      option.series[0].data = consultDiagnosisData;
      option.series[0].name = "申请量";
      option.series[0].itemStyle = {
        barBorderRadius: [0, 8, 8, 0], // 圆角（左上、右上、右下、左下）
        color: new echarts.graphic.LinearGradient(
          1,
          0,
          0,
          0,
          [
            {
              offset: 0,
              color: "#19a576",
            },
            {
              offset: 1,
              color: "#20c88e",
            },
          ],
          false
        ), // 渐变
      };
      return option;
    },
  },
  mounted() {
    const self = this
    self.pageName = self.$route.name;
    self.initRequest();
    let timer = null
    clearInterval(timer)
    timer = setInterval(function(){
      self.searchData.institution_type++
      if (self.searchData.institution_type == 5) {
        self.searchData.institution_type = 1
      }
      self.initRequest();
    },5000)
  },
  methods: {
    dealXdata() {
      return 1;
      //   if (this.navbarIndex === 1 || this.navbarIndex === 2) {
      //     return 1
      //   } else if (this.navbarIndex === 3) {
      //     return 1
      //   } else {
      //     return 1
      //   }
    },
    // 获取远程医疗所有的统计
    getTelemedicineTotal() {
      const self = this;
      if (self.searchData.institution_type !== 4) {
        axios.get("/wuhanyiliaoyun.json").then((response) => { // 本地开发用
        //axios.get("https://tymh.whhealth.org.cn/hbwhexpo/mtyw/operate/wuhanyiliaoyun.json").then((response) => {
        //axios.get("http://88.3.201.67:82/mtyw/operate/wuhanyiliaoyun.json").then((response) => {  
        let res = response.data;
        if (res.code === 0) {
          self.telemedicineTotalObj = res.data;
          if (res.data.title) {
            self.title = res.data.title;
          } else {
            self.title = self.defaultTitle;
          }
          // 赋值影像检查类型
          self.image_inspect_class = res.data.image_inspect_class;
          // 赋值远程会诊数据
          self.consultList = res.data.consult;
          if (self.telemedicineTotalObj.platform_overview) {
            let length =
              self.telemedicineTotalObj.platform_overview.use_amount.length;
            self.totalUnit =
              self.telemedicineTotalObj.platform_overview.use_amount.substring(
                length - 2,
                length
              );
            let useAmountNum = parseFloat(
              self.telemedicineTotalObj.platform_overview.use_amount.substring(
                0,
                length - 2
              )
            );
            self.telemedicineTotalObj.platform_overview.use_amount =
              useAmountNum.toFixed(2);
          }
          //
          if (self.consultList.length !== 0) {
            self.consult_bussess_list =
              self.consultList[0].consult_bussess_list;
          }
        } else {
          self.$message.error(res.msg);
        }
       }); 
      } else {
        // 共建+自建
        axios.get("/gjAndzj.json").then((response) => { // 本地开发用
        //axios.get("https://tymh.whhealth.org.cn/hbwhexpo/mtyw/operate/gjAndzj.json").then((response) => {
       // axios.get("http://88.3.201.67:82/mtyw/operate/gjAndzj.json").then((response) => {
        let res = response.data;
        if (res.code === 0) {
          self.telemedicineTotalObj = res.data;
          if (res.data.title) {
            self.title = res.data.title;
          } else {
            self.title = self.defaultTitle;
          }
          // 赋值影像检查类型
          self.image_inspect_class = res.data.image_inspect_class;
          // 赋值远程会诊数据
          self.consultList = res.data.consult;
          if (self.telemedicineTotalObj.platform_overview) {
            let length =
              self.telemedicineTotalObj.platform_overview.use_amount.length;
            self.totalUnit =
              self.telemedicineTotalObj.platform_overview.use_amount.substring(
                length - 2,
                length
              );
            let useAmountNum = parseFloat(
              self.telemedicineTotalObj.platform_overview.use_amount.substring(
                0,
                length - 2
              )
            );
            self.telemedicineTotalObj.platform_overview.use_amount =
              useAmountNum.toFixed(2);
          }
          //
          if (self.consultList.length !== 0) {
            self.consult_bussess_listObj =
              self.consultList[0].consult_bussess_listObj; // 注意这里不一样
          }
        } else {
          self.$message.error(res.msg);
        }
      });
      }
      
    },
    // 点击柱状图
    clickChartFunc(index, action) {
      if (action === "consult") {
        if (
          this.consultList[index] && (this.consultList[index].consult_bussess_list || this.consultList[index].consult_bussess_listObj)) {
          if (this.searchData.institution_type !== 4) {
             this.consult_bussess_list =
            this.consultList[index].consult_bussess_list;
          } else {
            // 共建+自建
            this.consult_bussess_listObj =
            this.consultList[index].consult_bussess_listObj;
          }
          
        } else {
          this.consultProgressList = [];
          this.consultProgressListObj = {}
        }
      }
    },
    selectNavbar(item) {
      const { value } = item;
      if (this.navbarIndex !== value) {
        this.navbarIndex = value;
        this.initRequest();
      }
    },
    // 更新数据
    updateData() {
      this.initRequest();
    },
    // 修改页面标题
    updateTitle(title) {
      if (title !== this.title) {
        const params = {
          title: title,
        };
        updatePageTitle(params).then((res) => {
          if (res.code === 0) {
            this.title = title;
          } else {
            this.$message.error(res.msg);
          }
        });
      }
    },
    // 获取api请求的统一参数 客戶id
    getBaseParams() {
      return new Promise((resolve, reject) => {
        // 客戶ID
        var manager = new Mgr();
        manager.getRole().then((item) => {
          if (item) {
            this.tenancy_id = sessionStorage.getItem('curTenancyId') || item.profile.tenancy_id;
            this.baseParams = {
              tenancy_id: this.isDev ? "0" : this.tenancy_id,
            };
            resolve();
          } else {
            reject();
          }
        });
      });
    },
    async initRequest() {
      const _date = new Date();
      this.updateTime = utils.dateFormat(_date, 1);
      //await this.getBaseParams();
      // 获取远程医疗所有的统计
      this.getTelemedicineTotal();
    },
    // 远程诊断统计
    getDiagnosisTotal() {
      const data = this.baseParams;
      getDiagnosisTotal(data).then((res) => {
        if (res.code === 0) {
          //this.diagnosisList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
  },
};
</script>
<style lang="less" scoped>
.w145 {
  width: 145px;
}
::v-deep .title-text {
  font-size:32px;
}
.w300 {
  width: 300px;
}
.w560 {
  width: 560px;
}
.w580 {
  // width: 580px;
  width:100%;
}
.h310 {
  height: 310px;
}
.h420 {
  height: 420px;
}
.h480 {
  height: 480px;
}
.bottomChart{
  height:480px;
}
.h560 {
  height: 560px;
}
.h540 {
  height: 540px;
}
.h400 {
  height: 400px;
}
.h970 {
  height: 970px;
}
.col-hz {
  color: #f6bd16;
}
.col-jc {
  color: #6298f4;
}
.col-cc {
  color: #5ad8a6;
}
.col-dy {
  color: #ff7100;
}

.container-bg {
  // width: 1920px;
  width:100%;
  height: 1080px;
  background: url("~@/assets/images/dataCockpit/jinhua2/bg.png");
}
.header-content {
  width: 100%;
  height: 76px;
  position: relative;
  padding: 0 20px;
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  // background: url("~@/assets/images/dataCockpit/jinhua2/header_bg.png");
  background: url("~@/assets/images/dataCockpit/jinhua2/header_bg.png") center;
  ::v-deep .title {
    width: 680px;
    font-size: 32px;
    // line-height: 76px;
    line-height: 60px;
    color: #00d3ff;
    font-weight: 700;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    text-align: center;
    letter-spacing: 3px;
    cursor: pointer;
  }
}
.section-container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.firstSection{
  width:35%;
}
.chartSection{
  width:calc(50% - 295px);
}
.navbar {
  height: 34px;
  display: flex;
  align-items: center;
  &-item {
    width: 72px;
    height: 34px;
    font-size: 16px;
    color: #00d3ff;
    line-height: 34px;
    text-align: center;
    cursor: pointer;
    background: url("~@/assets/images/dataCockpit/anji/platform/nav_bg.png");
    & + & {
      margin-left: 5px;
    }
    &-selected {
      background: url("~@/assets/images/dataCockpit/anji/platform/nav_selected.png") !important;
    }
    &:hover {
      background: url("~@/assets/images/dataCockpit/anji/platform/nav_hover.png");
    }
  }
  .timeChoose {
    line-height: initial;
  }
  ::v-deep .el-radio-group {
    height: 34px;
    line-height: 32px;
    .el-radio-button__inner {
      height: 34px;
      line-height: 32px;
      padding: 0 15px !important;
      color: #00d3ff;
      background: rgba(87, 91, 105, 0.15) !important;
      border: 1px solid #2050a8;
      border-right: none;
    }
    .el-radio-button:last-of-type {
      .el-radio-button__inner {
        border-right: 1px solid #2050a8;
      }
    }
    .el-radio-button__inner:hover {
      border-color: #367fff;
      color: #fff;
    }
    .el-radio-button__orig-radio:checked + .el-radio-button__inner {
      //background-color: initial!important;
      border-color: #367fff !important;
      color: #fff;
      box-shadow: rgb(54, 127, 255, 0.6) 0px 0px 25px inset !important;
    }
  }
}
.time {
  color: #00d3ff;
  font-size: 16px;
  padding: 5px 0;
  display: flex;
  align-items: center;
}
.flex-content {
  margin: 0 10px;
  height: 340px;
  display: flex;
}
.flex-item {
  //   flex: 1;
  .charts-title {
    font-size: 22px !important;
  }
}
.mapContainer {
  width: calc(100% - 298px);
}
.twoChartCon {
  height: calc(100% - 40px);
}
.card-map {
  // width: 254px;
  height: 340px;
  background: url("~@/assets/images/dataCockpit/wuhanzhongxin/wuhanMap.png")
    center center no-repeat;
  margin: auto;
}
.card-jg {
  width: 364px;
  height: 54px;
  background: url("~@/assets/images/dataCockpit/jinhua2/card-jg.png");
}
.card-content {
  height: 54px;
  font-size: 20px;
  color: #fff;
  margin-left: 66px;
  line-height: 50px;
}
.span-data {
  font-size: 26px;
  color: #4992ff;
}
.charts {
  &-container {
    margin: 15px;
    display: flex;
  }
  &-section {
    border: 1px solid rgba(106, 127, 197, 0.7);
    border-radius: 4px;
    position: relative;
    background: rgba(18, 20, 64, 0.6);
  }
  &-header {
    height: 40px;
    padding: 0 15px;
    color: #00d3ff;
    font-size: 20px;
    font-weight: bold;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: rgba(6, 26, 77, 0.9);
    &-content {
      display: flex;
      align-items: center;
    }
    &-icon {
      width: 20px;
      height: 20px;
      //   margin-right: 10px;
    }
    &-tip {
      float: right;
      color: #00d3ff;
      font-size: 16px;
      line-height: 45px;
      font-weight: normal;
    }
  }
  &-noBgHeader {
    background: initial;
  }
  &-item {
    overflow: hidden;
    & + & {
      margin-top: 10px;
    }
    &-bt {
      border-top: 1px solid #4c5d94;
    }
    &-nopadding {
      padding: 0;
    }
    &-flex {
      display: flex;
      justify-content: space-between;
      align-items: center;
      &-colu {
        flex-direction: column;
      }
    }
  }
  &-content {
    overflow: hidden;
  }
  &-title {
    color: #fff;
    font-size: 16px;
    font-weight: bold;
    margin: 10px 0;
    overflow: hidden;
    &-flex {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    &-item {
      flex: 1;
    }
    &-small {
      font-size: 15px;
    }
  }
  &-tab {
    float: right;
    display: flex;
    font-size: 14px;
    color: #409eff;
    border: 1px solid #409eff;
    border-radius: 3px;
    font-weight: normal;
    &-item {
      padding: 4px 15px;
      cursor: pointer;
      &-selected {
        background: #409eff;
        color: #fff;
      }
    }
  }
  &-icons {
    width: 100%;
    padding: 20px 0;
    display: flex;
    justify-content: space-around;
    align-items: center;
    border-bottom: 1px dashed #4c5d94;
  }
  &-icon {
    height: 56px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    &-data {
      font-size: 36px;
      height: 36px;
      line-height: 36px;
    }
    &-text {
      font-size: 16px;
      color: #fff;
    }
    &-number {
      height: 36px;
      line-height: 36px;
      margin-right: 5px;
      display: inline-block;
    }
    &-content {
      margin-left: 10px;
    }
  }
  &-sideNav {
    width: 120px;
    height: 256px;
    float: left;
    margin-top: 10px;
    overflow-y: auto;
    &-item {
      width: 100%;
      padding: 0 10px;
      height: 32px;
      line-height: 32px;
      color: #00d3ff;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: pointer;
      &-selected {
        color: #fff;
        background: #4e52aa;
        border-radius: 3px;
      }
    }
  }
  &-nav {
    width: 110px;
    text-align: center;
    cursor: pointer;
    &-selected {
      color: #409eff;
      border-bottom: 3px solid #409eff;
    }
  }
  &-navbar {
    display: flex;
    height: 44px;
    line-height: 44px;
    &-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 45px;
      padding: 0 15px;
      color: #00d3ff;
      font-size: 20px;
      font-weight: bold;
      border-bottom: 1px solid #515f98;
      background: rgba(6, 26, 77, 0.9);
    }
  }
  &-thead {
    width: 100%;
    padding: 15px 15px 0;
    color: #fff;
    display: flex;
  }
  &-cards {
    display: flex;
    justify-content: space-between;
    margin: 10px;
  }
  &-card {
    // width: 111px;
    // height: 76px; // 有共建和自建的 样式
    width: 130px;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
    //background: url("~@/assets/images/dataCockpit/jinhua2/card-bg.png");
    &-jg {
      background: url("~@/assets/images/dataCockpit/wuhanyiliaoyun/jg-bg.png")
        right bottom no-repeat;
    }
    // 共建和自建的背景图
    // &-gj {
    //   background: url("~@/assets/images/dataCockpit/wuhanyiliaoyun/createTogether-bg.png")
    //     right bottom no-repeat;
    // }
    // &-zj {
    //   background: url("~@/assets/images/dataCockpit/wuhanyiliaoyun/createBySelf_bg.png")
    //     right bottom no-repeat;
    // }
    &-yh {
      background: url("~@/assets/images/dataCockpit/wuhanyiliaoyun/yh-bg.png")
        right bottom no-repeat;
    }
    &-zx {
      background: url("~@/assets/images/dataCockpit/wuhanyiliaoyun/zx-bg.png")
        right bottom no-repeat;
    }
    &-cc {
      background: url("~@/assets/images/dataCockpit/wuhanyiliaoyun/cc-bg.png")
        right bottom no-repeat;
    }
    &-title {
      font-size: 15px;
      color: #fff;
      // line-height: 26px; // 有自建和共建的样式
      line-height: 28px;
      text-align: center;
    }
    &-data {
      // font-size: 25px; // 有自建和共建的样式
      font-size: 32px;
      font-family: "Arial";
      font-weight: bold;
      color: #fff;
      text-align: center;
    }
  }
}
.coursePie {
  height: calc(100% - 40px);
}
.news-container {
  width: 298px;
  &-title {
    font-size: 26px;
    color: #fff;
    text-shadow: 0 0 8px #fff;
    margin-bottom: 10px;
  }
}
.news-item {
  width: 100%;
  height: 48px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .bussessModelName {
    padding-left: 60px;
    position: relative;
    top: -2px;
  }
  & + & {
    margin-top: 10px;
  }
  &-title {
    font-size: 16px;
    color: #fff;
  }
  &-num {
    font-size: 24px;
    color: #4992ff;
    font-family: Arial, Arial-Bold;
    padding: 0 20px;
  }
}
.imgTotal {
  background: url("~@/assets/images/dataCockpit/wuhanzhongxin/img_bg.png");
}
.ecgTotal {
  background: url("~@/assets/images/dataCockpit/wuhanzhongxin/ecg_bg.png");
}
.pisTotal {
  background: url("~@/assets/images/dataCockpit/wuhanzhongxin/pis_bg.png");
}
.usTotal {
  background: url("~@/assets/images/dataCockpit/wuhanzhongxin/us_bg.png");
}
.consultTotal {
  background: url("~@/assets/images/dataCockpit/wuhanzhongxin/consult_bg.png");
}
.noData {
  background: url("~@/assets/images/dataCockpit/common/noData.png") center
    no-repeat;
}
.border-line {
  width: 330px;
  height: 1px;
  background: url("~@/assets/images/dataCockpit/jinhua2/line.png");
  position: absolute;
  top: -1px;
  left: 0;
  right: 0;
  margin: 0 auto;
}
.border-icon {
  width: 16px;
  height: 16px;
  position: absolute;
  &-lt {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-lt.png");
    top: -1px;
    left: -1px;
  }
  &-lb {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-lb.png");
    bottom: -1px;
    left: -1px;
  }
  &-rt {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-rt.png");
    top: -1px;
    right: -1px;
  }
  &-rb {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-rb.png");
    right: -1px;
    bottom: -1px;
  }
}
.chart {
  &-flex {
    flex: 1;
    & + & {
      border-left: 1px dashed #4c5d94;
    }
  }
}
.barAndPieChart {
  display: flex;
  .diagnosisChartBar {
    // width:calc(100% - 272px);
    width: 100%;
    .chart-bar {
      padding-right: 15px;
      //    padding-bottom:15px;
      height: calc(100% - 40px);
    }
  }
  .diagnosisPieBar {
    width: 100%;
  }
  .inspectClassTitDiv {
    width: 100%;
    justify-content: center;
  }
}
.chartTit {
  height: 40px;
  line-height: 40px;
  padding: 0 15px;
  color: #fff;
  font-size: 15px;
}
.w700{
  width:700px!important;
}
.watchRoomDiv {
  height: 400px;
}
.teachDiv {
  height: calc(100% - 130px);
}
.blueNum {
  color: #4992ff;
}
.greenNum {
  color: #00db84;
}
.orangeNum {
  color: #ffd100;
}
.redNum {
  color: #e8684a;
}
@media screen and (max-width: 1300px) {
    .container-bg{
      height:960px;
      overflow: hidden;
    }
    ::v-deep .title-text {
      font-size:24px!important;
    }
    .header-content {
      padding:0 10px;
      background: url("~@/assets/images/dataCockpit/jinhua2/headerSmall_bg.png") center;
    }
    ::v-deep .navbar{
      .el-radio-button{
        .el-radio-button__inner{
          padding:0 8px!important;
        }
      }
      
    }
    .bottomChart{
      height:360px!important;
    }
    .h970{
      height:850px;
    }
    ::v-deep .time{
      .updateTimeLabel{
        margin-right:5px!important;
      }
      .el-select{
        width:80px!important;
      }
      .refresh-btn{
        margin-left:5px!important;
      }
    }
    .charts-header-content {
      span{
        font-size:14px;
      }
    }
    .charts-header{
      padding: 0 10px;
    }
    .charts-header-tip{
      line-height: inherit;
      font-size:14px;
    }
    .charts-card{
      width:100px;
    }
    .w700{
      width:570px!important;
    }
    .news-container{
      width:250px;
    }

    .charts-card-jg {
      background: url("~@/assets/images/dataCockpit/wuhanyiliaoyun/jgSmall-bg.png")
        right bottom no-repeat;
    }
    .charts-card-yh {
      background: url("~@/assets/images/dataCockpit/wuhanyiliaoyun/yhSmall-bg.png")
        right bottom no-repeat;
    }
    .charts-card-zx {
      background: url("~@/assets/images/dataCockpit/wuhanyiliaoyun/zxSmall-bg.png")
        right bottom no-repeat;
    }
    .mapContainer{
      width: calc(100% - 250px);
    }
    .imgTotal {
      background: url("~@/assets/images/dataCockpit/wuhanzhongxin/imgSmall_bg.png");
    }
    .ecgTotal {
      background: url("~@/assets/images/dataCockpit/wuhanzhongxin/ecgSmall_bg.png");
    }
    .pisTotal {
      background: url("~@/assets/images/dataCockpit/wuhanzhongxin/pisSmall_bg.png");
    }
    .usTotal {
      background: url("~@/assets/images/dataCockpit/wuhanzhongxin/usSmall_bg.png");
    }
    .consultTotal {
      background: url("~@/assets/images/dataCockpit/wuhanzhongxin/consultSmall_bg.png");
    }
}
</style>
