<template>
  <div class="container-bg">
    <div class="header-content">
      <div class="navbar">
        <div
          class="navbar-item"
          :class="{ 'navbar-item-selected': navbarIndex === item.value }"
          v-for="item in navbarList"
          :key="item.value"
          @click="selectNavbar(item)"
        >
          {{ item.name }}
        </div>
      </div>
      <page-title :title="title" :initSize="44" :initMax="12" :width="680" :letterSpace="12" @updateTitle="updateTitle"></page-title>
      <div class="time">
        <span style="margin-right: 25px;">更新日期：{{ updateTime }}</span>
        <update-data @updateData="updateData"></update-data>
      </div>
    </div>
    <div class="charts-container">
      <div class="charts-section">
        <div class="border-icon border-icon-lt"></div>
        <div class="border-icon border-icon-lb"></div>
        <div class="border-icon border-icon-rt"></div>
        <div class="border-icon border-icon-rb"></div>
        <div class="border-line"></div>
        <div class="charts-header">
          <img
            class="charts-header-icon"
            src="@/assets/images/dataCockpit/anji/platform/icon_keshi.png"
            alt=""
          />
          <span>检查科室</span>
        </div>
        <div class="charts-item pd15 mt10">
          <div class="chart-bar" style="width:100%;height:280px">
            <chart-item :option="examWorkedOption"></chart-item>
          </div>
        </div>
        <div class="charts-item charts-item-bt pd15">
          <div class="charts-title">
            检查费用
          </div>
          <div class="list fl h216">
            <div class="list-head">
              <div class="list-cell w90">检查科室</div>
              <div class="list-cell w210">检查费用(万元）</div>
            </div>
            <div
              class="list-row"
              v-for="item in examCostList"
              :key="item.dep_name"
            >
              <div class="list-cell w90">
                {{ item.dep_name }}
              </div>
              <div class="list-cell list-cell-progress w210">
                <el-progress
                  :stroke-width="10"
                  :percentage="item.cost_ratio * 100"
                  color="#FF8A45"
                  :show-text="false"
                ></el-progress>
                <span class="list-cell-span">{{ item.exam_cost }}</span>
              </div>
            </div>
          </div>
          <div class="chart-pie fr" style="width:280px;height:240px;">
            <chart-item
              :option="examCostOption"
              v-show="examCostOption"
            ></chart-item>
          </div>
        </div>
        <div class="charts-item charts-item-bt pd15 mb20">
          <div class="charts-title charts-title-flex">
            <span class="charts-title-span">
              工作质量
            </span>
            <div class="charts-tab">
              <div
                class="charts-tab-item"
                :class="{
                  'charts-tab-item-selected': qualityTabAcitveIndex === 0
                }"
                @click="changeQualityTab(0)"
              >
                危急值
              </div>
              <div
                class="charts-tab-item"
                :class="{
                  'charts-tab-item-selected': qualityTabAcitveIndex === 1
                }"
                @click="changeQualityTab(1)"
              >
                阳性率
              </div>
            </div>
          </div>
          <div class="list fl h242" v-if="qualityTabAcitveIndex === 0">
            <div class="list-head">
              <div class="list-cell w90">检查科室</div>
              <div class="list-cell w243 tc">处理情况</div>
              <div class="list-cell w127">危机数</div>
              <div class="list-cell w127">处理率</div>
            </div>
            <div
              class="list-row"
              v-for="item in crisisNumList"
              :key="item.dep_name"
            >
              <div class="list-cell w90">{{ item.dep_name }}</div>
              <div class="list-cell list-cell-flex w243">
                <div class="chart-scale" v-if="item.option">
                  <chart-item :option="item.option"></chart-item>
                </div>
              </div>
              <div class="list-cell w127">
                {{ item.crisis_num }}
              </div>
              <div class="list-cell w127">
                {{ item.process_ratio + '%' }}
              </div>
            </div>
            <div class="charts-legends">
              <div class="charts-legend">
                <div class="charts-legend-circle bg_wcl"></div>
                未处理
              </div>
              <div class="charts-legend">
                <div class="charts-legend-circle bg_ycl"></div>
                已处理
              </div>
            </div>
          </div>
          <div class="list fl h242" v-if="qualityTabAcitveIndex === 1">
            <div class="list-head">
              <div class="list-cell w90">检查科室</div>
              <div class="list-cell w243 tc">阴阳性情况</div>
              <div class="list-cell w127">检查人数</div>
              <div class="list-cell w127">阳性率</div>
            </div>
            <div
              class="list-row"
              v-for="item in positiveRatioList"
              :key="item.dep_name"
            >
              <div class="list-cell w90">{{ item.dep_name }}</div>
              <div class="list-cell list-cell-flex w243">
                <div class="chart-scale" v-if="item.option">
                  <chart-item :option="item.option"></chart-item>
                </div>
              </div>
              <div class="list-cell w127">
                {{ item.exam_num }}
              </div>
              <div class="list-cell w127">
                {{ item.positive_ratio + '%' }}
              </div>
            </div>
            <div class="charts-legends">
              <div class="charts-legend">
                <div class="charts-legend-circle bg_yinx"></div>
                阴性
              </div>
              <div class="charts-legend">
                <div class="charts-legend-circle bg_yangx"></div>
                阳性
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="section-container">
        <div class="charts-section">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>
          <div class="charts-header">
            <img
              class="charts-header-icon"
              src="@/assets/images/dataCockpit/anji/platform/icon_quyu.png"
              alt=""
            />
            <span>医共体概览</span>
          </div>
          <div class="charts-content">
            <div class="charts-icons">
              <div class="charts-icon">
                <img
                  src="@/assets/images/dataCockpit/anji/platform/icon-yljg.png"
                  alt=""
                />
                <div class="charts-icon-content">
                  <div class="charts-icon-data">
                    <span class="charts-icon-number col_yljg">{{
                      orgLevelInfo.org_sum
                    }}</span>
                    <span class="charts-icon-text">家</span>
                  </div>
                  <div class="charts-icon-text">医疗机构</div>
                </div>
              </div>

              <div class="charts-icon">
                <img
                  src="@/assets/images/dataCockpit/anji/platform/icon-yhry.png"
                  alt=""
                />
                <div class="charts-icon-content">
                  <div class="charts-icon-data">
                    <span class="charts-icon-number col_yhry">{{
                      docTypeInfo.doc_sum
                    }}</span>
                    <span class="charts-icon-text">人</span>
                  </div>
                  <div class="charts-icon-text">医护人员</div>
                </div>
              </div>
              <div class="charts-icon">
                <img
                  src="@/assets/images/dataCockpit/anji/platform/icon-jcsb.png"
                  alt=""
                />
                <div class="charts-icon-content">
                  <div class="charts-icon-data">
                    <span class="charts-icon-number col_ygt">{{
                      equipmentTypeInfo.equipment_sum
                    }}</span>
                    <span class="charts-icon-text">台</span>
                  </div>
                  <div class="charts-icon-text">检查设备</div>
                </div>
              </div>
            </div>
            <div class="charts-item charts-item-flex">
              <div class="chart-flex">
                <div class="chart-pie" style="width:100%;height:280px">
                  <chart-item :option="orgLevelOption"></chart-item>
                </div>
              </div>
              <div class="chart-flex">
                <div class="chart-pie" style="width:100%;height:280px">
                  <chart-item :option="docTypeOption"></chart-item>
                </div>
              </div>
              <div class="chart-flex">
                <div class="chart-pie" style="width:100%;height:280px">
                  <chart-item :option="equipmentTypeOption"></chart-item>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="charts-section mt15" style="height: 530px">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>
          <div class="charts-header justify-between">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/anji/platform/icon_sjgx.png"
                alt=""
              />
              <span>数据共享</span>
            </div>

            <div class="charts-tab">
              <div
                class="charts-tab-item"
                :class="{
                  'charts-tab-item-selected':
                    shareNumTabAcitveIndex === tab.value
                }"
                v-for="tab in shareNumTabs"
                :key="tab.value"
                @click="changeShareNumTab(tab.value)"
              >
                {{ tab.name }}
              </div>
            </div>
          </div>
          <div
            class="charts-content"
            v-if="shareNumTabAcitveIndex === 1"
            :key="1"
          >
            <div class="charts-item">
              <div class="charts-cards">
                <div class="charts-card">
                  <div class="charts-card-text">检查总量(人次)</div>
                  <div class="charts-card-data col_jc">
                    {{ shareNumByDepInfo.exam_sum }}
                  </div>
                </div>
                <div class="charts-card">
                  <div class="charts-card-text">检验总量(人次)</div>
                  <div class="charts-card-data col_jy">
                    {{ shareNumByDepInfo.inspection_sum }}
                  </div>
                </div>
              </div>
              <div class="chart-bar fr mt15" style="width:440px;height:255px">
                <chart-item :option="shareNumByDepOption"></chart-item>
              </div>
            </div>
            <div class="charts-item charts-item-bt charts-item-nopadding">
              <div class="scroll-list">
                <div class="scroll-list-row scroll-list-row-bg">
                  <div class="scroll-list-head col-4">医疗机构</div>
                  <div class="scroll-list-head col-3">检查量</div>
                  <div class="scroll-list-head col-3">检验量</div>
                </div>
                <div class="scroll-list-content h160">
                  <div class="scroll-list-ul" id="js-scroll-shareNumByOrg">
                    <div
                      class="scroll-list-row"
                      v-for="item in shareNumByOrgList"
                      :key="item.org_name"
                    >
                      <div class="scroll-list-cell col-4">
                        {{ item.org_name }}
                      </div>
                      <div class="scroll-list-cell col-3">
                        {{ item.exam_num }}
                      </div>
                      <div class="scroll-list-cell col-3">
                        {{ item.inspection_num }}
                      </div>
                    </div>
                  </div>
                  <div
                    class="scroll-list-ul scroll-list-ul-repeat"
                    id="js-scroll-shareNumByOrg-repeat"
                  >
                    <div
                      class="scroll-list-row"
                      v-for="item in shareNumByOrgList"
                      :key="item.org_name"
                    >
                      <div class="scroll-list-cell col-4">
                        {{ item.org_name }}
                      </div>
                      <div class="scroll-list-cell col-3">
                        {{ item.exam_num }}
                      </div>
                      <div class="scroll-list-cell col-3">
                        {{ item.inspection_num }}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            class="charts-content"
            v-if="shareNumTabAcitveIndex === 2"
            :key="2"
          >
            <div class="charts-item charts-item-flex mt10">
              <div class="chart-flex">
                <div
                  class="chart-liquid"
                  style="width:200px;height:200px;margin: 0 auto;"
                >
                  <chart-liquid-fill
                    :option="storageSumOption"
                  ></chart-liquid-fill>
                </div>
                <div class="chart-legends">
                  <div class="chart-legend">
                    <img
                      src="@/assets/images/dataCockpit/anji/platform/legend-total.png"
                      alt=""
                    />
                    总容量：{{ storageSum.storage_sum }}T
                  </div>
                  <div class="chart-legend">
                    <img
                      src="@/assets/images/dataCockpit/anji/platform/legend-data.png"
                      alt=""
                    />
                    已使用：{{ storageSum.storage_usage_sum }}T
                  </div>
                </div>
              </div>
              <div class="chart-flex">
                <div class="chart-pie" style="width:100%;height:220px">
                  <chart-item :option="storageUsageByDepOption"></chart-item>
                </div>
              </div>
            </div>
            <div class="charts-item charts-item-bt charts-item-nopadding">
              <div class="scroll-list">
                <div class="scroll-list-row scroll-list-row-bg">
                  <div class="scroll-list-head" style="width:35%">医疗机构</div>
                  <div
                    class="scroll-list-head"
                    style="width:13%"
                    v-for="item in storageUsageByOrgThead"
                    :key="item"
                  >
                    {{ item }}
                  </div>
                </div>
                <div class="scroll-list-content h192">
                  <div class="scroll-list-ul" id="js-scroll-storageUsageByOrg">
                    <div
                      class="scroll-list-row"
                      v-for="item in storageUsageByOrgList"
                      :key="item.org_name"
                    >
                      <div class="scroll-list-cell" style="width:35%">
                        {{ item.org_name }}
                      </div>
                      <div
                        class="scroll-list-cell"
                        style="width:13%"
                        v-for="head in storageUsageByOrgThead"
                        :key="head"
                      >
                        {{ item[head] }}
                      </div>
                    </div>
                  </div>
                  <div
                    class="scroll-list-ul scroll-list-ul-repeat"
                    id="js-scroll-storageUsageByOrg-repeat"
                  >
                    <div
                      class="scroll-list-row"
                      v-for="item in storageUsageByOrgList"
                      :key="item.org_name"
                    >
                      <div class="scroll-list-cell" style="width:35%">
                        {{ item.org_name }}
                      </div>
                      <div
                        class="scroll-list-cell"
                        style="width:13%"
                        v-for="head in storageUsageByOrgThead"
                        :key="head"
                      >
                        {{ item[head] }}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            class="charts-content"
            v-if="shareNumTabAcitveIndex === 3"
            :key="3"
          >
            <div class="charts-item">
              <div class="charts-cards">
                <div class="charts-card">
                  <div class="charts-card-text f14">调阅总量(人次)</div>
                  <div class="charts-card-data col_jc">
                    {{ lookByClientInfo.look_in_sum }}
                  </div>
                </div>
                <div class="charts-card">
                  <div class="charts-card-text f14">被调阅总量(人次)</div>
                  <div class="charts-card-data col_jy">
                    {{ lookByClientInfo.look_out_sum }}
                  </div>
                </div>
              </div>
              <div class="chart-bar fr mt15" style="width:440px;height:255px">
                <chart-item :option="lookByClientOption"></chart-item>
              </div>
            </div>
            <div class="charts-item charts-item-bt mt10">
              <div class="chart-bar" style="width:100%;height:180px">
                <chart-item :option="lookByUserAndDateOption"></chart-item>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="charts-section">
        <div class="border-icon border-icon-lt"></div>
        <div class="border-icon border-icon-lb"></div>
        <div class="border-icon border-icon-rt"></div>
        <div class="border-icon border-icon-rb"></div>
        <div class="border-line"></div>
        <div class="charts-header">
          <img
            class="charts-header-icon"
            src="@/assets/images/dataCockpit/anji/platform/icon_yiliao.png"
            alt=""
          />
          <span>远程医疗</span>
        </div>
        <div class="charts-item">
          <div class="charts-title">
            检查预约量
          </div>
          <div class="chart-bar" style="width:100%;height:220px"></div>
        </div>
        <div class="charts-item charts-item-bt mt10">
          <div class="chart-bar" style="width:100%;height:280px">
            <chart-item :option="longTypeOption"></chart-item>
          </div>
        </div>
        <div class="charts-item charts-item-bt charts-item-flex mt10">
          <div class="chart-flex">
            <div class="chart-pie" style="width:100%;height:320px">
              <chart-item :option="diagnoseByDepOption"></chart-item>
            </div>
          </div>
          <div class="chart-flex">
            <div class="chart-pie" style="width:100%;height:320px">
              <chart-item :option="consultationByDepOption"></chart-item>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import ChartItem from '@/components/dataCockpit/ChartItem.vue'
import ChartLiquidFill from '@/components/dataCockpit/ChartLiquidFill.vue'
import PageTitle from '@/components/dataCockpit/PageTitle.vue'
import UpdateData from '@/components/dataCockpit/UpdateData.vue'
import Mgr from '@/utils/SecurityService'
import utils from '@/utils/PIScommonMethod'
import {
  getExamWorked,
  getExamCost,
  getCrisisNum,
  getPositiveRatio,
  getOrgLevel,
  getDocType,
  getEquipmentType,
  getShareNumByDep,
  getShareNumByOrg,
  getStorageSum,
  getStorageByDep,
  getStorageByOrg,
  getLookByClient,
  getLookByUserAndDate,
  getLongType,
  getDiagnoseRatio,
  getConsultationRatio,
  getPageTitle,
  updatePageTitle
} from '@/api/dataCockpit/anji/dataCockpit'

import { getCostomerinfoByid } from '@/api/platform_operate/costomer'
export default {
  components: { ChartItem, ChartLiquidFill, PageTitle, UpdateData },
  data () {
    return {
      isDev: false,
      updateTime: '',
      title: '',
      pageName: '',
      deftaulDeptLegends: [
        {name: '放射科'},
        {name: '超声科'},
        {name: '内镜科'},
        {name: '心电科'},
        {name: '病理科'}
      ],
      navbarList: [
        { name: '今日', value: 1 },
        { name: '本月', value: 2 },
        { name: '上个月', value: 3 },
        { name: '近三月', value: 4 },
        { name: '近六月', value: 5 },
        { name: '近一年', value: 6 }
      ],
      navbarIndex: 1,
      // 检查工作量 数据源
      examWorkedList: [],
      // 检查费用 数据源
      examCostList: [],
      examCostActiveIndex: 0,
      // 工作质量tab
      qualityTabAcitveIndex: 0,
      // 工作质量--危急值 数据源
      crisisNumList: [],
      // 工作质量--阳性率 数据源
      positiveRatioList: [],
      // 危急值比例图图表option
      crisisNumScaleOption: {
        grid: {
          top: 'middle',
          left: 0,
          right: 0
        },
        xAxis: [
          {
            type: 'value',
            axisTick: {
              show: false
            },
            axisLine: {
              show: false
            },
            axisLabel: {
              show: false
            },
            splitLine: {
              show: false
            }
          }
        ],
        yAxis: [
          {
            type: 'category',
            data: [''],
            axisTick: {
              show: false
            },
            axisLine: {
              show: false
            },
            axisLabel: {
              textStyle: {
                color: '#fff'
              }
            }
          }
        ],
        series: [
          {
            name: '未处理',
            type: 'bar',
            barWidth: 16,
            stack: '1',
            itemStyle: {
              color: '#E8A61F'
            },
            data: [
              {
                value: 0,
                itemStyle: {
                  normal: {
                    color: {
                      type: 'bar',
                      colorStops: [
                        {
                          offset: 0,
                          color: '#FF8A45' // 0% 处的颜色
                        },
                        {
                          offset: 1,
                          color: '#FF8A45' // 100% 处的颜色
                        }
                      ],
                      globalCoord: false // 缺省为 false
                    }
                  }
                }
              }
            ]
          },
          {
            name: '已处理',
            type: 'bar',
            barWidth: 16,
            stack: '1',
            itemStyle: {
              color: '#409EFF'
            },
            label: {
              show: true,
              color: '#fff',
              formatter: ''
            },
            data: [
              {
                value: 0,
                itemStyle: {
                  normal: {
                    color: {
                      type: 'bar',
                      colorStops: [
                        {
                          offset: 0,
                          color: '#409EFF' // 0% 处的颜色
                        },
                        {
                          offset: 1,
                          color: '#409EFF' // 100% 处的颜色
                        }
                      ]
                    }
                  }
                }
              }
            ]
          }
        ]
      },
      // 阳性率比例图图表option
      positiveRatioScaleOption: {
        grid: {
          top: 'middle',
          left: 0,
          right: 0
        },
        xAxis: [
          {
            type: 'value',
            axisTick: {
              show: false
            },
            axisLine: {
              show: false
            },
            axisLabel: {
              show: false
            },
            splitLine: {
              show: false
            }
          }
        ],
        yAxis: [
          {
            type: 'category',
            data: [''],
            axisTick: {
              show: false
            },
            axisLine: {
              show: false
            },
            axisLabel: {
              textStyle: {
                color: '#fff'
              }
            }
          }
        ],
        series: [
          {
            name: '未处理',
            type: 'bar',
            barWidth: 16,
            stack: '1',
            itemStyle: {
              color: '#E8A61F'
            },
            data: [
              {
                value: 0,
                itemStyle: {
                  normal: {
                    color: {
                      type: 'bar',
                      colorStops: [
                        {
                          offset: 0,
                          color: '#00B448' // 0% 处的颜色
                        },
                        {
                          offset: 1,
                          color: '#00B448' // 100% 处的颜色
                        }
                      ],
                      globalCoord: false // 缺省为 false
                    }
                  }
                }
              }
            ]
          },
          {
            name: '已处理',
            type: 'bar',
            barWidth: 16,
            stack: '1',
            itemStyle: {
              color: '#409EFF'
            },
            label: {
              show: true,
              color: '#fff',
              formatter: ''
            },
            data: [
              {
                value: 0,
                itemStyle: {
                  normal: {
                    color: {
                      type: 'bar',
                      colorStops: [
                        {
                          offset: 0,
                          color: '#FF6E76' // 0% 处的颜色
                        },
                        {
                          offset: 1,
                          color: '#FF6E76' // 100% 处的颜色
                        }
                      ]
                    }
                  }
                }
              }
            ]
          }
        ]
      },
      // 医共体概览--医疗机构
      orgLevelInfo: {},
      // 医共体概览--医护人员
      docTypeInfo: {},
      // 医共体概览--医疗设备
      equipmentTypeInfo: {},
      shareNumTabs: [
        {
          name: '检查检验量',
          value: 1
        },
        {
          name: '存储量',
          value: 2
        },
        {
          name: '调阅量',
          value: 3
        }
      ],
      shareNumTabAcitveIndex: 1,
      // 检查检验量-- 科室分组
      shareNumByDepInfo: {},
      shareNumByOrgList: [],
      shareNumScrollTimer: null,
      // 存储量--总使用情况
      storageSum: {},
      // 存储量-- 当前时间维度科室占比 数据源
      storageUsageByDepList: [],
      storageUsageByOrgThead: [
        '放射科',
        '超声科',
        '心电科',
        '内镜科',
        '病理科'
      ],
      storageUsageByOrgList: [],
      storageUsageScrollTimer: null,
      lookByClientInfo: {},
      lookByUserAndDateList: [],
      // 远程医疗--远程服务量
      longTypeList: [],
      diagnoseRatioList: [],
      consultationRatioList: []
    }
  },
  computed: {
    // 检查工作量 图表 option
    examWorkedOption () {
      let option = null
      const list = this.examWorkedList
      if (list.length === 0) {
        return option
      }
      const sourceOption = []
      list.forEach(item => {
        const sourceItem = {}
        sourceItem.product = item.dep_name
        sourceItem['检查人次'] = item.exam_num
        sourceItem['项目数'] = item.item_num
        sourceItem['工作量'] = item.work_num
        sourceOption.push(sourceItem)
      })
      option = {
        title: {
          text: '检查工作量',
          textStyle: {
            color: '#fff',
            fontSize: 16
          },
          subtext: '单位：人次',
          subtextStyle: {
            color: '#fff',
            fontSize: 12,
            fontWeight: 'normal'
          }
        },
        legend: {
          right: '5%',
          itemWidth: 10,
          itemHeight: 10,
          textStyle: {
            color: '#00d3ff'
          }
        },
        tooltip: {},
        grid: {
          top: '20%',
          bottom: '10%',
          right: '5%'
        },
        dataset: {
          dimensions: ['product', '检查人次', '项目数', '工作量'],
          source: sourceOption
        },
        xAxis: {
          type: 'category',
          axisLabel: {
            color: '#00d3ff'
          },
          axisTick: {
            show: false
          }
        },
        yAxis: {
          splitLine: {
            lineStyle: {
              type: 'dashed',
              color: '#00d3ff',
              opacity: 0.3
            }
          },
          axisLabel: {
            color: '#00d3ff'
          }
        },
        series: [
          { type: 'bar', barMaxWidth: '30px' },
          { type: 'bar', barMaxWidth: '30px' },
          { type: 'bar', barMaxWidth: '30px' }
        ]
      }
      return option
    },
    // 检查费用 图表 option
    examCostOption () {
      let option = null
      const list = this.examCostList
      if (list.length === 0) {
        return option
      }
      const dataOption = []
      list.forEach(item => {
        const obj = {}
        obj.name = item.dep_name
        obj.value = item.exam_cost
        dataOption.push(obj)
      })
      option = {
        tooltip: {
          formatter: '{d}%'
        },
        legend: {
          bottom: 30,
          textStyle: {
            color: '#00d3ff'
          },
          itemWidth: 10,
          itemHeight: 10,
          itemGap: 2,
          data: this.deftaulDeptLegends
        },
        series: [
          {
            type: 'pie',
            radius: ['20%', '40%'],
            label: {
              formatter: '{d}%',
              color: '#00D3FF',
              fontSize: 14
            },
            labelLine: {
              length: 10,
              length: 5
            },
            center: ['50%', '35%'],
            data: dataOption
          }
        ]
      }
      return option
    },
    // 医共体概览--医疗机构 图表 option
    orgLevelOption () {
      let option = null
      const list = this.orgLevelInfo.list
      if (!list || list.length === 0) {
        return option
      }
      const dataOption = []
      list.forEach(item => {
        const obj = {}
        obj.name = item.org_level
        obj.value = item.org_num
        dataOption.push(obj)
      })
      option = {
        tooltip: {},
        legend: {
          top: '80%',
          textStyle: {
            color: '#00d3ff'
          },
          itemWidth: 10,
          itemHeight: 10,
          itemGap: 2
        },
        series: [
          {
            type: 'pie',
            radius: ['25%', '50%'],
            label: {
              formatter: '{c}',
              color: '#00D3FF',
              fontSize: 14
            },
            labelLine: {
              length: 10,
              length2: 5
            },
            center: ['50%', '50%'],
            data: dataOption
          }
        ]
      }
      return option
    },
    // 医共体概览--医护人员 图表 option
    docTypeOption () {
      let option = null
      const list = this.docTypeInfo.list
      if (!list || list.length === 0) {
        return option
      }
      const dataOption = []
      list.forEach(item => {
        const obj = {}
        obj.name = item.doc_type
        obj.value = item.doc_num
        dataOption.push(obj)
      })
      option = {
        tooltip: {},
        legend: {
          top: '80%',
          textStyle: {
            color: '#00d3ff'
          },
          itemWidth: 10,
          itemHeight: 10,
          itemGap: 2
        },
        series: [
          {
            type: 'pie',
            radius: ['25%', '50%'],
            label: {
              formatter: '{c}',
              color: '#00D3FF',
              fontSize: 14
            },
            labelLine: {
              length: 10,
              length2: 5
            },
            center: ['50%', '50%'],
            data: dataOption
          }
        ]
      }
      return option
    },
    // 医共体概览--医疗设备 图表 option
    equipmentTypeOption () {
      let option = null
      const list = this.equipmentTypeInfo.list
      if (!list || list.length === 0) {
        return option
      }
      const dataOption = []
      list.forEach(item => {
        const obj = {}
        obj.name = item.dep_name
        obj.value = item.equipment_num
        dataOption.push(obj)
      })
      option = {
        tooltip: {},
        legend: {
          top: '80%',
          textStyle: {
            color: '#00d3ff'
          },
          itemWidth: 10,
          itemHeight: 10,
          itemGap: 2,
          data: this.deftaulDeptLegends
        },
        series: [
          {
            type: 'pie',
            radius: ['25%', '50%'],
            label: {
              formatter: '{c}',
              color: '#00D3FF',
              fontSize: 14
            },
            labelLine: {
              length: 10,
              length2: 5
            },
            center: ['50%', '50%'],
            data: dataOption
          }
        ]
      }
      return option
    },
    // 检查检验量-- 科室分组 图表 option
    shareNumByDepOption () {
      let option = null
      const list = this.shareNumByDepInfo.list
      if (!list || list.length === 0) {
        return option
      }
      const sourceOption = []
      list.forEach(item => {
        const sourceItem = {}
        sourceItem.product = item.dep_name
        sourceItem['检查量'] = item.exam_num
        sourceItem['检验量'] = item.inspection_num
        sourceOption.push(sourceItem)
      })
      option = {
        legend: {
          itemWidth: 10,
          itemHeight: 10,
          textStyle: {
            color: '#00d3ff'
          },
          right: '5%'
        },
        tooltip: {},
        grid: {
          top: '20%',
          bottom: '10%',
          right: '5%',
          left: '15%'
        },
        dataset: {
          dimensions: ['product', '检查量', '检验量'],
          source: sourceOption
        },
        xAxis: {
          type: 'category',
          axisLabel: {
            color: '#00d3ff'
          },
          axisTick: {
            show: false
          }
        },
        yAxis: {
          splitLine: {
            lineStyle: {
              type: 'dashed',
              color: '#00d3ff',
              opacity: 0.3
            }
          },
          axisLabel: {
            color: '#00d3ff'
          }
        },
        series: [{ type: 'bar' }, { type: 'bar' }]
      }
      return option
    },
    // 数据共享 存储量使用情况水波纹option
    storageSumOption () {
      if (!this.storageSum.storage_sum) {
        return null
      }
      const data = parseFloat(
        (
          this.storageSum.storage_usage_sum / this.storageSum.storage_sum
        ).toFixed(4)
      )
      const option = {
        series: [
          {
            type: 'liquidFill',
            data: [data],
            label: {
              fontSize: 18,
              color: '#fff'
            },
            radius: '70%',
            outline: {
              show: true,
              borderDistance: 2,
              itemStyle: {
                borderColor: '#409EFF',
                borderWidth: 2
              }
            },
            backgroundStyle: {
              color: '#08194B'
            },
            itemStyle: {
              color: '#409EFF'
            }
          }
        ]
      }
      return option
    },
    // 存储量-- 当前时间维度科室占比 图表 option
    storageUsageByDepOption () {
      let option = null
      const list = this.storageUsageByDepList
      if (list.length === 0) {
        return option
      }
      const data = []
      list.forEach(item => {
        const obj = {}
        obj.name = item.dep_name
        obj.value = item.storage_ratio
        data.push(obj)
      })
      option = {
        legend: {
          bottom: 0,
          textStyle: {
            color: '#00d3ff'
          },
          itemWidth: 10,
          itemHeight: 10,
          padding: [0, 0, 0, 0],
          itemGap: 2,
          data: this.deftaulDeptLegends
        },
        tooltip: {
          formatter: '{d}%'
        },
        series: [
          {
            type: 'pie',
            radius: ['25%', '50%'],
            label: {
              formatter: '{d}%',
              color: '#00D3FF',
              fontSize: 14
            },
            center: ['50%', '50%'],
            data: data
          }
        ]
      }
      return option
    },
    // 调阅量--不同终端分组占比 图表 option
    lookByClientOption () {
      let option = null
      const list = this.lookByClientInfo.list
      if (!list || list.length === 0) {
        return option
      }
      const data = []
      list.forEach(item => {
        const obj = {}
        obj.name = item.client_kind
        obj.value = item.ratio
        data.push(obj)
      })
      option = {
        legend: {
          right: '10',
          top: 'center',
          textStyle: {
            color: '#00d3ff'
          },
          itemWidth: 10,
          itemHeight: 10,
          padding: [0, 0, 0, 0],
          itemGap: 2
        },
        tooltip: {
          formatter: '{d}%'
        },
        series: [
          {
            type: 'pie',
            radius: ['35%', '60%'],
            label: {
              formatter: '{d}%',
              color: '#00D3FF',
              fontSize: 14
            },
            center: ['40%', '50%'],
            data: data
          }
        ]
      }
      console.log(option)
      return option
    },
    // 调阅量-- 用户分组  图表 option
    lookByUserAndDateOption () {
      let option = null
      const list = this.lookByUserAndDateList
      if (list.length === 0) {
        return option
      }
      //let newList = []
      let sourceOption = []
      const xData = Array.from(new Set(list.map(x => x.date_group)))
      xData.forEach(x => {
        const obj = {}
        const data = list.filter(item => item.date_group === x)
        data.forEach(item => {
          const user_kind = item.user_kind
          if (user_kind === '医生') {
            obj['医生量'] = item.look_in_num
          } else if (user_kind === '患者') {
            obj['患者量'] = item.look_in_num
          }
        })
        obj.product = x
        obj['调阅总量'] = data.reduce((x, y) => {
          return x + y.look_in_num
        }, 0)
        sourceOption.push(obj)
      })
      option = {
        legend: {
          itemWidth: 10,
          itemHeight: 10,
          textStyle: {
            color: '#00d3ff'
          },
          right: "5%"
        },
        tooltip: {},
        grid: {
          top: '15%',
          bottom: '10%',
          right: '5%'
        },
        dataset: {
          dimensions: ['product', '医生量', '患者量', '调阅总量'],
          source: sourceOption
        },
        xAxis: {
          type: 'category',
          axisLabel: {
            color: '#00d3ff'
          },
          axisTick: {
            show: false
          }
        },
        yAxis: {
          splitLine: {
            lineStyle: {
              type: 'dashed',
              color: '#00d3ff',
              opacity: 0.3
            }
          },
          axisLabel: {
            color: '#00d3ff'
          }
        },
        series: [
          { type: 'bar', barMaxWidth: 40 },
          { type: 'bar', barMaxWidth: 40 },
          { type: 'line', barMaxWidth: 40 }
        ]
      }
      return option
    },
    // 远程服务量 图表 option
    longTypeOption () {
      let option = null
      const list = this.longTypeList
      if (list.length === 0) {
        return option
      }
      let xAxisData = []
      let yAxisData = []
      xAxisData = list.map(x => x.long_type)
      yAxisData = list.map(x => x.num)
      option = {
        title: {
          text: '远程服务量',
          textStyle: {
            color: '#fff',
            fontSize: 16
          },
          subtext: '单位：人次',
          subtextStyle: {
            color: '#fff',
            fontSize: 12,
            fontWeight: 'normal'
          },
          top: 10,
          left: 0
        },
        tooltip: {},
        grid: {
          top: '25%',
          right: '5%',
          bottom: '10%'
        },
        xAxis: {
          type: 'category',
          data: xAxisData,
          axisLabel: {
            color: '#00d3ff'
          },
          axisTick: {
            show: false
          }
        },
        yAxis: {
          splitLine: {
            lineStyle: {
              type: 'dashed',
              color: '#00d3ff',
              opacity: 0.3
            }
          },
          axisLabel: {
            color: '#00d3ff'
          },
          minInterval: 1
        },
        series: [{ type: 'bar', data: yAxisData, barMaxWidth: 40 }]
      }
      return option
    },
    // 诊断占比科室分组 图表 option
    diagnoseByDepOption () {
      let option = null
      const list = this.diagnoseRatioList
      if (list.length === 0) {
        return option
      }
      const data = []
      list.forEach(item => {
        const obj = {}
        obj.name = item.dep_name
        obj.value = item.num
        data.push(obj)
      })
      const legendData = [
        {name: '放射科诊断'},
        {name: '超声科诊断'},
        {name: '内镜科诊断'},
        {name: '心电科诊断'},
        {name: '病理科诊断'},
        {name: '专科诊断'},
        {name: 'XIS诊断'},
        {name: '多学科诊断'},
        {name: '转诊诊断'},
        {name: '紧急诊断'},
      ]
      option = {
        title: {
          text: '诊断分布图',
          textStyle: {
            color: '#fff',
            fontSize: 16
          },
          show: true,
          left: 0,
          top: 20
        },
        tooltip: {},
        legend: {
          bottom: 0,
          textStyle: {
            color: '#00d3ff'
          },
          itemWidth: 10,
          itemHeight: 10,
          itemGap: 2,
          data: legendData
        },
        series: [
          {
            type: 'pie',
            radius: ['25%', '50%'],
            label: {
              formatter: '{c}',
              color: '#00D3FF',
              fontSize: 14
            },
            center: ['50%', '50%'],
            data: data
          }
        ]
      }
      return option
    },
    // 会诊占比科室分组 图表 option
    consultationByDepOption () {
      let option = null
      const list = this.consultationRatioList
      if (list.length === 0) {
        return option
      }
      const data = []
      list.forEach(item => {
        const obj = {}
        obj.name = item.dep_name
        obj.value = item.num
        data.push(obj)
      })
      const legendData = [
        {name: '放射科会诊'},
        {name: '超声科会诊'},
        {name: '内镜科会诊'},
        {name: '心电科会诊'},
        {name: '病理科会诊'},
        {name: '专科会诊'},
        {name: 'XIS会诊'},
        {name: '多学科会诊'},
        {name: '转诊会诊'},
        {name: '紧急会诊'},
      ]
      option = {
        tooltip: {},
        title: {
          text: '会诊分布图',
          textStyle: {
            color: '#fff',
            fontSize: 16
          },
          show: true,
          left: 0,
          top: 20
        },
        legend: {
          bottom: 0,
          textStyle: {
            color: '#00d3ff'
          },
          itemWidth: 10,
          itemHeight: 10,
          itemGap: 2,
          data: legendData
        },
        series: [
          {
            type: 'pie',
            radius: ['25%', '50%'],
            label: {
              formatter: '{c}',
              color: '#00D3FF',
              fontSize: 14
            },
            center: ['50%', '50%'],
            data: data
          }
        ]
      }
      return option
    }
  },
  watch: {
    navbarIndex () {
      this.clearTimer()
      this.clearAnimate()
      this.initRequest()
    },
    qualityTabAcitveIndex (value) {
      if (value === 0) {
        this.getCrisisNum()
      } else if (value === 1) {
        this.getPositiveRatio()
      }
    },
    shareNumTabAcitveIndex (value) {
      this.clearTimer()
      this.clearAnimate()
      // switch (value) {
      //   case 1:
      //     this.getShareNumByDep()
      //     this.getShareNumByOrg()
      //     break
      //   case 2:
      //     this.getStorageSum()
      //     this.getStorageByDep()
      //     this.getStorageByOrg()
      //     break
      //   case 3:
      //     this.getLookByClient()
      //     this.getLookByUserAndDate()
      //     break
      //   default: 
      //     this.getShareNumByDep()
      //     this.getShareNumByOrg()
      //     break
      // }
    }
  },
  mounted () {
    this.pageName = this.$route.name
    this.getPageTitle()
    this.initRequest()
  },
  beforeDestroy () {
    this.clearTimer()
    this.clearAnimate()
  },
  methods: {
    // 更新数据
    updateData() {
      this.clearTimer()
      this.clearAnimate()
      this.initRequest();
    },
    // 查询页面标题
    getPageTitle() {
      const params = {
        title_flag: this.pageName
      }
      getPageTitle(params).then(res => {
        if(res.code === 0) {
          if(res.data.title_name) {
            this.title = res.data.title_name
          }else {
            this.getCostomerinfoByid()
          }
        }else {
          this.getCostomerinfoByid()
        }
      }).catch(() => {
        this.getCostomerinfoByid()
      })
    },
    // 修改页面标题
    updateTitle(title) {
      if(title !== this.title) {
        const params = {
          title_flag: this.pageName,
          title_name: title
        }
        updatePageTitle(params).then(res => {
          if(res.code === 0) {
            this.title = title
          }else {
            this.$message.error(res.msg)
          }
        })
      }
    },
    // 清除定时器
    clearTimer () {
      clearInterval(this.shareNumScrollTimer)
      this.shareNumScrollTimer = null
      clearInterval(this.storageUsageScrollTimer)
      this.storageUsageScrollTimer = null
    },
    // 清除动画队列
    clearAnimate () {
      $('#js-scroll-shareNumByOrg').stop(true, true)
      $('#js-scroll-shareNumByOrg-repeat').stop(true, true)
      $('#js-scroll-storageUsageByOrg').stop(true, true)
      $('#js-scroll-storageUsageByOrg-repeat').stop(true, true)
    },
    // 获取api请求的统一参数 客戶id和科室类型
    getBaseParams () {
      return new Promise((resolve, reject) => {
        // 客戶ID
        var manager = new Mgr()
        manager.getRole().then(item => {
          if (item) {
            this.tenancy_id = sessionStorage.getItem('curTenancyId') || item.profile.tenancy_id
            resolve()
          } else {
            reject()
          }
        })
      })
    },
    async initRequest () {
      const _date = new Date()
      this.updateTime = utils.dateFormat(_date, 1)
      await this.getBaseParams()
      this.getExamWorked()
      this.getExamCost()
      this.getPositiveRatio()
      this.getOrgLevel()
      this.getDocType()
      this.getEquipmentType()
      this.getLongType()
      this.getDiagnoseRatio()
      this.getConsultationRatio()
      if (this.qualityTabAcitveIndex === 0) {
        this.getCrisisNum()
      } else if (this.qualityTabAcitveIndex === 1) {
        this.getPositiveRatio()
      }
      switch (this.shareNumTabAcitveIndex) {
        // default:
        case 1:
          this.getShareNumByDep()
          this.getShareNumByOrg()
          break
        case 2:
          this.getStorageSum()
          this.getStorageByDep()
          this.getStorageByOrg()
          break
        case 3:
          this.getLookByClient()
          this.getLookByUserAndDate()
          break
      }
    },
    // 获取客戶名称
    getCostomerinfoByid(){
      getCostomerinfoByid().then(res => {
        if(res.code === 0) {
          this.title = res.data.tenancy_info.name + '数据驾驶舱'
        }
      })
    },
    // 检查工作量
    getExamWorked () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getExamWorked(data).then(res => {
        if (res.code === 0) {
          this.examWorkedList = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 检查费用
    getExamCost () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getExamCost(data).then(res => {
        if (res.code === 0) {
          this.examCostList = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 工作质量--危急值
    getCrisisNum () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getCrisisNum(data).then(res => {
        if (res.code === 0) {
          this.crisisNumList = res.data
          this.crisisNumList.forEach(item => {
            const obj = JSON.parse(JSON.stringify(this.crisisNumScaleOption))
            obj.series[1].data[0].value = item.process_ratio
            obj.series[1].label.formatter =
              item.process_num === 0 ? '' : String(item.process_num)
            obj.series[0].data[0].value = item.crisis_num
              ? 100 - item.process_ratio
              : 0
            this.$set(item, 'option', obj)
          })
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 工作质量--阳性率
    getPositiveRatio () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getPositiveRatio(data).then(res => {
        if (res.code === 0) {
          this.positiveRatioList = res.data
          this.positiveRatioList.forEach(item => {
            const obj = JSON.parse(
              JSON.stringify(this.positiveRatioScaleOption)
            )
            obj.series[1].data[0].value = item.positive_ratio
            obj.series[1].label.formatter =
              item.positive_num === 0 ? '' : String(item.positive_num)
            obj.series[0].data[0].value = item.exam_num
              ? 100 - item.positive_ratio
              : 0
            this.$set(item, 'option', obj)
          })
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 医共体概览--医疗机构
    getOrgLevel () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getOrgLevel(data).then(res => {
        if (res.code === 0) {
          this.orgLevelInfo = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 医共体概览--医护人员
    getDocType () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getDocType(data).then(res => {
        if (res.code === 0) {
          this.docTypeInfo = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 医共体概览--医疗设备
    getEquipmentType () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getEquipmentType(data).then(res => {
        if (res.code === 0) {
          this.equipmentTypeInfo = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 检查检验量-- 科室分组
    getShareNumByDep () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getShareNumByDep(data).then(res => {
        if (res.code === 0) {
          this.shareNumByDepInfo = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 检查检验量-- 医疗机构分组
    getShareNumByOrg () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getShareNumByOrg(data).then(res => {
        if (res.code === 0) {
          this.shareNumByOrgList = res.data
          this.$nextTick(() => {
            this.scrollList(
              'js-scroll-shareNumByOrg',
              this.shareNumByOrgList,
              'shareNumScrollTimer'
            )
          })
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 存储量--总使用情况
    getStorageSum () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getStorageSum(data).then(res => {
        if (res.code === 0) {
          this.storageSum = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 存储量-- 当前时间维度科室占比
    getStorageByDep () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getStorageByDep(data).then(res => {
        if (res.code === 0) {
          this.storageUsageByDepList = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 存储量-- 当前时间维度机构分组
    getStorageByOrg () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getStorageByOrg(data).then(res => {
        if (res.code === 0) {
          const list = res.data
          let newList = []
          const orgs = Array.from(new Set(list.map(x => x.org_name)))
          orgs.forEach(org => {
            const obj = {}
            obj.org_name = org
            const data = list.filter(item => item.org_name === org)
            data.forEach(item => {
              obj[item.dep_name] = item.usage_total
            })
            newList.push(obj)
          })
          this.storageUsageByOrgList = newList
          this.$nextTick(() => {
            this.scrollList(
              'js-scroll-storageUsageByOrg',
              this.storageUsageByOrgList,
              'storageUsageScrollTimer'
            )
          })
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 调阅量--不同终端分组占比
    getLookByClient () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getLookByClient(data).then(res => {
        if (res.code === 0) {
          this.lookByClientInfo = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 调阅量--用户分组
    getLookByUserAndDate () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getLookByUserAndDate(data).then(res => {
        if (res.code === 0) {
          this.lookByUserAndDateList = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 远程医疗--远程服务量
    getLongType () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getLongType(data).then(res => {
        if (res.code === 0) {
          this.longTypeList = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 远程医疗--诊断占比科室分组
    getDiagnoseRatio () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getDiagnoseRatio(data).then(res => {
        if (res.code === 0) {
          this.diagnoseRatioList = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    // 远程医疗--会诊占比科室分组
    getConsultationRatio () {
      const data = {
        date_type: this.isDev ? 5 : this.navbarIndex,
        // tenancy_id: this.tenancy_id,
        tenancy_id: this.isDev ? '1371415955011276800' : this.tenancy_id
      }
      getConsultationRatio(data).then(res => {
        if (res.code === 0) {
          this.consultationRatioList = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    selectNavbar (item) {
      const { value } = item
      if (this.navbarIndex !== value) {
        this.navbarIndex = value
      }
    },
    selectExamCost (index) {
      if (index !== this.examCostActiveIndex) {
        this.examCostActiveIndex = index
      }
    },
    changeQualityTab (index) {
      if (index !== this.qualityTabAcitveIndex) {
        this.qualityTabAcitveIndex = index
      }
    },
    changeShareNumTab (index) {
      if (index !== this.shareNumTabAcitveIndex) {
        this.shareNumTabAcitveIndex = index
      }
    },
    scrollList (scrollListDomId, scrollList, timerName) {
      const that = this
      scrollListDomId = '#' + scrollListDomId
      const ulHeight = $(scrollListDomId).height()
      const length = scrollList.length
      // 滚动区域可视视图高度
      const minScrollHeight = $(scrollListDomId)
        .parent()
        .height()
      // 列表高度 < = 可视视图高度时，无需滚动展示
      if (ulHeight <= minScrollHeight) {
        return
      }
      // 列表中每一项移动时间
      const itemTime = 1000
      // 列表滚动动画一个循环所需时间
      const animateTime = itemTime * length
      $(`${scrollListDomId}-repeat`).css({
        top: ulHeight + 'px',
        display: 'block'
      })
      mySetInterval()

      function callbackFn () {
        $(scrollListDomId).animate(
          { top: ulHeight * -1 },
          animateTime,
          'linear',
          () => {
            $(scrollListDomId).css({ top: 0 + 'px' })
          }
        )
        $(`${scrollListDomId}-repeat`).animate(
          { top: 0 },
          animateTime,
          'linear',
          () => {
            $(`${scrollListDomId}-repeat`).css({ top: ulHeight + 'px' })
          }
        )
      }
      function mySetInterval () {
        callbackFn()
        that[timerName] = setInterval(callbackFn, animateTime)
      }
    }
  }
}
</script>
<style lang="less" scoped>
.f14 {
  font-size: 14px !important;
}
.w135 {
  width: 135px;
}
.w75 {
  width: 75px;
}
.w90 {
  width: 90px;
}
.w210 {
  width: 210px;
}
.w243 {
  width: 243px;
}
.w127 {
  width: 127px;
}
.w218 {
  width: 218px;
}

.w430 {
  width: 430px;
}
.w300 {
  width: 300px !important;
}
.h160 {
  height: 160px;
}
.h192 {
  height: 192px;
}
.h216 {
  height: 216px;
}
.h242 {
  height: 242px;
}
.h256 {
  height: 256px;
}

.mt0 {
  margin-top: 0 !important;
}
.pd15 {
  padding: 15px;
}
.col_yljg {
  color: #409eff;
}
.col_ygt {
  color: #ff8a45;
}
.col_yhry {
  color: #00b448;
}
.col_jc {
  color: #409eff;
}
.col_jy {
  color: #f6bd16;
}
.bg_yczd {
  background: #4992ff;
}
.bg_ychz {
  background: #05c091;
}
.bg_wcl {
  background: #ff8a45;
}
.bg_ycl {
  background: #409eff;
}
.bg_yinx {
  background: #00b448;
}
.bg_yangx {
  background: #ff6e76;
}
.position-rel {
  position: relative;
}
.col-6 {
  width: 60%;
}
.col-4 {
  width: 40%;
}
.col-3 {
  width: 30%;
}
.justify-between {
  justify-content: space-between;
}
.container-bg {
  width: 1920px;
  height: 1080px;
  background: url('~@/assets/images/dataCockpit/anji/platform/bg.png');
  font-family: 'Helvetica Neue', Helvetica, 'PingFang SC', Tahoma, Arial,
    sans-serif;
}
.section-container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.header-content {
  width: 100%;
  height: 76px;
  position: relative;
  padding: 0 20px;
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  background: url('~@/assets/images/dataCockpit/anji/platform/header_bg.png');
  ::v-deep .title {
    width: 680px;
    font-size: 44px;
    line-height: 76px;
    color: #00d3ff;
    font-weight: 700;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    text-align: center;
    letter-spacing: 12px;
    cursor: pointer;
  }
}
.navbar {
  height: 34px;
  display: flex;
  align-items: center;
  &-item {
    width: 72px;
    height: 34px;
    font-size: 16px;
    color: #00d3ff;
    line-height: 34px;
    text-align: center;
    cursor: pointer;
    background: url('~@/assets/images/dataCockpit/anji/platform/nav_bg.png');
    & + & {
      margin-left: 5px;
    }
    &-selected {
      background: url('~@/assets/images/dataCockpit/anji/platform/nav_selected.png') !important;
    }
    &:hover {
      background: url('~@/assets/images/dataCockpit/anji/platform/nav_hover.png');
    }
  }
}
.time {
  color: #00d3ff;
  font-size: 16px;
  padding: 5px 0;
  display: flex;
  align-items: center;
}
.charts {
  &-container {
    margin: 20px;
    display: flex;
    justify-content: space-between;
  }
  &-section {
    width: 620px;
    border: 1px solid rgba(106, 127, 197, 0.7);
    border-radius: 4px;
    position: relative;
    background: rgba(18, 20, 64, 0.6);
  }
  &-header {
    height: 45px;
    padding: 0 15px;
    color: #00d3ff;
    font-size: 20px;
    font-weight: bold;
    display: flex;
    align-items: center;
    background: rgba(6, 26, 77, 0.9);
    &-content {
      display: flex;
      align-items: center;
    }
    &-icon {
      width: 20px;
      height: 20px;
      margin-right: 10px;
    }
  }
  &-item {
    overflow: hidden;
    padding: 0 15px;
    & + & {
      margin-top: 10px;
    }
    &-bt {
      border-top: 1px dashed #4c5d94;
    }
    &-nopadding {
      padding: 0;
    }
    &-flex {
      display: flex;
      justify-content: space-between;
      align-items: center;
      &-colu {
        flex-direction: column;
      }
    }
  }
  &-content {
    overflow: hidden;
  }
  &-title {
    color: #fff;
    font-size: 16px;
    font-weight: bold;
    margin: 10px 0;
    overflow: hidden;
    &-flex {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    &-item {
      flex: 1;
    }
  }
  &-tab {
    float: right;
    display: flex;
    font-size: 14px;
    color: #409eff;
    border: 1px solid #409eff;
    border-radius: 3px;
    font-weight: normal;
    &-item {
      padding: 4px 15px;
      cursor: pointer;
      &-selected {
        background: #409eff;
        color: #fff;
      }
    }
  }
  &-icons {
    width: 100%;
    padding: 0 15px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    border-bottom: 1px dashed #4c5d94;
  }
  &-icon {
    flex: 1;
    height: 100%;
    padding: 20px 0;
    display: flex;
    align-items: center;
    justify-content: center;
    & + & {
      border-left: 1px dashed #4c5d94;
    }
    &-data {
      font-size: 36px;
      height: 36px;
      line-height: 36px;
    }
    &-text {
      font-size: 16px;
      color: #fff;
    }
    &-number {
      height: 36px;
      line-height: 36px;
      margin-right: 5px;
      display: inline-block;
      font-family: 'arial';
      font-weight: 600;
    }
    &-content {
      margin-left: 10px;
    }
  }
  &-sideNav {
    width: 120px;
    height: 256px;
    float: left;
    margin-top: 10px;
    overflow-y: auto;
    &-item {
      width: 100%;
      padding: 0 10px;
      height: 32px;
      line-height: 32px;
      color: #00d3ff;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: pointer;
      &-selected {
        color: #fff;
        background: #4e52aa;
        border-radius: 3px;
      }
    }
  }
  &-nav {
    width: 110px;
    text-align: center;
    cursor: pointer;
    &-selected {
      color: #409eff;
      border-bottom: 3px solid #409eff;
    }
  }
  &-navbar {
    display: flex;
    height: 44px;
    line-height: 44px;
    &-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 45px;
      padding: 0 15px;
      color: #00d3ff;
      font-size: 20px;
      font-weight: bold;
      border-bottom: 1px solid #515f98;
      background: rgba(6, 26, 77, 0.9);
    }
  }
  &-cards {
    display: flex;
    flex-direction: column;
    margin-top: 15px;
    float: left;
  }
  &-card {
    width: 140px;
    height: 120px;
    padding: 20px 15px;
    background: url('~@/assets/images/dataCockpit/anji/platform/bg-card.png');
    & + & {
      margin-top: 15px;
    }
    &-text {
      color: #fff;
      font-size: 15px;
    }
    &-data {
      font-size: 30px;
      font-weight: bold;
      margin-top: 15px;
      font-family: Arial;
    }
  }
  &-legends {
    display: flex;
    align-items: center;
    width: 130px;
    margin-left: 120px;
    margin-top: 10px;
    &-position {
      position: absolute;
      left: 170px;
      bottom: -25px;
    }
  }
  &-legend {
    font-size: 12px;
    color: #00d3ff;
    & + & {
      margin-left: 20px;
    }
    &-square {
      width: 10px;
      height: 10px;
      display: inline-block;
      border-radius: 2px;
    }
    &-circle {
      width: 10px;
      height: 10px;
      display: inline-block;
      border-radius: 50%;
    }
  }
}
.border-line {
  width: 330px;
  height: 1px;
  background: url('~@/assets/images/dataCockpit/anji/platform/line.png');
  position: absolute;
  top: -1px;
  left: 0;
  right: 0;
  margin: 0 auto;
}
.border-icon {
  width: 16px;
  height: 16px;
  position: absolute;
  &-lt {
    background: url('~@/assets/images/dataCockpit/anji/platform/border-lt.png');
    top: -1px;
    left: -1px;
  }
  &-lb {
    background: url('~@/assets/images/dataCockpit/anji/platform/border-lb.png');
    bottom: -1px;
    left: -1px;
  }
  &-rt {
    background: url('~@/assets/images/dataCockpit/anji/platform/border-rt.png');
    top: -1px;
    right: -1px;
  }
  &-rb {
    background: url('~@/assets/images/dataCockpit/anji/platform/border-rb.png');
    right: -1px;
    bottom: -1px;
  }
}
.list {
  color: #00d3ff;
  &-normal {
    height: 224px;
  }
  &-head {
    height: 36px;
    line-height: 36px;
    background: rgba(78, 82, 175, 0.15);
    display: flex;
    font-size: 14px;
    font-weight: bold;
  }
  &-cell {
    padding-left: 10px;
    & + & {
      border-left: 1px solid #0f1235;
    }
    &-name {
      width: 160px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    &-progress {
      width: 213px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    &-span {
      margin-right: 10px;
    }
    &-bl {
      border-left: 1px solid #0f1235;
    }
    &-flex {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-left: 0;
    }
  }
  &-row {
    height: 36px;
    line-height: 36px;
    display: flex;
    border-bottom: 1px solid rgba(78, 82, 170, 0.3);
    &-selected {
      color: #fff;
      border-color: #4e52aa;
      background: #4e52aa !important;
      ::v-deep .el-progress__text {
        color: #fff !important;
      }
    }
    &:hover {
      background: rgba(78, 82, 170, 0.3);
    }
  }
}
.chart {
  &-scale {
    width: 180px;
    height: 20px;
    margin: auto;
  }
  &-bar {
    &-small {
      float: left;
      width: 150px;
      height: 256px;
      margin-top: 10px;
      & + & {
        margin-left: 5px;
      }
    }
  }
  &-flex {
    flex: 1;
    & + & {
      border-left: 1px dashed #4c5d94;
    }
  }
  &-legends {
    width: 100%;
    display: flex;
    color: #00d3ff;
    justify-content: space-around;
  }
  &-bt {
    border-top: 1px dashed #4c5d94;
  }
}
.scroll-list {
  &-row {
    height: 32px;
    display: flex;
    color: #00d3ff;
    &-bg {
      background: rgba(78, 82, 175, 0.15);
    }
  }
  &-head {
    height: 32px;
    line-height: 32px;
    font-weight: bold;
    font-size: 14px;
    padding-left: 15px;
    & + & {
      border-left: 1px solid #0f1235;
    }
  }
  &-content {
    overflow: hidden;
    position: relative;
    font-size: 14px;
  }
  &-ul {
    width: 100%;
    position: absolute;
    &-repeat {
      display: none;
    }
  }
  &-cell {
    height: 32px;
    line-height: 32px;
    padding-left: 15px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    & + & {
      border-left: 1px solid #0f1235;
    }
  }
}
::v-deep .el-progress-bar {
  margin-right: -45px;
}
::v-deep .el-progress-bar__outer {
  width: 110px;
  background: none;
}
::v-deep .el-progress__text {
  color: #00d3ff;
  margin-left: 0;
}
</style>
