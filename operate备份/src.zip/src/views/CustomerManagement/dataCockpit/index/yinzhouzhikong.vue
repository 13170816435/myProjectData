<template>
  <div class="visualizing-container">
    <div class="visualizing-header">
      <div class="header-bg"></div>
      <div class="title">
        <!-- <input class="title-input" type="text" v-model="screenTitle" @blur="changeTitle" /> -->
        <input class="title-input" type="text" v-model="screenTitle" disabled/>
        <i class="iconfont tabSetIcon" @click="showTabSetAlert">&#xe624;</i>
      </div>
      <div class="update-date-wrapper">
        <!-- <p class="update-date">
          更新时间：{{ updateDate }}
          <i class="el-icon-refresh"></i>
        </p> -->

        <div class="m-tab">
          <div class="m-tab-item" :class="tabIndex === index ? 'm-tab-item-active' : ''" v-for="(item, index) in tabList" :key="index" @click="toggleTab(index,item.value)">{{item.label}}</div>
          <div class="tab-line" :style="{left: number + 'px'}"></div>
        </div>

      </div>
      <div class="btn-group">
        <div
          class="btn"
          v-for="item in btnList"
          :key="item.value"
          :class="[activeBtnValue == item.value ? 'btn-active' : '']"
          @click="onPacsChange(item.value)"
        >
          <p>{{ item.label }}</p>
          <img
            v-if="activeBtnValue == item.value"
            class="btn-active-img"
            src="@/assets/images/visualizing/icon_active.png"
            alt=""
          />
        </div>
      </div>
    </div>
    <div class="visualizing-main"
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-custom-class="cockpitLoading"
      element-loading-background="rgba(0, 0, 0, 0.8)">
      <div class="card-list">
        <!--基础数据-->
        <div class="commonCard">
        <div
          class="card-item card-one basicData"
        >
          <div class="icon-border left-top"></div>
          <div class="icon-border left-bottom"></div>
          <div class="icon-border right-top"></div>
          <div class="icon-border right-bottom"></div>
          <div class="header-wrapper">
            <i :class="`iconfont ${cardList[0].icon}`"  alt="" />
            <p class="title">{{ cardList[0].title }}</p>
          </div>
          <div class="content">
            <div class="left">
              <p class="title">{{ cardList[0].leftTitle }}</p>
              <p class="value">{{ cardList[0].leftValue }}</p>
            </div>
            <div class="center">
              <p class="title">{{ cardList[0].centerTitle }}</p>
              <p class="value">{{ cardList[0].centerValue }}</p>
            </div>
            <div class="right">
              <p class="title">{{ cardList[0].rightTitle }}</p>
              <p class="value">{{ cardList[0].rightValue }}</p>
            </div>
          </div>
        </div>
        </div>   
        <!--工作进展-->
        <div
          class="card-item workProgressCard critical"
        >
          <div class="icon-border left-top"></div>
          <div class="icon-border left-bottom"></div>
          <div class="icon-border right-top"></div>
          <div class="icon-border right-bottom"></div>
          <div class="header-wrapper">
            <i :class="`iconfont ${workPregressObj.icon}`"  alt="" />
            <p class="title">{{ workPregressObj.title }}</p>
          </div>
          <div class="content">
            <div class="left">
              <p class="title">{{ workPregressObj.leftTitle }}</p>
              <p class="value">{{ workPregressObj.leftValue }}</p>
            </div>
            <div class="right">
              <p class="title">{{ workPregressObj.rightTitle }}</p>
              <p class="value">{{ workPregressObj.rightValue }}</p>
            </div>
          </div>
        </div>
       <!--检查费用-->
        <div
          class="card-item critical workProgressCard"
        >
          <div class="icon-border left-top"></div>
          <div class="icon-border left-bottom"></div>
          <div class="icon-border right-top"></div>
          <div class="icon-border right-bottom"></div>
          <div class="header-wrapper">
            <i :class="`iconfont ${inspectFeeObj.icon}`"  alt="" />
            <p class="title">{{ inspectFeeObj.title }}</p>
          </div>
          <div class="content">
            <div class="left">
              <p class="title">{{ inspectFeeObj.leftTitle }}</p>
              <p class="value">{{ inspectFeeObj.leftValue }}</p>
            </div>
            <div class="right">
              <p class="title">{{ inspectFeeObj.rightTitle }}</p>
              <p class="value">{{ inspectFeeObj.rightValue }}</p>
            </div>
          </div>
        </div>
        <!--远程协同-->
        <div class="commonCard remoteCard">
        <div
          class="card-item card-one remote"
        >
          <div class="icon-border left-top"></div>
          <div class="icon-border left-bottom"></div>
          <div class="icon-border right-top"></div>
          <div class="icon-border right-bottom"></div>
          <div class="header-wrapper">
            <i :class="`iconfont ${cardList[1].icon}`"  alt="" />
            <p class="title">{{ cardList[1].title }}</p>
          </div>
          <div class="content">
            <div class="left">
              <p class="title">{{ cardList[1].leftTitle }}</p>
              <p class="value">{{ cardList[1].leftValue }}</p>
            </div>
            <div class="center">
              <p class="title">{{ cardList[1].centerTitle }}</p>
              <p class="value">{{ cardList[1].centerValue }}</p>
            </div>
            <div class="right">
              <p class="title">{{ cardList[1].rightTitle }}</p>
              <p class="value">{{ cardList[1].rightValue }}</p>
            </div>
          </div>
        </div>
        </div> 
      
        <!--危急值-->
         <div
          class="card-item critical"
        >
          <div class="icon-border left-top"></div>
          <div class="icon-border left-bottom"></div>
          <div class="icon-border right-top"></div>
          <div class="icon-border right-bottom"></div>
          <div class="header-wrapper">
            <i :class="`iconfont ${crisisObj.icon}`"  alt="" />
            <p class="title">{{ crisisObj.title }}</p>
          </div>
          <div class="content">
            <div class="left">
              <p class="title">{{ crisisObj.leftTitle }}</p>
              <p class="value">{{ crisisObj.leftValue }}</p>
            </div>
            <div class="right">
              <p class="title">{{ crisisObj.rightTitle }}</p>
              <p class="value">{{ crisisObj.rightValue }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="chart-main" v-if="activeBtnValue != 'ECG' ">
        <div class="data-left">
          <div class="flex-warp-item positive-rate-department">
            <!--预约人次和检查人次/多柱状图-->
             <imageExcellenceRateExamineTypeChart
              ref="inspectOrderTimeRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'inspectOrder'"
              v-if="activeBtnValue == 'RIS'"
            />
            <!--检查人次/单柱状图--> 
            <singleBarChart
              ref="inspectOrderTimeRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'inspectPeople'"
              v-if="activeBtnValue == 'UIS' || activeBtnValue == 'EIS'"
            />
          </div>
          <div class="flex-warp-item positive-rate-examine-type">
             <!--检查报告/多柱状图-->
             <imageExcellenceRateExamineTypeChart
              ref="inspectReportTimeRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'inspectReport'"
               v-if="activeBtnValue == 'RIS'"
            />
      
            <!--影像优良率/多折线图-->
             <!-- <reportExcellentRateRankingChart
              ref="inspectReportTimeRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :bussinessType="'imageRate'"
               v-if="activeBtnValue == 'UIS' || activeBtnValue == 'EIS'"
            /> -->
            <!--影像优良率/单柱状图-->
            <singleBarChart
              ref="inspectReportTimeRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'imageRate'"
              @clickChartFunc="clickChartFunc"
              v-if="activeBtnValue == 'UIS' || activeBtnValue == 'EIS'"
            />
          </div>
        </div>
        <div class="data-center">
          <div class="flex-warp-item machine-room">
            <!--危急值通报人次/多柱状图-->
            <imageExcellenceRateExamineTypeChart
              ref="criticaValueRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'criticaValue'"
              v-if="activeBtnValue == 'RIS'"
            />
            <!--报告优良率--->
            <reportExcellentRateExamineTypeChart
              ref="criticaValueRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'reportYLRate'"
              v-if="activeBtnValue == 'UIS' || activeBtnValue == 'EIS'"
            />
          </div>
          <div class="flex-warp-item image-excellence-rate-examine-type">
            <!--报告阳性率/多折线图-->
            <!-- <reportExcellentRateRankingChart
              ref="reportRateRankingChartRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :bussinessType="'reportYXRate'"
              v-if="activeBtnValue == 'RIS'"
            /> -->

             <!--报告阳性率/单柱状图-->
            <reportExcellentRateExamineTypeChart
              ref="reportRateRankingChartRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'reportYXRate'"
              v-if="activeBtnValue == 'RIS' || activeBtnValue == 'UIS' || activeBtnValue == 'EIS'"
            />
            
          </div>
        </div>
        <div class="data-right">
          <div class="flex-warp-item report-excellent-rate-ranking">
             <!--影像优良率/多折线图-->
             <!-- <reportExcellentRateRankingChart
              ref="imageRateRankingChartRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :bussinessType="'imageRate'"
               v-if="activeBtnValue == 'RIS'"
            /> -->

            <!--影像优良率/单柱状图--> 
            <singleBarChart
              ref="imageRateRankingChartRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'imageRate'"
              @clickChartFunc="clickChartFunc"
               v-if="activeBtnValue == 'RIS'"
            />

            <!--检查等待平均耗时/多柱状图-->
            <imageExcellenceRateExamineTypeChart
              ref="imageRateRankingChartRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'inspectWait'"
               v-if="activeBtnValue == 'UIS' || activeBtnValue == 'EIS'"
            />
          </div>
         
          <div class="flex-warp-item report-excellent-rate-examine-type">
            <!--报告优良率 单柱状图组件-->
            <reportExcellentRateExamineTypeChart
              ref="reportExcellentRateExamineTypeChartRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'reportYLRate'"
              v-if="activeBtnValue == 'RIS'"
            />
            <!--检查报告/单柱状图-->
             <singleBarChart
              ref="reportExcellentRateExamineTypeChartRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'inspectReport'"
              :itemClassArr="itemClassArr"
              v-if="activeBtnValue == 'UIS' || activeBtnValue == 'EIS'"
            />
          </div>
        </div>
      </div>


      <!--心电特殊排版-->
      <div class="chart-main ecgChartMain" v-if="activeBtnValue =='ECG' ">
        <div class="data-left">
          <div class="flex-warp-item positive-rate-department">
              <ecgInspectFeeAndInspectPeopleChart
                  ref="inspectPeopleRef"
                  :params="params"
                  :activeBtnValue="activeBtnValue"
                  :inspectType="'inspectPeople'"
              />
          </div>
          <div class="flex-warp-item positive-rate-examine-type">
              <ecgInspectFeeAndInspectPeopleChart
                  ref="inspectFeeRef"
                  :params="params"
                  :activeBtnValue="activeBtnValue"
                  :inspectType="'inspectFee'"
              />
          </div>
        </div>
        <div class="data-right">
          <div class="flex-warp-item report-excellent-rate-ranking">
            <!--检查等待平均耗时/多柱状图-->
            <ecgInSpectChart
              ref="inspectWaitRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'inspectWait'"
              v-if="activeBtnValue == 'ECG'"
            />
          </div>
         
          <div class="flex-warp-item report-excellent-rate-examine-type">
            <!--检查报告/多柱状图-->
             <ecgInSpectChart
              ref="inspectReportRef"
              :params="params"
              :activeBtnValue="activeBtnValue"
              :inspectType="'inspectReport'"
              v-if="activeBtnValue == 'ECG'"
            />
          </div>
        </div>
      </div>

    </div>

    <!-- 详情 -->
    <el-drawer
      size="410"
      :modal="false"
      :visible.sync="drawer"
      :show-close="false"
      :withHeader="false"
      :direction="direction"
      :before-close="handleClose"
    >
      <tabSetAlert
        ref="tabSetAlert"
        @closeFn="closeFn"
        @sureSaveTabSet="sureSaveTabSet"
      ></tabSetAlert>
    </el-drawer>
  </div>
</template>

<script>
import imageExcellenceRateExamineTypeChart from '../yinzhouComponents/imageExcellenceRateExamineTypeChart.vue'
import reportExcellentRateExamineTypeChart from '../yinzhouComponents/reportExcellentRateExamineTypeChart.vue'
import reportExcellentRateRankingChart from '../yinzhouComponents/reportExcellentRateRankingChart.vue'
import ecgInspectFeeAndInspectPeopleChart from '../yinzhouComponents/ecgInspectFeeAndInspectPeopleChart'
import singleBarChart from '../yinzhouComponents/singleBarChart'
import ecgInSpectChart from '../yinzhouComponents/ecgInSpectChart'
import tabSetAlert from '../yinzhouComponents/tabSetAlert'
import moment from 'moment'
import Mgr from '@/utils/SecurityService'
import { dynamicInvoke, getCurScreenTit, addScreenTit, updateCurScreenTit } from '@/api/dataapi'
export default {
  components: {
    imageExcellenceRateExamineTypeChart,
    reportExcellentRateExamineTypeChart,
    reportExcellentRateRankingChart,
    ecgInspectFeeAndInspectPeopleChart,
    singleBarChart,
    ecgInSpectChart,
    tabSetAlert,
  },
  // directives: {
  //   focus: {
  //     inserted(el) {
  //       const input = el.childNodes[1]
  //       input.focus()
  //     }
  //   }
  // },
  data() {
    return {
      drawer: false,
      direction: "rtl",
      loading: false,
      updateDate: '',
      dataDicDefineId: null,
      hasScreenTitle: false,
      screenTitle: '质控中心运维管理大屏',
      timer: null,
      activeBtnValue: 'RIS',
      btnList: [
        {
          label: '放射',
          value: 'RIS'
        },
        {
          label: '超声',
          value: 'UIS'
        },
        {
          label: '内镜',
          value: 'EIS'
        },
        {
          label: '心电',
          value: 'ECG'
        },
        {
          label: '病理',
          value: 'PIS'
        }
      ],
      cardList: [
        {
          title: '基础数据',
          cardClass: 'basicData',
          icon: 'iconyewuqushi',
          // icon: require('@/assets/images/visualizing/icon_progress.svg'),
          leftTitle: '机构数量',
          centerTitle: '设备数量',
          rightTitle: '从业人员',
          leftValue: '',
          centerValue: '',
          rightValue: '',
        },
        {
          title: '远程协同',
          cardClass: 'remote',
          icon: 'iconyuanchenghuizhen',
          //icon: require('@/assets/images/visualizing/icon_efficiency.svg'),
          leftTitle: '远程诊断(人次)',
          centerTitle: '远程会诊(人次)',
          rightTitle: '跨机构检查预约(人次)',
          leftValue: '',
          centerValue: '',
          rightValue: ''
        },
      ],
      workPregressObj: {
        title: '工作进展',
        cardClass: 'inspectCase',
        icon: 'iconyewujindu',
        leftTitle: '预约(人次)',
        rightTitle: '检查(人次)',
        leftValue: '',
        rightValue: ''
      },
      inspectFeeObj: {
        title: '检查费用',
        cardClass: 'inspectCase',
        icon: 'iconyingxiangzhenduan',
        leftTitle: '检查费用(元)',
        rightTitle: '绿色通道(人次)',
        leftValue: '',
        rightValue: ''
      },
      crisisObj: {
        title: '危急值',
        cardClass: 'critical',
        icon: 'icontishi',
        //icon: require('@/assets/images/visualizing/icon_critical.svg'),
        leftTitle: '危急值通报(人次)',
        rightTitle: '危急值处理(人次)',
        leftValue: '',
        rightValue: ''
      },
      params: {},
      tabIndex: 3,
      activeTimeTab: '',
      tabList: ['本周', '本月', '本年', '近两年'],
      number: 180, // (tabList长度为-1) * 60
      itemClassArr: [],
    }
  },
  // async created() {
  //   this.setParams()
  // },
  mounted() {
    this.getScreenTit()
  },
  methods: {
    toggleTab(index,val) {
      if (this.tabIndex < index) {
        this.number = index * 60
      } else {
        this.number = this.number - ((this.tabIndex-index) * 60)
      }
      this.activeTimeTab = val
      if (this.tabIndex != index) {
        this.tabIndex = index
        this.setParams()
        this.initPage()
      }
    },
    // 获取大屏标题和tab配置
    getScreenTit () {
      const self = this
      getCurScreenTit({key: '0',dicTypeCode: 'YZ-Quality-Screen-Title'}).then((res) => {
        if (res.code == 0) {
          const result = res.data[0]
          if (result && JSON.parse(result.dicDefineValue)) {
            const tabSetObj = JSON.parse(result.dicDefineValue)
            // 赋值pacs tab类型
            self.btnList = []
            tabSetObj.bussessType.forEach((item) => {
              if (item.enable) {
                self.btnList.push(item)
                if (item.default == '1') {
                  self.activeBtnValue = item.value
                }
              }
            });
            // 赋值时间tab
            self.tabList = []
            tabSetObj.timeArr.forEach((item) => {
              if (item.enable) {
                self.tabList.push(item)
                if (item.default == '1') {
                  self.activeTimeTab = item.value
                  self.setParams()
                }
              }
            });
            if (self.tabList.length != 0) {
              self.tabList.forEach((one,i) => {
                if (one.value == self.activeTimeTab) {
                  self.tabIndex = i
                  self.number = 60*i
                }
              })
            }
            self.screenTitle = tabSetObj.screenTitle
            self.hasScreenTitle = true
          } else {
            self.hasScreenTitle = false
          }
          if (result) {
            self.dataDicDefineId = result.dataDicDefineId
          }
          
          self.$nextTick(() => {
            self.initPage()
            self.timer = setInterval(() => {
              self.initPage()
            }, 60 * 1000)
          })
        } else {
          self.$message.error(res.msg)
        }
      })
    },
    // 修改/新增大屏标题
    changeTitle () {
      if (this.hasScreenTitle) { // 修改标题
        updateCurScreenTit({ dataDicDefineId: this.dataDicDefineId,dicDefineValue: this.screenTitle }).then((res) => {
        if (res.code == 0) {

        } else {
          this.$message.error(res.msg)
        }
       })
      } else { // 新增标题
        addScreenTit({dicDefineCode: "0",
            dicClassCode: "YZ-Quality-Screen-Title",
            dicDefineValue: this.screenTitle,
            dataDicTypeId: "1154380743602999296"}).then((res) => {
        if (res.code == 0) {

        } else {
          this.$message.error(res.msg)
        }
       })
      }
    },
    // 点击影像优良率单柱状图 的  单根柱子
    clickChartFunc (index, action) {
      console.log(index,action)
    },
    onPacsChange(value) {
      this.activeBtnValue = value
      this.setParams()
      this.initPage()
    },
    setUpdateDate() {
      this.updateDate = moment().format('YYYY-MM-DD HH:mm:ss')
    },
    setParams() {
      // let orgId = ''
      // const { profile } = this.loginUserInfo
      // if (profile?.inst_id) {
      //   orgId = profile.inst_id
      // }
      // this.$set(this.params, 'orgId', orgId)
      this.$set(this.params, 'startTime', this.getStartTime())
      this.$set(this.params, 'endTime', moment().format('YYYY-MM-DD') + ' 23:59:59')
      this.$set(this.params, 'produceCode', this.activeBtnValue)
      if (this.activeTimeTab == 0) { // 本周
        this.$set(this.params, 'dateType', 'THIS_WEEK')
      } else if (this.activeTimeTab == 1) { // 本月
        this.$set(this.params, 'dateType', 'THIS_MONTH')
      } else if (this.activeTimeTab == 2) { // 本年
        this.$set(this.params, 'dateType', 'THIS_YEAR')
      } else if (this.activeTimeTab == 3) { // 近两年
        this.$set(this.params, 'dateType', 'TWO_YEAR')
      }

    },
    getStartTime() {
      let startDate = ''
      // if (this.tabIndex == 0) { // 今日
      //   startDate = moment().format('YYYY-MM-DD')
      // } 
      if (this.activeTimeTab == 0) { // 本周
        // 本周第一天 从周一开始
        startDate = moment()
          .isoWeekday(1)
          .format('YYYY-MM-DD')
      } else if (this.activeTimeTab == 1) { // 本月
        startDate = moment()
          .startOf('month')
          .format('YYYY-MM-DD')
      } else if (this.activeTimeTab == 2) { // 本年
        startDate = moment()
          .startOf('year')
          .format('YYYY-MM-DD')
      } else if (this.activeTimeTab == 3) { // 近两年
        startDate = moment().subtract(2, "years").format("YYYY-MM-DD")
        //startDate = moment().subtract(8, "years").format("YYYY-MM-DD")
      }
      return startDate + ' 00:00:00'
    },
    initPage() {
      this.setUpdateDate()
      this.loading = true
      this.getData()
    },
    // 数值超过3位 前面加逗号
    thousands(num){
      if (num) {
        var str = num.toString();
        var reg = str.indexOf(".") > -1 ? /(\d)(?=(\d{3})+\.)/g : /(\d)(?=(?:\d{3})+$)/g;
        return str.replace(reg,"$1,");
      }
    },
    numberFormat(value) {
      var param = {};
      var k = 10000,
      sizes = ['', '万', '亿', '万亿'],
      i;
      if(value < k){
          param.value =value
          param.unit=''
      }else{
          i = Math.floor(Math.log(value) / Math.log(k)); 
          param.value = ((value / Math.pow(k, i))).toFixed(2);
          param.unit = sizes[i];
      }
      return param;
      // return param.value+param.unit;
    },
    async getData() {
      // 基础数据 机构数量
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1007', this.params).then((res) => {
        if (res.code == 0) {
          this.cardList[0].leftValue = this.thousands(res.data.orgNum)
        } else {
          this.$message.error(res.msg)
        }
      })
      // 基础数据 设备数量
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1008', this.params).then((res) => {
        if (res.code == 0) {
          this.cardList[0].centerValue = this.thousands(res.data.equipmentNum)
        } else {
          this.$message.error(res.msg)
        }
      })
      // 基础数据 从业人员
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1009', this.params).then((res) => {
        if (res.code == 0) {
          this.cardList[0].rightValue = this.thousands(res.data.empNum)
        } else {
          this.$message.error(res.msg)
        }
      })
      // 检查概括 预约人次
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1010', this.params).then((res) => {
        if (res.code == 0) {
          //this.workPregressObj.leftValue = this.thousands(res.data.bookNum)
          const orderObj = this.numberFormat(res.data.bookNum)
          this.workPregressObj.leftValue = orderObj.value
          this.workPregressObj.leftTitle = `预约(${orderObj.unit}人次)`
        } else {
          this.$message.error(res.msg)
        }
      })
      // 检查概括 检查人次
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1011', this.params).then((res) => {
        if (res.code == 0) {
          //this.workPregressObj.rightValue = this.thousands(res.data.examNum)
          const orderObj = this.numberFormat(res.data.examNum)
          this.workPregressObj.rightValue = orderObj.value
          this.workPregressObj.rightTitle = `检查(${orderObj.unit}人次)`
        } else {
          this.$message.error(res.msg)
        }
      })
      // 检查概括 检查费用
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1012', this.params).then((res) => {
        if (res.code == 0) {
          const feeObj = this.numberFormat(res.data.money)
          this.inspectFeeObj.leftValue = feeObj.value
          this.inspectFeeObj.leftTitle = `检查费用(${feeObj.unit}元)`
        } else {
          this.$message.error(res.msg)
        }
      })
      // 远程协同 远程诊断人次
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1013', this.params).then((res) => {
        if (res.code == 0) {
          const diagnosisObj = this.numberFormat(res.data.applyNum)
          this.cardList[1].leftValue = diagnosisObj.value
          this.cardList[1].leftTitle = `远程诊断(${diagnosisObj.unit}人次)`

        } else {
          this.$message.error(res.msg)
        }
      })
      // 远程协同 远程会诊人次
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1014', this.params).then((res) => {
        if (res.code == 0) {
          //this.cardList[1].centerValue = this.thousands(res.data.consNum)
          const consultObj = this.numberFormat(res.data.consNum)
          this.cardList[1].centerValue = consultObj.value
          this.cardList[1].centerTitle = `远程会诊(${consultObj.unit}人次)`
        } else {
          this.$message.error(res.msg)
        }
      })
      // 远程协同 跨机构检查预约人次
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1015', this.params).then((res) => {
        if (res.code == 0) {
          //this.cardList[1].rightValue = this.thousands(res.data.moreOrgBookNum)
          const orderObj = this.numberFormat(res.data.moreOrgBookNum)
          this.cardList[1].rightValue = orderObj.value
          this.cardList[1].rightTitle = `跨机构检查预约(${orderObj.unit}人次)`
          // 将跨机构检查预约人次 数量写死
          if (this.activeTimeTab == 0) { // 本周
            this.cardList[1].rightValue = 90
          } else if (this.activeTimeTab == 1) { // 本月
            this.cardList[1].rightValue = 496
          } else if (this.activeTimeTab == 2) { // 本年
            this.cardList[1].rightValue = 8575
          } else if (this.activeTimeTab == 3) { // 近两年
            this.cardList[1].rightValue = 16624
          }
        } else {
          this.$message.error(res.msg)
        }
      })
      // 危急值 危急值通报人次
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1016', this.params).then((res) => {
        if (res.code == 0) {
          //this.crisisObj.leftValue = this.thousands(res.data.critNum)
          const orderObj = this.numberFormat(res.data.critNum)
          this.crisisObj.leftValue = orderObj.value
          this.crisisObj.leftTitle = `危急值通报(${orderObj.unit}人次)`
        } else {
          this.$message.error(res.msg)
        }
      })
      // 危急值 危急值处理人次
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1017', this.params).then((res) => {
        if (res.code == 0) {
          //this.crisisObj.rightValue = this.thousands(res.data.critNum)
          const orderObj = this.numberFormat(res.data.critNum)
          this.crisisObj.rightValue = orderObj.value
          this.crisisObj.rightTitle = `危急值处理(${orderObj.unit}人次)`
        } else {
          this.$message.error(res.msg)
        }
      })
      // 绿色通道
      await dynamicInvoke('YZ-Area-Quality-YWScreen_1018', this.params).then((res) => {
        if (res.code == 0) {
          const greenObj = this.numberFormat(res.data.greenNum)
          this.inspectFeeObj.rightValue = greenObj.value
          this.inspectFeeObj.rightTitle = `绿色通道(${greenObj.unit}人次)`
        } else {
          this.$message.error(res.msg)
        }
      })

      // 超声或内镜时 获取检查报告图表 里面 的 项目分类
      if (this.activeBtnValue == 'UIS' || this.activeBtnValue == 'EIS') {
        await dynamicInvoke('QC_1177', {produceCode: this.activeBtnValue }).then((res) => {
          if (res.code == 0) {
            this.itemClassArr = res.data
          } else {
            this.$message.error(res.msg)
          }
        })
      }
      await this.initChart()
      this.loading = false
    },
    initChart () {
      const self = this
      self.$nextTick(() =>{
        if (self.activeBtnValue == 'ECG') {
          self.$refs.inspectPeopleRef.refreshChart()
          self.$refs.inspectPeopleRef.refreshPieChart()

          self.$refs.inspectFeeRef.refreshChart()
          self.$refs.inspectFeeRef.refreshPieChart()
          // 检查等待
          self.$refs.inspectWaitRef.refreshChart()
          // 检查报告
          self.$refs.inspectReportRef.refreshChart()  
        } else {
          // 放射检查预约
          self.$refs.inspectOrderTimeRef.refreshChart()
          // 放射检查报告平均耗时
          self.$refs.inspectReportTimeRef.refreshChart()
          // 放射危急值通报
          self.$refs.criticaValueRef.refreshChart()
          // 放射报告阳性率
          self.$refs.reportRateRankingChartRef.refreshChart()
          // 放射诊断符合率
          self.$refs.imageRateRankingChartRef.refreshChart()
          // 放射报告优良率
          self.$refs.reportExcellentRateExamineTypeChartRef.refreshChart()    
        }
        
      })
      
    },
    handleClose(done) {
      done();
    },
    closeFn() {
      this.drawer = false;
    },
    showTabSetAlert () {
      const self = this
      self.drawer = true;
      self.$nextTick(() => {
        self.$refs.tabSetAlert.getScreenTit()
      })
    },
    // 确认保存tab配置
    sureSaveTabSet (data) {
     updateCurScreenTit({ dataDicDefineId: this.dataDicDefineId,dicDefineValue: data }).then((res) => {
        if (res.code == 0) {
          this.$message.success("保存成功");
          this.drawer = false;
          this.getScreenTit()
        } else {
          this.$message.error(res.msg)
        }
      })
     }
  },
  destroyed() {
    clearInterval(this.timer)
    this.timer = null
  }
}
</script>

<style lang="scss" scoped>
@import "~@/style/util.scss";
.visualizing-container {
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background-image: url('~@/assets/images/visualizing/bg.png');
  background-size: cover;
  background-position: center;
}
.visualizing-header {
  width: 100%;
  height: vh(81);
  position: relative;

  .header-bg {
    width: 100%;
    height: vh(63);
    background-image: url('~@/assets/images/visualizing/header_bg.png');
    background-size: 100% 100%;
    position: absolute;
    left: 0;
    bottom: 0;
  }
  .btn-group {
    position: absolute;
    left: vw(20);
    bottom: 0;
    display: flex;
    align-items: center;
    .btn {
      position: relative;
      width: vw(48);
      height: vh(30);
      // line-height: vh(30);
      display: flex;
      justify-content: center;
      align-items: center;
      font-family: PingFangSC-Regular;
      font-weight: 400;
      font-size: vh(14);
      color: #25f5ff;
      text-align: center;
      border-radius: 4px;
      border: 1px solid #25f5ff;
      box-sizing: border-box;
      cursor: pointer;
      &:not(:last-child) {
        margin-right: vw(20);
      }
    }
    .btn-active {
      border: none;
    }
    .btn-active-img {
      width: vw(48);
      height: vh(30);
      position: absolute;
      top: 0;
      left: 0;
    }
  }
  .title {
    position: relative;
  }
  .tabSetIcon{
    position: absolute;
    right:10px;
    top:10px;
    color:#25F5FF;
    font-size: 16px;
    cursor: pointer;
  }
  .title-input {
    width: 100%;
    border: none;
    font-family: PingFangSC-SNaNpxibold;
    font-weight: 600;
    font-size: vh(54);
    text-align: center;
    letter-spacing: 8px;
    color: transparent;
    caret-color: #fff;
    line-height: vh(50);
    background-image: linear-gradient(
      90deg,
      #3f70ff 35%,
      #25f5ff 50%,
      #3f70ff 65%
    );
    -webkit-background-clip: text;
    background-clip: text;
    z-index: 999;
  }
  .update-date-wrapper {
    position: absolute;
    right: vw(20);
    bottom: 0;
    .update-date {
      font-family: PingFangSC-Medium;
      font-weight: 500;
      font-size: vh(16);
      color: #25f5ff;
    }
  }
}
.visualizing-main {
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  padding: vh(20) vw(20);
}
.card-list {
  height: vh(140);
  display: flex;
  justify-content: space-between;

  .card-item {
    position: relative;
    width: vw(493);
    height: vh(140);
    background-size: 100% 100%;
    border-radius: 10px;
    background-image: url('~@/assets/images/visualizing/other_bg1.png');
    display: flex;
    flex-direction: column;
    .icon-border {
      background: url('~@/assets/images/visualizing/icon_border1.svg');
      position: absolute;
      width: 20px;
      height: 20px;
    }
    i{
      color: #00FFF6;
      font-size: vh(16);
      position: relative;
      top: vh(1);
    }
    .left-top {
      left: 0;
      top: 0;
    }
    .left-bottom {
      left: 0;
      bottom: 0;
      transform: rotateX(180deg);
    }
    .right-top {
      right: 0;
      top: 0;
      transform: rotateY(180deg);
    }
    .right-bottom {
      right: 0;
      bottom: 0;
      transform: rotateX(180deg) rotateY(180deg);
    }
    .header-wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      height: vh(30);
      .title {
        line-height: vh(22);
        font-family: PingFangSC-Medium;
        font-weight: 500;
        font-size: vh(16);
        color: #00fff6;
        margin-left: vw(6);
      }
    }
    .content {
      display: flex;
      flex: 1;
      margin-top: vh(16);
      margin-bottom: vh(19);
      margin-left: vw(20);
      margin-right: vw(20);
      .left {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }
      .center {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }
      .right {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }
      .title {
        font-family: PingFangSC-Medium;
        font-weight: 500;
        font-size: vh(14);
        color: #00fff6;
      }
      .value {
        font-family: PingFangSC-Medium;
        font-weight: 500;
        font-size: vh(36);
        color: #00fff6;
      }
      .unit {
        font-size: vh(14);
      }
    }
    // &:nth-child(n + 4) {
    //   background-image: url('~@/assets/images/visualizing/other_bg2.png');
    //   .icon-border {
    //     background: url('~@/assets/images/visualizing/icon_border2.svg');
    //   }
    //   .header-wrapper {
    //     .title {
    //       color: #ffe800;
    //     }
    //   }
    //   .content {
    //     .title,
    //     .value {
    //       color: #ffe800;
    //     }
    //   }
    // }
  }
  .commonCard{
    width:vw(393);
    .card-item {
      width:100%;
    }
  }
  .workProgressCard{
     width:vw(320.67)!important;
  }
  .remoteCard{
    width:vw(443)!important;;
    margin-left: vw(20)
  }
  .basicData {
    .icon {
      width: vw(16);
      height: vw(14.8);
    }
  }

  .inspectCase {
    .icon {
      width: vw(16);
      height: vw(15.43);
    }
  }
  .remote {
    .icon {
      width: vw(16);
      height: vh(14.1);
    }
  }
  .critical {
    width: vw(270.67);
    margin-left: vw(20);
    .icon {
      width: vw(13.59);
      height: vh(16);
    }
  }
  .check-abnormal {
    .icon {
      width: vw(11.1);
      height: vh(16);
    }
  }
  .report-abnormal {
    .icon {
      width: vw(13.87);
      height: vh(16);
    }
  }
}
.chart-main {
  flex: 1;
  overflow: hidden;
  display: flex;
  justify-content: space-between;
  margin-top: vh(20);
}
.flex-warp-item {
  position: relative;
  width: 100%;
  box-sizing: border-box;
}
.data-left {
  width: vw(612);
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.data-center {
  width: vw(612);
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.data-right {
  width: vw(614);
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.workload{
  height: vh(240);
}
.positive-rate-department,
.machine-room,
.report-excellent-rate-ranking {
  height: vh(387);
}
.positive-rate-examine-type,
.image-excellence-rate-examine-type,
.report-excellent-rate-examine-type {
  height: vh(387);
}
.m-tab { position: relative;display: flex; align-items: center; justify-content: space-between;}
.m-tab-item { width: 60px; color: #25F5FF; font-size: 15px; text-align: center; padding-bottom: 10px;cursor: pointer;}
.m-tab-item-active {color: #25F5FF;font-weight: 700;}
.tab-line {height: 4px; width: 60px; background: #25F5FF; position: absolute; bottom: 0; left: 0; transition: all 0.3s ease;}
.ecgChartMain {
 .data-left {
  width: vw(930);
 }
 .data-right {
  width: vw(930);
 }
}
</style>
