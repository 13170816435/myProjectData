<template>
  <div class="container-bg">
    <div class="header-content">
      <div class="navbar">
        <div
          class="navbar-item"
          :class="{ 'navbar-item-selected': navbarIndex === item.value }"
          v-for="item in navbarList"
          :key="item.value"
          @click="selectNavbar(item)"
        >
          {{ item.name }}
        </div>
      </div>
      <page-title :title="title" :initSize="32" :initMax="19" :width="680" :letterSpace="3" @updateTitle="updateTitle"></page-title>
      <div class="time">
        <span style="margin-right: 25px;">更新日期：{{ updateTime }}</span>
        <update-data @updateData="updateData"></update-data>
      </div>
    </div>
    <div class="charts-container">
      <div class="section-container h970">
        <div class="charts-section w620">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>
          <div class="charts-item">
            <div class="charts-header">
              <div class="charts-header-content">
                <img
                  class="charts-header-icon"
                  src="@/assets/images/dataCockpit/yunshangfuyou/yczd.png"
                  alt=""
                />
                <!-- <span>{{this.year}}远程诊断</span> -->
                <span>远程诊断</span>
              </div>
              <!-- <span class="charts-header-tip">单位：人次</span> -->
            </div>
            <div class="chart-bar" style="width:100%;height:308px;position:relative;">
              <span class="barTit">远程诊断分布</span>
              <clickChartItem
                :option="diagnosisBarOption"
                :action="'diagnosis'"
                v-show="diagnosisBarOption"
                @clickChartFunc="clickChartFunc"
              ></clickChartItem>
            </div>
          </div>
          <div class="charts-item-bt barAndPieChart h310">
            <div class="diagnosisChartBar">
              <div class="charts-header charts-noBgHeader">
                <div class="charts-header-content">
                  <span class="diagnosisLabel">{{diagnosisName}}申请量 TOP5</span>
                </div>
              </div>
              <div class="chart-bar" style="width:100%;">
                <chart-item
                  :option="diagnosisProgressOption"
                  v-show="diagnosisProgressOption"
                ></chart-item>
              </div>
            </div>
            <!-- <div class="diagnosisPieBar">
              <div class="charts-header charts-noBgHeader">
                <div class="charts-header-content inspectClassTitDiv">
                  <span class="diagnosisLabel">{{diagnosisInspectClassName}}</span>
                </div>
              </div>
              <div class="chart-bar" style="width:100%;height:230px">
                <chart-item
                  :option="diagnosisPieOption"
                  v-show="diagnosisPieOption"
                ></chart-item>
              </div>
            </div> -->
          </div>

         <div class="charts-item-bt barAndPieChart h310">
            <div class="diagnosisChartBar">
              <div class="charts-header charts-noBgHeader">
                <div class="charts-header-content">
                  <span class="diagnosisLabel">{{diagnosisName}}{{diagnosisInspectClassName}}</span>
                </div>
              </div>
              <div class="chart-bar" style="width:100%;">
                <chart-item
                  :option="diagnosisPieOption"
                  v-show="diagnosisPieOption"
                ></chart-item>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="section-container h970 ml10">
        <div class="charts-section w750 h480">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>

          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/yunshangfuyou/ptgl.png"
                alt=""
              />
              <span>平台概览</span>
            </div>
          </div>
          <div class="charts-cards">
            <div class="charts-card charts-card-jg">
              <div class="charts-card-content">
                <div class="charts-card-title">
                  接入机构(家)
                </div>
                <div class="charts-card-data blueNum">
                  {{telemedicineTotalObj.platform_overview && telemedicineTotalObj.platform_overview.institution_num}}
                </div>
              </div>
            </div>
            <div class="charts-card charts-card-yh">
              <div class="charts-card-content">
                <div class="charts-card-title">
                  医护人员(人)
                </div>
                <div class="charts-card-data greenNum">
                   {{telemedicineTotalObj.platform_overview && telemedicineTotalObj.platform_overview.doctor_num}}
                </div>
              </div>
            </div>
            <div class="charts-card charts-card-zx">
              <div class="charts-card-content">
                <div class="charts-card-title">
                  服务中心(个)
                </div>
                <div class="charts-card-data orangeNum">
                   {{telemedicineTotalObj.platform_overview && telemedicineTotalObj.platform_overview.service_center_num}}
                </div>
              </div>
            </div>
            <div class="charts-card charts-card-cc">
              <div class="charts-card-content">
                <div class="charts-card-title">
                  存储量(GB)
                </div>
                <div class="charts-card-data redNum">
                   {{telemedicineTotalObj.platform_overview && telemedicineTotalObj.platform_overview.use_amount}}
                </div>
              </div>
            </div>
          </div>
          <div class="flex-content">
            <div class="flex-item">
              <div class="charts-item">
                 <div class="news-container">
                    <div class="news-container-title tfont">业务动态</div>
                    <div class="news-item">
                      <div class="news-item-title">远程诊断(人次)</div>
                      <div class="news-item-data">
                        <div :class="item === '，'?'news-item-data-span':'news-item-data-box'" v-for="(item, index) in businessTotalInfo['diagnosis_num-str']" :key="index">{{item}}</div>
                      </div>
                    </div>
                    <div class="news-item">
                      <div class="news-item-title">远程会诊(人次)</div>
                      <div class="news-item-data">
                        <div :class="item === '，'?'news-item-data-span':'news-item-data-box'" v-for="(item, index) in businessTotalInfo['consult_num-str']" :key="index">{{item}}</div>
                      </div>
                    </div>
                    <div class="news-item">
                      <div class="news-item-title">远程教学(人次)</div>
                      <div class="news-item-data">
                        <div :class="item === '，'?'news-item-data-span':'news-item-data-box'" v-for="(item, index) in businessTotalInfo['teach_num-str']" :key="index">{{item}}</div>
                      </div>
                    </div>
                    <!-- <div class="news-item">
                      <div class="news-item-title">线上转诊(人次)</div>
                      <div class="news-item-data">
                        <div :class="item === '，'?'news-item-data-span':'news-item-data-box'" v-for="(item, index) in businessTotalInfo['referral_num-str']" :key="index">{{item}}</div>
                      </div>
                    </div> -->
                  </div>
              </div>
            </div>
            <div class="flex-item mapContainer">
              <div class="card-map"></div>
            </div>
          </div>
        </div>
        <div class="charts-section mt10 w620 h480">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/yunshangfuyou/ycpx.png"
                alt=""
              />
              <span>远程培训</span>
            </div>
          </div>
           <div class="headTotal headTotalBorderNone charts-item-flex">
              <div class="oneTotal chart-flex">
                <div class="totalPaddingDiv">
                   <span class="oneTotalLabel">已授课量(门)</span>
                   <span class="oneTotalVal blueNum">{{educationObj.taught_num}}</span>
                </div>
              </div>
              <div class="oneTotal chart-flex">
                <div class="totalPaddingDiv">
                   <span class="oneTotalLabel">待授课量(门)</span>
                   <span class="oneTotalVal greenNum">{{educationObj.un_taught_num}}</span>
                </div>
              </div>
              <div class="oneTotal chart-flex">
                <div class="totalPaddingDiv">
                   <span class="oneTotalLabel">学习量(门)</span>
                   <span class="oneTotalVal orangeNum">{{educationObj.learn_num}}</span>
                </div>
              </div>
              <div class="oneTotal chart-flex">
                <div class="totalPaddingDiv">
                   <span class="oneTotalLabel">考试量(门)</span>
                   <span class="oneTotalVal redNum">{{educationObj.exam_num}}</span>
                </div>
              </div>
          </div>
          <div class="charts-item charts-item-bt barAndPieChart teachDiv">
              <!-- <div class="diagnosisChartBar">
                <div class="charts-header">
                  <div class="charts-header-content">
                    <span class="diagnosisLabel">讲师授课总量 TOP5</span>
                  </div>
                </div>
                <div class="chart-bar" style="width:100%;height:230px">
                  <chart-item
                    :option="teachOption"
                    v-show="teachOption"
                  ></chart-item>
                </div>
              </div> -->
              <div class="percentage-list" style="height: 100%">
                <div class="percentage-list-header">
                  <div class="percentage-list-title">
                    讲师授课总量 TOP8
                  </div>
                  <div class="percentage-list-legends">
                    <div class="percentage-list-legend">
                      <div class="percentage-list-legend-shape anlNum"></div>
                      <div class="percentage-list-legend-label">已授</div>
                    </div>
                    <div class="percentage-list-legend">
                      <div class="percentage-list-legend-shape examNum"></div>
                      <div class="percentage-list-legend-label">未授</div>
                    </div>
                  </div>
                </div>
                <div class="percentage-list-content">
                  <div class="percentage-item" v-for="item in distanceTeachList" :key="item.orgName">
                    <div class="percentage-item-label">{{item.name}}</div>
                    <div class="percentage" v-bind:title="'未授课:'+item.un_taught_num+',已授课:'+item.taught_num">
                      <div class="percentage-exam" :style="{width: item.examWidth + '%'}"></div>
                      <div class="percentage-anl" :style="{width: item.anlWidth + '%'}"></div>
                    </div>
                    <!-- <div class="percentage-item-text">{{item.anlRatio}}%</div> -->
                  </div>
                </div>
            </div>
              <div class="diagnosisPieBar" style="width:274px;">
                <div class="charts-header charts-noBgHeader">
                  <div class="charts-header-content inspectClassTitDiv">
                    <span class="diagnosisLabel">课程类型分布</span>
                  </div>
                </div>
                <div class="chart-bar coursePie" style="width:100%;">
                  <chart-item
                    :option="courseTypePieOption"
                    v-show="courseTypePieOption"
                  ></chart-item>
                </div>
              </div>
          </div>
        </div>
      </div>
      <div class="section-container h970 ml10">
        <div class="charts-section w620">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>
          <div class="charts-item">
            <div class="charts-header">
              <div class="charts-header-content">
               <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/yunshangfuyou/ychz.png"
                alt=""
               />
              <span>远程会诊</span>
            </div>
          </div>
          <div class="chart-bar" style="width:100%;height:308px;position:relative;">
            <span class="barTit">远程会诊分布</span>
            <clickChartItem
              :option="consultBarOption"
              :action="'consult'"
              v-show="consultBarOption"
              @clickChartFunc="clickChartFunc"
            ></clickChartItem>
          </div>
        </div>
        <div class="charts-item-bt barAndPieChart h310">
            <div class="diagnosisChartBar">
              <div class="charts-header charts-noBgHeader">
                <div class="charts-header-content">
                  <span class="diagnosisLabel">{{consultName}}申请量 TOP5</span>
                </div>
              </div>
              <div class="chart-bar" style="width:100%;">
                <chart-item
                  :option="consultProgressOption"
                  v-show="consultProgressOption"
                ></chart-item>
              </div>
            </div>
          </div>

          <div class="charts-item-bt barAndPieChart h310">
            <div class="diagnosisChartBar">
              <div class="charts-header charts-noBgHeader">
                <div class="charts-header-content">
                  <span class="diagnosisLabel">{{consultName}}{{consultInspectClassName}}</span>
                </div>
              </div>
              <div class="chart-bar" style="width:100%;">
                <chart-item
                  :option="consultPieOption"
                  v-show="consultPieOption"
                ></chart-item>
              </div>
            </div>
          </div>
       </div>
      </div>
      
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import * as echarts from "echarts";
import ChartItem from "@/components/dataCockpit/ChartItem.vue";
import clickChartItem from "../components/ChartItem.vue";
import PageTitle from "@/components/dataCockpit/PageTitle.vue";
import UpdateData from '@/components/dataCockpit/UpdateData.vue'
import utils from "@/utils/PIScommonMethod";
import Mgr from "@/utils/SecurityService";
import {
  // getConsultTotal,
  // getBusinessTotal,
  // getDiagnosisTotal,
  // getSummary,
  // getWatchRoomTotal,
  // getDistanceTeachTotal,
  // getReferralTotal,
  getTelemedicineTotal,
  updatePageTitle,
} from "@/api/dataCockpit/wuhanertong/index";
export default {
  components: { ChartItem, PageTitle, UpdateData, clickChartItem },
  data() {
    return {
      isDev: false,
      title: '',
      pageName: '',
      defaultTitle: '武汉儿童医院远程影像中心数据驾驶舱',
      tenancy_id: "",
      baseParams: null,
      updateTime: "",
      telemedicineTotalObj: {
        platform_overview: {}
      },
      ward_roundObj: {},
      educationObj: {},
      businessTotalInfo:{
        'consult_num': 0,
        'diagnosis_num':0,
        'teach_num':0,
        // 'referral_num':120,
      },
      distanceTeachList: [],
      navbarList: [
        // { name: '今日', value: 1 },
        { name: '本月', value: 1 },
        { name: '近1月', value: 2 },
        { name: '近3月', value: 3 },
        { name: '近6月', value: 4 },
        { name: '近12月', value: 5 }
      ],
      navbarIndex: 1,
      // 双y轴柱状图图表共享使用的option
      barDoubleYOption: {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            crossStyle: {
              color: '#999'
            }
          }
        },
        legend: {
          data: [],
          orient: 'horizontal',
          icon: "rect",
          show: true,
          textStyle: { //图例文字的样式
            color: '#fff',
            fontSize: 14
          },
          itemWidth: 12,  // 设置宽度
  　　    itemHeight: 12, // 设置高度
  　　    itemGap: 13,// 设置间距
          right: '10px',
          top:'10px'
        },
        grid: {
          left: '2%',
          right: '10',
          bottom: '3%',
          top:'45',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            data: [],
            axisPointer: {
              type: 'shadow'
            },
            axisLabel: {
            color: '#00d3ff',
            width: 20
          },
          }
        ],
        yAxis: [
          {
            type: 'value',
            splitLine: {
            lineStyle: {//坐标线样式
                type: 'dashed',
                color: '#00d3ff',
                opacity: 0.3
              }
            },
            axisLabel: { //y轴上的 刻度值样式
              color: '#00d3ff'
            }
          }
        ],
        series: [
          {
            name: '诊断量',
            type: 'bar',
            data: [],
            itemStyle: {
              normal: {
                //柱图高亮渐变色
                color: new echarts.graphic.LinearGradient(
                    0, 0, 0, 1,
                    [{
                        offset: 0,
                        color: '#19A576'
                    },
                    {
                        offset: 1,
                        color: '#20C88E'
                    }]
                ),
                barBorderRadius: [2, 2, 0, 0],
              },
            },
          },
          {
            name: '申请量',
            type: 'bar',
            data: [],
            itemStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(
                    0, 0, 0, 1,
                    [{
                        offset: 0,
                        color: '#6298f4'
                    },
                    {
                        offset: 1,
                        color: '#93BAFB'
                    }]
                ),
                //圆角
                barBorderRadius: [2, 2, 0, 0],
              },
            },
          }
        ]
      },
      diagnosisName: "",
      diagnosisInspectClassName:"",
      consultName: "",
      consultInspectClassName:"",
      // 远程诊断分布统计
      diagnosisList: [],
      // 远程会诊分布统计
      consultList: [],
      // 诊断机构分布情况
      diagnosisProgressList: [],
      // 诊断检查类型
      diagnosisInspectClassList: [],
      // 会诊机构分布情况
      consultProgressList: [],
      // 会诊检查类型
      consultInspectClassList: [],
      // 远程培训
      distanceLearning: {},
      // 课程类型
      courseTypeList: [],
      // 转诊统计
      referralList: [],
      referralLevelList: [],
      referralName: '',
      unAppointmentRate: '',
      // 存储量分布情况
      storageTotalList: [],
      // 饼图共享option
      pieSharedOption: {
        tooltip: {
          trigger: 'item',
          // formatter:function (parms){
          //   var str=  parms.name+"</br>"+
          //     "占比："+ parms.percent+"%";
          //     return  str ;
          // }
        },
        legend: {
          icon: "circle",
          itemHeight: 10,
          itemWidth: 10,
          //orient: "vertical",
          bottom: "15%",
          itemGap :10,
          // right: "5%",
          textStyle: {
            align: "bottom",
            color: "#",
            verticalAlign: "middle",
          },
          data: [],
        },
          series: [
              {
                  name: '入住科室分布',
                  type: 'pie',
                  radius: ['25%', '50%'],
                  center: ["50%", "40%"], 
                  labelLine: {
                    normal: {
                      length: 10,
                      length2: 10,
                    }
                  },
                  itemStyle: {
                    normal: {
                      borderColor: '#0d133a',
                      borderWidth: 2  
                    }  
                  },
                  color: ["#0270f2","#628afd","#009ede","#62bdfd","#756bca","#4adeca","#00d169","#19a576","#ff745a","#db6bcf","#f383a2","#ffa8a8","#ff745a","#f6903d","#ffa557"],
                  label: {
                      // formatter: function (e) {
                      //     let {
                      //         data: { value, name, percent },
                      //     } = e;
                      //     //return `{x|}{a|${name}}\n{b|${value}个}{c|${percent}}`;
                      //     return `{c|${percent}}`;
                      // },
                      padding: [0, -10],
                      rich: {
                        c: {
                          fontSize: 12,
                          lineHeight: 20,
                          color: '#00d3ff',
                        }
                      },
                  },
                  data: [],
              },
          ],
      },
    };
  },
  computed: {
    ...mapGetters(['year']),
    // 远程诊断分布图表option
    diagnosisBarOption() {
      let option = null;
      const list = this.diagnosisList;
      if (list.length === 0 || typeof list === 'string') {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.barDoubleYOption));
      const legendData =  ['诊断量', '申请量']
      const xData = list.map(x => x.name);
      const dia_numArr = list.map(x => x.diagnosis_num);
      const apply_numArr = list.map(x => x.apply_num)
      // const maxValue = list[0].exam_num;
      //const maxData = new Array(list.length).fill(maxValue);
      option.legend.data = legendData
      option.xAxis[0].data = xData;
      option.series[0].data = dia_numArr;
      option.series[0].barWidth = 20;
      option.series[0].name='诊断量'
      option.series[1].data = apply_numArr;
      option.series[1].barWidth = 20;
      return option;
    },
    // 远程会诊分布图表option
    consultBarOption() {
      let option = null;
      const list = this.consultList;
      if (list.length === 0 || typeof list === 'string') {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.barDoubleYOption));
      const consultlegendData = ['会诊量', '申请量']
      const xData = list.map(x => x.name);
      const consultCountArr = list.map(x => x.diagnosis_num);
      const applyCountArr = list.map(x => x.apply_num)
      // const maxValue = list[0].exam_num;
      //const maxData = new Array(list.length).fill(maxValue);
      option.legend.data = consultlegendData
      option.xAxis[0].data = xData;
      option.series[0].data = consultCountArr;
      option.series[0].barWidth = 20;
      option.series[0].name='会诊量'
      option.series[1].data = applyCountArr;
      option.series[1].barWidth = 20;
      return option;
    },
    // 诊断检查类型饼状图统计
    diagnosisPieOption () {
      let option = null;
      let list = []
      let total = 0
      if (this.diagnosisInspectClassList.length === 0 || typeof (this.diagnosisInspectClassList) === 'string') {
        return option;
      }
      this.diagnosisInspectClassList.forEach((one) => {
        total = total + one.subtotal
      })
      this.diagnosisInspectClassList.forEach((one) => {
        let obj = {
          value: one.subtotal,
          name: one.name,
          percent:one.subtotal==0 ? 0 : Number((one.subtotal/total).toFixed(2) * 100).toFixed(0)+"%"
        }
        list.push(obj)
      })
      option = JSON.parse(JSON.stringify(this.pieSharedOption));
      // 注意函数不支持
      option.tooltip.formatter = function (parms){
        var str=  parms.name+"</br>"+
          "占比："+ parms.percent+"%";
        return  str ;
      }
      const legendData = list.map(x => x.name);
      option.legend.data = legendData
      option.legend.bottom = '5%'
      option.series[0].radius =  ['30%', '60%'];
      option.series[0].data = list;
      option.series[0].label.formatter = function (e) {
          let {
              data: { value, name, percent },
          } = e;
          //return `{x|}{a|${name}}\n{b|${value}个}{c|${percent}}`;
          return `{c|${percent}}`;
      }
      return option;
    },
    consultPieOption () {
      let option = null;
      let list = []
      let total = 0
      if (this.consultInspectClassList.length === 0 || typeof (this.consultInspectClassList) === 'string') {
        return option;
      }
      this.consultInspectClassList.forEach((one) => {
        total = total + one.subtotal
      })
      this.consultInspectClassList.forEach((one) => {
        let obj = {
          value: one.subtotal,
          name: one.name,
          percent:one.subtotal==0 ? 0 :Number((one.subtotal/total).toFixed(2) * 100).toFixed(0)+"%"
        }
        list.push(obj)
      })
      option = JSON.parse(JSON.stringify(this.pieSharedOption));
      // 注意函数不支持
      option.tooltip.formatter = function (parms){
        var str=  parms.name+"</br>"+
          "占比："+ parms.percent+"%";
        return  str ;
      }
      const legendData = list.map(x => x.name);
      option.legend.data = legendData
      option.legend.bottom = '5%'
      option.series[0].radius =  ['30%', '60%'];
      option.series[0].data = list;
      option.series[0].label.formatter = function (e) {
          let {
              data: { value, name, percent },
          } = e;
          //return `{x|}{a|${name}}\n{b|${value}个}{c|${percent}}`;
          return `{c|${percent}}`;
      }
      return option;      
    },
    // 课程费类型饼状图统计
    courseTypePieOption () {
      let option = null;
      let list = []
      let total = 0
      if (this.courseTypeList.length === 0 || typeof (this.courseTypeList) === 'string') {
        return option;
      }
      this.courseTypeList.forEach((one) => {
        total = total + one.subtotal
      })
      this.courseTypeList.forEach((one) => {
        let obj = {
          value: one.subtotal,
          name: one.name,
          percent:one.subtotal==0 ? 0 :Number((one.subtotal/total).toFixed(2) * 100).toFixed(0)+"%"
        }
        list.push(obj)
      })

      option = JSON.parse(JSON.stringify(this.pieSharedOption));
      // 注意函数得特殊赋值处理
      option.tooltip.formatter = function (parms){
        var str=  parms.name+"</br>"+
          "占比："+ parms.percent+"%";
        return  str ;
      }
      const legendData = list.map(x => x.name);
      option.legend.data = legendData
      option.series[0].color = ['#4992FF','#E8684A','#1AC380']
      option.series[0].data = list;
      option.series[0].label.formatter = function (e) {
          let {
              data: { value, name, percent },
          } = e;
          //return `{x|}{a|${name}}\n{b|${value}个}{c|${percent}}`;
          return `{c|${percent}}`;
      }
      return option;
    },
    // 诊断进度统计
    diagnosisProgressOption () {
      let option = null;
      let getzszy = []
      let getzswcl = []
      let totalArr = []
      let total = 0
     
      // var getzszy = ['专业1', '专业2', '专业3', '专业4', '专业5', ]; //数据点名称
      // var getzswcl = [50, 60, 70, 80, 90]; //招生完成率
      // var getzswcl2 = [50, 60, 70, 80, 90]; //招生完成率
      // var totalArr = [100,200,300,400,500]
      if (this.diagnosisProgressList.length !== 0) {
        this.diagnosisProgressList.forEach((one) => {
        //   if (one.name && one.name.length > 10) {
        //     one.name = one.name.slice(0,10) + '...'
        //   }
          getzszy.push(one.name)
          total = total + one.subtotal
          totalArr.push(one.subtotal)
        })
        this.diagnosisProgressList.forEach((one) => {
          if (one.subtotal == 0) {
            getzswcl.push(0)
          } else {
            getzswcl.push(Number((one.subtotal/total).toFixed(2) * 100).toFixed(0))
          }
        })
      } else {
        return option
      }
      var getzswclzd = []; //招生完成率100%
      for (let i = 0; i < getzswcl.length; i++) {
          if (getzswcl[i] > 100) {
              getzswcl[i] = 100
          }
          getzswclzd.push(100)
      }
      option = {
          grid: {
              left: '15',
              right: '10',
              bottom: '3%',
              top: '3%',
              containLabel: true
          },
          tooltip: {
              trigger: 'axis',
              axisPointer: {
                  type: 'none'
              },
              formatter: function(params) {
                //return getzszy[params[0].dataIndex] + '<br>招生完成率: ' + getzswcl2[params[0].dataIndex] + '%'
                return getzszy[params[0].dataIndex] + '<br>该机构总数: ' + totalArr[params[0].dataIndex]
              }
          },
          xAxis: {
              show: false,
              type: 'value',
          },
          yAxis: [{
              type: 'category',
              inverse: true,
              axisLabel: {
                  show: true,
                  textStyle: {
                      color: '#00d3ff',
                      fontSize: '15'
                  },
                  interval: 0,
                  formatter: function (value) {
                    if (value && value.length >10) {
                      return `${value.slice(0, 10)}...`;
                    }
                    return value;
                  }
              },
              splitLine: {
                  show: false
              },
              axisTick: {
                  show: false
              },
              axisLine: {
                  show: false
              },
              data: getzszy
          }, 
          // {
          //     type: 'category',
          //     inverse: true,
          //     axisTick: 'none',
          //     axisLine: 'none',
          //     show: true,
          //     axisLabel: {
          //         textStyle: {
          //             color: '#333333',
          //             fontSize: '15'
          //         },
          //        // formatter: '{value}%'
          //     },
          //     data: getzswcl2
          // }
          ],
          series: [{
                  name: '值',
                  type: 'bar',
                  zlevel: 1,
                  itemStyle: {
                      normal: {
                          barBorderRadius:  [ 0, 8, 8, 0],
                          //color: '#4992FF'
                          color: new echarts.graphic.LinearGradient(
                                0, 0, 0, 1,
                                [{
                                    offset: 0,
                                    color: '#6298f4'
                                },
                                {
                                    offset: 1,
                                    color: '#93BAFB'
                                }]
                            ),
                      },
                  },
                  barWidth: 16,
                  data: getzswcl
              },
              {
                  name: '背景',
                  type: 'bar',
                  barWidth: 16,
                  barGap: '-100%',
                  data: getzswclzd,
                  itemStyle: {
                      normal: {
                          //color: 'rgba(103,150,253,0.3)',
                          color: '#1A224A',
                          barBorderRadius: 8,
                      }
                  },
              },
          ]
      };
      return option;
    },
    consultProgressOption () {
      let option = null;
      let getzszy = []
      let getzswcl = []
      let totalArr = []
      let total = 0
      // var getzszy = ['专业1', '专业2', '专业3', '专业4', '专业5', ]; //数据点名称
      // var getzswcl = [50, 60, 70, 80, 90]; //招生完成率
      // var getzswcl2 = [50, 60, 70, 80, 90]; //招生完成率
      // var totalArr = [100,200,300,400,500]
      if (this.consultProgressList && this.consultProgressList.length !== 0) {
        this.consultProgressList.forEach((one) => {
          getzszy.push(one.name)
          total = total + one.subtotal
          totalArr.push(one.subtotal)
        })
        this.consultProgressList.forEach((one) => {
          getzswcl.push(Number((one.subtotal/total).toFixed(2) * 100).toFixed(0))
        })
      } else {
        return option
      }
      
      var getzswclzd = []; //招生完成率100%
      for (let i = 0; i < getzswcl.length; i++) {
          if (getzswcl[i] > 100) {
              getzswcl[i] = 100
          }
          getzswclzd.push(100)
      }
      option = {
          grid: {
              left: '15',
              right: '10',
              bottom: '3%',
              top: '3%',
              containLabel: true
          },
          tooltip: {
              trigger: 'axis',
              axisPointer: {
                  type: 'none'
              },
              formatter: function(params) {
                //return getzszy[params[0].dataIndex] + '<br>招生完成率: ' + getzswcl2[params[0].dataIndex] + '%'
                return getzszy[params[0].dataIndex] + '<br>该机构总数: ' + totalArr[params[0].dataIndex]
              }
          },
          xAxis: {
              show: false,
              type: 'value'
          },
          yAxis: [{
              type: 'category',
              inverse: true,
              axisLabel: {
                  show: true,
                  textStyle: {
                      color: '#00d3ff',
                      fontSize: '15'
                  },
                  interval: 0,
                  formatter: function (value) {
                    if (value && value.length >10) {
                      return `${value.slice(0, 10)}...`;
                    }
                    return value;
                  }
              },
              splitLine: {
                  show: false
              },
              axisTick: {
                  show: false
              },
              axisLine: {
                  show: false
              },
              data: getzszy
          }, 
          // {
          //     type: 'category',
          //     inverse: true,
          //     axisTick: 'none',
          //     axisLine: 'none',
          //     show: true,
          //     axisLabel: {
          //         textStyle: {
          //             color: '#333333',
          //             fontSize: '15'
          //         },
          //        // formatter: '{value}%'
          //     },
          //     data: getzswcl2
          // }
          ],
          series: [{
                  name: '值',
                  type: 'bar',
                  zlevel: 1,
                  itemStyle: {
                      normal: {
                          barBorderRadius:  [ 0, 8, 8, 0],
                        //   color: '#4992FF'
                        color: new echarts.graphic.LinearGradient(
                                0, 0, 0, 1,
                                [{
                                    offset: 0,
                                    color: '#6298f4'
                                },
                                {
                                    offset: 1,
                                    color: '#93BAFB'
                                }]
                            ),
                      },
                  },
                  barWidth: 16,
                  data: getzswcl
              },
              {
                  name: '背景',
                  type: 'bar',
                  barWidth: 16,
                  barGap: '-100%',
                  data: getzswclzd,
                  itemStyle: {
                      normal: {
                          //color: 'rgba(103,150,253,0.3)',
                          color: '#1A224A',
                          barBorderRadius: 8,
                      }
                  },
              },
          ]
      };
      return option;      
    },
  },
  mounted() {
    this.pageName = this.$route.name
    this.initRequest()
  },
  methods: {
    // 获取远程医疗所有的统计
    getTelemedicineTotal() {
      const self = this
      getTelemedicineTotal({date_type: self.navbarIndex}).then(res => {
        if (res.code === 0) {
          self.telemedicineTotalObj = res.data
          if (res.data.title) {
            self.title = res.data.title
          } else {
            self.title = self.defaultTitle
          }
          // 赋值远程诊断数据
          self.diagnosisList = res.data.telemed_diagnosis
          if (self.diagnosisList.length !== 0) {
            self.diagnosisProgressList = self.diagnosisList[0].apply_institution
            self.diagnosisInspectClassList = self.diagnosisList[0].categories
            self.diagnosisName = self.diagnosisList[0].name
            self.diagnosisInspectClassName = self.diagnosisList[0].category_name
          }
          // 赋值远程查房数据统计
            self.ward_roundObj = res.data.ward_round
          // 赋值远程会诊数据
          self.consultList = res.data.consult
          if (self.consultList.length !== 0) {
            self.consultProgressList = self.consultList[0].apply_institution
            self.consultInspectClassList = self.consultList[0].categories
            self.consultName = self.consultList[0].name
            self.consultInspectClassName = self.consultList[0].category_name
          }
          // 特殊处理教学数据
          self.educationObj = res.data.education
          self.getDistanceTeachTotal()
          self.courseTypeList = res.data.education.course_type
          // 特殊处理业务动态数据
          self.getBusinessTotal()
          // 处理转诊的统计数据
          self.referralList = res.data.referral
          if (self.referralList.length !== 0) {
            self.referralLevelList = self.referralList[0].level
            self.referralName = self.referralList[0].name
            if (self.referralList[0].un_appointment_num === 0) {
              self.unAppointmentRate = 0
            } else {
              self.unAppointmentRate = (self.referralList[0].un_appointment_num/self.referralList[0].total_num).toFixed(2) * 100
            }
          }
        } else {
          self.$message.error(res.msg);
        }
      });
    },
    // 点击柱状图
    clickChartFunc (index,action) {
      if (action === 'diagnosis') {
        this.diagnosisProgressList = this.diagnosisList[index].apply_institution
        this.diagnosisInspectClassList = this.diagnosisList[index].categories
        this.diagnosisName = this.diagnosisList[index].name
        this.diagnosisInspectClassName = this.diagnosisList[index].category_name
      } else if (action === 'consult'){
        this.consultProgressList = this.consultList[index].apply_institution
        this.consultInspectClassList = this.consultList[index].categories
        this.consultName = this.consultList[index].name
        this.consultInspectClassName = this.consultList[index].category_name
      } 
      else if (action === 'referral'){
        this.referralName = this.referralList[index].name
        this.referralLevelList = this.referralList[index].level
        if (this.referralList[index].un_appointment_num === 0) {
          this.unAppointmentRate = 0
        } else {
          this.unAppointmentRate = (this.referralList[index].un_appointment_num/this.referralList[index].total_num).toFixed(2) * 100
        }
      }
    },
    // 讲师授课总量 TOP5
    getDistanceTeachTotal() {
      this.distanceTeachList= this.educationObj.teacher
      this.distanceTeachList = this.distanceTeachList.sort((a, b)=>{
        return  b.taught_num -a.taught_num
      })
      if(this.distanceTeachList.length > 0) {
        const maxItem = this.distanceTeachList[0]
        this.distanceTeachList.forEach( item => {
          let examWidth
          if (item.un_taught_num === 0) {
            examWidth = 0
          } else {
            examWidth = (item.un_taught_num / maxItem.taught_num).toFixed(2) * 100
          }
          let anlWidth
          if (item.taught_num === 0) {
            anlWidth = 0
          } else {
            anlWidth = (item.taught_num / maxItem.taught_num).toFixed(2) * 100
          }
          this.$set(item, 'examWidth', examWidth)
          this.$set(item, 'anlWidth', anlWidth)
        })
      }
    },
    selectNavbar (item) {
      const { value } = item
      if (this.navbarIndex !== value) {
        this.navbarIndex = value
        this.initRequest();
      }
    },
    // 更新数据
    updateData() {
      this.initRequest();
    },
    // 修改页面标题
    updateTitle(title) {
      if(title !== this.title) {
        const params = {
          title: title
        }
        updatePageTitle(params).then(res => {
          if(res.code === 0) {
            this.title = title
          }else {
            this.$message.error(res.msg)
          }
        })
      }
    },
    // 获取api请求的统一参数 客戶id
    getBaseParams() {
      return new Promise((resolve, reject) => {
        // 客戶ID
        var manager = new Mgr();
        manager.getRole().then(item => {
          if (item) {
            this.tenancy_id = sessionStorage.getItem('curTenancyId') || item.profile.tenancy_id;
            this.baseParams = {
              tenancy_id: this.isDev
                ? "0"
                : this.tenancy_id
            };
            resolve();
          } else {
            reject();
          }
        });
      });
    },
    async initRequest() {
      const _date = new Date();
      this.updateTime = utils.dateFormat(_date, 1);
      //await this.getBaseParams();
      // 获取远程医疗所有的统计
      this.getTelemedicineTotal()


      // 获取远程诊断统计
      // this.getDiagnosisTotal()
      // // 业务动态统计
      // this.getBusinessTotal()
      // // 讲师授课总量 TOP5
      // this.getDistanceTeachTotal()
      // // 获取线上转诊统计
      // this.getReferralTotal()
    },
    // 业务动态统计情况
    getBusinessTotal() {
      this.businessTotalInfo = {
        'consult_num': this.telemedicineTotalObj.platform_overview.consult_num,
        'diagnosis_num':this.telemedicineTotalObj.platform_overview.diagnosis_num,
        'teach_num':this.telemedicineTotalObj.platform_overview.teach_num,
        //'referral_num':this.telemedicineTotalObj.platform_overview.referral_num,
      }
      for(let key in this.businessTotalInfo) {
        let str = String(this.businessTotalInfo[key])
        let pre = new Array(6 - str.length).fill(0).join('')
        str = pre + str
        //str = str.slice(0,1)+'，'+str.slice(1)
        str = str.slice(0,3)+'，'+str.slice(3)
        let arr = str.split('')
        let strKey = key + '-str'
        this.$set(this.businessTotalInfo, strKey, arr)
      }
    },
    // 远程诊断统计
    getDiagnosisTotal() {
      const data = this.baseParams;
      getDiagnosisTotal(data).then(res => {
        if (res.code === 0) {
          //this.diagnosisList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 获取转诊统计
    getReferralTotal() {
      const data = this.baseParams;
      getReferralTotal(data).then(res => {
        if (res.code === 0) {
          this.referralList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
  }
};
</script>
<style lang="less" scoped>
.w145 {
  width: 145px;
}
.w300 {
  width: 300px;
}
.w560 {
  width: 560px;
}
.w620 {
  width: 620px;
}
.h310{
  height:310px;
}
.h420 {
  height: 420px;
}
.h480 {
  height: 480px;
}
.h560 {
  height: 560px;
}
.h540 {
  height: 540px;
}
.h400 {
  height: 400px;
}
.h970 {
  height: 970px;
}
.col-hz {
  color: #f6bd16;
}
.col-jc {
  color: #6298f4;
}
.col-cc {
  color: #5ad8a6;
}
.col-dy {
  color: #ff7100;
}

.container-bg {
  width: 1920px;
  height: 1080px;
  background: url("~@/assets/images/dataCockpit/jinhua2/bg.png");
}
.header-content {
  width: 100%;
  height: 76px;
  position: relative;
  padding: 0 20px;
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  background: url("~@/assets/images/dataCockpit/jinhua2/header_bg.png");
  ::v-deep .title {
    width: 680px;
    font-size: 32px;
    line-height: 76px;
    color: #00d3ff;
    font-weight: 700;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    text-align: center;
    letter-spacing: 3px;
    cursor: pointer;
  }
}
.section-container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.navbar {
  height: 34px;
  display: flex;
  align-items: center;
  &-item {
    width: 72px;
    height: 34px;
    font-size: 16px;
    color: #00d3ff;
    line-height: 34px;
    text-align: center;
    cursor: pointer;
    background: url('~@/assets/images/dataCockpit/anji/platform/nav_bg.png');
    & + & {
      margin-left: 5px;
    }
    &-selected {
      background: url('~@/assets/images/dataCockpit/anji/platform/nav_selected.png') !important;
    }
    &:hover {
      background: url('~@/assets/images/dataCockpit/anji/platform/nav_hover.png');
    }
  }
}
.time {
  color: #00d3ff;
  font-size: 16px;
  padding: 5px 0;
  display: flex;
  align-items: center;
}
.flex-content {
  margin: 0 10px;
  height: 340px;
  display: flex;
}
.flex-item {
//   flex: 1;
  .charts-title{
    font-size:22px!important;
  }
}
.mapContainer{
  width:calc(100% - 250px);
}
.card-map {
  // width: 254px;
  height: 340px;
  background: url("~@/assets/images/dataCockpit/yunshangfuyou/whMap.png")  right center no-repeat;
  margin: auto;
}
.card-jg {
  width: 364px;
  height: 54px;
  background: url("~@/assets/images/dataCockpit/jinhua2/card-jg.png");
}
.card-content {
  height: 54px;
  font-size: 20px;
  color: #fff;
  margin-left: 66px;
  line-height: 50px;
}
.span-data {
  font-size: 26px;
  color: #4992ff;
}
.charts {
  &-container {
    margin: 15px;
    display: flex;
  }
  &-section {
    border: 1px solid rgba(106, 127, 197, 0.7);
    border-radius: 4px;
    position: relative;
    background: rgba(18, 20, 64, 0.6);
  }
  &-header {
    height: 40px;
    padding: 0 15px;
    color: #00d3ff;
    font-size: 20px;
    font-weight: bold;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: rgba(6, 26, 77, 0.9);
    &-content {
      display: flex;
      align-items: center;
    }
    &-icon {
      width: 20px;
      height: 20px;
      margin-right: 10px;
    }
    &-tip {
      float: right;
      color: #fff;
      font-size: 16px;
      line-height: 45px;
      font-weight: normal;
    }
    .diagnosisLabel{
      font-size:15px;
      color:#fff;
      font-weight: 400;
    }
  }
  &-noBgHeader{
    background: initial;
  }
  &-item {
    overflow: hidden;
    & + & {
      margin-top: 10px;
    }
    &-bt {
      border-top: 1px dashed #4c5d94;
    }
    &-nopadding {
      padding: 0;
    }
    &-flex {
      display: flex;
      justify-content: space-between;
      align-items: center;
      &-colu {
        flex-direction: column;
      }
    }
  }
  &-content {
    overflow: hidden;
  }
  &-title {
    color: #fff;
    font-size: 16px;
    font-weight: bold;
    margin: 10px 0;
    overflow: hidden;
    &-flex {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    &-item {
      flex: 1;
    }
    &-small {
      font-size: 15px;
    }
  }
  &-tab {
    float: right;
    display: flex;
    font-size: 14px;
    color: #409eff;
    border: 1px solid #409eff;
    border-radius: 3px;
    font-weight: normal;
    &-item {
      padding: 4px 15px;
      cursor: pointer;
      &-selected {
        background: #409eff;
        color: #fff;
      }
    }
  }
  &-icons {
    width: 100%;
    padding: 20px 0;
    display: flex;
    justify-content: space-around;
    align-items: center;
    border-bottom: 1px dashed #4c5d94;
  }
  &-icon {
    height: 56px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    &-data {
      font-size: 36px;
      height: 36px;
      line-height: 36px;
    }
    &-text {
      font-size: 16px;
      color: #fff;
    }
    &-number {
      height: 36px;
      line-height: 36px;
      margin-right: 5px;
      display: inline-block;
    }
    &-content {
      margin-left: 10px;
    }
  }
  &-sideNav {
    width: 120px;
    height: 256px;
    float: left;
    margin-top: 10px;
    overflow-y: auto;
    &-item {
      width: 100%;
      padding: 0 10px;
      height: 32px;
      line-height: 32px;
      color: #00d3ff;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: pointer;
      &-selected {
        color: #fff;
        background: #4e52aa;
        border-radius: 3px;
      }
    }
  }
  &-nav {
    width: 110px;
    text-align: center;
    cursor: pointer;
    &-selected {
      color: #409eff;
      border-bottom: 3px solid #409eff;
    }
  }
  &-navbar {
    display: flex;
    height: 44px;
    line-height: 44px;
    &-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 45px;
      padding: 0 15px;
      color: #00d3ff;
      font-size: 20px;
      font-weight: bold;
      border-bottom: 1px solid #515f98;
      background: rgba(6, 26, 77, 0.9);
    }
  }
  &-thead {
    width: 100%;
    padding: 15px 15px 0;
    color: #fff;
    display: flex;
  }
  &-cards {
    display: flex;
    justify-content: space-between;
    margin: 10px;
  }
  &-card {
    width: 142px;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
    //background: url("~@/assets/images/dataCockpit/jinhua2/card-bg.png");
    &-jg{
      background: url("~@/assets/images/dataCockpit/yunshangfuyou/jg-bg.png") right bottom no-repeat;
    }
    &-yh{
      background: url("~@/assets/images/dataCockpit/yunshangfuyou/yh-bg.png") right bottom no-repeat;
    }
    &-zx{
      background: url("~@/assets/images/dataCockpit/yunshangfuyou/zx-bg.png") right bottom no-repeat;
    }
    &-cc{
      background: url("~@/assets/images/dataCockpit/yunshangfuyou/cc-bg.png") right bottom no-repeat;
    }
    &-title {
      font-size: 15px;
      color: #fff;
      margin-bottom: 5px;
    }
    &-data {
      font-size: 32px;
      font-family: "Arial";
      font-weight: bold;
      color: #fff;
      text-align: center;
    }
  }
}
.coursePie{
  height: calc(100% - 40px);  
}
.news-container {
  width: 250px;
  margin-top: 10px;
  &-title {
    font-size: 26px;
    color: #fff;
    text-shadow: 0 0 8px #fff;
  }
}
.news-item {
  width: 100%;
  & + & {
    margin-top: 10px;
  }
  &-title {
    text-align: right;
    font-size: 15px;
    color: #fff;
    font-weight: bold;
    margin-bottom: 8px;
  }
  &-data{
    display: flex;
    height: 48px;
    &-box {
      width: 36px;
      height: 48px;
      background: url('~@/assets/images/dataCockpit/yunshangfuyou/num-bg.png');
      // color: #FAED3B;
      color:#00D3FF;
      font-size: 36px;
      font-family: Arial;
      text-align: center;
      line-height: 50px;
      margin-right: 3px;
      flex-shrink: 0;
    }
    &-span {
      height: 48px;
      line-height: 48px;
      // color: #FAED3B;
      color:#00D3FF;
      font-size: 36px;
      margin-right: -18px;
    }
  }
}
.border-line {
  width: 330px;
  height: 1px;
  background: url("~@/assets/images/dataCockpit/jinhua2/line.png");
  position: absolute;
  top: -1px;
  left: 0;
  right: 0;
  margin: 0 auto;
}
.border-icon {
  width: 16px;
  height: 16px;
  position: absolute;
  &-lt {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-lt.png");
    top: -1px;
    left: -1px;
  }
  &-lb {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-lb.png");
    bottom: -1px;
    left: -1px;
  }
  &-rt {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-rt.png");
    top: -1px;
    right: -1px;
  }
  &-rb {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-rb.png");
    right: -1px;
    bottom: -1px;
  }
}
.chart {
  &-flex {
    flex: 1;
    & + & {
      border-left: 1px dashed #4c5d94;
    }
  }
}
.barAndPieChart{
  display: flex;
  .diagnosisChartBar{
    // width:calc(100% - 272px);
    width:100%;
    .chart-bar{
       padding-right:15px;
    //    padding-bottom:15px;
       height: calc(100% - 40px); 
    }
  }
  .diagnosisPieBar{
    width:100%;
  }
  .inspectClassTitDiv{
    width:100%;
    justify-content: center;
  }
}
.chartTit{
  height: 40px;
  line-height: 40px;
  padding: 0 15px;
  color: #fff;
  font-size: 15px;
}
.watchRoomDiv{
  height:400px;
}
.headTotal{
  height:90px;
  border-bottom:1px dashed #4c5d94;
  .oneTotal{
    height: 100%;
    border-left:none!important;
    .totalPaddingDiv{
      height: 100%;
      padding:15px 15px;
      display: flex;
      flex-direction: column;
      // align-items: center;
      justify-content: space-between;
      color:#fff;
    }
    .oneTotalLabel{
      font-size:15px;
      color:#fff;
    }
    .oneTotalVal{
      font-size: 26px;
      font-family: "Arial";
      font-weight: 700;
      letter-spacing: 0.65px;
    }
    
  }
}
.headTotalBorderNone{
  border-bottom:none;
}
.teachDiv{
  height: calc(100% - 130px);
}
.blueNum{
  color:#4992FF;
}
.greenNum{
  color:#00DB84;
}
.orangeNum{
  color:#FFD100;
}
.redNum{
  color:#E8684A;
}
.barTit{
  font-size:15px;
  color:#fff;
  position: absolute;
  top:0px;
  line-height: 40px;
  padding-left:15px;
}
/***讲师授课 */
.percentage-list {
  padding: 10px 15px;
  padding-top:0px;
  width:calc(100% - 274px);
  overflow: hidden;
  & + & {
    border-top: 1px solid rgba(32,219,238,0.3);
  }
  &-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 40px;
    line-height: 40px;
  }
  &-content {
    overflow: hidden;
    height:calc(100% - 52px);
    margin-top:12px;
  }
  &-title {
    font-size: 15px;
    color: #fff;
  }
  &-legends{
    display: flex;
    // margin-left: 175px;
  }
  &-legend {
    display: flex;
    align-items: center;
    & + & {
      margin-left: 10px;
    }
    &-shape {
      width: 12px;
      height: 12px;
      // border-radius: 50%;
    }
    &-label {
      color: #20DBEE;
      font-size: 14px;
      margin-left: 5px;
    }
  }
}
.percentage {
  width: 300px;
  height: 14px;
  // background: rgba(32,219,238,.3);
  background:#1A224A;
  // border-radius: 7px;
  margin-left: 5px;
  position: relative;
  &-exam {
    height: 100%;
    // background: #F19D00;
    background: linear-gradient(0deg,#fdab13 0%, #ce8809 100%);
    position: absolute;
    top: 0;
    left: 0;
    z-index: 100;
    // border-radius: 7px;
  }
  &-anl {
    height: 100%;
    // background: #4992FF;
    background: linear-gradient(0deg,#93bafb 0%, #6298f4 100%);
    z-index: 100;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 99;
    // border-radius: 7px;
  }
}
.percentage-item {
  display: flex;
  align-items: center;
  & + & {
    margin-top: 16px;
  }
  &-label {
    width: 75px;
    text-align: right;
    font-size: 14px;
    color: #BEE6FF;
    line-height: 1;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }
  &-text {
    font-size: 15px;
    color: #20DBEE;
    margin-left: 15px;
  }
}
.percentage-container {
  display: flex;
  flex-direction: column;
}
.anlNum {
  background: #4992FF;
}
.examNum {
  background: #F19D00;
}
</style>
