<template>
  <div class="container-bg">
    <div class="header-content">
      <page-title :title="title" :initSize="32" :initMax="19" :width="680" :letterSpace="3" @updateTitle="updateTitle"></page-title>
      <div class="time">
        <span style="margin-right: 25px;">更新日期：{{ updateTime }}</span>
        <update-data @updateData="updateData"></update-data>
      </div>
    </div>
    <div class="charts-container">
      <div class="charts-section w560 h970">
        <div class="border-icon border-icon-lt"></div>
        <div class="border-icon border-icon-lb"></div>
        <div class="border-icon border-icon-rt"></div>
        <div class="border-icon border-icon-rb"></div>
        <div class="border-line"></div>
        <div class="charts-item">
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/jinhua2/icon-jclfb.png"
                alt=""
              />
              <span>{{this.year}}年检查量分布 TOP6</span>
            </div>
            <span class="charts-header-tip">单位：人次</span>
          </div>
          <div class="chart-bar" style="width:100%;height:265px">
            <chart-item
              :option="examNumOption"
              v-show="examNumOption"
            ></chart-item>
          </div>
        </div>
        <div class="charts-item charts-item-bt">
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/jinhua2/icon-cclfb.png"
                alt=""
              />
              <span>{{this.year}}年存储量分布 TOP6</span>
            </div>
            <span class="charts-header-tip">单位：TB</span>
          </div>
          <div class="chart-bar" style="width:100%;height:265px">
            <chart-item
              :option="storageTotalOption"
              v-show="storageTotalOption"
            ></chart-item>
          </div>
        </div>
        <div class="charts-item charts-item-bt">
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/jinhua2/icon-dylfb.png"
                alt=""
              />
              <span>{{this.year}}年调阅量分布 TOP6</span>
            </div>
            <span class="charts-header-tip">单位：人次</span>
          </div>
          <div class="chart-bar" style="width:100%;height:265px">
            <chart-item
              :option="viewNumOption"
              v-show="viewNumOption"
            ></chart-item>
          </div>
        </div>
      </div>
      <div class="section-container h970">
        <div class="charts-section w750 h420">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>

          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/jinhua2/icon-pingtai.png"
                alt=""
              />
              <span>平台概览</span>
            </div>
          </div>
          <div class="charts-cards">
            <div class="charts-card charts-card-hz">
              <div class="charts-card-content">
                <div class="charts-card-title">
                  患者总量(人次)
                </div>
                <div class="charts-card-data">
                  {{ summaryInfo.patient_sum }}
                </div>
              </div>
            </div>
            <div class="charts-card charts-card-jc">
              <div class="charts-card-content">
                <div class="charts-card-title">
                  检查总量(人次)
                </div>
                <div class="charts-card-data">
                  {{ summaryInfo.exam_sum }}
                </div>
              </div>
            </div>
            <div class="charts-card charts-card-cc">
              <div class="charts-card-content">
                <div class="charts-card-title">
                  存储总量(TB)
                </div>
                <div class="charts-card-data">
                  {{ summaryInfo.storage_sum }}
                </div>
              </div>
            </div>
            <div class="charts-card charts-card-dy">
              <div class="charts-card-content">
                <div class="charts-card-title">
                  调阅总量(人次)
                </div>
                <div class="charts-card-data">
                  {{ summaryInfo.view_sum }}
                </div>
              </div>
            </div>
          </div>
          <div class="flex-content">
            <div class="flex-item">
              <div class="card-jg">
                <div class="card-content">
                  接入医疗机构
                  <span class="span-data">{{ orgDistributeInfo.org_num }}</span>
                  家
                </div>
              </div>
              <div class="charts-item">
                <div class="charts-title">
                  {{this.year}}年检查阳性率
                </div>
                <div class="charts-gauge" style="width:100%;height:180px">
                  <chart-item :option="positiveRatioOption"></chart-item>
                </div>
              </div>
            </div>
            <div class="flex-item">
              <div class="card-map"></div>
            </div>
          </div>
        </div>
        <div class="charts-section w750 h540">
          <div class="border-icon border-icon-lt"></div>
          <div class="border-icon border-icon-lb"></div>
          <div class="border-icon border-icon-rt"></div>
          <div class="border-icon border-icon-rb"></div>
          <div class="border-line"></div>
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/jinhua2/icon-pingtai.png"
                alt=""
              />
              <span>{{this.year}}年患者分析</span>
            </div>
          </div>
          <div class="charts-item">
            <div class="chart-line" style="width:100%;height:250px">
              <chart-item :option="patientNumByOldOption"></chart-item>
            </div>
          </div>
          <div class="charts-item charts-item-flex charts-item-bt">
            <div class="chart-flex">
              <div class="chart-pie" style="width:100%;height:233px">
                <chart-item :option="patientRatioByClassOption"></chart-item>
              </div>
            </div>
            <div class="chart-flex">
              <div class="chart-pie" style="width:100%;height:233px">
                <chart-item :option="patientRatioBySexOption"></chart-item>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="charts-section w560 h970">
        <div class="border-icon border-icon-lt"></div>
        <div class="border-icon border-icon-lb"></div>
        <div class="border-icon border-icon-rt"></div>
        <div class="border-icon border-icon-rb"></div>
        <div class="border-line"></div>
        <div class="charts-item">
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/jinhua2/icon-jclqs.png"
                alt=""
              />
              <span>{{this.year}}年检查量趋势</span>
            </div>
          </div>
          <div class="chart-line" style="width:100%;height:260px">
            <chart-item
              :option="examNumByMonthOption"
              v-show="examNumByMonthOption"
            ></chart-item>
          </div>
        </div>
        <div class="charts-item charts-item-bt">
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/jinhua2/icon-cclqs.png"
                alt=""
              />
              <span>{{this.year}}年存储量趋势</span>
            </div>
          </div>
          <div class="chart-line" style="width:100%;height:260px">
            <chart-item
              :option="storageTotalByMonthOption"
              v-show="storageTotalByMonthOption"
            ></chart-item>
          </div>
        </div>
        <div class="charts-item charts-item-bt">
          <div class="charts-header">
            <div class="charts-header-content">
              <img
                class="charts-header-icon"
                src="@/assets/images/dataCockpit/jinhua2/icon-dylqs.png"
                alt=""
              />
              <span>{{this.year}}年调阅量趋势</span>
            </div>
          </div>
          <div class="chart-line" style="width:100%;height:260px">
            <chart-item
              :option="viewNumByMonthOption"
              v-show="viewNumByMonthOption"
            ></chart-item>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import * as echarts from "echarts";
import ChartItem from "@/components/dataCockpit/ChartItem.vue";
import PageTitle from "@/components/dataCockpit/PageTitle.vue";
import UpdateData from '@/components/dataCockpit/UpdateData.vue'
import utils from "@/utils/PIScommonMethod";
import Mgr from "@/utils/SecurityService";
import {
  getExamNum,
  getStorageTotal,
  getViewNum,
  getSummary,
  getOrgDistribute,
  getPositiveRatio,
  getPatientNumByOld,
  getPatientRatioByClass,
  getPatientRatioBySex,
  getExamNumByMonth,
  getStorageTotalByMonth,
  getViewNumByMonth
} from "@/api/dataCockpit/jinhua/index2";
import {
  getPageTitle,
  updatePageTitle
} from "@/api/dataCockpit/jinhua/index"
export default {
  components: { ChartItem, PageTitle, UpdateData },
  data() {
    return {
      isDev: false,
      title: '',
      pageName: '',
      defaultTitle: '金华市区域云影像智慧医疗平台医院驾驶舱',
      tenancy_id: "",
      baseParams: null,
      updateTime: "",
      // 双y轴柱状图图表共享使用的option
      barDoubleYOption: {
        grid: {
          left: 160,
          right: 100,
          bottom: "5%",
          top: "5%"
        },
        xAxis: {
          show: false,
          type: "value"
        },
        yAxis: [
          {
            type: "category",
            inverse: true,
            axisLabel: {
              show: true,
              color: "#00D3FF",
              width: 140,
              overflow: "break",
              margin: 10,
              fontSize: "15"
            },
            splitLine: {
              show: false
            },
            axisTick: {
              show: false
            },
            axisLine: {
              show: false
            },
            data: []
          },
          {
            type: "category",
            inverse: true,
            axisTick: "none",
            axisLine: "none",
            show: true,
            axisLabel: {
              color: "#00D3FF",
              fontSize: "15",
              width: 80,
              overflow: "break"
            },
            data: []
          }
        ],
        series: [
          {
            name: "值",
            type: "bar",
            zlevel: 1,
            barWidth: 16,
            itemStyle: {
              borderRadius: [0, 20, 20, 0],
              color: ""
            },
            data: []
          },
          {
            name: "背景",
            type: "bar",
            barWidth: 16,
            barGap: "-100%",
            data: [],
            itemStyle: {
              color: "rgba(24,31,68,1)",
              borderRadius: [0, 20, 20, 0]
            }
          }
        ]
      },
      // 年度检查量分布 TOP6 数据源
      examNumList: [],
      // 存储量分布情况
      storageTotalList: [],
      // 调阅量分布情况
      viewNumList: [],
      // 平台概览
      summaryInfo: {},
      // 机构地图分布
      orgDistributeInfo: {},
      // 阳性率
      positiveRatio: null,
      // 年龄分布
      patientNumByOldList: [],
      // 饼图共享option
      pieSharedOption: {
        title: {
          text: "",
          textStyle: {
            color: "#fff",
            fontSize: 16,
            fontWeight: "bold"
          },
          left: 10,
          top: 10
        },
        tooltip: {},
        legend: {
          top: "85%",
          textStyle: {
            color: "#00d3ff"
          },
          itemWidth: 12,
          itemHeight: 12,
          padding: [0, 0, 0, 0],
          itemGap: 2
        },
        series: [
          {
            type: "pie",
            radius: ["25%", "50%"],
            label: {
              formatter: "{c}%",
              color: "#00D3FF",
              fontSize: 14
            },
            center: ["50%", "50%"],
            data: []
          }
        ]
      },
      // 患者类别分布图表数据源
      patientRatioByClassList: [],
      // 患者性别分布图表数据源
      patientRatioBySexList: [],
      // 折线图共享optoin
      lineSharedOption: {
        title: {
          text: "",
          textStyle: {
            color: "#fff",
            fontSize: 16
          },
          top: 10,
          left: "5%"
        },
        grid: {
          top: "20%",
          left: "1%",
          right: "1%",
          bottom: "0%",
          containLabel: true
        },
        xAxis: {
          type: "category",
          axisLine: {
            //坐标轴轴线相关设置。数学上的x轴
            show: true,
            lineStyle: {
              color: "#00D3FF"
            }
          },
          axisLabel: {
            //坐标轴刻度标签的相关设置
            textStyle: {
              color: "#00D3FF",
              margin: 15
            }
          },
          axisTick: {
            show: false
          },
          data: []
        },
        yAxis: {
          type: "value",
          min: 0,
          // max: 140,
          splitNumber: 7,
          splitLine: {
            show: true,
            lineStyle: {
              color: "#00D3FF",
              type: "dashed",
              opacity: 0.3
            }
          },
          axisLine: {
            show: false
          },
          axisLabel: {
            textStyle: {
              color: "#00D3FF"
            }
          },
          axisTick: {
            show: false
          }
        },
        series: [
          {
            type: "line",
            smooth: true, //是否平滑曲线显示
            symbol: "emptyCircle",
            symbolSize: 6,
            lineStyle: {
              color: "#4992ff" // 线条颜色
            },
            label: {
              show: true,
              position: "top",
              textStyle: {
                color: "#00D3FF"
              }
            },
            itemStyle: {
              color: "#4992ff"
            },
            tooltip: {
              show: false
            },
            areaStyle: {
              //区域填充样式
              //线性渐变，前4个参数分别是x0,y0,x2,y2(范围0~1);相当于图形包围盒中的百分比。如果最后一个参数是‘true’，则该四个值是绝对像素位置。
              color: new echarts.graphic.LinearGradient(
                0,
                0,
                0,
                1,
                [
                  {
                    offset: 0,
                    color: "rgba(73,146,255,0.2)"
                  },
                  {
                    offset: 1,
                    color: "rgba(73,146,255,0)"
                  }
                ],
                false
              )
            },
            data: [100, 120, 110, 60, 70, 130, 150]
          },
          {
            type: "line",
            smooth: true, //是否平滑曲线显示
            symbol: "emptyCircle",
            symbolSize: 6,
            lineStyle: {
              color: "#4992ff" // 线条颜色
            },
            label: {
              show: true,
              position: "top",
              textStyle: {
                color: "#00D3FF"
              }
            },
            itemStyle: {
              color: "#4992ff"
            },
            tooltip: {
              show: false
            },
            areaStyle: {
              //区域填充样式
              //线性渐变，前4个参数分别是x0,y0,x2,y2(范围0~1);相当于图形包围盒中的百分比。如果最后一个参数是‘true’，则该四个值是绝对像素位置。
              color: new echarts.graphic.LinearGradient(
                0,
                0,
                0,
                1,
                [
                  {
                    offset: 0,
                    color: "rgba(73,146,255,0.2)"
                  },
                  {
                    offset: 1,
                    color: "rgba(73,146,255,0)"
                  }
                ],
                false
              )
            },
            data: []
          }
        ]
      },
      // 检查量趋势图表数据源
      examNumByMonthList: [],
      // 存储量趋势图表数据源
      storageTotalByMonthList: [],
      // 调阅量趋势图表数据源
      viewNumByMonthList: []
    };
  },
  computed: {
    ...mapGetters(['year']),
    // 年度检查量分布 图表option
    examNumOption() {
      let option = null;
      const list = this.examNumList;
      if (list.length === 0) {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.barDoubleYOption));
      const category = list.map(x => x.org_name);
      const data = list.map(x => x.exam_num);
      const maxValue = list[0].exam_num;
      const maxData = new Array(list.length).fill(maxValue);
      option.yAxis[0].data = category;
      option.yAxis[1].data = data;
      option.series[0].data = data;
      option.series[1].data = maxData;
      option.series[0].itemStyle.color = new echarts.graphic.LinearGradient(
        0,
        0,
        1,
        0,
        [
          {
            offset: 0,
            color: "#93BAFB"
          },
          {
            offset: 1,
            color: "#6298F4"
          }
        ]
      );
      return option;
    },
    // 存储量分布情况 图表option
    storageTotalOption() {
      let option = null;
      const list = this.storageTotalList;
      if (list.length === 0) {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.barDoubleYOption));
      const category = list.map(x => x.org_name);
      const data = list.map(x => x.storage_total);
      const maxValue = list[0].storage_total;
      const maxData = new Array(list.length).fill(maxValue);
      option.yAxis[0].data = category;
      option.yAxis[1].data = data;
      option.series[0].data = data;
      option.series[1].data = maxData;
      option.series[0].itemStyle.color = new echarts.graphic.LinearGradient(
        0,
        0,
        1,
        0,
        [
          {
            offset: 0,
            color: "#20C88E"
          },
          {
            offset: 1,
            color: "#19A576"
          }
        ]
      );
      return option;
    },
    // 调阅量分布情况 图表option
    viewNumOption() {
      let option = null;
      const list = this.viewNumList;
      if (list.length === 0) {
        return option;
      }
      option = JSON.parse(JSON.stringify(this.barDoubleYOption));
      const category = list.map(x => x.org_name);
      const data = list.map(x => x.view_num);
      const maxValue = list[0].view_num;
      const maxData = new Array(list.length).fill(maxValue);
      option.yAxis[0].data = category;
      option.yAxis[1].data = data;
      option.series[0].data = data;
      option.series[1].data = maxData;
      option.series[0].itemStyle.color = new echarts.graphic.LinearGradient(
        0,
        0,
        1,
        0,
        [
          {
            offset: 0,
            color: "#FDAB13"
          },
          {
            offset: 1,
            color: "#F19D00"
          }
        ]
      );
      return option;
    },
    // 阳性率
    positiveRatioOption() {
      let option = null;
      const value = this.positiveRatio;
      if (value === null) {
        return option;
      }
      option = {
        title: [
          {
            text: "{a|阳性率}\n{b|" + value + "%}",
            show: true,
            x: "center",
            y: "center",
            textStyle: {
              rich: {
                a: {
                  fontSize: 14,
                  color: "#fff",
                  padding: [0, 0, 15, 0]
                },
                b: {
                  fontSize: 24,
                  color: "#fff",
                  fontFamily: "alibabaPuhuiM"
                }
              }
            }
          }
        ],
        polar: {
          center: ["50%", "50%"],
          radius: ["60%", "75%"]
        },
        angleAxis: {
          max: 100,
          show: false
        },
        radiusAxis: {
          type: "category",
          show: true,
          axisLabel: {
            show: false
          },
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          }
        },
        series: [
          {
            name: "",
            type: "bar",
            roundCap: true,
            showBackground: true,
            backgroundStyle: {
              color: "rgba(19, 84, 146, .4)"
            },
            data: [value],
            coordinateSystem: "polar",
            itemStyle: {
              normal: {
                color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
                  {
                    offset: 0,
                    color: "#E8684A"
                  },
                  {
                    offset: 1,
                    color: "#FF702B"
                  }
                ])
              }
            }
          },
          {
            name: "",
            type: "gauge",
            radius: "54%",
            axisLine: {
              lineStyle: {
                color: [
                  [
                    1,
                    new echarts.graphic.LinearGradient(0, 1, 0, 0, [
                      {
                        offset: 0,
                        color: "rgba(0, 182, 253, 0)"
                      },
                      {
                        offset: 0.5,
                        color: "rgba(0, 182, 253, .2)"
                      },
                      {
                        offset: 1,
                        color: "rgba(0, 182, 253, .4)"
                      }
                    ])
                  ]
                ],
                width: 1
              }
            },
            axisLabel: {
              show: false
            },
            axisTick: {
              show: false
            },
            splitLine: {
              show: false
            },
            itemStyle: {
              show: false
            },
            detail: {
              show: false
            },
            data: [],
            pointer: {
              show: false
            }
          }
        ]
      };
      return option;
    },
    // 年龄分布
    patientNumByOldOption() {
      let option = null;
      const list = this.patientNumByOldList;
      if (list.length === 0) {
        return option;
      }
      const mellcolor = [
        "#BF3DD1",
        "#008A5D",
        "#2563F7",
        "#017CFF",
        "#FF702B",
        "#FF555E"
      ];
      const mellcolor2 = [
        "#FB77ED",
        "#19A576",
        "#2489F7",
        "#1CBBFB",
        "#FDBC0C",
        "#FF6E76"
      ];
      let xAxisData = [];
      const yAxisData = [];
      xAxisData = list.map(x => x.old_type);
      xAxisData = xAxisData.sort((x, y) => {
        return parseInt(x) - parseInt(y);
      });
      xAxisData.forEach(x => {
        const idx = list.findIndex(item => item.old_type === x);
        const value = list[idx].num;
        yAxisData.push(value);
      });
      option = {
        title: {
          text: "{a|患者年龄分布}{b|（单位：人次/岁）}",

          textStyle: {
              rich: {
                a: {
                  fontSize: 16,
                  color: "#fff",
                  fontWeight: "bold"
                },
                b: {
                  fontSize: 12,
                  color: "#ccc",
                }
              }
            },
          left: 10,
          top: 10
        },
        grid: {
          top: "20%",
          right: "3%",
          left: "8%",
          bottom: "8%"
        },
        xAxis: [
          {
            type: "category",
            color: "#59588D",
            data: xAxisData,
            axisPointer: {
              type: "line"
            },
            axisLine: {},
            axisTick: {
              show: false
            },
            axisLabel: {
              margin: 10,
              color: "#00D3FF",
              fontSize: 12
            }
          }
        ],
        yAxis: [
          {
            axisLabel: {
              color: "#00D3FF"
            },
            axisLine: {
              show: false
            },
            axisTick: {
              show: false
            },
            splitLine: {
              lineStyle: {
                type: "dashed",
                color: "#00D3FF",
                opacity: 0.3
              }
            }
          }
        ],
        series: [
          {
            type: "bar",
            data: yAxisData,
            barWidth: "15px",
            itemStyle: {
              color: function(params) {
                return new echarts.graphic.LinearGradient(
                  0,
                  0,
                  0,
                  1,
                  [
                    {
                      offset: 0,
                      color: mellcolor2[params.dataIndex], // 0% 处的颜色
                      opacity: 0.1
                    },
                    {
                      offset: 1,
                      color: mellcolor[params.dataIndex] // 100% 处的颜色
                    }
                  ],
                  false
                );
              },
              borderRadius: [30, 30, 0, 0]
            },
            label: {
              show: true,
              lineHeight: 20,
              height: 20,
              backgroundColor: "#1e61c2",
              borderRadius: 20,
              position: ["-8", "-38"],
              distance: 1,
              formatter: ["  {d|●}", " {a|{c}人}  \n", "    {b|}"].join(""),
              rich: {
                d: {
                  color: "#3CDDCF"
                },
                a: {
                  color: "#fff",
                  align: "center"
                },
                b: {
                  width: 1,
                  height: 15,
                  borderWidth: 1,
                  borderColor: "#2f6fcd",
                  align: "left"
                }
              }
            }
          }
        ]
      };
      return option;
    },
    // 类别分布
    patientRatioByClassOption() {
      let option = null;
      const list = this.patientRatioByClassList;
      if (list.length === 0) {
        return option;
      }
      const data = [];
      list.forEach(item => {
        const obj = {};
        obj.name = item.patient_class;
        obj.value = item.ratio;
        data.push(obj);
      });
      option = JSON.parse(JSON.stringify(this.pieSharedOption));
      option.tooltip.formatter = function(params) {
        let string = `${params.marker}${params.name}：${params.percent}%`;
        return string;
      };
      option.title.text = "患者类别分布";
      option.series[0].data = data;
      return option;
    },
    // 性别分布
    patientRatioBySexOption() {
      let option = null;
      const list = this.patientRatioBySexList;
      if (list.length === 0) {
        return option;
      }
      const data = [];
      list.forEach(item => {
        const obj = {};
        obj.name = item.patient_sex;
        obj.value = item.ratio;
        data.push(obj);
      });
      option = JSON.parse(JSON.stringify(this.pieSharedOption));
      option.tooltip.formatter = function(params) {
        let string = `${params.marker}${params.name}：${params.percent}%`;
        return string;
      };
      option.title.text = "患者性别分布";
      option.series[0].data = data;
      return option;
    },
    // 检查量趋势
    examNumByMonthOption() {
      let option = null;
      const list = this.examNumByMonthList;
      if (list.length === 0) {
        return option;
      }
      const xAxisOption = list.map(x => x.month + "月");
      const yAxisOption = list.map(x => x.exam_num);
      const total = yAxisOption.reduce((x, y) => x + y);
      option = JSON.parse(JSON.stringify(this.lineSharedOption));
      option.title.text = `检查总量：${total}（人次）`;
      option.xAxis.data = xAxisOption;
      option.series[0].data = yAxisOption;
      option.series[0].lineStyle.color = "#4992ff";
      option.series[0].itemStyle.color = "#4992ff";
      option.series[0].areaStyle.color = new echarts.graphic.LinearGradient(
        0,
        0,
        0,
        1,
        [
          {
            offset: 0,
            color: "rgba(73,146,255,0.2)"
          },
          {
            offset: 1,
            color: "rgba(73,146,255,0.05)"
          }
        ],
        false
      );
      return option;
    },
    // 存储量趋势
    storageTotalByMonthOption() {
      let option = null;
      const list = this.storageTotalByMonthList;
      if (list.length === 0) {
        return option;
      }
      const xAxisOption = list.map(x => x.month + "月");
      const yAxisOption = list.map(x => x.storage_total);
      const total = yAxisOption.reduce((x, y) => x + y).toFixed(2);
      option = JSON.parse(JSON.stringify(this.lineSharedOption));
      option.title.text = `存储总量：${total}（TB）`;
      option.xAxis.data = xAxisOption;
      option.series[0].data = yAxisOption;
      option.series[0].lineStyle.color = "#369D54";
      option.series[0].itemStyle.color = "#369D54";
      option.series[0].areaStyle.color = new echarts.graphic.LinearGradient(
        0,
        0,
        0,
        1,
        [
          {
            offset: 0,
            color: "rgba(54,157,84,0.2)"
          },
          {
            offset: 1,
            color: "rgba(54,157,84,0.05)"
          }
        ],
        false
      );
      return option;
    },
    // 调阅量趋势
    viewNumByMonthOption() {
      let option = null;
      const list = this.viewNumByMonthList;
      if (list.length === 0) {
        return option;
      }
      const xData = Array.from(new Set(list.map(x => x.month)));
      const xAxisOption = Array.from(new Set(list.map(x => x.month + "月")));
      const yData1 = list.filter(item => item.user_type === '医生');
      const yData2 = list.filter(item => item.user_type === '患者');
      let yAxisOption1 = []
      let yAxisOption2 = []
      xData.forEach(item => {
        const idx1 = yData1.findIndex( y => y.month === item)
        const idx2 = yData2.findIndex( y => y.month === item)
        const y1 = idx1 === -1?0: yData1[idx1].view_num
        const y2 = idx2 === -1?0: yData2[idx2].view_num
        yAxisOption1.push(y1)
        yAxisOption2.push(y2)
      })
      const total = yAxisOption1.reduce((x, y) => x + y) + yAxisOption2.reduce((x, y) => x + y);
      option = JSON.parse(JSON.stringify(this.lineSharedOption));
      option.title.text = `调阅总量：${total}（人次）`;
      option.legend = {
        data: ['医生', '患者'],
        top: 10,
        textStyle: {
          color: '#00D3FF'
        }
      }
      option.xAxis.data = xAxisOption;
      option.series[0].name = '医生';
      option.series[0].data = yAxisOption1;
      option.series[0].lineStyle.color = "#F6BD16";
      option.series[0].itemStyle.color = "#F6BD16";
      option.series[0].areaStyle.color = new echarts.graphic.LinearGradient(
        0,
        0,
        0,
        1,
        [
          {
            offset: 0,
            color: "rgba(246,189,22,0.2)"
          },
          {
            offset: 1,
            color: "rgba(246,189,22,0.05)"
          }
        ],
        false
      );
      option.series[1].name = '患者';
      option.series[1].data = yAxisOption2;
      option.series[1].lineStyle.color = "#4992ff";
      option.series[1].itemStyle.color = "#4992ff";
      option.series[1].areaStyle.color = new echarts.graphic.LinearGradient(
        0,
        0,
        0,
        1,
        [
          {
            offset: 0,
            color: "rgba(73,146,255,0.2)"
          },
          {
            offset: 1,
            color: "rgba(73,146,255,0.05)"
          }
        ],
        false
      );
      return option;
    }
  },
  mounted() {
    this.pageName = this.$route.name
    this.getPageTitle()
    this.initRequest();
  },
  methods: {
    // 更新数据
    updateData() {
      this.initRequest();
    },
    // 查询页面标题
    getPageTitle() {
      const params = {
        title_flag: this.pageName
      }
      getPageTitle(params).then(res => {
        if(res.code === 0) {
          if(res.data.title_name) {
            this.title = res.data.title_name
          }else {
            this.title = this.defaultTitle
          }
        }else {
          this.title = this.defaultTitle
        }
      }).catch(() => {
          this.title = this.defaultTitle
      })
    },
    // 修改页面标题
    updateTitle(title) {
      if(title !== this.title) {
        const params = {
          title_flag: this.pageName,
          title_name: title
        }
        updatePageTitle(params).then(res => {
          if(res.code === 0) {
            this.title = title
          }else {
            this.$message.error(res.msg)
          }
        })
      }
    },
    // 获取api请求的统一参数 客戶id
    getBaseParams() {
      return new Promise((resolve, reject) => {
        // 客戶ID
        // var manager = new Mgr();
        // manager.getRole().then(item => {
        //   if (item) {
        //     this.tenancy_id = item.profile.tenancy_id;
        //     this.baseParams = {
        //       tenancy_id: this.isDev
        //         ? "0"
        //         : item.profile.tenancy_id
        //     };
        //     resolve();
        //   } else {
        //     reject();
        //   }
        // });

        if (this.$route.query.tenancy_id) {
          this.tenancy_id = this.$route.query.tenancy_id
          this.baseParams = {
            tenancy_id: this.isDev
              ? "0"
              : item.profile.tenancy_id
          };
          resolve();
        } else {
          reject();
        }
      });
    },
    async initRequest() {
      const _date = new Date();
      this.updateTime = utils.dateFormat(_date, 1);
      await this.getBaseParams();
      this.getExamNum();
      this.getStorageTotal();
      this.getViewNum();
      this.getSummary();
      this.getOrgDistribute();
      this.getPositiveRatio();
      this.getPatientNumByOld();
      this.getPatientRatioByClass();
      this.getPatientRatioBySex();
      this.getExamNumByMonth();
      this.getStorageTotalByMonth();
      this.getViewNumByMonth();
    },
    // 年度检查量分布
    getExamNum() {
      const data = this.baseParams;
      getExamNum(data).then(res => {
        if (res.code === 0) {
          this.examNumList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 存储量分布情况
    getStorageTotal() {
      const data = this.baseParams;
      getStorageTotal(data).then(res => {
        if (res.code === 0) {
          this.storageTotalList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 调阅量分布情况
    getViewNum() {
      const data = this.baseParams;
      getViewNum(data).then(res => {
        if (res.code === 0) {
          this.viewNumList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 平台概览
    getSummary() {
      const data = this.baseParams;
      getSummary(data).then(res => {
        if (res.code === 0) {
          this.summaryInfo = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 机构地图分布
    getOrgDistribute() {
      const data = this.baseParams;
      getOrgDistribute(data).then(res => {
        if (res.code === 0) {
          this.orgDistributeInfo = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 阳性率
    getPositiveRatio() {
      const data = this.baseParams;
      getPositiveRatio(data).then(res => {
        if (res.code === 0) {
          this.positiveRatio = res.data.ratio;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 年龄分布
    getPatientNumByOld() {
      const data = this.baseParams;
      getPatientNumByOld(data).then(res => {
        if (res.code === 0) {
          this.patientNumByOldList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 患者类别分布
    getPatientRatioByClass() {
      const data = this.baseParams;
      getPatientRatioByClass(data).then(res => {
        if (res.code === 0) {
          this.patientRatioByClassList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 患者性别分布
    getPatientRatioBySex() {
      const data = this.baseParams;
      getPatientRatioBySex(data).then(res => {
        if (res.code === 0) {
          this.patientRatioBySexList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 检查量趋势
    getExamNumByMonth() {
      const data = this.baseParams;
      getExamNumByMonth(data).then(res => {
        if (res.code === 0) {
          this.examNumByMonthList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 存储量趋势
    getStorageTotalByMonth() {
      const data = this.baseParams;
      getStorageTotalByMonth(data).then(res => {
        if (res.code === 0) {
          this.storageTotalByMonthList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    // 调阅量趋势
    getViewNumByMonth() {
      const data = this.baseParams;
      getViewNumByMonth(data).then(res => {
        if (res.code === 0) {
          // if(res.data.length === 0) {
          //   res.data = [
          //     {
          //       month: '1',
          //       view_num: 100,
          //       user_type: '医生'
          //     },
          //     {
          //       month: '2',
          //       view_num: 100,
          //       user_type: '医生'
          //     },
          //     {
          //       month: '3',
          //       view_num: 100,
          //       user_type: '医生'
          //     },
          //     {
          //       month: '1',
          //       view_num: 500,
          //       user_type: '患者'
          //     },
          //     {
          //       month: '2',
          //       view_num: 200,
          //       user_type: '患者'
          //     }
          //   ]
          // }
          this.viewNumByMonthList = res.data;
        } else {
          this.$message.error(res.msg);
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
.w145 {
  width: 145px;
}
.w300 {
  width: 300px;
}
.w560 {
  width: 560px;
}
.w750 {
  width: 750px;
}
.h420 {
  height: 420px;
}
.h540 {
  height: 540px;
}
.h970 {
  height: 970px;
}
.col-hz {
  color: #f6bd16;
}
.col-jc {
  color: #6298f4;
}
.col-cc {
  color: #5ad8a6;
}
.col-dy {
  color: #ff7100;
}

.container-bg {
  width: 1920px;
  height: 1080px;
  background: url("~@/assets/images/dataCockpit/jinhua2/bg.png");
}
.header-content {
  width: 100%;
  height: 76px;
  position: relative;
  padding: 0 20px;
  display: flex;
  justify-content: flex-end;
  align-items: flex-end;
  background: url("~@/assets/images/dataCockpit/jinhua2/header_bg.png");
  ::v-deep .title {
    width: 680px;
    font-size: 32px;
    line-height: 76px;
    color: #00d3ff;
    font-weight: 700;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    text-align: center;
    letter-spacing: 3px;
    cursor: pointer;
  }
}
.section-container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.time {
  color: #00d3ff;
  font-size: 16px;
  padding: 5px 0;
  display: flex;
  align-items: center;
}
.flex-content {
  margin: 0 10px;
  height: 270px;
  display: flex;
}
.flex-item {
  flex: 1;
}
.card-map {
  width: 303px;
  height: 270px;
  background: url("~@/assets/images/dataCockpit/jinhua2/map.png")  0 -10px no-repeat;
  margin: auto;
}
.card-jg {
  width: 364px;
  height: 54px;
  background: url("~@/assets/images/dataCockpit/jinhua2/card-jg.png");
}
.card-content {
  height: 54px;
  font-size: 20px;
  color: #fff;
  margin-left: 66px;
  line-height: 50px;
}
.span-data {
  font-size: 26px;
  color: #4992ff;
}
.charts {
  &-container {
    margin: 15px;
    display: flex;
    justify-content: space-between;
  }
  &-section {
    border: 1px solid rgba(106, 127, 197, 0.7);
    border-radius: 4px;
    position: relative;
    background: rgba(18, 20, 64, 0.6);
  }
  &-header {
    height: 45px;
    padding: 0 10px;
    color: #00d3ff;
    font-size: 20px;
    font-weight: bold;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: rgba(6, 26, 77, 0.9);
    &-content {
      display: flex;
      align-items: center;
    }
    &-icon {
      width: 20px;
      height: 20px;
      margin-right: 10px;
    }
    &-tip {
      float: right;
      color: #fff;
      font-size: 16px;
      line-height: 45px;
      font-weight: normal;
    }
  }
  &-item {
    overflow: hidden;
    & + & {
      margin-top: 10px;
    }
    &-bt {
      border-top: 1px dashed #4c5d94;
    }
    &-nopadding {
      padding: 0;
    }
    &-flex {
      display: flex;
      justify-content: space-between;
      align-items: center;
      &-colu {
        flex-direction: column;
      }
    }
  }
  &-content {
    overflow: hidden;
  }
  &-title {
    color: #fff;
    font-size: 16px;
    font-weight: bold;
    margin: 10px 0;
    overflow: hidden;
    &-flex {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    &-item {
      flex: 1;
    }
    &-small {
      font-size: 15px;
    }
  }
  &-tab {
    float: right;
    display: flex;
    font-size: 14px;
    color: #409eff;
    border: 1px solid #409eff;
    border-radius: 3px;
    font-weight: normal;
    &-item {
      padding: 4px 15px;
      cursor: pointer;
      &-selected {
        background: #409eff;
        color: #fff;
      }
    }
  }
  &-icons {
    width: 100%;
    padding: 20px 0;
    display: flex;
    justify-content: space-around;
    align-items: center;
    border-bottom: 1px dashed #4c5d94;
  }
  &-icon {
    height: 56px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    &-data {
      font-size: 36px;
      height: 36px;
      line-height: 36px;
    }
    &-text {
      font-size: 16px;
      color: #fff;
    }
    &-number {
      height: 36px;
      line-height: 36px;
      margin-right: 5px;
      display: inline-block;
    }
    &-content {
      margin-left: 10px;
    }
  }
  &-sideNav {
    width: 120px;
    height: 256px;
    float: left;
    margin-top: 10px;
    overflow-y: auto;
    &-item {
      width: 100%;
      padding: 0 10px;
      height: 32px;
      line-height: 32px;
      color: #00d3ff;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: pointer;
      &-selected {
        color: #fff;
        background: #4e52aa;
        border-radius: 3px;
      }
    }
  }
  &-nav {
    width: 110px;
    text-align: center;
    cursor: pointer;
    &-selected {
      color: #409eff;
      border-bottom: 3px solid #409eff;
    }
  }
  &-navbar {
    display: flex;
    height: 44px;
    line-height: 44px;
    &-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 45px;
      padding: 0 15px;
      color: #00d3ff;
      font-size: 20px;
      font-weight: bold;
      border-bottom: 1px solid #515f98;
      background: rgba(6, 26, 77, 0.9);
    }
  }
  &-thead {
    width: 100%;
    padding: 15px 15px 0;
    color: #fff;
    display: flex;
  }
  &-cards {
    display: flex;
    justify-content: space-between;
    margin: 10px;
  }
  &-card {
    width: 175px;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: url("~@/assets/images/dataCockpit/jinhua2/card-bg.png");
    &-title {
      font-size: 15px;
      color: #fff;
      margin-bottom: 5px;
    }
    &-data {
      font-size: 32px;
      font-family: "Arial";
      font-weight: bold;
      color: #fff;
    }
  }
}
.border-line {
  width: 330px;
  height: 1px;
  background: url("~@/assets/images/dataCockpit/jinhua2/line.png");
  position: absolute;
  top: -1px;
  left: 0;
  right: 0;
  margin: 0 auto;
}
.border-icon {
  width: 16px;
  height: 16px;
  position: absolute;
  &-lt {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-lt.png");
    top: -1px;
    left: -1px;
  }
  &-lb {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-lb.png");
    bottom: -1px;
    left: -1px;
  }
  &-rt {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-rt.png");
    top: -1px;
    right: -1px;
  }
  &-rb {
    background: url("~@/assets/images/dataCockpit/jinhua2/border-rb.png");
    right: -1px;
    bottom: -1px;
  }
}
.chart {
  &-flex {
    flex: 1;
    & + & {
      border-left: 1px dashed #4c5d94;
    }
  }
}
</style>
