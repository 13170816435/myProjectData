<template>
  <div class="userinfo">
    <div class="userinfo-title">
      <span class="userinfo-titleinfo">{{ pacsinfo.title }}</span>
      <span
        @click="closeFn"
        class="close-btn iconfont iconchuangjianshibai"
      ></span>
    </div>
    <el-form
      :model="pacsinfo.formInfo"
      ref="formInfo"
      label-width="120px"
      class="demo-ruleForm"
    >
      <div class="contaner">
        <div class="contaner-info">
          <el-row class="contaner-info-title">
            <span class="border-left"></span>基本信息
          </el-row>
          <el-row class="mt20 pl10 pr10">
            <el-form-item label="授权产品 ：" v-if="pacsinfo.product_name">
              <div>{{ pacsinfo.product_name }}</div>
            </el-form-item>
            <el-form-item v-else label="授权产品 ：">
              <span class="system_type active">检查预约</span>
            </el-form-item>
            <el-form-item class="mt15" label="系统名称 ：">
              <el-input
                v-model="pacsinfo.formInfo.name"
                placeholder="请输入系统名称"
                style="width: 480px"
              ></el-input>
            </el-form-item>
            <el-form-item class="mt15" label="系统管理员 ：">
              <el-input
                v-model="pacsinfo.formInfo.admin_phone"
                @input="changePhone"
                placeholder="请输入管理员电话"
                @blur="getAdminNameFn"
                style="width: 236px"
              ></el-input>
              <el-input
                v-model="pacsinfo.formInfo.admin_name"
                placeholder="请输入管理员姓名"
                :disabled="pacsinfo.isAdminname"
                class="ml10"
                style="width: 236px"
              ></el-input>
            </el-form-item>
            <weChat
              :weChatObj="pacsinfo.providersObj"
              :inputWidth="'236px'"
            ></weChat>
          </el-row>
        </div>
        <div
          class="contaner-info contaner-bottom"
          v-if="pacsinfo.formInfo.type === 1 || pacsinfo.formInfo.type === 4"
        >
          <el-row class="contaner-info-title instituteInfor">
            <el-col :span="12">
              <span class="border-left"></span>使用机构数量
              <span class="ml5 clr_oarange" v-if="pacsinfo.institution_count"
                >({{ pacsinfo.institution_count }}家)</span
              >
            </el-col>
            <el-col :span="12" class="tr clr_0a">
              <span class="function-btn bg_e6 clr_ff" @click="isAddInstution">
                <i class="iconfont iconxinzeng"></i>添加机构
              </span>
            </el-col>
          </el-row>
          <div
            class="contaner-info-list"
            v-if="pacsinfo.multipleSelection.length > 0"
          >
            <div class="contaner-info-list-item clr_999">
              <div class="width_60">操作</div>
              <div class="width_300">机构名称</div>
            </div>
            <div
              class="contaner-info-list-item"
              v-for="(item, index) in pacsinfo.multipleSelection"
              :key="index"
            >
              <div class="width_60">
                <span
                  @click="delInstitutionFn(item.id)"
                  class="icon-btn bg_f5"
                  type="text"
                  size="small"
                  title="删除"
                  ><i class="iconfont icondongjie"></i
                ></span>
              </div>
              <div class="width_300">{{ item.name }}</div>
            </div>
          </div>
        </div>
      </div>
      <div class="mt15">
        <el-button
          type="primary"
          size="medium"
          @click="submitForm('formInfo', 'commit')"
          >提交</el-button
        >
        <el-button size="medium" plain @click="submitForm('formInfo')"
          >取消</el-button
        >
      </div>
    </el-form>
    <el-dialog
      title="选择机构"
      :append-to-body="true"
      :visible.sync="pacsinfo.isChioseOrgan"
      width="900px"
      v-dialogDrag
      :before-close="instclose"
    >
      <div class="CAdialog">
        <div>
          <el-input
            :value="pacsinfo.serchName"
            @input="getSerchName"
            placeholder="机构名称"
            style="width: 240px"
          ></el-input>
          <el-button
            type="primary"
            size="small"
            class="ml10"
            @click="serchListFn"
            >查询</el-button
          >
        </div>
        <el-table
          ref="institutions"
          class="mt10 instituteTable"
          border
          v-bind:class="{ noTableData: pacsinfo.institutionList.length == 0 }"
          :data="pacsinfo.institutionList"
          :header-cell-style="{ background: '#DCDFE6', color: '#1E1D22' }"
          style="width: 100%"
          :row-key="getRowKeys"
          @select="selectCurRow"
          @selection-change="handleSelectionChange"
        >
          <el-table-column
            type="selection"
            width="55"
            :reserve-selection="true"
          ></el-table-column>
          <el-table-column
            prop="name"
            label="机构名称"
            width="250"
          ></el-table-column>
          <el-table-column
            prop="admin_name"
            label="联系人"
            width="100"
          ></el-table-column>
          <el-table-column
            prop="admin_phone"
            label="联系电话"
          ></el-table-column>
        </el-table>
        <div class="blockPage">
          <pagination-tool
            :layout="pageLayout"
            :total="pageInfo.total_count"
            :page.sync="pageInfo.page_index"
            :limit.sync="pageInfo.page_size"
            @pagination="pageSizeChangeFn"
          />
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" plain @click="pacsinfo.isChioseOrgan = false"
          >取 消</el-button
        >
        <el-button type="primary" size="small" @click="ChoiceOrganFn('commit')"
          >确定</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>
<script>
import weChat from "@/components/common/weChat";
import PaginationTool from "@/components/common/PaginationTool";
export default {
  components: {
    PaginationTool,
    weChat,
  },
  props: {
    pacsinfo: Object,
    pageInfo: Object,
  },
  data() {
    return {
      pageLayout: "total, prev, pager, next, jumper",
    };
  },
  methods: {
    closeFn() {
      this.$emit("closeFn");
    },
    changePhone() {
      this.$emit("changePhone");
    },
    activeSystemFn(index, code) {
      this.$emit("activeSystemFn", index, code);
    },
    submitForm(formName, type) {
      var info = {
        formName: formName,
        refs: this.$refs,
        type: type,
      };
      this.$emit("submitForm", info);
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    // onTableSelect (rows, row) {
    //   this.$emit('onTableSelect', rows, row)
    // },
    handleSelectionChange(val) {
      this.$emit("selectInstitionListFn", val);
    },
    selectCurRow(selection, row) {
      this.$emit("selectCurRowFn", selection, row);
    },
    delInstitutionFn(_id) {
      this.$emit("delInstitutionFn", _id);
    },
    ChoiceOrganFn(type) {
      this.$emit("ChoiceOrganFn", type);
    },
    getAdminNameFn(val) {
      this.$emit("getAdminNameFn", val);
    },
    getSerchName(val) {
      this.$emit("getSerchName", val);
    },
    serchListFn() {
      this.$emit("serchListFn");
    },
    isAddInstution() {
      this.$emit("isAddInstution");
    },
    pageSizeChangeFn(info) {
      this.$emit("pageSizeChangeFn", info);
    },
    getRowKeys(val) {
      // this.$emit('getRowKeys', val)
      return val.id;
    },
    instclose() {
      this.$emit("instclose");
    },
  },
};
</script>
<style lang="less" scoped>
.userinfo {
  width: 800px;
  padding: 0px 25px;
  ::v-deep .el-select,
  .el-select__tags {
    display: block !important;
    width: 350px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .userinfo-title {
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    .userinfo-titleinfo {
      font-size: 18px;
      color: #1f2f3d;
      font-weight: bold;
    }
    .close-btn {
      position: absolute;
      right: 0px;
      top: 0px;
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .contaner {
    border: 1px solid #dcdfe6;
    height: calc(100vh - 120px);
    .contaner-info {
      // border-bottom: 1px dashed #dcdfe6;
      padding-bottom: 20px;
      .instituteInfor {
        border-top: 1px dashed #dcdfe6;
      }
      .contaner-info-title {
        height: 40px;
        line-height: 40px;
        background: rgba(250, 250, 253, 1);
        color: #1f2f3d;
        padding: 0px 10px;
        .border-left {
          display: inline-block;
          width: 3px;
          height: 14px;
          background: rgba(9, 113, 176, 1);
          margin-right: 7px;
          vertical-align: middle;
          position: relative;
          top: -1.5px;
        }
      }
      .system_type {
        display: inline-block;
        padding: 0px 12px;
        height: 36px;
        line-height: 34px;
        border: 1px solid #dcdfe6;
        border-radius: 18px;
        color: #0a70b0;
        cursor: pointer;
        margin: 0px 5px;
      }
      .system_type:hover {
        border-color: #0a70b0;
      }
      .active {
        background: #0a70b0;
        color: #fff;
        border-color: #0a70b0;
      }
      .contaner-info-list {
        padding: 5px 20px 0 20px;
        overflow: auto;
      }
      .contaner-info-list-item {
        display: flex;
        height: 45px;
        line-height: 45px;
        border-bottom: 1px solid #e4e7ed;
        .width_60 {
          width: 60px;
        }
        .width_300 {
          width: 300px;
        }
        .icon-btn {
          display: inline-block;
          width: 24px;
          height: 24px;
          color: #fff;
          line-height: 24px;
          text-align: center;
          padding: 0px;
          cursor: pointer;
          border-radius: 3px;
          margin-right: 8px;
        }
        .depspan {
          display: inline-block;
          padding: 0px 3px;
          color: #333;
        }
      }
      .authorize-img {
        width: 48px;
        height: 48px;
        vertical-align: middle;
      }
      .clr_88 {
        color: #888888;
      }
    }
    .contaner-bottom {
      height: calc(100% - 270px);
      padding-bottom: 0px !important;
      .contaner-info-list {
        height: calc(100% - 40px);
      }
    }
  }
  .bg_e6 {
    background: #e6a23c;
  }
  .bg_f5 {
    background: #f56c6c;
  }
  .bg_0c {
    background: #0c83cd;
  }
  .bg_00 {
    background: #00ad78;
  }
  .w_300 {
    width: 300px;
  }
}
.CAdialog {
  padding: 10px 20px 0 20px;
  ::v-deep .el-table {
    height: 447px;
    th {
      background: #f5f5f5 !important;
    }
    .el-table__body-wrapper {
      height: calc(100% - 40px);
      overflow: auto;
    }
  }
}
.instituteTable {
  ::v-deep .el-table__empty-block {
    display: none;
  }
}
</style>
