<template>
  <div class="jurisdictionlist">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303"
          ><i class="iconfont icondingwei mr10"></i>PACS系统</span
        >
      </div>
      <div class="tr col">
        <el-popover
          placement="bottom"
          width="90"
          popper-class="systemTypePopover"
          :offset="50"
          trigger="hover"
        >
          <div class="addClassDiv">
            <div
              v-if="serviceTypePowerObj.pacs === true"
              class="serviceCenterClass"
              @click="chooseSystemType(1)"
            >
              云PACS
            </div>
            <div
              v-if="serviceTypePowerObj.ewcss === true"
              class="serviceCenterClass"
              @click="chooseSystemType(4)"
            >
              集中预约
            </div>
            <div
              v-if="serviceTypePowerObj.image_archive === true"
              class="serviceCenterClass"
              @click="chooseSystemType(6)"
            >
              影像存档
            </div>
            <div
              v-if="serviceTypePowerObj.calling === true"
              class="serviceCenterClass"
              @click="chooseSystemType(5)"
            >
              语音叫号
            </div>
            <div
              v-if="serviceTypePowerObj.aim === true"
              class="serviceCenterClass"
              @click="chooseSystemType(9)"
            >
              智能诊断
            </div>
          </div>

          <!-- <span @click="isShowinfoFn('add')" class="function-btn bg_e6 clr_ff">
          <i class="iconfont iconxinzeng"></i>新增系统<i class="el-icon-caret-bottom"></i>
        </span> -->
          <el-button
            slot="reference"
            class="function-btn borderNone createBtn bg_e6 clr_ff"
          >
            <i class="iconfont iconxinzeng"></i>新增系统</el-button
          >
        </el-popover>
      </div>
    </div>
    <div
      class="pacsContainer"
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-background="rgba(255,255,255,0.6)"
      v-bind:class="{ noTableData: systemList.length === 0 }"
    >
      <el-table
        :data="systemList"
        border
        stripe
        height="100%"
        ref="tableAutoScroll"
        highlight-current-row
        header-row-class-name="strong"
      >
        <el-table-column align="center" type="index" label="序号" width="50">
          <!-- <template slot-scope="scope">
                      <span>{{(searchData.offset - 1) * searchData.limit + scope.$index + 1}}</span>

                  </template> -->
        </el-table-column>
        <el-table-column
          width="180"
          align="left"
          prop="id"
          label="系统ID"
          :show-overflow-tooltip="true"
        >
        </el-table-column>
        <el-table-column
          width="260"
          align="left"
          label="系统名称"
          :show-overflow-tooltip="true"
        >
          <template slot-scope="scope">
            <img
              class="system_img"
              :src="
                scope.row.product_code == 'NMIS'
                  ? HYX
                  : scope.row.product_code == 'ECGIS'
                  ? XD
                  : scope.row.product_code == 'UIS'
                  ? CS
                  : scope.row.product_code == 'RIS'
                  ? FS
                  : scope.row.product_code == 'EIS'
                  ? NJ
                  : scope.row.product_code == 'PIS'
                  ? PS
                  : scope.row.product_code == 'ExamSchedule'
                  ? ES
                  : scope.row.product_code == 'ImageArchive'
                  ? CUND
                  : scope.row.product_code == 'OIS'
                  ? YK
                  : scope.row.product_code == 'DRIS'
                  ? SZJGH
                  : scope.row.product_code == 'AIM'
                  ? AIM
                  : scope.row.product_code == 'RTIS'
                  ? FL
                  : YY
              "
            />
            <span class="system_name">{{ scope.row.name }}</span>
          </template>
        </el-table-column>
        <el-table-column
          width="200"
          align="left"
          prop="admin"
          label="管理员"
          :show-overflow-tooltip="true"
        >
          <!-- <template slot-scope="scope">
                      <span>{{scope.row.admin_name}}</span>
                      <span>( {{scope.row.admin_phone}} )</span>
                </template> -->
        </el-table-column>
        <el-table-column
          width="150"
          align="left"
          prop="product_code_desc"
          label="授权产品"
          :show-overflow-tooltip="true"
        >
        </el-table-column>
        <el-table-column align="left" label="操作">
          <template slot-scope="scope">
            <span
              class="operateBtn manageBtn mr10"
              v-if="isShowManageBtn"
              @click="isShowinfoFn('operate', scope.row)"
              ><i class="iconfont">&#xe667;</i>管理</span
            >
            <span
              class="operateBtn manageBtn mr10"
              v-if="scope.row.product_code == 'RIS' || scope.row.product_code == 'UIS' || scope.row.product_code == 'ECGIS' || scope.row.product_code == 'EIS' || scope.row.product_code == 'RTIS' || scope.row.product_code == 'NMIS' || scope.row.product_code == 'PIS'"
              @click="enterOfficeManage(scope.row)"
              ><i class="iconfont">&#xe667;</i>科室管理</span
            >
            <span
              class="operateBtn mr10"
              @click="isShowinfoFn('edit', scope.row)"
              ><i class="iconfont">&#xe63d;</i>编辑</span
            >
            <span
              v-if="
                isSetUdi &&
                scope.row.product_code !== 'ImageArchive' &&
                scope.row.product_code !== 'Calling'
              "
              class="operateBtn"
              @click="isShowinfoFn('aboutSystem', scope.row)"
              ><i class="iconfont">&#xe84e;</i>关于系统</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="isPacsinfo"
      :show-close="false"
      :withHeader="false"
      :wrapperClosable="this.operateSystemInfo.title === '编辑' ? true : false"
      :direction="direction"
      :before-close="handleClose"
    >
      <component
        :is="curSystemModule"
        ref="info"
        :pacsinfo="operateSystemInfo"
        :pageInfo="InstitutionPage"
        :productObj="productObj"
        :pacsServiceList="pacsServiceList"
        :getDetailFinished="getDetailFinished"
        :isUpdate="isUpdate"
        @closeFn="closeFn"
        @selectInstitionListFn="selectInstitionListFn"
        @selectCurRowFn="selectCurRow"
        @delInstitutionFn="delInstitutionFn"
        @changePhone="changePhone"
        @ChoiceOrganFn="ChoiceOrganFn"
        @serchListFn="serchListFn"
        @getSerchName="getSerchName"
        @getAdminNameFn="getAdminNameFn"
        @pageSizeChangeFn="pageSizeChangeFn"
        @CheckOfficeidsFn="CheckOfficeidsFn"
        @activePacsSystemFn="activePacsSystemFn"
        @activeSystemFn="activeSystemFn"
        @activeVoiceSystemFn="activeVoiceSystemFn"
        @changeService="changeService"
        @submitForm="submitForm"
        @isAddInstution="isAddInstution"
        @getRowKeys="getRowKeys"
        @instclose="instclose"
      ></component>
      <!-- <pacs-info ref="info" :pacsinfo="operateSystemInfo" :pageInfo="InstitutionPage" @closeFn="closeFn" @selectInstitionListFn="selectInstitionListFn" @selectCurRowFn="selectCurRow" @delInstitutionFn="delInstitutionFn"
        @changePhone="changePhone" @ChoiceOrganFn="ChoiceOrganFn" @serchListFn="serchListFn" @getSerchName="getSerchName" @getAdminNameFn="getAdminNameFn" @pageSizeChangeFn="pageSizeChangeFn" @CheckOfficeidsFn="CheckOfficeidsFn"
        @activeSystemFn="activeSystemFn" @submitForm="submitForm" @isAddInstution="isAddInstution" @getRowKeys="getRowKeys" @instclose="instclose"></pacs-info> -->
    </el-drawer>
  </div>
</template>

<script>
import Vue from "vue";
import Mgr from "@/utils/SecurityService";
import aboutSystem from "tomtaw-system-about";
import JSEncrypt from "jsencrypt";
import { mapGetters } from "vuex";
import pacsInfo from "./pacsinfo";
import ewcssinfo from "./ewcssinfo";
import imageInfo from "./imageInfo";
import voiceCallInfo from "./voiceCallInfo";
import aimInfo from "./aimInfo"
import {
  addPacsSystems,
  getInstitutionList,
  getAllPacsList,
  getPacsSystemsInfoByid,
  putPacsSystems,
  getPasServicecList,
  getServiceTypePower,
  getCallingService,
} from "@/api/platform_costomer/institution";
import {
  getLoginName,
  getConfigurations,
  getLoginUserInfor,
  ownMenu,
} from "@/api/commonHttp";
export default {
  components: {
    pacsInfo,
    ewcssinfo,
    imageInfo,
    voiceCallInfo,
    aimInfo,
  },
  computed: {
    ...mapGetters(["isSetUdi","isShowManageBtn"]),
  },
  // computed: {
  //   ...mapGetters(["usertype", "isSetUdi"]),
  // },
  data() {
    return {
      CS: require("../../../assets/images/CS_Image.png"), // 超声
      FS: require("../../../assets/images/FS_Image.png"), // 放射
      NJ: require("../../../assets/images/NJ_Image.png"), // 内镜
      XD: require("../../../assets/images/XD_Image.png"), // 心电
      PS: require("../../../assets/images/PS_Image.png"), // 病理
      HYX: require("../../../assets/images/HYX_Image.png"), // 核医学
      ES: require("../../../assets/images/Appoint_Image.png"), // 集中预约
      CUND: require("../../../assets/images/YXCD_Image.png"), // 影像存档
      YY: require("../../../assets/images/YY_Image.png"), // 影像存档
      YK: require("../../../assets/images/YK_Image.png"), // 眼科
      SZJGH: require("../../../assets/images/SZHBG_Image.png"), // 数字结构化报告
      AIM: require("../../../assets/images/AIM.png"), // 智能诊断
      FL: require("../../../assets/images/fangLiao_Image.png"), // 放疗pacs
      info: "",
      loading: true,
      isPacsinfo: false,
      direction: "rtl",
      systemList: [],
      isactive: "",
      curSystemModule: "",
      curSystemType: "",
      isoperateactive: "",
      pacsServiceList: [],
      getDetailFinished: false,
      operateSystemInfo: {
        title: "新增PACS系统",
        serchName: "",
        activesystem: "",
        systemList: [{ code: "", name: "",modules: [] }], // 授权产品
        isAdminname: false,
        product_name: "",
        providersObj: {
          app_id: "",
          app_secret: "",
          provider_name: "WeChat",
        },
        formInfo: {
          type: 1,
          product_code: "",
          name: "",
          admin_phone: "",
          admin_name: "",
          function_services: [],
          service_codes: [],
          providers: [],
        },
        rules: {
          product_code: [
            { required: true, message: "请选择产品名称", trigger: "change" },
          ],
          name: [
            { required: true, message: "请输入系统名称", trigger: "blur" },
          ],
          admin_phone: [
            { required: true, message: "请输入管理员电话", trigger: "change" },
          ],
          admin_name: [
            { required: true, message: "请输入管理员姓名", trigger: "change" },
          ],
        },
        isChioseOrgan: false,
        institutionList: [], // 机构列表
        deplist: [],
        multipleSelection: [], // 机构列表选中机构
      },
      productObj: {},
      searchPacsData: {
        offset: 1,
        limit: 200,
        sorts: [],
      },
      userLoginInfor: {},
      serviceTypePowerObj: {},
      isUpdate: false,
      isFirstChange: true,
      InstitutionPage: {
        eof: 1,
        page_index: 1,
        page_size: 8,
        total_count: 0,
        total_pages: 1,
      },
      choiseList: [], // select 选中机构
      isChoiceFirst: true, // 是否第一次select
    };
  },
  mounted() {
    const self = this;
    self.$nextTick(() => {
      this.getPascListFn();
      // 加密函数
      this.getConfigurationsFn();
      // 获取登录用户信息
      this.getUserLoginInfor();
    });
  },
  methods: {
    async getUserLoginInfor() {
      const res = await getLoginUserInfor();
      if (res.code == 0) {
        this.userLoginInfor = res.data;
        const tenancy_id = sessionStorage.getItem('curTenancyId') || this.userLoginInfor.tenancy_id
        this.beganGetServiceTypePower(tenancy_id);
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    async getConfigurationsFn() {
      const res = await getConfigurations("TransmissionSecurity.RSA.PublicKey");
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) {
          // 注册方法
          const pubKey = res.data; // ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt();
          encryptStr.setPublicKey(pubKey); // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()); // 进行加密
          return data;
        };
      }
    },
    // 加载相应的组件
    loadCurComponents() {
      if (this.curSystemType === 1) {
        this.curSystemModule = pacsInfo;
      }
      if (this.curSystemType === 4) {
        // 集中预约
        this.curSystemModule = ewcssinfo;
      }
      if (this.curSystemType === 6) {
        // 影像存档
        this.curSystemModule = imageInfo;
      }
      if (this.curSystemType === 5) {
        // 语音叫号
        this.curSystemModule = voiceCallInfo;
      }
      if (this.curSystemType === 9) {
        // 智能诊断
        this.curSystemModule = aimInfo
      }
    },
    // 选择系统
    chooseSystemType(type) {
      this.curSystemType = type;
      this.loadCurComponents();
      if (type === 5) {
        this.beganGetCallingService();
      }
      if (type === 1) {
        this.getPasServicecListFn();
      }
      this.isShowinfoFn("add");
    },
    async beganGetCallingService() {
      const res = await getCallingService();
      if (res.code === 0) {
        this.operateSystemInfo.systemList = res.data;
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    initDifferentSystemVal() {
      const self = this
      self.operateSystemInfo.formInfo.type = self.curSystemType;
      if (self.curSystemType === 1) {
        self.operateSystemInfo.title = "新增PACS系统";
      }
      if (self.curSystemType === 4) {
        // 集中预约
        self.operateSystemInfo.formInfo.product_code = "ExamSchedule";
        self.operateSystemInfo.title = "新增集中预约系统";
      }
      if (self.curSystemType === 6) {
        // 影像存档
        self.operateSystemInfo.formInfo.product_code = "ImageArchive";
        self.operateSystemInfo.title = "新增影像存档系统";
      }
      if (self.curSystemType === 5) {
        // 语音叫号
        // self.operateSystemInfo.formInfo.product_code = 'Calling'
        self.operateSystemInfo.title = "新增语音叫号系统";
      }
      if (self.curSystemType === 9) {
        self.operateSystemInfo.formInfo.product_code = "AIM";
        self.operateSystemInfo.title = "新增智能诊断系统";
        // 将之前选择的机构清空
        
        self.$nextTick(() => {
          self.$refs.info.page = 1
          self.$refs.info.size = 10
          self.$refs.info.tableData = []
          self.$refs.info.choosedInstituteArr = [];
          self.$refs.info.getTabelData2();
          self.$refs.info.$refs.qualityInstituTable.doLayout();
        });
      }
    },
    changePhone() {
      if (this.isUpdate) {
        // 是否是第一次改变
        if (this.isFirstChange) {
          this.operateSystemInfo.formInfo.admin_phone = "";
          this.operateSystemInfo.formInfo.admin_name = "";
        }
        this.isFirstChange = false;
      }
    },
    // 系统列表
    async getPascListFn() {
      const res = await getAllPacsList(this.searchPacsData);
      if (res.code === 0) {
        this.loading = false;
        this.systemList = res.data;
      } else {
        this.loading = false;
        this.$message({ type: "error", message: res.msg });
      }
    },
    async beganGetServiceTypePower(id) {
      const res = await getServiceTypePower({ tenancy_id: id });
      if (res.code === 0) {
        this.serviceTypePowerObj = res.data;
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 授权产品列表
    async getPasServicecListFn() {
      const self = this
      self.operateSystemInfo.systemList = []
      self.pacsServiceList = []
      const res = await getPasServicecList();
      if (res.code === 0) {
        if (res.data.length != 0){
          res.data.forEach((val) => {
          self.operateSystemInfo.systemList.push(val)
          self.pacsServiceList.push(val)
          // 初始化产品对象
          self.$set(self.productObj,val.code,[])
         })
        }
        //console.log(self.pacsServiceList)
      }

    },
    isAddInstution() {
      if (!this.operateSystemInfo.formInfo.product_code) {
        this.$message({
          type: "warning",
          message: "请选择授权产品！",
        });
        return;
      }
      this.InstitutionPage.page_index = 1;
      this.InstitutionPage.page_size = 10;
      this.getInstitutionListFn();
      this.operateSystemInfo.isChioseOrgan = true;
    },
    // 获取菜单
    getOwnMenu (system_id) {
      return new Promise((resolve) => {
        ownMenu().then(res  =>  {
          if (res.code != 0) {
            this.$message.error(res.msg)
            return
          }
          let arr = res.data.filter(item => {
            //return item.name === 'serviceCenterManage' && item.service_center_id == centerId
            return item.system_id == system_id
          })
          let url = ''
          if (arr[0].children[0].children.length != 0) { //有二级子菜单
            if (arr[0].children[0].children[0].children.length != 0) {
              url = arr[0].children[0].children[0].path + arr[0].children[0].children[0].children[0].path
            } else {
              url = arr[0].children[0].path + arr[0].children[0].children[0].path
            }
            
          } else { // 只有一级菜单
            url = arr[0].children[0].path
          }
          resolve(url)
        })
      })
    },
    // 点击管理处理跳转
    dealSkip(obj, id) {
      if (obj.type === 1) {
        // 云pacs
        window.sessionStorage.setItem("ChosedSystemName", "DepartmentSystem"); // 菜单name
        const href = "/operate/DepartmentSystem/UserList";
        const pisHref = "/operate/DepartmentSystem/userList";
        var newHref;
        if (obj.product_code === "PIS") {
          // 病理PACS系统 跳转时 去掉 /cloudpacs
          newHref =
            configUrl.frontEndUrl +
            "/piscloudpacs" +
            pisHref +
            "?system_id=" +
            id +
            "&ChosedSystemName=" +
            "DepartmentSystem";
            window.open(newHref, "_blank");
        } else if (obj.product_code === "NMIS") {
          newHref = configUrl.frontEndUrl +'/nmis/operate/DepartMentManage/user/UserList?system_id='+id
          window.open(newHref, "_blank");
        }
        else if (obj.product_code === "DRIS" || obj.product_code === "OIS") { // 眼科\心电\数字化报告
          newHref = configUrl.frontEndUrl +'/epis/operate/DepartmentSystem/UserList?system_id='+id+"&ChosedSystemName=" +"DepartmentSystem";
          window.open(newHref, "_blank");
        } else if (obj.product_code === "ECGIS") { // 心电
          newHref = configUrl.frontEndUrl +'/epis/operate/DepartmentSystem/UserList?system_id='+id+"&ChosedSystemName=" +"DepartmentSystem";
          if (configUrl.ecgUrl && configUrl.ecgUrl == 'cloudpacs') {
            newHref = configUrl.frontEndUrl + "/cloudpacs" + href +"?system_id=" + id +"&ChosedSystemName=" + "DepartmentSystem";
          }
          window.open(newHref, "_blank");
        }
        else if (obj.product_code === "RTIS") { // 放疗
          newHref = configUrl.frontEndUrl +'/rtis/systemset/TemplateManage/FormTemplate';
          window.open(newHref, "_blank");
        } else if (obj.product_code === "RTIS") { // 放疗
          newHref = configUrl.frontEndUrl +'/rtis/systemset/TemplateManage/FormTemplate';
          window.open(newHref, "_blank");
        }
        else {
          newHref =
            configUrl.frontEndUrl +
            "/cloudpacs" +
            href +
            "?system_id=" +
            id +
            "&ChosedSystemName=" +
            "DepartmentSystem";
            window.open(newHref, "_blank");
        }
        // this.getOwnMenu(id).then((url) => {
        //   // 新的跳转
        //   const { href } = this.$router.resolve({ path: url, query: { system_id: id, ChosedSystemName: 'DepartmentSystem'} })
        //   window.open(href, '_blank')
        // })
        
      } else if (obj.type === 4) {
        var path = process.env.NODE_ENV === "development" ? "" : "/ewcss";
        const href = configUrl.frontEndUrl + path + "/examSchedule/request";
        sessionStorage.setItem("system_id", id);
        window.open(href, "_blank");
      } else if (obj.type === 5) {
        // 语音叫号
        var path = process.env.NODE_ENV === "development" ? "" : "/calling/";
        //const href = configUrl.frontEndUrl + path + '/ExamSchedule/ScheduleList'
        const href = configUrl.frontEndUrl + path;
        sessionStorage.setItem("system_id", id);
        window.open(href, "_blank");
      } else if (obj.type === 6) {
        // 影像存档
        var path = process.env.NODE_ENV === "development" ? "" : "/paservice";
        const href =
          configUrl.frontEndUrl +
          path +
          "/?scope=" +
          "institution" +
          "&group=tenancy";
        sessionStorage.setItem("system_id", id);
        window.open(href, "_blank");
      } else if (obj.type === 9) { // 智能诊断
        const href = configUrl.frontEndUrl + '/intelligentDiagnosis/accessManagement/dataOverview'
        sessionStorage.setItem("system_id", id);
        window.open(href, "_blank");
      }
      // 请求菜单的方式
      //  sessionStorage.setItem("system_id", id);
      //  this.getOwnMenu(id).then((url) => {
      //     var dev = process.env.NODE_ENV === 'development' ? true : false
      //     if (dev) {
      //       url = url.replace('/operate', '')
      //     }
      //     const {href} = this.$router.resolve({path: url, query: {system_id: id}})
      //     window.open(href, '_blank')
      //   })
    },
    // 获取菜单
    getOwnMenu(id) {
      return new Promise((resolve) => {
        ownMenu().then((res) => {
          if (res.code != 0) {
            this.$message.error(res.msg);
            return;
          }
          let arr = res.data.filter((item) => {
            return item.system_id == id;
          });
          let url;
          if (arr[0].children[0].children.length != 0) {
            url = arr[0].children[0].path + arr[0].children[0].children[0].path;
          } else {
            url = arr[0].children[0].path;
          }
          resolve(url);
        });
      });
    },
    // 进入科室管理
    enterOfficeManage (obj) {
      var id;
      var code;
      var isopen;
      id = obj.id;
      isopen = obj.is_jump;
      code = obj.product_code;
      if (obj.type === 1 && !isopen) {
          // 只有云pacs 才需要判断
          self.$message({
            type: "error",
            message: "新增的系统，如需管理，请重新登录!",
          });
          return;
        }
        if (code) {
          sessionStorage.setItem("currentSystemClass", code);
        }
        if (id) {
          sessionStorage.setItem("lastname", id);
        }
        var newHref;
        newHref = configUrl.frontEndUrl +"/dms" +"?system_id=" +id;
        window.open(newHref, "_blank");
    },
    // 操作按钮
    isShowinfoFn(type, obj) {
      const self = this
      var id;
      var code;
      var isopen;

      // 新增和编辑时重置下产品对象
      for (let code in self.productObj) {
        self.$set(self.productObj,code,[])
      }

      if (obj) {
        id = obj.id;
        code = obj.product_code;
        isopen = obj.is_jump;
        self.curSystemType = obj.type;
      }
      if (type === "add") {
        self.isPacsinfo = true;
        self.isUpdate = false;
        self.operateSystemInfo = self.$options.data().operateSystemInfo;
        self.$nextTick(() => {
          self.$refs.info.activesystemIndex = -1
        })
        self.initDifferentSystemVal();
      } else if (type === "operate") {
        if (obj.type === 1 && !isopen) {
          // 只有云pacs 才需要判断
          self.$message({
            type: "error",
            message: "新增的系统，如需管理，请重新登录!",
          });
          return;
        }
        if (code) {
          sessionStorage.setItem("currentSystemClass", code);
        }
        if (id) {
          sessionStorage.setItem("lastname", id);
        }
        self.dealSkip(obj, id);
      } else if (type === "aboutSystem") { // 关于系统
          var manager = new Mgr()
          let appKey = obj.product_code == "PIS" ? 'pis': 'cloudpacs'
          if (obj.product_code == "ExamSchedule") { // 集中预约
            appKey = 'cloudcss'
          }
          else if (obj.product_code == "NMIS") { // 核医学
            appKey = 'nmis'
          }
          else if (obj.product_code == "RTIS") { // 放疗
            appKey = 'rtis'
          }
          manager.getRole().then(function (item) {
            if (item) {
              aboutSystem(appKey,item)
            }
          })
       }
      else {
        
        self.isactive = id;
        self.isPacsinfo = true;
        self.isUpdate = true;
        self.loadCurComponents();
        self.isFirstChange = true;
        self.operateSystemInfo.title = "编辑";
        if (obj.type === 5) {
          self.beganGetCallingService();
        }
        if (obj.type === 1) {
          self.getPasServicecListFn();
        }
        self.getDetailFinished = false
        const responce = getPacsSystemsInfoByid(id); // 详情接口
        self.operateSystemInfo.multipleSelection = [];
        responce.then((res) => {
          if (res.code === 0) {
            self.operateSystemInfo.product_name = res.data.product_name;
            self.operateSystemInfo.formInfo.product_code =
              res.data.product_code;
            self.operateSystemInfo.formInfo.id = res.data.id;
            self.operateSystemInfo.formInfo.name = res.data.name;
            self.operateSystemInfo.formInfo.admin_phone = res.data.admin_phone;
            self.operateSystemInfo.formInfo.admin_name = res.data.admin_name;
            self.operateSystemInfo.multipleSelection = res.data.institutions;
            self.operateSystemInfo.institution_count = res.data.institution_count;
            self.operateSystemInfo.formInfo.service_codes = res.data.service_codes;
            self.operateSystemInfo.isAdminname = true;
            if (res.data.providers.length != 0) {
              self.operateSystemInfo.providersObj = res.data.providers[0];
            }
            self.$set(self.productObj,res.data.product_code,res.data.function_services)
            self.isChoiceFirst = true;
            self.getDetailFinished = true
          }
        });
      }
    },
    changeService (arr) {
      const self = this
      self.$set(self.productObj,self.operateSystemInfo.formInfo.product_code,arr)
      if (arr.length > 0) {
        for (let code in self.productObj) {
          if (code != self.operateSystemInfo.formInfo.product_code) {
            self.$set(self.productObj,code,[])
          }
        }  
      }
    },
    activePacsSystemFn (index, code) {
      //console.log(this.productObj)
      this.operateSystemInfo.activesystem = index;
      this.operateSystemInfo.formInfo.product_code = code
      // 编辑时
      if (this.operateSystemInfo.title == '编辑') {
      } else {
        // 新增时
        this.operateSystemInfo.formInfo.function_services = []
      }
    },
    // 选择产品类型
    activeSystemFn(index, code) {
      this.operateSystemInfo.activesystem = index;
      this.operateSystemInfo.formInfo.product_code = code;
    },
    // 选择产品类型
    activeVoiceSystemFn(index, obj) {
      const self = this;
      self.operateSystemInfo.activesystem = index;
      self.operateSystemInfo.formInfo.service_codes = [];
      for (var key in obj) {
        if (obj[key]) {
          self.operateSystemInfo.formInfo.service_codes.push(key);
        }
      }
    },
    // 手机号姓名匹配
    async getAdminNameFn() {
      var _phone = this.operateSystemInfo.formInfo.admin_phone;
      var phoneReg = /^1[3456789]\d{9}$/;
      if (!phoneReg.test(_phone)) {
        return;
      }
      var url = `/users/lite/${_phone}`;
      var res = await getLoginName(url);
      if (res.code === 0) {
        this.operateSystemInfo.formInfo.admin_name = res.data
          ? res.data.name
          : "";
        this.operateSystemInfo.isAdminname = true;
      } else {
        this.operateSystemInfo.isAdminname = false;
        this.operateSystemInfo.formInfo.admin_name = "";
      }
    },
    handleClose(done) {
      done();
    },
    // 关闭 选择机构
    instclose() {
      this.operateSystemInfo.institutionList.forEach((item) => {
        this.$nextTick(() => {
          this.$refs.info.$refs.institutions.toggleRowSelection(item, false);
        });
      });
      this.operateSystemInfo.isChioseOrgan = false;
    },
    closeFn() {
      var info = {
        type: "cancel",
        refs: this.$refs["info"].$refs,
        formName: "formInfo",
      };
      this.submitForm(info);
    },
    // 获取机构列表
    async getInstitutionListFn() {
      const self = this;
      let filter_system_id = "";
      if (
        self.operateSystemInfo.title !== "新增PACS系统" ||
        self.operateSystemInfo.title !== "新增集中预约系统"
      ) {
        filter_system_id = "&filter_system_id=" + self.isactive;
      }
      // 机构的获取 云pacs 跟 集中预约有区别的
      let _url;
      if (this.curSystemType === 1) {
        _url =
          "/institutions?office_type=2&product_code=" +
          self.operateSystemInfo.formInfo.product_code +
          "&offset=" +
          self.InstitutionPage.page_index +
          "&limit=" +
          this.InstitutionPage.page_size +
          filter_system_id;
      } else if (this.curSystemType === 4) {
        _url =
          "/institutions?offset=" +
          self.InstitutionPage.page_index +
          "&limit=" +
          this.InstitutionPage.page_size +
          filter_system_id;
      }
      const res = await getInstitutionList(_url);
      self.$refs.info.$refs.institutions.clearSelection();
      if (res.code === 0) {
        res.data.forEach((item) => {
          item.office_ids = [];
          if (item.offices.length === 1) {
            item.office_ids[0] = item.offices[0].id;
          }
        });
        self.operateSystemInfo.institutionList = res.data;
        self.InstitutionPage = res.page;
        if (self.operateSystemInfo.title === "编辑") {
          // 勾上已选中的
          res.data.forEach((itemids) => {
            self.operateSystemInfo.multipleSelection.forEach((item) => {
              if (itemids.id === item.id) {
                self.$nextTick(() => {
                  self.$refs.info.$refs.institutions.toggleRowSelection(
                    itemids,
                    true
                  );
                });
                itemids.office_ids = item.office_ids;
              }
            });
          });
        }
      }
    },
    getRowKeys(row) {
      return row.id;
    },
    // 分页
    pageSizeChangeFn(info) {
      this.InstitutionPage.page_index = info.page;
      this.InstitutionPage.page_size = info.limit;
      this.getInstitutionListFn();
    },
    // 选中某一行
    selectCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === row.id) {
            self.operateSystemInfo.multipleSelection.splice(i, 1);
          }
        });
      }
    },
    // 去掉数组元素 里面对象 id值相同的
    clearCommonId(arr) {
      let obj = {};
      let peon = arr.reduce((cur, next) => {
        obj[next.id] ? "" : (obj[next.id] = true && cur.push(next));
        return cur;
      }, []);
      return peon;
    },
    handleInstituSelectionChange(val) {
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    // 机构 select change事件
    selectInstitionListFn(val) {
      // if (this.InstitutionPage.page_index === 1 && this.isChoiceFirst) {
      //   this.choiseList = [...this.operateSystemInfo.multipleSelection, ...rows]
      // } else {
      //   this.choiseList = rows
      // }
      // this.isChoiceFirst = false
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    // 机构 提交
    ChoiceOrganFn(type) {
      // if (type === 'commit') {
      //   this.operateSystemInfo.multipleSelection = this.choiseList
      // }
      this.instclose();
    },
    CheckOfficeidsFn(val) {
      // console.log(val)
    },
    delInstitutionFn(id) {
      this.$confirm("是否删除这条机构信息？", "删除信息", {
        distinguishCancelAndClose: true,
        confirmButtonText: "删除",
        cancelButtonText: "取消",
      }).then(() => {
        this.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === id) {
            if (this.operateSystemInfo.institutionList.length > 0) {
              this.$refs.info.$refs.institutions.toggleRowSelection(
                item,
                false
              );
            }
            this.operateSystemInfo.multipleSelection.splice(i, 1);
            this.$message({
              type: "success",
              message: "删除成功",
            });
          }
        });
      });
    },
   // 去重
    clearCommonService (arr) {
      let newArr = []
      if (arr.length != 0) {
        arr.forEach((item) => {
          if (newArr.indexOf(item) == -1) {
            newArr.push(item)
          }
        })
      }
      return newArr
    },
    async addPacsSystemsFn() {
      let subText = '正在新增，请稍等...'
      if (this.isUpdate) {
        subText = '正在编辑，请稍等...'
      }
      const loading = this.$loading({
        lock: true,
        text: this.operateSystemInfo.formInfo.id
          ? "正在编辑，请稍等..."
          : "正在新增，请稍等...",
        spinner: "el-icon-loading",
        background: "rgba(255, 255, 255, 0.6)",
      });
      // 叫号系统
      if (this.curSystemType === 5) {
        this.operateSystemInfo.formInfo.product_code = "Calling";
      }
      const _params = this.operateSystemInfo.formInfo;
      var _institutionList = [];
      this.operateSystemInfo.multipleSelection.forEach((item) => {
        var info = {};
        info.id = item.id;
        info.office_ids = item.office_ids;
        _institutionList.push(info);
      });
      _params.institutions = _institutionList;
      _params.providers = [];
      _params.providers.push(this.operateSystemInfo.providersObj);
      // 对手机号加密
      var adminPhone = _params.admin_phone;
      _params.admin_phone = this.$getRsaCode(_params.admin_phone);
       // 新增或编辑pacs时
      if (_params.type == 1) {
        _params.function_services = []
        for (let code in this.productObj) {
          if (this.productObj[code] && this.productObj[code].length > 0 && _params.product_code == code) {
            this.productObj[code].forEach((val) => {
              _params.function_services.push(val)
            })
          }
        }
        _params.function_services = this.clearCommonService(_params.function_services)
      }
      var res = null;
      var tipmsg = `${this.operateSystemInfo.title}成功`;

      if (_params.id) {
        delete _params["type"];
        res = await putPacsSystems(_params);
        //tipmsg = `修改${this.operateSystemInfo.title}成功`;
        tipmsg = `${this.operateSystemInfo.formInfo.name}修改成功`;
      } else {
        res = await addPacsSystems(_params);
      }
      loading.close();
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: tipmsg,
        });
        this.isPacsinfo = false;
        this.getPascListFn();
        this.pacsServiceList = []
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      } else {
        this.operateSystemInfo.formInfo.admin_phone = adminPhone;
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    getSerchName(val) {
      this.operateSystemInfo.serchName = val;
    },
    // 选择机构页面 查询按钮
    async serchListFn() {
      const _url =
        "/institutions?office_type=2&product_code=" +
        this.operateSystemInfo.formInfo.product_code +
        "&offset=1" +
        "&limit=" +
        this.InstitutionPage.page_size +
        "&name=" +
        this.operateSystemInfo.serchName;
      const res = await getInstitutionList(_url);
      if (res.code === 0) {
        this.operateSystemInfo.institutionList = res.data;
      }
    },
    submitForm(info) {
      if (info.type === "commit") {
        if (
          this.curSystemType !== 5 &&
          !this.operateSystemInfo.formInfo.product_code
        ) {
          this.$message({ type: "error", message: "请选择产品" });
          return;
        }
        if (
          this.curSystemType === 5 &&
          this.operateSystemInfo.formInfo.service_codes.length === 0
        ) {
          this.$message({ type: "error", message: "请选择产品" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.name) {
          this.$message({ type: "error", message: "请输入系统名称" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.admin_phone) {
          this.$message({ type: "error", message: "请输入管理员电话" });
          return;
        }
        var phoneReg = /^1[3456789]\d{9}$/;
        // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
        if (!this.isUpdate || (this.isUpdate && !this.isFirstChange)) {
          if (!phoneReg.test(this.operateSystemInfo.formInfo.admin_phone)) {
            this.$message({
              message: "请输入正确的手机号码!",
              type: "warning",
            });
            return false;
          }
        }
        if (!this.operateSystemInfo.formInfo.admin_name) {
          this.$message({ type: "error", message: "请输入管理员姓名" });
          return;
        }
        if (info.hasOwnProperty('choosedInstituteArr')) { // 智能诊断
          this.operateSystemInfo.multipleSelection = JSON.parse(JSON.stringify(info.choosedInstituteArr));
        }
        this.addPacsSystemsFn();
      } else {
        this.isPacsinfo = false;
        this.isactive = "";
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      }
    },
  },
};
</script>

<style lang="less" scoped>
.jurisdictionlist {
  height: 100%;
  .pacsContainer {
    height: calc(100% - 47px);
    padding: 10px 15px;
    overflow: auto;
    position: relative;
    ::v-deep .el-table__body-wrapper {
      height: calc(100% - 40px) !important;
      overflow: auto;
    }
    .system_img {
      width: 36px;
      float: left;
      margin-right: 10px;
    }
    .system_name {
      line-height: 36px;
      font-size: 16px;
      color: #303133;
    }
    .operateBtn {
      display: inline-block;
      cursor: pointer;
      height: 32px;
      line-height: 30px;
      padding: 0 10px;
      font-size: 15px;
      color: #0a70b0;
      border: 1px solid #ebeef5;
      border-radius: 3px;
      i {
        padding-right: 4px;
      }
    }
    .manageBtn {
      background: #0a70b0;
      color: #fff;
      border: 1px solid #0a70b0;
    }
  }
}
.adminInfor {
  width: 50%;
  max-width: 170px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

@media screen and (max-width: 1500px) {
  .list-item {
    width: calc(50% - 20px) !important;
  }
}
.borderNone {
  border: none !important;
}
.addClassDiv {
  text-align: center;
  .serviceCenterClass {
    line-height: 32px;
    cursor: pointer;
  }
}
.createBtn:hover {
  background: #e48e0b !important;
  color: #fff !important;
}
</style>
