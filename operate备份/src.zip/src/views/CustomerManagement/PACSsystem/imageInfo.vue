<template>
  <div class="userinfo">
    <div class="userinfo-title">
      <span class="userinfo-titleinfo">{{ pacsinfo.title }}</span>
      <span
        @click="closeFn"
        class="close-btn iconfont iconchuangjianshibai"
      ></span>
    </div>
    <el-form
      :model="pacsinfo.formInfo"
      ref="formInfo"
      label-width="120px"
      class="demo-ruleForm"
    >
      <div class="contaner">
        <div class="contaner-info">
          <el-row class="contaner-info-title">
            <span class="border-left"></span>基本信息
          </el-row>
          <el-row class="mt20 pl10 pr10">
            <el-form-item label="授权产品 ：" v-if="pacsinfo.product_name">
              <div>{{ pacsinfo.product_name }}</div>
            </el-form-item>
            <el-form-item v-else label="授权产品 ：">
              <span class="system_type active">影像存档</span>
            </el-form-item>
            <el-form-item class="mt15" label="系统名称 ：">
              <el-input
                v-model="pacsinfo.formInfo.name"
                placeholder="请输入系统名称"
                style="width: 480px"
              ></el-input>
            </el-form-item>
            <el-form-item class="mt15" label="系统管理员 ：">
              <el-input
                v-model="pacsinfo.formInfo.admin_phone"
                @input="changePhone"
                placeholder="请输入管理员电话"
                @blur="getAdminNameFn"
                style="width: 236px"
              ></el-input>
              <el-input
                v-model="pacsinfo.formInfo.admin_name"
                placeholder="请输入管理员姓名"
                :disabled="pacsinfo.isAdminname"
                class="ml10"
                style="width: 236px"
              ></el-input>
            </el-form-item>
            <weChat
              :weChatObj="pacsinfo.providersObj"
              :inputWidth="'236px'"
            ></weChat>
          </el-row>
        </div>
      </div>
      <div class="mt15">
        <el-button
          type="primary"
          size="medium"
          @click="submitForm('formInfo', 'commit')"
          >提交</el-button
        >
        <el-button size="medium" plain @click="submitForm('formInfo')"
          >取消</el-button
        >
      </div>
    </el-form>
  </div>
</template>
<script>
import weChat from "@/components/common/weChat";
import PaginationTool from "@/components/common/PaginationTool";
export default {
  components: {
    PaginationTool,
    weChat,
  },
  props: {
    pacsinfo: Object,
    pageInfo: Object,
  },
  data() {
    return {
      pageLayout: "total, prev, pager, next, jumper",
    };
  },
  methods: {
    closeFn() {
      this.$emit("closeFn");
    },
    changePhone() {
      this.$emit("changePhone");
    },
    activeSystemFn(index, code) {
      this.$emit("activeSystemFn", index, code);
    },
    submitForm(formName, type) {
      var info = {
        formName: formName,
        refs: this.$refs,
        type: type,
      };
      this.$emit("submitForm", info);
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    // onTableSelect (rows, row) {
    //   this.$emit('onTableSelect', rows, row)
    // },
    ChoiceOrganFn(type) {
      this.$emit("ChoiceOrganFn", type);
    },
    getAdminNameFn(val) {
      this.$emit("getAdminNameFn", val);
    },
  },
};
</script>
<style lang="less" scoped>
.userinfo {
  width: 800px;
  padding: 0px 25px;
  ::v-deep .el-select,
  .el-select__tags {
    display: block !important;
    width: 350px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .userinfo-title {
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    .userinfo-titleinfo {
      font-size: 18px;
      color: #1f2f3d;
      font-weight: bold;
    }
    .close-btn {
      position: absolute;
      right: 0px;
      top: 0px;
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .contaner {
    border: 1px solid #dcdfe6;
    height: calc(100vh - 120px);
    .contaner-info {
      // border-bottom: 1px dashed #dcdfe6;
      padding-bottom: 20px;
      .instituteInfor {
        border-top: 1px dashed #dcdfe6;
      }
      .contaner-info-title {
        height: 40px;
        line-height: 40px;
        background: rgba(250, 250, 253, 1);
        color: #1f2f3d;
        padding: 0px 10px;
        .border-left {
          display: inline-block;
          width: 3px;
          height: 14px;
          background: rgba(9, 113, 176, 1);
          margin-right: 7px;
          vertical-align: middle;
          position: relative;
          top: -1.5px;
        }
      }
      .system_type {
        display: inline-block;
        padding: 0px 12px;
        height: 36px;
        line-height: 34px;
        border: 1px solid #dcdfe6;
        border-radius: 18px;
        color: #0a70b0;
        cursor: pointer;
        margin: 0px 5px;
      }
      .system_type:hover {
        border-color: #0a70b0;
      }
      .active {
        background: #0a70b0;
        color: #fff;
        border-color: #0a70b0;
      }
      .contaner-info-list {
        padding: 5px 20px 0 20px;
        overflow: auto;
      }
      .contaner-info-list-item {
        display: flex;
        height: 45px;
        line-height: 45px;
        border-bottom: 1px solid #e4e7ed;
        .width_60 {
          width: 60px;
        }
        .width_300 {
          width: 300px;
        }
        .icon-btn {
          display: inline-block;
          width: 24px;
          height: 24px;
          color: #fff;
          line-height: 24px;
          text-align: center;
          padding: 0px;
          cursor: pointer;
          border-radius: 3px;
          margin-right: 8px;
        }
        .depspan {
          display: inline-block;
          padding: 0px 3px;
          color: #333;
        }
      }
      .authorize-img {
        width: 48px;
        height: 48px;
        vertical-align: middle;
      }
      .clr_88 {
        color: #888888;
      }
    }
    .contaner-bottom {
      height: calc(100% - 270px);
      padding-bottom: 0px !important;
      .contaner-info-list {
        height: calc(100% - 40px);
      }
    }
  }
  .bg_e6 {
    background: #e6a23c;
  }
  .bg_f5 {
    background: #f56c6c;
  }
  .bg_0c {
    background: #0c83cd;
  }
  .bg_00 {
    background: #00ad78;
  }
  .w_300 {
    width: 300px;
  }
}
.CAdialog {
  padding: 10px 20px 0 20px;
  ::v-deep .el-table {
    height: 447px;
    th {
      background: #f5f5f5 !important;
    }
    .el-table__body-wrapper {
      height: calc(100% - 40px);
      overflow: auto;
    }
  }
}
.instituteTable {
  ::v-deep .el-table__empty-block {
    display: none;
  }
}
</style>
