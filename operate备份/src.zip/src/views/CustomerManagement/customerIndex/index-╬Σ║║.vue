<template>
    <div class="customerHome"
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-background="rgba(255,255,255,0.6)">
        <div class="title-bar flex_row">
            <div class="tl flex_1">
                <span class="title-name clr_303"><i class="iconfont icondingwei mr10"></i>监管首页</span>
            </div>
            <div class="tr flex_1">
                <span @click="refresh" class="function-btn clr_0a">
                <i class="iconfont iconshuaxin1 pr5"></i>刷新
                </span>
            </div>
        </div>
        <div class="custoemrInfo">
            <div class="customerHead">
                <div class="headLeft fl">
                    <div class="imgIconDiv"><img :src="userImg" class="userIcon fl"/></div>
                    <div class="userInfoDiv fl">
                        <div class="userName" v-bind:title="loginInfo.profile.name">{{loginInfo.profile.name}}，欢迎登录！</div>
                        <div class="personCenter" @click="gotoPersonCenter"><i class="iconfont">&#xe6e2;</i> <span>个人中心</span></div>
                    </div>
                </div>
                <div class="headRight fl">
                  <div class="fl serviceAuth">服务授权</div>
                  <div class="fr applyAuth pointer" v-if="showApplyAuth" @click="gotoAuthPage">申请授权</div>
                  <div class="clear allAuth">
                      <div class="fl mr15 authCon" v-if="tenancy_service.service_state === 2">
                          <i class="authorize-img iconfont">&#xe768;</i>
                          <div class="authSucTit">授权成功</div>
                      </div>
                      <!--暂未授权-->
                      <div class="fl mr15 authCon noAuth" v-if="tenancy_service.service_state === 0">
                          <i class="authorize-img iconfont">&#xe766;</i>
                          <div class="authSucTit">暂未授权</div>
                      </div>
                       <!--等待授权-->
                      <div class="fl mr15 authCon waitAuth" v-if="tenancy_service.service_state === 1">
                          <i class="authorize-img iconfont">&#xe767;</i>
                          <div class="authSucTit">等待授权</div>
                      </div>
                      <!--已授权-->
                      <div class="serviceModule fl" v-if="tenancy_service.service_state === 2 || tenancy_service.service_state === 1">
                         <span class="oneServcieModule fl mr10" v-for="(item, index) in opendedService" :key="index">{{item}}</span>
                      </div>
                      <!--暂未授权-->
                      <div class="noAuthCon fl" v-if="tenancy_service.service_state === 0">
                         <span class="noAuthTip"><i class="iconfont pr10">&#xe769;</i>申请授权后，可享更多服务</span>
                      </div>
                  </div>
                </div>
            </div>
            <div class="dataStatic mt5">
                <div class="clear needAuthDiv fl">
                    <div class="oneChart fl mr4">
                      <div class="chartHead">
                          <i class="iconfont chartIcon">&#xe75d;</i>
                        <span class="instituteLabel">医疗机构<span class="unitDesc">（单位：家）</span></span> 
                        <span class="addInstitute pointer fr" @click="gotoInstituteListPage">新增机构</span>
                      </div>
                      <!-- <div id="pieInstituteChart" v-bind:class="{'noTableData': instituteArr.length == 0}"></div> -->
                      <div id="pieInstituteChart" v-bind:class="{'noChartData': !hasInstitution}"></div>
                  </div>
                  <div class="oneChart fl">
                      <div class="chartHead">
                          <i class="iconfont chartIcon">&#xe762;</i>
                        <span class="instituteLabel">医务人员<span class="unitDesc">（单位：人）</span></span> 
                        <span class="addInstitute pointer fr" @click="gotoUserListPage">新增人员</span>
                      </div>
                      <!-- <div id="pieInstituteChart" v-bind:class="{'noTableData': instituteArr.length == 0}"></div> -->
                      <div id="pieDoctorChart" v-bind:class="{'noChartData': !hasDoctor}"></div>
                  </div>
                  <div class="mt5 clear fl lineChart" v-show="showImageShare">
                      <div class="chartHead">
                          <i class="iconfont chartIcon">&#xe760;</i>
                        <span class="instituteLabel">影像共享<span class="unitDesc">（单位：人次）</span></span> 
                        <span class="addInstitute timeChoose fr">
                          <el-radio-group v-model="totalParam.idcas_day" @change="changeTimeType('idca')">
                              <el-radio-button :label="item.value" v-for="(item, index) in timeTypeArr" :key="index">{{item.name}}</el-radio-button>
                          </el-radio-group>
                        </span>
                      </div>
                      <div id="imageShareChart"></div>
                  </div>
                  
                  <div class="mt5 clear fl lineChart" v-show="showEducation">
                    <div class="chartHead">
                        <i class="iconfont chartIcon">&#xe764;</i>
                       <span class="instituteLabel">远程培训量趋势<span class="unitDesc">（单位：人次）</span></span> 
                       <span class="addInstitute timeChoose fr">
                           <el-radio-group v-model="totalParam.remote_education_days" @change="changeTimeType('center')">
                            <el-radio-button :label="item.value" v-for="(item, index) in timeTypeArr" :key="index">{{item.name}}</el-radio-button>
                           </el-radio-group>
                       </span>
                     </div>
                     <div id="distanceTrainingChart"></div>
                  </div>
                </div>

                
                <!-- <div class="noNeedAuthDiv fl"> -->
                  <div class="oneChart fl" v-show="showDevice">
                    <div class="chartHead">
                        <i class="iconfont chartIcon">&#xe765;</i>
                       <span class="instituteLabel">医疗设备<span class="deviceTip">（单位：台）</span></span> 
                     </div>
                      <!-- <div id="pieInstituteChart" v-bind:class="{'noTableData': instituteArr.length == 0}"></div> -->
                      <div id="pieDeviceChart" v-bind:class="{'noChartData': !hasDevice}"></div>
                  </div>
                  <div class="mt5 fl dataStaticChart" v-bind:class="{'newDataStaticChart': authArr.length === 0, 'noMarginTop': !showDevice}">
                      <div class="chartHead">
                          <i class="iconfont chartIcon">&#xe75e;</i>
                        <span class="instituteLabel">数据存储</span> 
                        <span class="addInstitute pointer fr" @click="gotoDataBase">存储管理</span>
                      </div>
                      <div class="usedStorage">{{use_amount}}</div>
                      <div id="bearingChart"></div>
                  </div>
                  <div class="mt5 fl barChart">
                      <div class="chartHead">
                          <i class="iconfont chartIcon">&#xe761;</i>
                        <span class="instituteLabel">服务工单<span class="unitDesc">（单位：个）</span></span> 
                        <span class="addInstitute pointer fr" @click="watchOrder">查看工单</span>
                      </div>
                      <div id="orderBarChart"></div>
                      <div class="orderCon">
                          <div class="allOrderTit">所有工单</div>
                          <div class="orderTotalNum">{{totalOrderNum}}</div>
                          <!-- <div class="addOrderBtn" @click="watchOrder"><i class="iconfont">&#xe6f9;</i><span>新增工单</span></div> -->
                      </div>
                  </div>
                  <div v-if="showDataScreen" class="mt5 fl dataBigScreen" v-bind:class="{'addMl5':authArr.length === 0 || (authArr.length === 1 && showPacs)}">
                      <div class="chartHead">
                          <i class="iconfont chartIcon">&#xe763;</i>
                        <span class="instituteLabel">数据大屏</span>
                        <span class="addInstitute pointer fr" @click="addDataCockpit">新增大屏</span>
                      </div>
                      <div id="bigScreenCon">
                          <div class="oneScreen" v-for="(item,index) in largeScreenList" :key="index" @click="gotoDataCockpit(item)" @mouseover="showDataCockpitOperate($event)" @mouseout="hideDataCockpitOperate($event)">
                            <div class="fl oneScreenNameDiv">
                               <i class="iconfont">&#xe76d;</i>
                               <!-- <span class="cockpitName" v-bind:title="customerinfo.name + '数据驾驶舱'">{{customerinfo.name}}</span> -->
                               <span class="cockpitName" v-bind:title="item.name">{{item.name}}</span>
                            </div>
                            <div class="cockpitOperate fr">
                              <span @click.stop="updateCockpitOperate(item)" class="editDataCockpit">编辑</span>
                              <span class="splitIcon"></span>
                              <span @click.stop="delCockpitOperate(item.id)" class="delCockpitOperate">删除</span>
                            </div>
                          </div>
                          <!-- <div class="oneScreen" @click="gotoRisDataCockpit">放射pacs数据驾驶舱</div> -->
                      </div>
                  </div>
                  <div class="mt5 clear fl lineChart" v-show="showPacs">
                      <div class="chartHead">
                          <i class="iconfont chartIcon">&#xe75f;</i>
                        <span class="instituteLabel">PACS系统<span class="unitDesc">（单位：人次）</span></span> 
                        <span class="addInstitute timeChoose fr">
                            <el-radio-group v-model="totalParam.pacs_day" @change="changeTimeType('pacs')">
                              <el-radio-button :label="item.value" v-for="(item, index) in timeTypeArr" :key="index">{{item.name}}</el-radio-button>
                          </el-radio-group>
                        </span>
                      </div>
                      <div id="pacsLineChart"></div>
                  </div>
                  <div class="mt5 clear fl lineChart" v-show="showServiceCenter">
                    <div class="chartHead">
                        <i class="iconfont chartIcon">&#xe764;</i>
                       <span class="instituteLabel">远程医疗<span class="unitDesc">（单位：人次）</span></span> 
                       <span class="addInstitute timeChoose fr">
                           <el-radio-group v-model="totalParam.center_day" @change="changeTimeType('center')">
                            <el-radio-button :label="item.value" v-for="(item, index) in timeTypeArr" :key="index">{{item.name}}</el-radio-button>
                           </el-radio-group>
                       </span>
                     </div>
                     <div id="serviceCenterChart"></div>
                  </div>
                <!-- </div> -->
            </div>
        </div>
        <el-dialog :title="cockpitTit" :visible.sync="showAddDataCockpitAlert" top="8vh" width="500px" :close-on-click-modal="false" v-dialogDrag>
          <div class="addDataCockpitCon">
            <div class="logItem">
                <span class="logLabel fl">
                <i class="iconfont iconbitian mustIcon"></i>
                大屏名称：</span>
                <el-input class="fl passwordInput"  v-model="addDataCockpitParam.name" placeholder="请输入大屏名称"></el-input>
            </div>
            <div class="logItem">
                <span class="logLabel fl">
                <i class="iconfont iconbitian mustIcon"></i>
                跳转链接：</span>
                <el-input class="fl passwordInput"  v-model="addDataCockpitParam.url" placeholder="请输入大屏的跳转链接地址"></el-input>
            </div>
            <div class="dialog_footer">
              <el-button size="small" @click="showAddDataCockpitAlert=false">取消</el-button>
              <el-button v-if="!isUpdateCockpit" type="primary" size="small" @click="sureAddDataCockpit()">确定</el-button>
              <el-button v-if="isUpdateCockpit" type="primary" size="small" @click="sureUpdateDataCockpit()">确定</el-button>
              
            </div>
        </div>
       </el-dialog>
    </div>
</template>
<script>
import * as echarts from 'echarts'
import { getUserLogo, getTenancyStatistics } from '@/api/commonHttp'
import Mgr from '@/utils/SecurityService'
import { getBase64 } from '@/components/commonJs'
import { getCostomerinfoByid, getLargeScreenlist,addLargeScreen,putLargeScreen,delLargeScreen } from '@/api/platform_operate/costomer'
var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
export default {
  data () {
    return {
       userImg: require('@/assets/images/common/doctor_boy.png'),
       instituteArr: [],
       allConstants: '',
       idcaTimeType: 7,
       pacsTimeType: 7,
       centerTimeType: 7,
       showApplyAuth: false,
       loading: true, // 为了开发急用 先改成false
       authArr: [], // 用于存放有几个授权
       timeTypeArr: [
         {
           name: '近7天',
           value: 7
         },
         {
           name: '近15天',
           value: 15
         },
         {
           name: '近1个月',
           value: 30
         }
       ],
       loginInfo: {
        profile: {
          inst_name: ''
        }
      },
      showDataScreen: true,
      showPacs: false,  // 是否授权pacs
      showServiceCenter: false, // 是否授权服务中心
      showImageShare: false, // 是否授权影像共享
      showEducation: false,
      showDevice: false, // 是否展示设备
      use_amount: '',
      customerinfo: {},
      totalOrderNum: 0,
      tenancyTotalData: '',
      hasInstitution: false,
      hasDoctor: false,
      hasDevice: false,
      // 大屏参数
      largeScreenList: [],
      showAddDataCockpitAlert: false,
      cockpitTit: '新增大屏',
      isUpdateCockpit: false,
      addDataCockpitParam: {
        id: 0,
        name: '',
        url: ''
      },
      // 客户授权信息
      tenancy_service: {},
      opendedService: [],
      totalParam: {
        center_day: 7,
        pacs_day: 7,
        idcas_day: 7,
        remote_education_days: 7
      }
    }
  },
  methods: {
    async getAllLargeScreenList () {
      const self = this
      self.largeScreenList = []
      const res = await getLargeScreenlist()
      if (res.code === 0) {
        if (res.data.length > 0) {
          res.data.forEach((val) => {
             //val.url = decodeURI(val.url)
             // 将&已经被转义的 &amp; 反转义成 '&'
              var url = val.url
              var c = document.createElement('div');
              c.innerHTML = url;
              url = c.innerText || c.textContent;
              c = null;
              val.url = url
             self.largeScreenList.push(val)
          })
        }
        //self.largeScreenList = res.data
      } else {
        self.$message({ type: 'info',message: `${res.msg}`})
      }
    },
    // 显示大屏操作
    showDataCockpitOperate (e) {
      const obj = e.currentTarget
      const cockpitOperateObj = obj.getElementsByClassName('cockpitOperate')[0]
      cockpitOperateObj.style.display = 'block'
    },
    // 隐藏大屏操作
    hideDataCockpitOperate (e) {
      const obj = e.currentTarget
      const cockpitOperateObj = obj.getElementsByClassName('cockpitOperate')[0]
      cockpitOperateObj.style.display = 'none'
    },
    // 新增大屏
    addDataCockpit () {
      this.showAddDataCockpitAlert = true
      this.cockpitTit = '新增大屏'
      this.isUpdateCockpit = false
      this.addDataCockpitParam = this.$options.data().addDataCockpitParam
    },
    verifyAddDataCockpit () {
      if (this.addDataCockpitParam.name === '') {
        this.$message({ type: 'error', message: '请输入名称' })
        return false
      }
      if (this.addDataCockpitParam.url === '') {
        this.$message({ type: 'error', message: '请输入跳转链接地址' })
        return false
      }
      return true
    },
    // 确定新增大屏
    async sureAddDataCockpit () {
      if (this.verifyAddDataCockpit()) {
       const param = {
        name : this.addDataCockpitParam.name,
        url: this.addDataCockpitParam.url,
       }
       const res = await addLargeScreen(param)
       if (res.code === 0) {
          this.showAddDataCockpitAlert = false
          this.$message({ type: 'success',message: '新增大屏成功' })
          // 获取大屏列表
          this.getAllLargeScreenList()
        } else {
          this.$message.error(res.msg)
        }
       }
    },
    async beganDelCockpitOperate (id) {
      const param = {
        id: id
      }
      const res = await delLargeScreen(param)
      if (res.code === 0) {
        this.$message({ type: 'success',message: '删除大屏成功' })
        // 获取大屏列表
        this.getAllLargeScreenList()
      } else {
        this.$message.error(res.msg)
      }      
    },
    // 删除大屏
    delCockpitOperate (id) {
      const self = this
      self.$confirm('确定要删除该大屏?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        customClass: 'warningAlert',
        type: 'warning'
      })
      .then(() => {
        self.beganDelCockpitOperate(id)
      })
      .catch(() => {
      })      
    },
    // 确定编辑大屏
    async sureUpdateDataCockpit () {
      if (this.verifyAddDataCockpit()) {
        const param = {
          id: this.addDataCockpitParam.id,
          name: this.addDataCockpitParam.name,
          url: this.addDataCockpitParam.url,
        }
        const res = await putLargeScreen(param)
        if (res.code === 0) {
          this.showAddDataCockpitAlert = false
          this.$message({ type: 'success',message: '编辑大屏成功' })
          // 获取大屏列表
          this.getAllLargeScreenList()
        } else {
          this.$message.error(res.msg)
        }
      }
    },
    // 编辑大屏
    updateCockpitOperate (item) {
      this.showAddDataCockpitAlert = true
      this.cockpitTit = '编辑大屏'
      this.isUpdateCockpit = true
      this.addDataCockpitParam = item
      // 将&已经被转义的 &amp; 反转义成 '&'
      let url = item.url
      var c = document.createElement('div');
      c.innerHTML = url;
      url = c.innerText || c.textContent;
      c = null;
      this.addDataCockpitParam.url = url
    },
    gotoPersonCenter () {
      var path = '/personCenter/index'
      path = basepath + path
      this.$router.push({path: path})      
    },
    refresh () {
      this.loading = true
      this.getTenancyTotal()
    },
    // 改变时间
    changeTimeType (val,type) {
      this.getTenancyTotal()
      // this.getMyChartData(val)
    },
    makePieChart (domId, total, ydata, xdata) {
      const self = this
      var myChart = echarts.init(document.getElementById(domId));
      var color = ["#5892ff","#ffb95e","#ff7768","#4ecb73","#2ec6c6","#247fea","#fd866a","#fdb301","#676ec6","#fdb36a","#61c178","#946dff"]
    // var xdata = ['财务管理决策实训', "商品流通业实训", "暖心陪伴（津乐园20cm定制蛋糕）", "嘉果荟萃（津乐园20cm定制蛋糕）", '优雅圆舞曲（津乐园20cm）','巧克力之夏（津乐园20cm定制蛋糕）','财税宝4G','成本会计','纳税会计与筹划','金融担保业实训'];
      var option = {
          title: {
              text: '总计',
              subtext: total,
              textStyle: {
                fontSize: 15,
                color: '#333',
                lineHeight: 20,
                fontWeight: 'initial'
              },
              subtextStyle: {
                  fontSize:28,
                  color: '#333',
                  fontFamily:'Aarial'
              },
              textAlign: 'center',
              left: '30%',
              top: '40%'
          },
          // tooltip: {
          //     trigger: 'item',
          // },
        backgroundColor: "rgba(255,255,255,1)",
        color:color,
        tooltip: {
            trigger: 'item',
            formatter:function (parms){
              var str=  parms.name+"</br>"+
                "数量："+ parms.data.value+"</br>"+
                "占比："+ parms.percent+"%";
                return  str ;
            }
        },
        legend: {
            orient: "vartical",
            x: "left",
            top: "center",
            left: "60%",
            bottom: "0%",
            data: xdata,
            itemWidth: 8,
            itemHeight: 8,
            itemGap :16,
             formatter: (name) => { 
                var item = ydata.filter((item) => item.name === name)[0];
                return `${name} | ${item.value}`;
              }
        },
        series: [{
            type: 'pie',
            radius: [60, 90],
            center: ['30%', '50%'],
            label: {
                show: false
            },
            labelLine: {
                show: false
            },
            itemStyle: {
                borderWidth: 2,
                borderColor: '#fff'
            },
            data: ydata
        }]
    };
    myChart.setOption(option)
    },
    // 画折线图
    makeLineChart (domId, title, itemData, xData, yData) {
      const self = this
      var myChart = echarts.init(document.getElementById(domId));
      var option = {
              backgroundColor: '#fff',
              title: {
                  text: title,
                  // left: "18px",
                  top: "0",
                  textStyle: {
                    color:'#303133',
                    fontSize: '14px'
                  }
              },
              color: ["#247fea", "#ff9000","#00b235","#ff745a","#1d9ed1","#5b8ff9","#ff5ca2"],
              tooltip: {
                  trigger: 'axis',
                  axisPointer: {
                      type: 'cross',
                      crossStyle: {
                          color: '#999'
                      },
                      lineStyle: {
                          type: 'dashed'
                      }
                  }
              },
              grid: {
                left: '1%',
                right: '0',
                bottom: '3%',
                top:'35',
                containLabel: true
              },
              legend: {
                  data: itemData,
                  orient: 'horizontal',
                  icon: "circle",
                  show: true,
                  right: '0px',
                  itemWidth: 10,
                  itemHeight: 10,
                  textStyle:{
                    padding:[2, 0, 0, 0]
                  }
              },
              xAxis: {
                  type: 'category',
                  data: xData,
                  splitLine: {
                      show: false
                  },
                  axisTick: {
                      show: false
                  },
                  axisLine: {
                      show: false
                  },
              },
              yAxis: {
                  type: 'value',
                  axisLabel: {
                      color: '#303133',
                      textStyle: {
                          fontSize: 14
                      },
                  },
                  splitLine: {
                      show: true,
                      lineStyle: {
                       type: 'dashed',
                       color: '#dcdfe6' // 横线的颜色
                      }
                  },
                  axisTick: {
                      show: false
                  },
                  axisLine: {
                      show: false
                  },
              },
              series: yData
          };

        myChart.clear()　　//先清除图表
        myChart.setOption(option, true)　　//再设置配置
        myChart.hideLoading()　　//关闭loadin
    },
    // 画条形图
    makeBarChart (domId, orderChartData) {
       const self = this
       var myChart = echarts.init(document.getElementById(domId));
        var colorArr = [
            {
              top: '#e6a23c',//黄色
              bottom: '#ffb95e',
            },
            {
              top: '#4481ff',//蓝色
              bottom: '#76a1fa'
            },
            {
              top: '#5abe72',//蓝色
              bottom: '#4ecb73'
            },
            {
              top: '#ff6958',//蓝色
              bottom: '#ff7d6f'
            }
        ];
        var option = {
            backgroundColor: '#fff',
            grid: {
                top: '10%',
                right: '0%',
                left: '8%',
                bottom: '8%'
            },
            xAxis: [{
                type: 'category',
                color: '#59588D',
                data: ['已提交', '处理中', '已完成', '已关闭'],
                axisLabel: {
                    margin: 5,
                    color: '#303133',
                    textStyle: {
                        fontSize: 13
                    },
                },
                axisLine: {
                    lineStyle: {
                      color: '#dcdfe6',
                    }
                },
                axisTick: {
                    show: false
                },
            }],
            yAxis: [{
              type: 'value',
              axisLabel: {
                  color: '#303133',
                  textStyle: {
                      fontSize: 14
                  },
              },
              splitLine: {
                  show: true,
                  lineStyle: {
                    type: 'dashed',
                    color: '#dcdfe6' // 横线的颜色
                  }
              },
            }],
            series: [{
                type: 'bar',
                data: orderChartData,
                barWidth: '15px',
                itemStyle: {
                    normal: {
                        color: function(params) {
                            let num = colorArr.length;
                            return new echarts.graphic.LinearGradient(0, 0, 0, 1,[{
                                offset: 0,
                                color: colorArr[params.dataIndex % num].top // 0% 处的颜色
                            },{//可根据具体情况决定哪根柱子显示哪种颜色
                                offset: 1,
                                color: colorArr[params.dataIndex % num].bottom // 100% 处的颜色
                            }],false)
                        },
                        barBorderRadius: [30, 30, 0, 0],
                    }
                },
                label: {
                    normal: {
                        show: true,
                        fontSize: 15,
                        fontWeight: 'bold',
                        color: '#333',
                        position: 'top',
                        fontFamily: 'Arial',
                    }
                }
            }]
        };
        myChart.setOption(option);
    },
    makeBearingChart (domId,val,usedCount) {
       const self = this
       var myChart = echarts.init(document.getElementById(domId));
       var option = {
        backgroundColor: '#fff',
        series: [
            {
              // 进度条指针
              type: 'gauge',
              splitNumber: 5,
              radius: '67%',
              min: 0,
              max: 100,
              pointer: {
                  show: true,
                  width: 10,
                  length: '56%',
                  itemStyle: {
                      color: 'auto',
                  },
              },
              markPoint: {
              // 仪表盘指针圆
              animation: false,
              silent: true,
              data: [{
                  x: '50%',
                  y: '50%',
                  symbol: 'circle',
                  symbolSize: 22,
                  // itemStyle: {
                  //     color: '#1890ff',
                  // },
              }, {
                  x: '50%',
                  y: '50%',
                  symbol: 'circle',
                  symbolSize: 14,
                  itemStyle: {
                      color: '#fff'
                  },
              }]
          },
              axisLine: {
                  show: true,
                  lineStyle: {
                      width: 28,
                      color: [
                          [0.5, '#05c397'],
                          [0.8, '#ffb661'],
                          [1, '#FF6061'],
                      ],
                      borderColor: '#000',
                      borderWidth: '10',
                  },
              },
              axisLabel: {
                  show: true,
                  // 数字刻度显示位置
                  distance: 14,
                  fontSize: 13,
                  color: '#3699FF',
              }, //刻度标签
              axisTick: {
                  show: false,
              }, //刻度样式
              splitLine: {
                  show: false,
                  length: '12%',
                  lineStyle: {
                      color: '#3699FF',
                      width: 2,
                  },
              }, //分隔线样式
              detail: {
                  show: false,
              },
              title: {
                  show: true,
                  textStyle: {
                      fontSize: 15,
                  },
                offsetCenter: ['2%', '75%'] ,
              },
              data: [
                  {
                      value: val,
                      name: '使用容量(%)',
                  },
              ],
          },
          {
              // 刻盘彩色部分
              type: 'gauge',
              splitNumber: 10,
              radius: '75%',
              min: 0,
              max: 45,
              pointer: {
                  show: false,
                  width: 2,
                  length: '100%',
                  color: 'auto',
              },
              axisLine: {
                  show: true,
                  lineStyle: {
                      width: 2,
                      color: [
                          [0.5, '#05c397'],
                          [0.8, '#ffb661'],
                          [1, '#FF6061'],
                      ],
                  },                
              },
              axisLabel: {
                  show: false,
              }, //刻度标签
              axisTick: {
                  show: true,
                  splitNumber: 5,
                  lineStyle: {
                      color: '#EBF3FE',
                      width: 1,
                  },
              }, 
              //刻度样式
              splitLine: {
                  show: true,
                  length: '15%',
                  lineStyle: {
                      color: '#fff',
                      width: 1,
                  },
              },
              detail: {
                  show: false,
                  offsetCenter: ['8%', '100%']
              },
              title: {
                  show: false,
              },
              data: [
                  {
                      value: '59.54',
                      name: '占比',
                  },
              ],
          },
          {
              // 背景大圆环
              name: '',
              type: 'pie',
              radius: ['71%', '44%'],
              silent: true,
              startAngle: 225,
              labelLine: {
                  normal: {
                      show: false,
                  },
              },
              z: -1,
              data: [
                  {
                      value: 75,
                      itemStyle: {
                          color: '#ebf3fe',
                      },
                  },
                  {
                      value: 25,
                      itemStyle: {
                          color: 'rgba(255,255,255,0)',
                      },
                  },
              ],
          },
          {
              z: -1,
              data: [
                  {
                      value: 75,
                      itemStyle: {
                      color: 'rgba(19, 55, 169,0)',
                      borderWidth: 2,
                      borderColor: 'rgba(19, 55, 169,0)',
                      shadowColor: 'rgba(0,138,255,0)',
                      shadowBlur: 2,
                      shadowOffsetX: 1,
                      shadowOffsetY: 1
                      },
                  },
                  {
                      value: 25,
                      itemStyle: {
                          color: 'transparent',
                      },
                  },
              ],
          },
      ],
     }
      myChart.setOption(option)
    },
    //画折线图和柱状图一起
    makeLineAndBarChart (domId, title, itemData, xData, yData) {
       const self = this
       var myChart = echarts.init(document.getElementById(domId));
       var option = {
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross',
              crossStyle: {
                color: '#999'
              }
            }
          },
          legend: {
            data: itemData,
            orient: 'horizontal',
            icon: "circle",
            show: true,
            right: '0px',
            itemWidth: 10,
            itemHeight: 10,
            textStyle:{
              padding:[2, 0, 0, 0]
            }
          },
          grid: {
            left: '1%',
            right: '0',
            bottom: '2%',
            top:'60',
            containLabel: true
          },
          // grid: {
          //   left: '3%',
          //   right: '20',
          //   bottom: '3%',
          //   containLabel: true
          // },
          xAxis: [
            {
              type: 'category',
              data: xData,
              axisPointer: {
                type: 'shadow'
              }
            }
          ],
          yAxis: [
            {
              type: 'value',
              name: '单位：人次',
              min: 0,
              max: 1000,
              interval: 200,
              axisLabel: {
                // formatter: '{value} ml'
                formatter: '{value}'
              }
            },
            {
              type: 'value',
              name: '单位：门',
              min: 0,
              max: 100,
              interval: 20,
              axisLabel: {
                // formatter: '{value} °C'
                formatter: '{value}'
              }
            }
          ],
          series: yData
        };
        myChart.setOption(option);      
    },
    async getUserIcon () {
      const self = this
      const userIconId = self.loginInfo.profile.sub
      if (userIconId && userIconId !== '0') {
        // 用户头像
        const imgFile = await getUserLogo(userIconId)
        if (imgFile) {
           getBase64(imgFile).then(result => {
              self.userImg = result
           })
        }
        
      }
    },
    // 去个人中心页面
    gotoPersonCenter () {
      var path = '/personCenter'
      path = basepath + path
      this.$router.push({path: path})
    },
    // 跳转到授权页面
    gotoAuthPage () {
      var path = '/CustomerManagement/platformInfo'
      path = basepath + path
      this.$router.push({path: path, query:{from: 'customerIndex', state: this.tenancy_service.service_state}})
    },
    // 查看工单
    watchOrder () {
      var path = '/systemOperation/serviceOrder'
      path = basepath + path
      this.$router.push({path: path})
    },
    // 跳转机构列表页面
    gotoInstituteListPage () {
      var path = '/MedicalInstitution/institutionList'
      path = basepath + path
      this.$router.push({path: path})
    },
    // 跳转用户列表页面
    gotoUserListPage () {
      var path = '/CustomerUser/userList'
      path = basepath + path
      this.$router.push({path: path})
    },
    // 跳转到数据存储页面
    gotoDataBase () {
      var path = '/dataStorage/storageDevice'
      path = basepath + path
      this.$router.push({path: path})
    },
    // 客户管理的大屏
    gotoDataCockpit (item) {
      // var href = configUrl.frontEndUrl + basepath + '/customerDataCockpit/index'
      // window.open(href, '_blank')
      window.open(item.url, '_blank')
    },
    // 跳转到放射pacs的数据大屏
    gotoRisDataCockpit () {
      var href = configUrl.frontEndUrl + basepath + '/departMentDataCockpit/index'
      window.open(href, '_blank')
    },
    async getTenancyTotal () {
      const self = this
      self.authArr = []
      const res = await getTenancyStatistics(self.totalParam)
      if (res.code === 0) {
        self.loading = false
        self.showApplyAuth = true
        self.tenancyTotalData = res.data
        self.tenancy_service = res.data.tenancy_service
        if (res.data.tenancy_service.service_name) {
          self.opendedService = res.data.tenancy_service.service_name.split('、')
        }
        var xInstitutedata = []
        var instituteChartData = []
        var totalInstitute = 0
        if (res.data.institution_level.length === 0) {
          self.hasInstitution = false
        } else {
          res.data.institution_level.forEach((val) => {
            if (val.count !== 0) {
              self.hasInstitution = true
            }
            totalInstitute = totalInstitute + val.count
            xInstitutedata.push(val.level_name)
            var obj = {
              name:val.level_name,
              value: val.count
            }
            instituteChartData.push(obj)
          })
        }
        // 处理医务人员的数据
        var xDoctordata = []
        var doctorChartData = []
        var totalDoctor = 0
        if (res.data.user_title_kind.length === 0) {
          self.hasDoctor = false
        } else {
          res.data.user_title_kind.forEach((val) => {
            if (val.count !== 0) {
              self.hasDoctor = true
            }
            totalDoctor = totalDoctor + val.count
            xDoctordata.push(val.title_kind)
            var obj = {
              name:val.title_kind,
              value: val.count
            }
            doctorChartData.push(obj)
          })
        }
        // 武汉项目 程勇超 2023年12月12号 说不需要展示医疗设备 
        // 处理设备的数据 (注意：授权了云pacs 才有相应的设备) 
        // if (self.tenancyTotalData.hasOwnProperty('system_equipment')) {
        //   self.showDevice = true
        //   var xDevicedata = []
        //   var deviceChartData = []
        //   var totalDevice = 0
        //   if (res.data.system_equipment.length === 0) {
        //     self.hasDevice = false
        //   } else {
        //     res.data.system_equipment.forEach((val) => {
        //       if (val.count !== 0) {
        //         self.hasDevice = true
        //       }
        //       totalDevice = totalDevice + val.count
        //       xDevicedata.push(val.office_type_name)
        //       var obj = {
        //         name:val.office_type_name,
        //         value: val.count
        //       }
        //       deviceChartData.push(obj)
        //     })
        //   }
        //   self.$nextTick(() => {
        //     if (self.hasDevice) {
        //       self.makePieChart('pieDeviceChart', totalDevice, deviceChartData, xDevicedata)
        //     }  
        //   })
          
        // } else {
        //   self.showDevice = false
        // }
        if (self.hasInstitution) {
          self.makePieChart('pieInstituteChart', totalInstitute, instituteChartData, xInstitutedata)
        }
        if (self.hasDoctor) {
          self.makePieChart('pieDoctorChart', totalDoctor, doctorChartData, xDoctordata)
        }
        // 画折线图
        if (self.tenancyTotalData.hasOwnProperty('idcas')) {
            self.showImageShare = true
            self.authArr.push('imageShare')
            var idcaItemData = []
            var yidcaData = []
            res.data.idcas.data.forEach((one) => {
              idcaItemData.push(one.name)
              one.type = 'line'
              one.smooth = true
              yidcaData.push(one)
            })
            self.$nextTick(() => {
              // self.makeLineChart('imageShareChart', '检查检验量趋势', idcaItemData, res.data.idcas.dates, yidcaData)
              self.makeLineChart('imageShareChart', '', idcaItemData, res.data.idcas.dates, yidcaData)
            })
        } else {
          self.showImageShare = false
        }
        if (self.tenancyTotalData.hasOwnProperty('pacs_examine')) {
            self.showPacs = true
            self.authArr.push('pacs')
            var pacsItemData = []
            var ypacsData = []
            res.data.pacs_examine.data.forEach((one) => {
              pacsItemData.push(one.name)
              one.type = 'line'
              one.smooth = true
              ypacsData.push(one)  
            })
            self.$nextTick(() => {
              //self.makeLineChart('pacsLineChart', '检查工作量趋势', pacsItemData, res.data.pacs_examine.dates, ypacsData)
              self.makeLineChart('pacsLineChart', '', pacsItemData, res.data.pacs_examine.dates, ypacsData)
            })
        } else {
          self.showPacs = false
        }
        if (self.tenancyTotalData.hasOwnProperty('service_center_item')) {
          self.showServiceCenter = true
          self.authArr.push('serviceCenter')
          var centerItemData = []
          var ycenterData = []
          res.data.service_center_item.data.forEach((one) => {
            centerItemData.push(one.name)
            one.type = 'line'
            one.smooth = true
            ycenterData.push(one)
          })
          self.$nextTick(() => {
            //self.makeLineChart('serviceCenterChart','服务量/申请量趋势', centerItemData, res.data.service_center_item.dates ,ycenterData)
            self.makeLineChart('serviceCenterChart','', centerItemData, res.data.service_center_item.dates ,ycenterData)
          })
        } else {
          self.showServiceCenter = false
        }
        // 武汉项目 程勇超 2023年12月12号 说不需要展示远程培训趋势图 即便开通了远程教学服务也不展示 
        //画远程培训趋势图
        // if (self.tenancyTotalData.telemedicine && self.tenancyTotalData.telemedicine.hasOwnProperty('daily_educations')) {
        //   self.showEducation = true
        //   self.authArr.push('education')
        //   var centerItemData = []
        //   var barAndLineData = []
        //   centerItemData.push(self.tenancyTotalData.telemedicine.daily_educations.data[0].name)
        //   centerItemData.push(self.tenancyTotalData.telemedicine.daily_educations.data[1].name)
        //   // 条形图数据
        //   let oneBarObj = {
        //     type: 'bar',
        //     name: self.tenancyTotalData.telemedicine.daily_educations.data[0].name,
        //     yAxisIndex: 1,
        //     itemStyle: { //柱状图 柱子的颜色
        //       normal: {
        //         color: function(params) {
        //           return '#0092F1'
        //         },
        //       }
        //     },
        //     data: self.tenancyTotalData.telemedicine.daily_educations.data[0].data,
        //   }
        //   barAndLineData.push(oneBarObj)
        //   // 折线图数据
        //   let lineObj = {
        //     type: 'line',
        //     smooth: true,
        //     name: self.tenancyTotalData.telemedicine.daily_educations.data[1].name,
        //     itemStyle : {  // 折线图 折线的颜色
        //       normal : {  
        //         color:'#2EBC58',  
        //         lineStyle:{  
        //           color:'#2EBC58'  
        //         }  
        //       }  
        //     }, 
        //     data:self.tenancyTotalData.telemedicine.daily_educations.data[1].data,
        //   }
        //   barAndLineData.push(lineObj)
        //   self.$nextTick(() => {
        //     //self.makeLineChart('wardRoundsChart','服务量/申请量趋势', centerItemData, res.data.service_center_item.dates ,ycenterData)
        //     self.makeLineAndBarChart('distanceTrainingChart','', centerItemData, self.tenancyTotalData.telemedicine.daily_educations.dates ,barAndLineData)
        //   })
        // } else {
        //   self.showEducation = false
        // }

        
        //画条形图 处理工单数据
        var orderChartData = []
        orderChartData.push(self.tenancyTotalData.service_order_state.pending)
        orderChartData.push(self.tenancyTotalData.service_order_state.processing)
        orderChartData.push(self.tenancyTotalData.service_order_state.completed)
        orderChartData.push(self.tenancyTotalData.service_order_state.closed)
        self.totalOrderNum = self.tenancyTotalData.service_order_state.pending + self.tenancyTotalData.service_order_state.processing + self.tenancyTotalData.service_order_state.completed + self.tenancyTotalData.service_order_state.closed
        self.makeBarChart('orderBarChart', orderChartData)
        // 画仪表图
        var percent = res.data.idcas_usage_rate.percentage
        self.use_amount = res.data.idcas_usage_rate.use_amount
        // var usedNum = res.data.dataBase((value * 100) / total).toFixed(2)
        self.makeBearingChart('bearingChart',percent, res.data.idcas_usage_rate.use_amount)
      } else {
        self.loading = false
        self.$message({ type: 'error', message: res.msg })
      }
    },
    async getConstomerInfo (id) {
      const res = await getCostomerinfoByid(id)
      if (res.code === 0) {
        this.customerinfo = res.data.tenancy_info
      }
    },
   getUrlValue (name) {
      var reg = new RegExp(`(^|&)${name}=([^&]*)(&|$)`, 'i')
      var r = null
      if (window.location.href.indexOf('#') === -1) {
        r = window.location.search.substr(1).match(reg)
      } else {
        var search = window.location.href.split('?')
        if (search && search.length > 1) {
          r = search[1].match(reg)
        }
      }
      if (r != null) {
        return unescape(r[2])
      }
      return null
    }
  },
  mounted () {
    if (window.location.pathname.indexOf('/mtyw/') != -1) {
      this.showDataScreen = false
    }
    // 获取登录信息
    const self = this
    if (self.getUrlValue('tenancy_id')) {
      sessionStorage.setItem('EWTenancyId',self.getUrlValue('tenancy_id'))
    }
    
    self.$nextTick(() => {
      const manager = new Mgr()
      manager.getRole().then(function (item) {
        if (item) {
          localStorage.setItem('tenancy_id',item.profile.tenancy_id)
          self.loginInfo = item
          self.getUserIcon()
          // 获取租户详情
          self.getConstomerInfo(item.profile.tenancy_id)
          // 获取大屏列表
          self.getAllLargeScreenList()
        }
      })
    })
    // 获取客户统计
    self.getTenancyTotal()
  }
}
</script>
<style lang="less" scoped>
.customerHome{
  height:100%;
}
.custoemrInfo{
//    height:calc(100% - 46px);
   padding: 5px;
   background: #E4E7ED;
   .customerHead{
     height:136px;
     .headLeft{
       width:330px;
       height:100%;
       margin-right:5px;
       background:#fff;
       padding-top: 25px; 
       padding-left: 20px;
       box-shadow: 0px 1px 3px 0px rgba(0,0,0,0.05);
       .imgIconDiv{
          width: 88px;
          height: 88px;
          margin-right: 12px;
          border-radius: 50%;
          border: 3px solid #ebeef5;
          display: block;
          overflow: hidden; 
          float: left;
       } 
       .userIcon{
         width:86px;
         margin:-1px;
        //  max-height: 80px;
        //  border-radius: 50%;
       }
       .userInfoDiv{
           .userName{
              font-weight: 700;
              color: #000000;
              letter-spacing: 1px;
              font-size:20px;
              margin-bottom:15px;
              width:207px;
              overflow: hidden;
              text-overflow:ellipsis;
              white-space: nowrap;
              line-height: 24px;
              margin-top: 5px;
           }
           .personCenter{
              width: 100px;
              height: 30px;
              background: linear-gradient(#ffbc0f 0%, #ffab00 100%);
              border: 2px solid rgba(254,189,22,0.20);
              border-radius: 17px;
              cursor: pointer;
              text-align: center;
              line-height: 26px;
              color: #fff;
              position: relative;
              i{
                  font-size:20px;
                  position: absolute;
                  top:1px;
                  left: 5px;
              }
              span{
                padding-left:18px;
              }
           }
       }
     }
     .headRight{
       width:calc(100% - 335px);
       height:100%;
       background:#fff;
       padding: 12px;
       padding-top: 0px;
       .serviceAuth{
         color:#000;
         font-size:16px;
         font-weight: 700;
         line-height: 40px;
       }
       .applyAuth{
           font-size:15px;
           color:#0A70B0;
           line-height: 40px;
       }
       .allAuth{
         height:calc(100% - 40px);
       }
       .authCon{
           width:120px;
           height:84px;
           text-align: center;
           background: #58c979;
           border-radius: 3px;
           padding-top:15px;
            .authorize-img{
                font-size:36px!important;
                color:#fff;
                
            }
            .authSucTit{
                font-size:15px;
                color:#fff;
            }
       }
       .noAuth{
          background:#F56C6C;
       }
       .waitAuth{
          background:#FFB95E;
       }
       .serviceModule{
          width:calc(100% - 135px);
          height:100%;
          overflow: hidden; 
          text-overflow: ellipsis;
          display: -webkit-box; 
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2; 
       }
       .noAuthCon{
          width:calc(100% - 135px);
          text-align: center;
          color:#909399;
          span {
            font-size:15px;
            line-height: 50px;
          }
          i {
              font-size:36px!important;
              position: relative;
              top:6px;
          }
       }
       .oneServcieModule{
          padding: 8px 10px;
          color:#303133;
          margin-bottom:10px;
          background:rgba(88,201,121,.2);
          border-radius: 4px;
       }

     }
   }
   .dataStatic::after{
    content: '';
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
   }
   .dataStatic{
    .oneChart{
      width:calc(33.333% - 4px);
      background: #fff;
      .instituteLabel{
         font-size:16px;
         color:#000000;
         padding-left:6px;
         .deviceTip{
            font-size:16px;
            color:#909399;
         }
      }
      #pieInstituteChart{
        height:300px;
        padding: 10px 20px;
      }
      #pieDoctorChart {
        height:300px;
        padding: 10px 20px;
      }
      #pieDeviceChart {
        height:300px;
        padding: 10px 20px;
      }
    }
    // 折线图样式
    .lineChart{
        // width:calc(67% - 8px);
        width:100%;
        background: #fff;
        margin-right:5px;
        #imageShareChart{
          height:300px;
          padding: 10px 20px; 
        }
        #pacsLineChart{
          height:300px;
          padding: 10px 20px;
        }
        #serviceCenterChart{
          height:300px;
          padding: 10px 20px; 
        }
        #distanceTrainingChart{
          height:300px;
          padding: 10px 20px; 
        }
      }
      // 条形图样式
      .barChart{
        width:calc(33% + 3px);
        // width:100%;
        background: #fff;
        position: relative;
        #orderBarChart{
          width:calc(100% - 100px);
          height:300px;
          padding: 10px 10px;
          margin-left:100px;
        }
        .orderCon{
          position: absolute;
          top:110px;
          left:5px;
          .allOrderTit{
            line-height: 40px;
            font-size:15px;
            color:#303133;
            text-align: center;
          }
          .orderTotalNum{
             line-height: 60px;
            font-size:36px;
            color:#303133;
            font-weight: 700;
            text-align: center;
            font-family: arial;
          }
          .addOrderBtn{
            width: 100px;
            height: 30px;
            line-height: 30px;
            background: #0a70b0;
            border-radius: 15px;
            color:#fff;
            font-size:15px;
            text-align: center;
            cursor: pointer;
            position: relative;
            i{
              font-size:20px;
              padding-right:5px;
              position: absolute;
              top: 1px;
              left: 5px;
            }
            span{
              padding-left: 18px;
            }
          }
        }

      }
      // 表盘图
      .dataStaticChart{
        width:calc(33% + 3px);
        // width:100%;
        background: #fff;
        position: relative;
        #bearingChart{
          height:300px;
          padding: 10px 20px;
        } 
      }
      .newDataStaticChart{
        width:calc(33% - 1px);
      }

      .dataBigScreen{
        width:calc(33% + 3px);
        // width:100%;
        background: #fff;
        #bigScreenCon{
          height:300px;
          padding: 20px 15px;
          overflow-y: auto;
          .oneScreen{
            height: 40px;
            line-height: 40px;
            padding: 0 10px;
            background:rgba(236,245,255,1);
            border-radius: 3px;
            font-size:15px;
            color:#0A70B0;
            margin-bottom:15px;
            cursor: pointer;
            .cockpitName{
              display: inline-block;
              max-width:calc(100% - 26px);
              white-space:nowrap;
              overflow:hidden;
              text-overflow:ellipsis;
              color:#303133;
            }
            .oneScreenNameDiv{
              display: flex;
              align-items: center;
              width:calc(100% - 82px);
            }
            .cockpitOperate{
              display: none;
              .delCockpitOperate{
                color:#DA4A4A;
              }
              .splitIcon{
                display: inline-block;
                width:1px;
                height:20px;
                margin:0px 10px;
                position: relative;
                top: 4px;
                background:#0CDFE6;
              }
            }
            i{
              font-size:16px;
              color:'#0a70b0';
              margin-right:10px;
            }
          }
          .oneScreen:hover{
            background:#e1eefb;
            .cockpitName{
              color:#0a70b0!important;
            }
            
          }
        }
      }
   }
}
.chartIcon{
    font-size:16px;
    color:#0A70B0;
}
.instituteLabel{
    font-size:16px;
    color:#000000;
    padding-left:6px;
}
.addInstitute{
    font-size:15px;
    color:#0A70B0;
}
.lineChartTit{
  font-size:14px;
  color:#301333;
  .lineChartTip{
    color:#909399;
    font-size:14px;
  }
}
.chartHead{
  height:45px;
  line-height: 44px;
  padding:0 20px;
  border-bottom:1px solid #F0F0F0;
  .timeChoose{
    line-height: initial;
    margin-top: 8px;
  }
  ::v-deep .el-radio-group{
    height:28px;
    line-height: 26px;
    .el-radio-button__inner{
      height:28px;
      line-height: 26px;
      padding: 0 8px!important;
      color: #303133;
      text-align: center;
    }
    .el-radio-button__orig-radio:checked+.el-radio-button__inner{
       background-color: #fff!important;
       color: #0a70b0;
    }
  }
}
.pointer{
  cursor: pointer;
}
.noChartData{
  background: url('../../../assets/images/indexNoData.png') center no-repeat;
}
.usedStorage{
  position: absolute;
  top: 80%;
  bottom: 10%;
  z-index:990;
  width:100%;
  text-align: center;
  font-size: 26px;
  color: #303133;
  font-weight: 700;
  font-family: Arial;
  text-indent:5px;
}
.unitDesc {
  font-size:16px;
  color:#909399;
}
.needAuthDiv{
  width:calc(67% - 8px);
  margin-right:5px;
  .mr4{
    margin-right:4px;
  }
  .oneChart{
    width:calc(50% - 2px)!important;
  }
}
.noNeedAuthDiv{
  width:calc(33% + 3px);
}
.addMl5{
  margin-left:5px;
}
.noMarginTop{
  margin-top:0px!important;
}
.addDataCockpitCon{
  padding: 30px 0px;
  padding-bottom:0px;
  .logItem::after{
    content: '';
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  ::v-deep .logItem {
    clear:both;
    margin-bottom: 15px;
    position: relative;
    .logLabel{
      width: 120px;
      text-align: right;
      font-size:15px;
      color:#303133;
      height:36px;
      line-height: 36px;
    }
    .ukeyIcon{
      font-size:24px;
      padding-right:5px;
      position: relative;
      top: 3px;
    }
    .ukeyTip{
      font-size:16px;
      color:#e6a23c;
    }
    .doctorName{
      font-size:15px;
      color:#303133;
      line-height: 36px;
    }
    .readCaBtn{
      padding:9px 12px!important;
      margin-left:15px;
    }
    .el-input__inner {
      width:360px;
      height:36px;
      line-height: 34px;
    }
    .passwordInput{
      width:350px;
      .el-input__inner {
        width:350px;
      }
    }
  }
}
.dialog_footer{
  margin-top:40px;
}
</style>