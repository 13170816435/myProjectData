<template>
  <div class="addCenterPage">
    <div class="userinfo-title">
      <span class="userinfo-titleinfo">{{ titletext }}</span>
      <span
        @click="closeFn"
        class="close-btn iconfont iconchuangjianshibai"
      ></span>
    </div>
    <div class="applyCenterCon">
      <div
        class="info_box"
        v-bind:element-loading-text="tipText"
        element-loading-background="rgba(255,255,255,0.6)"
        v-loading="fullScreenLoad"
      >
        <div v-show="step == 1" class="info_step_1">
          <ul class="info_ulList clear">
            <li>
              <span class="fl length_info_label">
                <i class="iconfont iconbitian mustIcon"></i>服务中心：
              </span>
              <el-input
                v-model="applyInfo.name"
                maxlength="25"
                show-word-limit
                type="text"
                class="fl info_input pr8"
              />
            </li>

            <li>
              <span class="fl info_label organNameLabel"
                ><i class="iconfont iconbitian mustIcon"></i>机构名称：</span
              >
              <!-- <el-select class="fl organ-select alertFormSelect width_360_select organNameSec" v-model="choosedOrganName" @change="chooseOrgan"> -->
              <el-select
                class="fl organ-select alertFormSelect width_360_select organNameSec"
                multiple
                collapse-tags
                filterable
                v-model="applyInfo.institution_ids"
                @change="chooseOrgan"
              >
                <!-- <el-option value>请选择</el-option> -->
                <el-option
                  v-for="(item, index) in InstitutionsArr"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
            </li>

            <li>
              <span class="fl info_label organNameLabel">
                <i class="iconfont iconbitian mustIcon"></i>管理人员：
              </span>
              <el-select
                filterable
                class="fl organ-select alertFormSelect width_180_select organNameSec"
                v-model="applyInfo.manager_id"
                @change="chooseManager"
              >
                <el-option value="">请选择</el-option>
                <el-option
                  v-for="(item, index) in allManagerArr"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
              <input
                v-model="applyInfo.manager_phone"
                placeholder="手机号码"
                type="text"
                disabled
                class="fl input_175 pr8 ml5"
              />
            </li>

            <li>
              <span class="fl info_label organNameLabel">二级域名：</span>
              <el-input
                v-model="applyInfo.domain"
                type="text"
                class="fl info_input pr8"
              />
            </li>

            <weChat
              :weChatObj="providersObj"
              :inputWidth="'236px'"
              style="margin-left: 22px"
            ></weChat>

            <li>
              <span class="fl organNameLabel info_label openModuleDiv"
                ><i class="iconfont iconbitian mustIcon"></i>使用期限：</span
              >
              <div style="display: flex; align-items: center">
                <el-date-picker
                  v-model="applyInfo.start_date"
                  type="date"
                  placeholder="选择开始期限"
                  value-format="yyyy-MM-dd"
                >
                </el-date-picker>
                <el-radio-group v-model="applyInfo.isIndefinitely" class="ml20">
                  <el-radio :label="true">无期限</el-radio>
                  <el-radio :label="false">
                    <el-date-picker
                      v-model="applyInfo.stop_date"
                      type="date"
                      :disabled="applyInfo.isIndefinitely"
                      placeholder="选择结束期限"
                      value-format="yyyy-MM-dd"
                    >
                    </el-date-picker>
                  </el-radio>
                </el-radio-group>
              </div>
            </li>
            <li>
              <span class="fl organNameLabel info_label openModuleDiv"
                ><i class="iconfont iconbitian mustIcon"></i>系统状态：</span
              >
              <div style="display: flex; align-items: center; height: 36px">
                <el-radio-group v-model="applyInfo.state" class="ml20">
                  <el-radio :label="10">启用</el-radio>
                  <el-radio :label="-2">停用</el-radio>
                </el-radio-group>
                <el-input
                  v-if="applyInfo.state === -2"
                  v-model="applyInfo.reason"
                  class="ml10"
                  placeholder="备注"
                  style="width: 180px"
                />
              </div>
            </li>

            <li>
              <span class="fl organNameLabel info_label"
                ><i class="iconfont iconbitian mustIcon"></i>开通服务：</span
              >
              <el-checkbox-group v-model="applyInfo.services">
                <el-checkbox
                  v-for="(item, index) in serviceArr"
                  v-bind:key="index"
                  class="fl openModule"
                  v-bind:label="item.service_code"
                  border
                  >{{ item.name }}</el-checkbox
                >
              </el-checkbox-group>
            </li>
            <li class="fl uploadLi">
              <div class="fl mr22">
                <div class="logoCon">
                  <span class="logoTit"
                    ><i class="iconfont iconbitian mustIcon"></i
                    >服务中心logo</span
                  >
                  <span class="logoTip">(用于远程医疗模块)</span>
                </div>
                <div class="uploadMettingImg serviceCenterUpload">
                  <uploadImg
                    class="uploadImgComponent"
                    @chooseUploadImg="chooseUploadImg"
                    :imgClass="'logo'"
                    @uploadSuc="uploadImgSucceed"
                    :UploadSrc="UploadSrc"
                    :isAutoUpload="isAutoUpload"
                    :ImgSrc="currentLogoSrc"
                  ></uploadImg>
                </div>
              </div>
              <div class="fl mr22">
                <div class="logoCon">
                  <span class="logoTit">服务中心Banaer</span>
                  <span class="logoTip">(用于服务中心门户)</span>
                </div>
                <div class="uploadMettingImg serviceCenterUpload">
                  <uploadImg
                    class="uploadImgComponent"
                    @chooseUploadImg="chooseUploadImg"
                    @uploadSuc="uploadImgSucceed"
                    :imgClass="'banner'"
                    :UploadSrc="UploadSrc"
                    :ImgSrc="currentBannerSrc"
                    :isAutoUpload="isAutoUpload"
                  ></uploadImg>
                </div>
              </div>
            </li>
            <li class="clear uploadLi">
              <div class="fl">
                <div class="logoCon">
                  <span class="logoTit">宣传图</span>
                  <span class="logoTip">(用于中心简介)</span>
                </div>
                <div class="uploadMettingImg serviceCenterUpload">
                  <uploadImg
                    class="uploadImgComponent"
                    @chooseUploadImg="chooseUploadImg"
                    @uploadSuc="uploadImgSucceed"
                    :imgClass="'advertise'"
                    :UploadSrc="UploadSrc"
                    :ImgSrc="currentAdvertiseSrc"
                    :isAutoUpload="isAutoUpload"
                  ></uploadImg>
                </div>
              </div>
            </li>
            <li class="clear mb0">
              <div v-if="!meetingImageUrl" class="el-upload__tip" slot="tip">
                注：所有上传图片仅支持jpg、jpeg、bmp、gif、png格式;大小不超过2M
              </div>
            </li>
            <li class="editCon">
              <div class="fl centerIntroTit">
                <i class="iconfont iconbitian mustIcon"></i>中心简介：
              </div>
              <quill-editor
                ref="text"
                v-model="applyInfo.introduction"
                class="myQuillEditor clear"
                :options="editorOption"
                @change="onEditorChange($event)"
              />
              <form
                action=""
                method="post"
                enctype="multipart/form-data"
                id="uploadFormMulti"
              >
                <input
                  style="display: none"
                  :id="uniqueId"
                  type="file"
                  name="files"
                  multiple
                  accept="image/jpg,image/jpeg,image/png,image/gif"
                  @change="uploadEditImg('uploadFormMulti')"
                />
              </form>
              <span class="wordNumber">{{ TiLength }}/500</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="btnCon mt15">
      <!-- <button type="button" size="medium"  class="nextStepBtn operateBtn" @click="nextStep">提交</button> -->
      <el-button type="primary" size="medium" @click="nextStep">提交</el-button>
      <el-button size="medium" class="ml10" @click="closeFn">取消</el-button>
    </div>
  </div>
</template>
//
<script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
<script>
import Vue from "vue";
import JSEncrypt from "@/utils/jsencrypt.min";
import uploadImg from "@/components/common/uploadImg";
import { quillEditor } from "vue-quill-editor";
import Quill from "quill";
import "quill/dist/quill.core.css";
import "quill/dist/quill.snow.css";
import "quill/dist/quill.bubble.css";
import weChat from "@/components/common/weChat";
import {
  addSeviceCenter,
  getInstitutionServices,
  getInstitutions,
  getServiceCenterDetail,
  getAllManager,
  updateServiceCenterData,
  getUploadSrc,
  uploadFile,
  getEditImg,
  getUserPhone,
} from "@/api/platform_costomer/telemedicine";
import {
  getImgSrcById,
  getConstants,
  getServiceAdervise,
  getServiceBanner,
  getServiceLogo,
  getConfigurations,
  uploadMediaFile,
  getUploadImg,
} from "@/api/commonHttp";
import { getBase64, connectUrlParam } from "@/components/commonJs";
import moment from "moment";

export default {
  components: {
    quillEditor,
    uploadImg,
    weChat,
  },
  data() {
    return {
      managerName: "",
      titletext: "开设",
      choosedOrganName: "",
      checked2: false,
      step: 1,
      isCollectImg: false,
      fullScreenLoad: false,
      checked1: true,
      allSeviceInfor: [],
      content: "", // 编辑器内容
      editorOption: {
        placeholder: "请输入服务中心简介...",
        modules: {
          toolbar: [
            ["bold", "italic", "underline", "strike"], // toggled buttons
            ["blockquote", "code-block", "image"],
          ],
          clipboard: {
            // 粘贴过滤
            matchers: [[Node.ELEMENT_NODE, this.HandleCustomMatcher]],
          },
        },
      }, // 编辑器操作选项
      InstitutionsArr: [], // 所有的机构
      allManagerArr: [], // 所有的管理员
      healthCardTypeList: [
        {
          DicCode: 123,
          DicName: "邵逸夫医院",
        },
        {
          DicCode: 234,
          DicName: "杭州人民医院",
        },
      ],
      addSeviceCenterForm: "",
      providersObj: {
        // 需要特殊处理
        app_id: "",
        app_secret: "",
      },
      applyInfo: {
        institution_ids: "",
        name: "",
        manager_id: "",
        manager_name: "",
        manager_phone: "",
        introduction: "",
        services: [],
        domain: "",
        isIndefinitely: true, // 是否无限期
        start_date: "", // 开始期限
        stop_date: null, // 结束期限
        state: 10, // 启用状态
        reason: "", // 停用原因
        // providers: [
        //   {
        //     app_id: "",
        //     app_secret: "",
        //   }
        // ]
      },
      tipText: "",
      TiLength: 0,
      servicecenterLogo: "", // 服务中心logo
      servicecenterBanaer: "", // 服务中心banaer
      meetingImageUrl: "",
      applyType: 0, // 代表申请
      institutionServiceArr: [], // 某机构下开通的服务
      serviceArr: [], // 所有的服务
      currentLogoSrc: "",
      currentBannerSrc: "",
      currentAdvertiseSrc: "",
      operateId: "",
      UploadSrc: configUrl.apiUrl + "/img/upload",
      isAutoUpload: true, // 是否自动上传图片
      logo_id: "",
      banner_id: "",
      advertise_id: "",
      addImgRange: "",
      uniqueId: "testUpload",
      detailService: [],
    };
  },
  methods: {
    closeFn() {
      this.$emit("closeFn");
    },
    HandleCustomMatcher(node, Delta) {
      // 文字，从别处复制而来，清除自带样式，转为纯文本
      if (node.src && node.src.indexOf("data:image/png") > -1) {
        Delta.ops = [];
        return Delta;
      }
      let ops = [];
      Delta.ops.forEach((op) => {
        if (op.insert && typeof op.insert === "string") {
          ops.push({
            insert: op.insert,
          });
        } else if (op.insert && typeof op.insert.image === "string") {
          ops.push({
            insert: op.insert,
          });
        }
      });
      Delta.ops = ops;
      return Delta;
    },
    async getConfigurationsFn() {
      const res = await getConfigurations("TransmissionSecurity.RSA.PublicKey");
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) {
          // 注册方法
          const pubKey = res.data; // ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt();
          encryptStr.setPublicKey(pubKey); // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()); // 进行加密
          return data;
        };
      }
    },
    onEditorChange(e) {
      e.quill.deleteText(500, 4); // 从第500个开始删除，删除4个
      if (this.$refs.text.value === "") {
        this.TiLength = 0;
      } else {
        this.TiLength = e.quill.getLength() - 1;
      }
    },
    // 获取所有开通的服务
    async getMyAllService() {
      const self = this;
      const res = await getInstitutionServices();
      if (res.code === 0) {
        self.serviceArr = res.data;
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    chooseUploadImg(file, className, bool) {
      this.isCollectImg = bool;
      if (className === "logo") {
        this.servicecenterLogo = URL.createObjectURL(file);
      } else if (className === "banner") {
        this.servicecenterBanaer = URL.createObjectURL(file);
      } else {
        this.meetingImageUrl = URL.createObjectURL(file);
      }
    },
    async uploadImgSucceed(params, className) {
      if (this.isCollectImg) {
        let res;
        let param = {
          file_name: params.file.name,
          //file_sha: '123',
          file_size: params.file.size,
          position: 0,
          file_type: 0,
        };
        let paramUrl = connectUrlParam(param);
        const formData = new FormData();
        if (className === "logo") {
          formData.append("file", params.file);
          res = await uploadMediaFile(formData, paramUrl);
        } else if (className === "banner") {
          formData.append("file", params.file);
          res = await uploadMediaFile(formData, paramUrl);
        } else {
          formData.append("file", params.file);
          res = await uploadMediaFile(formData, paramUrl);
        }
        if (res.code == 0) {
          if (className === "logo") {
            // 手写签名
            this.currentLogoSrc = URL.createObjectURL(params.file);
            this.addSeviceCenterForm.delete("logo_id");
            this.addSeviceCenterForm.append("logo_id", res.document_id);
          } else if (className === "banner") {
            this.currentBannerSrc = URL.createObjectURL(params.file);
            this.addSeviceCenterForm.delete("banner_id");
            this.addSeviceCenterForm.append("banner_id", res.document_id);
          } else {
            this.currentAdvertiseSrc = URL.createObjectURL(params.file);
            this.addSeviceCenterForm.delete("advertise_id");
            this.addSeviceCenterForm.append("advertise_id", res.document_id);
          }
        } else {
          this.$message({ type: "error", message: res.msg });
        }
      }
    },
    chooseOrgan(val) {
      // this.applyInfo.manager_name = ''
      // this.applyInfo.manager_id = ''
      if (val.length === 0) {
        this.applyInfo.manager_name = "";
        this.applyInfo.manager_id = "";
        this.applyInfo.manager_phone = "";
        this.allManagerArr = [];
      } else {
        this.getMyManager(val);
      }
    },
    chooseManager(id) {
      const self = this;
      if (!id) {
        self.applyInfo.manager_name = "";
        self.applyInfo.manager_phone = "";
        return false;
      }
      self.allManagerArr.forEach((item) => {
        if (item.id === id) {
          self.applyInfo.manager_name = item.name;
        }
      });
      self.getOneUserPhone(id);
    },
    async getOneUserPhone(userId) {
      const res = await getUserPhone({ id: userId });
      if (res.code === 0) {
        this.applyInfo.manager_phone = res.data.phone;
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // 获取某机构下开通的服务
    async getInstitutionServices(instituId) {
      const res = await getInstitutionServices({ institution_id: instituId });
      if (res.code === 0) {
        this.institutionServiceArr = res.data;
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    validateSub() {
      const phoneExe = /^1(3|4|5|7|8)\d{9}$/;
      if (!this.applyInfo.name) {
        this.$message({ message: "请输入服务中心名称", type: "error" });
        return false;
      }
      if (this.applyInfo.institution_ids.length === 0) {
        this.$message({ message: "请选择机构", type: "error" });
        return false;
      }
      if (!this.applyInfo.manager_name) {
        this.$message({ message: "请选择管理员", type: "error" });
        return false;
      }
      var re =
        /^(?=^.{3,255}$)(http(s)?:\/\/)(www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\d+)*(\/\w+)*\/$/;
      if (this.applyInfo.domain && !re.test(this.applyInfo.domain)) {
        this.$message({ message: "请输入正确的域名！", type: "error" });
        return false;
      }
      // if (!this.applyInfo.manager_phone) {
      //   this.$message({ message: '请输入管理员手机号码', type: 'error' })
      //   return false
      // }
      // // 新增的时候验证 编辑的时候不需要因为不可修改
      // if ((!this.$route.query.id) && !phoneExe.test(this.applyInfo.manager_phone)) {
      //   this.$message({ message: '请输入正确的手机号', type: 'error' })
      //   return false
      // }
      if (!this.operateId && !this.servicecenterLogo) {
        this.$message({ message: "请上传服务中心LOGO", type: "error" });
        return false;
      }
      if (!this.$refs.text.value) {
        this.$message({ message: "请输入中心简介", type: "error" });
        return false;
      }

      if (!this.applyInfo.start_date) {
        this.$message({ type: "error", message: "请选择使用开始期限" });
        return false;
      }
      if (!this.applyInfo.isIndefinitely && !this.applyInfo.stop_date) {
        this.$message({ type: "error", message: "请选择使用结束期限" });
        return false;
      }
      if (!this.applyInfo.state) {
        this.$message({ type: "error", message: "请选择系统状态" });
        return false;
      }
      if (this.applyInfo.state === -2 && !this.applyInfo.reason) {
        this.$message({ type: "error", message: "请输入停用备注" });
        return false;
      }

      return true;
    },
    deleteFormDataKey() {
      this.addSeviceCenterForm.delete("institution_ids");
      if (this.InstitutionsArr.length !== 0) {
        for (let i = 0; i < this.InstitutionsArr.length; i++) {
          this.addSeviceCenterForm.delete("institution_ids[" + i + "]");
        }
      }
      this.addSeviceCenterForm.delete("name");
      this.addSeviceCenterForm.delete("manager_id");
      this.addSeviceCenterForm.delete("manager_name");
      this.addSeviceCenterForm.delete("manager_phone");
      this.addSeviceCenterForm.delete("introduction");
      this.addSeviceCenterForm.delete("services");
      this.addSeviceCenterForm.delete("providers");
      this.addSeviceCenterForm.delete("id");
      this.addSeviceCenterForm.delete("domain");
      this.addSeviceCenterForm.delete("start_date");
      this.addSeviceCenterForm.delete("stop_date");
      this.addSeviceCenterForm.delete("state");
      this.addSeviceCenterForm.delete("reason");

      // 开通的服务
      if (this.detailService.length !== 0) {
        for (let i = 0; i < this.detailService.length; i++) {
          this.addSeviceCenterForm.delete("services[" + i + "].service_code");
        }
      }
    },
    setFormDataValue() {
      if (this.applyInfo.institution_ids.length > 0) {
        for (let i = 0; i < this.applyInfo.institution_ids.length; i++) {
          this.addSeviceCenterForm.delete("institution_ids[" + i + "]"); // 目的是防止 append添加重复的
          this.addSeviceCenterForm.append(
            "institution_ids[" + i + "]",
            this.applyInfo.institution_ids[i]
          );
        }
      }
      // this.addSeviceCenterForm.append('institution_ids', this.applyInfo.institution_ids)
      this.addSeviceCenterForm.append("name", this.applyInfo.name);
      this.addSeviceCenterForm.append("manager_id", this.applyInfo.manager_id);
      if (this.applyInfo.domain) {
        this.addSeviceCenterForm.append("domain", this.applyInfo.domain);
      }
      this.addSeviceCenterForm.append(
        "manager_name",
        this.applyInfo.manager_name
      );
      this.addSeviceCenterForm.append(
        "manager_phone",
        this.$getRsaCode(this.applyInfo.manager_phone)
      );
      this.addSeviceCenterForm.append(
        "introduction",
        this.applyInfo.introduction
      );
      if (this.applyInfo.services.length > 0) {
        for (let i = 0; i < this.applyInfo.services.length; i++) {
          this.addSeviceCenterForm.set(
            "services[" + i + "].service_code",
            this.applyInfo.services[i]
          );
        }
      } else {
        this.addSeviceCenterForm.append("services", []);
      }

      // 赋值微信公众号信息
      if (this.providersObj.app_id) {
        this.addSeviceCenterForm.set(
          "providers[" + 0 + "].app_id",
          this.providersObj.app_id
        );
      }
      if (this.providersObj.app_secret) {
        this.addSeviceCenterForm.set(
          "providers[" + 0 + "].app_secret",
          this.providersObj.app_secret
        );
      }
      this.addSeviceCenterForm.set(
        "providers[" + 0 + "].provider_name",
        "WeChat"
      );

      this.addSeviceCenterForm.append("start_date", this.applyInfo.start_date);
      if (!this.applyInfo.isIndefinitely) {
        this.addSeviceCenterForm.append("stop_date", this.applyInfo.stop_date);
      }

      this.addSeviceCenterForm.append("state", this.applyInfo.state);
      if (this.applyInfo.state === -2 && this.applyInfo.reason) {
        this.addSeviceCenterForm.append("reason", this.applyInfo.reason);
      }
    },
    async beganAdd() {
      this.deleteFormDataKey();
      this.setFormDataValue();
      this.tipText = "正在初始化服务中心，请稍候";
      this.fullScreenLoad = true;
      const res = await addSeviceCenter(this.addSeviceCenterForm);
      if (res.code === 0) {
        this.fullScreenLoad = false;
        this.$message({ message: "添加服务中心成功", type: "success" });
        this.$emit("updateOrAddSuc");
        // var path = process.env.NODE_ENV === "development" ? "/" : "/operate/";
        // this.$router.push({ path: `${path}telemedicine/servicecenter` });
      } else {
        this.fullScreenLoad = false;
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    async readyUpdateServiceCenterData() {
      this.deleteFormDataKey();
      this.setFormDataValue();
      this.tipText = "正在修改请稍候";
      this.fullScreenLoad = true;
      this.addSeviceCenterForm.append("id", this.operateId);
      console.log(Object.fromEntries(this.addSeviceCenterForm), "99999999999");
      const res = await updateServiceCenterData(
        this.addSeviceCenterForm,
        this.operateId
      );
      if (res.code === 0) {
        this.fullScreenLoad = false;
        this.$emit("updateOrAddSuc");
        this.$message({ message: "编辑服务中心成功", type: "success" });
      } else {
        this.fullScreenLoad = false;
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    async nextStep() {
      if (this.validateSub()) {
        // 编辑
        if (this.operateId) {
          this.readyUpdateServiceCenterData();
        } else {
          this.beganAdd();
        }
      }
    },
    finishApply() {
      this.$router.push({ name: "servicecenter" });
    },
    // 获取机构
    async getMyInstitutions() {
      const res = await getInstitutions();
      this.InstitutionsArr = res.data;
    },
    async getMyServiceCenterDetail(serviceCenterId) {
      this.UploadSrc = getUploadSrc();
      const res = await getServiceCenterDetail({ id: serviceCenterId });
      if (res.code === 0) {
        this.operateId = res.data.id;
        this.applyInfo.institution_ids = res.data.institution_ids;
        this.choosedOrganName = res.data.institution_name;
        this.applyInfo.name = res.data.name;
        this.applyInfo.manager_id = res.data.manager_id;
        this.applyInfo.manager_name = res.data.manager_name;
        this.applyInfo.manager_phone = res.data.manager_phone;
        this.applyInfo.domain = res.data.domain;
        this.applyInfo.introduction = res.data.introduction;
        this.applyInfo.services = [];

        this.applyInfo.isIndefinitely =
          res.data.stop_date === "无期限" ? true : false;
        this.applyInfo.start_date = res.data.start_date;
        this.applyInfo.stop_date =
          res.data.stop_date === "无期限" ? "" : res.data.stop_date;
        this.applyInfo.state = res.data.state;
        this.applyInfo.reason = res.data.reason;

        if (res.data.providers.length != 0) {
          this.providersObj = res.data.providers[0];
        }

        await this.getMyManager(res.data.institution_ids);
        // 判断一下该管理员是否被删除
        let isHasManager = false;
        if (this.allManagerArr.length !== 0) {
          this.allManagerArr.forEach((val) => {
            if (val.id === this.applyInfo.manager_id) {
              isHasManager = true;
            }
          });
        }

        if (!isHasManager) {
          this.applyInfo.manager_id = "";
          this.applyInfo.manager_name = "";
          this.applyInfo.manager_phone = "";
        }

        this.choosedOrganName = res.data.institution_name;
        this.detailService = [];
        for (let i = 0; i < res.data.services.length; i++) {
          this.applyInfo.services.push(res.data.services[i].service_code);
          this.detailService.push(res.data.services[i].service_code);
        }
        if (res.data.logo_id) {
          this.logo_id = res.data.logo_id;
          getServiceLogo(res.data.id)
            .then((res) => {
              if (res) {
                getBase64(res).then((resinfo) => {
                  this.currentLogoSrc = resinfo;
                });
              } else {
                this.currentLogoSrc = "";
              }
            })
            .catch((error) => {
              this.currentLogoSrc = "";
            });
        } else {
          this.currentLogoSrc = "";
        }
        if (res.data.banner_id) {
          this.banner_id = res.data.banner_id;
          getServiceBanner(res.data.id)
            .then((res) => {
              if (res) {
                getBase64(res).then((resinfo) => {
                  this.currentBannerSrc = resinfo;
                });
              } else {
                this.currentBannerSrc = "";
              }
            })
            .catch((error) => {
              this.currentBannerSrc = "";
            });
        } else {
          this.currentBannerSrc = "";
        }
        if (res.data.advertise_id) {
          getServiceAdervise(res.data.id)
            .then((res) => {
              if (res) {
                getBase64(res).then((resinfo) => {
                  this.currentAdvertiseSrc = resinfo;
                });
              } else {
                this.currentAdvertiseSrc = "";
              }
            })
            .catch((error) => {
              this.currentAdvertiseSrc = "";
            });
        } else {
          this.currentAdvertiseSrc = "";
        }
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    async getMyManager(arr) {
      const self = this;
      let param = "";
      let str;
      if (arr) {
        arr.forEach((val, i) => {
          if (i === 0) {
            str = `?ids[0]=` + val;
          } else {
            str = `&ids[${i}]=` + val;
          }
          param = param + str;
        });
      }
      const res = await getAllManager(param);
      // const res = await getAllManager()
      if (res.code === 0) {
        self.allManagerArr = res.data;
        // 特殊处理  当改变机构时 如果接口里面返回的管理员还有 之前选择的管理员时就不清空管理员姓名和管理员手机号
        let hasThisManager = false;
        if (self.allManagerArr && self.allManagerArr.length !== 0) {
          self.allManagerArr.forEach((val) => {
            if (val.id === self.applyInfo.manager_id) {
              hasThisManager = true;
            }
          });
        }
        // 如果改变机构后 接口返回的管理员里面 没有之前设置的管理员的话 得把管理员信息清空
        if (!hasThisManager) {
          self.applyInfo.manager_id = "";
          self.applyInfo.manager_name = "";
          self.applyInfo.manager_phone = "";
        }
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    async getMyConstants() {
      const res = await getConstants();
      this.allSeviceInfor = res.available_service;
    },
    initFormData() {
      this.applyInfo = {
        institution_ids: "",
        name: "",
        manager_id: "",
        manager_name: "",
        manager_phone: "",
        introduction: "",
        services: [],
        isIndefinitely: true, // 是否无限期
        start_date: moment().format("YYYY-MM-DD"), // 开始期限
        stop_date: null, // 结束期限
        state: 10, // 启用状态
        reason: "", // 停用原因
      };
      this.currentLogoSrc = "";
      this.currentBannerSrc = "";
      this.currentAdvertiseSrc = "";
    },
    async uploadEditImg(id) {
      var vm = this;
      var obj = document.getElementById("uploadFormMulti");
      // 获取文件对象
      var fileObj = document.getElementById(vm.uniqueId);
      var file = fileObj.files[0];
      var fileName = file.name;
      var fileSize = file.size;
      var formData = new FormData(obj);
      formData.append("file_name", fileName);
      try {
        vm.uploadImgReq(formData, fileName, fileSize); // 自定义的图片上传函数
      } catch ({ message: msg }) {
        document.getElementById(vm.uniqueId).value = "";
        vm.$message.warning(msg);
      }
    },
    // 下载图片
    downloadImg(file_id) {
      const vm = this;
      var src =
        configUrl.docUrl +
        "/api-document/download/document-id?document_id=" +
        file_id +
        "&is_crm_document=true";
      vm.addImgRange = vm.$refs.text.quill.getSelection();
      vm.$refs.text.quill.insertEmbed(
        vm.addImgRange != null ? vm.addImgRange.index : 0,
        "image",
        src,
        Quill.sources.USER
      );
    },

    async uploadImgReq(myformData, file_name, file_size) {
      // 这里实现你自己的图片上传
      var vm = this;
      let param = {
        file_name: file_name,
        file_size: file_size,
        position: 0,
        file_type: 0,
      };
      let paramUrl = connectUrlParam(param);
      const res = await uploadMediaFile(myformData, paramUrl);
      if (res.code === 0) {
        const result = res;
        // 获取图片
        vm.downloadImg(result.document_id);
      }
    },
    initAdd() {
      this.titletext = "开设本系统服务中心";
      this.choosedOrganName = "";
      this.operateId = "";
      this.initFormData();
    },
    initEdit(id) {
      this.titletext = "编辑本系统服务中心";
      this.getMyServiceCenterDetail(id);
    },
  },
  created() {
    var vm = this;
    // 编辑
    // if (vm.$route.query.id) {
    //   vm.isAutoUpload = true;
    // } else {
    //   vm.isAutoUpload = false;
    // }
  },
  mounted() {
    var vm = this;
    // 加密
    vm.getConfigurationsFn();
    var imgHandler = async function (image) {
      vm.addImgRange = vm.$refs.text.quill.getSelection();
      if (image) {
        var fileInput = document.getElementById(vm.uniqueId); //隐藏的file文本ID
        fileInput.click(); //加一个触发事件
      }
    };
    vm.$nextTick(() => {
      vm.$refs.text.quill.getModule("toolbar").addHandler("image", imgHandler);
      vm.addSeviceCenterForm = new FormData();
      // 获取管理员
      // vm.getMyManager()
      vm.getMyInstitutions();
      vm.getMyConstants().then(() => {
        vm.getMyAllService();
      });
    });

    // 编辑
    // if (vm.$route.query.id) {
    //   vm.titletext = "编辑";
    //   vm.getMyServiceCenterDetail(vm.$route.query.id);
    // } else {
    //   vm.titletext = "开设";
    //   vm.choosedOrganName = "";
    //   vm.initFormData();
    // }
  },
};
</script>
<style lang="less" scoped>
.organNameSec {
  ::v-deep .el-input__icon {
    line-height: 36px;
  }
}
/*进度条*/
.stepBox {
  position: relative;
  width: 980px;
  height: 80px;
  background: url("../../../../../assets/images/common/processtab.png") center
    top no-repeat;
  margin: 30px auto;
  border-bottom: 1px dashed #cdd0d0;
}

.stepLine {
  position: absolute;
  top: 22px;
  left: 59px;
  height: 4px;
  width: 200px;
  background: #0a70b0;
  transition: width 0.2s;
}

.stepLine.step2 {
  width: 500px;
}
.stepLine.step3 {
  width: 794px;
}
.stepLine.step4 {
  width: 863px;
}

.stepState {
  position: absolute;
  left: 16px;
  top: 6px;
  width: 36px;
  height: 36px;
  text-align: center;
  line-height: 36px;
  border-radius: 50%;
  background: #fff;
}
.el-switch.is-checked .el-switch__core::after {
  margin-left: -36px;
}
.stepState.active {
  background: #0a70b0;
  color: #fff;
}

.stepState2 {
  left: 320px;
}

.stepState3 {
  left: 624px;
}
.stepState4 {
  left: 928px;
}

.stateText {
  position: absolute;
  left: 6px;
  top: 50px;
}

.stateText.active {
  color: #0a70b0;
}

.stateText2 {
  left: 310px;
}

.stateText3 {
  left: 616px;
}
.stateText4 {
  left: 920px;
}
/**/
.addCenterPage {
  width: 800px;
  height: 100%;
  padding: 0 25px;
  overflow: hidden;
}
.userinfo-title {
  position: relative;
  width: 100%;
  height: 48px;
  line-height: 48px;
  .userinfo-titleinfo {
    font-size: 18px;
    color: #1f2f3d;
    font-weight: bold;
  }
  .close-btn {
    position: absolute;
    right: 0px;
    top: 0px;
    color: #9facc3;
    font-size: 24px !important;
    cursor: pointer;
  }
}
.applyCenterCon {
  border: 1px solid #dcdfe6;
  padding: 0 10px;
  padding-top: 15px;
  height: calc(100vh - 112px);
  overflow: auto;
  ::v-deep .el-checkbox-group {
    float: left;
    width: calc(100% - 120px);
  }
  .el-checkbox.is-bordered + .el-checkbox.is-bordered {
    margin-left: 0 !important;
  }
}
.fl {
  float: left;
}
.info_ulList li {
  min-height: 36px;
  margin-bottom: 15px;
}
::v-deep .info_ulList {
  .wechatLabel {
    width: 88px !important;
    padding-right: 0px;
  }
  .wechatTip {
    margin-left: 88px;
  }
}
.mb0 {
  margin-bottom: 0 !important;
}
.editCon {
  position: relative;
  margin-bottom: 10px !important;
  .wordNumber {
    position: absolute;
    right: 5px;
    bottom: 5px;
  }
  ::v-deep .ql-toolbar.ql-snow {
    line-height: 36px;
  }
  ::v-deep .ql-editor {
    font-size: 15px;
    line-height: 26px;
    padding: 5px 10px;
    color: #303133;
  }
  ::v-deep .ql-editor.ql-blank::before {
    font-style: initial;
  }
}
.width_370 {
  width: 370px;
  ::v-deep .el-input__inner {
    height: 36px;
    line-height: 36px;
    border-radius: 3px;
  }
}
.info_label {
  width: 110px;
  height: 36px;
  line-height: 36px;
  text-align: left;
  color: #454545;
  vertical-align: top;
}
.iconbitian {
  color: #da4a4a;
  font-size: 10px;
}
.length_info_label {
  width: 110px;
  height: 36px;
  line-height: 36px;
  text-align: right;
  color: #454545;
  vertical-align: top;
}
.domainLabel {
  text-indent: 12px;
}
.margin_10 {
  margin-right: 10px;
}
.organNameLabel {
  width: 110px !important;
  text-align: right;
}
.info_input {
  width: 360px;
  height: 36px;
  line-height: 36px;
  // border: 1px solid #e6e6e6;
  border-radius: 3px;
  // padding:0 8px;
  ::v-deep .el-input__inner {
    height: 36px;
    line-height: 34px;
  }
}
.input_175 {
  width: 175px;
  height: 36px;
  line-height: 36px;
  border: 1px solid #e6e6e6;
  border-radius: 3px;
  padding: 0 8px;
}
.openModuleDiv {
  padding-left: 13px;
}
.ml63 {
  margin-left: 63px;
}
.openModule {
  height: 36px;
  line-height: 36px;
  padding: 0 15px;
  border-radius: 3px;
  border: 1px solid #dcdfe6;
  margin-right: 10px;
  color: #0a70b0;
  cursor: pointer;
  margin-bottom: 5px;
  ::v-deep .el-checkbox__label {
    padding-left: 0px;
  }
}
.openModule.el-checkbox.is-bordered.is-checked {
  background: url("../../../../../assets/images/common/checkboxBg.png") right
    bottom no-repeat;
}
.openModule {
  ::v-deep .el-checkbox__inner {
    display: none;
  }
}
.openModule:hover {
  background: rgba(10, 112, 176, 0.6);
  color: #fff;
}
.logoCon {
  height: 20px;
  line-height: 20px;
  margin-bottom: 10px;
  .logoTit {
    font-size: 15px;
    color: #303133;
    padding-right: 5px;
  }
  .logoTip {
    font-size: 15px;
    color: #909399;
  }
}
.lastUpload {
  margin-right: 0px !important;
}
::v-deep .serviceCenterUpload {
  // position: absolute;
  // right: 0;
  // top: 70px;
  width: 312px;
  .el-upload-dragger .el-icon-upload {
    margin-top: 10px !important;
  }
}
.el-upload__tip {
  text-align: left;
  height: 30px;
  line-height: 30px;
  color: #ff9a50;
  font-size: 15px;
  width: 600px;
}
.uploadLi {
  margin-bottom: 0px !important;
}
.centerIntroTit {
  width: 140px;
  height: 20px;
  line-height: 20px;
  text-align: left;
  font-weight: bold;
  color: #303133;
  vertical-align: top;
  margin-bottom: 10px;
  i {
    font-weight: initial;
  }
}
.quill-editor {
  ::v-deep .ql-container {
    height: 254px !important;
  }
}
.btnCon {
  // text-align: center;
}
.operateBtn,
.nextStepBtn {
  border: none;
  height: 40px;
  cursor: pointer;
  line-height: 40px;
  padding: 0 20px;
  min-width: 88px;
  border-radius: 3px;
  font-size: 15px;
  color: #fff;
  background: #0a70b0;
}
/**第四步样式 */
.info_step_4 {
  width: 980px;
  margin: auto;
  .applySuc {
    width: 260px;
    margin: auto;
    margin-top: 30px;
    text-align: center;
    .applySucLogo:before {
      content: "\e63c";
      font-size: 64px;
      color: #00c579;
    }
    h3 {
      font-size: 22px;
      height: 40px;
      line-height: 40px;
      color: #303133;
      margin-top: 15px;
      margin-bottom: 6px;
      letter-spacing: 1px;
    }
    span {
      display: block;
      font-size: 15px;
      line-height: 30px;
      color: #909399;
      margin-bottom: 20px;
    }
  }
  .subSucCon {
    background: #fafafa;
    width: 624px;
    padding-top: 25px;
    padding-bottom: 10px;
    margin: auto;
    margin-bottom: 30px;
    .subInforDiv {
      width: 400px;
      margin: 0 auto;
    }
    li {
      margin-bottom: 15px;
      .patientItem:nth-of-type(1) {
        display: inline-block;
        width: 98px;
        text-align: right;
        line-height: 24px;
      }
      .patientItemCon:nth-of-type(2) {
        display: inline-block;
        line-height: 24px;
        font-size: 14px;
        color: #303133;
      }
    }
  }
}
/**第四步样式结束 */
.uploadImgComponent {
  ::v-deep .el-upload-dragger {
    display: flex;
    align-items: center;
    justify-content: center;
    img {
      width: auto;
      height: auto !important;
      max-width: 100%;
      max-height: 100%;
      vertical-align: middle;
    }
  }
}
</style>
