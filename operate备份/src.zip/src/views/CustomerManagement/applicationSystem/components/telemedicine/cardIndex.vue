<template>
  <div class="jurisdictionlist">
    <div class="oneSystemItem" v-if="oneSystem">
      <div class="listItemInfor">
      <div class="flex_row">
        <img class="pacs_img" :src="oneSystem.service_center_type == 0 ? FWZX : FWZX_THIRD" />
        <div class="shareHead">
          <div class="systemNameTitle overOneLine" v-bind:title="oneSystem.name">
            {{ oneSystem.name }}
          </div>
          <div class="productIdAndType">
            <span
              class="productIdAndTypeText productName overOneLine"
              v-if="oneSystem.service_center_type == 0"
              :title="oneSystem.product_name"
              >本系统</span>
              <span
              class="productIdAndTypeText productName overOneLine"
              v-else
              :title="oneSystem.product_name"
              >第三方</span>

              <span
              class="productIdAndTypeText idNumber overOneLine"
              :title="'系统ID：' + oneSystem.id"
              >{{ oneSystem.id }}</span
            >
          </div>
        </div>
      </div>
      <div class="flex_row mt10 f14">
        <div
          class="tl adminInfor"
          v-bind:title="'管理人员：' + oneSystem.admin_name"
        >
          <span class="clr_999">管理人员：</span>
          <span class="clr_303"
            >{{ oneSystem.admin_name }}({{ oneSystem.admin_phone }})</span
          >
        </div>
      </div>
      <div class="mt10">
        <div class="flex_row tl f14">
            <div class="useInstituteLabel clr_999">开设机构：</div>
            <div class="clr_303 useInstituteNum  overOneLine flex_row" v-if="oneSystem.institution_names.length != 0">[{{oneSystem.institution_names.length}}家]
              <!-- <span v-for="(itemname, index) in item.institution_names" :key="itemname"><span v-if="index!=0">、</span>{{itemname}}</span> -->
              <tooltip-over
              :content="oneSystem.institution_names"
              placement="top-start"
              class="wid190"
              refName="tooltipOver"
            ></tooltip-over>
            </div>
            <div class="clr_303 useInstituteNum  overOneLine" v-else>无</div>
        </div>
        </div>
        <div class="contractedhospital mt10">
            <div class="contractedInstitute">
            <span class="contractedLabel">签约机构：</span>
            <span class="contractedNum canClick" @click="goToContractHospital(oneSystem.id)" v-if="oneSystem.signing_institution_count != 0">{{oneSystem.signing_institution_count}}家</span>
            <span class="contractedNum canClick" @click="goToContractHospital(oneSystem.id)" v-else>0家</span>
            </div>
            <div class="contractedDoctor ml30">
            <span class="contractedLabel">服务医生：</span>
            <span class="contractedNum canClick" @click="gotoServiceDoctor(oneSystem.id)" v-if="oneSystem.signing_doctor_count != 0">{{oneSystem.signing_doctor_count}}人</span>
            <span class="contractedNum canClick" @click="gotoServiceDoctor(oneSystem.id)" v-else>0人</span>
            </div>
      </div>
      </div>
      <div class="operateBtnCon">
        <div class="operateBtnOneBox"  v-if="isSetUdi" @click="isShowinfoFn('aboutSystem', oneSystem)">
          <div class="operateBtnOne">
            <span class="operateBtnTxt">关于</span>
          </div>
        </div>
        <div class="operateBtnOneBox" @click="isShowinfoFn('edit', oneSystem)">
          <div class="operateBtnOne">
            <span class="operateBtnTxt">编辑</span>
          </div>
        </div>
        <div class="operateBtnOneBox" v-if="isShowManageBtn" @click="isShowinfoFn('operate', oneSystem)">
          <div class="operateBtnOne">
            <span class="operateBtnTxt"><i class="iconfont">&#xe667;</i> 中心管理</span>
          </div>
        </div>
      </div>
    </div>
    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="isPacsinfo"
      :show-close="false"
      :withHeader="false"
      :wrapperClosable="this.operateSystemInfo.title === '编辑' ? true : false"
      :direction="direction"
      :before-close="handleClose"
    >
      <component
        :is="curSystemModule"
        ref="info"
        :pacsinfo="operateSystemInfo"
        @updateOrAddSuc="updateOrAddSuc"
        @selectInstitionListFn="selectInstitionListFn"
        :pageInfo="InstitutionPage"
        @isAddInstution="isAddInstution"
        @closeFn="closeFn"
        :getDetailFinished="getDetailFinished"
        @ChoiceOrganFn="ChoiceOrganFn"
        @delInstitutionFn="delInstitutionFn"
        @serchListFn="serchListFn"
        @selectCurRowFn="selectCurRow"
        @getSerchName="getSerchName"
        @instclose="instclose"
        @pageSizeChangeFn="pageSizeChangeFn"
        :InstitutionsArr="InstitutionsArr"
        @submitForm="submitForm"
      ></component>
    </el-drawer>
  </div>
</template>

<script>
import Vue from "vue";
import aboutSystem from "tomtaw-system-about";
import Mgr from "@/utils/SecurityService";
// import JSEncrypt from 'jsencrypt'
import JSEncrypt from "@/utils/jsencrypt.min";
import { mapGetters } from "vuex";
import addservicecenter from "./addservicecenter";
import addThirdservicecenter from "./addThirdservicecenter";
import tooltipOver from "../tooltipOver"
import { getConfigurations } from "@/api/commonHttp";
import { getInstitutionList } from "@/api/platform_costomer/institution";
import {
  getInstitutions,
  addSeviceCenter,
  getServiceCenterDetail,
  updateServiceCenterData,
  getSeviceCenterList,
} from "@/api/platform_costomer/telemedicine";
import { getServiceLogo, getLoginUserInfor, ownMenu } from "@/api/commonHttp";
import { getCostomerInfoDetail } from "@/api/platform_operate/costomer";
// import { setCachedTeachCenterId } from 'tomtaw-caches';
export default {
  components: {
    addservicecenter,
    addThirdservicecenter,
    tooltipOver,
  },
  computed: {
    ...mapGetters(["isSetUdi", "isShowManageBtn"]),
  },
  props: {
    oneSystem: Object,
  },
  data() {
    return {
      FWZX: require("../../../../../assets/images/FWZX_Image.png"), // 服务中心
      FWZX_THIRD: require("../../../../../assets/images/FWZX_THIRD_Image.png"), // 第三方服务中心
      curSystemModule: '',
      info: "",
      addDistanceTeachForm: "",
      isPacsinfo: false,
      loading: true,
      direction: "rtl",
      InstitutionsArr: [],
      distanceTeachList: [],
      isactive: "",
      getDetailFinished: false,
      serviceListParam: {
        is_third_party: false,
        institution_id: "",
        category: 2,
        offset: 1,
        limit: 12,
      },
      InstitutionPage: {
        eof: 1,
        page_index: 1,
        page_size: 15,
        total_count: 0,
        total_pages: 1,
      },
      operateSystemInfo: {
        title: "开设远程教学中心",
        formInfo: {
          name: "",
          abbreviation: "",
          institution_ids: [],
          manager_id: "",
          manager_phone: "",
          manager_name: "",
          introduction: "",
          domain: "",
          app_id: "",
          secret: "",
          category: 2,
          services: [
            {
              service_code: 400,
            },
          ],
        },
        providersObj: {
          // 需要特殊处理
          app_id: "",
          app_secret: "",
        },
        isChioseOrgan: false,
        institutionList: [], // 机构列表
        multipleSelection: [], // 机构列表选中机构
      },
      isUpdate: false,
      isFirstChange: true,
      choiseList: [], // select 选中机构
      isChoiceFirst: true, // 是否第一次select
    };
  },
  created() {
    this.serviceListParam.offset = 1;
    this.distanceTeachList = [];
    // this.getDistanceTeachCenterList();
    // 加密函数
    //this.getConfigurationsFn();
    // 初始化formdata
    this.addDistanceTeachForm = new FormData();
    // 获取机构
    // this.getMyInstitutions();
  },
  methods: {
    // 新增服务中心或编辑服务中心成功
    updateOrAddSuc () {
      this.closeFn()
      this.$emit('getSystemList')
    },
    isAddInstution() {
      this.InstitutionPage.page_index = 1;
      this.getInstitutionListFn();
      this.operateSystemInfo.isChioseOrgan = true;
    },
    // 分页
    pageSizeChangeFn(info) {
      this.InstitutionPage.page_index = info.page;
      this.InstitutionPage.page_size = info.limit;
      this.getInstitutionListFn();
    },
    // 去掉数组元素 里面对象 id值相同的
    clearCommonId(arr) {
      let obj = {};
      let peon = arr.reduce((cur, next) => {
        obj[next.id] ? "" : (obj[next.id] = true && cur.push(next));
        return cur;
      }, []);
      return peon;
    },
    // 机构 select change事件
    selectInstitionListFn(val) {
      // if (this.InstitutionPage.page_index === 1 && this.isChoiceFirst) {
      //   this.choiseList = [...this.operateSystemInfo.multipleSelection, ...rows]
      // } else {
      //   this.choiseList = rows
      // }
      // this.isChoiceFirst = false
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    // 关闭 选择机构
    instclose() {
      this.operateSystemInfo.institutionList.forEach((item) => {
        this.$nextTick(() => {
          this.$refs.info.$refs.institutions.toggleRowSelection(item, false);
        });
      });
      this.operateSystemInfo.isChioseOrgan = false;
    },
    // 机构 提交
    ChoiceOrganFn(type) {
      // if (type === 'commit') {
      //   this.operateSystemInfo.multipleSelection = this.choiseList
      // }
      this.instclose();
    },
    getSerchName(val) {
      this.operateSystemInfo.serchName = val;
    },
    // 选中某一行
    selectCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === row.id) {
            self.operateSystemInfo.multipleSelection.splice(i, 1);
          }
        });
      }
    },
    // 选择机构页面 查询按钮
    async serchListFn() {
      const _url =
        "/institutions?offset=1" +
        "&limit=" +
        this.InstitutionPage.page_size +
        "&name=" +
        this.operateSystemInfo.serchName;
      const res = await getInstitutionList(_url);
      if (res.code === 0) {
        this.operateSystemInfo.institutionList = res.data;
      }
    },
    // 获取机构列表
    async getInstitutionListFn() {
      let filter_system_id = "";
      if (this.operateSystemInfo.title !== "新增系统") {
        filter_system_id = "&filter_system_id=" + this.isactive;
      }
      const _url =
        "/institutions?offset=" +
        this.InstitutionPage.page_index +
        "&limit=" +
        this.InstitutionPage.page_size +
        filter_system_id;
      const res = await getInstitutionList(_url);
      if (res.code === 0) {
        res.data.forEach((item) => {
          item.office_ids = [];
          if (item.offices.length === 1) {
            item.office_ids[0] = item.offices[0].id;
          }
        });
        this.operateSystemInfo.institutionList = res.data;
        this.InstitutionPage = res.page;
        // 先全部清空下
        this.$refs.info.$refs.institutions.clearSelection();
        //if (this.operateSystemInfo.title === '编辑') {
        // 勾上已选中的

        res.data.forEach((itemids) => {
          this.operateSystemInfo.multipleSelection.forEach((item) => {
            if (itemids.id === item.id) {
              this.$nextTick(() => {
                this.$refs.info.$refs.institutions.toggleRowSelection(
                  itemids,
                  true
                );
              });
              itemids.office_ids = item.office_ids;
            }
          });
        });
        //}
      }
    },
    delInstitutionFn(id) {
      this.$confirm("是否删除这条机构信息？", "删除信息", {
        distinguishCancelAndClose: true,
        confirmButtonText: "删除",
        cancelButtonText: "取消",
      }).then(() => {
        this.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === id) {
            if (this.operateSystemInfo.institutionList.length > 0) {
              this.$refs.info.$refs.institutions.toggleRowSelection(
                item,
                false
              );
            }
            this.operateSystemInfo.multipleSelection.splice(i, 1);
            this.$message({
              type: "success",
              message: "删除成功",
            });
          }
        });
      });
    },
    async getConfigurationsFn() {
      const res = await getConfigurations("TransmissionSecurity.RSA.PublicKey");
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) {
          // 注册方法
          const pubKey = res.data; // ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt();
          encryptStr.setPublicKey(pubKey); // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()); // 进行加密
          return data;
        };
      }
    },
    // 获取机构
    async getMyInstitutions() {
      const res = await getInstitutions();
      this.InstitutionsArr = res.data;
    },
    async getDistanceTeachCenterList() {
      const res = await getSeviceCenterList(this.serviceListParam);
      if (res.code === 0) {
        this.loading = false;
        // 当
        if (res.data.length > 0) {
          this.serviceListParam.offset++;
          const result = res.data;
          for (let i = 0; i < result.length; i++) {
            this.distanceTeachList.push(result[i]);
          }
          if (res.data.length < this.serviceListParam.limit) {
            this.aq = false;
          }
        } else {
          this.aq = false;
        }
        // this.distanceTeachList = res.data
      } else {
        this.loading = false;
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    enterServiceCenterManage(centerId, name) {
      this.getOwnMenu(centerId).then((url) => {
        // 进入服务中心管理
        sessionStorage.setItem("serviceCenterId", centerId);
        // 将系统id 赋值成 服务中心id
        // sessionStorage.setItem('lastname', centerId)
        sessionStorage.setItem("serviceCenterName", decodeURI(name));
        // 新的跳转
        var dev = process.env.NODE_ENV === "development" ? true : false;
        if (dev) {
          url = url.replace("/operate", "");
        }
        const href = configUrl.frontEndUrl + url + "?id=" + centerId;
        //const {href} = this.$router.resolve({path: url, query: {id: centerId}})
        console.log("href==", href);
        window.open(href, "_blank");

        // 老的跳转
        // var path = process.env.NODE_ENV === 'development' ? '/' : '/operate/'
        // const { href } = this.$router.resolve({ path: `${path}centerSet/serviceCenterInfor`, query: { id: centerId } })
        // window.open(href, '_blank')
      });
    },
    // 获取菜单
    getOwnMenu(centerId) {
      return new Promise((resolve) => {
        ownMenu().then((res) => {
          if (res.code != 0) {
            this.$message.error(res.msg);
            return;
          }
          let arr = res.data.filter((item) => {
            return (
              item.name === "serviceCenterManage" &&
              item.service_center_id == centerId
            );
          });
          let url = "";
          if (arr[0].children[0].children.length != 0) {
            url = arr[0].children[0].path + arr[0].children[0].children[0].path;
          } else {
            url = arr[0].children[0].path;
          }
          resolve(url);
          // this.getUrlStr(url, arr[0].children[0]).then(() => {
          //   console.log('url', url)
          // })
        });
      });
    },
    // 操作按钮
    async isShowinfoFn(type, item) {
      const self = this;
      if (type === "add") {
        self.isPacsinfo = true;
        self.isUpdate = false;
        self.operateSystemInfo.title = "开设远程教学中心";
        self.operateSystemInfo = self.$options.data().operateSystemInfo;
        if (item.service_center_type == 0) {// 本系统服务中心
          self.curSystemModule = addservicecenter
        } else { // 第三方服务中心
          self.curSystemModule = addThirdservicecenter
        }
        console.log("触发了")
        self.$nextTick(() => {
          self.$refs.info.initAdd()
        })
      } else if (type === "operate") {
        self.enterServiceCenterManage(item.id,item.name)
      } else if (type == "aboutSystem") {
        var manager = new Mgr();
        manager.getRole().then(function (item) {
          if (item) {
            aboutSystem("telemed", item);
          }
        });
      } else {
        await self.$emit('closeAllDrawDetailAlert','Telemed')
        self.isactive = item.id;
        self.isPacsinfo = true;
        self.isUpdate = true;
        self.isFirstChange = true;
        self.getDetailFinished = false;
        self.operateSystemInfo.title = "编辑";
        // 获取机构
        await self.getMyInstitutions()
        if (item.service_center_type == 0) {// 本系统服务中心
          self.curSystemModule = addservicecenter
        } else { // 第三方服务中心
          self.curSystemModule = addThirdservicecenter
        }
        
        self.$nextTick(() => {
          self.$refs.info.initEdit(item.id)
        })
        
      }
    },
    handleClose(done) {
      done();
    },
    closeFn() {
      var info = {
        type: "cancel",
        refs: this.$refs["info"].$refs,
        formName: "formInfo",
      };
      this.submitForm(info);
    },
    goToContractHospital(id) {
      var path = process.env.NODE_ENV === "development" ? "/" : "/operate/";
      this.$router.push({
        path: `${path}telemedicine/contractedhospital`,
        query: { id: id },
      });
    },
    gotoServiceDoctor(id) {
      var path = process.env.NODE_ENV === "development" ? "/" : "/operate/";
      this.$router.push({
        path: `${path}telemedicine/servicedoctor`,
        query: { id: id },
      });
    },
    async addDistanceTeachCenter() {
      const _params = this.operateSystemInfo.formInfo;
      const loading = this.$loading({
        lock: true,
        text: _params.id ? "正在编辑，请稍等..." : "正在新增，请稍等...",
        spinner: "el-icon-loading",
        background: "rgba(255, 255, 255, 0.6)",
      });
      var res = null;
      var tipmsg = "新增远程教学中心成功！";

      if (_params.id) {
        res = await updateServiceCenterData(
          this.addDistanceTeachForm,
          _params.id
        );
        tipmsg = "修改远程教学中心成功！";
      } else {
        res = await addSeviceCenter(this.addDistanceTeachForm);
      }
      loading.close();
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: tipmsg,
        });
        this.isPacsinfo = false;
        this.serviceListParam.offset = 1;
        this.distanceTeachList = [];
        //this.getDistanceTeachCenterList();
        this.$emit('getSystemList')
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      } else {
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    delFormData() {
      for (let key in this.operateSystemInfo.formInfo) {
        this.addDistanceTeachForm.delete(key);
      }
      if (this.operateSystemInfo.formInfo.institution_ids.length !== 0) {
        for (
          let i = 0;
          i < this.operateSystemInfo.formInfo.institution_ids.length;
          i++
        ) {
          this.addDistanceTeachForm.delete("institution_ids[" + i + "]");
        }
      }
      if (this.operateSystemInfo.multipleSelection.length !== 0) {
        for (
          let i = 0;
          i < this.operateSystemInfo.multipleSelection.length;
          i++
        ) {
          this.addDistanceTeachForm.delete("use_institution_ids[" + i + "]");
        }
      }
      this.addDistanceTeachForm.delete("services[" + 0 + "]");
      this.addDistanceTeachForm.delete("providers");
    },
    initFormData() {
      for (let key in this.operateSystemInfo.formInfo) {
        // 对手机号加密
        if (key === "manager_phone") {
          this.addDistanceTeachForm.append(
            key,
            this.$getRsaCode(this.operateSystemInfo.formInfo[key])
          );
        } else {
          if (key !== "institution_ids" && key !== "services") {
            this.addDistanceTeachForm.append(
              key,
              this.operateSystemInfo.formInfo[key]
            );
          }
        }
      }
      if (this.operateSystemInfo.formInfo.institution_ids.length > 0) {
        for (
          let i = 0;
          i < this.operateSystemInfo.formInfo.institution_ids.length;
          i++
        ) {
          this.addDistanceTeachForm.delete("institution_ids[" + i + "]"); // 目的是防止 append添加重复的
          this.addDistanceTeachForm.append(
            "institution_ids[" + i + "]",
            this.operateSystemInfo.formInfo.institution_ids[i]
          );
        }
      }
      if (this.operateSystemInfo.multipleSelection.length > 0) {
        for (
          let i = 0;
          i < this.operateSystemInfo.multipleSelection.length;
          i++
        ) {
          this.addDistanceTeachForm.delete("use_institution_ids[" + i + "]"); // 目的是防止 append添加重复的
          this.addDistanceTeachForm.append(
            "use_institution_ids[" + i + "]",
            this.operateSystemInfo.multipleSelection[i].id
          );
        }
      }
      this.addDistanceTeachForm.set("services[" + 0 + "].service_code", 400);
      // 赋值微信公众号信息
      if (this.operateSystemInfo.providersObj.app_id) {
        this.addDistanceTeachForm.set(
          "providers[" + 0 + "].app_id",
          this.operateSystemInfo.providersObj.app_id
        );
      }
      if (this.operateSystemInfo.providersObj.app_secret) {
        this.addDistanceTeachForm.set(
          "providers[" + 0 + "].app_secret",
          this.operateSystemInfo.providersObj.app_secret
        );
      }
      this.addDistanceTeachForm.set(
        "providers[" + 0 + "].provider_name",
        "WeChat"
      );
    },
    submitForm(info) {
      if (info.type === "commit") {
        if (!this.operateSystemInfo.formInfo.name) {
          this.$message({ type: "error", message: "请输入教学中心名称" });
          return;
        }
        if (
          this.operateSystemInfo.formInfo.institution_ids &&
          this.operateSystemInfo.formInfo.institution_ids.length === 0
        ) {
          this.$message({ type: "error", message: "请选择机构" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.manager_id) {
          this.$message({ type: "error", message: "请选择管理员" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.manager_phone) {
          this.$message({ type: "error", message: "请输入管理员电话" });
          return;
        }
        var phoneReg = /^1[3456789]\d{9}$/;
        // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
        // if (!this.isUpdate || (this.isUpdate && !this.isFirstChange)) {
        //   if (!phoneReg.test(this.operateSystemInfo.formInfo.manager_phone)) {
        //     this.$message({
        //       message: '请输入正确的手机号码!',
        //       type: 'warning'
        //     })
        //     return false
        //   }
        // }
        if (this.$refs.info && !this.$refs.info.$refs.introduction.value) {
          this.$message({ message: "请输入中心简介", type: "error" });
          return false;
        }
        var re =
          /^(?=^.{3,255}$)(http(s)?:\/\/)(www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\d+)*(\/\w+)*\/$/;
        if (
          this.operateSystemInfo.formInfo.domain &&
          !re.test(this.operateSystemInfo.formInfo.domain)
        ) {
          this.$message({ message: "请输入正确的域名！", type: "error" });
          return;
        }
        this.delFormData();
        this.initFormData();
        this.addDistanceTeachCenter();
      } else {
        this.isPacsinfo = false;
        this.isactive = "";
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
        // setTimeout (() => {
        //   this.$refs.info.$refs.institutions.clearSelection()
        // }, 4)
      }
    },
  },
};
</script>

<style lang="less" scoped>
.jurisdictionlist {
  // width: 100%;
  display: flex;
  flex-wrap: wrap;
  .oneSystemItem{
    width:100%;
  }
  .pacsContainer {
    height: calc(100% - 47px);
    padding: 10px 5px;
    position: relative;
    overflow: auto;
    .teachList {
      // height:100%;
    }
  }
}

.list-item {
  width: calc(25% - 15px);
  margin-right: 15px;
  box-sizing: border-box;
  border: 1px solid #EBEEF5;
  box-shadow: 0 1px 5px 0 rgba(26,26,26,.050980392156862744);
  border-radius: 6px;
  background: #ffffff;
  margin-bottom: 15px;
  .listItemInfor{
    padding: 18px 14px 14px 18px;
    //border-bottom: 1px solid #ebeef5;
  }
  .active {
    background: rgba(10, 112, 176) !important;
    color: #fff !important;
  }
  .pacs_img {
    width: 52px;
    height: 52px;
    vertical-align: middle;
  }
  .title {
    // max-width: 200px;
    width: 100%;
  }
  .systemNameTitle {
    width: 100%;
    font-size: 20px;
    color: #1f2f3d;
    font-weight: 500;
    position: relative;
    top: -3px;
  }
  .shareHead {
    width: calc(100% - 70px);
    margin-left:16px;
  }
  .productIdAndType {
    display: flex;
    .productIdAndTypeText {
      display: inline-block;
      line-height: 22px;
    }
    .productName {
      margin-right: 10px;
    }
    .idNumber {
      display: inline-block;
      max-width: 190px;
    }
  }
  .item_btn {
    padding: 0 10px;
    height: 30px;
    line-height: 28px;
    text-align: center;
    background: rgba(255, 255, 255, 1);
    border: 1px solid rgba(10, 112, 176, 0.5);
    border-radius: 3px;
    color: #0a70b0;
    cursor: pointer;
  }
  .manageBtn {
    background-color: #0a70b0;
    color: #fff;
  }
  .border_bd {
    border-bottom: 1px dashed #dcdfe6;
  }
  .useInstituteLabel {
    width: 70px;
  }
  .useInstituteNum {
    width: calc(100% - 70px);
  }
  .overOneLine {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .contractedhospital {
    display: flex;
    .contractedLabel {
      font-size: 14px;
      color: #909399;
    }
    .contractedNum {
      font-size: 14px;
      color: #0a70b0;
      i {
        margin-left: 5px;
      }
    }
    .canClick{
      cursor: pointer;
    }
  }
  .operateBtnCon {
    display: flex;
    height: 40px;
    align-items: center;
    border-top:1px solid #ebeef5;
    .operateBtnOneBox{
      flex:1;
      height: 100%;
      display: flex;
      align-items: center;
      cursor: pointer;
    }
    .operateBtnOne{
      width: 100%;
      text-align: center;
      font-size:14px;
      color:#0A70B0;
      border-right:1px solid #DCDFE6;
    }
    .operateBtnOneBox:last-of-type{
      .operateBtnOne{
        border-right: none;
      }
    }
    .operateBtnOneBox:hover{
      background:#f2f7ff;
    }
  }
}
.list-item:hover {
  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(10, 112, 176, 0.3);
}
.list-item:hover .title {
  color: #0a70b0;
}
.adminInfor {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.over_ell_3 {
  text-align: justify;
}
.showOneLine {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: justify;
}
.productNameDiv {
  justify-content: left !important;
}
@media screen and (max-width: 1500px) {
  .list-item {
    width: calc(50% - 20px) !important;
  }
  .idNumber{
    max-width: initial!important;
  }
}
::v-deep .el-drawer__wrapper {
  overflow: visible !important;
}
</style>
