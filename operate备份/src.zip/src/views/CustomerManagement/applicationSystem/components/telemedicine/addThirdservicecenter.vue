<template>
  <div class="addCenterPage">
    <div class="userinfo-title">
      <span class="userinfo-titleinfo">{{ titletext }}</span>
      <span
        @click="closeFn"
        class="close-btn iconfont iconchuangjianshibai"
      ></span>
    </div>
    <div class="applyCenterCon">
      <div
        class="info_box"
        v-bind:element-loading-text="tipText"
        element-loading-background="rgba(255,255,255,0.6)"
        v-loading="fullScreenLoad"
      >
        <div v-show="step == 1" class="info_step_1">
          <ul class="info_ulList clear">
            <li>
              <span class="fl length_info_label">
                <i class="iconfont iconbitian mustIcon"></i>厂商名称：
              </span>
              <el-select
                class="fl organ-select alertFormSelect width_360_select organNameSec"
                filterable
                v-model="applyInfo.type"
                @change="chooseOrgan"
              >
                <!-- <el-option value>请选择</el-option> -->
                <el-option
                  v-for="(item, index) in baseData.service_center_company"
                  :key="index"
                  :label="item.name"
                  :value="item.value"
                ></el-option>
              </el-select>
            </li>

            <li>
              <span class="fl length_info_label">
                <i class="iconfont iconbitian mustIcon"></i>服务中心名称：
              </span>
              <input
                v-model="applyInfo.name"
                type="text"
                class="fl info_input"
              />
            </li>

            <li>
              <span class="fl info_label organNameLabel"
                ><i class="iconfont iconbitian mustIcon"></i>机构名称：</span
              >
              <!-- <el-select class="fl organ-select alertFormSelect width_360_select organNameSec" v-model="choosedOrganName" @change="chooseOrgan"> -->
              <el-select
                class="fl organ-select alertFormSelect width_360_select organNameSec"
                multiple
                collapse-tags
                filterable
                v-model="applyInfo.institution_ids"
                @change="chooseOrgan"
              >
                <!-- <el-option value>请选择</el-option> -->
                <el-option
                  v-for="(item, index) in InstitutionsArr"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
            </li>

            <li>
              <span class="fl length_info_label">
                <i class="iconfont iconbitian mustIcon"></i>门户地址：
              </span>
              <input
                v-model="mySetting_items.portal_url"
                type="text"
                class="fl info_input"
              />
            </li>
            <li>
              <span class="fl info_label organNameLabel"
                ><i class="iconfont iconbitian mustIcon"></i>API地址：</span
              >
              <input
                v-model="mySetting_items.api_url"
                type="text"
                class="fl info_input"
              />
            </li>
            <li>
              <span class="fl length_info_label">
                <i class="iconfont iconbitian mustIcon"></i>授权地址：
              </span>
              <input
                v-model="mySetting_items.authorize_url"
                type="text"
                class="fl info_input"
              />
            </li>
            <li>
              <span class="fl info_label organNameLabel"
                ><i class="iconfont iconbitian mustIcon"></i>文档地址：</span
              >
              <input
                v-model="mySetting_items.document_url"
                type="text"
                class="fl info_input"
              />
            </li>

            <li>
              <span class="fl length_info_label">
                <i class="iconfont iconbitian mustIcon"></i>服务中心ID：
              </span>
              <input
                v-model="mySetting_items.service_center_id"
                type="text"
                class="fl info_input"
              />
            </li>
            <li>
              <span class="fl info_label organNameLabel"
                ><i class="iconfont iconbitian mustIcon"></i
                >服务访问账号：</span
              >
              <input
                v-model="mySetting_items.account"
                type="text"
                class="fl info_input"
              />
            </li>
            <li>
              <span class="fl length_info_label">
                <i class="iconfont iconbitian mustIcon"></i>服务访问密码：
              </span>
              <input
                v-model="mySetting_items.password"
                type="password"
                class="fl info_input"
              />
            </li>

            <li>
              <span class="fl organNameLabel info_label openModuleDiv"
                ><i class="iconfont iconbitian mustIcon"></i>使用期限：</span
              >
              <div style="display: flex; align-items: center">
                <el-date-picker
                  v-model="applyInfo.start_date"
                  type="date"
                  placeholder="选择开始期限"
                  value-format="yyyy-MM-dd"
                >
                </el-date-picker>
                <el-radio-group v-model="applyInfo.isIndefinitely" class="ml20">
                  <el-radio :label="true">无期限</el-radio>
                  <el-radio :label="false">
                    <el-date-picker
                      v-model="applyInfo.stop_date"
                      type="date"
                      :disabled="applyInfo.isIndefinitely"
                      placeholder="选择结束期限"
                      value-format="yyyy-MM-dd"
                    >
                    </el-date-picker>
                  </el-radio>
                </el-radio-group>
              </div>
            </li>
            <li>
              <span class="fl organNameLabel info_label openModuleDiv"
                ><i class="iconfont iconbitian mustIcon"></i>系统状态：</span
              >
              <div style="display: flex; align-items: center; height: 36px">
                <el-radio-group v-model="applyInfo.state" class="ml20">
                  <el-radio :label="10">启用</el-radio>
                  <el-radio :label="-2">停用</el-radio>
                </el-radio-group>
                <el-input
                  v-if="applyInfo.state === -2"
                  v-model="applyInfo.reason"
                  class="ml10"
                  placeholder="备注"
                  style="width: 180px"
                />
              </div>
            </li>
            <!-- <li v-if="applyInfo.institution_id"> -->
            <li>
              <span class="fl organNameLabel info_label openModuleDiv"
                ><i class="iconfont iconbitian mustIcon"></i>开通服务：</span
              >
              <el-checkbox-group v-model="openedServiceArr">
                <el-checkbox
                  v-for="(item, index) in serviceArr"
                  v-bind:key="index"
                  class="fl openModule"
                  v-bind:label="item.service_code"
                  border
                  >{{ item.name }}</el-checkbox
                >
              </el-checkbox-group>
            </li>
            <li class="editCon">
              <div class="fl centerIntroTit">
                <i class="iconfont iconbitian mustIcon"></i>中心简介：
              </div>
              <quill-editor
                ref="text"
                v-model="applyInfo.introduction"
                class="myQuillEditor fl"
                :options="editorOption"
                @change="onEditorChange($event)"
              />
              <form
                action=""
                method="post"
                enctype="multipart/form-data"
                id="uploadFormMulti"
              >
                <input
                  style="display: none"
                  :id="uniqueId"
                  type="file"
                  name="files"
                  multiple
                  accept="image/jpg,image/jpeg,image/png,image/gif"
                  @change="uploadEditImg('uploadFormMulti')"
                />
              </form>
              <span class="wordNumber">{{ TiLength }}/500</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="btnCon mt15">
      <!-- <button
          type="button"
          class="nextStepBtn operateBtn"
          @click="nextStep"
        >
          确定
        </button> -->
      <el-button type="primary" size="medium" @click="nextStep">提交</el-button>
      <el-button size="medium" class="ml10" @click="closeFn">取消</el-button>
    </div>
  </div>
</template>
<script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
<script>
import { mapGetters } from "vuex";
import { quillEditor } from "vue-quill-editor";
import Quill from "quill";
import "quill/dist/quill.core.css";
import "quill/dist/quill.snow.css";
import "quill/dist/quill.bubble.css";
import {
  addThirdServiceCenter,
  getInstitutionServices,
  getInstitutions,
  getThirdServiceCenterDetail,
  updateThirdServiceCenterData,
  uploadFile,
} from "@/api/platform_costomer/telemedicine";
import { getLoginUserInfor, uploadMediaFile } from "@/api/commonHttp";
import { connectUrlParam } from "@/components/commonJs";
import Mgr from "@/utils/SecurityService";
import moment from "moment";

export default {
  components: {
    quillEditor,
  },
  computed: {
    ...mapGetters({
      // 获取store查询枚举条件
      baseData: "enumerations",
      // tenancyInfo: 'tenancyInfo'
    }),
  },
  data() {
    return {
      titletext: "开设第三方服务中心",
      choosedOrganName: "",
      checked2: false,
      step: 1,
      fullScreenLoad: false,
      checked1: true,
      content: "", // 编辑器内容
      editorOption: {
        placeholder: "请输入服务中心简介...",
        modules: {
          toolbar: [
            ["bold", "italic", "underline", "strike"], // toggled buttons
            ["blockquote", "code-block", "image"],
          ],
          clipboard: {
            // 粘贴过滤
            matchers: [[Node.ELEMENT_NODE, this.HandleCustomMatcher]],
          },
        },
      }, // 编辑器操作选项
      InstitutionsArr: [], // 所有的机构
      healthCardTypeList: [
        {
          DicCode: 123,
          DicName: "邵逸夫医院",
        },
        {
          DicCode: 234,
          DicName: "杭州人民医院",
        },
      ],
      tenancyId: "",
      mySetting_items: {
        portal_url: "",
        api_url: "",
        authorize_url: "",
        document_url: "",
        service_center_id: "",
        account: "",
        password: "",
      },
      openedServiceArr: [],
      applyInfo: {
        type: "",
        name: "",
        tenancy_id: "",
        institution_ids: [],
        setting_items: {},
        services: [],
        introduction: "",
        isIndefinitely: true, // 是否无限期
        start_date: "", // 开始期限
        stop_date: null, // 结束期限
        state: 10, // 启用状态
        reason: "", // 停用原因
      },
      tipText: "",
      TiLength: 0,
      applyType: 0, // 代表申请
      institutionServiceArr: [], // 某机构下开通的服务
      serviceArr: [], // 所有的服务
      operateId: "",
      isAutoUpload: false, // 是否自动上传图片
      logo_id: "",
      banner_id: "",
      advertise_id: "",
      addImgRange: "",
      uniqueId: "testUpload",
    };
  },
  methods: {
    closeFn() {
      this.$emit("closeFn");
    },
    HandleCustomMatcher(node, Delta) {
      // 文字，从别处复制而来，清除自带样式，转为纯文本
      if (node.src && node.src.indexOf("data:image/png") > -1) {
        Delta.ops = [];
        return Delta;
      }
      let ops = [];
      Delta.ops.forEach((op) => {
        if (op.insert && typeof op.insert === "string") {
          ops.push({
            insert: op.insert,
          });
        } else if (op.insert && typeof op.insert.image === "string") {
          ops.push({
            insert: op.insert,
          });
        }
      });
      Delta.ops = ops;
      return Delta;
    },
    onEditorChange(e) {
      e.quill.deleteText(500, 4); // 从第500个开始删除，删除4个
      if (this.$refs.text.value === "") {
        this.TiLength = 0;
      } else {
        this.TiLength = e.quill.getLength() - 1;
      }
    },
    // 获取所有开通的服务
    async getMyAllService() {
      const self = this;
      const res = await getInstitutionServices();
      if (res.code === 0) {
        self.serviceArr = res.data;
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    chooseOrgan(val) {
      // this.applyInfo.manager_name = ''
      // this.applyInfo.manager_id = ''
      if (val.length === 0) {
        this.allManagerArr = [];
      }
    },
    // 获取某机构下开通的服务
    async getInstitutionServices(instituId) {
      const res = await getInstitutionServices({ institution_id: instituId });
      if (res.code === 0) {
        this.institutionServiceArr = res.data;
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    validateSub() {
      const self = this;
      const phoneExe = /^1(3|4|5|7|8)\d{9}$/;
      if (!self.applyInfo.type) {
        self.$message({ message: "请选择厂商", type: "error" });
        return false;
      }
      if (!self.applyInfo.name) {
        self.$message({ message: "请输入服务中心名称", type: "error" });
        return false;
      }
      if (self.applyInfo.institution_ids.length === 0) {
        self.$message({ message: "请选择机构", type: "error" });
        return false;
      }
      if (!self.mySetting_items.portal_url) {
        self.$message({ message: "请输入门户地址", type: "error" });
        return false;
      }
      if (!self.mySetting_items.api_url) {
        self.$message({ message: "请输入API地址", type: "error" });
        return false;
      }
      if (!self.mySetting_items.authorize_url) {
        self.$message({ message: "请输入授权地址", type: "error" });
        return false;
      }
      if (!self.mySetting_items.document_url) {
        self.$message({ message: "请输入文档地址", type: "error" });
        return false;
      }
      if (!self.mySetting_items.service_center_id) {
        self.$message({ message: "请输入服务中心ID", type: "error" });
        return false;
      }
      if (!self.mySetting_items.account) {
        self.$message({ message: "请输入服务访问账号", type: "error" });
        return false;
      }
      if (!self.mySetting_items.password) {
        self.$message({ message: "请输入服务访问密码", type: "error" });
        return false;
      }
      if (!self.applyInfo.start_date) {
        this.$message({ type: "error", message: "请选择使用开始期限" });
        return;
      }
      if (!self.applyInfo.isIndefinitely && !self.applyInfo.stop_date) {
        this.$message({ type: "error", message: "请选择使用结束期限" });
        return;
      }
      if (!self.applyInfo.state) {
        this.$message({ type: "error", message: "请选择系统状态" });
        return;
      }

      if (self.applyInfo.state === -2 && !self.applyInfo.reason) {
        this.$message({ type: "error", message: "请输入停用备注" });
        return;
      }

      if (self.openedServiceArr.length === 0) {
        self.$message({ message: "请选择开通服务", type: "error" });
        return false;
      }
      if (!self.$refs.text.value) {
        self.$message({ message: "请输入中心简介", type: "error" });
        return false;
      }
      self.applyInfo.setting_items = JSON.parse(
        JSON.stringify(self.mySetting_items)
      );
      self.applyInfo.services = [];
      self.openedServiceArr.forEach((val) => {
        self.applyInfo.services.push({ service_code: val });
      });
      return true;
    },
    async beganAdd() {
      this.tipText = "正在初始化服务中心，请稍候";
      this.fullScreenLoad = true;
      const obj = { ...this.applyInfo };
      // 处理期限字段
      obj.stop_date = obj.isIndefinitely ? null : obj.stop_date;
      obj.reason = obj.state === 10 ? "" : obj.reason;
      delete obj.isIndefinitely;
      const res = await addThirdServiceCenter(obj);
      if (res.code === 0) {
        this.fullScreenLoad = false;
        this.$message({ message: "添加服务中心成功", type: "success" });
        this.$emit("updateOrAddSuc");
        // var path = process.env.NODE_ENV === "development" ? "/" : "/operate/";
        // this.$router.push({
        //   path: `${path}telemedicine/servicecenter`,
        //   query: { type: true },
        // });
      } else {
        this.fullScreenLoad = false;
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    async readyUpdateServiceCenterData() {
      this.tipText = "正在修改请稍候";
      this.fullScreenLoad = true;
      this.applyInfo.id = this.operateId;
      delete this.applyInfo["type"];
      const obj = { ...this.applyInfo };
      // 处理期限字段
      obj.stop_date = obj.isIndefinitely ? null : obj.stop_date;
      obj.reason = obj.state === 10 ? "" : obj.reason;
      delete obj.isIndefinitely;
      const res = await updateThirdServiceCenterData(obj);
      if (res.code === 0) {
        this.fullScreenLoad = false;
        this.$message({ message: "编辑服务中心成功", type: "success" });
        this.$emit("updateOrAddSuc");
        // var path = process.env.NODE_ENV === "development" ? "/" : "/operate/";
        // this.$router.push({
        //   path: `${path}telemedicine/servicecenter`,
        //   query: { type: true },
        // });
      } else {
        this.fullScreenLoad = false;
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    async nextStep() {
      if (this.validateSub()) {
        // 编辑
        if (this.operateId) {
          this.readyUpdateServiceCenterData();
        } else {
          this.beganAdd();
        }
      }
    },
    finishApply() {
      this.$router.push({ name: "servicecenter" });
    },
    // 获取机构
    async getMyInstitutions() {
      const res = await getInstitutions();
      this.InstitutionsArr = res.data;
    },
    async getMyServiceCenterDetail(service_center_id) {
      const res = await getThirdServiceCenterDetail({ id: service_center_id });
      if (res.code === 0) {
        this.operateId = res.data.id;
        this.applyInfo.type = res.data.type;
        this.applyInfo.name = res.data.name;
        this.applyInfo.institution_ids = res.data.institution_ids;
        // this.mySetting_items = JSON.parse(res.data.setting_items);
        this.mySetting_items = res.data.setting_items;
        this.applyInfo.introduction = res.data.introduction;
        this.openedServiceArr = [];

        this.applyInfo.isIndefinitely =
          res.data.stop_date === "无期限" ? true : false;
        this.applyInfo.start_date = res.data.start_date;
        this.applyInfo.stop_date =
          res.data.stop_date === "无期限" ? "" : res.data.stop_date;
        this.applyInfo.state = res.data.state;
        this.applyInfo.reason = res.data.reason;

        for (let i = 0; i < res.data.services.length; i++) {
          this.openedServiceArr.push(res.data.services[i].service_code);
        }
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    initFormData() {
      this.applyInfo = {
        type: "",
        name: "",
        tenancy_id: this.tenancyId,
        institution_ids: [],
        setting_items: {},
        services: [],
        introduction: "",
        isIndefinitely: true, // 是否无限期
        start_date: moment().format("YYYY-MM-DD"), // 开始期限
        stop_date: null, // 结束期限
        state: 10, // 启用状态
        reason: "", // 停用原因
      };
      this.openedServiceArr = [];
      this.mySetting_items = {
        portal_url: "",
        api_url: "",
        authorize_url: "",
        document_url: "",
        service_center_id: "",
        account: "",
        password: "",
      };
    },
    // 获取登录用户信息
    async getUserLoginInfor() {
      const res = await getLoginUserInfor();
      if (res.code == 0) {
        this.tenancyId =
          sessionStorage.getItem("curTenancyId") || res.data.tenancy_id;
        this.applyInfo.tenancy_id =
          sessionStorage.getItem("curTenancyId") || res.data.tenancy_id;
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    initAdd() {
      this.titletext = "开设第三方服务中心";
      this.choosedOrganName = "";
      this.isAutoUpload = false;
      this.initFormData();
    },
    initEdit(id) {
      this.titletext = "编辑第三方服务中心";
      this.isAutoUpload = true;
      this.getMyServiceCenterDetail(id);
    },
    async uploadEditImg(id) {
      var vm = this;
      var obj = document.getElementById("uploadFormMulti");
      // 获取文件对象
      var fileObj = document.getElementById(vm.uniqueId);
      var file = fileObj.files[0];
      var fileName = file.name;
      var fileSize = file.size;
      var formData = new FormData(obj);
      formData.append("file_name", fileName);
      try {
        vm.uploadImgReq(formData, fileName, fileSize); // 自定义的图片上传函数
      } catch ({ message: msg }) {
        document.getElementById(vm.uniqueId).value = "";
        vm.$message.warning(msg);
      }
    },
    // 下载图片
    downloadImg(file_id) {
      const vm = this;
      var src =
        configUrl.docUrl +
        "/api-document/download/document-id?document_id=" +
        file_id +
        "&is_crm_document=true";
      vm.addImgRange = vm.$refs.text.quill.getSelection();
      vm.$refs.text.quill.insertEmbed(
        vm.addImgRange != null ? vm.addImgRange.index : 0,
        "image",
        src,
        Quill.sources.USER
      );
    },

    async uploadImgReq(myformData, file_name, file_size) {
      // 这里实现你自己的图片上传
      var vm = this;
      let param = {
        file_name: file_name,
        file_size: file_size,
        position: 0,
        file_type: 0,
      };
      let paramUrl = connectUrlParam(param);
      const res = await uploadMediaFile(myformData, paramUrl);
      if (res.code === 0) {
        const result = res;
        // 获取图片
        vm.downloadImg(result.document_id);
      }
    },
  },
  created() {
    var vm = this;
    // 编辑
    if (vm.$route.query.id) {
      vm.isAutoUpload = true;
    } else {
      vm.isAutoUpload = false;
    }
    vm.getUserLoginInfor();
  },
  mounted() {
    var vm = this;
    var imgHandler = async function (image) {
      vm.addImgRange = vm.$refs.text.quill.getSelection();
      if (image) {
        var fileInput = document.getElementById(vm.uniqueId); //隐藏的file文本ID
        fileInput.click(); //加一个触发事件
      }
    };
    vm.$refs.text.quill.getModule("toolbar").addHandler("image", imgHandler);
    vm.getMyInstitutions();
    // vm.getMyConstants().then(() => {
    //   vm.getMyAllService()
    // })
    vm.getMyAllService();
    // 编辑
    // if (vm.$route.query.id) {
    //   vm.titletext = "编辑第三方服务中心";
    //   vm.isAutoUpload = true;
    //   vm.getMyServiceCenterDetail(vm.$route.query.id);
    // } else {
    //   vm.titletext = "开设第三方服务中心";
    //   vm.choosedOrganName = "";
    //   vm.isAutoUpload = false;
    //   vm.initFormData();
    // }
  },
};
</script>
<style lang="less" scoped>
.organNameSec {
  ::v-deep .el-input__icon {
    line-height: 36px;
  }
}
/*进度条*/
.stepBox {
  position: relative;
  width: 980px;
  height: 80px;
  background: url("../../../../../assets/images/common/processtab.png") center
    top no-repeat;
  margin: 30px auto;
  border-bottom: 1px dashed #cdd0d0;
}

.stepLine {
  position: absolute;
  top: 22px;
  left: 59px;
  height: 4px;
  width: 200px;
  background: #0a70b0;
  transition: width 0.2s;
}

.stepLine.step2 {
  width: 500px;
}
.stepLine.step3 {
  width: 794px;
}
.stepLine.step4 {
  width: 863px;
}

.stepState {
  position: absolute;
  left: 16px;
  top: 6px;
  width: 36px;
  height: 36px;
  text-align: center;
  line-height: 36px;
  border-radius: 50%;
  background: #fff;
}
.el-switch.is-checked .el-switch__core::after {
  margin-left: -36px;
}
.stepState.active {
  background: #0a70b0;
  color: #fff;
}

.stepState2 {
  left: 320px;
}

.stepState3 {
  left: 624px;
}
.stepState4 {
  left: 928px;
}

.stateText {
  position: absolute;
  left: 6px;
  top: 50px;
}

.stateText.active {
  color: #0a70b0;
}

.stateText2 {
  left: 310px;
}

.stateText3 {
  left: 616px;
}
.stateText4 {
  left: 920px;
}
/**/
.addCenterPage {
  width: 800px;
  height: 100%;
  padding: 0 25px;
  overflow: hidden;
}
.userinfo-title {
  position: relative;
  width: 100%;
  height: 48px;
  line-height: 48px;
  .userinfo-titleinfo {
    font-size: 18px;
    color: #1f2f3d;
    font-weight: bold;
  }
  .close-btn {
    position: absolute;
    right: 0px;
    top: 0px;
    color: #9facc3;
    font-size: 24px !important;
    cursor: pointer;
  }
}
.applyCenterCon {
  border: 1px solid #dcdfe6;
  padding: 0 10px;
  padding-top: 15px;
  height: calc(100vh - 112px);
  overflow: auto;
  ::v-deep .el-checkbox-group {
    float: left;
    width: calc(100% - 130px);
    margin-bottom: 13px;
  }
  .el-checkbox.is-bordered + .el-checkbox.is-bordered {
    margin-left: 0 !important;
  }
}
.fl {
  float: left;
}
.info_ulList li {
  min-height: 36px;
  margin-bottom: 15px;
}
.mb0 {
  margin-bottom: 0 !important;
}
.editCon {
  position: relative;
  clear: both;
  .wordNumber {
    position: absolute;
    right: 5px;
    bottom: 5px;
  }
  ::v-deep .ql-toolbar.ql-snow {
    line-height: 36px;
  }
  ::v-deep .ql-editor {
    font-size: 15px;
    line-height: 26px;
    padding: 5px 10px;
    color: #303133;
  }
  ::v-deep .ql-editor.ql-blank::before {
    font-style: initial;
  }
}
.width_370 {
  width: 370px;
  ::v-deep .el-input__inner {
    height: 36px;
    line-height: 36px;
    border-radius: 3px;
  }
}
.info_label {
  width: 80px;
  height: 36px;
  line-height: 36px;
  text-align: right;
  color: #454545;
  vertical-align: top;
}
.iconbitian {
  color: #da4a4a;
  font-size: 10px;
}
.length_info_label {
  width: 130px;
  height: 36px;
  line-height: 36px;
  text-align: right;
  color: #454545;
  vertical-align: top;
}
.margin_10 {
  margin-right: 10px;
}
.organNameLabel {
  width: 130px !important;
}
.info_input {
  width: 360px;
  height: 36px;
  line-height: 36px;
  border: 1px solid #e6e6e6;
  border-radius: 3px;
  padding: 0 8px;
}
.input_175 {
  width: 175px;
  height: 36px;
  line-height: 36px;
  border: 1px solid #e6e6e6;
  border-radius: 3px;
  padding: 0 8px;
}
.openModuleDiv {
  padding-left: 17px;
}
.openModule {
  height: 36px;
  line-height: 36px;
  padding: 0 15px;
  border-radius: 3px;
  border: 1px solid #dcdfe6;
  margin-right: 10px;
  color: #0a70b0;
  cursor: pointer;
  margin-bottom: 5px;
  ::v-deep .el-checkbox__label {
    padding-left: 0px;
  }
}
.openModule.el-checkbox.is-bordered.is-checked {
  background: url("../../../../../assets/images/common/checkboxBg.png") right
    bottom no-repeat;
}
.openModule {
  ::v-deep .el-checkbox__inner {
    display: none;
  }
}
.openModule:hover {
  background: rgba(10, 112, 176, 0.6);
  color: #fff;
}
.logoCon {
  height: 20px;
  line-height: 20px;
  margin-bottom: 10px;
  .logoTit {
    font-size: 15px;
    color: #303133;
    padding-right: 5px;
  }
  .logoTip {
    font-size: 15px;
    color: #909399;
  }
}
.lastUpload {
  margin-right: 0px !important;
}
.uploadMettingImg {
  // position: absolute;
  // right: 0;
  // top: 70px;
  width: 312px;
}
.el-upload__tip {
  text-align: left;
  height: 30px;
  line-height: 30px;
  color: #ff9a50;
  font-size: 15px;
  width: 600px;
}
.uploadLi {
  margin-bottom: 0px !important;
}
.centerIntroTit {
  width: 130px;
  height: 20px;
  line-height: 20px;
  text-align: right;
  font-weight: bold;
  color: #303133;
  vertical-align: top;
  margin-bottom: 10px;
  i {
    font-weight: initial;
  }
}
.quill-editor {
  ::v-deep .ql-container {
    height: 254px !important;
  }
}
.myQuillEditor {
  width: calc(100% - 130px);
}
.editCon::after {
  content: "";
  height: 0;
  display: block;
  clear: both;
  visibility: hidden;
}
.btnCon {
  // text-align: center;
}
.operateBtn,
.nextStepBtn {
  border: none;
  height: 40px;
  cursor: pointer;
  line-height: 40px;
  padding: 0 20px;
  min-width: 88px;
  border-radius: 3px;
  font-size: 15px;
  color: #fff;
  background: #0a70b0;
}
/**第四步样式 */
.info_step_4 {
  width: 980px;
  margin: auto;
  .applySuc {
    width: 260px;
    margin: auto;
    margin-top: 30px;
    text-align: center;
    .applySucLogo:before {
      content: "\e63c";
      font-size: 64px;
      color: #00c579;
    }
    h3 {
      font-size: 22px;
      height: 40px;
      line-height: 40px;
      color: #303133;
      margin-top: 15px;
      margin-bottom: 6px;
      letter-spacing: 1px;
    }
    span {
      display: block;
      font-size: 15px;
      line-height: 30px;
      color: #909399;
      margin-bottom: 20px;
    }
  }
  .subSucCon {
    background: #fafafa;
    width: 624px;
    padding-top: 25px;
    padding-bottom: 10px;
    margin: auto;
    margin-bottom: 30px;
    .subInforDiv {
      width: 400px;
      margin: 0 auto;
    }
    li {
      margin-bottom: 15px;
      .patientItem:nth-of-type(1) {
        display: inline-block;
        width: 98px;
        text-align: right;
        line-height: 24px;
      }
      .patientItemCon:nth-of-type(2) {
        display: inline-block;
        line-height: 24px;
        font-size: 14px;
        color: #303133;
      }
    }
  }
}
/**第四步样式结束 */
</style>
