<template>
  <div class="imageDetailCon">
    <div class="productBox">
      <div class="productCon">
        <span class="productName">镜像预警</span>
      </div>
      <span @click="closeFn" class="close-btn iconfont icon-guanbi"></span>
    </div>
    <div class="imageSendContent">
      <!--目标仓库-->
      <div class="targetImage">
        <div class="targetImageForm">
          <div class="targetImageItem">
            <div class="targetImageTit">
              <span>发布产品</span><i class="iconfont clr_red">&#xe6c5;</i>
            </div>
            <el-select
              class="w300"
              size="small"
              v-model="product_id"
              filterable
              @change="beganGetPublishRecord"
            >
              <el-option
                v-for="(item, index) in productList"
                :key="index"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </div>
          <!-- <div class="targetImageItem ml10">
            <div class="targetImageTit">
              <span>研发项目</span><i class="iconfont clr_red">&#xe6c5;</i>
            </div>
            <el-select
              class="w200"
              size="small"
              @change="changeProject"
              v-model="publishWarnParam.zentao_project_id"
              filterable
            >
              <el-option
                v-for="(item, index) in projectList"
                :key="index"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </div> -->
          <div class="targetImageItem ml10">
            <div class="targetImageTit">
              <span>发布记录</span><i class="iconfont clr_red">&#xe6c5;</i>
            </div>
            <el-select
              class="w300"
              size="small"
              v-model="publishWarnParam.publish_id"
              filterable
            >
              <el-option
                v-for="(item, index) in publishRecordList"
                :key="index"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </div>
        </div>
      </div>
      <div class="publishTypeLabel">
        通知人员<i class="iconfont clr_red">&#xe6c5;</i>
      </div>
      <div class="publishTip">
        通知历史有下载镜像使用的人员。
      </div>
      <div class="">
        <el-select
          class="noticeSelect"
          size="small"
          v-model="publishWarnParam.version"
          filterable
        >
          <el-option
            v-for="(item, index) in imageTypeList"
            :key="index"
            :label="item.name"
            :value="item.id"
          ></el-option>
        </el-select>
      </div>
      <!--问题及风险-->
      <div class="publishTypeCon">
        <div class="publishTypeLabel">
          问题及风险<i class="iconfont clr_red">&#xe6c5;</i>
        </div>
        <quill-editor
          ref="question"
          v-model="publishWarnParam.risk_issue"
          class="myQuillEditor clear"
          :options="editorOption"
          @change="onEditorChange($event)"
        />
        <form
          action=""
          method="post"
          enctype="multipart/form-data"
          id="uploadFormMulti"
        >
          <input
            style="display: none"
            :id="uniqueId2"
            type="file"
            name="files"
            multiple
            accept="image/jpg,image/jpeg,image/png,image/gif"
            @change="uploadEditImg('uploadFormMulti')"
          />
        </form>

        <div class="publishTypeLabel">
          处理方法及注意事项<i class="iconfont clr_red">&#xe6c5;</i>
        </div>
        <quill-editor
          ref="platformfooter"
          v-model="publishWarnParam.handling_method"
          class="myQuillEditor clear"
          :options="editorOption"
          @change="onEditorChange($event)"
        />
        <form
          action=""
          method="post"
          enctype="multipart/form-data"
          id="uploadFormFooterMulti"
        >
          <input
            style="display: none"
            :id="uniqueId"
            type="file"
            name="files"
            multiple
            accept="image/jpg,image/jpeg,image/png,image/gif"
            @change="uploadFooterEditImg('uploadFormFooterMulti')"
          />
        </form>
        <!--相关附件-->
        <div class="fileCon">
          <div class="publishTypeLabel">相关附件</div>
          <div class="publishTip">
            添加必要的更新说明、使用说明等文档，指导镜像下载人员如何使用。
          </div>
          <div class="fileList" v-for="(file, i) in fileList" :key="i">
            <div class="fileItem">
              <div class="fileItemLeft">
                <img src="@/assets/images/common/oneLevel.png" />
                <div class="fileInfor">
                  <div class="fileHead">
                    <span class="fileName">{{ file.file.name }}</span>
                    <span class="fileSize"
                      >（{{ file.file.size | dealFileSize }}）</span
                    >
                  </div>
                  <div class="fileBottom">
                    <span class="uploadPeople">老王</span>
                    <span class="uploadTime">{{
                      file.requestParas.business_time
                    }}</span>
                  </div>
                </div>
              </div>
              <i class="iconfont icon-tuichu1" @click="deleteFile(file, i)"></i>
            </div>
            <label
              v-show="file.pecent == 100"
              class="el-upload-list__item-status-label"
            >
              <i class="el-icon-upload-success el-icon-circle-check"></i>
            </label>
            <i
              v-if="file.pecent < 100 && !file.reUpload"
              :style="{ width: file.pecent + '%' }"
              class="uploadProcess"
            ></i>
            <div class="el-progress">
              <i
                class="el-progress__text clr_green"
                v-if="loading && file.pecent < 100"
                >{{ file.pecent }}%</i
              >
            </div>
          </div>
        </div>
        <div class="operateAddBtn" @click="uploadFile">
          <i class="iconfont icon-xinzeng"></i>
          <span>上传</span>
        </div>
        <!-- 大文件上传 -->
        <input
          id="fileInput"
          class="hidden"
          type="file"
          multiple
          :accept="accept[file_kind]"
        />
      </div>
    </div>
    <div class="imageSendBtn">
      <el-button
        class="fabuBtn"
        size="small"
        type="primary"
        @click="beganPublishWarn()"
      >
        <i class="iconfont icon-fabu mr5"></i>发布
      </el-button>
      <el-button size="small" class="cancelBtn" @click="closeFn()">
        取消
      </el-button>
    </div>
  </div>
</template>
<script>
import pagination from "@/components/common/pagination";
import { getPublishRecordListFn } from "@/api/formalLibrary";
import { addWarn, editdWarn } from "@/api/formalLibrary";
import { quillEditor } from "vue-quill-editor";
import Quill from "quill";
import "quill/dist/quill.core.css";
import "quill/dist/quill.snow.css";
import "quill/dist/quill.bubble.css";
import { Upload } from "@/utils/lib/Upload";
export default {
  components: {
    pagination,
    quillEditor,
  },
  props: {
    productList: Array,
    isUpdate: {
      type:Boolean,
      default: false,
    }
  },
  data() {
    return {
      curImage: {}, // 添加或移除依赖服务时用到
      choosedServiceData: [],
      product_id: '',
      publishWarnParam: {
        publish_id: "",
        risk_issue: "",
        handling_method: "",
        users: [],
        accessories: [],
      },
      publishTypeArr: [
        {
          name: "正式版本",
          value: 1,
        },
        {
          name: "临时版本",
          value: 2,
        },
        {
          name: "试生产版本",
          value: 3,
        },
      ],
      publishRecordList: [], // 发布记录
      imageTypeList: [],
      tableHeight: "100%",
      totalVersion: 0,
      statusObj: {
        1: { label: "在用", color: "#1890ff" },
        2: { label: "停用", color: "#da4a4a" },
      },
      totalService: 0,
      imageDetailObj: {},
      groupProductList: [],
      addSeviceCenterForm: "",
      addImgRange: "",
      uniqueId: "testUpload",
      addImgRange2: "",
      uniqueId2: "testFooterUpload",
      content: "", // 编辑器内容
      editorOption: {
        placeholder: "请输入服务中心简介...",
        modules: {
          toolbar: [
            ["bold", "italic", "underline", "strike"], // toggled buttons
            ["blockquote", "code-block", "image"],
          ],
          clipboard: {
            // 粘贴过滤
            matchers: [[Node.ELEMENT_NODE, this.HandleCustomMatcher]],
          },
        },
      }, // 编辑器操作选项
      loading: false,
      file_name: "",
      file_size: "",
      accept: {
        1: ".apk,",
        2: ".jpg,.jpe,.jpeg,.png,.gif,.bmp,.pdf,.svg,",
        3: ".rar,.zip,.7z,.msi,.exe",
      },
      uploadSucData: [],
      fileList: [],
      file_kind: 3, // .rar,.zip,.7z
    };
  },
  filters: {
    dealFileSize(btyes) {
      if (btyes === 0) {
        return "0B";
      }
      const k = 1024;
      const sizes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
      let i = Math.floor(Math.log(btyes) / Math.log(k));
      if (i < 1) {
        i = 0;
      }
      const num = btyes / Math.pow(k, i);
      const value = num.toFixed(3) / 1;
      const unit = sizes[i];
      const text = `${value}${unit}`;
      return text;
      // return {
      //   value,
      //   unit,
      //   text,
      // };
    },
  },
  methods: {
    verifyIsFrx(file) {
      // console.log(file)
      const fileName = file.name;
      this.currentFileName = file.name;
      const type = fileName.substring(fileName.lastIndexOf(".")).toLowerCase();
      var isFrx = null;
      isFrx =
        type === ".zip" ||
        type === ".rar" ||
        type === ".msi" ||
        type === ".exe";
      if (!isFrx) {
        this.$message.error("上传文件只能是zip、rar、msi、exe格式!");
        return false;
      }
      const fileSize = file.size / 1024 / 1024 < 300;
      if (!fileSize) {
        this.$message.error("上传文件不能超过300M!");
        return false;
      }
      return isFrx;
    },
    // 初始化资料上传
    initUpload() {
      const _this = this;
      _this.$nextTick(() => {
        // 初始化上传
        _this.upload = new Upload({
          eleId: "fileInput", // inputid
          // businessId: _this.course.id,
          businessId: 0,
          businessType: '',
          systemId: 0,
          departCode: "other",
          inputFileName: "file",
          file_type: 1,
          callback: {
            // 相同文件提示
            sameCallBack(file) {
              _this.$message.error(`已选择资料：${file.name}`);
            },
            // 选择文件时回调
            insert(file) {
              console.log("file", file);
              _this.file_name = file.file.name;
              _this.file_size = file.file.size;
              // 文件扩展名对比
              var lastIndex = file.file.name.lastIndexOf(".");
              var fileType = file.file.name.substr(lastIndex + 1).toLowerCase();
              // 验证文件格式是否正确
              if (!_this.verifyIsFrx(file.file)) {
                return;
              }
              if (_this.accept[_this.file_kind].includes(fileType)) {
                _this.fileList.push(file);
                // 开始自动上传
                const arr = _this.upload.getQueueList();
                const failArr = _this.upload.getFailList();
                if (arr.length === 0 && failArr.length === 0) {
                  _this.$message.error("请选择文件");
                  return;
                }
                _this.loading = true;
                if (arr.length > 0) {
                  _this.upload.uploadStart();
                }
                if (failArr.length > 0) {
                  _this.upload.uploadRecover();
                }
              } else {
                // 删除上传队列
                _this.upload.deleleQueue(file);
                _this.$message.error("文件格式错误");
              }
            },
            // 文件上传中回调
            process(file) {
              _this.fileList.forEach((dic) => {
                if (dic.fileId === file.fileId) {
                  dic.pecent = file.pecent;
                }
              });
            },
            // 上传完成回调
            finish(file) {
              _this.fileList.forEach((dic) => {
                if (dic.fileId === file.fileId) {
                  dic.pecent = 100;
                }
              });
            },
            // 上传失败回调
            error(file) {
              // console.log(file)
              _this.$message.error(file.errorText);
              // _this.$message.error(file.file.name + '上传失败')
              _this.loading = false;
              _this.fileList.forEach((dic) => {
                if (dic.fileId === file.fileId) {
                  dic.reUpload = true;
                }
              });
            },
            // 全部完成时
            complete(arr) {
              _this.loading = false;
              if (arr.length === 0) return;
              arr.forEach((item) => {
                _this.uploadSucData.push({
                  document_id: item.document_id,
                  document_name: _this.file_name,
                  document_size: item.file_size,
                });
              });
              _this.dealUploadSucBigFile();
            },
          },
        });
        var handler = function () {
          var data = {
            modality: _this.modality,
            format_code: _this.file_kind == 3 ? "DICOMDIR" : "",
          };
          _this.upload.setUploadQueue(data);
        };
        document
          .getElementById("fileInput")
          .removeEventListener("change", handler);
        document.getElementById("fileInput").value = "";
        document.getElementById("fileInput").onchange = handler;
      });
    },
    dealUploadSucBigFile() {
      const fileObj = {
        document_id:
          this.uploadSucData[this.uploadSucData.length - 1].document_id,
        document_name: this.file_name,
        document_size:
          this.uploadSucData[this.uploadSucData.length - 1].document_size,
      };
      this.publishWarnParam.accessories.push(fileObj);
      // this.$emit('dealUploadSucBigFile', this.uploadSucData, this.file_name, this.file_size)
    },
    // 删除文件
    deleteFile(file, index) {
      const _this = this;
      this.fileList.splice(index, 1);
      // 需要判断已上传和未上传
      if (file.folder_flag) {
        // 已上传资料
        deleteLoadFile({
          document_id: file.id,
          business_id: "0",
        }).then((res) => {
          if (res.code !== 0) {
            _this.$message.error(res.msg);
            return;
          }
          _this.$message({
            type: "success",
            message: "删除成功",
          });
        });
      } else {
        document.getElementById("fileInput").value = "";
        // 删除上传队列
        this.upload.deleleQueue(file);
      }
    },
    // 点击上传
    uploadFile() {
      document.getElementById("fileInput").click();
    },
    closeFn() {
      this.$emit("closeFn");
    },
    // 验证发布镜像
    validatePublishWarn() {
      if (this.product_id == "") {
        this.$message.error("请选择一个产品");
        return;
      }
      if (this.publishWarnParam.publish_id == "") {
        this.$message.error("请选择一条发布记录");
        return;
      }
      if (this.publishWarnParam.users.length == 0) {
        this.$message.error("请选择通知人员");
        return;
      }
      if (this.publishWarnParam.risk_issue == "") {
        this.$message.error("请输入问题及风险");
        return;
      }
      if (this.publishWarnParam.handling_method == "") {
        this.$message.error("请输入处理方法及注意事项");
        return;
      }
      return true;
    },
    // 发布警告
    async beganPublishWarn() {
      if (this.validatePublishWarn()) {
        let res
        let tip = '新增预警成功'
        if (!this.isUpdate) {
          res = await addWarn(this.publishWarnParam);
        } else {
          res = await editdWarn(this.publishWarnParam);
          tip = '编辑预警成功'
        }
        if (res.code == 0) {
          this.$message.success(tip);
          this.$emit('refreshList')
        } else {
          this.$message.error(res.msg);
        }
      }
    },
    onEditorChange (event, type) { // 富文本字数
      if (type) {
        event.quill.deleteText(800, 4)
        if (this.portalsInfo.footer === '') {
          this.addlength = 0
        } else {
          this.addlength = event.quill.getLength() - 1
        }
      }
    },
    // 编辑器上传图片
    async uploadEditImg(id) {
      var vm = this;
      var obj = document.getElementById("uploadFormMulti");
      var formData = new FormData(obj);
      try {
        vm.uploadImgReq(formData); // 自定义的图片上传函数
      } catch ({ message: msg }) {
        document.getElementById(vm.uniqueId).value = "";
        vm.$message.warning(msg);
      }
    },
    // 尾页 上传图片
    async uploadFooterEditImg(id) {
      var vm = this;
      var obj = document.getElementById("uploadFormFooterMulti");
      // 获取文件对象
      var fileObj = document.getElementById(vm.uniqueId2);
      var file = fileObj.files[0]; 
      var fileName = file.name
      var fileSize = file.size
      var formData = new FormData(obj);
      formData.append('file_name',fileName)
      try {
        vm.uploadImgReq(formData,fileName,fileSize,'footer'); // 自定义的图片上传函数
      } catch ({ message: msg }) {
        document.getElementById(vm.uniqueId2).value = "";
        vm.$message.warning(msg);
      }
    },
    async uploadImgReq(myformData) {
      // 这里实现你自己的图片上传
      var vm = this;
      const formdata1 = new FormData();
      formdata1.append("files", myformData);
      const res = await uploadFile(myformData);
      if (res.code === 0) {
        const result = res.data;
        // const eitImgResult = await getEditImg(result[0].file_token)
        // src 如果传base64位给后端会比较长  所以改传一个图片链接地址但 直接用图片链接的话会报401（需要传token）
        // 因为是get请求然后链接是拼接的 所以token 不方便传给后台 所以需要后端网关处理下(解除该接口需要token的限制)
        var src =
          configUrl.apiUrl + "/api-operate" + `/medias/${result[0].file_token}`;
        vm.addImgRange = vm.$refs.text.quill.getSelection();
        vm.$refs.text.quill.insertEmbed(
          vm.addImgRange != null ? vm.addImgRange.index : 0,
          "image",
          src,
          Quill.sources.USER
        );
      } else {
      }
    },
    // 获取某个产品下的 发布记录
    async beganGetPublishRecord() {
      const res = await getPublishRecordListFn({
        product_id: this.product_id,
      });
      if (res.code == 0) {
        this.publishRecordList = res.data;
      } else {
        this.$message.error(res.msg);
      }
    },
    // 初始化数据
    initData(warnDetailObj) {
      // warnDetailObj有值 说明是编辑
      if (warnDetailObj) {
       this.publishWarnParam = {
         publish_id: warnDetailObj.publish_id,
         risk_issue: warnDetailObj.risk_issue,
         handling_method: warnDetailObj.handling_method,
         users: warnDetailObj.users,
         accessories: warnDetailObj.accessories,
       }
      } else {
        this.publishWarnParam = this.$options.data().publishWarnParam
      }



    },
  },
  mounted() {
      var vm = this;
      // vm.beganGetAllProduct();
      // 初始化 上传文件
      vm.initUpload();
      //vm.paramsFormdata = new FormData();
      var imgHandler = async function (image) {
        vm.addImgRange = vm.$refs.question.quill.getSelection();
        if (image) {
          var fileInput = document.getElementById(vm.uniqueId); //隐藏的file文本ID
          fileInput.click(); //加一个触发事件
        }
      };
      var footerImgHandler = async function (image) {
        vm.addImgRange2 = vm.$refs.platformfooter.quill.getSelection();
        if (image) {
          var fileInput = document.getElementById(vm.uniqueId2); //隐藏的file文本ID
          fileInput.click(); //加一个触发事件
        }
      };
      
      vm.$nextTick(() => {
        console.log('vm.$refs.question',vm.$refs.question)
        vm.$refs.question.quill.getModule("toolbar").addHandler("image", imgHandler);
        vm.$refs.platformfooter.quill.getModule("toolbar").addHandler("image", footerImgHandler);
      })
  },
};
</script>
<style lang="less" scoped>
.imageDetailCon {
  .productBox {
    display: flex;
    height: 48px;
    justify-content: space-between;
    align-items: center;
    padding-right: 10px;
    border-bottom: 1px solid #DCDFE6;
    .productCon {
      //   display:flex;
      padding-left: 20px;
      .productName {
        font-weight: 600;
        font-size: 18px;
        color: #000000;
      }
    }
    .icon-guanbi {
      font-size: 24px;
      color: #c0c4cc;
      cursor: pointer;
    }
  }
  .imageSendContent {
    height: calc(100vh - 106px);
    padding: 10px;
    padding-left:20px;
    overflow: auto;
  }
  ::v-deep .targetImage {
    .targetImageTit {
      line-height: 36px;
      font-weight: 600;
      font-size: 14px;
      color: #303133;
      i {
        margin-left: 5px;
        font-weight: initial;
      }
    }
    .targetImageForm {
      display: flex;
      .ml40 {
        margin-left: 40px;
      }
    }
  }
  ::v-deep .imageSendContent {
    .el-radio-group {
      height: 32px;
      line-height: 30px;
      .el-radio-button__inner {
        height: 32px;
        line-height: 30px;
        padding: 0 10px !important;
        text-align: center;
      }
      .el-radio-button__orig-radio:checked + .el-radio-button__inner {
        background-color: #0a70b0 !important;
        border-color: #0a70b0 !important;
      }
    }
  }
  .productTitHead {
    display: flex;
    height: 40px;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #dcdfe6;
    padding: 0 20px;
    .productTitHeadLeft {
      display: flex;
      align-items: center;
      .productTitHeadIcon {
        width: 3px;
        height: 15px;
        background: #0a70b0;
        border-radius: 2px;
        margin-right: 8px;
      }
      img {
        margin-right: 5px;
      }
      .productTitText {
        font-weight: 600;
        font-size: 15px;
        color: #303133;
      }
      .productTitHeadTip {
        font-size: 14px;
        color: #909399;
        margin-left: 10px;
      }
    }
    .addProductCon {
      cursor: pointer;
      i {
        font-size: 16px;
        color: #0a70b0;
        margin-right: 5px;
      }
      .addProductConText {
        font-size: 14px;
        color: #0a70b0;
      }
    }
  }
}
.publishTypeLabel {
  line-height: 24px;
  font-weight: 600;
  font-size: 14px;
  color: #303133;
  margin-top: 5px;
  i {
    font-weight: initial;
    margin-left: 5px;
  }
}
.publishTip {
  font-size: 14px;
  color: #909399;
  line-height: 24px;
}
.productVersionCon {
  height: 300px;
  .productVersionTable {
    height: 250px;
  }
}
.noticeSelect {
  width: 100%;
}
.fileCon {
  margin-top: 10px;
  .fileList {
    position: relative;
    .fileItem {
      padding: 10px;
      margin-right: 10px;
      margin-bottom: 10px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: #f5f7fa;
      border-radius: 3px;
      .fileItemLeft {
        display: flex;
        align-items: center;
        img {
          width: 36px;
          height: 36px;
          margin-right: 10px;
        }
        .fileInfor {
          .fileHead {
            .fileName {
              font-size: 14px;
              color: #303133;
              line-height: 20px;
            }
            .fileSize {
              font-size: 12px;
              color: #909399;
            }
          }
          .fileBottom {
            .uploadPeople {
              font-size: 12px;
              color: #606266;
            }
            .uploadTime {
              font-size: 12px;
              color: #606266;
              margin-left: 5px;
            }
          }
        }
      }
      .icon-tuichu1 {
        font-size: 14px;
        color: #c0c4cc;
        cursor: pointer;
      }
    }
  }
}
.serviceOperate {
  display: flex;
  font-size: 14px;
  .updateServe {
    color: #0a70b0;
  }
  .deleteServe {
    color: #da4a4a;
    margin-left: 10px;
  }
}
.clircle {
  position: relative;
  top: -2px;
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  &.running::after {
    position: absolute;
    top: -1px;
    left: -1px;
    width: 100%;
    height: 100%;
    border-width: 1px;
    border-style: solid;
    border-radius: 50%;
    content: "";
    border-color: #1890ff;
    animation: animate 1.2s ease-in-out infinite;
  }
  &.stoped::after {
    border-color: #da4a4a;
  }
}
.operateAddBtn {
  height: 32px;
  margin-top: 10px;
  cursor: pointer;
  background: #ffffff;
  border: 1px dashed #dcdfe6;
  border-radius: 3px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  color: #0a70b0;
  i {
    margin-right: 5px;
    font-size: 13px;
  }
}
::v-deep .w105 {
  width: 105px;
  margin-right: 5px;
  color: #0a70b0;
  font-size: 14px;
  .el-input__inner,
  .el-input__icon {
    height: 20px !important;
    line-height: 20px !important;
  }
}
.quill-editor {
  ::v-deep .ql-container {
    height: 158px !important;
  }
}
.imageSendBtn {
  height: 56px;
  background: #ffffff;
  display: flex;
  align-items: center;
  padding-left: 20px;
}
.fabuBtn {
  width: 80px;
  background: #e6a23c;
  border-color: #e6a23c;
  text-align: center;
}
.cancelBtn {
  width: 80px;
  text-align: center;
}
.uploadProcess {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 1px;
  background: #0a70b0;
}
@keyframes animate {
  0% {
    transform: scale(0.8);
    opacity: 0.5;
  }
  to {
    transform: scale(2);
    opacity: 0;
  }
}
</style>