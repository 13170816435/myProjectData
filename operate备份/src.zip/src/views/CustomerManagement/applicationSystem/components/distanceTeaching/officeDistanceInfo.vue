<template>
  <div class="userinfo">
    <div class="userinfo-title">
      <span class="userinfo-titleinfo">{{ titletext }}</span>
      <span
        @click="closeFn"
        class="close-btn iconfont iconchuangjianshibai"
      ></span>
    </div>
    <el-form
      :model="pacsinfo.formInfo"
      ref="formInfo"
      label-width="120px"
      class="demo-ruleForm"
    >
      <div class="contaner">
        <div class="contaner-info">
          <el-row class="contaner-info-title">
            <span class="border-left"></span>基本信息

            <!--非 眼科和放疗--->
            <span
              class="officeTeachDesc"
              v-if="
                pacsinfo.formInfo.service_code &&
                pacsinfo.formInfo.service_code != 402007 &&
                pacsinfo.formInfo.service_code != 402008
              "
            >
              {{
                getOfficeName(pacsinfo.formInfo.service_code)
              }}科室教学：适用于{{
                getOfficeName(pacsinfo.formInfo.service_code)
              }}科学习资源查阅管理、学习、考试、诊断思维训练等教学场景。
            </span>
            <!-- 眼科和放疗--->
            <span
              class="officeTeachDesc"
              v-if="
                pacsinfo.formInfo.service_code &&
                (pacsinfo.formInfo.service_code == 402007 ||
                  pacsinfo.formInfo.service_code == 402008)
              "
            >
              {{
                getOfficeName(pacsinfo.formInfo.service_code)
              }}科室教学：适用于{{
                getOfficeName(pacsinfo.formInfo.service_code)
              }}科学习资源查阅管理、学习、考试等教学场景。
            </span>
          </el-row>
          <el-row class="mt15 pl10 pr10">
            <div class="formItemDiv" v-if="pacsinfo.category_desc">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>授权产品：</span
              >
              <span class="formItemValue">{{ pacsinfo.category_desc }}</span>
            </div>
            <div class="formItemDiv" v-else>
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>授权产品：</span
              >
              <span class="serviceListCon">
                <span
                  class="system_type"
                  :class="{
                    active: pacsinfo.formInfo.service_code === item.code,
                  }"
                  v-for="(item, index) in deptTeachServiceList"
                  :key="index"
                  @click="activeTeachSystemFn(index, item)"
                >
                  {{ item.name }}
                </span>
              </span>
            </div>

            <!-- <div class="formItemDiv">

            <el-form-item label="授权产品 ：" v-if="pacsinfo.product_name">
              <div>{{ pacsinfo.product_name }}</div>
            </el-form-item>
            <el-form-item v-else label="授权产品 ：" class="mb5">
              <span
                class="system_type"
                :class="{ active: pacsinfo.activesystem === index }"
                v-for="(item, index) in deptTeachServiceList"
                :key="index"
                @click="activeSystemFn(index, item.code)"
                >{{ item.name }}</span
              >
            </el-form-item>
            </div> -->
          </el-row>
        </div>

        <div class="contaner-info contaner-bottom">
          <el-row class="contaner-info-title instituteInfor">
            <el-col :span="12">
              <span class="border-left"></span>关联系统
            </el-col>
            <el-col :span="12" class="tr clr_0a">
              <span
                class="function-btn bg_e6 clr_ff"
                @click="isAddInstutionOrSystem"
              >
                <i class="iconfont iconxinzeng"></i>关联系统
              </span>
            </el-col>
          </el-row>
          <div
            class="contaner-info-list"
            v-if="pacsinfo.multipleSelection.length > 0"
          >
            <div class="contaner-info-list-item clr_999">
              <div class="width_60">操作</div>
              <div class="width_300">系统名称</div>
              <div class="width_100">系统类型</div>
            </div>
            <div class="listItemBox">
              <div
                class="contaner-info-list-item"
                v-for="(item, index) in pacsinfo.multipleSelection"
                :key="index"
              >
                <div class="width_60">
                  <span
                    @click="delInstitutionOrSystemFn(item.id)"
                    class="icon-btn bg_f5"
                    type="text"
                    size="small"
                    title="删除"
                    ><i class="iconfont icondongjie"></i
                  ></span>
                </div>
                <div class="width_300">{{ item.name }}</div>
                <div class="width_100">{{ item.product_name }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="mt15">
        <el-button
          type="primary"
          size="medium"
          @click="submitForm('formInfo', 'commit')"
          >提交</el-button
        >
        <el-button size="medium" @click="submitForm('formInfo')"
          >取消</el-button
        >
      </div>
    </el-form>

    <el-dialog
      title="选择系统"
      :append-to-body="true"
      :visible.sync="pacsinfo.isChioseOrganOrSystem"
      width="900px"
      v-dialogDrag
      :before-close="instclose"
    >
      <div class="CAdialog">
        <div>
          <el-input
            v-model="pacsinfo.serchName"
            placeholder="系统名称"
            style="width: 240px"
          ></el-input>
          <el-button
            type="primary"
            size="small"
            class="ml10"
            @click="searchSystemFn"
            >查询</el-button
          >
        </div>
        <el-table
          ref="systemTable"
          class="mt10"
          border
          :data="pacsinfo.systemList"
          v-bind:class="{ noTableData: pacsinfo.systemList.length == 0 }"
          :header-cell-style="{ background: '#DCDFE6', color: '#1E1D22' }"
          style="width: 100%"
          :row-key="getRowKeys"
          highlight-current-row
          @select="handleSelectionChange"
        >
          <el-table-column
            type="selection"
            width="55"
            :reserve-selection="true"
          ></el-table-column>
          <el-table-column
            prop="name"
            label="系统名称"
            :show-overflow-tooltip="true"
            width="250"
          ></el-table-column>
          <el-table-column
            prop="product_name"
            label="系统类型"
            width="100"
          ></el-table-column>
          <el-table-column
            prop="admin_name"
            label="联系人"
            width="100"
          ></el-table-column>
          <el-table-column
            prop="admin_phone"
            label="联系电话"
          ></el-table-column>
        </el-table>
        <div class="blockPage">
          <pagination-tool
            :layout="pageLayout"
            :total="pageInfo.total_count"
            :page.sync="pageInfo.page_index"
            :limit.sync="pageInfo.page_size"
            @pagination="pageSizeChangeFn"
          />
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button
          size="small"
          plain
          @click="pacsinfo.isChioseOrganOrSystem = false"
          >取 消</el-button
        >
        <el-button
          type="primary"
          size="small"
          @click="ChioseOrganOrSystemFn('commit')"
          >确定</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>
<script>
import PaginationTool from "@/components/common/PaginationTool";
import {
  getAllManager,
  getUserPhone,
} from "@/api/platform_costomer/telemedicine";
import { uploadMediaFile } from "@/api/commonHttp";
import { connectUrlParam } from "@/components/commonJs";
export default {
  components: {
    PaginationTool,
  },
  props: {
    pacsinfo: Object,
    pageInfo: Object,
    serviceList: Array,
    getDetailFinished: Boolean,
    InstitutionsArr: Array,
    deptTeachServiceList: Array,
  },
  data() {
    return {
      titletext: "开设远程教学中心",
      activesystemIndex: -1,
      pageLayout: "total, prev, pager, next, jumper",
      addlength: "",
      moduleServiceName: "",
      allManagerArr: [],
      addImgRange: "",
      uniqueId: "testUpload",
      teachTypeList: [
        {
          name: "科室教学",
          code: "410",
        },
      ],
      currentRow: null, // 当前选中行
    };
  },
  watch: {
    getDetailFinished: function (val) {
      if (val) {
        //
      }
    },
  },
  methods: {
    initAdd() {
      this.titletext = "新增科室教学";
      // this.choosedOrganName = "";
      // this.isAutoUpload = false;
      // this.initFormData();
    },
    initEdit(id) {
      this.titletext = "编辑科室教学";
      // this.isAutoUpload = true;
      // this.getMyServiceCenterDetail(id);
    },
    getOfficeName(service_code) {
      if (service_code == 402001) {
        return "放射";
      } else if (service_code == 402002) {
        return "超声";
      } else if (service_code == 402003) {
        return "心电";
      } else if (service_code == 402004) {
        return "内镜";
      } else if (service_code == 402005) {
        return "病理";
      } else if (service_code == 402006) {
        return "核医学";
      } else if (service_code == 402007) {
        return "眼科";
      } else if (service_code == 402008) {
        return "放疗";
      }
    },
    isAddInstutionOrSystem() {
      if (!this.pacsinfo.formInfo.service_code) {
        this.$message({ message: "请先选择授权产品", type: "error" });
        return;
      }
      this.$emit("isAddInstutionOrSystem");
    },
    pageSizeChangeFn(info) {
      this.$emit("pageSizeChangeFn", info);
    },
    searchSystemFn() {
      this.$emit("searchSystemFn");
    },
    ChioseOrganOrSystemFn(type) {
      this.$emit("ChioseOrganOrSystemFn", type);
    },
    chooseOrgan(val) {
      if (val.length === 0) {
        this.allManagerArr = [];
      } else {
        this.getMyManager(val);
      }
    },
    activeTeachSystemFn(index, item) {
      if (this.activesystemIndex != index) {
        this.$emit("activeTeachSystemFn", index, item);
      }
      this.activesystemIndex = index;
    },
    handleSelectionChange(selection) {
      const self = this;
      if (selection.length > 1) {
        self.$nextTick(() => {
          // 先清空选中，再选中当前行
          self.$refs.systemTable.clearSelection();
          const selectRowLength = selection.length;
          let curSelectRow = {};
          curSelectRow = selection[selectRowLength - 1];
          // 再选中最后一个
          self.$refs.systemTable.toggleRowSelection(selection.pop());
          self.$emit("selectOneSystemListFn", curSelectRow);
        });
      } else {
        // 只有一个选中行的情况
        if (selection.length == 1) {
          self.currentRow = selection[0];
          self.$emit("selectOneSystemListFn", self.currentRow);
        } else {
          self.$emit("selectOneSystemListFn", null);
        }
      }
    },
    selectCurRow(selection, row) {
      this.$emit("selectCurRowFn", selection, row);
    },
    // getSerchName (val) {
    //   this.$emit('getSerchName', val)
    // },
    instclose() {
      this.$emit("instclose");
    },
    getRowKeys(val) {
      // this.$emit('getRowKeys', val)
      return val.id;
    },
    async getMyManager(arr) {
      const self = this;
      let param = "";
      let str;
      if (arr) {
        arr.forEach((val, i) => {
          if (i === 0) {
            str = `?ids[0]=` + val;
          } else {
            str = `&ids[${i}]=` + val;
          }
          param = param + str;
        });
      }
      const res = await getAllManager(param);
      // const res = await getAllManager()
      if (res.code === 0) {
        self.allManagerArr = res.data;
        // 特殊处理  当改变机构时 如果接口里面返回的管理员还有 之前选择的管理员时就不清空管理员姓名和管理员手机号
        let hasThisManager = false;
        self.allManagerArr.forEach((val) => {
          if (val.id === self.pacsinfo.formInfo.manager_id) {
            hasThisManager = true;
          }
        });
        // 如果改变机构后 接口返回的管理员里面 没有之前设置的管理员的话 得把管理员信息清空
        if (!hasThisManager) {
          self.pacsinfo.formInfo.manager_id = "";
          self.pacsinfo.formInfo.manager_name = "";
          self.pacsinfo.formInfo.manager_phone = "";
        }
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    closeFn() {
      this.activesystemIndex = -1;
      this.$emit("closeFn");
    },
    submitForm(formName, type) {
      if (type == "commit") {
        if (this.pacsinfo.formInfo.service_code == "") {
          this.$message({ message: "请选择产品", type: "error" });
          return;
        }
        if (this.pacsinfo.multipleSelection.length == 0) {
          this.$message({ message: "请选择关联系统", type: "error" });
          return;
        }
      }
      var info = {
        formName: formName,
        refs: this.$refs,
        type: type,
      };
      this.$emit("submitOfficeDistanceForm", info);
    },
    delInstitutionOrSystemFn(_id) {
      this.$emit("delInstitutionOrSystemFn", _id);
    },
    // 下载图片
    downloadImg(file_id) {
      const vm = this;
      var src =
        configUrl.docUrl +
        "/api-document/download/document-id?document_id=" +
        file_id +
        "&is_crm_document=true";
      vm.addImgRange = vm.$refs.introduction.quill.getSelection();
      vm.$refs.introduction.quill.insertEmbed(
        vm.addImgRange != null ? vm.addImgRange.index : 0,
        "image",
        src,
        Quill.sources.USER
      );
    },

    async uploadImgReq(myformData, file_name, file_size) {
      // 这里实现你自己的图片上传
      var vm = this;
      let param = {
        file_name: file_name,
        file_size: file_size,
        position: 0,
        file_type: 0,
      };
      let paramUrl = connectUrlParam(param);
      const res = await uploadMediaFile(myformData, paramUrl);
      if (res.code === 0) {
        const result = res;
        // 获取图片
        vm.downloadImg(result.document_id);
      }
    },
  },
  mounted() {
    var vm = this;
    // var imgHandler = async function (image) {
    //   vm.addImgRange = vm.$refs.introduction.quill.getSelection();
    //   if (image) {
    //     var fileInput = document.getElementById(vm.uniqueId); //隐藏的file文本ID
    //     fileInput.click(); //加一个触发事件
    //   }
    // };
    // vm.$nextTick(() => {
    //   vm.$refs.introduction.quill.getModule("toolbar").addHandler("image", imgHandler);
    // })
  },
};
</script>
<style lang="less" scoped>
.userinfo {
  width: 800px;
  padding: 0px 25px;
  ::v-deep .el-select,
  .el-select__tags {
    display: block !important;
    width: 350px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .userinfo-title {
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    .userinfo-titleinfo {
      font-size: 18px;
      color: #1f2f3d;
      font-weight: bold;
    }
    .close-btn {
      position: absolute;
      right: 0px;
      top: 0px;
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .contaner {
    border: 1px solid #dcdfe6;
    height: calc(100vh - 112px);
    .contaner-info {
      // border-bottom: 1px dashed #dcdfe6;
      padding-bottom: 0px;
      .openModule {
        height: 36px;
        line-height: 36px;
        padding: 0 15px;
        border-radius: 3px;
        border: 1px solid #dcdfe6;
        margin-right: 10px;
        color: #0a70b0;
        cursor: pointer;
        margin-bottom: 5px;
        ::v-deep .el-checkbox__label {
          padding-left: 0px;
        }
      }
      .openModule.el-checkbox.is-bordered.is-checked {
        background: url("../../../../../assets/images/common/checkboxBg.png")
          right bottom no-repeat;
      }
      .openModule {
        ::v-deep .el-checkbox__inner {
          display: none;
        }
      }
      .openModule:hover {
        background: rgba(10, 112, 176, 0.6);
        color: #fff;
      }
      .contaner-info-title {
        height: 40px;
        line-height: 40px;
        background: rgba(250, 250, 253, 1);
        color: #1f2f3d;
        padding: 0px 10px;
        .border-left {
          display: inline-block;
          width: 3px;
          height: 14px;
          background: rgba(9, 113, 176, 1);
          margin-right: 7px;
          vertical-align: middle;
          position: relative;
          top: -1.5px;
        }
        .officeTeachDesc {
          font-size: 14px;
          color: #ef8900;
          padding-left: 57px;
        }
      }
      .system_type {
        display: inline-block;
        padding: 0px 20px;
        height: 36px;
        line-height: 34px;
        border: 1px solid #dcdfe6;
        border-radius: 18px;
        color: #0a70b0;
        cursor: pointer;
        margin: 0px 5px;
        margin-bottom: 5px;
      }
      .system_type:hover {
        border-color: #0a70b0;
      }
      .active {
        background: #0a70b0;
        color: #fff;
        border-color: #0a70b0;
      }
      .contaner-info-list {
        padding: 5px 20px 0 20px;
        height: calc(100% - 40px);
        overflow: auto;
      }
      .contaner-info-list-item {
        display: flex;
        min-height: 45px;
        align-items: center;
        border-bottom: 1px solid #e4e7ed;
        .width_60 {
          width: 60px;
        }
        .width_300 {
          width: 300px;
        }
        .width_100 {
          width: 100px;
        }
        .icon-btn {
          display: inline-block;
          width: 24px;
          height: 24px;
          color: #fff;
          line-height: 24px;
          text-align: center;
          padding: 0px;
          cursor: pointer;
          border-radius: 3px;
          margin-right: 8px;
        }
        .depspan {
          display: inline-block;
          padding: 0px 3px;
          color: #333;
        }
      }
      .listItemBox {
        height: calc(100% - 45px);
        overflow: auto;
      }
      .authorize-img {
        width: 48px;
        height: 48px;
        vertical-align: middle;
      }
      .clr_88 {
        color: #888888;
      }
      ::v-deep .el-form-item__label {
        width: 132px !important;
      }
    }
    .contaner-bottom {
      height: calc(100% - 152px);
    }
  }
  ::v-deep .formItemDiv {
    margin-bottom: 15px;
    display: flex;
    .formItemLabel {
      width: 132px;
      color: #303133;
      font-size: 14px;
      line-height: 30px;
      text-align: right;
      padding-right: 12px;
    }
    .formItemValue {
      color: #303133;
      font-size: 14px;
      line-height: 30px;
    }
    .serviceListCon {
      flex: 1;
    }
    .powerService {
      line-height: 30px;
    }
    .el-radio {
      height: 30px;
      line-height: 30px;
    }
    .width_285 {
      width: 285px;
      height: 36px;
      padding: 0 8px;
    }
  }
  .formItemDiv::after {
    content: "";
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  .operate-btn {
    width: 84px;
    height: 36px;
    line-height: 36px;
    border-radius: 3px;
    padding: 0px;
    border: none;
    border: 1px solid #dcdfe6;
  }
  .bg_e6 {
    background: #e6a23c;
  }
  .bg_f5 {
    background: #f56c6c;
  }
  .bg_0c {
    background: #0c83cd;
  }
  .bg_00 {
    background: #00ad78;
  }
  .w_300 {
    width: 300px;
  }
}
.pd8 {
  padding: 0 8px;
}
.iconxinzeng {
  padding-right: 3px;
}
::v-deep .delTip {
  font-size: 15px !important;
  color: #ef8900 !important;
}
::v-deep .el-table__fixed {
  height: 100% !important;
}
.centerAdmin {
  width: 50%;
  max-width: 300px;
}
.operateBtnDiv {
  margin-top: 4px;
}
.blockPage {
  position: relative;
}
.radioDiv {
  min-height: 30px;
}
.addressVal {
  font-size: 15px;
  color: #999;
  // display: inline-block;
  line-height: 28px;
  padding-left: 100px;
}
::v-deep .ql-editor {
  height: 200px;
}
::v-deep .quill-editor {
  float: left;
  width: calc(100% - 147px);
}
.CAdialog {
  padding: 10px 20px 0 20px;
  ::v-deep .el-table {
    height: 447px;
    th {
      background: #f5f5f5 !important;
    }
    .el-table__body-wrapper {
      height: calc(100% - 40px);
      overflow-y: auto;
    }
  }
  ::v-deep .el-table__empty-block {
    display: none;
  }

  ::v-deep .el-table__header-wrapper .el-checkbox {
    display: none;
  }
}
</style>
