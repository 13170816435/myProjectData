<template>
  <div class="userinfo">
    <div class="userinfo-title">
      <span class="userinfo-titleinfo">{{ titletext }}</span>
      <span
        @click="closeFn"
        class="close-btn iconfont iconchuangjianshibai"
      ></span>
    </div>
    <el-form
      :model="pacsinfo.formInfo"
      ref="formInfo"
      label-width="120px"
      class="demo-ruleForm"
    >
      <div class="contaner">
        <div class="contaner-info">
          <!-- <el-row class="contaner-info-title">
            <span class="border-left"></span>系统信息
          </el-row> -->
          <el-row class="mt15 pl10 pr10">
            <div class="formItemDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>授权产品：</span
              >
              <span class="formItemValue">远程教学</span>
            </div>

            <!--新增和编辑 不能修改 科室管理--->

            <div class="formItemDiv" v-if="teachServiceList.length != 0">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>开通服务：</span
              >
              <el-checkbox-group
                v-model="choosedServiceArr"
                @change="changeCooperateProductObj"
              >
                <!-- <el-tooltip v-for="(oneProduct,index) in pacsServiceList[activesystemIndex].children" v-bind:key="index" class="item toolTipText" effect="dark" :content="oneProduct.instruction" placement="top-start"> -->
                <el-checkbox
                  v-for="(oneProduct, index) in teachServiceList"
                  v-bind:key="index + 10"
                  class="fl openModule"
                  :label="oneProduct.service_code"
                  border
                >
                  {{ oneProduct.name }}
                </el-checkbox>
                <!-- </el-tooltip>   -->
              </el-checkbox-group>
            </div>

            <div class="formItemDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>教学中心名称
                ：</span
              >
              <el-input
                v-model="pacsinfo.formInfo.name"
                placeholder=""
                style="width: 580px"
              ></el-input>
            </div>
            <div class="formItemDiv">
              <span class="formItemLabel">教学中心简称 ：</span>
              <el-input
                v-model="pacsinfo.formInfo.abbreviation"
                placeholder=""
                style="width: 170px"
              ></el-input>
              <span class="ml5 f13 clr_oarange"
                >(用于医网云APP在线教学模块名称的自定义，如不填，则默认在线教学)</span
              >
            </div>
            <div class="formItemDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>机构名称 ：</span
              >
              <el-select
                v-model="pacsinfo.formInfo.institution_ids"
                @change="chooseOrgan"
                filterable
                multiple
                collapse-tags
                placeholder="请选择(可多选)"
                class="w_300"
                style="width: 580px"
              >
                <el-option
                  v-for="(item, index) in InstitutionsArr"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
            </div>

            <div class="formItemDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>管理人员 ：</span
              >
              <el-select
                filterable
                class="fl organ-select alertFormSelect organNameSec pr8 mr10"
                v-model="pacsinfo.formInfo.manager_id"
                @change="chooseManager"
                style="width: 285px"
              >
                <el-option value>请选择</el-option>
                <el-option
                  v-for="(item, index) in allManagerArr"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
              <input
                disabled
                v-model="pacsinfo.formInfo.manager_phone"
                placeholder="手机号码"
                type="text"
                class="fl width_285"
              />
            </div>
            <div class="formItemDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>使用期限 ：</span
              >
              <div style="display: flex; align-items: center">
                <el-date-picker
                  v-model="pacsinfo.formInfo.start_date"
                  type="date"
                  placeholder="选择开始期限"
                  value-format="yyyy-MM-dd"
                >
                </el-date-picker>
                <el-radio-group
                  v-model="pacsinfo.formInfo.isIndefinitely"
                  class="ml20"
                >
                  <el-radio :label="true">无期限</el-radio>
                  <el-radio :label="false">
                    <el-date-picker
                      v-model="pacsinfo.formInfo.stop_date"
                      type="date"
                      :disabled="pacsinfo.formInfo.isIndefinitely"
                      placeholder="选择结束期限"
                      value-format="yyyy-MM-dd"
                    >
                    </el-date-picker>
                  </el-radio>
                </el-radio-group>
              </div>
            </div>
            <div class="formItemDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>系统状态 ：</span
              >
              <div style="display: flex; align-items: center; height: 30px">
                <el-radio-group v-model="pacsinfo.formInfo.state" class="ml20">
                  <el-radio :label="10">启用</el-radio>
                  <el-radio :label="-2">停用</el-radio>
                </el-radio-group>
                <el-input
                  v-if="pacsinfo.formInfo.state === -2"
                  v-model="pacsinfo.formInfo.reason"
                  class="ml10"
                  placeholder="备注"
                  style="width: 180px"
                />
              </div>
            </div>

            <div class="formItemDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>中心简介 ：</span
              >
              <quill-editor
                ref="introduction"
                v-model="pacsinfo.formInfo.introduction"
                class="myQuillEditor"
                :options="editorOption"
                @change="onEditorChange($event, 'info')"
                style="min-height: 100px"
              ></quill-editor>

              <form
                action=""
                method="post"
                enctype="multipart/form-data"
                id="uploadFormMulti"
              >
                <input
                  style="display: none"
                  :id="uniqueId"
                  type="file"
                  name="files"
                  multiple
                  accept="image/jpg,image/jpeg,image/png,image/gif"
                  @change="uploadEditImg('uploadFormMulti')"
                />
              </form>
            </div>
            <div class="formItemDiv">
              <span class="formItemLabel">二级域名 ：</span>
              <el-input
                v-model="pacsinfo.formInfo.domain"
                placeholder=""
                style="width: 580px"
              ></el-input>
            </div>
            <weChat
              :weChatObj="pacsinfo.providersObj"
              :inputWidth="'236px'"
            ></weChat>
          </el-row>
        </div>

        <div class="contaner-info contaner-bottom">
          <el-row class="contaner-info-title instituteInfor">
            <el-col :span="12">
              <span class="border-left"></span>使用机构
              <span class="ml5 clr_oarange" v-if="pacsinfo.institution_count"
                >({{ pacsinfo.institution_count }}家)</span
              >
            </el-col>
            <el-col :span="12" class="tr clr_0a">
              <span
                class="function-btn bg_e6 clr_ff"
                @click="isAddInstutionOrSystem"
              >
                <i class="iconfont iconxinzeng"></i>添加机构
              </span>
            </el-col>
          </el-row>
          <div
            class="contaner-info-list"
            :class="{ hasService: teachServiceList.length != 0 }"
            v-if="pacsinfo.multipleSelection.length > 0"
          >
            <div class="contaner-info-list-item clr_999">
              <div class="width_60">操作</div>
              <div class="width_300">机构名称</div>
            </div>
            <div
              class="contaner-info-list-item"
              v-for="(item, index) in pacsinfo.multipleSelection"
              :key="index"
            >
              <div class="width_60">
                <span
                  @click="delInstitutionOrSystemFn(item.id)"
                  class="icon-btn bg_f5"
                  type="text"
                  size="small"
                  title="删除"
                  ><i class="iconfont icondongjie"></i
                ></span>
              </div>
              <div class="width_300">{{ item.name }}</div>
            </div>
          </div>
        </div>
      </div>
      <div class="mt15">
        <el-button
          type="primary"
          size="medium"
          @click="submitForm('formInfo', 'commit')"
          >提交</el-button
        >
        <el-button size="medium" @click="submitForm('formInfo')"
          >取消</el-button
        >
      </div>
    </el-form>

    <el-dialog
      title="选择机构"
      :append-to-body="true"
      :visible.sync="pacsinfo.isChioseOrganOrSystem"
      width="900px"
      v-dialogDrag
      :before-close="instclose"
    >
      <div class="CAdialog">
        <div>
          <el-input
            v-model="pacsinfo.serchName"
            placeholder="机构名称"
            style="width: 240px"
          ></el-input>
          <el-button
            type="primary"
            size="small"
            class="ml10"
            @click="serchListFn"
            >查询</el-button
          >
        </div>
        <el-table
          ref="institutionsTable"
          class="mt10"
          border
          :data="pacsinfo.institutionList"
          v-bind:class="{ noTableData: pacsinfo.institutionList.length == 0 }"
          :header-cell-style="{ background: '#DCDFE6', color: '#1E1D22' }"
          style="width: 100%"
          :row-key="getRowKeys"
          @select="selectCurRow"
          @selection-change="handleSelectionChange"
        >
          <el-table-column
            type="selection"
            width="55"
            :reserve-selection="true"
          ></el-table-column>
          <el-table-column
            prop="name"
            label="机构名称"
            :show-overflow-tooltip="true"
            width="250"
          ></el-table-column>
          <el-table-column
            prop="admin_name"
            label="联系人"
            width="100"
          ></el-table-column>
          <el-table-column
            prop="admin_phone"
            label="联系电话"
          ></el-table-column>
          <!-- <el-table-column label="选择科室">
            <template slot-scope="scope">
              <el-select
                  v-model="scope.row.office_ids"
                  multiple
                  class="w_300"
                  @change="CheckOfficeidsFn"
                  placeholder="请选择">
                  <el-option
                    v-for="itemdep in scope.row.offices"
                    :key="itemdep.id"
                    :label="itemdep.name"
                    :value="itemdep.id">
                  </el-option>
                </el-select>
            </template>
          </el-table-column> -->
        </el-table>
        <div class="blockPage">
          <pagination-tool
            :layout="pageLayout"
            :total="pageInfo.total_count"
            :page.sync="pageInfo.page_index"
            :limit.sync="pageInfo.page_size"
            @pagination="pageSizeChangeFn"
          />
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button
          size="small"
          plain
          @click="pacsinfo.isChioseOrganOrSystem = false"
          >取 消</el-button
        >
        <el-button
          type="primary"
          size="small"
          @click="ChioseOrganOrSystemFn('commit')"
          >确定</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>
<script>
import weChat from "@/components/common/weChat";
import { quillEditor } from "vue-quill-editor";
import PaginationTool from "@/components/common/PaginationTool";
import Quill from "quill";
import "quill/dist/quill.core.css";
import "quill/dist/quill.snow.css";
import "quill/dist/quill.bubble.css";
import {
  getAllManager,
  getUserPhone,
} from "@/api/platform_costomer/telemedicine";
import { uploadMediaFile } from "@/api/commonHttp";
import { connectUrlParam } from "@/components/commonJs";
const toolbarOptions = [
  ["bold", "italic", "underline"], // 加粗 斜体 下划线 删除线
  ["blockquote", "code-block"], // 引用  代码块
  [{ color: [] }, { background: [] }], // 字体颜色、字体背景颜色
  [{ indent: "-1" }, { indent: "+1" }], // 缩进
  [{ align: [] }], // 对齐方式
  [{ header: 1 }, { header: 2 }], // 1、2 级标题
  [{ list: "ordered" }, { list: "bullet" }], // 有序、无序列表
  [{ script: "sub" }, { script: "super" }], // 上标/下标
  ["link", "image"], // 链接、图片、视频
  ["clean"], // 清除文本格式
];
export default {
  components: {
    quillEditor,
    PaginationTool,
    weChat,
  },
  props: {
    pacsinfo: Object,
    pageInfo: Object,
    getDetailFinished: Boolean,
    InstitutionsArr: Array,
    teachServiceList: Array,
  },
  data() {
    return {
      titletext: "开设远程教学中心",
      activesystemIndex: -1,
      editorOption: {
        placeholder: "请在这里输入",
        modules: {
          toolbar: toolbarOptions,
        },
      },
      pageLayout: "total, prev, pager, next, jumper",
      addlength: "",
      moduleServiceName: "",
      allManagerArr: [],
      addImgRange: "",
      uniqueId: "testUpload",
      choosedServiceArr: [],
    };
  },
  watch: {
    getDetailFinished: function (val) {
      if (val) {
        let productIndex;
        if (this.teachServiceList.length != 0) {
          this.teachServiceList.forEach((one, j) => {
            if (this.pacsinfo.formInfo.service_code == one.service_code) {
              productIndex = j;
            }
          });
        }
        this.activesystemIndex = productIndex;
      }
    },
  },
  methods: {
    initAdd() {
      this.titletext = "开设远程教学中心";
      this.choosedServiceArr = [];
      // this.choosedOrganName = "";
      // this.isAutoUpload = false;
      // this.initFormData();
    },
    initEdit(id) {
      this.titletext = "编辑教学中心";
      // this.isAutoUpload = true;
      // this.getMyServiceCenterDetail(id);
    },
    isAddInstutionOrSystem() {
      this.$emit("isAddInstutionOrSystem");
    },
    pageSizeChangeFn(info) {
      this.$emit("pageSizeChangeFn", info);
    },
    serchListFn() {
      this.$emit("serchListFn");
    },
    ChioseOrganOrSystemFn(type) {
      this.$emit("ChioseOrganOrSystemFn", type);
    },
    chooseOrgan(val) {
      if (val.length === 0) {
        this.allManagerArr = [];
      } else {
        this.getMyManager(val);
      }
    },
    activeTeachSystemFn(index, item) {
      if (this.activesystemIndex != index) {
        this.$emit("activeTeachSystemFn", index, item);
      }
      this.activesystemIndex = index;
    },
    changeCooperateProductObj(arr) {
      this.$emit("changeCooperateProductObj", arr);
    },
    handleSelectionChange(val) {
      this.$emit("selectInstitionListFn", val);
    },
    selectCurRow(selection, row) {
      this.$emit("selectCurRowFn", selection, row);
    },
    // getSerchName (val) {
    //   this.$emit('getSerchName', val)
    // },
    instclose() {
      this.activesystemIndex = -1;
      this.$emit("instclose");
    },
    getRowKeys(val) {
      // this.$emit('getRowKeys', val)
      return val.id;
    },
    chooseManager(id) {
      const self = this;
      self.allManagerArr.forEach((item) => {
        if (item.id === id) {
          self.pacsinfo.formInfo.manager_name = item.name;
        }
      });
      self.getOneUserPhone(id);
    },
    async getOneUserPhone(userId) {
      const res = await getUserPhone({ id: userId });
      if (res.code === 0) {
        this.pacsinfo.formInfo.manager_phone = res.data.phone;
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    async getMyManager(arr) {
      const self = this;
      let param = "";
      let str;
      if (arr) {
        arr.forEach((val, i) => {
          if (i === 0) {
            str = `?ids[0]=` + val;
          } else {
            str = `&ids[${i}]=` + val;
          }
          param = param + str;
        });
      }
      const res = await getAllManager(param);
      // const res = await getAllManager()
      if (res.code === 0) {
        self.allManagerArr = res.data;
        // 特殊处理  当改变机构时 如果接口里面返回的管理员还有 之前选择的管理员时就不清空管理员姓名和管理员手机号
        let hasThisManager = false;
        self.allManagerArr.forEach((val) => {
          if (val.id === self.pacsinfo.formInfo.manager_id) {
            hasThisManager = true;
          }
        });
        // 如果改变机构后 接口返回的管理员里面 没有之前设置的管理员的话 得把管理员信息清空
        if (!hasThisManager) {
          self.pacsinfo.formInfo.manager_id = "";
          self.pacsinfo.formInfo.manager_name = "";
          self.pacsinfo.formInfo.manager_phone = "";
        }
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    onEditorChange(event, type) {
      // 富文本字数
      if (type) {
        event.quill.deleteText(800, 4);
        if (this.pacsinfo.formInfo.introduction === "") {
          this.addlength = 0;
        } else {
          this.addlength = event.quill.getLength() - 1;
        }
      }
    },
    closeFn() {
      this.activesystemIndex = -1;
      this.$emit("closeFn");
    },
    submitForm(formName, type) {
      var info = {
        formName: formName,
        refs: this.$refs,
        type: type,
      };
      if (!type) {
        this.activesystemIndex = -1;
      }
      this.$emit("submitForm", info);
    },
    delInstitutionOrSystemFn(_id) {
      this.$emit("delInstitutionOrSystemFn", _id);
    },
    async uploadEditImg(id) {
      var vm = this;
      var obj = document.getElementById("uploadFormMulti");
      // 获取文件对象
      var fileObj = document.getElementById(vm.uniqueId);
      var file = fileObj.files[0];
      var fileName = file.name;
      var fileSize = file.size;
      var formData = new FormData(obj);
      formData.append("file_name", fileName);
      try {
        vm.uploadImgReq(formData, fileName, fileSize); // 自定义的图片上传函数
      } catch ({ message: msg }) {
        document.getElementById(vm.uniqueId).value = "";
        vm.$message.warning(msg);
      }
    },
    // 下载图片
    downloadImg(file_id) {
      const vm = this;
      var src =
        configUrl.docUrl +
        "/api-document/download/document-id?document_id=" +
        file_id +
        "&is_crm_document=true";
      vm.addImgRange = vm.$refs.introduction.quill.getSelection();
      vm.$refs.introduction.quill.insertEmbed(
        vm.addImgRange != null ? vm.addImgRange.index : 0,
        "image",
        src,
        Quill.sources.USER
      );
    },

    async uploadImgReq(myformData, file_name, file_size) {
      // 这里实现你自己的图片上传
      var vm = this;
      let param = {
        file_name: file_name,
        file_size: file_size,
        position: 0,
        file_type: 0,
      };
      let paramUrl = connectUrlParam(param);
      const res = await uploadMediaFile(myformData, paramUrl);
      if (res.code === 0) {
        const result = res;
        // 获取图片
        vm.downloadImg(result.document_id);
      }
    },
  },
  mounted() {
    var vm = this;
    var imgHandler = async function (image) {
      vm.addImgRange = vm.$refs.introduction.quill.getSelection();
      if (image) {
        var fileInput = document.getElementById(vm.uniqueId); //隐藏的file文本ID
        fileInput.click(); //加一个触发事件
      }
    };
    vm.$nextTick(() => {
      vm.$refs.introduction.quill
        .getModule("toolbar")
        .addHandler("image", imgHandler);
    });
  },
};
</script>
<style lang="less" scoped>
.userinfo {
  width: 800px;
  padding: 0px 25px;
  ::v-deep .el-select,
  .el-select__tags {
    display: block !important;
    width: 350px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .userinfo-title {
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    .userinfo-titleinfo {
      font-size: 18px;
      color: #1f2f3d;
      font-weight: bold;
    }
    .close-btn {
      position: absolute;
      right: 0px;
      top: 0px;
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .contaner {
    border: 1px solid #dcdfe6;
    height: calc(100vh - 112px);
    .contaner-info {
      // border-bottom: 1px dashed #dcdfe6;
      padding-bottom: 0px;
      ::v-deep .wechatLabel {
        width: 132px !important;
      }
      ::v-deep .wechatTip {
        margin-left: 132px !important;
      }
      .openModule {
        height: 36px;
        line-height: 36px;
        padding: 0 15px;
        border-radius: 3px;
        border: 1px solid #dcdfe6;
        margin-right: 10px;
        color: #0a70b0;
        cursor: pointer;
        margin-bottom: 5px;
        ::v-deep .el-checkbox__label {
          padding-left: 0px;
        }
      }
      .openModule.el-checkbox.is-bordered.is-checked {
        background: url("../../../../../assets/images/common/checkboxBg.png")
          right bottom no-repeat;
      }
      .openModule {
        ::v-deep .el-checkbox__inner {
          display: none;
        }
      }
      .openModule:hover {
        background: rgba(10, 112, 176, 0.6);
        color: #fff;
      }
      .contaner-info-title {
        height: 40px;
        line-height: 40px;
        background: rgba(250, 250, 253, 1);
        color: #1f2f3d;
        padding: 0px 10px;
        .border-left {
          display: inline-block;
          width: 3px;
          height: 14px;
          background: rgba(9, 113, 176, 1);
          margin-right: 7px;
          vertical-align: middle;
          position: relative;
          top: -1.5px;
        }
      }
      .system_type {
        display: inline-block;
        padding: 0px 20px;
        height: 36px;
        line-height: 34px;
        border: 1px solid #dcdfe6;
        border-radius: 18px;
        color: #0a70b0;
        cursor: pointer;
        margin: 0px 5px;
      }
      .system_type:hover {
        border-color: #0a70b0;
      }
      .active {
        background: #0a70b0;
        color: #fff;
        border-color: #0a70b0;
      }
      .contaner-info-list {
        padding: 5px 20px 0 20px;
        max-height: 150px;
        overflow: auto;
      }
      .hasService {
        max-height: 105px;
      }
      .contaner-info-list-item {
        display: flex;
        min-height: 45px;
        align-items: center;
        border-bottom: 1px solid #e4e7ed;
        .width_60 {
          width: 60px;
        }
        .width_300 {
          width: 300px;
        }
        .icon-btn {
          display: inline-block;
          width: 24px;
          height: 24px;
          color: #fff;
          line-height: 24px;
          text-align: center;
          padding: 0px;
          cursor: pointer;
          border-radius: 3px;
          margin-right: 8px;
        }
        .depspan {
          display: inline-block;
          padding: 0px 3px;
          color: #333;
        }
      }
      .authorize-img {
        width: 48px;
        height: 48px;
        vertical-align: middle;
      }
      .clr_88 {
        color: #888888;
      }
      ::v-deep .el-form-item__label {
        width: 132px !important;
      }
    }
  }
  ::v-deep .formItemDiv {
    margin-bottom: 15px;
    .formItemLabel {
      float: left;
      width: 132px;
      color: #303133;
      font-size: 14px;
      line-height: 30px;
      text-align: right;
      padding-right: 12px;
    }
    .formItemValue {
      color: #303133;
      font-size: 14px;
      line-height: 30px;
    }
    .powerService {
      line-height: 30px;
    }
    .el-radio {
      height: 30px;
      line-height: 30px;
    }
    .width_285 {
      width: 285px;
      height: 36px;
      padding: 0 8px;
    }
  }
  .formItemDiv::after {
    content: "";
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  .operate-btn {
    width: 84px;
    height: 36px;
    line-height: 36px;
    border-radius: 3px;
    padding: 0px;
    border: none;
    border: 1px solid #dcdfe6;
  }
  .bg_e6 {
    background: #e6a23c;
  }
  .bg_f5 {
    background: #f56c6c;
  }
  .bg_0c {
    background: #0c83cd;
  }
  .bg_00 {
    background: #00ad78;
  }
  .w_300 {
    width: 300px;
  }
}
.systemIntro {
  height: 100px;
  ::v-deep .el-textarea__inner {
    height: 100px;
  }
}
::v-deep .allProvince {
  height: 276px;
  .el-table__body-wrapper {
    height: calc(100% - 40px) !important;
    overflow: auto;
  }
  .el-table-column--selection .cell {
    padding-left: 10px;
  }
}
.hadService {
  height: 320px !important;
}
// .CAdialog{
//   padding: 10px 20px 0 20px;
//   ::v-deep .el-table{
//     height:447px;
//     th{
//       background:#f5f5f5!important;
//     }
//     .el-table__body-wrapper{
//       height:calc(100% - 40px);
//       overflow: auto;
//     }
//   }
// }
.hadChooseNum {
  font-size: 15px;
  color: #303133;
  font-weight: bold;
  padding-right: 3px;
}
.instituePageOperate {
  margin-top: 10px;
  .el-checkbox__label {
    padding-left: 5px;
  }
}
.pd8 {
  padding: 0 8px;
}
.iconxinzeng {
  padding-right: 3px;
}
.onlyInstituLabel {
  height: 30px;
  float: left;
  line-height: 30px;
  color: #0a70b0;
  font-weight: bold;
  font-size: 15px;
}
::v-deep .delTip {
  font-size: 15px !important;
  color: #ef8900 !important;
}
::v-deep .el-table__fixed {
  height: 100% !important;
}
.centerAdmin {
  width: 50%;
  max-width: 300px;
}
.operateBtnDiv {
  margin-top: 4px;
}
.blockPage {
  position: relative;
}
.radioDiv {
  min-height: 30px;
}
.addressVal {
  font-size: 15px;
  color: #999;
  // display: inline-block;
  line-height: 28px;
  padding-left: 100px;
}
::v-deep .ql-editor {
  height: 200px;
}
::v-deep .quill-editor {
  float: left;
  width: calc(100% - 147px);
}
.CAdialog {
  padding: 10px 20px 0 20px;
  ::v-deep .el-table {
    height: 447px;
    th {
      background: #f5f5f5 !important;
    }
    .el-table__body-wrapper {
      height: calc(100% - 40px);
      overflow-y: auto;
    }
  }
  ::v-deep .el-table__empty-block {
    display: none;
  }
}
</style>
