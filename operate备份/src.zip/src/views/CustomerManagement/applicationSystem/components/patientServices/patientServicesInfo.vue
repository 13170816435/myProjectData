<template>
  <div class="userinfo">
    <div class="userinfo-title">
      <span class="userinfo-titleinfo">{{ pacsinfo.title }}</span>
      <span
        @click="closeFn"
        class="close-btn iconfont iconchuangjianshibai"
      ></span>
    </div>
    <el-form
      :model="pacsinfo.formInfo"
      ref="formInfo"
      label-width="120px"
      class="demo-ruleForm"
    >
      <div class="contaner imageControlContainer">
        <div class="contaner-info">
          <el-row class="contaner-info-title">
            <span class="border-left"></span>基本信息
          </el-row>
          <el-row class="pl10 pr10">
            <!-- <el-form-item label="授权产品 ：" v-if="pacsinfo.product_name">
              <div>{{ pacsinfo.product_name }}</div>
            </el-form-item>
            <el-form-item v-else label="授权产品 ：">
              <span class="system_type active">智能诊断</span>
            </el-form-item> -->
            <el-form-item class="mt15" label="系统名称 ：">
              <el-input
                v-model="pacsinfo.formInfo.name"
                placeholder="请输入系统名称"
                style="width: 480px"
              ></el-input>
            </el-form-item>
            <el-form-item class="mt15" label="系统管理员 ：">
              <el-input
                v-model="pacsinfo.formInfo.admin_phone"
                @input="changePhone"
                placeholder="请输入管理员电话"
                @blur="getAdminNameFn"
                style="width: 236px"
              ></el-input>
              <el-input
                v-model="pacsinfo.formInfo.admin_name"
                placeholder="请输入管理员姓名"
                :disabled="pacsinfo.isAdminname"
                class="ml10"
                style="width: 236px"
              ></el-input>
            </el-form-item>
            <el-form-item class="mt5" label="开通服务 ：">
              <el-checkbox-group v-model="pacsinfo.formInfo.function_services">
                <el-checkbox
                  class="fl openModule"
                  :label="oneService.code"
                  border
                  v-for="(oneService, index) in ewspsServiceList"
                  v-bind:key="index"
                >
                  {{ oneService.name }}
                </el-checkbox>
              </el-checkbox-group>

              <!--开通服务带描述-->
              <!-- <el-checkbox-group  v-model="pacsinfo.formInfo.function_services">
                  <el-tooltip v-for="(oneService,index) in ewspsServiceList" v-bind:key="index" class="item toolTipText" effect="dark" :content="oneService.instruction" placement="top-start">
                     <el-checkbox  class="fl openModule" :label="oneService.code" border>
                        {{oneService.name}}
                    </el-checkbox>
                  </el-tooltip>
               </el-checkbox-group> -->
            </el-form-item>
            <el-form-item class="mt15" label="使用期限：">
              <div style="display: flex; align-items: center">
                <el-date-picker
                  v-model="pacsinfo.formInfo.start_date"
                  type="date"
                  placeholder="选择开始期限"
                  value-format="yyyy-MM-dd"
                >
                </el-date-picker>
                <el-radio-group
                  v-model="pacsinfo.formInfo.isIndefinitely"
                  class="ml20"
                >
                  <el-radio :label="true">无期限</el-radio>
                  <el-radio :label="false">
                    <el-date-picker
                      v-model="pacsinfo.formInfo.stop_date"
                      type="date"
                      :disabled="pacsinfo.formInfo.isIndefinitely"
                      placeholder="选择结束期限"
                      value-format="yyyy-MM-dd"
                    >
                    </el-date-picker>
                  </el-radio>
                </el-radio-group>
              </div>
            </el-form-item>
            <el-form-item class="mt15" label="系统状态：">
              <div style="display: flex; align-items: center; height: 30px">
                <el-radio-group v-model="pacsinfo.formInfo.state">
                  <el-radio :label="10">启用</el-radio>
                  <el-radio :label="-2">停用</el-radio>
                </el-radio-group>
                <el-input
                  v-if="pacsinfo.formInfo.state === -2"
                  v-model="pacsinfo.formInfo.reason"
                  class="ml10"
                  placeholder="备注"
                  style="width: 180px"
                />
              </div>
            </el-form-item>

            <weChat
              :weChatObj="pacsinfo.providersObj"
              :inputWidth="'236px'"
            ></weChat>
          </el-row>
        </div>
        <div
          class="contaner-info contaner-bottom"
          v-bind:class="{
            updateContainerBottom: isUpdate,
          }"
        >
          <el-row class="contaner-info-title instituteInfor">
            <el-col :span="12">
              <span class="border-left"></span>使用机构
              <span class="ml5 clr_oarange"
                >({{ choosedInstituteArr.length }}家)</span
              >
            </el-col>
            <el-col :span="12" class="tr clr_0a">
              <span
                @click="removeInstitu"
                class="function-btn bg_f5 clr_ff mr20"
              >
                移除
              </span>
              <span class="function-btn bg_e6 clr_ff" @click="isAddInstution">
                <i class="iconfont iconxinzeng"></i>添加机构
              </span>
            </el-col>
          </el-row>
          <div
            class="allProvince"
            v-bind:class="{
              noTableData: tableData.length == 0,
              hadService: !pacsinfo.module_name,
            }"
          >
            <el-table
              :data="tableData"
              height="100%"
              ref="qualityInstituTable"
              :row-key="myRowkey"
              highlight-current-row
              v-on:selection-change="handleAllInstuSelectionChange"
              header-row-class-name="strong"
            >
              <el-table-column
                type="selection"
                v-bind:reserve-selection="true"
                width="48"
              ></el-table-column>
              <el-table-column
                fixed="left"
                align="center"
                type="index"
                label="序号"
                width="55"
              >
                <!-- <template slot-scope="scope">
                      <span>{{(page - 1) * size + scope.$index + 1}}</span>
                  </template> -->
              </el-table-column>
              <!-- <common-table :propData="institutePropData" /> -->
              <el-table-column prop="name" label="机构名称"></el-table-column>
            </el-table>
          </div>
          <div class="blockPage myPageDiv">
            <!-- <div class="pageOperate">
              <el-checkbox v-model="checked">全选</el-checkbox>
            </div> -->
            <el-pagination
              style="text-align: right;"
              :background="true"
              @size-change="sizeChange"
              @current-change="currentChange"
              :current-page="page"
              :page-size="size"
              :page-sizes="pageSizes"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
        </div>
      </div>
      <div class="mt15">
        <el-button
          type="primary"
          size="medium"
          @click="submitForm('formInfo', 'commit')"
          >提交</el-button
        >
        <el-button size="medium" @click="submitForm('formInfo')"
          >取消</el-button
        >
      </div>
    </el-form>
    <el-dialog
      class="addInstituAlert"
      append-to-body
      title="选择机构"
      :visible.sync="showAddInstituAlert"
      width="940px"
      height="660px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <div class="addInstituCon">
        <div class="searchQuery clear">
          <div class="searchQueryItem fl mr15">
            <!-- <span class="queryLabel fl">医院名称：</span> -->
            <el-input
              v-model="searchInstitutionParam.name"
              placeholder="机构名称"
              v-on:keyup.enter.native="getMyInstitutionsList()"
              class="fl input_200"
            ></el-input>
          </div>
          <div class="fl operateBtnDiv">
            <el-button
              type="primary"
              size="small"
              @click="getMyInstitutionsList"
              >查询</el-button
            >
          </div>
        </div>
        <div
          class="allMyInstitu"
          v-bind:class="{ noTableData: allInstituArr.length == 0 }"
        >
          <el-table
            :data="allInstituArr"
            border
            stripe
            height="100%"
            ref="allInstitutionTable"
            highlight-current-row
            :row-key="instituteRow"
            @select="selectCurRow"
            v-on:selection-change="handleInstituSelectionChange"
            header-row-class-name="strong"
          >
            <el-table-column
              type="selection"
              v-bind:reserve-selection="true"
              width="48"
            ></el-table-column>
            <el-table-column
              fixed="left"
              align="center"
              type="index"
              label="序号"
              width="55"
            >
              <template slot-scope="scope">
                <span>{{
                  (searchInstitutionParam.offset - 1) *
                    searchInstitutionParam.limit +
                  scope.$index +
                  1
                }}</span>
              </template>
            </el-table-column>
            <!-- <common-table :propData="addInstutitePropData" /> -->
            <el-table-column
              prop="name"
              label="机构名称"
              width="250"
            ></el-table-column>
            <el-table-column
              prop="admin_name"
              label="联系人"
              width="100"
            ></el-table-column>
            <el-table-column
              prop="admin_phone"
              label="联系电话"
            ></el-table-column>
          </el-table>
        </div>
        <div class="blockPage">
          <!-- <div class="pageOperate">
              <el-checkbox v-model="checked">全选</el-checkbox>
            </div> -->
          <pagination-tool
            :total="allInstitutePage"
            :page.sync="searchInstitutionParam.offset"
            :limit.sync="searchInstitutionParam.limit"
            @pagination="getMyInstitutionsList"
          />
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <!-- <span class="showChoosed fl ml20">已选：<span class="hadChooseNum">8</span>家</span> -->
        <el-button size="small" plain @click="cancelAddInstitu"
          >取 消</el-button
        >
        <el-button size="small" type="primary" @click="sureAddInstitu"
          >确 定</el-button
        >
      </span>
    </el-dialog>
  </div>
</template>
<script>
import weChat from "@/components/common/weChat";
import PaginationTool from "@/components/common/PaginationTool";
import {
  getQualityCenterInstitute,
  delQualityInstitu,
  getInstitutionsList,
  getInterfaceInstitutionsList,
} from "@/api/platform_costomer/imgControlCenter";
import { getDistinfoByType } from "@/api/commonHttp";
export default {
  components: {
    PaginationTool,
    weChat,
  },
  props: {
    ewspsServiceList: Array,
    pacsinfo: Object,
    serviceList: Array,
    pageInfo: Object,
    tancyDetail: Object,
    getDetailFinished: Boolean,
    isUpdate: Boolean,
    systemArr: Array,
  },
  data() {
    return {
      page: 1, //第几页
      size: 10, //一页多少条
      total: 0, //总条目数
      pageSizes: [5, 10, 20, 50, 100, 200, 300, 400, 500, 1000], //可选择的一页多少条
      tableData: [], //表格绑定的数据

      pageLayout: "total, prev, pager, next, jumper",
      allChooseInstitutePage: 0,
      totalInstitutePage: 0,
      allInstitutePage: 0,
      preChoosedInstituteArr: [],
      choosedInstituteArr: [],
      removeInstituIds: [],
      QualityCenterInstitueParam: {
        quality_center_id: "",
      },
      imgControType: 0,
      institutePropData: [
        { prop: "name", label: "机构名称", width: 220 },
        { prop: "admin_name", label: "机构管理员" },
      ],
      addInstutitePropData: [
        { prop: "name", label: "机构名称", width: 160 },
        { prop: "level", label: "机构等级", width: 85 },
        { prop: "nature", label: "机构性质", width: 100 },
        { prop: "admin_name", label: "机构管理员" },
      ],
      moduleServiceName: "",
      showAddInstituAlert: false,
      allInstituArr: [],
      searchChooseInstitutionParam: {
        offset: 1,
        limit: 10,
      },
      searchInstitutionParam: {
        name: "",
        system_ids: [],
        offset: 1,
        limit: 10,
        sorts: [],
      },
      addQualityInstituParam: {
        ids: [],
        quality_center_id: "",
      },
    };
  },
  watch: {
    getDetailFinished: function (val) {
      if (val) {
        this.getMyQualityCenterInstitute();
      }
    },
  },
  methods: {
    // 前端自己实现分页
    //获取表格数据，自行分页(slice)
    getTabelData() {
      //allData为全部数据
      this.tableData = this.choosedInstituteArr.slice(
        (this.page - 1) * this.size,
        this.page * this.size
      );
      this.total = this.choosedInstituteArr.length;
    },

    //获取表格数据，自行分页（splice）
    getTabelData2() {
      let data = JSON.parse(JSON.stringify(this.choosedInstituteArr));
      this.tableData = data.splice((this.page - 1) * this.size, this.size);
      //console.log(this.tableData)
      this.total = this.choosedInstituteArr.length;
    },
    //page改变时的回调函数，参数为当前页码
    currentChange(val) {
      //console.log("翻页，当前为第几页", val);
      this.page = val;
      this.getTabelData2();
    },
    //size改变时回调的函数，参数为当前的size
    sizeChange(val) {
      //console.log("改变每页多少条，当前一页多少条数据", val);
      this.size = val;
      this.page = 1;
      this.getTabelData2();
    },
    // 前端自己实现分页结束
    myRowkey(row) {
      return row.id;
    },
    handleAllInstuSelectionChange(val) {
      const self = this;
      self.removeInstituIds = [];
      val.forEach((item) => {
        self.removeInstituIds.push(item.id);
      });
    },
    async beganRemoveInstitu() {
      const self = this;
      self.removeInstituIds.forEach((val, i) => {
        self.choosedInstituteArr.forEach((one, j) => {
          if (val === one.id) {
            self.$nextTick(() => {
              self.$refs.qualityInstituTable.toggleRowSelection(one, false);
            });
            // self.$refs.allInstitutionTable.toggleRowSelection(one, false)
            self.choosedInstituteArr.splice(j, 1);
          }
        });
      });
      // 获取分页数据
      if (self.choosedInstituteArr.length % self.size == 0) {
        // 12条数据 一页显示10条 移除后2条后 变成1页
        self.page = parseInt(self.choosedInstituteArr.length / self.size);
      }

      self.getTabelData2();
    },
    removeInstitu() {
      const self = this;
      if (self.removeInstituIds.length === 0 && !this.checkAllInstitution) {
        this.$message({ message: "请至少选择一个机构", type: "error" });
        return false;
      }
      self
        .$confirm(
          "<div>移除机构，该机构将无法使用该智能诊断，请谨慎操作<p class='f14 clr_oarange'>确定移除所选机构吗？</p></div>",
          "提示",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            customClass: "warningAlert",
            dangerouslyUseHTMLString: true,
            type: "warning",
          }
        )
        .then(() => {
          self.beganRemoveInstitu();
        })
        .catch(() => {
          // self.$message({
          //   type: 'info',
          //   message: '已取消删除'
          // })
        });
    },

    // 获取质控机构
    async getMyQualityCenterInstitute() {
      const res = await getQualityCenterInstitute(
        this.QualityCenterInstitueParam
      );
      if (res.code === 0) {
        this.choosedInstituteArr = res.data;
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // 获取已选择了的 机构
    async getMyChooseInstitutionsList() {
      const self = this;
      const res = await getInstitutionsList(self.searchChooseInstitutionParam);
      if (res.code === 0) {
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // 获取所有的 机构
    async getMyInstitutionsList() {
      const self = this;
      self.allInstituArr = [];
      const res = await getInterfaceInstitutionsList(
        self.searchInstitutionParam
      );
      if (res.code === 0) {
        res.data.forEach((item) => {
          item.office_ids = [];
          if (item.offices.length === 1) {
            item.office_ids[0] = item.offices[0].id;
          }
        });
        self.allInstituArr = res.data;
        self.allInstitutePage = res.page.total_count;
        self.$nextTick(function () {
          self.$refs.allInstitutionTable.clearSelection();
          // 勾上已选中的
          self.allInstituArr.forEach((itemids) => {
            if (self.choosedInstituteArr.length !== 0) {
              self.choosedInstituteArr.forEach((item) => {
                if (itemids.id === item.id) {
                  self.$nextTick(() => {
                    self.$refs.allInstitutionTable.toggleRowSelection(
                      itemids,
                      true
                    );
                  });
                  itemids.office_ids = item.office_ids;
                }
              });
            }
          });
        });
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    resetSearch() {
      this.searchInstitutionParam = {
        product_code: "AIM",
        name: "",
        offset: 1,
        limit: 10,
        sorts: [],
      };
      this.getMyInstitutionsList();
    },
    instituteRow(row) {
      return row.id;
    },
    // 选中某一行
    selectCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.choosedInstituteArr.forEach((item, i) => {
          if (item.id === row.id) {
            self.choosedInstituteArr.splice(i, 1);
            // 为记录上一次选择的机构
            self.preChoosedInstituteArr.push(item);
          }
        });
      }
    },
    // 去掉重复的id
    clearCommonId(arr) {
      let obj = {};
      let peon = arr.reduce((cur, next) => {
        obj[next.id] ? "" : (obj[next.id] = true && cur.push(next));
        return cur;
      }, []);
      return peon;
    },
    handleInstituSelectionChange(val) {
      const self = this;
      // 保存上一次 选择的机构  这样当点击取消添加机构按钮时 恢复显示上一次显示的已选机构
      if (self.choosedInstituteArr.length != 0) {
        self.choosedInstituteArr.forEach((one) => {
          self.preChoosedInstituteArr.push(one);
        });
        self.preChoosedInstituteArr = self.clearCommonId(
          self.preChoosedInstituteArr
        );
      }

      //self.choosedInstituteArr = []  // 这里不能清空  清空后就不能回显了
      val.forEach((item) => {
        self.choosedInstituteArr.push(item);
      });
      self.choosedInstituteArr = self.clearCommonId(self.choosedInstituteArr);
      // 获取分页数据
      self.getTabelData2();
    },
    // 取消添加机构
    cancelAddInstitu() {
      const self = this;
      // 恢复显示上一次显示的已选机构
      self.choosedInstituteArr = [];
      if (self.preChoosedInstituteArr.length != 0) {
        self.preChoosedInstituteArr.forEach((item) => {
          self.choosedInstituteArr.push(item);
        });
      }
      // 获取分页数据
      self.getTabelData2();
      self.showAddInstituAlert = false;
    },
    // 确定添加质控机构
    async sureAddInstitu() {
      const self = this;
      self.showAddInstituAlert = false;
      self.checkAllInstitution = false;
      self.$nextTick(() => {
        self.$refs.qualityInstituTable.clearSelection();
      });
      // this.addQualityInstituParam.quality_center_id = this.detail.id
      // const res = await addQualityInstitute(this.addQualityInstituParam)
      // if (res.code === 0) {
      //   this.showAddInstituAlert = false
      //   this.checkAllInstitution = false
      //   this.$message({ message: '添加质控机构成功', type: 'success' })
      //   this.getMyQualityCenterInstitute()
      //   // 如果只有区质控中心
      //   if (this.detail.type === 3) {
      //     this.$emit('refreshQualityCenter')
      //   }
      // } else {
      //   this.$message({ message: `${res.msg}`, type: 'error' })
      // }
    },

    closeFn() {
      this.$emit("closeFn");
    },
    changePhone() {
      this.$emit("changePhone");
    },
    getAdminNameFn(val) {
      this.$emit("getAdminNameFn", val);
    },
    submitForm(formName, type) {
      var info = {
        formName: formName,
        refs: this.$refs,
        type: type,
        choosedInstituteArr: this.choosedInstituteArr,
      };
      this.$emit("submitForm", info);
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    // selectCurRow (selection, row) {
    //   this.$emit('dealselectCurRow', selection, row)
    // },
    handleSelectionChange(val) {
      this.$emit("selectInstitionListFn", val);
    },
    getSerchName(val) {
      this.$emit("getSerchName", val);
    },
    serchListFn() {
      this.$emit("serchListFn");
    },
    isAddInstution() {
      const self = this;
      self.showAddInstituAlert = true;
      self.getMyInstitutionsList();
    },
    pageSizeChangeFn(info) {
      this.$emit("pageSizeChangeFn", info);
    },
    getRowKeys(val) {
      // this.$emit('getRowKeys', val)
      return val.id;
    },
  },
};
</script>
<style>
/* .el-select, .el-select__tags{
  display: block !important;
  width: 350px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
} */
</style>
<style lang="less" scoped>
.userinfo {
  width: 800px;
  padding: 0px 25px;
  ::v-deep .el-select,
  .el-select__tags {
    display: block !important;
    width: 350px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .userinfo-title {
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    .userinfo-titleinfo {
      font-size: 18px;
      color: #1f2f3d;
      font-weight: bold;
    }
    .close-btn {
      position: absolute;
      right: 0px;
      top: 0px;
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .imageControlContainer {
    overflow: auto;
  }
  .contaner {
    display: flex;
    flex-direction: column;
    border: 1px solid #dcdfe6;
    height: calc(100vh - 118px);
    .contaner-info {
      // border-bottom: 1px dashed #dcdfe6;
      padding-bottom: 20px;
      .openModule {
        height: 36px;
        line-height: 36px;
        padding: 0 15px;
        border-radius: 3px;
        border: 1px solid #dcdfe6;
        margin-right: 10px;
        color: #0a70b0;
        cursor: pointer;
        margin-bottom: 5px;
        margin-left: 0px !important;
        ::v-deep .el-checkbox__label {
          padding-left: 0px;
        }
      }
      .openModule.el-checkbox.is-bordered.is-checked {
        background: url("../../../../../assets/images/common/checkboxBg.png")
          right bottom no-repeat;
      }
      .openModule {
        ::v-deep .el-checkbox__inner {
          display: none;
        }
      }
      .openModule:hover {
        background: rgba(10, 112, 176, 0.6);
        color: #fff;
      }
      .instituteInfor {
        border-top: 1px dashed #dcdfe6;
      }
      .contaner-info-title {
        height: 40px;
        line-height: 40px;
        background: rgba(250, 250, 253, 1);
        color: #1f2f3d;
        padding: 0px 10px;
        .border-left {
          display: inline-block;
          width: 3px;
          height: 14px;
          background: rgba(9, 113, 176, 1);
          margin-right: 7px;
          vertical-align: middle;
          position: relative;
          top: -1.5px;
        }
      }
      .el-upload__tip {
        font-size: 13px;
      }
      .system_type {
        display: inline-block;
        padding: 0px 20px;
        height: 36px;
        line-height: 34px;
        border: 1px solid #dcdfe6;
        border-radius: 18px;
        color: #0a70b0;
        cursor: pointer;
        margin: 0px 5px;
      }
      .system_type:hover {
        border-color: #0a70b0;
      }
      .active {
        background: #0a70b0;
        color: #fff;
        border-color: #0a70b0;
      }
      .contaner-info-list {
        padding: 5px 20px 0 20px;
        overflow: auto;
      }
      .contaner-info-list-item {
        display: flex;
        min-height: 45px;
        align-items: center;
        border-bottom: 1px solid #e4e7ed;
        .width_60 {
          width: 60px;
        }
        .width_300 {
          width: 300px;
        }
        .icon-btn {
          display: inline-block;
          width: 24px;
          height: 24px;
          color: #fff;
          line-height: 24px;
          text-align: center;
          padding: 0px;
          cursor: pointer;
          border-radius: 3px;
          margin-right: 8px;
        }
        .depspan {
          display: inline-block;
          padding: 0px 3px;
          color: #333;
        }
      }
      .authorize-img {
        width: 48px;
        height: 48px;
        vertical-align: middle;
      }
      .clr_88 {
        color: #888888;
      }
    }
    .contaner-bottom {
      // height: calc(100% - 360px);
      flex: 1;
      height: 0;
      padding-bottom: 0px !important;
      display: flex;
      flex-direction: column;
      .contaner-info-list {
        height: calc(100% - 40px);
      }
    }
    .updateContainerBottom {
      height: calc(100% - 210px);
    }
  }
  ::v-deep .formItemDiv {
    margin-bottom: 15px;
    .formItemLabel {
      float: left;
      width: 120px;
      color: #303133;
      font-size: 14px;
      line-height: 30px;
      text-align: right;
      padding-right: 12px;
    }
    .powerService {
      line-height: 30px;
    }
    .el-radio {
      height: 30px;
      line-height: 30px;
    }
  }
  .operate-btn {
    width: 84px;
    height: 36px;
    line-height: 36px;
    border-radius: 3px;
    padding: 0px;
    border: none;
    border: 1px solid #dcdfe6;
  }
  .bg_e6 {
    background: #e6a23c;
  }
  .bg_f5 {
    background: #f56c6c;
  }
  .bg_0c {
    background: #0c83cd;
  }
  .bg_00 {
    background: #00ad78;
  }
  .w_300 {
    width: 300px;
  }
  .w_180 {
    width: 180px;
  }
}
.systemIntro {
  height: 100px;
  ::v-deep .el-textarea__inner {
    height: 100px;
  }
}
::v-deep .allProvince {
  // height: calc(100% - 41px) !important;
  // min-height: 320px !important;
  flex: 1;
  height: 0;
  .el-table::before {
    display: none;
  }
  .el-table__fixed::before {
    display: none;
  }
  .el-table__body-wrapper {
    height: calc(100% - 40px) !important;
    overflow: auto;
  }
  .el-table-column--selection .cell {
    padding-left: 10px;
  }
}
.hadService {
  // height: calc(100% - 40px) !important;
}
// .CAdialog{
//   padding: 10px 20px 0 20px;
//   ::v-deep .el-table{
//     height:447px;
//     th{
//       background:#f5f5f5!important;
//     }
//     .el-table__body-wrapper{
//       height:calc(100% - 40px);
//       overflow: auto;
//     }
//   }
// }
// 添加质控机构弹窗样式
::v-deep .allMyInstitu {
  height: 350px;
  .el-table {
    height: 100%;
    .el-table__body-wrapper {
      height: calc(100% - 40px);
      overflow: auto;
    }
    .el-table__fixed-body-wrapper {
      height: calc(100% - 40px) !important;
    }
  }
}
.addInstituCon {
  padding: 10px 20px;
  padding-bottom: 0px;
  .searchQueryItem {
    margin-bottom: 10px;
    .queryLabel {
      height: 36px;
      line-height: 36px;
      font-size: 15px;
      color: #303133;
    }
    .width_240_select {
      // width:340px!important;
      height: 36px;
      ::v-deep .el-input__inner {
        height: 36px;
      }
    }
    .input_200 {
      width: 200px;
      height: 36px;
      ::v-deep .el-input__inner {
        height: 36px;
      }
    }
  }
}
.hadChooseNum {
  font-size: 15px;
  color: #303133;
  font-weight: bold;
  padding-right: 3px;
}
.instituePageOperate {
  margin-top: 10px;
  .el-checkbox__label {
    padding-left: 5px;
  }
}
.pd8 {
  padding: 0 8px;
}
.iconxinzeng {
  padding-right: 3px;
}
.onlyInstituLabel {
  height: 30px;
  float: left;
  line-height: 30px;
  color: #0a70b0;
  font-weight: bold;
  font-size: 15px;
}
::v-deep .delTip {
  font-size: 15px !important;
  color: #ef8900 !important;
}
::v-deep .el-table__fixed {
  height: 100% !important;
}
.centerAdmin {
  width: 50%;
  max-width: 300px;
}
.operateBtnDiv {
  margin-top: 2px;
}
.blockPage {
  position: relative;
}
.radioDiv {
  min-height: 30px;
}
.addressVal {
  font-size: 15px;
  color: #999;
  // display: inline-block;
  line-height: 28px;
  padding-left: 100px;
}
::v-deep .myPageDiv {
  float: right;
  .pagination-container {
    text-align: right;
    background: #fff;
    padding: 10px 16px;
  }
  .pagination-container.hidden {
    display: none;
  }
  .el-pagination.is-background .el-pager li:not(.disabled).active {
    background-color: #0a70b0 !important;
  }
  .el-pagination.is-background .btn-next,
  .el-pagination.is-background .btn-prev,
  .el-pagination.is-background .el-pager li {
    background-color: #fff;
  }
  .el-pagination__total {
    height: 32px !important;
    line-height: 32px !important;
  }
  .el-pagination__sizes {
    margin: 0px;
  }
  .el-pagination__jump {
    margin-left: 4px;
  }
}
</style>
