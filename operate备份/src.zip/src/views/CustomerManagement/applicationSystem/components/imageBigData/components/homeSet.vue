<template>
  <div class="homeSetCon">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>影像大数据
          <i class="iconfont iconzhankaishouqi"></i> 门户设置
        </span>
        <span
          @click="closeFn"
          class="fr close-btn iconfont iconchuangjianshibai"
        ></span>
      </div>
    </div>
    <el-form
      :model="portalsInfo"
      :rules="rules"
      ref="portalsInfo"
      label-width="135px"
      :class="{ container: !from }"
    >
      <div class="container-item-border">
        <el-form-item label="平台名称 :" prop="name">
          <el-input v-model="portalsInfo.name" class="w_300"></el-input>
        </el-form-item>
        <el-form-item class="mt10 logo" label="平台Logo:">
          <el-upload
            class="avatar-uploader upload uploadLogo"
            action="#"
            :show-file-list="false"
            :auto-upload="false"
            :on-change="chooselogoImgFn"
          >
            <div class="headImg">
              <img :src="portalsInfo.logo" v-if="portalsInfo.logo" />
              <i v-if="noHaveLogo" class="iconfont icondaochu mr5"></i>
            </div>
            <!-- <div v-else class="headImg"><i  class="iconfont icondaochu mr5"></i></div> -->
            <span
              v-if="!portalsInfo.logo"
              slot="tip"
              class="el-upload__tip clr_oarange tl"
              >（图片大小：250*70,不能超过2MB,格式支持JPG、Png
              、bmp、jpeg、gif格式）</span
            >
          </el-upload>
        </el-form-item>
        <el-form-item class="mt10 formItem" label="平台banner :">
          <div
            class="bannerupload"
            v-for="(item, index) in bannerList"
            v-if="item.image"
            :key="index"
          >
            <img :src="item.image" />
            <div class="operationbtn">
              <span class="bg_0a" @click="uploadshow('put', 1, item.id)"
                >更换</span
              ><span class="bg_f5 ml10" @click="uploadshow('del', 1, item.id)"
                >删除</span
              >
            </div>
          </div>
          <div
            v-if="bannerList.length < 6"
            class="bannerupload"
            @click="uploadshow('add', 1)"
          >
            <i class="iconfont iconxinzeng mr5"></i>添加banner
          </div>
        </el-form-item>
        <el-form-item class="formItem" label="友情链接 :">
          <div class="">
            <div
              class="bannerupload Logolinkitem"
              v-for="(item, index) in linkList"
              v-if="item.image"
              :key="index"
            >
              <img :src="item.image" />
              <span>{{ item.name }}</span>
              <div class="operationbtn">
                <span class="bg_0a" @click="uploadshow('put', 2, item.id)"
                  >更换</span
                ><span class="bg_f5 ml10" @click="uploadshow('del', 2, item.id)"
                  >删除</span
                >
              </div>
            </div>
            <div
              v-if="linkList.length < 6"
              class="bannerupload"
              @click="uploadshow('add', 2)"
            >
              <i class="iconfont iconxinzeng mr5"></i>添加友情链接
            </div>
          </div>
        </el-form-item>
        <el-form-item class="formItem" label="平台介绍 :">
          <quill-editor
            ref="introduction"
            v-model="portalsInfo.introduction"
            class="myQuillEditor"
            :options="editorOption"
            @change="onEditorChange($event, 'info')"
            style="max-width: 1000px; min-height: 150px; padding-bottom: 10px"
          ></quill-editor>
          <form action="" method="post" enctype="multipart/form-data" id="uploadIntroFormMulti">
              <input style="display: none" :id="uniqueId" type="file" name="files" multiple accept="image/jpg,image/jpeg,image/png,image/gif" @change="uploadIntroEditImg('uploadFormMulti')">
           </form>
        </el-form-item>
        <el-form-item class="formItem" label="网站尾页 :" prop="footer">
          <div class="relative">
            <el-upload
              class="avatar-uploader"
              :action="upimgurl"
              :headers="upimgheaders"
              :http-request="to_upload_img"
              :show-file-list="false"
              style="display: none"
            >
              <i class="el-icon-plus avatar-uploader-icon" id="imgInput"></i>
            </el-upload>
            <quill-editor
              ref="platformfooter"
              v-model="portalsInfo.footer"
              class="myQuillEditor"
              :options="editorOption"
              @change="onEditorChange($event)"
              style="max-width: 1000px; min-height: 150px; padding-bottom: 10px"
            ></quill-editor>
            <form action="" method="post" enctype="multipart/form-data" id="uploadFooterFormMulti">
                 <input style="display: none" :id="uniqueFooterId" type="file" name="files" multiple accept="image/jpg,image/jpeg,image/png,image/gif" @change="uploadFooterEditImg('uploadFormMulti')">
              </form>
          </div>
        </el-form-item>
        <el-form-item label="二级域名 :" prop="domain">
          <el-input v-model="portalsInfo.domain" class="w_300"></el-input><br />
          <span class="el-upload__tip clr_oarange tl"
            >（二级域名绑定后，可使用该域名访问平台系统，示例：https://www.mtywcloud.com:8080/）</span
          >
        </el-form-item>
        <weChat
          :weChatObj="providersObj"
          :inputWidth="'236px'"
        ></weChat>
        <!-- <el-form-item label="审核方式 :">
          <el-radio-group v-model="portalsInfo.audit_type">
            <el-radio :label=1>事前审核</el-radio>
            <el-radio :label=2>事后审核</el-radio>
          </el-radio-group>
          <span class="ml30 clr_orange">需要审核人员审核后才能进行调阅</span>
        </el-form-item>
        <el-form-item label="拍照留档 :">
          <el-switch v-model="portalsInfo.is_take_photos"></el-switch>
          <span class="ml30 clr_orange">开启后用户在进行数据调阅需进行拍照留档</span>
        </el-form-item> -->
      </div>
    </el-form>
    <div class="subBtnDiv">
      <el-button
        class="mb15"
        type="primary"
        size="medium"
        @click="commitFn('submit')"
        >提交</el-button
      >
      <!-- <el-button v-if="from" size="small" plain @click="commitFn('cansel')">取消</el-button> -->
      <!-- <div class="tc"><el-button type="primary" size="medium" @click="commitFn">保存</el-button></div> -->
    </div>
    <el-dialog
      :append-to-body="true"
      :title="dialogoperate + uploadtitle"
      :visible.sync="isuploadInfo"
      @close="closeDialogFn"
      width="500px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <upload
        :uploadinfo="uploadinfo"
        :textType="textType"
        @chooseLogoImgFn="chooseImgFn"
        @submitForm="submitForm"
      ></upload>
    </el-dialog>
  </div>
</template>

<script>
import weChat from "@/components/common/weChat";
import { quillEditor } from "vue-quill-editor";
import "quill/dist/quill.core.css";
import "quill/dist/quill.snow.css";
import "quill/dist/quill.bubble.css";
import {
  getCustomerPortals,
  setPortals,
  addPortalsImg,
  putPortalsImg,
  delPortalsImgInfo,
  getCustomerPortalsImgList,
  getCustomerPortalsImgListInfo,
  getPortalsImgurl,
  getCriminallLogourl,
  getPortalsappLogourl,
} from "@/api/platform_operate/systemset";
// 编辑器里面上传图片需要的
import Quill from "quill";
import { uploadFile } from "@/api/platform_costomer/telemedicine";
// 编辑器里面上传图片需要的到这为止
import { getBase64 } from "@/components/commonJs";
import upload from "@/views/PlatformOperation/systemManager/components/upload";
const toolbarOptions = [
  ["bold", "italic", "underline"], // 加粗 斜体 下划线 删除线
  ["blockquote", "code-block"], // 引用  代码块
  [{ color: [] }, { background: [] }], // 字体颜色、字体背景颜色
  [{ indent: "-1" }, { indent: "+1" }], // 缩进
  [{ align: [] }], // 对齐方式
  //[{ header: 1 }, { header: 2 }], // 1、2 级标题
  [{ list: "ordered" }, { list: "bullet" }], // 有序、无序列表
  [{ script: "sub" }, { script: "super" }], // 上标/下标
  ["link", "image"], // 链接、图片、视频
  ["clean"], // 清除文本格式
];
export default {
  name: "operationMonitoring",
  data() {
    return {
      portalsInfo: {
        // 门户信息
        app_logo: "",
        font_color: "#333",
        font_size: "",
        footer: "",
        id: "",
        logo: "",
        name: "",
        tenancy_id: "",
        introduction: "",
        audit_type: 1,
        is_take_photos: true,
        domain: "",
      },
      providersObj: { // 需要特殊处理
        app_id: "",
        app_secret: "",
      },
      noHaveLogo: false,
      rules: {
        name: [{ required: true, message: "请输入平台名称", trigger: "blur" }],
        logo: [{ required: true, message: "请选择平台logo", trigger: "blur" }],
        footer: [
          { required: true, message: "请输入网站尾页", trigger: "blur" },
        ],
      },
      addlength: "",
      paramsFormdata: new CompatibleFormData(),
      logo_imgrul: "",
      headerInfo: {
        // imgurl: require('../../../assets/images/common/logo.png'),
        imgurl: "",
        name: "",
        fontsize: "",
        color: "",
      },
      dialogImageUrl: "",
      dialogVisible: false,
      disabled: false,
      bannerList: [],
      linkList: [],
      codeList: [],
      appbannerList: [],
      footer: "",
      editorOption: {
        placeholder: "请在这里输入",
        modules: {
          toolbar: toolbarOptions,
        },
      },
      codeimgurl: "",
      fontsizeList: [
        { value: "16", name: "16px" },
        { value: "18", name: "18px" },
        { value: "20", name: "20px" },
        { value: "22", name: "22px" },
        { value: "24", name: "24px" },
        { value: "26", name: "26px" },
      ],
      dialogoperate: "新增",
      uploadtitle: "横幅",
      textType: "横幅",
      isuploadInfo: false,
      uploadinfo: {
        category: "", // banner:1  link:2  code:3
        tenancy_id: 0,
        name: "",
        ordinal: "",
        link_url: "",
        image: "",
        state: true,
      },
      uploadinfoFormdata: new CompatibleFormData(),
      upimgurl: configUrl.apiUrl + "/api-operate/medias",
      upimgheaders: {},
      addImgRange: "",
      addImgRangeToFooter: "",
      uniqueId: "testUpload",
      uniqueFooterId: "footerUploadId"
    };
  },
  props: {
    userId: String,
    from: String,
    curSystemObj: Object
  },
  watch: {},
  components: {
    quillEditor,
    upload,
    weChat
  },
  mounted() {
    var vm = this;
    vm.paramsFormdata = new FormData();
    // 给平台介绍编辑器上传图片做特殊处理
    var imgHandler = async function (image) {
      vm.addImgRange = vm.$refs.introduction.quill.getSelection();
      if (image) {
        var fileInput = document.getElementById(vm.uniqueId); //隐藏的file文本ID
        fileInput.click(); //加一个触发事件
      }
    };
    vm.$refs.introduction.quill.getModule("toolbar").addHandler("image", imgHandler);
   // 给网站尾页编辑器上传图片做特殊处理
    var footerImgHandler = async function (image) {
      vm.addImgRangeToFooter = vm.$refs.platformfooter.quill.getSelection();
       if (image) {
        var fileInput = document.getElementById(vm.uniqueFooterId); //隐藏的file文本ID
        fileInput.click(); //加一个触发事件
      }
    };
    vm.$refs.platformfooter.quill.getModule("toolbar").addHandler("image", footerImgHandler)
    // 获取门户详情
    vm.getPortalsInfo();
  },
  created() {},
  methods: {
    // 平台介绍和 尾页介绍编辑器上传图片的 处理
    async uploadIntroEditImg(id) {
      var vm = this;
      var obj = document.getElementById("uploadIntroFormMulti");
      var formData = new FormData(obj);
      try {
        const url = vm.uploadIntroImgReq(formData); // 自定义的图片上传函数
      } catch ({ message: msg }) {
        document.getElementById(vm.uniqueId).value = "";
        vm.$message.warning(msg);
      }
    },
    async uploadIntroImgReq(myformData) {
      // 这里实现你自己的图片上传
      var vm = this;
      const formdata1 = new FormData();
      formdata1.append("files", myformData);
      const res = await uploadFile(myformData);
      if (res.code === 0) {
        const result = res.data;
        // const eitImgResult = await getEditImg(result[0].file_token)

        // src 如果传base64位给后端会比较长  所以改传一个图片链接地址但 直接用图片链接的话会报401（需要传token）
        // 因为是get请求然后链接是拼接的 所以token 不方便传给后台 所以需要后端网关处理下(解除该接口需要token的限制)
        var src = configUrl.apiUrl + "/api-operate" + `/medias/${result[0].file_token}`;
        vm.addImgRange = vm.$refs.introduction.quill.getSelection();
        vm.$refs.introduction.quill.insertEmbed(
          vm.addImgRange != null ? vm.addImgRange.index : 0,
          "image",
          src,
          Quill.sources.USER
        );
      } else {
      }
    },
    async uploadFooterEditImg(id) {
      var vm = this;
      var obj = document.getElementById("uploadFooterFormMulti");
      var formData = new FormData(obj);
      try {
        const url = vm.uploadFooterImgReq(formData); // 自定义的图片上传函数
      } catch ({ message: msg }) {
        document.getElementById(vm.uniqueFooterId).value = "";
        vm.$message.warning(msg);
      }
    },
    async uploadFooterImgReq(myformData) {
      // 这里实现你自己的图片上传
      var vm = this;
      const formdata1 = new FormData();
      formdata1.append("files", myformData);
      const res = await uploadFile(myformData);
      if (res.code === 0) {
        const result = res.data;
        // const eitImgResult = await getEditImg(result[0].file_token)

        // src 如果传base64位给后端会比较长  所以改传一个图片链接地址但 直接用图片链接的话会报401（需要传token）
        // 因为是get请求然后链接是拼接的 所以token 不方便传给后台 所以需要后端网关处理下(解除该接口需要token的限制)
        var src = configUrl.apiUrl + "/api-operate" + `/medias/${result[0].file_token}`;
        vm.addImgRangeToFooter = vm.$refs.platformfooter.quill.getSelection();
        vm.$refs.platformfooter.quill.insertEmbed(
          vm.addImgRangeToFooter != null ? vm.addImgRangeToFooter.index : 0,
          "image",
          src,
          Quill.sources.USER
        );
      } else {
      }
    },
    // 平台介绍和 尾页介绍编辑器上传图片的 处理 结束
    closeFn() {
      this.$emit("closeFn");
    },
    chooseLogoImgFn(file, fileList) {},
    handleChangeColor() {},
    // 平台logo
    chooselogoImgFn(file) {
      this.paramsFormdata.delete("logo");
      this.paramsFormdata.append("logo", file.raw);
      // this.portalsInfo.logo = URL.createObjectURL(file.raw)
      this.$set(this.portalsInfo, "logo", URL.createObjectURL(file.raw));
    },
    // app logo
    chooseAppLogoImgFn(file) {
      this.paramsFormdata.delete("app_logo");
      this.paramsFormdata.append("app_logo", file.raw);
      this.$set(this.portalsInfo, "app_logo", URL.createObjectURL(file.raw));
      // this.portalsInfo.app_logo = URL.createObjectURL(file.raw)
    },
    // 弹框logo
    chooseImgFn(file) {
      const types = [
        "image/jpeg",
        "image/gif",
        "image/bmp",
        "image/png",
        "image/jpg",
      ];
      const isJPG = types.includes(file.raw.type);
      const isLt2M = file.size / 1024 / 1024 < 2;
      if (!isJPG) {
        this.$message.error("图片只能是 JPG、Png 、bmp、jpeg、gif格式!");
        return false;
      }
      if (!isLt2M) {
        this.$message.error("图片大小不能超过 2MB!");
        return false;
      }
      this.uploadinfoFormdata.delete("image");
      this.uploadinfoFormdata.append("image", file.raw);
      this.uploadinfo.image = URL.createObjectURL(file.raw);
    },
    async closeDialogFn() {
      this.uploadinfo.name = "";
      this.uploadinfo.ordinal = "";
      this.uploadinfo.link_url = "";
      this.uploadinfo.state = true;
      this.uploadinfo.image = "";
    },
    // 获取门户详情
    async getPortalsInfo() {
      this.portalsInfo = this.$options.data().portalsInfo;
      let param = {
        system:2300,
        business_system_id: this.curSystemObj.id
      }
      const res = await getCustomerPortals(param);
      if (res.code === 0) {
        this.portalsInfo = res.data;
        this.portalsInfo.logo = "";
        if (res.data.providers && res.data.providers.length != 0) {
          this.providersObj = res.data.providers[0];
        }
        // this.uploadinfo.tenancy_id = res.data.tenancy_id
        await getCriminallLogourl(param)
          .then((imgFile) => {
            if (imgFile) {
              getBase64(imgFile).then((result) => {
                this.$set(this.portalsInfo, "logo", result);
              });
            } else {
              this.$set(this.portalsInfo, "logo", "");
              this.noHaveLogo = true;
            }
          })
          .catch((error) => {
            console.log(error);
            this.noHaveLogo = true;
          });
        await getPortalsappLogourl(res.data.tenancy_id)
          .then((imgFile) => {
            if (imgFile) {
              getBase64(imgFile).then((result) => {
                this.$set(this.portalsInfo, "app_logo", result);
              });
            } else {
              this.$set(this.portalsInfo, "app_logo", "");
            }
          })
          .catch((error) => {
            console.log(error);
          });
        this.getPortalsImgListFn(1);
        this.getPortalsImgListFn(2);
        this.getPortalsImgListFn(3);
        this.getPortalsImgListFn(4);
      }
    },
    // 获取图片列表
    async getPortalsImgListFn(type) {
      let param = {
        category: type,
        system:2300,
        business_system_id: this.curSystemObj.id
      }
      const res = await getCustomerPortalsImgList(param);
      if (res.code === 0) {
        for (var m = 0; m < res.data.length; m++) {
          await getPortalsImgurl(res.data[m].id)
            .then((imgFile) => {
              if (imgFile) {
                getBase64(imgFile).then((result) => {
                  res.data[m].image = result;
                });
              } else {
                res.data[m].image = "";
              }
            })
            .catch((error) => {
              console.log(error);
            });
        }
        if (type === 1) {
          this.bannerList = res.data;
        } else if (type === 2) {
          this.linkList = res.data;
        } else if (type === 3) {
          this.codeList = res.data;
        } else if (type === 4) {
          this.appbannerList = res.data;
        }
      }
    },
    onEditorChange(event, type) {
      // 富文本字数
      if (type) {
        event.quill.deleteText(800, 4);
        if (this.portalsInfo.footer === "") {
          this.addlength = 0;
        } else {
          this.addlength = event.quill.getLength() - 1;
        }
      }
    },
    // 新增弹框
    uploadshow(operate, type, id) {
      this.uploadinfo = this.$options.data().uploadinfo;
      this.textType =
        type === 1
          ? "横幅"
          : type === 2
          ? "链接"
          : type === 3
          ? "二维码"
          : "Banner";
      this.uploadtitle =
        type === 1
          ? "横幅"
          : type === 2
          ? "友情链接"
          : type === 3
          ? "二维码"
          : "移动端banner图";
      this.uploadinfo.category = type;
      if (operate === "add") {
        // 新增
        this.isuploadInfo = true;
        this.dialogoperate = "新增";
      } else if (operate === "put") {
        // 编辑
        this.dialogoperate = "编辑";
        this.getPortalsImgInfoFn(id);
        this.isuploadInfo = true;
      } else if (operate === "del") {
        // 删除
        this.$confirm("是否删除这条图片信息？", "删除信息", {
          distinguishCancelAndClose: true,
          confirmButtonText: "删除",
          cancelButtonText: "取消",
        }).then(() => {
          this.delPortalsImgInfoFn(type, id);
        });
      }
    },
    // 获取图片信息
    async getPortalsImgInfoFn(id) {
      let param = {
        id: id,
        system:2300,
        business_system_id: this.curSystemObj.id
      }
      const res = await getCustomerPortalsImgListInfo(param);
      if (res.code === 0) {
        res.data.state = res.data.state === 1 ? true : false;
        this.uploadinfo = res.data;
        await getPortalsImgurl(res.data.id)
          .then((imgFile) => {
            if (imgFile) {
              getBase64(imgFile).then((result) => {
                // this.uploadinfo.image = result
                this.$set(this.uploadinfo, "image", result);
              });
            } else {
              this.$set(this.uploadinfo, "image", "");
            }
          })
          .catch((error) => {
            console.log(error);
          });
      }
    },
    // 删除图片信息
    async delPortalsImgInfoFn(type, id) {
       const parmas = {
        id: id,
        system: 2300,
        business_system_id:this.curSystemObj.id
      }
      const res = await delPortalsImgInfo(parmas);
      if (res.code === 0) {
        this.$message.success("删除成功！");
        if (type === 1) {
          // banner
          this.bannerList.forEach((item, i) => {
            if (item.id === id) {
              this.bannerList.splice(i, 1);
            }
          });
        } else if (type === 2) {
          this.linkList.forEach((item, i) => {
            if (item.id === id) {
              this.linkList.splice(i, 1);
            }
          });
        } else if (type === 3) {
          this.codeList.forEach((item, i) => {
            if (item.id === id) {
              this.codeList.splice(i, 1);
            }
          });
        } else if (type === 4) {
          this.appbannerList.forEach((item, i) => {
            if (item.id === id) {
              this.appbannerList.splice(i, 1);
            }
          });
        }
      } else {
        this.$message.error(res.msg);
      }
    },
    // 弹框添加图片信息formdata del
    async deleteUploadinfoFormData() {
      this.uploadinfoFormdata.delete("id");
      // this.uploadinfoFormdata.delete('tenancy_id')
      this.uploadinfoFormdata.delete("name");
      this.uploadinfoFormdata.delete("category");
      this.uploadinfoFormdata.delete("ordinal");
      this.uploadinfoFormdata.delete("link_url");
      this.uploadinfoFormdata.delete("state");
      this.uploadinfoFormdata.delete("system");
      this.uploadinfoFormdata.delete('business_system_id')
    },
    // 添加信息
    async submitForm(type) {
      if (type === "cancel") {
        // this.uploadinfo = this.$options.data().uploadinfo
        this.closeDialogFn();
        this.isuploadInfo = false;
        return;
      }
      if (!this.uploadinfo.name) {
        this.$message.error(this.uploadtitle + "名称不能为空");
      } else if (!this.uploadinfo.ordinal) {
        this.$message.error("排序排号不能为空");
      } else if (!this.uploadinfo.image) {
        this.$message.error("请上传图片");
      } else {
        this.deleteUploadinfoFormData();
        if (this.uploadinfo.id) {
          this.uploadinfoFormdata.append("id", this.uploadinfo.id);
        }
        // this.uploadinfoFormdata.append('tenancy_id', this.portalsInfo.tenancy_id)
        this.uploadinfoFormdata.append("name", this.uploadinfo.name);
        this.uploadinfoFormdata.append("category", this.uploadinfo.category);
        this.uploadinfoFormdata.append("ordinal", this.uploadinfo.ordinal);
        this.uploadinfoFormdata.append("link_url", this.uploadinfo.link_url);
        this.uploadinfoFormdata.append("state", this.uploadinfo.state ? 1 : 0);
        this.uploadinfoFormdata.append("system", 2300);
        this.uploadinfoFormdata.append('business_system_id', this.curSystemObj.id)
        
        if (this.uploadinfo.id) {
          const text = "正在修改...";
          const loading = this.$loading({
            lock: true,
            text: text,
            spinner: "el-icon-loading",
            background: "rgba(255, 255, 255, 0.6)",
          });
          const res = await putPortalsImg(this.uploadinfoFormdata.compatible());
          if (res.code === 0) {
            loading.close();
            this.$message.success("修改成功");
            if (this.uploadinfo.category === 1) {
              this.bannerList.forEach((item) => {
                if (this.uploadinfo.id === item.id) {
                  item.image = this.uploadinfo.image;
                }
              });
            } else if (this.uploadinfo.category === 2) {
              this.linkList.forEach((item) => {
                if (this.uploadinfo.id === item.id) {
                  item.image = this.uploadinfo.image;
                  item.name = this.uploadinfo.name;
                }
              });
            } else if (this.uploadinfo.category === 3) {
              this.codeList.forEach((item) => {
                if (this.uploadinfo.id === item.id) {
                  item.image = this.uploadinfo.image;
                }
              });
            } else if (this.uploadinfo.category === 4) {
              this.appbannerList.forEach((item) => {
                if (this.uploadinfo.id === item.id) {
                  item.image = this.uploadinfo.image;
                }
              });
            }
            this.isuploadInfo = false;
            this.getPortalsImgListFn(this.uploadinfo.category);
          } else {
            this.$message.error(res.msg);
          }
        } else {
          const text = "正在添加...";
          const loading = this.$loading({
            lock: true,
            text: text,
            spinner: "el-icon-loading",
            background: "rgba(255, 255, 255, 0.6)",
          });
          const ctype = this.uploadinfo.category;
          const _info = JSON.stringify(this.uploadinfo);
          const res = await addPortalsImg(this.uploadinfoFormdata.compatible());
          if (res.code === 0) {
            if (this.uploadinfo.category === 1) {
              // banner
              this.bannerList.push(JSON.parse(_info));
            } else if (this.uploadinfo.category === 2) {
              // link
              this.linkList.push(JSON.parse(_info));
            } else if (this.uploadinfo.category === 3) {
              // code
              this.codeList.push(JSON.parse(_info));
            } else if (this.uploadinfo.category === 4) {
              this.appbannerList.push(JSON.parse(_info));
            }
            loading.close();
            this.$message.success("上传成功");
            this.getPortalsImgListFn(ctype);
            this.closeDialogFn();
            const isParmas1 = ctype === 1 && this.bannerList.length > 5;
            const isParmas2 = ctype === 2 && this.linkList.length > 5;
            const isParmas3 = ctype === 3 && this.codeList.length > 1;
            const isParmas4 = ctype === 4 && this.appbannerList.length > 2;
            if (isParmas1 || isParmas2 || isParmas3 || isParmas4) {
              this.isuploadInfo = false;
            }
          } else {
            this.$message.error(res.msg);
          }
        }
      }
    },
    // 平台信息formdata del
    async deleteFormData() {
      this.paramsFormdata.delete("id");
      this.paramsFormdata.delete("name");
      this.paramsFormdata.delete("font_color");
      this.paramsFormdata.delete("font_size");
      this.paramsFormdata.delete("footer");
      // this.paramsFormdata.delete('tenancy_id')
      this.paramsFormdata.delete("introduction");
      this.paramsFormdata.delete("system");
      this.paramsFormdata.delete("domain");
      this.paramsFormdata.delete('business_system_id')
      this.paramsFormdata.delete('providers')
    },
    // 保存平台信息
    async commitFn() {
      if (!this.portalsInfo.name) {
        this.$message({ message: "平台名不能为空！", type: "error" });
        return;
      }
      if (!this.portalsInfo.footer) {
        this.$message({ message: "平台名尾页不能为空！", type: "error" });
        return;
      }
      var re =
        /^(?=^.{3,255}$)(http(s)?:\/\/)(www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\d+)*(\/\w+)*\/$/;
      if (this.portalsInfo.domain && !re.test(this.portalsInfo.domain)) {
        this.$message({ message: "请输入正确的域名！", type: "error" });
        return;
      }

      this.deleteFormData();
      const text =
        this.$route.query.id || !this.from
          ? "正在修改，请稍等..."
          : "正在新增， 请稍等....";
      const loading = this.$loading({
        lock: true,
        text: text,
        spinner: "el-icon-loading",
        background: "rgba(255, 255, 255, 0.6)",
      });
      this.paramsFormdata.append("id", this.portalsInfo.id);
      this.paramsFormdata.append("name", this.portalsInfo.name);
      this.paramsFormdata.append("font_color", this.portalsInfo.font_color);
      this.paramsFormdata.append("font_size", this.portalsInfo.font_size);
      this.paramsFormdata.append("footer", this.portalsInfo.footer);
      // this.paramsFormdata.append('tenancy_id', this.portalsInfo.tenancy_id)
      this.paramsFormdata.append("introduction", this.portalsInfo.introduction);
      this.paramsFormdata.append("system", 2300);
      this.paramsFormdata.append("domain", this.portalsInfo.domain);
      this.paramsFormdata.append('business_system_id', this.curSystemObj.id)
      // 赋值微信公众号信息
      if (this.providersObj.app_id) {
        this.paramsFormdata.set(
          "providers[" + 0 + "].app_id",
          this.providersObj.app_id
        );
      }
      if (this.providersObj.app_secret) {
        this.paramsFormdata.set(
          "providers[" + 0 + "].app_secret",
          this.providersObj.app_secret
        );
      }
      this.paramsFormdata.set("providers[" + 0 + "].provider_name", "WeChat");
      const res = await setPortals(this.paramsFormdata);
      // const res = await setPortals(this.paramsFormdata.compatible());
      if (res.code === 0) {
        loading.close();
        this.$message({ message: "平台信息填写成功", type: "success" });
        this.$emit('closeFn')
        if (this.from) {
          if (this.$route.query.type) {
            this.$router.push({
              path: "serviceauthorization",
              query: { id: this.$route.query.id, type: "add" },
            });
          } else {
            this.$router.go(-1);
          }
        } else {
          //this.$emit("updataSuccess", "platform");
        }
      } else {
        this.$message.error(res.msg);
      }
    },
    to_upload_img(formdata) {
      console.log(formdata);
      console.log(this.upimgurl);
    },
  },
};
</script>
<style>
.el-collapse {
  border: none;
}
.disUoloadSty .el-upload--picture-card {
  display: none; /* 上传按钮隐藏 */
}
</style>
<style lang="less" scoped>
.homeSetCon {
  width: 800px;
  
}
.close-btn{
    position: absolute;
    right: 10px;
    top: 0;
    color: #9facc3;
    font-size: 24px!important;
    cursor: pointer;
}
.container-item-border {
  width: 100%;
  // padding: 10px 10px 0px 10px;
  box-sizing: border-box;
  // border-bottom : 1px dashed #DCDFE6;
  position: relative;
  .container-item-title {
    text-align: left;
    color: #303133;
    .border_l {
      display: inline-block;
      width: 3px;
      height: 14px;
      border-radius: 1px;
      margin-right: 5px;
      vertical-align: middle;
      background: #0a70b0;
    }
  }
  ::v-deep .wechatTip{
    margin-left:142px;
  }
  .w_450 {
    width: 450px;
    margin: auto;
  }
  .w_300 {
    width: 300px;
  }
  .clr_ff9 {
    color: #ff9a50;
  }
  .uploadLogo {
    display: flex;
    align-items: center;
  }
  ::v-deep .wechatLabel{
    width: 135px;
    padding-right: 0;
  }
  .headImg {
    position: relative;
    width: 154px;
    height: 72px;
    line-height: 72px;
    background: #fbfdff;
    color: #0a70b0;
    border: 1px dashed #dddddd;
    z-index: 9;
  }
  .headImg img {
    height: 100%;
    max-width: 100%;
  }
  .bannerupload img {
    height: 100%;
    max-width: 100%;
  }
  .bannerupload:hover .operationbtn {
    display: block;
  }
  .bannerupload {
    position: relative;
    display: inline-block;
    width: 154px;
    height: 60px;
    line-height: 60px;
    text-align: center;
    cursor: pointer;
    background: #fbfdff;
    color: #0a70b0;
    border: 1px dashed #dddddd;
    font-size: 15px;
    margin-right: 15px;
    overflow: hidden;
  }
  .bannerupload img {
    height: 100%;
    max-width: 100%;
  }
  .bannerupload:hover .operationbtn {
    display: block;
  }
  .bannerupload:hover,
  .codeimg:hover,
  .headImg:hover {
    border-color: #0a70b0;
  }
  .Logolinkitem {
    padding: 0px 15px;
    box-sizing: border-box;
    text-align: left !important;
    color: #303133;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .Logolinkitem img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 5px;
    vertical-align: middle;
  }
  .codeimg {
    position: relative;
    width: 120px;
    height: 120px;
    background: #fbfdff;
    color: #0a70b0;
    border: 1px dashed #dddddd;
    margin-right: 15px;
    text-align: center;
    font-size: 12px;
  }
  .height120 {
    height: 120px;
  }
  .line120 {
    line-height: 120px;
  }
  .codeimg img {
    width: 100%;
    margin-right: 15px;
    max-width: 100%;
    height: 100%;
  }
  .codeimg:hover .operationbtn {
    display: block;
  }
  .operationbtn {
    display: none;
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);
    z-index: 10;
    text-align: center;
  }
  .operationbtn span {
    display: inline-block;
    width: 50px;
    height: 28px;
    line-height: 28px;
    color: #ffffff;
    border: 1 solid #e4e7ed;
    border-radius: 2px;
    cursor: pointer;
  }
}
// .container-item-border:last-child{
//   border: none;
// }
.formItem {
  margin-bottom: 5px !important;
}
.subBtnDiv {
  margin-left: 150px !important;
}
.el-upload__tip {
  font-size: 14px;
}
</style>
