<template>
  <div class="jurisdictionlist">
    <div class="oneSystemItem" v-if="oneSystem">
      <div class="listItemInfor">
        <div class="flex_row">
          <img class="pacs_img" :src="ks" />
          <div class="shareHead">
            <div
              class="systemNameTitle overOneLine"
              v-bind:title="oneSystem.name"
            >
              {{ oneSystem.name }}
            </div>
            <div class="productIdAndType">
              <span
                class="productIdAndTypeText productName overOneLine"
                :title="oneSystem.product_name"
                >{{ oneSystem.product_name }}</span
              ><span
                class="productIdAndTypeText idNumber overOneLine"
                :title="'系统ID：' + oneSystem.id"
                >{{ oneSystem.id }}</span
              >
            </div>
          </div>
        </div>
        <div class="clr_666 mt10">
          <div class="mt5 overOneLine">
            <span class="clr_999">开通服务：</span>
            <span class="clr_303">{{ oneSystem.function_service_names }}</span>
          </div>
        </div>
        <div class="flex_row mt10 f14">
          <div
            class="tl adminInfor"
            v-bind:title="'管理人员：' + oneSystem.admin_name"
          >
            <span class="clr_999">管理人员：</span>
            <span class="clr_303"
              >{{ oneSystem.admin_name }}({{ oneSystem.admin_phone }})</span
            >
          </div>
        </div>
        <div class="mt10">
          <div class="flex_row tl f14">
            <div class="useInstituteLabel clr_999">使用机构：</div>
            <div
              class="clr_303 useInstituteNum overOneLine flex_row"
              v-if="oneSystem.institution_names.length != 0"
            >
              [{{ oneSystem.institution_names.length }}家]
              <!-- <span
              v-for="(itemname, index) in oneSystem.institution_names"
              :key="itemname"
              ><span v-if="index != 0">、</span>{{ itemname }}</span> -->

              <tooltip-over
                :content="oneSystem.institution_names"
                placement="top-start"
                class="wid190"
                refName="tooltipOver"
              ></tooltip-over>
            </div>
            <div class="clr_303 useInstituteNum overOneLine" v-else>无</div>
          </div>
        </div>
      </div>
      <div class="operateBtnCon">
        <div
          class="operateBtnOneBox"
          v-if="isSetUdi"
          @click="isShowinfoFn('aboutSystem', oneSystem.id)"
        >
          <div class="operateBtnOne">
            <span class="operateBtnTxt">关于</span>
          </div>
        </div>
        <div
          class="operateBtnOneBox"
          @click="isShowinfoFn('edit', oneSystem.id)"
        >
          <div class="operateBtnOne">
            <span class="operateBtnTxt">编辑</span>
          </div>
        </div>
        <div
          class="operateBtnOneBox"
          v-if="isShowManageBtn"
          @click="
            isShowinfoFn(
              'operate',
              oneSystem.id,
              oneSystem.product_code,
              oneSystem.is_jump
            )
          "
        >
          <div class="operateBtnOne">
            <span class="operateBtnTxt"
              ><i class="iconfont">&#xe667;</i> 系统管理</span
            >
          </div>
        </div>
      </div>
    </div>
    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="isPacsinfo"
      :show-close="false"
      :withHeader="false"
      :wrapperClosable="this.operateSystemInfo.title === '编辑' ? true : false"
      :direction="direction"
      :before-close="handleClose"
    >
      <intelligenceOfficeinfo
        :key="key"
        ref="info"
        :pacsinfo="operateSystemInfo"
        :pageInfo="InstitutionPage"
        :officeServiceList="officeServiceList"
        @closeFn="closeFn"
        @selectInstitionListFn="selectInstitionListFn"
        @selectCurRowFn="selectCurRow"
        @delInstitutionFn="delInstitutionFn"
        @changePhone="changePhone"
        @ChoiceOrganFn="ChoiceOrganFn"
        @serchListFn="serchListFn"
        @getSerchName="getSerchName"
        @getAdminNameFn="getAdminNameFn"
        @pageSizeChangeFn="pageSizeChangeFn"
        @CheckOfficeidsFn="CheckOfficeidsFn"
        @activeSystemFn="activeSystemFn"
        @submitForm="submitForm"
        @isAddInstution="isAddInstution"
        @getRowKeys="getRowKeys"
        @instclose="instclose"
      ></intelligenceOfficeinfo>
    </el-drawer>
  </div>
</template>

<script>
import Vue from "vue";
import { mapGetters } from "vuex";
import aboutSystem from "tomtaw-system-about";
import Mgr from "@/utils/SecurityService";
import JSEncrypt from "jsencrypt";
import intelligenceOfficeinfo from "./intelligenceOfficeinfo";
import tooltipOver from "../tooltipOver";
import {
  addPacsSystems,
  getInstitutionList,
  getUseInstitute,
  getintellingenceOfficeList,
  getPacsSystemsInfoByid,
  putPacsSystems,
  getPasServicecList,
  getAllOfficeServicesList,
} from "@/api/platform_costomer/institution";
import { getLoginName, getConfigurations } from "@/api/commonHttp";
import moment from "moment";
export default {
  components: {
    intelligenceOfficeinfo,
    tooltipOver,
  },
  computed: {
    ...mapGetters(["isSetUdi", "isShowManageBtn"]),
  },
  props: {
    oneSystem: Object,
  },
  data() {
    return {
      ks: require("../../../../../assets/images/intelligenceOfficeIcon.png"), // 放射
      info: "",
      isPacsinfo: false,
      loading: true,
      direction: "rtl",
      pacsList: [],
      isactive: "",
      key: 0,
      searchData: {
        contains_name: "",
        admin_info: "",
        institution_ids: [],
        type: 3,
      },
      InstitutionsArr: [],
      operateSystemInfo: {
        title: "新增智能科室系统",
        serchName: "",
        activesystem: "",
        systemList: [{ code: "", name: "" }], // 授权产品
        isAdminname: false,
        product_name: "",
        providersObj: {
          app_id: "",
          app_secret: "",
          provider_name: "WeChat",
        },
        formInfo: {
          type: 3,
          product_code: "DMS_RIS",
          name: "",
          admin_phone: "",
          admin_name: "",
          function_services: [],
          domain: "",
          providers: [],

          isIndefinitely: true, // 是否无限期
          start_date: moment().format("YYYY-MM-DD"), // 开始期限
          stop_date: null, // 结束期限
          state: 10, // 启用状态
          reason: "", // 停用原因
        },
        rules: {
          product_code: [
            { required: true, message: "请选择产品名称", trigger: "change" },
          ],
          name: [
            { required: true, message: "请输入系统名称", trigger: "blur" },
          ],
          admin_phone: [
            { required: true, message: "请输入管理员电话", trigger: "change" },
          ],
          admin_name: [
            { required: true, message: "请输入管理员姓名", trigger: "change" },
          ],
        },
        isChioseOrgan: false,
        institutionList: [], // 机构列表
        deplist: [],
        multipleSelection: [], // 机构列表选中机构
      },
      isUpdate: false,
      isFirstChange: true,
      InstitutionPage: {
        eof: 1,
        page_index: 1,
        page_size: 8,
        total_count: 0,
        total_pages: 1,
      },
      officeServiceList: [],
    };
  },
  created() {},
  methods: {
    initData() {
      // this.getintellingenceOfficeFn();
      // 加密函数
      // this.getConfigurationsFn();
      // 获取使用机构
      this.getMyInstitutions();
    },
    async getConfigurationsFn() {
      const res = await getConfigurations("TransmissionSecurity.RSA.PublicKey");
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) {
          // 注册方法
          const pubKey = res.data; // ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt();
          encryptStr.setPublicKey(pubKey); // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()); // 进行加密
          return data;
        };
      }
    },
    resetSearchDataFn() {
      this.searchData = {
        contains_name: "",
        admin_info: "",
        institution_ids: [],
        type: 3,
      };
      //this.getintellingenceOfficeFn();
    },
    changePhone() {
      if (this.isUpdate) {
        // 是否是第一次改变
        if (this.isFirstChange) {
          this.operateSystemInfo.formInfo.admin_phone = "";
          this.operateSystemInfo.formInfo.admin_name = "";
        }
        this.isFirstChange = false;
      }
    },
    // 授权产品列表
    async getOfficeServiceListFn() {
      const self = this;
      self.officeServiceList = [];
      const res = await getAllOfficeServicesList();
      if (res.code === 0) {
        if (res.data.length != 0) {
          res.data.forEach((val) => {
            self.officeServiceList.push(val);
          });
        }
      }
    },
    // 获取已经签约的机构
    async getMyInstitutions() {
      //var _type = 3;
      const res = await getUseInstitute();
      if (res.code === 0) {
        this.InstitutionsArr = res.data;
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 系统列表
    async getintellingenceOfficeFn() {
      const res = await getintellingenceOfficeList(this.searchData);
      if (res.code === 0) {
        this.loading = false;
        this.pacsList = res.data;
      } else {
        this.loading = false;
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 授权产品列表
    async getPasServicecListFn() {
      const res = await getPasServicecList();
      if (res.code === 0) {
        this.operateSystemInfo.systemList = res.data;
      }
    },
    isAddInstution() {
      if (!this.operateSystemInfo.formInfo.product_code) {
        this.$message({
          type: "warning",
          message: "请选择授权产品！",
        });
        return;
      }
      this.getInstitutionListFn();
      this.operateSystemInfo.isChioseOrgan = true;
    },
    // 操作按钮
    async isShowinfoFn(type, id, code, isopen) {
      if (type === "add") {
        this.isPacsinfo = true;
        this.operateSystemInfo.title = "新增智能科室系统";
        this.isUpdate = false;
        this.getOfficeServiceListFn();
        //this.getPasServicecListFn();
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
        // console.log(this.operateSystemInfo)
      } else if (type === "operate") {
        // if (code) {
        //   sessionStorage.setItem('currentSystemClass', code)
        // }
        // if (id) {
        //   sessionStorage.setItem('lastname', id)
        // }
        const href = configUrl.frontEndUrl + "/dms?dms_id=" + id;
        window.open(href, "_blank");
      } else if (type == "aboutSystem") {
        var manager = new Mgr();
        manager.getRole().then(function (item) {
          if (item) {
            aboutSystem("dms", item);
          }
        });
      } else {
        await this.getOfficeServiceListFn();
        await this.$emit("closeAllDrawDetailAlert", "DMS");
        this.isactive = id;
        this.isPacsinfo = true;
        this.isUpdate = true;
        this.isFirstChange = true;
        this.operateSystemInfo.title = "编辑";
        const responce = getPacsSystemsInfoByid(id); // 详情接口
        responce.then((res) => {
          if (res.code === 0) {
            this.operateSystemInfo.product_name = res.data.product_name;
            this.operateSystemInfo.formInfo.product_code =
              res.data.product_code;
            this.operateSystemInfo.formInfo.id = res.data.id;
            this.operateSystemInfo.formInfo.name = res.data.name;
            this.operateSystemInfo.formInfo.admin_phone = res.data.admin_phone;
            this.operateSystemInfo.formInfo.admin_name = res.data.admin_name;
            this.operateSystemInfo.formInfo.function_services =
              res.data.function_services;
            this.operateSystemInfo.formInfo.domain = res.data.domain;
            this.operateSystemInfo.institution_count =
              res.data.institution_count;
            this.operateSystemInfo.isAdminname = true;
            this.operateSystemInfo.multipleSelection = [];

            this.operateSystemInfo.formInfo.isIndefinitely =
              res.data.stop_date === "无期限" ? true : false;
            this.operateSystemInfo.formInfo.start_date = res.data.start_date;
            this.operateSystemInfo.formInfo.stop_date =
              res.data.stop_date === "无期限" ? "" : res.data.stop_date;
            this.operateSystemInfo.formInfo.state = res.data.state;
            this.operateSystemInfo.formInfo.reason = res.data.reason;

            res.data.institutions.forEach((val) => {
              if (!val.office_id) {
                val.office_id = "";
              }
              this.operateSystemInfo.multipleSelection.push(val);
            });
            if (res.data.providers.length != 0) {
              this.operateSystemInfo.providersObj = res.data.providers[0];
            }
          }
        });
      }
    },
    // 选择产品类型
    activeSystemFn(index, code) {
      this.operateSystemInfo.activesystem = index;
      this.operateSystemInfo.formInfo.product_code = code;
    },
    // 手机号姓名匹配
    async getAdminNameFn() {
      var _phone = this.operateSystemInfo.formInfo.admin_phone;
      var phoneReg = /^1[3456789]\d{9}$/;
      if (!phoneReg.test(_phone)) {
        return;
      }
      var url = `/users/lite/${_phone}`;
      var res = await getLoginName(url);
      if (res.code === 0) {
        this.operateSystemInfo.formInfo.admin_name = res.data
          ? res.data.name
          : "";
        this.operateSystemInfo.isAdminname = true;
      } else {
        this.operateSystemInfo.isAdminname = false;
        this.operateSystemInfo.formInfo.admin_name = "";
      }
    },
    handleClose(done) {
      done();
    },
    // 关闭 选择机构
    instclose() {
      this.operateSystemInfo.institutionList.forEach((item) => {
        this.$nextTick(() => {
          this.$refs.info.$refs.institutions.toggleRowSelection(item, false);
        });
      });
      this.operateSystemInfo.isChioseOrgan = false;
    },
    closeFn() {
      var info = {
        type: "cancel",
        refs: this.$refs["info"].$refs,
        formName: "formInfo",
      };
      this.submitForm(info);
    },
    // 获取机构列表
    async getInstitutionListFn() {
      let filter_system_id = "";
      if (this.operateSystemInfo.title !== "新增智能科室系统") {
        filter_system_id = "&filter_system_id=" + this.isactive;
      }
      const _url =
        "/institutions?is_show_office=true" +
        "&offset=" +
        this.InstitutionPage.page_index +
        "&limit=" +
        this.InstitutionPage.page_size +
        "&name=" +
        this.operateSystemInfo.serchName +
        filter_system_id;
      const res = await getInstitutionList(_url);
      if (res.code === 0) {
        res.data.forEach((item) => {
          item.office_ids = [];
          if (item.offices.length === 1) {
            item.office_ids[0] = item.offices[0].id;
          }
        });

        if (
          this.operateSystemInfo.title === "编辑" ||
          this.operateSystemInfo.multipleSelection.length !== 0
        ) {
          // 勾上已选中的
          res.data.forEach((itemids) => {
            this.operateSystemInfo.multipleSelection.forEach((item) => {
              if (itemids.id === item.id) {
                this.$nextTick(() => {
                  this.$refs.info.$refs.institutions.toggleRowSelection(
                    itemids,
                    true
                  );
                });
                itemids.office_ids = item.office_ids;
                itemids.is_selected = true;
              }
            });
          });
          this.operateSystemInfo.institutionList = res.data;
        } else {
          // 新增
          this.operateSystemInfo.institutionList = res.data;
          // this.operateSystemInfo.institutionList.forEach(item => {
          //   this.$nextTick(() => {
          //     this.$refs.info.$refs.institutions.clearSelection()(item, false)
          //   })
          // })
          // this.operateSystemInfo.multipleSelection = []
          if (this.operateSystemInfo.multipleSelection.length === 0) {
            this.$refs.info.$refs.institutions.clearSelection();
          }
        }

        this.InstitutionPage = res.page;
      }
    },
    getRowKeys(row) {
      return row.id;
    },
    // 分页
    pageSizeChangeFn(info, serchName) {
      this.InstitutionPage.page_index = info.page;
      this.InstitutionPage.page_size = info.limit;
      this.operateSystemInfo.serchName = serchName;
      this.getInstitutionListFn();
    },
    // 选中某一行
    selectCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === row.id) {
            self.operateSystemInfo.multipleSelection.splice(i, 1);
          }
        });
      }
    },
    // 去掉数组元素 里面对象 id值相同的
    clearCommonId(arr) {
      let obj = {};
      let peon = arr.reduce((cur, next) => {
        obj[next.id] ? "" : (obj[next.id] = true && cur.push(next));
        return cur;
      }, []);
      return peon;
    },
    handleInstituSelectionChange(val) {
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    // 机构 select change事件
    selectInstitionListFn(val) {
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    // 机构 提交
    ChoiceOrganFn(type) {
      this.instclose();
    },
    CheckOfficeidsFn(val, obj) {
      if (obj.is_selected) {
        this.operateSystemInfo.multipleSelection.forEach((item) => {
          if ((item.id = obj.id)) {
            item.office_id = val;
          }
        });
      }
      console.log(this.operateSystemInfo.multipleSelection);
    },
    delInstitutionFn(id) {
      this.$confirm("是否删除这条机构信息？", "删除信息", {
        distinguishCancelAndClose: true,
        confirmButtonText: "删除",
        cancelButtonText: "取消",
      }).then(() => {
        this.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === id) {
            if (this.operateSystemInfo.institutionList.length > 0) {
              this.$refs.info.$refs.institutions.toggleRowSelection(
                item,
                false
              );
            }
            this.operateSystemInfo.multipleSelection.splice(i, 1);
            this.$message({
              type: "success",
              message: "删除成功",
            });
          }
        });
      });
    },
    async addPacsSystemsFn() {
      const _params = JSON.parse(
        JSON.stringify(this.operateSystemInfo.formInfo)
      );
      const loading = this.$loading({
        lock: true,
        text: _params.id ? "正在修改，请稍等..." : "正在新增，请稍等...",
        spinner: "el-icon-loading",
        background: "rgba(255, 255, 255, 0.6)",
      });
      var _institutionList = [];
      this.operateSystemInfo.multipleSelection.forEach((item) => {
        var info = {};
        info.id = item.id;
        info.office_ids = item.office_ids;
        _institutionList.push(info);
      });
      _params.institutions = _institutionList;
      _params.providers = [];
      _params.providers.push(this.operateSystemInfo.providersObj);
      // 对手机号加密
      var adminPhone = _params.admin_phone;
      _params.admin_phone = this.$getRsaCode(_params.admin_phone);
      var res = null;
      var tipmsg = "新增智能科室系统成功！";

      // 特殊处理一下期限相关的字段
      _params.stop_date = _params.isIndefinitely ? null : _params.stop_date;
      _params.reason = _params.state === 10 ? "" : _params.reason;
      delete _params.isIndefinitely;

      if (_params.id) {
        delete _params["type"];
        res = await putPacsSystems(_params);
        tipmsg = "修改智能科室系统成功！";
      } else {
        res = await addPacsSystems(_params);
      }
      loading.close();
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: tipmsg,
        });
        this.isPacsinfo = false;
        // this.getintellingenceOfficeFn();
        this.$emit("getSystemList");
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      } else {
        this.operateSystemInfo.formInfo.admin_phone = adminPhone;
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    getSerchName(val) {
      this.operateSystemInfo.serchName = val;
    },
    // 选择机构页面 查询按钮
    async serchListFn() {
      const _url =
        "/institutions?office_type=2" +
        "&offset=1" +
        "&limit=" +
        this.InstitutionPage.page_size +
        "&name=" +
        this.operateSystemInfo.serchName;
      const res = await getInstitutionList(_url);
      if (res.code === 0) {
        this.operateSystemInfo.institutionList = res.data;
        this.InstitutionPage = res.page;
      }
    },
    submitForm(info) {
      if (info.type === "commit") {
        if (!this.operateSystemInfo.formInfo.product_code) {
          this.$message({ type: "error", message: "请选择产品" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.name) {
          this.$message({ type: "error", message: "请输入系统名称" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.admin_phone) {
          this.$message({ type: "error", message: "请输入管理员电话" });
          return;
        }
        var phoneReg = /^1[3456789]\d{9}$/;
        // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
        if (!this.isUpdate || (this.isUpdate && !this.isFirstChange)) {
          if (!phoneReg.test(this.operateSystemInfo.formInfo.admin_phone)) {
            this.$message({
              message: "请输入正确的手机号码!",
              type: "warning",
            });
            return false;
          }
        }
        if (!this.operateSystemInfo.formInfo.admin_name) {
          this.$message({ type: "error", message: "请输入管理员姓名" });
          return;
        }
        // if (this.operateSystemInfo.formInfo.function_services.length == 0) {
        //   this.$message({ type: "error", message: "请选择开通服务" });
        //   return;
        // }

        if (!this.operateSystemInfo.formInfo.start_date) {
          this.$message({ type: "error", message: "请选择使用开始期限" });
          return;
        }
        if (
          !this.operateSystemInfo.formInfo.isIndefinitely &&
          !this.operateSystemInfo.formInfo.stop_date
        ) {
          this.$message({ type: "error", message: "请选择使用结束期限" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.state) {
          this.$message({ type: "error", message: "请选择系统状态" });
          return;
        }
        if (
          this.operateSystemInfo.formInfo.state === -2 &&
          !this.operateSystemInfo.formInfo.reason
        ) {
          this.$message({ type: "error", message: "请输入停用备注" });
          return;
        }

        var re =
          /^(?=^.{3,255}$)(http(s)?:\/\/)(www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\d+)*(\/\w+)*\/$/;
        if (
          this.operateSystemInfo.formInfo.domain &&
          !re.test(this.operateSystemInfo.formInfo.domain)
        ) {
          this.$message({ message: "请输入正确的域名！", type: "error" });
          return;
        }
        this.addPacsSystemsFn();
      } else {
        this.isPacsinfo = false;
        this.isactive = "";
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      }
    },
  },
};
</script>

<style lang="less" scoped>
.jurisdictionlist {
  // width: 100%;
  display: flex;
  flex-wrap: wrap;
  .oneSystemItem {
    width: 100%;
  }
  .intellContainer {
    height: calc(100% - 110px);
    padding: 0px 15px;
    position: relative;
    ::v-deep .el-table__body-wrapper {
      height: calc(100% - 40px);
      overflow-y: auto;
    }
  }
}
.list-item {
  width: calc(25% - 15px);
  margin-right: 15px;
  border: 1px solid #ebeef5;
  box-shadow: 0 1px 5px 0 rgba(26, 26, 26, 0.050980392156862744);
  box-sizing: border-box;
  border-radius: 6px;
  background: #ffffff;
  margin-bottom: 15px;
  .listItemInfor {
    padding: 18px 14px 14px 18px;
    //border-bottom: 1px solid #ebeef5;
  }
  .active {
    background: rgba(10, 112, 176) !important;
    color: #fff !important;
  }
  .pacs_img {
    width: 52px;
    height: 52px;
    vertical-align: middle;
  }
  .title {
    // max-width: 200px;
    width: 100%;
  }
  .systemNameTitle {
    width: 100%;
    font-size: 20px;
    color: #1f2f3d;
    font-weight: 500;
    position: relative;
    top: -3px;
  }
  .shareHead {
    width: calc(100% - 70px);
    margin-left: 16px;
  }
  .productIdAndType {
    display: flex;
    .productIdAndTypeText {
      display: inline-block;
      line-height: 22px;
    }
    .productName {
      margin-right: 10px;
    }
    .idNumber {
      display: inline-block;
      max-width: 190px;
    }
  }
  .item_btn {
    padding: 0 10px;
    height: 30px;
    line-height: 28px;
    text-align: center;
    background: rgba(255, 255, 255, 1);
    border: 1px solid rgba(10, 112, 176, 0.5);
    border-radius: 3px;
    color: #0a70b0;
    cursor: pointer;
  }
  .manageBtn {
    background-color: #0a70b0;
    color: #fff;
  }
  .border_bd {
    border-bottom: 1px dashed #dcdfe6;
  }
  .useInstituteLabel {
    width: 70px;
  }
  .useInstituteNum {
    width: calc(100% - 70px);
  }
  .overOneLine {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .contractedhospital {
    display: flex;
    .contractedLabel {
      font-size: 14px;
      color: #909399;
    }
    .contractedNum {
      font-size: 14px;
      color: #0a70b0;
      i {
        margin-left: 5px;
      }
    }
  }
  .operateBtnCon {
    display: flex;
    height: 40px;
    align-items: center;
    border-top: 1px solid #ebeef5;
    .operateBtnOneBox {
      flex: 1;
      height: 100%;
      display: flex;
      align-items: center;
      cursor: pointer;
    }
    .operateBtnOne {
      width: 100%;
      text-align: center;
      font-size: 14px;
      color: #0a70b0;
      border-right: 1px solid #dcdfe6;
    }
    .operateBtnOneBox:last-of-type {
      .operateBtnOne {
        border-right: none;
      }
    }
    .operateBtnOneBox:hover {
      background: #f2f7ff;
    }
  }
}
.list-item:hover {
  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(10, 112, 176, 0.3);
}
.list-item:hover .title {
  color: #0a70b0;
}
.adminInfor {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.system_name {
  font-size: 15px;
  color: #303133;
}
.institutionName {
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.operateBtn {
  display: inline-block;
  cursor: pointer;
  height: 32px;
  line-height: 30px;
  padding: 0 10px;
  font-size: 15px;
  color: #0a70b0;
  border: 1px solid #ebeef5;
  border-radius: 3px;
  i {
    padding-right: 4px;
  }
}
.manageBtn {
  background: #0a70b0;
  color: #fff;
  border: 1px solid #0a70b0;
}
.serachLabel {
  color: #303133;
  display: inline-block;
}
.adminInfor {
  // width: 50%;
  // max-width: 170px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

@media screen and (max-width: 1500px) {
  .list-item {
    width: calc(50% - 20px) !important;
  }
  .idNumber {
    max-width: initial !important;
  }
}
</style>
