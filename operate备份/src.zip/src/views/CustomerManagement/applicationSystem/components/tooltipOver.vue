<template>
  <div class="text-tooltip">
    <el-tooltip class="item" effect="dark" :disabled="isShowTooltip" :content="newContent" placement="top">
      <p class="over-flow" :class="className" @mouseover="onMouseOver(refName)">
        <span :ref="refName">{{newContent||'无'}}</span>
      </p>
    </el-tooltip>
  </div>
</template>

<script>
  export default {
    name: 'textTooltip',
    props: {
      // 显示的文字内容
      content: {
        type: Array,
        default: () => {
          return []
        }
      },
      // 外层框的样式，在传入的这个类名中设置文字显示的宽度
      className: {
        type: String,
        default: () => {
          return ''
        }
      },
      // 为页面文字标识（如在同一页面中调用多次组件，此参数不可重复）
      refName: {
        type: String,
        default: () => {
          return ''
        }
      }
    },
    watch: {
      content: {
       handler (newVal) {
        if (Array.isArray(newVal)) {// 值是数组
          var str = ''
          if (this.content.length != 0) {
            for (var i = 0; i < this.content.length; i++) {
              str += this.content[i] + '、'
            }
            // 去掉最后一个逗号(如果不需要去掉，就不用写)
            if (str.length > 0) {
              str = str.substr(0, str.length - 1)
            }
            this.newContent = str
          } else {
            this.newContent = ''
          }
        } else if (typeof newVal === 'string') {// 值是字符串
          this.newContent = newVal
        }
      },
      deep: true,
      immediate: true
    }
    },
    data() {
      return {
        isShowTooltip: true,
        newContent: '',
      }
    },
    mounted () {
        
    },
    methods: {
      onMouseOver(str) {
        let parentWidth = this.$refs[str].parentNode.offsetWidth;
        let contentWidth = this.$refs[str].offsetWidth;
        // 判断是否开启tooltip功能
        if (contentWidth>parentWidth) {
          this.isShowTooltip = false;
        } else {
          this.isShowTooltip = true;
        }
      }
    }
  }
</script>

<style lang="less" scoped>
.over-flow {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.wid190 {
    width: 100%;
}
p{
    margin: 0;
}
</style>
