<template>
  <div class="jurisdictionlist">
    <div class="list-item" v-for="(item, index) in systemArr" :key="index">
      <!-- 停用标识 -->
      <el-popover
        v-if="item.state === -2"
        placement="top-start"
        trigger="hover"
      >
        <div v-if="item.operator_name">
          停用人：{{ item.operator_name }}({{ item.update_time }})
        </div>
        <div>备注：{{ item.reason }}</div>
        <div slot="reference" class="deactivated-box">
          <div>停用!</div>
          <div class="deactivated-time" v-if="item.update_time">
            {{ item.update_time.substring(0, 11) }}
          </div>
        </div>
      </el-popover>
      <div class="listItemInfor">
        <div class="flex_row">
          <img
            class="pacs_img"
            :src="
              item.product_code == '620'
                ? CS
                : item.product_code == '610'
                ? FS
                : item.product_code == '630'
                ? NJ
                : item.product_code == '640'
                ? XD
                : item.product_code == '650'
                ? PS
                : XD
            "
          />
          <div class="shareHead">
            <div class="systemNameTitle overOneLine" v-bind:title="item.name">
              {{ item.name }}
            </div>
            <div class="productIdAndType">
              <span
                class="productIdAndTypeText productName overOneLine"
                :title="item.product_name"
                >{{ item.product_name }}</span
              ><span
                class="productIdAndTypeText idNumber overOneLine"
                :title="'系统ID：' + item.id"
                >{{ item.id }}</span
              >
            </div>
          </div>
        </div>
        <div class="clr_666 mt10 f14">
          <div class="mt5 overOneLine">
            <span class="clr_999">开通服务：</span>
            <span class="clr_303">{{ item.function_service_names }}</span>
          </div>
        </div>
        <div class="flex_row mt10 f14">
          <div
            class="tl adminInfor"
            v-bind:title="'管理人员：' + item.admin_name"
          >
            <span class="clr_999">管理人员：</span>
            <span class="clr_303"
              >{{ item.admin_name }}({{ item.admin_phone }})</span
            >
          </div>
        </div>
        <div class="mt10">
          <div class="flex_row tl f14">
            <div class="useInstituteLabel clr_999">使用机构：</div>
            <div
              class="clr_303 useInstituteNum overOneLine flex_row"
              v-if="item.institution_names.length != 0"
            >
              [{{ item.institution_names.length }}家]
              <!-- <span
              v-for="(itemname, index) in item.institution_names"
              :key="itemname"
              ><span v-if="index != 0">、</span>{{ itemname }}</span> -->

              <tooltip-over
                :content="item.institution_names"
                placement="top-start"
                class="wid190"
                refName="tooltipOver"
              ></tooltip-over>
            </div>
            <div class="clr_303 useInstituteNum overOneLine" v-else>无</div>
          </div>
        </div>
      </div>
      <div class="operateBtnCon">
        <div
          class="operateBtnOneBox"
          v-if="isSetUdi"
          @click="isShowinfoFn('aboutSystem', item.id)"
        >
          <div class="operateBtnOne">
            <span class="operateBtnTxt">关于</span>
          </div>
        </div>
        <div class="operateBtnOneBox" @click="isShowinfoFn('edit', item.id)">
          <div class="operateBtnOne">
            <span class="operateBtnTxt">编辑</span>
          </div>
        </div>
        <div
          class="operateBtnOneBox"
          v-if="isShowManageBtn"
          @click="
            isShowinfoFn('operate', item.id, item.product_code, item.is_jump)
          "
        >
          <div class="operateBtnOne">
            <span class="operateBtnTxt"
              ><i class="iconfont">&#xe667;</i> 系统管理</span
            >
          </div>
        </div>
      </div>
    </div>
    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="isPacsinfo"
      :show-close="false"
      :withHeader="false"
      :wrapperClosable="this.operateSystemInfo.title === '编辑' ? true : false"
      :direction="direction"
      :before-close="handleClose"
    >
      <imgsystem-info
        ref="info"
        :tancyDetail="tancyDetail"
        :pacsinfo="operateSystemInfo"
        :isUpdate="isUpdate"
        :pageInfo="InstitutionPage"
        @closeFn="closeFn"
        @selectInstitionListFn="selectInstitionListFn"
        @selectCurRowFn="selectCurRow"
        @changePhone="changePhone"
        @ChoiceOrganFn="ChoiceOrganFn"
        @serchListFn="serchListFn"
        @getSerchName="getSerchName"
        @getAdminNameFn="getAdminNameFn"
        @pageSizeChangeFn="pageSizeChangeFn"
        @CheckOfficeidsFn="CheckOfficeidsFn"
        @activeSystemFn="activeSystemFn"
        @submitForm="submitForm"
        @isAddInstution="isAddInstution"
        @getRowKeys="getRowKeys"
        @instclose="instclose"
      ></imgsystem-info>
    </el-drawer>
  </div>
</template>

<script>
import Vue from "vue";
import aboutSystem from "tomtaw-system-about";
import Mgr from "@/utils/SecurityService";
// import JSEncrypt from "jsencrypt";
import JSEncrypt from "@/utils/jsencrypt.min";
import { mapGetters } from "vuex";
import ImgsystemInfo from "./info";
import tooltipOver from "../tooltipOver";
// import { addPacsSystems, getInstitutionList, getPascList, getPacsSystemsInfoByid, putPacsSystems, getPasServicecList } from '@/api/platform_costomer/institution'
import {
  getQualityCenterService,
  getAllQualityCenter,
  getQualityCenterDetail,
  addImgControlCenter,
  updateImgControlCenter,
  getQualityCenterlogo,
  getQualityCenterList,
} from "@/api/platform_costomer/imgControlCenter";
import { getLoginName, getConfigurations } from "@/api/commonHttp";
import { getCostomerInfoDetail } from "@/api/platform_operate/costomer";
import moment from "moment";

export default {
  components: {
    ImgsystemInfo,
    tooltipOver,
  },
  computed: {
    ...mapGetters(["isSetUdi", "isShowManageBtn"]),
  },
  props: {
    systemArr: Array,
  },
  data() {
    return {
      CS: require("../../../../../assets/images/ZK_CS_Image.png"), // 超声
      FS: require("../../../../../assets/images/ZK_FS_Image.png"), // 放射
      NJ: require("../../../../../assets/images/ZK_NJ_Image.png"), // 内镜
      XD: require("../../../../../assets/images/ZK_XD_Image.png"), // 心电
      PS: require("../../../../../assets/images/ZK_PS_Image.png"), // 病理
      info: "",
      addImgControlForm: "",
      isPacsinfo: false,
      loading: true,
      direction: "rtl",
      pacsList: [],
      isactive: "",
      isoperateactive: "",
      operateSystemInfo: {
        title: "新增质控系统",
        serchName: "",
        activesystem: "",
        systemList: [{ code: "", name: "" }], // 授权产品
        isAdminname: false,
        product_name: "",
        module_name: "",
        providersObj: {
          app_id: "",
          app_secret: "",
          provider_name: "WeChat",
        },
        formInfo: {
          id: 0,
          type: "",
          product_code: "",
          name: "",
          admin_phone: "",
          admin_name: "",
          introduction: "",
          domain: "",
          providers: [],

          isIndefinitely: true, // 是否无限期
          start_date: moment().format("YYYY-MM-DD"), // 开始期限
          stop_date: null, // 结束期限
          state: 10, // 启用状态
          reason: "", // 停用原因
        },
        rules: {
          product_code: [
            { required: true, message: "请选择产品名称", trigger: "change" },
          ],
          name: [
            { required: true, message: "请输入系统名称", trigger: "blur" },
          ],
          admin_phone: [
            { required: true, message: "请输入管理员电话", trigger: "change" },
          ],
          admin_name: [
            { required: true, message: "请输入管理员姓名", trigger: "change" },
          ],
        },
        isChioseOrgan: false,
        institutionList: [], // 机构列表
        deplist: [],
        multipleSelection: [], // 机构列表选中机构
      },
      isUpdate: false,
      isFirstChange: true,
      QualityCenterDetail: {},
      choosedInstituteArr: [],
      tancyDetail: "",
      InstitutionPage: {
        eof: 1,
        page_index: 1,
        page_size: 8,
        total_count: 0,
        total_pages: 1,
      },
      choiseList: [], // select 选中机构
      isChoiceFirst: true, // 是否第一次select
    };
  },
  created() {
    // 获取租户详情
    this.getTancyDetail();
    // this.getPascListFn();
    // 加密函数
    //this.getConfigurationsFn();
    // 初始化formdata
    this.addImgControlForm = new FormData();
  },
  methods: {
    async getConfigurationsFn() {
      const res = await getConfigurations("TransmissionSecurity.RSA.PublicKey");
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) {
          // 注册方法
          const pubKey = res.data; // ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt();
          encryptStr.setPublicKey(pubKey); // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()); // 进行加密
          return data;
        };
      }
    },
    changePhone() {
      if (this.isUpdate) {
        // 是否是第一次改变
        if (this.isFirstChange && this.QualityCenterDetail.admin_phone) {
          this.operateSystemInfo.formInfo.admin_phone = "";
          this.operateSystemInfo.formInfo.admin_name = "";
        }
        this.isFirstChange = false;
      }
    },
    // 系统列表
    async getPascListFn() {
      const res = await getAllQualityCenter();
      if (res.code === 0) {
        this.loading = false;
        this.pacsList = res.data;
      } else {
        this.loading = false;
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 授权产品列表
    async getImgServiceListFn() {
      const res = await getQualityCenterService();
      if (res.code === 0) {
        this.operateSystemInfo.systemList = res.data;
      }
    },
    isAddInstution() {
      if (!this.operateSystemInfo.formInfo.product_code) {
        this.$message({
          type: "warning",
          message: "请选择授权产品！",
        });
        return;
      }
      this.InstitutionPage.page_index = 1;
      this.getInstitutionListFn();
      this.operateSystemInfo.isChioseOrgan = true;
    },
    // 操作按钮
    async isShowinfoFn(type, id, code, isopen) {
      const self = this;
      if (type === "add") {
        self.isPacsinfo = true;
        self.isUpdate = false;
        self.operateSystemInfo.title = "新增质控系统";
        self.getImgServiceListFn();
        self.operateSystemInfo = self.$options.data().operateSystemInfo;
        // 将之前选择的机构清空

        self.$nextTick(() => {
          self.$refs.info.choosedInstituteArr = [];
          self.$refs.info.$refs.qualityInstituTable.doLayout();
        });
      } else if (type === "operate") {
        // if (!isopen) {
        //   self.$message({ type: 'error', message: '新增的系统，如需管理，请重新登录!' })
        //   return
        // }
        // if (code) {
        //   sessionStorage.setItem('currentSystemClass', code)
        // }
        // if (id) {
        //   sessionStorage.setItem('lastname', id)
        // }
        // window.sessionStorage.setItem('ChosedSystemName', 'DepartmentSystem') // 菜单name
        // const { href } = self.$router.resolve({ name: 'DepUserList', params: { id: id } })
        // window.open(href, '_blank')
        const href = configUrl.frontEndUrl + "/quality/dashboard?id=" + id;
        window.open(href, "_blank");
      } else if (type == "aboutSystem") {
        var manager = new Mgr();
        manager.getRole().then(function (item) {
          if (item) {
            aboutSystem("quality", item);
          }
        });
      } else {
        await self.$emit("closeAllDrawDetailAlert", "Quality");
        self.isactive = id;
        self.isPacsinfo = true;
        self.isUpdate = true;
        self.isFirstChange = true;
        self.operateSystemInfo.title = "编辑";
        const responce = getQualityCenterDetail({ id: id }); // 详情接口
        self.operateSystemInfo.multipleSelection = [];
        responce.then((res) => {
          if (res.code === 0) {
            self.QualityCenterDetail = res.data;
            self.operateSystemInfo.product_name = res.data.product_name;
            self.operateSystemInfo.module_name = res.data.module_name;
            self.operateSystemInfo.formInfo.product_code =
              res.data.product_code;
            self.operateSystemInfo.formInfo.id = res.data.id;
            self.operateSystemInfo.formInfo.name = res.data.name;
            self.operateSystemInfo.formInfo.admin_phone = res.data.admin_phone;
            self.operateSystemInfo.formInfo.admin_name = res.data.admin_name;
            self.operateSystemInfo.formInfo.type = res.data.type;
            self.operateSystemInfo.formInfo.introduction =
              res.data.introduction;
            self.operateSystemInfo.formInfo.domain = res.data.domain;
            self.operateSystemInfo.multipleSelection = res.data.institutions;
            self.operateSystemInfo.institution_count =
              res.data.institution_count;
            self.operateSystemInfo.isAdminname = true;

            self.operateSystemInfo.formInfo.isIndefinitely =
              res.data.stop_date === "无期限" ? true : false;
            self.operateSystemInfo.formInfo.start_date = res.data.start_date;
            self.operateSystemInfo.formInfo.stop_date =
              res.data.stop_date === "无期限" ? "" : res.data.stop_date;
            self.operateSystemInfo.formInfo.state = res.data.state;
            self.operateSystemInfo.formInfo.reason = res.data.reason;

            self.isChoiceFirst = true;
            if (res.data.providers.length != 0) {
              self.operateSystemInfo.providersObj = res.data.providers[0];
            }
            // 获取已绑定的机构
            self.$refs.info.QualityCenterInstitueParam.quality_center_id = id;
            self.$refs.info.searchInstitutionParam.select_quality_center_id =
              id;
            self.$refs.info.getMyQualityCenterInstitute();
            self.$nextTick(() => {
              self.$refs.info.$refs.qualityInstituTable.doLayout();
            });
          }
        });
      }
    },
    // 选择产品类型
    activeSystemFn(index, code) {
      this.operateSystemInfo.activesystem = index;
      this.operateSystemInfo.formInfo.product_code = code;
    },
    // 手机号姓名匹配
    async getAdminNameFn() {
      var _phone = this.operateSystemInfo.formInfo.admin_phone;
      var phoneReg = /^1[3456789]\d{9}$/;
      if (!phoneReg.test(_phone)) {
        return;
      }
      var url = `/users/lite/${_phone}`;
      var res = await getLoginName(url);
      if (res.code === 0) {
        this.operateSystemInfo.formInfo.admin_name = res.data
          ? res.data.name
          : "";
        this.operateSystemInfo.isAdminname = true;
      } else {
        this.operateSystemInfo.isAdminname = false;
        this.operateSystemInfo.formInfo.admin_name = "";
      }
    },
    handleClose(done) {
      done();
    },
    // 关闭 选择机构
    instclose() {
      this.operateSystemInfo.institutionList.forEach((item) => {
        this.$nextTick(() => {
          this.$refs.info.$refs.institutions.toggleRowSelection(item, false);
        });
      });
      this.operateSystemInfo.isChioseOrgan = false;
    },
    closeFn() {
      var info = {
        type: "cancel",
        refs: this.$refs["info"].$refs,
        formName: "formInfo",
      };
      this.submitForm(info);
    },
    // 获取机构列表
    async getInstitutionListFn() {
      const self = this;
      let filter_system_id = "";
      if (self.operateSystemInfo.title !== "新增PACS系统") {
        filter_system_id = "&filter_system_id=" + self.isactive;
      }
      const _url =
        "/institutions?office_type=2&product_code=" +
        self.operateSystemInfo.formInfo.product_code +
        "&offset=" +
        self.InstitutionPage.page_index +
        "&limit=" +
        this.InstitutionPage.page_size +
        filter_system_id;
      const res = await getInstitutionList(_url);
      self.$refs.info.$refs.institutions.clearSelection();
      if (res.code === 0) {
        res.data.forEach((item) => {
          item.office_ids = [];
          if (item.offices.length === 1) {
            item.office_ids[0] = item.offices[0].id;
          }
        });
        self.operateSystemInfo.institutionList = res.data;
        self.InstitutionPage = res.page;
        if (self.operateSystemInfo.title === "编辑") {
          // 勾上已选中的
          res.data.forEach((itemids) => {
            self.operateSystemInfo.multipleSelection.forEach((item) => {
              if (itemids.id === item.id) {
                self.$nextTick(() => {
                  self.$refs.info.$refs.institutions.toggleRowSelection(
                    itemids,
                    true
                  );
                });
                itemids.office_ids = item.office_ids;
              }
            });
          });
        }
      }
    },
    getRowKeys(row) {
      return row.id;
    },
    // 分页
    pageSizeChangeFn(info) {
      this.InstitutionPage.page_index = info.page;
      this.InstitutionPage.page_size = info.limit;
      this.getInstitutionListFn();
    },
    // 选中某一行
    selectCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === row.id) {
            self.operateSystemInfo.multipleSelection.splice(i, 1);
          }
        });
      }
    },
    // 去掉数组元素 里面对象 id值相同的
    clearCommonId(arr) {
      let obj = {};
      let peon = arr.reduce((cur, next) => {
        obj[next.id] ? "" : (obj[next.id] = true && cur.push(next));
        return cur;
      }, []);
      return peon;
    },
    handleInstituSelectionChange(val) {
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    // 机构 select change事件
    selectInstitionListFn(val) {
      // if (this.InstitutionPage.page_index === 1 && this.isChoiceFirst) {
      //   this.choiseList = [...this.operateSystemInfo.multipleSelection, ...rows]
      // } else {
      //   this.choiseList = rows
      // }
      // this.isChoiceFirst = false
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    // 机构 提交
    ChoiceOrganFn(type) {
      // if (type === 'commit') {
      //   this.operateSystemInfo.multipleSelection = this.choiseList
      // }
      this.instclose();
    },
    CheckOfficeidsFn(val) {
      // console.log(val)
    },
    async addPacsSystemsFn() {
      const self = this;
      const _params = self.operateSystemInfo.formInfo;
      const loading = self.$loading({
        lock: true,
        text: _params.id ? "正在编辑，请稍等..." : "正在新增，请稍等...",
        spinner: "el-icon-loading",
        background: "rgba(255, 255, 255, 0.6)",
      });

      // var _institutionList = []
      // self.operateSystemInfo.multipleSelection.forEach(item => {
      //   var info = {}
      //   info.id = item.id
      //   info.office_ids = item.office_ids
      //   _institutionList.push(info)
      // })
      // _params.institutions = _institutionList

      var res = null;
      var tipmsg = "新增影像质控成功！";
      var param = JSON.parse(JSON.stringify(self.operateSystemInfo.formInfo));
      param.institutions = [];
      if (self.choosedInstituteArr.length != 0) {
        self.choosedInstituteArr.forEach((val) => {
          let obj = {
            id: val.id,
            office_ids: val.office_ids,
          };
          param.institutions.push(obj);
        });
      }
      //param.institutions = self.choosedInstituteArr;
      param.providers = [];
      param.providers.push(self.operateSystemInfo.providersObj);

      // 特殊处理一下期限相关的字段
      param.stop_date = param.isIndefinitely ? null : param.stop_date;
      param.reason = param.state === 10 ? "" : param.reason;
      delete param.isIndefinitely;

      if (_params.id) {
        delete param["product_code"];
        res = await updateImgControlCenter(param);
        tipmsg = "修改影像质控成功！";
      } else {
        res = await addImgControlCenter(param);
      }
      loading.close();
      if (res.code === 0) {
        self.$message({
          type: "success",
          message: tipmsg,
        });
        self.isPacsinfo = false;
        // self.getPascListFn();
        self.$emit("getSystemList");
        self.operateSystemInfo = self.$options.data().operateSystemInfo;
      } else {
        self.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    getSerchName(val) {
      this.operateSystemInfo.serchName = val;
    },
    // 选择机构页面 查询按钮
    async serchListFn() {
      const _url =
        "/institutions?office_type=2&product_code=" +
        this.operateSystemInfo.formInfo.product_code +
        "&offset=1" +
        "&limit=" +
        this.InstitutionPage.page_size +
        "&name=" +
        this.operateSystemInfo.serchName;
      const res = await getInstitutionList(_url);
      if (res.code === 0) {
        this.operateSystemInfo.institutionList = res.data;
      }
    },
    // 获取租户详情
    async getTancyDetail() {
      const res = await getCostomerInfoDetail();
      if (res.code === 0) {
        this.tancyDetail = res.data;
      }
    },
    initFormData() {
      for (let key in this.operateSystemInfo.formInfo) {
        // 对手机号加密
        if (key === "admin_phone") {
          this.addImgControlForm.append(
            key,
            this.$getRsaCode(this.operateSystemInfo.formInfo[key])
          );
        } else {
          if (this.operateSystemInfo.formInfo[key]) {
            this.addImgControlForm.append(
              key,
              this.operateSystemInfo.formInfo[key]
            );
          }
        }
      }
      if (this.choosedInstituteArr.length > 0) {
        for (let i = 0; i < this.choosedInstituteArr.length; i++) {
          //this.addImgControlForm.delete('institutions[' + i + ']') // 目的是防止 append添加重复的
          this.addImgControlForm.set(
            "institutions[" + i + "].id",
            this.choosedInstituteArr[i].id
          );
          this.addImgControlForm.set(
            "institutions[" + i + "].office_ids",
            this.choosedInstituteArr[i].office_ids
          );
        }
      } else {
        this.addImgControlForm.append("institutions", []);
      }
    },
    submitForm(info) {
      if (info.type === "commit") {
        if (!this.operateSystemInfo.formInfo.product_code) {
          this.$message({ type: "error", message: "请选择产品" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.name) {
          this.$message({ type: "error", message: "请输入系统名称" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.admin_phone) {
          this.$message({ type: "error", message: "请输入管理员电话" });
          return;
        }
        var phoneReg = /^1[3456789]\d{9}$/;
        // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
        if (!this.isUpdate || (this.isUpdate && !this.isFirstChange)) {
          if (!phoneReg.test(this.operateSystemInfo.formInfo.admin_phone)) {
            this.$message({
              message: "请输入正确的手机号码!",
              type: "warning",
            });
            return false;
          }
        }
        if (!this.operateSystemInfo.formInfo.admin_name) {
          this.$message({ type: "error", message: "请输入管理员姓名" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.type) {
          this.$message({ type: "error", message: "请选择系统类型" });
          return;
        }

        if (!this.operateSystemInfo.formInfo.start_date) {
          this.$message({ type: "error", message: "请选择使用开始期限" });
          return;
        }
        if (
          !this.operateSystemInfo.formInfo.isIndefinitely &&
          !this.operateSystemInfo.formInfo.stop_date
        ) {
          this.$message({ type: "error", message: "请选择使用结束期限" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.state) {
          this.$message({ type: "error", message: "请选择系统状态" });
          return;
        }
        if (
          this.operateSystemInfo.formInfo.state === -2 &&
          !this.operateSystemInfo.formInfo.reason
        ) {
          this.$message({ type: "error", message: "请输入停用备注" });
          return;
        }

        // var re= /^(?=^.{3,255}$)(http(s)?:\/\/)(www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\d+)*(\/\w+)*\/$/
        // if (this.operateSystemInfo.domain && !re.test(this.portalsInfo.domain)) {
        //   this.$message({ message: '请输入正确的域名！', type: 'error' })
        //   return
        // }

        this.choosedInstituteArr = info.choosedInstituteArr;
        var isChoosedOffice = false;
        // var instituteName = ''
        this.choosedInstituteArr.forEach((val) => {
          if (val.office_ids.length === 0) {
            isChoosedOffice = true;
            // instituteName = val.name
          }
        });
        if (isChoosedOffice) {
          this.$message({ type: "error", message: "请选择科室" });
          return;
        }
        this.addPacsSystemsFn();
      } else {
        this.isPacsinfo = false;
        this.isactive = "";
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      }
    },
  },
};
</script>

<style lang="less" scoped>
.jurisdictionlist {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  .pacsContainer {
    height: calc(100% - 47px);
    padding: 10px 5px;
    overflow: auto;
    position: relative;
  }
}
.list-item {
  position: relative;
  width: calc(25% - 15px);
  margin-right: 15px;
  box-sizing: border-box;
  border: 1px solid #ebeef5;
  box-shadow: 0 1px 5px 0 rgba(26, 26, 26, 0.050980392156862744);
  border-radius: 6px;
  background: #ffffff;
  margin-bottom: 15px;

  .deactivated-box {
    position: absolute;
    top: 65px;
    right: 20px;
    padding: 4px 10px;
    border: 1px solid #f56c6c;
    color: #f56c6c;
    transform: rotate(45deg);
    text-align: center;
    cursor: pointer;

    .deactivated-time {
      font-size: 12px;
    }
  }
  .listItemInfor {
    padding: 18px 14px 14px 18px;
    //border-bottom: 1px solid #ebeef5;
  }
  .active {
    background: rgba(10, 112, 176) !important;
    color: #fff !important;
  }
  .pacs_img {
    width: 52px;
    height: 52px;
    vertical-align: middle;
  }
  .title {
    // max-width: 200px;
    width: 100%;
  }
  .systemNameTitle {
    width: 100%;
    font-size: 20px;
    color: #1f2f3d;
    font-weight: 500;
    position: relative;
    top: -3px;
  }
  .shareHead {
    width: calc(100% - 70px);
    margin-left: 16px;
  }
  .productIdAndType {
    display: flex;
    .productIdAndTypeText {
      display: inline-block;
      line-height: 22px;
    }
    .productName {
      margin-right: 10px;
    }
    .idNumber {
      display: inline-block;
      max-width: 190px;
      padding: 0 5px;
    }
  }
  .item_btn {
    padding: 0 10px;
    height: 30px;
    line-height: 28px;
    text-align: center;
    background: rgba(255, 255, 255, 1);
    border: 1px solid rgba(10, 112, 176, 0.5);
    border-radius: 3px;
    color: #0a70b0;
    cursor: pointer;
  }
  .manageBtn {
    background-color: #0a70b0;
    color: #fff;
  }
  .border_bd {
    border-bottom: 1px dashed #dcdfe6;
  }
  .useInstituteLabel {
    width: 70px;
  }
  .useInstituteNum {
    width: calc(100% - 70px);
  }
  .overOneLine {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .contractedhospital {
    display: flex;
    .contractedLabel {
      font-size: 14px;
      color: #909399;
    }
    .contractedNum {
      font-size: 14px;
      color: #0a70b0;
      i {
        margin-left: 5px;
      }
    }
  }
  .operateBtnCon {
    display: flex;
    height: 40px;
    align-items: center;
    border-top: 1px solid #ebeef5;
    .operateBtnOneBox {
      flex: 1;
      height: 100%;
      display: flex;
      align-items: center;
      cursor: pointer;
    }
    .operateBtnOne {
      width: 100%;
      text-align: center;
      font-size: 14px;
      color: #0a70b0;
      border-right: 1px solid #dcdfe6;
    }
    .operateBtnOneBox:last-of-type {
      .operateBtnOne {
        border-right: none;
      }
    }
    .operateBtnOneBox:hover {
      background: #f2f7ff;
    }
  }
}
.list-item:hover {
  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(10, 112, 176, 0.3);
}
.list-item:hover .title {
  color: #0a70b0;
}
.adminInfor {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.over_ell_3 {
  text-align: justify;
}
.productNameDiv {
  justify-content: left !important;
}
@media screen and (max-width: 1500px) {
  .list-item {
    width: calc(50% - 20px) !important;
  }
  .idNumber {
    max-width: initial !important;
  }
}
</style>
