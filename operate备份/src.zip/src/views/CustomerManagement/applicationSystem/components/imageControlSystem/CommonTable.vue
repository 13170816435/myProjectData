<template>
<!-- 表格： 可通过后台返回控制table显示某列 及自定义宽度 -->
  <div>
    <template v-for="(item, index) in propData">
      <el-table-column
        v-if="item.prop == 'admin_name'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <!-- 急诊标红处理 -->
        <template  slot-scope="scope">
          <span>{{scope.row.admin_name }} <span v-if="scope.row.admin_phone">({{scope.row.admin_phone }})</span></span>
        </template>
      </el-table-column>
      <el-table-column
        v-else-if="item.prop == 'contact_name'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
           <span>{{scope.row.contact_name }} <span v-if="scope.row.contact_phone">({{scope.row.contact_phone}})</span></span>
        </template>
      </el-table-column>
      <el-table-column
        v-else
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
      </el-table-column>
    </template>
  </div>
</template>
<script>
import mixin from '@/utils/mixin/intelligentDiagnosis'
export default {
  name: 'CommonTable',
  props: {
    propData: Array
  },
  mixins: [mixin]
}
</script>
<style lang="less">
</style>
