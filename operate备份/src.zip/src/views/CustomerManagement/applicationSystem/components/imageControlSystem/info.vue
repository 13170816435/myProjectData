<template>
  <div class="userinfo">
    <div class="userinfo-title">
      <span class="userinfo-titleinfo">{{ pacsinfo.title }}</span>
      <span
        @click="closeFn"
        class="close-btn iconfont iconchuangjianshibai"
      ></span>
    </div>
    <el-form
      :model="pacsinfo.formInfo"
      ref="formInfo"
      label-width="120px"
      class="demo-ruleForm"
    >
      <div class="contaner imageControlContainer">
        <div class="contaner-info">
          <el-row class="contaner-info-title">
            <span class="border-left"></span>系统信息
          </el-row>
          <el-row class="mt15 pl10 pr10">
            <el-form-item label="授权产品 ：" v-if="pacsinfo.product_name">
              <div>{{ pacsinfo.product_name }}</div>
            </el-form-item>
            <div class="formItemDiv" v-else>
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>授权产品 ：</span
              >
              <span
                class="system_type"
                :class="{ active: pacsinfo.activesystem === index }"
                v-for="(item, index) in pacsinfo.systemList"
                :key="index"
                @click="activeSystemFn(index, item)"
                >{{ item.name }}</span
              >
            </div>
            <div class="formItemDiv" v-if="pacsinfo.module_name">
              <span class="formItemLabel">功能服务 ：</span>
              <span class="powerService">{{ pacsinfo.module_name }}</span>
            </div>
            <div class="formItemDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>系统名称 ：</span
              >
              <el-input
                v-model="pacsinfo.formInfo.name"
                placeholder=""
                style="width: 480px"
              ></el-input>
            </div>
            <div class="formItemDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>系统管理员 ：</span
              >
              <el-input
                v-model="pacsinfo.formInfo.admin_phone"
                @input="changePhone"
                @blur="getAdminNameFn"
                placeholder="请输入管理员电话"
                style="width: 236px"
              ></el-input>
              <el-input
                v-model="pacsinfo.formInfo.admin_name"
                placeholder="请输入管理员姓名"
                :disabled="pacsinfo.isAdminname"
                class="ml10"
                style="width: 236px"
              ></el-input>
            </div>
            <div class="formItemDiv radioDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>系统类型 ：</span
              >
              <el-radio-group class="fl" v-model="pacsinfo.formInfo.type">
                <el-radio
                  :label="item.value"
                  v-for="(item, index) in baseInfo.quality_center_type"
                  :key="index"
                  >{{ item.name }}</el-radio
                >
                <!-- <el-radio :label="1">省</el-radio>
                <el-radio :label="2">地市</el-radio>
                <el-radio :label="3">区（市）/ 县</el-radio> -->
              </el-radio-group>
              <span
                class="addressVal fl"
                v-if="
                  pacsinfo.formInfo.type === 1 ||
                  pacsinfo.formInfo.type === 2 ||
                  pacsinfo.formInfo.type === 3
                "
                >行政区域：
                <span v-if="pacsinfo.formInfo.type === 1">{{
                  tancyDetail.province
                }}</span>
                <span v-if="pacsinfo.formInfo.type === 2">{{
                  tancyDetail.city
                }}</span>
                <span v-if="pacsinfo.formInfo.type === 3">{{
                  tancyDetail.district
                }}</span>
              </span>
            </div>

            <div class="formItemDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>使用期限 ：</span
              >
              <div style="display: flex; align-items: center">
                <el-date-picker
                  v-model="pacsinfo.formInfo.start_date"
                  type="date"
                  placeholder="选择开始期限"
                  value-format="yyyy-MM-dd"
                >
                </el-date-picker>
                <el-radio-group
                  v-model="pacsinfo.formInfo.isIndefinitely"
                  class="ml20"
                >
                  <el-radio :label="true">无期限</el-radio>
                  <el-radio :label="false">
                    <el-date-picker
                      v-model="pacsinfo.formInfo.stop_date"
                      type="date"
                      :disabled="pacsinfo.formInfo.isIndefinitely"
                      placeholder="选择结束期限"
                      value-format="yyyy-MM-dd"
                    >
                    </el-date-picker>
                  </el-radio>
                </el-radio-group>
              </div>
            </div>
            <div class="formItemDiv radioDiv">
              <span class="formItemLabel"
                ><i class="iconfont iconbitian mustIcon"></i>系统状态 ：</span
              >
              <div style="display: flex; align-items: center">
                <el-radio-group v-model="pacsinfo.formInfo.state">
                  <el-radio :label="10">启用</el-radio>
                  <el-radio :label="-2">停用</el-radio>
                </el-radio-group>
                <el-input
                  v-if="pacsinfo.formInfo.state === -2"
                  v-model="pacsinfo.formInfo.reason"
                  class="ml10"
                  placeholder="备注"
                  style="width: 180px"
                />
              </div>
            </div>

            <el-form-item class="clear" label="系统简介 ：">
              <el-input
                class="systemIntro"
                resize="none"
                type="textarea"
                v-model="pacsinfo.formInfo.introduction"
                placeholder=""
                style="width: 580px"
              ></el-input>
            </el-form-item>
            <el-form-item class="mt15" label="二级域名 ：">
              <el-input
                v-model="pacsinfo.formInfo.domain"
                class="w_300"
              ></el-input
              ><br />
              <span class="el-upload__tip clr_oarange tl"
                >（二级域名绑定后，可使用该域名访问平台系统，示例：https://www.mtywcloud.com:8080/）</span
              >
            </el-form-item>
            <weChat
              :weChatObj="pacsinfo.providersObj"
              :inputWidth="'236px'"
            ></weChat>
          </el-row>
        </div>
        <div
          class="contaner-info contaner-bottom"
          v-bind:class="{
            activeContainerBottom: pacsinfo.module_name,
            updateContainerBottom: isUpdate,
          }"
        >
          <el-row class="contaner-info-title instituteInfor">
            <el-col :span="12">
              <span class="border-left"></span>使用机构
              <span class="ml5 clr_oarange"
                >({{ choosedInstituteArr.length }}家)</span
              >
            </el-col>
            <el-col :span="12" class="tr clr_0a">
              <span
                @click="removeInstitu"
                class="function-btn bg_f5 clr_ff mr20"
              >
                移除
              </span>
              <span class="function-btn bg_e6 clr_ff" @click="isAddInstution">
                <i class="iconfont iconxinzeng"></i>添加机构
              </span>
            </el-col>
          </el-row>
          <div
            class="allProvince"
            v-bind:class="{
              noTableData: choosedInstituteArr.length == 0,
              hadService: !pacsinfo.module_name,
            }"
          >
            <el-table
              :data="choosedInstituteArr"
              height="100%"
              ref="qualityInstituTable"
              :row-key="myRowkey"
              highlight-current-row
              v-on:selection-change="handleAllInstuSelectionChange"
              header-row-class-name="strong"
            >
              <el-table-column
                type="selection"
                v-bind:reserve-selection="true"
                width="48"
              ></el-table-column>
              <el-table-column
                fixed="left"
                align="center"
                type="index"
                label="序号"
                width="55"
              >
                <!-- <template slot-scope="scope">
                      <span>{{(QualityCenterInstitueParam.offset - 1) * QualityCenterInstitueParam.limit + scope.$index + 1}}</span>
                  </template> -->
              </el-table-column>
              <!-- <common-table :propData="institutePropData" /> -->
              <el-table-column
                prop="name"
                label="机构名称"
                width="200"
              ></el-table-column>
              <el-table-column label="机构管理员" width="220">
                <template slot-scope="scope">
                  {{ scope.row.admin_name }}({{ scope.row.admin_phone }})
                </template>
              </el-table-column>
              <el-table-column label="选择科室">
                <template slot-scope="scope">
                  <el-select
                    v-model="scope.row.office_ids"
                    multiple
                    collapse-tags
                    class="w_180"
                    @change="CheckOfficeidsFn"
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="itemdep in scope.row.offices"
                      :key="itemdep.id"
                      :label="itemdep.name"
                      :value="itemdep.id"
                    >
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <!-- <div class="instituePageOperate">
              <span @click="removeInstitu" class="function-btn bg_f5 clr_ff ml10">
                移除
              </span>
            </div> -->
        </div>
      </div>
      <div class="mt15">
        <el-button
          type="primary"
          size="medium"
          @click="submitForm('formInfo', 'commit')"
          >提交</el-button
        >
        <el-button size="medium" @click="submitForm('formInfo')"
          >取消</el-button
        >
      </div>
    </el-form>
    <el-dialog
      class="addInstituAlert"
      append-to-body
      title="添加质控机构"
      :visible.sync="showAddInstituAlert"
      width="940px"
      height="660px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <div class="addInstituCon">
        <div class="searchQuery clear">
          <div class="searchQueryItem fl mr15">
            <span class="queryLabel fl">医院名称：</span>
            <el-input
              v-model="searchInstitutionParam.name"
              v-on:keyup.enter.native="getMyInstitutionsList()"
              class="fl input_200"
            ></el-input>
          </div>
          <div class="searchQueryItem fl mr15">
            <span class="queryLabel fl">机构性质：</span>
            <el-select
              v-model="searchInstitutionParam.nature_code"
              placeholder="请选择"
              @change="getMyInstitutionsList"
              class="ele-select_32 width_150_select fl"
              style="width: 150px"
            >
              <el-option value="">请选择</el-option>
              <el-option
                v-for="item in HospitalKind"
                :key="item.dic_code"
                :label="item.dic_name"
                :value="item.dic_code"
              ></el-option>
            </el-select>
          </div>
          <div class="searchQueryItem fl mr15">
            <span class="queryLabel fl">机构等级：</span>
            <el-select
              v-model="searchInstitutionParam.level_code"
              placeholder="请选择"
              @change="getMyInstitutionsList"
              class="ele-select_32 width_150_select fl"
              style="width: 150px"
            >
              <el-option value="">请选择</el-option>
              <el-option
                v-for="item in HospitalLevel"
                :key="item.dic_code"
                :label="item.dic_name"
                :value="item.dic_code"
              ></el-option>
            </el-select>
          </div>
          <div class="fl operateBtnDiv">
            <el-button
              type="primary"
              size="small"
              @click="getMyInstitutionsList"
              >查询</el-button
            >
            <el-button size="small" plain @click="resetSearch">重置</el-button>
          </div>
        </div>
        <div
          class="allMyInstitu"
          v-bind:class="{ noTableData: allInstituArr.length == 0 }"
        >
          <el-table
            :data="allInstituArr"
            border
            stripe
            height="100%"
            ref="allInstitutionTable"
            highlight-current-row
            :row-key="instituteRow"
            @select="selectCurRow"
            v-on:selection-change="handleInstituSelectionChange"
            header-row-class-name="strong"
          >
            <el-table-column
              type="selection"
              v-bind:reserve-selection="true"
              width="48"
            ></el-table-column>
            <el-table-column
              fixed="left"
              align="center"
              type="index"
              label="序号"
              width="55"
            >
              <template slot-scope="scope">
                <span>{{
                  (searchInstitutionParam.offset - 1) *
                    searchInstitutionParam.limit +
                  scope.$index +
                  1
                }}</span>
              </template>
            </el-table-column>
            <!-- <common-table :propData="addInstutitePropData" /> -->
            <el-table-column
              prop="name"
              label="机构名称"
              width="160"
            ></el-table-column>
            <el-table-column
              prop="level"
              label="机构等级"
              width="85"
            ></el-table-column>
            <el-table-column
              prop="nature"
              label="机构性质"
              width="100"
            ></el-table-column>
            <el-table-column label="机构管理员" width="220">
              <template slot-scope="scope">
                {{ scope.row.admin_name }}({{ scope.row.admin_phone }})
              </template>
            </el-table-column>
            <el-table-column label="选择科室">
              <template slot-scope="scope">
                <el-select
                  v-model="scope.row.office_ids"
                  multiple
                  collapse-tags
                  class="w_180"
                  @change="CheckOfficeidsFn"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="itemdep in scope.row.offices"
                    :key="itemdep.id"
                    :label="itemdep.name"
                    :value="itemdep.id"
                  >
                  </el-option>
                </el-select>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="blockPage">
          <!-- <div class="pageOperate">
              <el-checkbox v-model="checked">全选</el-checkbox>
            </div> -->
          <pagination-tool
            :total="allInstitutePage"
            :page.sync="searchInstitutionParam.offset"
            :limit.sync="searchInstitutionParam.limit"
            @pagination="getMyInstitutionsList"
          />
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <!-- <span class="showChoosed fl ml20">已选：<span class="hadChooseNum">8</span>家</span> -->
        <el-button size="small" plain @click="showAddInstituAlert = false"
          >取 消</el-button
        >
        <el-button size="small" type="primary" @click="sureAddInstitu"
          >确 定</el-button
        >
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { mapGetters } from "vuex";
import weChat from "@/components/common/weChat";
import CommonTable from "./CommonTable";
import PaginationTool from "@/components/common/PaginationTool";
import {
  getQualityCenterInstitute,
  delQualityInstitu,
  getInstitutionsList,
} from "@/api/platform_costomer/imgControlCenter";
import { getDistinfoByType } from "@/api/commonHttp";
export default {
  components: {
    CommonTable,
    PaginationTool,
    weChat,
  },
  props: {
    pacsinfo: Object,
    serviceList: Array,
    pageInfo: Object,
    tancyDetail: Object,
    getDetailFinished: Boolean,
    isUpdate: Boolean,
  },
  computed: {
    ...mapGetters({
      // 获取store查询枚举条件
      baseInfo: "enumerations",
    }),
  },
  data() {
    return {
      pageLayout: "total, prev, pager, next, jumper",
      totalInstitutePage: 0,
      allInstitutePage: 0,
      choosedInstituteArr: [],
      removeInstituIds: [],
      QualityCenterInstitueParam: {
        quality_center_id: "",
      },
      imgControType: 0,
      institutePropData: [
        { prop: "name", label: "机构名称", width: 220 },
        { prop: "admin_name", label: "机构管理员" },
      ],
      addInstutitePropData: [
        { prop: "name", label: "机构名称", width: 160 },
        { prop: "level", label: "机构等级", width: 85 },
        { prop: "nature", label: "机构性质", width: 100 },
        { prop: "admin_name", label: "机构管理员" },
      ],
      moduleServiceName: "",
      showAddInstituAlert: false,
      allInstituArr: [],
      searchInstitutionParam: {
        name: "",
        level_code: "",
        product_code: "",
        // city_code: '',
        // district_code: '',
        nature_code: "",
        select_quality_center_id: this.pacsinfo.formInfo.id,
        office_type: 2,
        offset: 1,
        limit: 20,
        sorts: [],
      },
      HospitalLevel: [],
      HospitalKind: [],
      addQualityInstituParam: {
        ids: [],
        quality_center_id: "",
      },
    };
  },
  watch: {
    getDetailFinished: function (val) {
      if (val) {
        this.changeService(this.pacsinfo.formInfo.service_codes);
        this.getMyQualityCenterInstitute();
      }
    },
  },
  methods: {
    myRowkey(row) {
      return row.id;
    },
    handleAllInstuSelectionChange(val) {
      const self = this;
      self.removeInstituIds = [];
      val.forEach((item) => {
        self.removeInstituIds.push(item.id);
      });
    },
    async beganRemoveInstitu() {
      const self = this;
      self.removeInstituIds.forEach((val, i) => {
        self.choosedInstituteArr.forEach((one, j) => {
          if (val === one.id) {
            self.$nextTick(() => {
              self.$refs.qualityInstituTable.toggleRowSelection(one, false);
            });
            // self.$refs.allInstitutionTable.toggleRowSelection(one, false)
            self.choosedInstituteArr.splice(j, 1);
          }
        });
      });
    },
    removeInstitu() {
      const self = this;
      if (self.removeInstituIds.length === 0 && !this.checkAllInstitution) {
        this.$message({ message: "请至少选择一个机构", type: "error" });
        return false;
      }
      self
        .$confirm("确定要移除该质控机构", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          customClass: "warningAlert",
          type: "warning",
        })
        .then(() => {
          self.beganRemoveInstitu();
        })
        .catch(() => {
          // self.$message({
          //   type: 'info',
          //   message: '已取消删除'
          // })
        });
    },

    // 获取质控机构
    async getMyQualityCenterInstitute() {
      const res = await getQualityCenterInstitute(
        this.QualityCenterInstitueParam
      );
      if (res.code === 0) {
        this.choosedInstituteArr = res.data;
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    async getMyInstitutionsList() {
      const self = this;
      if (self.pacsinfo.formInfo.product_code) {
        self.searchInstitutionParam.product_code =
          self.pacsinfo.formInfo.product_code;
      }
      self.allInstituArr = [];
      const res = await getInstitutionsList(self.searchInstitutionParam);
      if (res.code === 0) {
        res.data.forEach((item) => {
          item.office_ids = [];
          if (item.offices.length === 1) {
            item.office_ids[0] = item.offices[0].id;
          }
        });
        self.allInstituArr = res.data;
        self.allInstitutePage = res.page.total_count;
        self.$nextTick(function () {
          self.$refs.allInstitutionTable.clearSelection();
          // 勾上已选中的
          self.allInstituArr.forEach((itemids) => {
            if (self.choosedInstituteArr.length !== 0) {
              self.choosedInstituteArr.forEach((item) => {
                if (itemids.id === item.id) {
                  self.$nextTick(() => {
                    self.$refs.allInstitutionTable.toggleRowSelection(
                      itemids,
                      true
                    );
                  });
                  itemids.office_ids = item.office_ids;
                }
              });
            }
          });
        });
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // 获取字典列表
    async getDistinfoFn() {
      var _parmas =
        "InstitutionType,InstitutionBusinessNature,HospitalLevel,HospitalKind";
      var _url = `/dict/${_parmas}`;
      const res = await getDistinfoByType(_url);
      if (res.code !== 0 || res.data.length === 0) {
        return;
      }
      var iL = [];
      var iK = [];
      res.data.forEach((item) => {
        if (item.lookup_key === "HospitalLevel") {
          iL.push(item);
        }
        if (item.lookup_key === "HospitalKind") {
          iK.push(item);
        }
      });
      this.HospitalLevel = iL;
      this.HospitalKind = iK;
    },
    resetSearch() {
      this.searchInstitutionParam = {
        name: "",
        level_code: "",
        // city_code: '',
        // district_code: '',
        nature_code: "",
        office_type: 2,
        offset: 1,
        limit: 20,
        sorts: [],
      };
      this.searchInstitutionParam.select_quality_center_id =
        this.pacsinfo.formInfo.id;
      this.getMyInstitutionsList();
    },
    instituteRow(row) {
      return row.id;
    },
    // 选中某一行
    selectCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.choosedInstituteArr.forEach((item, i) => {
          if (item.id === row.id) {
            self.choosedInstituteArr.splice(i, 1);
          }
        });
      }
    },
    // 去掉重复的id
    clearCommonId(arr) {
      let obj = {};
      let peon = arr.reduce((cur, next) => {
        obj[next.id] ? "" : (obj[next.id] = true && cur.push(next));
        return cur;
      }, []);
      return peon;
    },
    handleInstituSelectionChange(val) {
      const self = this;
      //self.choosedInstituteArr = []  // 这里不能清空  清空后就不能回显了
      val.forEach((item) => {
        self.choosedInstituteArr.push(item);
      });
      self.choosedInstituteArr = self.clearCommonId(self.choosedInstituteArr);
    },
    // 确定添加质控机构
    async sureAddInstitu() {
      const self = this;
      self.showAddInstituAlert = false;
      self.checkAllInstitution = false;
      self.$nextTick(() => {
        self.$refs.qualityInstituTable.clearSelection();
      });
      // this.addQualityInstituParam.quality_center_id = this.detail.id
      // const res = await addQualityInstitute(this.addQualityInstituParam)
      // if (res.code === 0) {
      //   this.showAddInstituAlert = false
      //   this.checkAllInstitution = false
      //   this.$message({ message: '添加质控机构成功', type: 'success' })
      //   this.getMyQualityCenterInstitute()
      //   // 如果只有区质控中心
      //   if (this.detail.type === 3) {
      //     this.$emit('refreshQualityCenter')
      //   }
      // } else {
      //   this.$message({ message: `${res.msg}`, type: 'error' })
      // }
    },

    closeFn() {
      this.$emit("closeFn");
    },
    changePhone() {
      this.$emit("changePhone");
    },
    submitForm(formName, type) {
      var info = {
        formName: formName,
        refs: this.$refs,
        type: type,
        choosedInstituteArr: this.choosedInstituteArr,
      };
      this.$emit("submitForm", info);
    },
    activeSystemFn(index, item) {
      //this.moduleServiceName = item.module_name
      this.pacsinfo.module_name = item.module_name;
      this.searchInstitutionParam.product_code = item.code;
      this.pacsinfo.formInfo.product_code = item.code;
      this.$emit("activeSystemFn", index, item.code);
    },
    changeService(arr) {
      const self = this;
      self.serviceList.forEach((val, i) => {
        // 1、2、4、8 分别是 影像共享、数字影像、索引管理、异地备份
        //没有选择任何一个服务 或者有选择服务但是 没有选择索引管理 和 影像共享
        if (
          arr.length === 0 ||
          (arr.indexOf("1") === -1 &&
            arr.indexOf("4") === -1 &&
            arr.indexOf("8") === -1)
        ) {
          self.$set(self.serviceList[i], "isCanChoose", false);
        }
        if (val.code === "4") {
          // 有索引管理
          if (arr.indexOf("1") !== -1 || arr.indexOf("8") !== -1) {
            self.$set(self.serviceList[i], "isCanChoose", true);
          }
        } else if (val.code === "1" || val.code === "8") {
          // 有影像共享服务
          if (arr.indexOf("4") !== -1) {
            self.$set(self.serviceList[i], "isCanChoose", true);
          }
        }
      });
      // if (arr.indexOf('1')) {

      // }
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    // selectCurRow (selection, row) {
    //   this.$emit('dealselectCurRow', selection, row)
    // },
    handleSelectionChange(val) {
      this.$emit("selectInstitionListFn", val);
    },
    ChoiceOrganFn(type) {
      this.$emit("ChoiceOrganFn", type);
    },
    getAdminNameFn(val) {
      this.$emit("getAdminNameFn", val);
    },
    getSerchName(val) {
      this.$emit("getSerchName", val);
    },
    serchListFn() {
      this.$emit("serchListFn");
    },
    isAddInstution() {
      // this.$emit('isAddInstution')
      if (!this.pacsinfo.formInfo.product_code) {
        this.$message({
          type: "warning",
          message: "请选择授权产品！",
        });
        return;
      }
      const self = this;
      self.showAddInstituAlert = true;
      self.getDistinfoFn();
      // self.$nextTick(() => {
      //   self.$refs.allInstitutionTable.clearSelection()
      // })
      self.getMyInstitutionsList();
      // self.getMyChoosedInstitute()
    },
    pageSizeChangeFn(info) {
      this.$emit("pageSizeChangeFn", info);
    },
    CheckOfficeidsFn(val) {
      this.$emit("CheckOfficeidsFn", val);
    },
    getRowKeys(val) {
      // this.$emit('getRowKeys', val)
      return val.id;
    },
  },
};
</script>
<style lang="less" scoped>
.userinfo {
  width: 800px;
  padding: 0px 25px;
  ::v-deep .el-select,
  .el-select__tags {
    display: block !important;
    width: 350px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .userinfo-title {
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    .userinfo-titleinfo {
      font-size: 18px;
      color: #1f2f3d;
      font-weight: bold;
    }
    .close-btn {
      position: absolute;
      right: 0px;
      top: 0px;
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .imageControlContainer {
    overflow: auto;
  }
  .contaner {
    border: 1px solid #dcdfe6;
    height: calc(100vh - 118px);
    display: flex;
    flex-direction: column;
    .contaner-info {
      // border-bottom: 1px dashed #dcdfe6;
      padding-bottom: 0px;
      .openModule {
        height: 36px;
        line-height: 36px;
        padding: 0 15px;
        border-radius: 3px;
        border: 1px solid #dcdfe6;
        margin-right: 10px;
        color: #0a70b0;
        cursor: pointer;
        margin-bottom: 5px;
        ::v-deep .el-checkbox__label {
          padding-left: 0px;
        }
      }
      .openModule.el-checkbox.is-bordered.is-checked {
        background: url("../../../../../assets/images/common/checkboxBg.png")
          right bottom no-repeat;
      }
      .openModule {
        ::v-deep .el-checkbox__inner {
          display: none;
        }
      }
      .openModule:hover {
        background: rgba(10, 112, 176, 0.6);
        color: #fff;
      }
      .instituteInfor {
        border-top: 1px dashed #dcdfe6;
      }
      .contaner-info-title {
        height: 40px;
        line-height: 40px;
        background: rgba(250, 250, 253, 1);
        color: #1f2f3d;
        padding: 0px 10px;
        .border-left {
          display: inline-block;
          width: 3px;
          height: 14px;
          background: rgba(9, 113, 176, 1);
          margin-right: 7px;
          vertical-align: middle;
          position: relative;
          top: -1.5px;
        }
      }
      .el-upload__tip {
        font-size: 13px;
      }
      .system_type {
        display: inline-block;
        padding: 0px 20px;
        height: 36px;
        line-height: 34px;
        border: 1px solid #dcdfe6;
        border-radius: 18px;
        color: #0a70b0;
        cursor: pointer;
        margin: 0px 5px;
      }
      .system_type:hover {
        border-color: #0a70b0;
      }
      .active {
        background: #0a70b0;
        color: #fff;
        border-color: #0a70b0;
      }
      .contaner-info-list {
        padding: 5px 20px 0 20px;
        overflow: auto;
      }
      .contaner-info-list-item {
        display: flex;
        min-height: 45px;
        align-items: center;
        border-bottom: 1px solid #e4e7ed;
        .width_60 {
          width: 60px;
        }
        .width_300 {
          width: 300px;
        }
        .icon-btn {
          display: inline-block;
          width: 24px;
          height: 24px;
          color: #fff;
          line-height: 24px;
          text-align: center;
          padding: 0px;
          cursor: pointer;
          border-radius: 3px;
          margin-right: 8px;
        }
        .depspan {
          display: inline-block;
          padding: 0px 3px;
          color: #333;
        }
      }
      .authorize-img {
        width: 48px;
        height: 48px;
        vertical-align: middle;
      }
      .clr_88 {
        color: #888888;
      }
    }
    .contaner-bottom {
      // height: calc(100% - 489px);
      padding-bottom: 0px !important;
      flex: 1;
      height: 0;
      display: flex;
      flex-direction: column;
      .contaner-info-list {
        height: calc(100% - 40px);
      }
    }
    .activeContainerBottom {
      height: calc(100% - 482px);
    }
    .updateContainerBottom {
      // height: calc(100% - 476px);
    }
  }
  ::v-deep .formItemDiv {
    margin-bottom: 15px;
    .formItemLabel {
      float: left;
      width: 120px;
      color: #303133;
      font-size: 14px;
      line-height: 30px;
      text-align: right;
      padding-right: 12px;
    }
    .powerService {
      line-height: 30px;
    }
    .el-radio {
      height: 30px;
      line-height: 30px;
    }
  }
  .operate-btn {
    width: 84px;
    height: 36px;
    line-height: 36px;
    border-radius: 3px;
    padding: 0px;
    border: none;
    border: 1px solid #dcdfe6;
  }
  .bg_e6 {
    background: #e6a23c;
  }
  .bg_f5 {
    background: #f56c6c;
  }
  .bg_0c {
    background: #0c83cd;
  }
  .bg_00 {
    background: #00ad78;
  }
  .w_300 {
    width: 300px;
  }
  .w_180 {
    width: 180px;
  }
}
.systemIntro {
  height: 100px;
  ::v-deep .el-textarea__inner {
    height: 100px;
  }
}
::v-deep .allProvince {
  height: calc(100% - 41px) !important;
  // min-height: 320px !important;
  .el-table::before {
    display: none;
  }
  .el-table__fixed::before {
    display: none;
  }
  .el-table__body-wrapper {
    height: calc(100% - 40px) !important;
    overflow: auto;
  }
  .el-table-column--selection .cell {
    padding-left: 10px;
  }
}
.hadService {
  height: calc(100% - 40px) !important;
}
// 添加质控机构弹窗样式
.addInstituCon {
  padding: 10px 20px;
  padding-bottom: 0px;
  .searchQueryItem {
    margin-bottom: 10px;
    .queryLabel {
      height: 36px;
      line-height: 36px;
      font-size: 15px;
      color: #303133;
    }
    .width_240_select {
      // width:340px!important;
      height: 36px;
      ::v-deep .el-input__inner {
        height: 36px;
      }
    }
    .input_200 {
      width: 200px;
      height: 36px;
      ::v-deep .el-input__inner {
        height: 36px;
      }
    }
  }
  ::v-deep .el-table__body-wrapper {
    min-height: 300px;
    max-height: 350px;
    overflow: auto;
  }
}
.hadChooseNum {
  font-size: 15px;
  color: #303133;
  font-weight: bold;
  padding-right: 3px;
}
.instituePageOperate {
  margin-top: 10px;
  .el-checkbox__label {
    padding-left: 5px;
  }
}
.pd8 {
  padding: 0 8px;
}
.iconxinzeng {
  padding-right: 3px;
}
.onlyInstituLabel {
  height: 30px;
  float: left;
  line-height: 30px;
  color: #0a70b0;
  font-weight: bold;
  font-size: 15px;
}
::v-deep .delTip {
  font-size: 15px !important;
  color: #ef8900 !important;
}
::v-deep .el-table__fixed {
  height: 100% !important;
}
.centerAdmin {
  width: 50%;
  max-width: 300px;
}
.operateBtnDiv {
  margin-top: 2px;
}
.blockPage {
  position: relative;
}
.radioDiv {
  min-height: 30px;
}
.addressVal {
  font-size: 15px;
  color: #999;
  // display: inline-block;
  line-height: 28px;
  padding-left: 100px;
}
</style>
