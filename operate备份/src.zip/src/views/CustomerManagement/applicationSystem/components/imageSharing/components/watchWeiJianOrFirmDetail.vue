<template>
   <div class="detailCon">
      <div class="titleDiv">
        <span class="titleIcon"></span>
        <span class="titleName">基本信息</span>
      </div>
      <div class="detailInfor" v-if="type == 'weiJian'">
         <div class="itemInfor"><span class="itemLabel">卫建名称：</span><span class="itemValue">{{weiJianOrFirmDetailObj.name}}</span></div>
         <div class="itemInfor"><span class="itemLabel">卫建简称：</span><span class="itemValue">{{weiJianOrFirmDetailObj.abbreviation}}</span></div>
         <div class="itemInfor"><span class="itemLabel">卫建代码：</span><span class="itemValue">{{weiJianOrFirmDetailObj.code}}</span></div>
         <div class="itemInfor"><span class="itemLabel">卫建区域：</span><span class="itemValue">{{weiJianOrFirmDetailObj.province}}/{{weiJianOrFirmDetailObj.city}}/{{weiJianOrFirmDetailObj.district}}</span></div>
         <div class="itemInfor"><span class="itemLabel">联<span class="addPadding">系</span>人：</span><span class="itemValue">{{weiJianOrFirmDetailObj.admin_name}}</span></div>
         <div class="itemInfor"><span class="itemLabel">联系电话：</span><span class="itemValue">{{weiJianOrFirmDetailObj.admin_phone}}</span></div>
         <div class="itemInfor remarkInfor"><span class="itemLabel">备注信息：</span><span class="itemValue" :title="weiJianOrFirmDetailObj.remark"  v-html="$replaceRN(weiJianOrFirmDetailObj.remark)"></span></div>
      </div>
      <div class="detailInfor" v-else>
         <div class="itemInfor"><span class="itemLabel">厂商名称：</span><span class="itemValue">{{weiJianOrFirmDetailObj.name}}</span></div>
         <div class="itemInfor"><span class="itemLabel">厂商简称：</span><span class="itemValue">{{weiJianOrFirmDetailObj.abbreviation}}</span></div>
         <div class="itemInfor"><span class="itemLabel">厂商代码：</span><span class="itemValue">{{weiJianOrFirmDetailObj.code}}</span></div>
         <div class="itemInfor"><span class="itemLabel">厂商类型：</span><span class="itemValue">{{weiJianOrFirmDetailObj.categories | showCategyName}}</span></div>
         <div class="itemInfor"><span class="itemLabel">联<span class="addPadding">系</span>人：</span><span class="itemValue">{{weiJianOrFirmDetailObj.admin_name}}</span></div>
         <div class="itemInfor"><span class="itemLabel">联系电话：</span><span class="itemValue">{{weiJianOrFirmDetailObj.admin_phone}}</span></div>
         <div class="itemInfor"><span class="itemLabel">通讯地址：</span><span class="itemValue" :title="weiJianOrFirmDetailObj.address">{{weiJianOrFirmDetailObj.address}}</span></div>
         <div class="itemInfor firmRemarkInfor"><span class="itemLabel">备注信息：</span><span class="itemValue" :title="weiJianOrFirmDetailObj.remark" v-html="$replaceRN(weiJianOrFirmDetailObj.remark)"></span></div>
      </div>
      <div class="titleDiv">
        <span class="titleIcon"></span>
        <span class="titleName">管理机构</span>
      </div>
      <div class="flex_row searchInstituteQuery mb10">
        <span class="queryLabel">机构名称：</span>
        <el-input
            class="doctorNameInput"
            v-model="searchInstitutionParam.contains_name"
            v-on:keyup.enter.native="beganGetUserList"
            placeholder="请输入机构名称"
            style="width:200px;"
          ></el-input>
          <el-button type="primary" size="small" class="ml10" @click="getCurFactoryInstitution">查询</el-button>
          <el-button size="small" plain @click="resetSearchDataFn">重置</el-button>
      </div>
      <div class="tableDiv" :class="{'noTableData':instituteList.length===0}">
         <el-table
            ref="tableList"
            border
            :data="instituteList"
            :height="tableHeight"
            :header-cell-style="{background: '#f5f5f5',color: '#1E1D22'}"
            tooltip-effect="dark"
            >
            <el-table-column type="index" label="序号" width="50" fixed="left"></el-table-column>
            <el-table-column
             prop="is_disable"
            label="管理状态"
            :width="100"
            fixed="left"
          >
            <template slot-scope="scope">
              <el-switch
                @change="beganUpdateInstitutionState($event, scope.row.id, scope.row.name)"
                class="instituteSwitchStyle"
                active-color="#409EFF"
                inactive-color="#F56C6C"
                active-text="启用"
                inactive-text="禁用"
                :active-value="1"
                :inactive-value="0"
                v-model="scope.row.is_disable"
              ></el-switch>
            </template>
            </el-table-column>
            <common-table :propData="institutePropData"></common-table>
        </el-table>
      </div>
      <!-- <div class="blockPage">
        <pagination-tool :total="totalInstitute" :page.sync="searchInstitutionParam.offset" :limit.sync="searchInstitutionParam.limit" @pagination="getCurFactoryInstitution"/>
      </div> -->
   </div>
</template>
<script>
import CommonTable from './CommonTable'
import PaginationTool from '@/components/common/PaginationTool'
import { getFirmOrWeiJianDetail, getAllFactoryInstitution, updateFactoryInstitutionState } from '@/api/platform_costomer/institution'
export default {
  components: {
    CommonTable,
    PaginationTool
  },
  props: {
    type:String,
  },
  data () {
    return {
      tableHeight: '100%',
      totalInstitute: 0,
      instituteList: [],
      institutePropData: [
        { prop: 'name', label: '机构名称', width: 200 },
        { prop: 'regional_nature', label: '行政级别', width: 100 },
        { prop: 'nature', label: '机构类别', width: 100 },
        { prop: 'region', label: '所属区域' },
      ],
      weiJianOrFirmDetailObj: {},
      searchInstitutionParam: {
        contains_name: '',
        factory_id: '',
        institution_ids: [],
        business_id: '',
        is_show_disable: true,
      },
      disable_institution_ids: [],
    }
  },
  methods: {
    resetSearchDataFn () {
      this.searchInstitutionParam.contains_name = ''
      this.getCurFactoryInstitution()
    },
    async getCurFirmOrWeiJianDetail (id) {
      const res = await getFirmOrWeiJianDetail({id: id})
      if (res.code === 0) {
        this.weiJianOrFirmDetailObj = res.data
      } else {
        this.$message({ type: 'error', message: res.msg })
      }
    },
    // 禁用或启用机构的状态
    async beganUpdateInstitutionState (state, id, name) {
      const _parmas = {
        institution_id: id,
        disable: state == 1 ? false : true,
        business_type: "idcas",
        business_id: this.searchInstitutionParam.business_id,
        factory_id: this.weiJianOrFirmDetailObj.id
      };
      let operateUserTip = "";
      if (state == 1) {
        operateUserTip = `${name}已启用`;
        //this.dealUserStatus(_parmas, this.operateUserTip, state);
      } else {
         operateUserTip = `${name}已禁用`;
      }

      const res = await updateFactoryInstitutionState(_parmas)
      if (res.code === 0) {
        this.$message.success(operateUserTip);
      } else {
        this.$message({ type: 'error', message: res.msg })
      }
    },
    // 获取厂商或卫建 所关联的机构
    async getCurFactoryInstitution () {
      const self = this
      self.instituteList = []

      const res = await getAllFactoryInstitution(this.searchInstitutionParam)
      if (res.code === 0) {
        const result = res.data
        if (result.length != 0) {
          result.forEach((one) => {
            if (one.is_disable) {
              one.is_disable = 0
            } else {
              one.is_disable = 1
            }
            self.instituteList.push(one)
          })
        }
        //this.totalInstitute = res.page.total_count
      } else {
        self.$message({ type: 'error', message: res.msg })
      }
    }
  },
  mounted () {

  },
  filters: {
    showCategyName (arr) {
      if (arr&&arr.length == 2) {
        return '注册厂商、调阅厂商'
      } else if (arr&&arr.length == 1) {
        if (arr&&arr[0] == 1) {
          return '注册厂商'
        } else {
          return '调阅厂商'
        }
      } else {
        return ''
      }
    }
  }
}
</script>
<style>
.instituteSwitchStyle .el-switch__label {
  position: absolute;
  display: none;
  color: #fff;
}
.instituteSwitchStyle .el-switch__label--left {
  z-index: 9;
  left: 19px;
}
.instituteSwitchStyle .el-switch__label--right {
  z-index: 9;
  left: -6px;
}
.instituteSwitchStyle .el-switch__label.is-active {
  display: block;
}
.instituteSwitchStyle.el-switch .el-switch__core,
.el-switch .el-switch__label {
  width: 50px !important;
}
.el-switch__label * {
  font-size: 12px !important;
}
</style>
<style lang="less" scoped>
.detailCon{
  padding: 0px 20px;
  padding-bottom: 15px;
  .titleDiv {
    display: flex;
    height: 42px;
    align-items: center;
    .titleIcon {
      width: 3px;
      height: 14px;
      background: #0a70b0;
      margin-right: 10px;
    }
    .titleName {
      font-size: 14px;
      color: #303133;
      font-weight: 600;
    }
  }
  .detailInfor{
    display: flex;
    flex-flow: wrap;
    .itemInfor{
      width: 33.33%;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
      .itemLabel{
        font-size:15px;
        color: #888888;
        line-height: 32px;
      }
      .itemValue{
        font-size:15px;
        color: #303133;
        line-height: 32px;
      }
      .addPadding{
        padding:0 8px;
      }
    }
    .remarkInfor{
      width:100%;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
    }
    .firmRemarkInfor{
      width:66.67%;  
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;  
    }
  }
  ::v-deep .tableDiv{
    height: 400px;
    .el-table{
      height:100%;
    }
    .el-table__body-wrapper{
      height:calc(100% - 40px)!important;
      overflow-y: auto;
    }
    .el-table__fixed-body-wrapper{
      height:calc(100% - 42px)!important;
    }
  }
}
 .blockPage {
  border: 1px solid #EBEEF5;
  border-top: none;
}
.searchInstituteQuery{
  .queryLabel{
    font-size:15px;
    color:#303133;
    line-height: 32px;
  }
}
</style>