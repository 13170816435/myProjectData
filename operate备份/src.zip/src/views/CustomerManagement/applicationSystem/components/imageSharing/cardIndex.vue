<template>
  <div class="jurisdictionlist">
    <div class="oneSystemItem" v-if="oneSystem">
      <div class="listItemInfor">
        <div class="flex_row">
          <img
            class="pacs_img"
            :src="
              oneSystem.product_code == 'ImageCriminal'
                ? CRI
                : oneSystem.product_code == 'RemoteBackup'
                ? YXZX
                : oneSystem.product_code == 'ImageSupervision'
                ? YXZSY
                : YXYGD
            "
          />
          <div class="shareHead">
            <div
              class="systemNameTitle overOneLine"
              v-bind:title="oneSystem.name"
            >
              {{ oneSystem.name }}
            </div>
            <div class="productIdAndType">
              <span
                class="productIdAndTypeText productName"
                :title="oneSystem.product_name"
                >{{ oneSystem.product_name }}</span
              ><span
                class="productIdAndTypeText idNumber overOneLine"
                :title="'系统ID：' + oneSystem.id"
                >{{ oneSystem.id }}</span
              >
            </div>
          </div>
        </div>
        <div
          class="clr_666 mt10 f14"
          v-if="oneSystem.product_code == 'ImageCriminal'"
        >
          <span class="clr_999">调阅来源：</span
          ><span class="clr_303">{{ oneSystem.access_source_name }}</span>
        </div>
        <div class="clr_666 mt10 f14" v-else>
          <div class="mt5 overOneLine">
            <span class="clr_999">开通服务：</span>
            <span class="clr_303">{{ oneSystem.function_service_names }}</span>
          </div>
        </div>
        <div class="flex_row mt10 f14">
          <div
            class="tl adminInfor"
            v-bind:title="'管理人员：' + oneSystem.admin_name"
          >
            <span class="clr_999">管理人员：</span>
            <span class="clr_303"
              >{{ oneSystem.admin_name }}({{ oneSystem.admin_phone }})</span
            >
          </div>
        </div>
        <div
          class="flex_row mt10 f14"
          v-if="oneSystem.product_code == 'ImageCriminal'"
        >
          <div class="tl">
            <div class="clr_999">
              调阅机构：<span class="clr_303">{{
                oneSystem.access_institution
              }}</span>
            </div>
          </div>
        </div>
        <div class="mt10" v-else>
          <div class="flex_row tl f14">
            <div class="useInstituteLabel clr_999">使用机构：</div>
            <div
              class="clr_303 useInstituteNum overOneLine flex_row"
              v-if="oneSystem.institution_names.length != 0"
            >
              [{{ oneSystem.institution_names.length }}家]
              <!-- <span v-for="(itemname, index) in oneSystem.institution_names" :key="itemname"><span v-if="index!=0">、</span>{{oneSystem.name}}</span> -->
              <tooltip-over
                :content="oneSystem.institution_names"
                placement="top-start"
                class="wid190"
                refName="tooltipOver"
              ></tooltip-over>
            </div>
            <div class="clr_303 useInstituteNum overOneLine" v-else>无</div>
          </div>
        </div>
      </div>
      <div class="operateBtnCon">
        <div
          class="operateBtnOneBox"
          v-if="oneSystem.product_code == 'ImageCriminal'"
          @click="setParam(oneSystem)"
        >
          <div class="operateBtnOne">
            <span class="operateBtnTxt">设置</span>
          </div>
        </div>
        <div
          class="operateBtnOneBox"
          v-if="isSetUdi && oneSystem.product_code != 'ImageCriminal'"
          @click="isShowinfoFn('aboutSystem', item)"
        >
          <div class="operateBtnOne">
            <span class="operateBtnTxt">关于</span>
          </div>
        </div>
        <div class="operateBtnOneBox" @click="isShowinfoFn('edit', oneSystem)">
          <div class="operateBtnOne">
            <span class="operateBtnTxt">编辑</span>
          </div>
        </div>
        <div
          class="operateBtnOneBox"
          v-if="isShowManageBtn"
          @click="isShowinfoFn('operate', oneSystem)"
        >
          <div class="operateBtnOne">
            <span class="operateBtnTxt"
              ><i class="iconfont">&#xe667;</i> 系统管理</span
            >
          </div>
        </div>
      </div>
    </div>
    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="isPacsinfo"
      :show-close="false"
      :withHeader="false"
      :direction="direction"
      :before-close="handleClose"
    >
      <component
        :is="curSystemModule"
        ref="info"
        :productObj="productObj"
        :pacsinfo="operateSystemInfo"
        :criminalSourceArr="criminalSourceArr"
        :serviceList="serviceList"
        :getDetailFinished="getDetailFinished"
        :pageInfo="InstitutionPage"
        @closeFn="closeFn"
        @selectInstitionListFn="selectInstitionListFn"
        @delInstitutionFn="delInstitutionFn"
        @changePhone="changePhone"
        @dealselectCurRow="dealselectCurRow"
        @dealselectWeiJianCurRow="dealselectWeiJianCurRow"
        @dealselectFirmCurRow="dealselectFirmCurRow"
        @selectWeiJianListFn="selectWeiJianListFn"
        @selectFirmListFn="selectFirmListFn"
        @ChoiceOrganFn="ChoiceOrganFn"
        @ChoiceWeiJianFn="ChoiceWeiJianFn"
        @ChoiceFirmFn="ChoiceFirmFn"
        @beganSerchListFn="beganSerchListFn"
        @getSerchName="getSerchName"
        @getAdminNameFn="getAdminNameFn"
        @pageSizeChangeFn="pageSizeChangeFn"
        @CheckOfficeidsFn="CheckOfficeidsFn"
        @activeSystemFn="activeSystemFn"
        @changeService="changeService"
        @submitForm="submitForm"
        @isAddInstution="isAddInstution"
        @isAddWeiJian="isAddWeiJian"
        @isAddFirm="isAddFirm"
      ></component>
    </el-drawer>

    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="isSetParam"
      :show-close="false"
      :withHeader="false"
      :direction="direction"
      :before-close="handleClose"
    >
      <comprehensiveSet
        :key="paramSetKey"
        ref="systemParamSet"
        @closeFn="closeSetFn"
      ></comprehensiveSet>
    </el-drawer>
  </div>
</template>

<script>
import Vue from "vue";
import aboutSystem from "tomtaw-system-about";
import Mgr from "@/utils/SecurityService";
import JSEncrypt from "jsencrypt";
import { mapGetters } from "vuex";
import ImgsystemInfo from "./info";
import criminalInfo from "./criminalInfo";
import comprehensiveSet from "./comprehensiveSet";
import {
  addPacsSystems,
  getInstitutionList,
  getPascList,
  getPacsSystemsInfoByid,
  putPacsSystems,
  getImageserviceList,
  getCriminalSource,
  checkIsOpenImageCriminal,
} from "@/api/platform_costomer/institution";
import { getLoginName, getConfigurations } from "@/api/commonHttp";
import tooltipOver from "../tooltipOver";
// import { setCachedLastName } from 'tomtaw-caches';
import moment from "moment";

export default {
  components: {
    ImgsystemInfo,
    criminalInfo,
    comprehensiveSet,
    tooltipOver,
  },
  computed: {
    ...mapGetters(["isSetUdi", "isShowManageBtn"]),
  },
  props: {
    oneSystem: Object,
  },
  data() {
    return {
      YXYGD: require("../../../../../assets/images/YXYGD_Image.png"),
      CRI: require("../../../../../assets/images/XZDY_Image.png"),
      YXZX: require("../../../../../assets/images/YYZX_Image.png"),
      YXZSY: require("../../../../../assets/images/YXZSY_Image.png"),
      info: "",
      isPacsinfo: false,
      isSetParam: false,
      loading: true,
      direction: "rtl",
      pacsList: [],
      isactive: "",
      isoperateactive: "",
      curSystemType: "",
      curSystemModule: "",
      openImageCriminal: false,
      getDetailFinished: false,
      paramSetKey: 0,
      serviceList: [],
      criminalSourceArr: [],
      paramId: {
        curCriminalInforId: "0",
      },
      operateSystemInfo: {
        title: "新增影像共享系统",
        serchName: "",
        activesystem: "",
        isAdminname: false,
        product_name: "",
        criminaInfor: {
          access_institution: "",
          access_source: "0",
          product_code: "ImageCriminal",
        },
        providersObj: {
          app_id: "",
          app_secret: "",
          provider_name: "WeChat",
        },
        formInfo: {
          type: 2,
          product_code: "",
          function_services: [],
          name: "",
          admin_phone: "",
          admin_name: "",
          providers: [],

          isIndefinitely: true, // 是否无限期
          start_date: moment().format("YYYY-MM-DD"), // 开始期限
          stop_date: null, // 结束期限
          state: 10, // 启用状态
          reason: "", // 停用原因
        },
        rules: {
          product_code: [
            { required: true, message: "请选择产品名称", trigger: "change" },
          ],
          name: [
            { required: true, message: "请输入系统名称", trigger: "blur" },
          ],
          admin_phone: [
            { required: true, message: "请输入管理员电话", trigger: "change" },
          ],
          admin_name: [
            { required: true, message: "请输入管理员姓名", trigger: "change" },
          ],
        },
        isUpdate: false,
        isFirstChange: true,
        isChioseOrgan: false,
        institutionList: [], // 机构列表
        deplist: [],
        multipleSelection: [], // 选中机构
        isChioseWeiJian: false,
        isChioseFirm: false,
        choosedWeiJianArr: [], // 选中的卫健
        choosedFirmArr: [], // 选中的厂商
      },
      systemDetail: {},
      InstitutionPage: {
        eof: 1,
        page_index: 1,
        page_size: 10,
        total_count: 0,
        total_pages: 1,
      },
      choiseList: [],
      choiseWeiJianList: [],
      choiseFirmList: [],
      productObj: {},
    };
  },
  provide() {
    return {
      // curCriminalInforId: ()=> {
      //   this.curCriminalInforId
      // }
      operateSystemInfo: this.operateSystemInfo,
      curCriminalInforIdObj: this.paramId,
    };
  },
  created() {},
  methods: {
    initData() {
      this.beganCheckIsOpenImageCriminal();
      //this.getPascListFn()
      this.getImageserviceListFn();
      // 获取调阅来源
      this.beganGetCriminalSource();
      // 加密函数
      //this.getConfigurationsFn()
    },
    // 检查是否开通了刑侦调阅服务
    async beganCheckIsOpenImageCriminal() {
      const res = await checkIsOpenImageCriminal();
      if (res.code === 0) {
        if (res.data) {
          this.openImageCriminal = true;
        } else {
          this.openImageCriminal = false;
        }
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 选择系统
    chooseSystemType(type) {
      this.curSystemType = type;
      this.loadCurComponents();
      // if (type === 5) {
      //   this.beganGetCallingService()
      // }
      // if (type === 1) {
      //   this.getPasServicecListFn()
      // }
      this.isShowinfoFn("add");
    },
    // 加载相应的组件
    loadCurComponents() {
      if (this.curSystemType === 2) {
        // 影像共享
        this.curSystemModule = ImgsystemInfo;
      }
      if (this.curSystemType === 7) {
        // 刑侦调阅
        this.curSystemModule = criminalInfo;
      }
    },
    async getConfigurationsFn() {
      const res = await getConfigurations("TransmissionSecurity.RSA.PublicKey");
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) {
          // 注册方法
          const pubKey = res.data; // ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt();
          encryptStr.setPublicKey(pubKey); // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()); // 进行加密
          return data;
        };
      }
    },
    activeSystemFn(index, code) {
      this.operateSystemInfo.formInfo.product_code = code;
      // 编辑时
      if (this.operateSystemInfo.title == "编辑影像共享系统") {
        // pacsinfo.formInfo.function_services
      } else {
        // 新增时
        this.operateSystemInfo.formInfo.function_services = [];
      }
    },
    changeService(arr) {
      const self = this;
      self.$set(
        self.productObj,
        self.operateSystemInfo.formInfo.product_code,
        arr
      );
      if (arr.length > 0) {
        for (let code in self.productObj) {
          if (code != self.operateSystemInfo.formInfo.product_code) {
            self.$set(self.productObj, code, []);
          }
        }
      }
    },
    initDifferentSystemVal() {
      if (this.curSystemType === 2) {
        this.operateSystemInfo.title = "新增影像共享系统";
      }
      if (this.curSystemType === 7) {
        // 刑侦调阅
        this.operateSystemInfo.title = "新增司法鉴定系统";
      }
    },
    changePhone() {
      if (this.isUpdate) {
        // 是否是第一次改变
        if (this.isFirstChange) {
          this.operateSystemInfo.formInfo.admin_phone = "";
          this.operateSystemInfo.formInfo.admin_name = "";
        }
        this.isFirstChange = false;
      }
    },
    async getPascListFn() {
      const res = await getPascList(this.operateSystemInfo.formInfo.type);
      if (res.code === 0) {
        this.loading = false;
        this.pacsList = res.data;
        // 获取调阅来源
        this.beganGetCriminalSource();
      } else {
        this.loading = false;
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 获取调阅来源
    async beganGetCriminalSource() {
      this.criminalSourceArr = [];
      const res = await getCriminalSource({ is_image_criminal: true, type: 2 });
      if (res.code === 0) {
        if (res.data.length != 0) {
          res.data.forEach((val) => {
            this.criminalSourceArr.push(val);
          });
        }
        this.criminalSourceArr.unshift({ name: "请选择", id: "0" });
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 影像共享系统获取开通的服务
    async getImageserviceListFn() {
      const self = this;
      self.serviceList = [];
      const res = await getImageserviceList();
      if (res.code === 0) {
        res.data.forEach((val) => {
          val.isCanChoose = false;
          val.function_services = [];
          self.serviceList.push(val);
          // 初始化产品对象
          self.$set(self.productObj, val.code, []);
        });
      }
    },
    // 添加机构
    isAddInstution() {
      this.operateSystemInfo.serchName = "";
      this.InstitutionPage.page_index = 1;
      this.InstitutionPage.page_size = 10;
      this.getInstitutionListFn();
      this.operateSystemInfo.isChioseOrgan = true;
    },
    // 添加卫健
    isAddWeiJian() {
      const self = this;
      self.operateSystemInfo.isChioseWeiJian = true;
      self.$nextTick(() => {
        self.$refs.info.$refs.addWeiJian.searchWeiJianParam = {
          contains_name: "",
          province_code: "",
          city_code: "",
          district_code: "",
          admin_info: "",
          type: 1,
          offset: 1,
          limit: 10,
        };
        //console.log(self.operateSystemInfo.choosedWeiJianArr)
        self.$refs.info.$refs.addWeiJian.beganGetWeiJianList(
          self.operateSystemInfo.choosedWeiJianArr
        );
      });
    },
    // 添加厂商
    isAddFirm() {
      const self = this;
      self.operateSystemInfo.isChioseFirm = true;
      self.$nextTick(() => {
        self.$refs.info.$refs.addFirm.searchFirmParam = {
          contains_name: "",
          category: "",
          admin_info: "",
          type: 2,
          offset: 1,
          limit: 10,
        };
        self.$refs.info.$refs.addFirm.beganGetFirmList(
          self.operateSystemInfo.choosedFirmArr
        );
      });
    },
    moreVersionSkip(item) {
      let url;
      if (item.product_code == "ImageStorage") {
        // 影像云归档
        url =
          configUrl.frontEndUrl + "/idcas/imgarchive/sysmanage/data-monitor";
      } else if (item.product_code == "RemoteBackup") {
        // 影像中心
        url = configUrl.frontEndUrl + "/idcas/imgcenter/sysmanage/data-monitor";
      } else if (item.product_code == "ImageSupervision") {
        // 影像主索引
        url =
          configUrl.frontEndUrl + "/idcas/imgmaster/sysmanage/archive-record";
      } else {
        url = configUrl.frontEndUrl + "/idcas/systemmanage/dashboard";
      }
      return url;
    },
    // 设置参数
    setParam(item) {
      this.isSetParam = true;
      this.paramId.curCriminalInforId = item.id;
      this.paramSetKey++;
    },
    async isShowinfoFn(type, item, code) {
      // 新增和编辑时重置下产品对象
      for (let code in this.productObj) {
        this.$set(this.productObj, code, []);
      }
      if (type === "add") {
        this.isUpdate = false;
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
        this.serviceList.forEach((val) => {
          val.isCanChoose = false;
        });
        this.isPacsinfo = true;
        this.initDifferentSystemVal();
        this.$nextTick(() => {
          if (self.curSystemType === 2) {
            // 影像共享
            this.$refs.info.curChooseProductCode = "";
            this.$refs.info.beganGetTenancyType();
          }
        });
      } else if (type === "operate") {
        sessionStorage.setItem("idcas_systemid", item.id);
        sessionStorage.setItem("lastname", item.id);
        if (item.product_code == "ImageSupervision") {
          // 影像主索引
          sessionStorage.setItem("lastCode", "imisys-idcas");
        } else if (item.product_code == "ImageStorage") {
          // 影像云归档
          sessionStorage.setItem("lastCode", "iasys-idcas");
        } else if (item.product_code == "RemoteBackup") {
          // 影像中心
          sessionStorage.setItem("lastCode", "icsys-idcas");
        }
        // 菜单name
        // window.sessionStorage.setItem('ChosedSystemName', 'DepartmentSystem')
        let url;
        // 如果是刑侦调阅的话 跳转特殊处理
        if (item.product_code == "ImageCriminal") {
          //url = configUrl.frontEndUrl + '/idcas/imgcriminal/sysmanage/application'
          url =
            configUrl.frontEndUrl + "/idcas/imgcriminal/sysmanage/review-log";
          sessionStorage.setItem("lastCode", "icisys-idcas");
        } else {
          if (typeof curImageShareVersion != "undefined") {
            ///是否在config.js里面定义了影像存档版本号
            if (curImageShareVersion === 14) {
              //// 针对归档15.1之前版本的跳转
              if (item.is_image_supervision) {
                url = configUrl.frontEndUrl + "/idcas/supervision/dashboard";
              } else {
                url = configUrl.frontEndUrl + "/idcas/systemmanage/dashboard";
              }
            } else {
              // 针对归档15.1版本的跳转
              url = this.moreVersionSkip(item);
            }
          } else {
            // 没有定义版本号的话 默认15.1版本的跳转
            url = this.moreVersionSkip(item);
          }
        }

        window.open(url);
      } else if (type == "aboutSystem") {
        var manager = new Mgr();
        manager.getRole().then(function (item) {
          if (item) {
            aboutSystem("idcas", item);
          }
        });
      } else {
        await this.$emit("closeAllDrawDetailAlert", "IDCAS");
        this.isactive = item.id;
        this.isPacsinfo = true;
        this.isUpdate = true;
        this.isFirstChange = true;
        // 编辑刑侦调阅
        if (item.product_code == "ImageCriminal") {
          this.curSystemType = 7;
          this.operateSystemInfo.title = "编辑司法鉴定系统";
          await this.beganGetCriminalSource();
        } else {
          this.curSystemType = 2;
          this.operateSystemInfo.title = "编辑影像共享系统";
        }
        this.loadCurComponents();
        await this.getImageserviceListFn();
        this.getDetailFinished = false;
        this.serviceList.forEach((val) => {
          val.isCanChoose = false;
        });
        this.getPacsSystemsInfoByidFn(item.id);
      }
    },
    async getPacsSystemsInfoByidFn(id) {
      const self = this;
      self.operateSystemInfo.multipleSelection = [];
      const res = await getPacsSystemsInfoByid(id);
      if (res.code === 0) {
        self.systemDetail = res.data;
        self.operateSystemInfo.product_name = res.data.product_name;
        self.operateSystemInfo.formInfo.id = res.data.id;
        self.operateSystemInfo.formInfo.name = res.data.name;
        self.operateSystemInfo.formInfo.admin_phone = res.data.admin_phone;
        self.operateSystemInfo.formInfo.admin_name = res.data.admin_name;
        self.operateSystemInfo.formInfo.function_services =
          res.data.function_services;
        self.operateSystemInfo.multipleSelection = res.data.institutions;
        self.operateSystemInfo.institution_count = res.data.institution_count;
        self.operateSystemInfo.formInfo.product_code = res.data.product_code;

        self.operateSystemInfo.formInfo.isIndefinitely =
          res.data.stop_date === "无期限" ? true : false;
        self.operateSystemInfo.formInfo.start_date = res.data.start_date;
        self.operateSystemInfo.formInfo.stop_date =
          res.data.stop_date === "无期限" ? "" : res.data.stop_date;
        self.operateSystemInfo.formInfo.state = res.data.state;
        self.operateSystemInfo.formInfo.reason = res.data.reason;

        self.getDetailFinished = true;
        self.operateSystemInfo.isAdminname = true;
        self.$set(
          self.productObj,
          res.data.product_code,
          res.data.function_services
        );
        if (res.data.providers.length != 0) {
          self.operateSystemInfo.providersObj = res.data.providers[0];
        }

        self.$nextTick(() => {
          if (self.curSystemType === 2) {
            // 影像共享
            self.$refs.info.curChooseProductCode = res.data.product_code;
            self.$refs.info.beganGetTenancyType();
          }
        });
        self.operateSystemInfo.choosedWeiJianArr = [];
        self.operateSystemInfo.choosedFirmArr = [];
        const factories = res.data.factories;
        if (factories && factories.length != 0) {
          factories.forEach((item) => {
            if (item.type == 1) {
              // 卫健
              self.operateSystemInfo.choosedWeiJianArr.push(item);
            } else {
              // 厂商
              self.operateSystemInfo.choosedFirmArr.push(item);
            }
          });
        }

        if (res.data.access_institution) {
          self.operateSystemInfo.criminaInfor.access_institution =
            res.data.access_institution;
          self.operateSystemInfo.criminaInfor.access_source =
            res.data.access_source;
          self.operateSystemInfo.criminaInfor.product_code =
            res.data.product_code;
          // 如果调阅来源的系统去掉了 刑侦调阅服务(相当于调阅来源被删掉了时) 得回显 请选择
          let isDelSource = true;
          if (self.criminalSourceArr.length != 0) {
            self.criminalSourceArr.forEach((one) => {
              if (one.id == res.data.access_source) {
                isDelSource = false; // 没删除调阅来源
              }
            });
            // 如果是删除了调阅来源的话 得回显 “请选择”
            if (isDelSource) {
              self.operateSystemInfo.criminaInfor.access_source = "0";
            }
          } else {
            self.operateSystemInfo.criminaInfor.access_source = "0";
          }
        }
      }
    },
    async getAdminNameFn() {
      var _phone = this.operateSystemInfo.formInfo.admin_phone;
      var phoneReg = /^1[3456789]\d{9}$/;
      if (!phoneReg.test(_phone)) {
        return;
      }
      var url = `/users/lite/${_phone}`;
      var res = await getLoginName(url);
      if (res.code === 0) {
        this.operateSystemInfo.formInfo.admin_name = res.data
          ? res.data.name
          : "";
        this.operateSystemInfo.isAdminname = true;
      } else {
        this.operateSystemInfo.isAdminname = false;
        this.operateSystemInfo.formInfo.admin_name = "";
      }
    },
    handleClose(done) {
      done();
    },
    // 关闭设置参数
    closeSetFn() {
      this.isSetParam = false;
    },
    closeFn() {
      var info = {
        type: "cancel",
        refs: this.$refs["info"].$refs,
        formName: "formInfo",
      };
      this.submitForm(info);
    },
    async getInstitutionListFn() {
      const self = this;
      const _url =
        "/institutions?offset=" +
        self.InstitutionPage.page_index +
        "&limit=" +
        self.InstitutionPage.page_size +
        "&name=" +
        self.operateSystemInfo.serchName;
      const res = await getInstitutionList(_url);
      self.$refs.info.$refs.institutions.clearSelection();
      if (res.code === 0) {
        self.operateSystemInfo.institutionList = res.data;
        self.InstitutionPage = res.page;
        if (self.operateSystemInfo.title === "编辑影像共享系统") {
          res.data.forEach((itemids) => {
            self.operateSystemInfo.multipleSelection.forEach((item) => {
              if (itemids.id === item.id) {
                self.$nextTick(() => {
                  self.$refs.info.$refs.institutions.toggleRowSelection(
                    itemids,
                    true
                  );
                });
              }
            });
          });
        }
      }
    },
    // 分页
    pageSizeChangeFn(info, serchName) {
      this.InstitutionPage.page_index = info.page;
      this.InstitutionPage.page_size = info.limit;
      this.operateSystemInfo.serchName = serchName;
      this.getInstitutionListFn();
    },
    // 选中某一行
    dealselectCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.operateSystemInfo.multipleSelection.forEach((val, i) => {
          if (val.id === row.id) {
            self.operateSystemInfo.multipleSelection.splice(i, 1);
          }
        });
      }
    },
    // 选中某一行（卫健）
    dealselectWeiJianCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.operateSystemInfo.choosedWeiJianArr.forEach((val, i) => {
          if (val.id === row.id) {
            self.operateSystemInfo.choosedWeiJianArr.splice(i, 1);
          }
        });
      }
    },
    dealselectFirmCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.operateSystemInfo.choosedFirmArr.forEach((val, i) => {
          if (val.id === row.id) {
            self.operateSystemInfo.choosedFirmArr.splice(i, 1);
          }
        });
      }
    },
    selectInstitionListFn(rows) {
      this.choiseList = rows;
    },
    selectWeiJianListFn(rows) {
      this.choiseWeiJianList = rows;
    },
    selectFirmListFn(rows) {
      this.choiseFirmList = rows;
    },
    instclose() {
      this.operateSystemInfo.institutionList.forEach((item) => {
        this.$nextTick(() => {
          this.$refs.info.$refs.institutions.toggleRowSelection(item, false);
        });
      });
      this.operateSystemInfo.isChioseOrgan = false;
    },
    // 去掉重复的id
    clearCommonId(arr) {
      var result = [];
      var obj = {};
      for (var i = 0; i < arr.length; i++) {
        if (!obj[arr[i].id]) {
          result.push(arr[i]);
          obj[arr[i].id] = true;
        }
      }
      return result;
    },
    ChoiceOrganFn(type) {
      const self = this;
      self.operateSystemInfo.isChioseOrgan = false;
      if (type === "commit") {
        self.choiseList.forEach((val) => {
          self.operateSystemInfo.multipleSelection.push(val);
        });
      }
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
      self.instclose();
    },
    ChoiceWeiJianFn(type) {
      const self = this;
      self.operateSystemInfo.isChioseWeiJian = false;
      if (type === "commit") {
        self.choiseWeiJianList.forEach((val) => {
          val.institutions = [];
          if (val.institution_ids.length != 0) {
            val.institution_ids.forEach((item) => {
              let obj = {
                id: item,
                is_disable: true,
              };
              val.institutions.push(obj);
            });
          }
          self.operateSystemInfo.choosedWeiJianArr.push(val);
        });
      }
      self.operateSystemInfo.choosedWeiJianArr = self.clearCommonId(
        self.operateSystemInfo.choosedWeiJianArr
      );
      self.instclose();
    },
    ChoiceFirmFn(type) {
      const self = this;
      self.operateSystemInfo.isChioseFirm = false;
      if (type === "commit") {
        self.choiseFirmList.forEach((val) => {
          val.institutions = [];
          if (val.institution_ids.length != 0) {
            val.institution_ids.forEach((item) => {
              let obj = {
                id: item,
                is_disable: true,
              };
              val.institutions.push(obj);
            });
          }
          self.operateSystemInfo.choosedFirmArr.push(val);
        });
      }
      self.operateSystemInfo.choosedFirmArr = self.clearCommonId(
        self.operateSystemInfo.choosedFirmArr
      );
      self.instclose();
    },
    CheckOfficeidsFn(val) {
      console.log(val);
    },
    delInstitutionFn(id, type) {
      this.$confirm("是否删除这条机构信息？", "删除信息", {
        distinguishCancelAndClose: true,
        confirmButtonText: "删除",
        cancelButtonText: "取消",
      }).then(() => {
        this.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === id) {
            if (this.operateSystemInfo.institutionList.length > 0) {
              this.$refs.info.$refs.institutions.toggleRowSelection(
                item,
                false
              );
            }
            this.operateSystemInfo.multipleSelection.splice(i, 1);
            this.$message({
              type: "success",
              message: "删除成功",
            });
          }
        });
        if (type == "weiJian") {
          this.dealWeiJianOrFirmList(id);
        }
      });
    },
    dealWeiJianOrFirmList(id) {
      const self = this;
      if (self.operateSystemInfo.multipleSelection.length == 0) {
        // 如果该系统下没有绑定机构
        self.operateSystemInfo.choosedWeiJianArr = [];
        self.operateSystemInfo.choosedFirmArr = [];
      }
      // 关联的卫健
      let ableInstituteCount = 0;
      if (self.operateSystemInfo.choosedWeiJianArr.length != 0) {
        self.operateSystemInfo.choosedWeiJianArr.forEach((item, i) => {
          ableInstituteCount = 0;
          if (item.institutions.length != 0) {
            item.institutions.forEach((nth) => {
              // 统计某个卫健 启用的机构数量
              if (nth.is_disable) {
                // 启用的机构
                ableInstituteCount++;
              }
            });
            item.institutions.forEach((one, j) => {
              if (one.id == id) {
                if (ableInstituteCount == 1) {
                  // 某个卫建 只有1家 启用的机构
                  self.operateSystemInfo.choosedWeiJianArr.splice(i, 1);
                } else {
                  item.institutions.splice(j, 1);
                }
              }
            });
          }
        });
      }
      // 关联的厂商
      let ableInstituteCountFromFirm = 0;
      if (self.operateSystemInfo.choosedFirmArr.length != 0) {
        self.operateSystemInfo.choosedFirmArr.forEach((item, i) => {
          ableInstituteCountFromFirm = 0;
          if (item.institutions.length != 0) {
            item.institutions.forEach((nth) => {
              // 统计某个厂商 启用的机构数量
              if (nth.is_disable) {
                // 启用的机构
                ableInstituteCountFromFirm++;
              }
            });
            item.institutions.forEach((one, j) => {
              if (one.id == id) {
                if (ableInstituteCountFromFirm == 1) {
                  // 某个厂商 只有1家 启用的机构
                  self.operateSystemInfo.choosedFirmArr.splice(i, 1);
                } else {
                  item.institutions.splice(j, 1);
                }
              }
            });
          }
        });
      }
    },
    // 去重
    clearCommonService(arr) {
      let newArr = [];
      if (arr.length != 0) {
        arr.forEach((item) => {
          if (newArr.indexOf(item) == -1) {
            newArr.push(item);
          }
        });
      }
      return newArr;
    },
    async addPacsSystemsFn(info) {
      const self = this;
      let tip = "正在新增，请稍等...";
      if (self.isUpdate) {
        tip = "正在编辑，请稍等...";
      }
      const loading = self.$loading({
        lock: true,
        text: tip,
        spinner: "el-icon-loading",
        background: "rgba(255, 255, 255, 0.6)",
      });
      let _params = {};
      if (info.formName == "criminaInfor") {
        _params.name = self.operateSystemInfo.formInfo.name;
        _params.admin_phone = self.operateSystemInfo.formInfo.admin_phone;
        _params.admin_name = self.operateSystemInfo.formInfo.admin_name;
        _params.id = self.operateSystemInfo.formInfo.id;
        _params.type = 2;
        _params.product_code = self.operateSystemInfo.criminaInfor.product_code;
        _params.access_institution =
          self.operateSystemInfo.criminaInfor.access_institution;
        _params.access_source =
          self.operateSystemInfo.criminaInfor.access_source;

        _params.isIndefinitely = self.operateSystemInfo.formInfo.isIndefinitely;
        _params.start_date = self.operateSystemInfo.formInfo.start_date;
        _params.stop_date = self.operateSystemInfo.formInfo.stop_date;
        _params.state = self.operateSystemInfo.formInfo.state;
        _params.reason = self.operateSystemInfo.formInfo.reason;
      } else {
        self.operateSystemInfo.formInfo.function_services = [];
        for (let code in self.productObj) {
          if (
            self.productObj[code].length > 0 &&
            self.operateSystemInfo.formInfo.product_code == code
          ) {
            self.productObj[code].forEach((val) => {
              self.operateSystemInfo.formInfo.function_services.push(val);
            });
          }
        }
        self.operateSystemInfo.formInfo.function_services =
          self.clearCommonService(
            self.operateSystemInfo.formInfo.function_services
          );
        _params = JSON.parse(JSON.stringify(self.operateSystemInfo.formInfo));
        var _institutionList = [];
        if (self.operateSystemInfo.multipleSelection.length != 0) {
          self.operateSystemInfo.multipleSelection.forEach((item) => {
            var info = {};
            info.id = item.id;
            _institutionList.push(info);
          });
        }
        _params.institutions = _institutionList;

        _params.factories = [];
        if (self.operateSystemInfo.choosedWeiJianArr.length != 0) {
          self.operateSystemInfo.choosedWeiJianArr.forEach((item) => {
            var info = {};
            info.id = item.id;
            info.type = 1;
            info.disable_institution_ids = item.disable_institution_ids;
            _params.factories.push(info);
          });
        }
        if (self.operateSystemInfo.choosedFirmArr.length != 0) {
          self.operateSystemInfo.choosedFirmArr.forEach((item) => {
            var info = {};
            info.id = item.id;
            info.type = 2;
            info.disable_institution_ids = item.disable_institution_ids;
            _params.factories.push(info);
          });
        }
      }
      _params.providers = [];
      _params.providers.push(this.operateSystemInfo.providersObj);
      // 对手机号加密
      var adminPhone = _params.admin_phone;
      _params.admin_phone = self.$getRsaCode(_params.admin_phone);
      var res = null;
      let tipmsg;
      if (info.formName == "criminaInfor") {
        tipmsg = "新增司法鉴定系统成功";
      } else {
        tipmsg = "新增影像共享系统成功";
      }

      // 特殊处理一下期限相关的字段
      _params.stop_date = _params.isIndefinitely ? null : _params.stop_date;
      _params.reason = _params.state === 10 ? "" : _params.reason;
      delete _params.isIndefinitely;
      if (_params.id) {
        delete _params["type"];
        res = await putPacsSystems(_params);
        if (info.formName == "criminaInfor") {
          tipmsg = "修改司法鉴定系统成功";
        } else {
          tipmsg = "修改影像共享系统成功";
        }
      } else {
        res = await addPacsSystems(_params);
      }
      loading.close();
      if (res.code === 0) {
        self.$message({
          type: "success",
          message: tipmsg,
        });
        self.isPacsinfo = false;
        // self.getPascListFn()
        self.$emit("getSystemList");
        self.operateSystemInfo = self.$options.data().operateSystemInfo;
      } else {
        self.operateSystemInfo.formInfo.admin_phone = adminPhone;
        self.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    getSerchName(val) {
      this.operateSystemInfo.serchName = val;
    },
    beganSerchListFn() {
      this.InstitutionPage.page_index = 1;
      this.InstitutionPage.page_size = 10;
      this.getInstitutionListFn();
    },
    async serchListFn() {
      const _url =
        "/institutions?office_type=2&name=" + this.operateSystemInfo.serchName;
      const res = await getInstitutionList(_url);
      if (res.code === 0) {
        this.operateSystemInfo.institutionList = res.data;
        this.InstitutionPage = res.page;
      }
    },
    submitForm(info) {
      if (info.type === "commit") {
        if (!this.operateSystemInfo.formInfo.name) {
          this.$message({ type: "error", message: "请输入系统名称" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.admin_phone) {
          this.$message({ type: "error", message: "请输入管理员电话" });
          return;
        }
        var phoneReg = /^1[3456789]\d{9}$/;
        // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
        if (!this.isUpdate || (this.isUpdate && !this.isFirstChange)) {
          if (!phoneReg.test(this.operateSystemInfo.formInfo.admin_phone)) {
            this.$message({
              message: "请输入正确的手机号码!",
              type: "warning",
            });
            return false;
          }
        }
        if (!this.operateSystemInfo.formInfo.admin_name) {
          this.$message({ type: "error", message: "请输入管理员姓名" });
          return;
        }
        // 刑侦调阅新增的验证
        if (info.formName == "criminaInfor") {
          if (!this.operateSystemInfo.criminaInfor.access_institution) {
            this.$message({ type: "error", message: "请输入调阅机构" });
            return;
          }
          if (
            !this.operateSystemInfo.criminaInfor.access_source ||
            this.operateSystemInfo.criminaInfor.access_source == "0"
          ) {
            this.$message({ type: "error", message: "请选择调阅来源" });
            return;
          }
        } else {
          if (!this.operateSystemInfo.formInfo.product_code) {
            this.$message({ type: "error", message: "请选择授权产品" });
            return;
          }
        }

        if (!this.operateSystemInfo.formInfo.start_date) {
          this.$message({ type: "error", message: "请选择使用开始期限" });
          return;
        }
        if (
          !this.operateSystemInfo.formInfo.isIndefinitely &&
          !this.operateSystemInfo.formInfo.stop_date
        ) {
          this.$message({ type: "error", message: "请选择使用结束期限" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.state) {
          this.$message({ type: "error", message: "请选择系统状态" });
          return;
        }
        if (
          this.operateSystemInfo.formInfo.state === -2 &&
          !this.operateSystemInfo.formInfo.reason
        ) {
          this.$message({ type: "error", message: "请输入停用备注" });
          return;
        }

        this.addPacsSystemsFn(info);
        // info.refs[info.formName].validate((valid) => {
        //   if (valid) {
        //     this.addPacsSystemsFn()
        //   }
        // })
      } else {
        this.isPacsinfo = false;
        this.isactive = "";
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      }
    },
  },
};
</script>

<style lang="less" scoped>
.jurisdictionlist {
  // width: 100%;
  display: flex;
  flex-wrap: wrap;
  .oneSystemItem {
    width: 100%;
  }
  .container {
    height: calc(100% - 47px);
    padding: 10px 5px;
    overflow: auto;
    position: relative;
  }
}
.list-item {
  width: calc(25% - 15px);
  margin-right: 15px;
  box-sizing: border-box;
  border: 1px solid #ebeef5;
  box-shadow: 0 1px 5px 0 rgba(26, 26, 26, 0.050980392156862744);
  border-radius: 6px;
  background: #ffffff;
  margin-bottom: 15px;
  .listItemInfor {
    padding: 18px 14px 14px 18px;
    //border-bottom: 1px solid #ebeef5;
  }
  .active {
    background: rgba(10, 112, 176) !important;
    color: #fff !important;
  }
  .pacs_img {
    width: 52px;
    height: 52px;
    vertical-align: middle;
  }
  .title {
    // max-width: 200px;
    width: 100%;
  }
  .systemNameTitle {
    width: 100%;
    font-size: 20px;
    color: #1f2f3d;
    font-weight: 500;
    position: relative;
    top: -3px;
  }
  .shareHead {
    width: calc(100% - 70px);
    margin-left: 16px;
  }
  .productIdAndType {
    display: flex;
    .productIdAndTypeText {
      display: inline-block;
      line-height: 22px;
    }
    .productName {
      margin-right: 10px;
    }
    .idNumber {
      display: inline-block;
      max-width: 190px;
    }
  }
  .item_btn {
    padding: 0 10px;
    height: 30px;
    line-height: 28px;
    text-align: center;
    background: rgba(255, 255, 255, 1);
    border: 1px solid rgba(10, 112, 176, 0.5);
    border-radius: 3px;
    color: #0a70b0;
    cursor: pointer;
  }
  .manageBtn {
    background-color: #0a70b0;
    color: #fff;
  }
  .border_bd {
    border-bottom: 1px dashed #dcdfe6;
  }
  .useInstituteLabel {
    width: 70px;
  }
  .useInstituteNum {
    width: calc(100% - 70px);
  }
  .overOneLine {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .contractedhospital {
    display: flex;
    .contractedLabel {
      font-size: 14px;
      color: #909399;
    }
    .contractedNum {
      font-size: 14px;
      color: #0a70b0;
      i {
        margin-left: 5px;
      }
    }
  }
  .operateBtnCon {
    display: flex;
    height: 40px;
    align-items: center;
    border-top: 1px solid #ebeef5;
    .operateBtnOneBox {
      flex: 1;
      height: 100%;
      display: flex;
      align-items: center;
      cursor: pointer;
    }
    .operateBtnOne {
      width: 100%;
      text-align: center;
      font-size: 14px;
      color: #0a70b0;
      border-right: 1px solid #dcdfe6;
    }
    .operateBtnOneBox:last-of-type {
      .operateBtnOne {
        border-right: none;
      }
    }
    .operateBtnOneBox:hover {
      background: #f2f7ff;
    }
  }
}
.list-item:hover {
  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(10, 112, 176, 0.3);
}
.list-item:hover .title {
  color: #0a70b0;
}
.adminInfor {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.shareHead {
  width: calc(100% - 89px);
}
.productNameDiv {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
@media screen and (max-width: 1500px) {
  .list-item {
    width: calc(50% - 20px) !important;
  }
  .idNumber {
    max-width: initial !important;
  }
}
.borderNone {
  border: none !important;
}
.addClassDiv {
  text-align: center;
  .serviceCenterClass {
    line-height: 32px;
    cursor: pointer;
  }
}
.createBtn:hover {
  background: #e48e0b !important;
  color: #fff !important;
}
</style>
