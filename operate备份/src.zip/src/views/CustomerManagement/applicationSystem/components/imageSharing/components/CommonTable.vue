<template>
<!-- 表格： 可通过后台返回控制table显示某列 及自定义宽度 -->
  <div>
    <template v-for="(item, index) in propData">
      <el-table-column
        v-if="item.prop == 'result'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <!-- 急诊标红处理 -->
        <template  slot-scope="scope">
          <span :class="scope.row.success === true ? 'clr_00' : 'clr_da'">{{scope.row.result}}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-else-if="item.prop == 'name'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <!-- 急诊标红处理 -->
        <template  slot-scope="scope">
          {{scope.row.name}}
          <el-popover
                v-if="scope.row.is_cross_tenancy"
                class="tipPop"
                placement="bottom-start"
                popper-class="organTipPopover"
                title=""
                width="300"
                trigger="hover"
                :content="`原属客户:${scope.row.original_tenancy_name}`">
                <el-button class="tipButton" slot="reference">
                  <span class="diffTanency">跨客户</span>
                </el-button>
                
              </el-popover>
        </template>
      </el-table-column>
      <el-table-column
        v-else
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
      </el-table-column>
    </template>
  </div>
</template>
<script>
import mixin from '@/utils/mixin/intelligentDiagnosis'

export default {
  name: 'CommonTable',
  props: {
    propData: Array
  },
  mixins: [mixin]
}
</script>
<style lang="less">
.diffTanency{
  display: inline-block;
  text-align: center;
  // width: 40px;
  padding: 0 5px;
  height: 20px;
  line-height: 20px;
  background: #ff9f46;
  color: #fff;
  border-radius: 10px;
  font-size: 12px;
}
.tipButton{
  padding: 0px!important;
  border:none!important;
}
</style>
