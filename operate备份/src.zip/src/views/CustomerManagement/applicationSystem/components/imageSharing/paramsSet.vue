<template>
  <div class="userlist">
    <div
      class="container"
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-background="rgba(255,255,255,0.6)"
    >
      <div class="search-bar">
        <!-- <div class="fl">
          <span class="search-bar-label fl">参数模块 :</span>
          <el-select
            v-model="searchData.paramModules"
            class="ele-select_32 width_200_select"
            placeholder="请选择"
            style="width:180px"
          >
           <el-option value="">全部</el-option>
            <el-option
              v-for="(item,index) in paramModuleArr"
              :key="index"
              :label="item.name"
              :value="item.value"
            ></el-option>
          </el-select>
        </div>
        <div class="fl margin_left_30">
          <span class="search-bar-label fl">参数名称 :</span>
          <el-input class="width_200_input fl" v-on:keyup.enter.native=getParamList() v-model="searchData.paramName" placeholder="请输入名称关键字"></el-input>
        </div>
        <div class="fl operateBtnDiv">
          <el-button class="search-bar-btn bg_0a clr_ff" @click=getParamList>查询</el-button>
        </div> -->
        <div class="tr col">
          <span @click="saveSet" class="function-btn bg_e6 clr_ff">
            <i class="iconfont iconzhengchang"></i>保存
          </span>
        </div>
      </div>
      <div
        class="table-list pageTable mt10"
        v-bind:class="{
          noTableDataActive: noFilingClerk,
          organTableData: true,
          noTableData: tableData.length == 0,
        }"
      >
        <el-table
          :data="tableData"
          border
          :header-cell-style="{ background: '#F2F2F2', color: '#333' }"
          highlight-current-row
          header-row-class-name="strong"
        >
          <el-table-column type="index" label="序号" width="50">
          </el-table-column>
          <el-table-column
            prop="param_name"
            label="参数名称"
            width="150"
            show-overflow-tooltip
          ></el-table-column>
          <el-table-column
            prop="service_state"
            label="参数值"
            width="290"
            show-overflow-tooltip
          >
            <template slot-scope="scope">
              <div class="serviceSetDiv">
                <el-select
                  v-if="scope.row.param_value_type === 1"
                  v-model="scope.row.param_value"
                  class="ele-select_32 width_200_select"
                  placeholder="请选择"
                  style="width: 180px"
                >
                  <el-option
                    v-for="(item, index) in scope.row.param_options"
                    :key="index"
                    :label="item.Name"
                    :value="item.Value"
                  ></el-option>
                </el-select>
                <el-input
                  v-if="scope.row.param_value_type === 2"
                  v-model="scope.row.param_value"
                  class="width_240_input"
                  placeholder=""
                ></el-input>
                <input
                  class="numberInput"
                  type="number"
                  v-if="scope.row.param_value_type === 3"
                  v-model="scope.row.param_value"
                  name="points"
                />
                <el-date-picker
                  v-if="scope.row.param_value_type === 4"
                  v-model="scope.row.param_value"
                  type="date"
                  placeholder="选择日期"
                >
                </el-date-picker>
                <input
                  class="numberInput"
                  type="number"
                  v-if="scope.row.param_value_type === 5"
                  v-model="scope.row.param_value"
                  name="points"
                />
                <el-switch
                  v-if="scope.row.param_value_type === 6"
                  v-model="scope.row.param_value"
                >
                </el-switch>
                <div v-if="scope.row.param_value_type === 7">
                  <el-radio
                    v-model="scope.row.radioValue"
                    :label="item.Value"
                    v-for="(item, index) in scope.row.param_value"
                    :key="index"
                    >{{ item.Name }}</el-radio
                  >
                </div>
                <!--调阅时效-->
                <div v-if="scope.row.param_value_type === 3001">
                  <el-switch v-model="scope.row.param_value.Enable"></el-switch>
                  <input
                    class="numberInput ml5 mr5"
                    type="number"
                    v-model="scope.row.param_value.Limit"
                    @blur="checkNumber(scope.row)"
                    name="points"
                  />
                  <span>{{ scope.row.param_value.Unit }}</span>
                </div>
                <!--短信模板-->
                <div v-if="scope.row.param_value_type === 3002">
                  <div
                    class="mb5 messageTemplate"
                    v-for="(item, index) in messageArr"
                    :key="index"
                  >
                    <el-checkbox v-model="item.Enable">{{
                      item.ItemTitle
                    }}</el-checkbox>
                    <input
                      class="numberInput codeInput"
                      type="input"
                      placeholder="短信模板代码"
                      v-model="item.TemplateCode"
                      name="points"
                    />
                  </div>
                </div>
                <!--审核方短信接收人-->
                <div v-if="scope.row.param_value_type === 3003">
                  <div
                    class="adminInfor"
                    v-for="(item, index) in msgReceivePeopleArr"
                    :key="index"
                  >
                    <div v-if="index == 0">
                      <el-input
                        v-model="item.ReceiverPhone"
                        placeholder="管理员电话"
                        @blur="getAdminNameFn(item, index)"
                        style="width: 120px"
                      ></el-input>
                      <el-input
                        v-model="item.ReceiverName"
                        placeholder="管理员姓名"
                        :disabled="true"
                        class="ml10"
                        style="width: 100px"
                      ></el-input>
                      <!-- <el-input
                          v-model="item.ReceiverName"
                          placeholder="管理员姓名"
                          :disabled="item.isAdminname"
                          class="ml10"
                          style="width: 100px"
                        ></el-input> -->
                      <el-tooltip placement="top">
                        <div slot="content">新增审核方短信接收人</div>
                        <span
                          class="addAddress dib ml10"
                          @click="addColorSet()"
                        >
                          <i class="el-icon-plus f16"></i>
                        </span>
                      </el-tooltip>
                    </div>
                    <div class="adminInfor" v-else>
                      <el-input
                        v-model="item.ReceiverPhone"
                        placeholder="请输入管理员电话"
                        @blur="getAdminNameFn(item, index)"
                        style="width: 120px"
                      ></el-input>
                      <el-input
                        v-model="item.ReceiverName"
                        placeholder="请输入管理员姓名"
                        :disabled="true"
                        class="ml10"
                        style="width: 100px"
                      ></el-input>
                      <!-- <el-input
                      v-model="item.ReceiverName"
                      placeholder="请输入管理员姓名"
                      :disabled="item.isAdminname"
                      class="ml10"
                      style="width: 100px"
                    ></el-input> -->
                      <span
                        class="delAddress mt5 ml10"
                        @click="delMsgReceivePeople(index)"
                        ><i class="iconfont iconshanchu1"> </i
                      ></span>
                    </div>
                  </div>
                </div>
                <!--公安分局-->
                <div v-if="scope.row.param_value_type === 3004">
                  <div
                    class="adminInfor"
                    v-for="(item, index) in subStationArr"
                    :key="index"
                  >
                    <div v-if="index == 0">
                      <el-input
                        v-model="item.Name"
                        placeholder="分局名称"
                        style="width: 230px"
                      ></el-input>
                      <el-tooltip placement="top">
                        <div slot="content">新增</div>
                        <span
                          class="addAddress dib ml10"
                          @click="addSubStation()"
                        >
                          <i class="el-icon-plus f16"></i>
                        </span>
                      </el-tooltip>
                    </div>
                    <div class="adminInfor" v-else>
                      <el-input
                        v-model="item.Name"
                        placeholder="分局名称"
                        style="width: 230px"
                      ></el-input>
                      <span
                        class="delAddress mt5 ml10"
                        @click="delSubStation(index)"
                        ><i class="iconfont iconshanchu1"> </i
                      ></span>
                    </div>
                  </div>
                </div>
                <el-checkbox-group
                  v-if="scope.row.param_value_type === 8"
                  v-model="scope.row.param_value"
                >
                  <el-checkbox
                    v-for="(item, index) in scope.row.param_options"
                    v-bind:key="index"
                    v-bind:label="item.Value"
                    >{{ item.Name }}</el-checkbox
                  >
                </el-checkbox-group>
                <el-date-picker
                  v-if="scope.row.param_value_type === 9"
                  v-model="scope.row.param_value"
                  type="datetime"
                  placeholder="选择日期时间"
                >
                </el-date-picker>
                <div
                  class="serviceDelay"
                  v-if="scope.row.param_value_type === 2001"
                >
                  <div
                    class="serviceItem"
                    v-for="(value, key, index) in scope.row.param_value"
                    v-bind:key="index"
                  >
                    <el-checkbox v-model="scope.row.param_value[key].Enabled">{{
                      key | dealModuleClass
                    }}</el-checkbox>
                    <label class="fl delayLabel">延时时间:</label
                    ><input
                      class="numberInput"
                      v-model="scope.row.param_value[key].Minute"
                      type="number"
                      name="points"
                    />
                  </div>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="param_description" label="参数说明">
            <template slot-scope="scope">
              <div class="paramState" :title="scope.row.param_description">
                <!-- <span>默认 60 s，单位：秒</span><br/>
                      <span>默认开启，适用于影像、超声、内镜诊断</span><br/>
                      <span>默认不开启</span><br/>
                      <span>默认开启</span><br/>
                      <span>默认关闭，开启后书写签名时判断是否已保存图像，未保存弹窗提示</span><br/>
                      <span>
                          默认不开启；双签名：书写医生、审核医生必须为不同医生，启用此参数，审核签名时判断审核医生与书写医生是否为同一人，同一人时不能签名，不同时允许签名；默认不开启
                      </span><br/>
                      <span>默认 7 天，空或0表示无需限制；单位：天</span><br/>
                      <span>默认全不开启；</span><br/>
                      <span>默认全不开启；单位：分钟</span><br/>
                      <span>默认全开启；</span><br/> -->
                <span>{{ scope.row.param_description }}</span>
              </div>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>

<script>
import { getLoginName } from "@/api/commonHttp";
import {
  getModuleList,
  getParamList,
  saveParam,
  getAllParamData,
  saveSystemParam,
} from "@/api/platform_costomer/criminalInvestigation";
export default {
  components: {
    // PaginationTool
  },
  inject: ["curCriminalInforIdObj"],
  data() {
    return {
      value: "",
      loading: true,
      value1: "",
      checked: false,
      checked2: false,
      isAdminname: false,
      verifySaveParams: true,
      verifyFailMsg: "",
      noFilingClerk: true, // 导入后台有没有列表数据
      currentPage: 1,
      CooperationsDetail: [],
      newCooperationsDetail: [],
      msgReceivePeopleArr: [],
      subStationArr: [],
      messageArr: [],
      totalPage: 1,
      searchData: {
        platform_service: 3,
        module_id: "",
        system_id: 0,
      },
      serviceCenterData: [],
      tableData: [],
    };
  },
  methods: {
    async getAdminNameFn(obj, nth) {
      var _phone = obj.ReceiverPhone;
      if (!_phone) {
        return false;
      }
      var phoneReg = /^1[3456789]\d{9}$/;
      if (!phoneReg.test(_phone)) {
        //this.$message({ message: "手机号码格式错误", type: "error" });
        this.verifySaveParams = false;
        this.verifyFailMsg = "手机号码格式错误";
        return;
      } else {
        this.verifySaveParams = true;
      }
      var url = `/users/lite/${_phone}`;
      var res = await getLoginName(url);
      if (res.code === 0) {
        let admin_name = res.data ? res.data.name : "";
        this.$set(this.msgReceivePeopleArr[nth], "ReceiverName", admin_name);
        this.$set(this.msgReceivePeopleArr[nth], "isAdminname", true);
        this.verifySaveParams = true;
      } else {
        this.$set(this.msgReceivePeopleArr[nth], "isAdminname", false);
        this.verifySaveParams = false;
        this.verifyFailMsg = "请到用户列表里面创建用户";
        //this.$message({ message: "请到用户列表里面创建用户", type: "error" });
      }
    },
    // 添加审核短信接受人
    addColorSet() {
      this.msgReceivePeopleArr.push({ ReceiverName: "", ReceiverPhone: "" });
    },
    // 删除审核短信接受人
    delMsgReceivePeople(index) {
      this.msgReceivePeopleArr.forEach((item, i) => {
        if (index == i) {
          this.msgReceivePeopleArr.splice(i, 1);
        }
      });
    },
    // 添加分局
    addSubStation() {
      this.subStationArr.push({ Name: "" });
    },
    delSubStation(index) {
      this.subStationArr.forEach((item, i) => {
        if (index == i) {
          this.subStationArr.splice(i, 1);
        }
      });
    },
    // 删除分局
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 4 || columnIndex === 5) {
        // 用于设置要合并的列
        if (rowIndex % 2 === 0) {
          // 用于设置合并开始的行号
          return {
            rowspan: 2,
            colspan: 1,
          };
        } else {
          return {
            rowspan: 0,
            colspan: 0,
          };
        }
      }
    },
    delThisOrgan(id) {
      const self = this;
      self
        .$confirm("确定要删除该签约机构?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          customClass: "warningAlert",
          type: "warning",
        })
        .then(() => {
          self.beganDelOrgan(id);
        })
        .catch(() => {
          self.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },
    // 验证输入值必须是大于0的整数
    checkNumber(obj) {
      var regNumber = /^\+?[1-9][0-9]*$/;
      if (
        obj.param_value.Enable &&
        regNumber.test(obj.param_value.Limit) == false
      ) {
        //this.$message({ message: `${obj.param_name}必须是大于0的整数`, type: "error" });
        this.verifySaveParams = false;
        this.verifyFailMsg = `${obj.param_name}必须是大于0的整数`;
        return false;
      } else {
        this.verifySaveParams = true;
      }
    },
    // 保存设置
    async saveSet() {
      const self = this;
      if (!self.verifySaveParams) {
        self.$message({ message: `${self.verifyFailMsg}`, type: "error" });
        return false;
      }
      self.loading = true;
      const arr = [];
      self.tableData.forEach(function (val) {
        arr.push(val);
      });
      let openMsg = false; // 是否开通了短信通知
      let openApplyCheck = false; // 是否勾选了 申请调阅通知审核方
      arr.forEach(function (val) {
        delete val.create_time
        delete val.system_id
        delete val.last_update_time
        delete val.department_id
        delete val.org_id
        delete val.param_module_id
        delete val.radio_value
        // 如果开通了短信通知 然后勾选了申请调阅审核方  审核方短信接受人要必填
        if (val.param_code == "idcas.forensicsmsnotify" && val.param_value) {
          openMsg = true;
        }
        if (
          val.param_code == "idcas.forensicsmsnotifytemplate" &&
          val.param_value[0].Enable
        ) {
          openApplyCheck = true;
        }
      });
      // 如果开通了短信通知 然后勾选了申请调阅审核方  审核方短信接受人要必填
      if (openMsg && openApplyCheck) {
        let hadInputMsgReceiveInfor = false;
        self.msgReceivePeopleArr.forEach((item) => {
          if (!item.ReceiverName || !item.ReceiverPhone) {
            hadInputMsgReceiveInfor = true;
          }
        });
        if (hadInputMsgReceiveInfor) {
          self.$message({
            message: "审核方短信接收人信息必须填写完整",
            type: "error",
          });
          self.loading = false;
          return false;
        }
      }
      arr.forEach(function (val) {
        // 如果开通了短信通知 然后勾选了申请调阅审核方  审核方短信接受人要必填
        if (val.param_code == "idcas.forensicsmsnotify" && val.param_value) {
          openMsg = true;
        }
        if (
          val.param_code == "idcas.forensicsmsnotifytemplate" &&
          val.param_value[0].Enable
        ) {
          openApplyCheck = true;
        }
        if (val.param_value_type === 8) {
          val.param_options = JSON.stringify(val.param_options);
          val.param_value = val.param_value.join(",");
        }
        if (
          val.param_value_type === 2001 ||
          val.param_value_type === 3002 ||
          val.param_value_type === 3001 ||
          val.param_value_type === 3003 ||
          val.param_value_type === 7 ||
          val.param_value_type === 3004
        ) {
          if (val.param_value_type === 3003) {
            val.param_value = [];
            self.msgReceivePeopleArr.forEach((one) => {
              var obj = {
                ReceiverName: one.ReceiverName,
                ReceiverPhone: one.ReceiverPhone,
              };
              val.param_value.push(obj);
            });
          }
          // 单选按钮
          if (val.param_value_type === 7) {
            val.param_value.forEach((one) => {
              if (one.Value === val.radioValue) {
                one.Enabled = true;
              } else {
                one.Enabled = false;
              }
            });
          }
          // 分局赋值
          if (val.param_value_type === 3004) {
            val.param_value = [];
            self.subStationArr.forEach((one) => {
              var obj = {
                Name: one.Name,
              };
              if (obj.Name) {
                val.param_value.push(obj);
              }
            });
            // 如果一个分局都没填 默认传个值
            if (val.param_value.length == 0) {
              val.param_value.push({ Name: "" });
            }
          }

          // 短信模板
          if (val.param_value_type === 3002) {
            val.param_value = [];
            self.messageArr.forEach((one) => {
              val.param_value.push(one);
            });
          }
          val.param_value = JSON.stringify(val.param_value);
        }
        if (val.param_value_type === 6) {
          val.param_value = JSON.stringify(val.param_value);
        }
      });
      const param = {
        //platform_service: 3,
        module_id: self.searchData.module_id,
        system_id: self.curCriminalInforIdObj.curCriminalInforId,
        param_list: arr,
      };
      console.log("开始调用");
      // 使用防抖函数
      let timerOut = null;
      clearTimeout(timerOut);
      timerOut = setTimeout(() => {
        self.beganSaveSet(param);
      }, 500);
    },
    async beganSaveSet(param) {
      const self = this;
      const res = await saveParam(param);
      if (res.code === 0) {
        self.$message({ message: "保存参数配置成功", type: "success" });
        self.$emit('closeFn')
        self.saveDisabled = false;
        self.getCurModuleId();
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // 获取moduleID
    async getCurModuleId() {
      const self = this;
      const res = await getModuleList({
        system_id: self.curCriminalInforIdObj.curCriminalInforId,
        module_name: "刑侦调阅系统综合参数设置",
      });
      if (res.code === 0) {
        if (res.data.length != 0) {
          res.data.forEach((val) => {
            if (val.module_name == "刑侦调阅系统综合参数设置") {
              self.searchData.module_id = val.id;
            }
          });
        }
        self.getCurParamList();
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // 获取 参数 列表
    async getCurParamList() {
      const self = this;
      self.searchData.system_id = self.curCriminalInforIdObj.curCriminalInforId;
      const res = await getParamList(self.searchData);
      if (res.code === 0) {
        self.loading = false;
        const result = res.data;
        self.tableData = [];
        result.forEach((val) => {
          val.department_id = 0;
          if (val.param_options) {
            val.param_options = JSON.parse(val.param_options);
          }
          if (
            val.param_value_type === 2001 ||
            val.param_value_type === 7 ||
            val.param_value_type === 3002 ||
            val.param_value_type === 3001 ||
            val.param_value_type === 3003 ||
            val.param_value_type === 3004
          ) {
            val.param_value = JSON.parse(val.param_value);
            if (val.param_value_type === 3003) {
              self.msgReceivePeopleArr = [];
              if (val.param_value.length != 0) {
                val.param_value.forEach((one) => {
                  one.isAdminname = true;
                  self.msgReceivePeopleArr.push(one);
                });
              }
            }
            // 单选按钮
            if (val.param_value_type === 7) {
              val.radioValue = "";
              val.param_value.forEach((one) => {
                if (one.Enabled) {
                  val.radioValue = one.Value;
                }
              });
            }
            // 公安分局
            if (val.param_value_type === 3004) {
              self.subStationArr = [];
              if (val.param_value.length != 0) {
                val.param_value.forEach((one) => {
                  self.subStationArr.push(one);
                });
              }
            }
            //短信模板
            if (val.param_value_type === 3002) {
              self.messageArr = [];
              if (val.param_value.length != 0) {
                val.param_value.forEach((one) => {
                  self.messageArr.push(one);
                });
              }
            }
          }
          if (val.param_value_type === 8) {
            if (val.param_value) {
              val.param_value = val.param_value.split(",");
            } else {
              val.param_value = [];
            }
          }
          if (val.param_value_type === 6) {
            if (val.param_value === "true") {
              val.param_value = true;
            } else {
              val.param_value = false;
            }
          }
          self.tableData.push(val);
        });
      } else {
        self.loading = false;
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
  },
  mounted() {
    // 获取模块id
    this.getCurModuleId();
  },
};
</script>
<style lang="less" scoped>
.iconxinzeng {
  padding-right: 4px;
}
.userlist {
  width: 100%;
  height: 100%;
  overflow: hidden !important;
}
.userlist {
  .container {
    height: 100%;
    background: #fff;
    .search-bar {
      height: 32px;
      line-height: 32px;
      .search-bar-label {
        display: inline-block;
        min-width: 74px;
        margin-right: 4px;
        color: #303133;
        vertical-align: middle;
      }
      .search-bar-btn {
        padding: 0px 13px;
        height: 32px;
        line-height: 32px;
        border-radius: 3px;
        border: none;
        cursor: pointer;
      }
      ::v-deep .el-input__inner {
        //   width:200px;
        border-radius: 3px;
      }
      .res-bar-btn {
        padding: 0px 13px;
        height: 32px;
        line-height: 32px;
        border-radius: 3px;
        border: 1px solid #ddd;
        cursor: pointer;
        color: #606266;
      }
      .iconzhengchang {
        padding-right: 5px;
      }
    }
    .table-list {
      position: relative;
      height: calc(100% - 42px);
      border: 1px solid #ebeef5;
      border-bottom: none;
      ::v-deep .el-table--border {
        border: none;
      }
      .pageDiv {
        width: 100%;
        position: absolute;
        bottom: 0px;
        text-align: right;
        padding-right: 5px;
        border-top: 1px solid #ebeef5;
      }
    }
    .iconfont {
      margin: 0px;
    }
    .icon-btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      color: #fff;
      line-height: 24px;
      text-align: center;
      padding: 0px;
      cursor: pointer;
      border-radius: 3px;
      margin-right: 8px;
    }
  }
}
.margin_left_30 {
  margin-left: 30px;
  margin-bottom: 15px;
}
.operateBtnDiv {
  margin-left: 10px;
}
.tableDataCon {
  padding-left: 40px;
  padding-right: 20px;
}
.serviceSetDiv {
  ::v-deep .el-checkbox {
    float: left;
    // width:70px;
    margin-right: 0px;
    height: 32px;
    line-height: 32px;
    padding-right: 8px;
  }
  ::v-deep .el-checkbox__label {
    padding-left: 5px !important;
  }
  .serviceItem {
    height: 32px;
    margin-bottom: 8px;
    clear: both;
  }
  .delayLabel {
    height: 32px;
    line-height: 32px;
    padding-right: 10px;
  }
}
.paramState {
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 4;
  -webkit-box-orient: vertical;
  word-break: break-all;
  span {
    font-size: 14px;
    color: #e6a23c;
    line-height: 20px;
  }
}
::v-deep .messageTemplate {
  .el-checkbox__input {
    top: -1px;
  }
}
.messageTemplate:last-of-type {
  margin-bottom: 0px;
}
.numberInput {
  width: 100px;
  height: 32px;
  color: #606266;
  font-size: 14px;
  line-height: 32px;
  padding: 0 8px;
  padding-right: 0px;
  border: none;
  border: 1px solid #dcdfe6;
}
.codeInput {
  width: 120px;
}
.checkboxCon {
  display: inline-block;
  min-width: 52px;
  height: 19px;
  line-height: 19px;
  margin-right: 8px;
  input {
    display: inline-block;
    position: relative;
    border: 1px solid #dcdfe6;
    border-radius: 2px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    width: 14px;
    height: 14px;
    background-color: #fff;
    top: 3px;
  }
  input[type="checkbox"]:checked {
    background-color: #409eff;
    border-color: #409eff;
  }
  .checkboxLabel {
    padding-left: 10px;
  }
}
.addAddress {
  width: 32px;
  height: 32px;
  line-height: 32px;
  text-align: center;
  border: 1px solid #dcdfe6;
  border-radius: 2px;
  color: #0a70b0;
  cursor: pointer;
  &:hover {
    border-color: #0a70b0;
    background: #0a70b0;
    color: #fff;
  }
}
.delAddress {
  display: inline-block;
  width: 32px;
  height: 32px;
  line-height: 32px;
  text-align: center;
  border: 1px solid #dcdfe6;
  border-radius: 2px;
  cursor: pointer;
  i {
    color: #da4a4a;
    font-size: 16px;
  }
}
.delAddress:hover {
  border-color: #da4a4a;
  background: #da4a4a;
  i {
    color: #fff;
  }
}
</style>
