<template>
   <div class="addInstituteCon">
       <div class="searchBar">
          <span class="search-bar-label">卫健名称 :</span>
            <el-input
                placeholder="请输入卫健名称"
                v-model="searchWeiJianParam.contains_name"
                class="w_186"
                v-on:keyup.enter.native=beganGetWeiJianList
              ></el-input>
            <span class="search-bar-label ml15">所属区域 :</span>
              <el-cascader
              ref="cascaderAddr"
              :style="{width: '220px'}"
              v-model="factoryCity.cityValue"
              :options="factoryCity.cityJson"
              @change="getCityCodeFn"
              @active-item-change="childrenCity">
            </el-cascader>

            <span class="search-bar-label ml15">联系人员 :</span>
            <el-input
                placeholder="请输入姓名/联系电话"
                v-model="searchWeiJianParam.admin_info"
                class="w_186"
                v-on:keyup.enter.native=beganGetWeiJianList
              ></el-input>
               
          <el-button type="primary" size="small" class="ml10" @click="searchWeiJian">查询</el-button>
          <el-button size="small" plain @click="resetFn">重置</el-button>
       </div>
       <div class="tableDivCon">
         <div class="tableDivBox" v-bind:class="{'noTableData':weiJianList.length===0}">
            <template>
              <el-table
                :data="weiJianList"
                style="width: 100%"
                :height="tableheight"
                border
                :default-sort="{prop: 'date', order: 'descending'}"
                ref="multipleTable"
                :row-key="getRowKeys"
                @select="selectCurRow"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55" :reserve-selection="true"></el-table-column>
                <el-table-column label="序号" width="60" fixed="left">
                    <template slot-scope="scope">
                    <span>{{(searchWeiJianParam.offset - 1) * searchWeiJianParam.limit + scope.$index + 1}}</span>
                    </template>
                </el-table-column>
                <common-table :propData="propData"></common-table>
              </el-table>
            </template>
           </div>
          <div class="blockPage">
              <pagination-tool :total="totalWeiJian" :page.sync="searchWeiJianParam.offset" :limit.sync="searchWeiJianParam.limit" @pagination="pageSizeChangeFn"/>
          </div>
        </div>
   </div>
</template>
<script>
import PaginationTool from '@/components/common/PaginationTool'
import CommonTable from './CommonTable'
import { getPayModelInstitution, getInstitutionListLite, getNewAllFirmOrWeiJianList, beganDeleteWeiJian,getFactoryRegion } from '@/api/platform_costomer/institution'
import { getTenanciesLiteFn } from '@/api/platform_operate/costomer'
import { CityLinkedJson } from "@/components/commonJs";
export default {
  components: {
    CommonTable,
    PaginationTool,
  },
  props:{
    city: Object
  },
  inject:['operateSystemInfo'],
  data () {
    return {
       tableheight: '100%',
       searchWeiJianParam: {
         contains_name: '',
         province_code: '',
         city_code: '',
         district_code: '',
         admin_info: '',
         institution_ids: [],
         type: 1,
         offset:1,
         limit: 10,
       },
       factoryCity: {
        cityValue: [],
        cityJson: [],
        city_parmas: {
          parent_code: "1",
          level: 1,
          type:1,
        },
      },
       choosedSeviceTableArr: [],
       weiJianList: [],
       totalWeiJian: 0,
       propData: [
        { prop: 'name', label: '卫健名称', width: 200 },
        { prop: 'abbreviation', label: '卫健简称', width: 120 },
        { prop: 'code', label: '卫健代码', width: 120 },
        { prop: 'region', label: '卫健区域', width: 200},
        { prop: 'institution_count', label: '机构数', width: 70 },
        { prop: 'admin_name', label: '联系人', width: 100 },
        { prop: 'admin_phone', label: '联系电话', width: 120 },
        { prop: 'remark', label: '备注信息'},
      ],
      addInstituteParams: {
        institution_ids: []
      },
      choosedWeiJianArr: [],
    }
  },
  methods: {
    selectCurRow (selection, row) {
      this.$emit('dealselectWeiJianCurRow', selection, row)
    },
    handleSelectionChange (val) {
      this.choosedWeiJianArr = val
      this.$emit('selectWeiJianListFn', val)
    },
    // 获取城市json
    async getCityJsonFn(params) {
      var self = this;
      const res = await getFactoryRegion(params);
      if (res.code === 0) {
        self.factoryCity.cityJson = CityLinkedJson(
          res.data,
          self.factoryCity.cityJson,
          params
        );
      }
    },
    async childrenCity(val) {
      var self = this;
      val.forEach((item, i) => {
        self.factoryCity.city_parmas.parent_code = item;
        self.factoryCity.city_parmas.level = i + 2;
      });
      await self.getCityJsonFn(self.factoryCity.city_parmas);
    },
    // 分页
    pageSizeChangeFn (info) {
      this.searchWeiJianParam.offset = info.page
      this.searchWeiJianParam.limit = info.limit
      this.beganGetWeiJianList()
    },
    getCityCodeFn (val) {
      var self = this
      var arr = self.getCascaderObj(val, self.factoryCity.cityJson)
      arr.forEach((item, i) => {
        if (i === 0) {
          self.searchWeiJianParam.province_code = item.value
        } else if (i === 1) {
          self.searchWeiJianParam.city_code = item.value
        } else if (i === 2) {
          self.searchWeiJianParam.district_code = item.value
        }
      })
      self.beganGetWeiJianList()
    },
    getCascaderObj (val, opt) {
      return val.map(function (value, index, array) {
        for (var itm of opt) {
          if (itm.value === value) { opt = itm.children; return itm }
        }
        return null
      })
    },
    // 重置
    resetFn () {
      this.searchWeiJianParam = this.$options.data().searchWeiJianParam
      //this.$emit('resetCity')
      this.factoryCity.cityValue = [];
      this.beganGetWeiJianList()
    },
    getRowKeys (row) {
      return row.id
    },
    // 点击查询机构
    searchWeiJian () {
      this.searchWeiJianParam.offset = 1
      this.beganGetWeiJianList()
    },
    // 获取table  机构列表
    async beganGetWeiJianList (choosedWeiJianArr) {
      const self = this
      // self.searchWeiJianParam.institution_ids = []
      // if (self.operateSystemInfo.multipleSelection.length != 0) {
      //   self.operateSystemInfo.multipleSelection.forEach((item) => {
      //     self.searchWeiJianParam.institution_ids.push(item.id)
      //   })
      // }
      const res = await getNewAllFirmOrWeiJianList(self.searchWeiJianParam)
      if (res.code === 0) {
        self.weiJianList = res.data
        if (res.page) {
          self.totalWeiJian = res.page.total_count
        } else {
          self.totalWeiJian = 0
        }
        //if (this.operateSystemInfo.title === '编辑影像共享系统') {
          self.dealTableSelected(choosedWeiJianArr)
        //}
        
      } else {
        self.$message({ type: 'error', message: res.msg })
      }
    },
    dealTableSelected (choosedWeiJianArr) {
      const self = this
      if (!choosedWeiJianArr) {
        return false
      }
      self.$refs.multipleTable.clearSelection()
        //if (self.operateSystemInfo.title === '编辑影像共享系统') {
          self.weiJianList.forEach(itemids => {
            if (choosedWeiJianArr.length != 0) {
               choosedWeiJianArr.forEach(item => {
                if (itemids.id === item.id) {
                  self.$nextTick(() => {
                    self.$refs.multipleTable.toggleRowSelection(itemids, true)
                  })
                }
              })
            }
          })
        //} 
        // else { // 新增的时候
        //    self.choosedWeiJianArr.forEach(itemids => {
        //     self.operateSystemInfo.choosedWeiJianArr.forEach(item => {
        //       if (itemids.id === item.id) {
        //         self.$nextTick(() => {
        //           self.$refs.multipleTable.toggleRowSelection(itemids, true)
        //         })
        //       }
        //     })
        //   })
        // }
    },
  },
  mounted () {
    this.getCityJsonFn(this.factoryCity.city_parmas)
    //this.beganGetWeiJianList()
  }
}
</script>
<style lang="less" scoped>
.addInstituteCon{
  padding:15px;
  padding-bottom:0px;
  ::v-deep .searchBar{
    margin-bottom:15px;
    .search-bar-label{
      display: inline-block;
      width:72px;
    }
    .w_186{
      width:186px;
      .el-input{
        width:186px;
      }
    }
    .w_180{
      width:180px;
      .el-input{
        width:180px;
      }
    }
  }
}
::v-deep.organTableData {
    height:442px;
    .el-table{
      height:100%;
      .el-table__row:last-of-type{
        td{
          border-bottom: none;
        }
      }
    }
    .el-table__body-wrapper{
      height:calc(100% - 40px)!important;
      overflow-y: auto;
    }
    
}
 .blockPage {
  text-align: center;
  border: 1px solid #EBEEF5;
  border-top: none;
}
.dialog_footer {
  padding-right: 0!important;
  border-top: none;
  height: 56px;
  line-height: 56px;
}
::v-deep .tableDivBox{
  height:400px;
  .el-table{
    height:100%;
    .el-table__body-wrapper{
      height:calc(100% - 40px);
      overflow: auto!important;
    }
  }
}
</style>