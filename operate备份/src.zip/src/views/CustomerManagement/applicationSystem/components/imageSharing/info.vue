<template>
  <div class="userinfo">
    <div class="userinfo-title">
      <span class="userinfo-titleinfo">{{ pacsinfo.title }}</span>
      <span
        @click="closeFn"
        class="close-btn iconfont iconchuangjianshibai"
      ></span>
    </div>
    <el-form
      :model="pacsinfo.formInfo"
      ref="imageShareInfo"
      class="demo-ruleForm"
    >
      <div class="contaner">
        <div class="contaner-info">
          <el-row class="contaner-info-title">
            <span class="border-left"></span>基本信息
          </el-row>
          <el-row class="mt20 pl10 pr10">
            <el-form-item>
              <span class="el-form-item__label"
                ><i class="iconfont iconbitian mustIcon"></i>系统名称 ：</span
              >
              <el-input
                v-model="pacsinfo.formInfo.name"
                placeholder="请输入影像共享系统名称"
                style="width: 480px"
              ></el-input>
            </el-form-item>
            <el-form-item class="mt15">
              <span class="el-form-item__label"
                ><i class="iconfont iconbitian mustIcon"></i>系统管理员 ：</span
              >
              <el-input
                v-model="pacsinfo.formInfo.admin_phone"
                @input="changePhone"
                placeholder="请输入管理员电话"
                @blur="getAdminNameFn"
                style="width: 236px"
              ></el-input>
              <el-input
                v-model="pacsinfo.formInfo.admin_name"
                placeholder="请输入管理员姓名"
                :disabled="pacsinfo.isAdminname"
                class="ml10"
                style="width: 236px"
              ></el-input>
            </el-form-item>
            <el-form-item class="mb5">
              <span class="el-form-item__label"
                ><i class="iconfont iconbitian mustIcon"></i>授权产品 ：</span
              >
              <span
                class="system_type"
                :class="{
                  active: pacsinfo.formInfo.product_code === item.code,
                }"
                v-for="(item, index) in serviceList"
                :key="item.code"
                @click="activeSystemFn(index, item.code)"
              >
                <el-tooltip
                  class="item"
                  effect="dark"
                  :content="item.instruction"
                  placement="top-start"
                >
                  <el-button>{{ item.name }}</el-button>
                </el-tooltip>
              </span>
            </el-form-item>
            <el-form-item class="mt15" v-if="pacsinfo.formInfo.product_code">
              <span class="el-form-item__label">开通服务 ：</span>
              <el-checkbox-group
                v-if="
                  serviceList[activesystemIndex] &&
                  serviceList[activesystemIndex].modules.length != 0
                "
                v-model="productObj[pacsinfo.formInfo.product_code]"
                @change="changeService"
              >
                <el-checkbox
                  v-for="(item, index) in serviceList[activesystemIndex]
                    .modules"
                  v-bind:key="index"
                  class="fl openModule"
                  :label="item.code"
                  v-bind:title="item.instruction"
                  border
                  >{{ item.name }}</el-checkbox
                >
              </el-checkbox-group>
              <span class="el-form-item__label noOpenService" v-else
                >暂未授权服务</span
              >
              <!-- <el-checkbox-group v-model="pacsinfo.formInfo.function_services" @change="changeService">
                <el-checkbox v-for="(item,index) in serviceList[activesystemIndex].modules" v-bind:key="index"  class="fl openModule" :label="item.code" v-bind:title="item.instruction" border>{{item.name}}</el-checkbox>
               </el-checkbox-group> -->
            </el-form-item>

            <el-form-item class="mt15">
              <span class="el-form-item__label"
                ><i class="iconfont iconbitian mustIcon"></i>使用期限 ：</span
              >
              <div style="display: flex; align-items: center">
                <el-date-picker
                  v-model="pacsinfo.formInfo.start_date"
                  type="date"
                  placeholder="选择开始期限"
                  value-format="yyyy-MM-dd"
                >
                </el-date-picker>
                <el-radio-group
                  v-model="pacsinfo.formInfo.isIndefinitely"
                  class="ml20"
                >
                  <el-radio :label="true">无期限</el-radio>
                  <el-radio :label="false">
                    <el-date-picker
                      v-model="pacsinfo.formInfo.stop_date"
                      type="date"
                      :disabled="pacsinfo.formInfo.isIndefinitely"
                      placeholder="选择结束期限"
                      value-format="yyyy-MM-dd"
                    >
                    </el-date-picker>
                  </el-radio>
                </el-radio-group>
              </div>
            </el-form-item>
            <el-form-item class="mt15">
              <span class="el-form-item__label"
                ><i class="iconfont iconbitian mustIcon"></i>系统状态 ：</span
              >
              <div style="display: flex; align-items: center; height: 30px">
                <el-radio-group v-model="pacsinfo.formInfo.state">
                  <el-radio :label="10">启用</el-radio>
                  <el-radio :label="-2">停用</el-radio>
                </el-radio-group>
                <el-input
                  v-if="pacsinfo.formInfo.state === -2"
                  v-model="pacsinfo.formInfo.reason"
                  class="ml10"
                  placeholder="备注"
                  style="width: 180px"
                />
              </div>
            </el-form-item>

            <weChat
              :weChatObj="pacsinfo.providersObj"
              :inputWidth="'236px'"
            ></weChat>
          </el-row>
        </div>
        <div class="contaner-info contaner-bottom">
          <el-row class="contaner-info-title instituteInfor">
            <el-col :span="12">
              <span class="border-left"></span>使用机构
              <span class="ml5 clr_oarange" v-if="pacsinfo.institution_count"
                >({{ pacsinfo.institution_count }}家)</span
              >
            </el-col>
            <el-col :span="12" class="tr clr_0a">
              <span
                class="function-btn bg_e6 clr_ff"
                @click="isAddInstution"
                v-if="curChooseProductCode == 'RemoteBackup'"
              >
                <i class="iconfont iconxinzeng"></i>添加机构
              </span>
              <div
                v-if="
                  curChooseProductCode == 'ImageSupervision' ||
                  curChooseProductCode == 'ImageStorage'
                "
              >
                <span
                  class="function-btn bg_e6 clr_ff"
                  v-if="addTypeVal == 1"
                  @click="isAddInstution"
                >
                  <span><i class="iconfont iconxinzeng"></i>添加机构</span>
                </span>

                <span
                  class="function-btn bg_e6 clr_ff"
                  v-if="addTypeVal == 2 && isWeiJianTenancy"
                  @click="isAddWeiJian"
                  :class="{
                    disabledAdd: pacsinfo.multipleSelection.length == 0,
                  }"
                >
                  <span><i class="iconfont iconxinzeng"></i>添加卫健</span>
                </span>

                <span
                  class="function-btn bg_e6 clr_ff"
                  v-if="addTypeVal == 3"
                  @click="isAddFirm"
                  :class="{
                    disabledAdd: pacsinfo.multipleSelection.length == 0,
                  }"
                >
                  <span><i class="iconfont iconxinzeng"></i>添加厂商</span>
                </span>
              </div>
            </el-col>
          </el-row>
          <!-- 影像中心--->
          <div
            class="contaner-info-list"
            v-if="
              pacsinfo.multipleSelection.length > 0 &&
              curChooseProductCode == 'RemoteBackup'
            "
          >
            <div class="contaner-info-list-item clr_999">
              <div class="width_60">操作</div>
              <div class="width_200">机构名称</div>
              <!-- <div class="flex_1">选择科室</div> -->
            </div>
            <div
              class="contaner-info-list-item"
              v-for="(item, index) in pacsinfo.multipleSelection"
              :key="index"
            >
              <div class="width_60">
                <!-- <span @click="delInstitutionFn(item.id)" class="icon-btn bg_f5" type="text" size="small"  title="删除"><i class="iconfont icondongjie"></i></span> -->
                <span
                  @click="delInstitutionFn(item.id, 'notWeiJian')"
                  class="clr_da pointer"
                  >移除</span
                >
              </div>
              <div class="width_300">{{ item.name }}</div>
            </div>
          </div>

          <!--影像云归档 和 影像主索引--->
          <div
            class="contaner-info-list"
            v-if="
              curChooseProductCode == 'ImageStorage' ||
              curChooseProductCode == 'ImageSupervision'
            "
          >
            <span class="addInstitute timeChoose">
              <el-radio-group v-model="addTypeVal" @change="changeAddType()">
                <!-- <el-radio-button :label="item.value" v-for="(item, index) in addTypeArr" :key="index">{{item.name}}</el-radio-button> -->
                <el-radio-button :label="1"
                  >机构({{
                    pacsinfo.multipleSelection.length
                  }})</el-radio-button
                >
                <el-radio-button :label="2" v-if="isWeiJianTenancy"
                  >卫健({{
                    pacsinfo.choosedWeiJianArr.length
                  }})</el-radio-button
                >
                <el-radio-button
                  :label="3"
                  v-if="curChooseProductCode == 'ImageSupervision'"
                  >厂商({{ pacsinfo.choosedFirmArr.length }})</el-radio-button
                >
              </el-radio-group>
            </span>
            <!--已添加的机构-->
            <div class="curTabContent" v-if="addTypeVal == 1">
              <div class="contaner-info-list-item clr_999">
                <div class="width_60">操作</div>
                <div class="width_200">机构名称</div>
                <!-- <div class="flex_1">选择科室</div> -->
              </div>
              <div
                class="contaner-info-list-item"
                v-for="(item, index) in pacsinfo.multipleSelection"
                :key="index"
              >
                <div class="width_60">
                  <span
                    @click="delInstitutionFn(item.id, 'weiJian')"
                    class="clr_da pointer"
                    >移除</span
                  >
                </div>
                <div class="width_300">{{ item.name }}</div>
              </div>
            </div>
            <!--已添加的卫健-->
            <div class="curTabContent" v-if="addTypeVal == 2">
              <div class="contaner-info-list-item clr_999">
                <div class="w_100">操作</div>
                <div class="w_200">卫健名称</div>
                <div class="w_200">卫健区域</div>
                <div class="w_100">机构数</div>
                <!-- <div class="flex_1">选择科室</div> -->
              </div>
              <div
                class="contaner-info-list-item"
                v-for="(item, index) in pacsinfo.choosedWeiJianArr"
                :key="index"
              >
                <div class="w_100">
                  <span
                    @click="watchWeiJianOrFirm(item, 'weiJian')"
                    class="clr_0a pointer"
                    >设置</span
                  >
                  <span
                    @click="delWeiJianFn(item.id)"
                    class="clr_da pointer ml10"
                    >移除</span
                  >
                </div>
                <div class="w_200">{{ item.name }}</div>
                <div class="w_200 belongRegion">{{ item.region }}</div>
                <div class="w_100">{{ item.institutions.length }}</div>
              </div>
            </div>

            <!--已添加的厂商-->
            <div class="curTabContent" v-if="addTypeVal == 3">
              <div class="contaner-info-list-item clr_999">
                <div class="w_100">操作</div>
                <div class="w_200">厂商名称</div>
                <div class="w_200">厂商类型</div>
                <div class="w_100">机构数</div>
                <!-- <div class="flex_1">选择科室</div> -->
              </div>
              <div
                class="contaner-info-list-item"
                v-for="(item, index) in pacsinfo.choosedFirmArr"
                :key="index"
              >
                <div class="w_100">
                  <span
                    @click="watchWeiJianOrFirm(item, 'firm')"
                    class="clr_0a pointer"
                    >设置</span
                  >
                  <span @click="delFirmFn(item.id)" class="clr_da pointer ml10"
                    >移除</span
                  >
                </div>
                <div class="w_200">{{ item.name }}</div>
                <div class="w_200 belongRegion">
                  {{ item.category_describe }}
                </div>
                <div class="w_100">{{ item.institution_count }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="mt15">
        <el-button
          type="primary"
          size="medium"
          @click="submitForm('imageShareInfo', 'commit')"
          >提交</el-button
        >
        <el-button size="medium" @click="submitForm('imageShareInfo', 'cancel')"
          >取消</el-button
        >
      </div>
    </el-form>
    <el-dialog
      title="选择机构"
      :append-to-body="true"
      :visible.sync="pacsinfo.isChioseOrgan"
      width="700px"
      v-dialogDrag
    >
      <div class="CAdialog">
        <div>
          <el-input
            v-model="pacsinfo.serchName"
            placeholder="机构名称"
            style="width: 240px"
          ></el-input>
          <el-button
            type="primary"
            size="small"
            class="ml10"
            @click="beganSerchListFn"
            >查询</el-button
          >
        </div>
        <el-table
          ref="institutions"
          class="mt10"
          border
          :data="pacsinfo.institutionList"
          :header-cell-style="{ background: '#DCDFE6', color: '#1E1D22' }"
          :row-key="getRowKeys"
          @select="selectCurRow"
          @selection-change="handleSelectionChange"
        >
          <el-table-column
            type="selection"
            width="55"
            :reserve-selection="true"
          ></el-table-column>
          <el-table-column
            prop="name"
            label="机构名称"
            width="300"
          ></el-table-column>
          <el-table-column
            prop="admin_name"
            label="联系人"
            width="150"
          ></el-table-column>
          <el-table-column
            prop="admin_phone"
            label="联系电话"
          ></el-table-column>
        </el-table>
        <div class="blockPage">
          <pagination-tool
            :layout="pageLayout"
            :total="pageInfo.total_count"
            :page.sync="pageInfo.page_index"
            :limit.sync="pageInfo.page_size"
            @pagination="pageSizeChangeFn"
          />
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="ChoiceOrganFn('cancel')">取 消</el-button>
        <el-button type="primary" @click="ChoiceOrganFn('commit')"
          >确定</el-button
        >
      </div>
    </el-dialog>

    <el-dialog
      title="选择卫健"
      :append-to-body="true"
      :visible.sync="pacsinfo.isChioseWeiJian"
      width="1000px"
      v-dialogDrag
    >
      <addWeiJian
        ref="addWeiJian"
        @dealselectWeiJianCurRow="dealselectWeiJianCurRow"
        @selectWeiJianListFn="selectWeiJianListFn"
      ></addWeiJian>
      <div slot="footer" class="dialog-footer">
        <el-button @click="ChoiceWeiJianFn('cancel')">取 消</el-button>
        <el-button type="primary" @click="ChoiceWeiJianFn('commit')"
          >确定</el-button
        >
      </div>
    </el-dialog>

    <el-dialog
      title="选择厂商"
      :append-to-body="true"
      :visible.sync="pacsinfo.isChioseFirm"
      width="1000px"
      v-dialogDrag
    >
      <addFirm
        ref="addFirm"
        @dealselectFirmCurRow="dealselectFirmCurRow"
        @selectFirmListFn="selectFirmListFn"
      ></addFirm>
      <div slot="footer" class="dialog-footer">
        <el-button @click="ChoiceFirmFn('cancel')">取 消</el-button>
        <el-button type="primary" @click="ChoiceFirmFn('commit')"
          >确定</el-button
        >
      </div>
    </el-dialog>

    <!-- 查看厂商 -->
    <el-dialog
      title="本系统内管理机构设置"
      :top="'10vh'"
      :visible.sync="showWeiJianOrFirmDetailAlert"
      width="950px"
      :close-on-click-modal="false"
      v-dialogDrag
      append-to-body
    >
      <watchWeiJianOrFirmDetail
        ref="weiJianOrFirmDetail"
        :type="addTypeStr"
      ></watchWeiJianOrFirmDetail>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeWatchFirmOrWeiJianDetail">关 闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import Mgr from "@/utils/SecurityService";
import weChat from "@/components/common/weChat";
import PaginationTool from "@/components/common/PaginationTool";
import addWeiJian from "./components/addWeiJian";
import addFirm from "./components/addFirm";
import watchWeiJianOrFirmDetail from "./components/watchWeiJianOrFirmDetail";
import { getCurTenancyType } from "@/api/commonHttp";
export default {
  components: {
    PaginationTool,
    weChat,
    addWeiJian,
    addFirm,
    watchWeiJianOrFirmDetail,
  },
  props: {
    pacsinfo: Object,
    productObj: Object,
    serviceList: Array,
    pageInfo: Object,
    getDetailFinished: Boolean,
  },
  data() {
    return {
      activesystemIndex: -1,
      curChooseProductCode: "",
      showWeiJianOrFirmDetailAlert: false,
      pageLayout: "total, prev, pager, next, jumper",
      addTypeStr: "firm",
      addTypeVal: 1,
      isWeiJianTenancy: false,
      addTypeArr: [
        {
          name: "机构",
          value: 1,
        },
        {
          name: "卫健",
          value: 2,
        },
        {
          name: "厂商",
          value: 3,
        },
      ],
    };
  },
  watch: {
    getDetailFinished: function (val) {
      if (!val) {
        return;
      }
      console.log("this.serviceList", this.serviceList);
      let productIndex;
      if (this.serviceList.length != 0) {
        this.serviceList.forEach((one, j) => {
          if (this.pacsinfo.formInfo.product_code == one.code) {
            productIndex = j;
          }
        });
      }
      this.activesystemIndex = productIndex;
    },
  },
  methods: {
    // 获取当前客户类型
    async beganGetTenancyType() {
      const manager = new Mgr();
      const user = await manager.getRole();
      const tenancy_id =
        sessionStorage.getItem("curTenancyId") || user.profile.tenancy_id;
      if (user) {
        const res = await getCurTenancyType({ tenancy_id: tenancy_id });
        if (res.code === 0) {
          if (res.data.type == 4) {
            // 如果客户类型是卫健委
            this.isWeiJianTenancy = true;
          } else {
            this.isWeiJianTenancy = false;
          }
        } else {
          this.$message({ type: "error", message: res.msg });
        }
      }
    },
    closeWatchFirmOrWeiJianDetail() {
      const self = this;
      self.showWeiJianOrFirmDetailAlert = false;
      self.$nextTick(() => {
        let disable_institution_idsArr = [];
        if (self.$refs.weiJianOrFirmDetail.instituteList.length != 0) {
          self.$refs.weiJianOrFirmDetail.instituteList.forEach((item) => {
            if (item.is_disable) {
              disable_institution_idsArr.push(item.id);
            }
          });
        }

        if (self.pacsinfo.choosedWeiJianArr.length != 0) {
          self.pacsinfo.choosedWeiJianArr.forEach((one) => {
            if (
              one.id == self.$refs.weiJianOrFirmDetail.weiJianOrFirmDetailObj.id
            ) {
              one.disable_institution_ids = disable_institution_idsArr;
            }
          });
        }

        if (self.pacsinfo.choosedFirmArr.length != 0) {
          self.pacsinfo.choosedFirmArr.forEach((one) => {
            if (
              one.id == self.$refs.weiJianOrFirmDetail.weiJianOrFirmDetailObj.id
            ) {
              one.disable_institution_ids = disable_institution_idsArr;
            }
          });
        }
      });
    },
    closeFn() {
      this.activesystemIndex = -1;
      this.$emit("closeFn");
    },
    changePhone() {
      this.$emit("changePhone");
    },
    watchWeiJianOrFirm(item, type) {
      const self = this;
      self.addTypeStr = type;
      //console.log(item.disable_institution_ids)
      const id = item.id;
      self.showWeiJianOrFirmDetailAlert = true;
      self.$nextTick(() => {
        self.$refs.weiJianOrFirmDetail.getCurFirmOrWeiJianDetail(id);
        self.$refs.weiJianOrFirmDetail.searchInstitutionParam.factory_id = id;
        self.$refs.weiJianOrFirmDetail.searchInstitutionParam.business_id =
          self.pacsinfo.formInfo.id;
        self.$refs.weiJianOrFirmDetail.searchInstitutionParam.institution_ids =
          [];
        self.$refs.weiJianOrFirmDetail.disable_institution_ids = [];
        if (item.disable_institution_ids) {
          self.$refs.weiJianOrFirmDetail.disable_institution_ids = JSON.parse(
            JSON.stringify(item.disable_institution_ids)
          );
        }
        if (self.pacsinfo.multipleSelection.length != 0) {
          self.pacsinfo.multipleSelection.forEach((item) => {
            self.$refs.weiJianOrFirmDetail.searchInstitutionParam.institution_ids.push(
              item.id
            );
          });
        }
        self.$refs.weiJianOrFirmDetail.getCurFactoryInstitution();
      });
    },
    submitForm(formName, type) {
      var info = {
        formName: formName,
        refs: this.$refs,
        type: type,
      };
      if (type == "cancel") {
        this.activesystemIndex = -1;
      }
      this.$emit("submitForm", info);
    },
    activeSystemFn(index, code) {
      if (this.activesystemIndex != index) {
        this.$emit("activeSystemFn", index, code);
      }
      this.curChooseProductCode = code;
      this.activesystemIndex = index;
    },
    changeService(arr) {
      this.$emit("changeService", arr);
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    selectCurRow(selection, row) {
      this.$emit("dealselectCurRow", selection, row);
    },
    dealselectWeiJianCurRow(selection, row) {
      this.$emit("dealselectWeiJianCurRow", selection, row);
    },
    dealselectFirmCurRow(selection, row) {
      this.$emit("dealselectFirmCurRow", selection, row);
    },
    handleSelectionChange(val) {
      this.$emit("selectInstitionListFn", val);
    },
    selectWeiJianListFn(val) {
      this.$emit("selectWeiJianListFn", val);
    },
    selectFirmListFn(val) {
      this.$emit("selectFirmListFn", val);
    },
    delInstitutionFn(_id, type) {
      this.$emit("delInstitutionFn", _id, type);
    },
    delWeiJianFn(id) {
      const self = this;
      self
        .$confirm("是否删除这个卫健？", "删除信息", {
          distinguishCancelAndClose: true,
          confirmButtonText: "删除",
          cancelButtonText: "取消",
        })
        .then(() => {
          self.pacsinfo.choosedWeiJianArr.forEach((item, i) => {
            if (item.id === id) {
              // self.$nextTick(() => {
              //   if (self.$refs.addWeiJian.weiJianList.length > 0) {
              //     self.$refs.addWeiJian.$refs.multipleTable.toggleRowSelection(item, false)
              //   }
              // })
              self.pacsinfo.choosedWeiJianArr.splice(i, 1);
              self.$message({
                type: "success",
                message: "删除成功",
              });
            }
          });
        });
    },
    delFirmFn(id) {
      const self = this;
      self
        .$confirm("是否删除这个厂商？", "删除信息", {
          distinguishCancelAndClose: true,
          confirmButtonText: "删除",
          cancelButtonText: "取消",
        })
        .then(() => {
          self.pacsinfo.choosedFirmArr.forEach((item, i) => {
            if (item.id === id) {
              // self.$nextTick(() => {
              //   if (self.$refs.addFirm.firmList.length > 0) {
              //     self.$refs.addFirm.$refs.multipleTable.toggleRowSelection(item, false)
              //   }
              // })

              self.pacsinfo.choosedFirmArr.splice(i, 1);
              self.$message({
                type: "success",
                message: "删除成功",
              });
            }
          });
        });
    },
    ChoiceOrganFn(type) {
      this.$emit("ChoiceOrganFn", type);
    },
    ChoiceWeiJianFn(type) {
      this.$emit("ChoiceWeiJianFn", type);
    },
    ChoiceFirmFn(type) {
      this.$emit("ChoiceFirmFn", type);
    },
    getAdminNameFn(val) {
      this.$emit("getAdminNameFn", val);
    },
    getSerchName(val) {
      this.$emit("getSerchName", val);
    },
    beganSerchListFn() {
      this.$emit("beganSerchListFn");
    },
    changeAddType() {},
    isAddInstution() {
      this.$emit("isAddInstution");
    },
    isAddWeiJian() {
      const self = this;
      if (self.pacsinfo.multipleSelection.length == 0) {
        return false;
      }
      self.$emit("isAddWeiJian", self.pacsinfo.multipleSelection);
    },
    isAddFirm() {
      if (this.pacsinfo.multipleSelection.length == 0) {
        return false;
      }
      this.$emit("isAddFirm");
    },
    pageSizeChangeFn(info) {
      this.$emit("pageSizeChangeFn", info, this.pacsinfo.serchName);
    },
    CheckOfficeidsFn(val) {
      this.$emit("CheckOfficeidsFn", val);
    },
    getRowKeys(val) {
      // this.$emit('getRowKeys', val)
      return val.id;
    },
  },
};
</script>
<style lang="less" scoped>
.userinfo {
  width: 800px;
  padding: 0px 25px;
  ::v-deep .el-select,
  .el-select__tags {
    display: block !important;
    width: 350px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .userinfo-title {
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    .userinfo-titleinfo {
      font-size: 18px;
      color: #1f2f3d;
      font-weight: bold;
    }
    .close-btn {
      position: absolute;
      right: 0px;
      top: 0px;
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .contaner {
    border: 1px solid #dcdfe6;
    height: calc(100vh - 120px);
    .contaner-info {
      // border-bottom: 1px dashed #dcdfe6;
      padding-bottom: 20px;
      .el-form-item__label {
        width: 120px;
      }
      .noOpenService {
        color: #999;
        width: auto;
      }
      .openModule {
        height: 36px;
        line-height: 36px;
        padding: 0 15px;
        border-radius: 3px;
        border: 1px solid #dcdfe6;
        margin-right: 10px;
        color: #0a70b0;
        cursor: pointer;
        margin-bottom: 5px;
        ::v-deep .el-checkbox__label {
          padding-left: 0px;
        }
      }
      .openModule.el-checkbox.is-bordered.is-checked {
        background: url("../../../../../assets/images/common/checkboxBg.png")
          right bottom no-repeat;
      }
      .openModule {
        ::v-deep .el-checkbox__inner {
          display: none;
        }
      }
      .openModule:hover {
        background: rgba(10, 112, 176, 0.6);
        color: #fff;
      }
      .instituteInfor {
        border-top: 1px dashed #dcdfe6;
      }
      .contaner-info-title {
        height: 40px;
        line-height: 40px;
        background: rgba(250, 250, 253, 1);
        color: #1f2f3d;
        padding: 0px 10px;
        .border-left {
          display: inline-block;
          width: 3px;
          height: 14px;
          background: rgba(9, 113, 176, 1);
          margin-right: 7px;
          vertical-align: middle;
          position: relative;
          top: -1.5px;
        }
      }
      ::v-deep .system_type {
        display: inline-block;
        padding: 0px 20px;
        height: 36px;
        line-height: 34px;
        border: 1px solid #dcdfe6;
        border-radius: 18px;
        color: #0a70b0;
        cursor: pointer;
        margin: 0px 5px;
        .el-button {
          padding: 0px;
          border: none;
        }
        .el-button:hover {
          background: #fff;
        }
      }
      .system_type:hover {
        border-color: #0a70b0;
      }
      .system_type.active {
        background: #0a70b0;
        color: #fff;
        border-color: #0a70b0;
        ::v-deep .el-button {
          background: #0a70b0;
          color: #fff;
        }
      }
      .contaner-info-list {
        padding: 5px 20px 0 20px;
        overflow: auto;
      }
      .contaner-info-list-item {
        display: flex;
        min-height: 45px;
        align-items: center;
        border-bottom: 1px solid #e4e7ed;
        .width_60 {
          width: 60px;
        }
        .width_300 {
          width: 300px;
        }
        .icon-btn {
          display: inline-block;
          width: 24px;
          height: 24px;
          color: #fff;
          line-height: 24px;
          text-align: center;
          padding: 0px;
          cursor: pointer;
          border-radius: 3px;
          margin-right: 8px;
        }
        .depspan {
          display: inline-block;
          padding: 0px 3px;
          color: #333;
        }
      }
      .authorize-img {
        width: 48px;
        height: 48px;
        vertical-align: middle;
      }
      .clr_88 {
        color: #888888;
      }
    }
    .contaner-bottom {
      height: calc(100% - 334px);
      padding-bottom: 0px !important;
      .contaner-info-list {
        height: calc(100% - 40px);
      }
    }
  }
  .operate-btn {
    width: 84px;
    height: 36px;
    line-height: 36px;
    border-radius: 3px;
    padding: 0px;
    border: none;
    border: 1px solid #dcdfe6;
  }
  .bg_e6 {
    background: #e6a23c;
  }
  .bg_f5 {
    background: #f56c6c;
  }
  .bg_0c {
    background: #0c83cd;
  }
  .bg_00 {
    background: #00ad78;
  }
  .w_300 {
    width: 300px;
  }
}
.CAdialog {
  padding: 10px 20px 0 20px;
  ::v-deep .el-table {
    height: 447px;
    th {
      background: #f5f5f5 !important;
    }
    .el-table__body-wrapper {
      height: calc(100% - 40px);
      overflow-y: auto;
    }
  }
}
.timeChoose {
  line-height: initial;
  margin-top: 8px;
  ::v-deep .el-radio-group {
    height: 28px;
    line-height: 26px;
    .el-radio-button__inner {
      height: 28px;
      line-height: 26px;
      padding: 0 8px !important;
      color: #303133;
      text-align: center;
    }
    .el-radio-button__orig-radio:checked + .el-radio-button__inner {
      background-color: #0a70b0 !important;
      color: #fff;
    }
  }
}
.disabledAdd {
  background-color: #f5f7fa !important;
  border-color: #e4e7ed;
  color: #c0c4cc;
  cursor: not-allowed;
}
.belongRegion {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  -o-text-overflow: ellipsis;
}
// .curTabContent{
//   .w_300{
//     width:300px;
//   }
//   .w_200{
//     width:200px;
//   }
//   .w_100{
//     width:100px;
//   }
// }
</style>
