<template>
  <div class="comprehensiveSet">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>司法鉴定
          <i class="iconfont iconzhankaishouqi"></i> 综合设置
        </span>
        <span
          @click="closeFn"
          class="fr close-btn iconfont iconchuangjianshibai"
        ></span>
      </div>
    </div>
    <div class="container">
      <div class="tabList">
        <div :class="{ active: activeIndex === 1 }" @click="routePush(1)">
          门户设置
        </div>
        <span class="border_l"></span>
        <div :class="{ active: activeIndex === 2 }" @click="routePush(2)">
          参数设置
        </div>
      </div>
      <div class="myContent">
        <!-- <router-view></router-view> -->
        <homeSet v-if="activeIndex === 1" @closeFn="closeFn"></homeSet>
        <paramsSet v-if="activeIndex === 2" @closeFn="closeFn"></paramsSet>
      </div>
    </div>
  </div>
</template>

<script>
import homeSet from "./homeSet";
import paramsSet from "./paramsSet";
export default {
  name: "comprehensiveSet",
  components: {
    homeSet,
    paramsSet,
  },
  data() {
    return {
      activeIndex: 1,
    };
  },
  created() {
    // if (this.$route.name === 'CIparamsSet') {
    //   this.activeIndex = 2
    // } else {
    //   this.activeIndex = 1
    // }
  },
  methods: {
    closeFn() {
      this.$emit("closeFn");
    },
    routePush(type) {
      this.activeIndex = type;
      // if (type === 1) {
      //   this.$router.push('CIhomeSet')
      // } else {
      //   this.$router.push('CIparamsSet')
      // }
    },
  },
};
</script>

<style lang="less" scoped>
.comprehensiveSet {
  width: 800px;
  height: 100vh;
}
.close-btn {
  position: absolute;
  right: 10px;
  top: 0px;
  color: #9facc3;
  font-size: 24px !important;
  cursor: pointer;
}
.container {
  // height: calc(100% - 46px);
  padding: 10px 0px;
  padding-bottom: 0px;
  height: calc(100% - 46px);
  .tabList {
    display: flex;
    line-height: 20px;
    width: calc(100% - 30px);
    margin: 0 15px;
    border-bottom: 1px solid #dcdfe6;
    div {
      display: inline-block;
      // min-width: 80px;
      padding: 0px 20px;
      text-align: center;
      cursor: pointer;
      padding-bottom: 10px;
      font-weight: 700;
    }
    .border_l {
      display: inline-block;
      width: 1px;
      height: 20px;
      background: #ddd;
      vertical-align: middle;
      // margin-top: 10px;
    }
    .active {
      border-bottom: 3px solid #0a70b0;
      color: #0a70b0;
    }
  }
}
.myContent {
  height: calc(100% - 34px);
  overflow: auto;
}
</style>
