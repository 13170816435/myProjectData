<template>
  <div class="userlist">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>影像共享
          <i class="iconfont iconzhankaishouqi"></i>业务结算
        </span>
      </div>
    </div>
    <div class="container">
      <div class="search-bar">
        <div class="fl">
          <span class="search-bar-label fl">机构名称 :</span>
          <el-input
            class="width_200_input fl"
            v-on:keyup.enter.native="getMySettlementList()"
            v-model="searchData.org_name"
            placeholder="请输入名称关键字"
          ></el-input>
        </div>
        <div class="fl margin_left_15">
          <span class="search-bar-label fl">结算日期 :</span>
          <!-- <el-date-picker
            class="dateInput"
            v-model="timer"
            type="monthrange"
            align="right"
            unlink-panels
            value-format="yyyy-MM"
            range-separator="至"
            start-placeholder="开始月份"
            end-placeholder="结束月份"
            :picker-options="pickerOptions">
            </el-date-picker> -->
          <el-date-picker
            class="dateInput"
            value-format="yyyy-MM"
            @change="getMySettlementList"
            v-model="searchData.begin_date"
            type="month"
            placeholder="选择月"
          >
          </el-date-picker>
        </div>
        <div class="fl margin_left_15">
          <span class="search-bar-label fl">结算状态 :</span>
          <el-select
            v-model="searchData.flag"
            @change="getMySettlementList"
            class="ele-select_32 width_160_select"
            placeholder="请选择"
            style="width: 160px"
          >
            <el-option value="">全部</el-option>
            <el-option
              v-for="(item, index) in checkStuArr"
              :key="index"
              :label="item.name"
              :value="item.value"
            ></el-option>
          </el-select>
        </div>
        <div class="fl operateBtnDiv">
          <el-button
            class="search-bar-btn bg_0a clr_ff"
            @click="getMySettlementList"
            >查询</el-button
          >
          <el-button class="res-bar-btn" @click="resetSearchData"
            >重置</el-button
          >
        </div>
        <div class="tr col">
          <a id="downlink"></a>
          <span @click="importOut" class="function-btn importBtn">
            <i class="iconfont icondaochu"></i>导出
          </span>
        </div>
      </div>
      <div
        class="table-list pageTable mt15"
        v-bind:class="{
          noTableDataActive: noFilingClerk,
          organTableData: true,
          noTableData: tableData.length == 0,
        }"
      >
        <el-table
          v-loading="loading"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          v-loading.fullscreen.lock="true"
          :data="tableData"
          border
          :header-cell-style="{ background: '#F2F2F2', color: '#333' }"
          highlight-current-row
          header-row-class-name="strong"
        >
          <el-table-column type="index" label="序号" width="50">
            <template slot-scope="scope">
              <span>{{ scope.$index + 1 }}</span>
            </template>
          </el-table-column>
          <el-table-column type="index" label="操作" width="50">
            <template slot-scope="scope">
              <span
                class="icon-btn bg_ff9 operateIcon"
                v-if="scope.row.flag != 1"
                @click="beganCheck(scope.row)"
                type="text"
                size="small"
                title="审核"
              >
                <i class="iconfont iconliebiaoshenhe"></i>
              </span>
              <span
                v-else
                class="icon-btn bg_0a operateIcon"
                @click="watch(scope.row)"
                type="text"
                size="small"
                title="查看"
              >
                <i class="iconfont iconchakan"></i>
              </span>
            </template>
          </el-table-column>
          <el-table-column label="结算时间区间" width="230">
            <template slot-scope="scope">
              <span>{{ scope.row.begin_date }}</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="org_name"
            label="机构名称"
            width="220"
          ></el-table-column>
          <el-table-column prop="flag" label="结算状态" width="120">
            <template slot-scope="scope">
              <span class="checkStu" v-if="scope.row.flag === 0">待审核</span>
              <span class="" v-else>审核通过</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="exam_cnt"
            label="结算检查数"
            width="120"
          ></el-table-column>
          <el-table-column
            prop="amount"
            label="结算金额(元)"
            width="140"
          ></el-table-column>
          <el-table-column
            prop="audit_time"
            label="审核时间"
            width="200"
          ></el-table-column>
          <el-table-column prop="audit_desc" label="审核备注">
            <template slot-scope="scope">
              <div
                class="belongToDescption"
                v-bind:title="scope.row.audit_desc"
              >
                {{ scope.row.audit_desc }}
              </div>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <!-- <div class="pageDiv">
        <pagination-tool :total="totalPage" :page.sync="searchData.PageIndex" :limit.sync="searchData.PageSize" @pagination="getMySettlementList"/>
      </div> -->
    </div>
    <el-dialog
      class="checkAlert"
      :title="operateTit"
      :visible.sync="showCheckAlert"
      width="450px"
      height="440px"
      :close-on-click-modal="false"
    >
      <div class="checkCon">
        <div class="checkItem">
          <label class="fl">计算机构:</label>
          <span class="fl">{{ currentDetail.org_name }}</span>
        </div>
        <div class="checkItem">
          <label class="fl">结算时间:</label>
          <span class="fl"
            >{{ currentDetail.begin_date }}~{{ currentDetail.end_date }}</span
          >
        </div>
        <div class="checkItem">
          <label class="fl">结算检查数:</label>
          <span v-if="isCheck" class="fl"
            ><input
              v-model="currentDetail.exam_cnt"
              type="number"
              name=""
              id=""
              min="0"
              class="inspectNum"
            />
            例</span
          >
          <span v-if="!isCheck" class="fl"
            >{{ currentDetail.exam_cnt }} 例
          </span>
        </div>
        <div class="checkItem">
          <label class="fl">结算金额:</label>
          <span class="fl money">{{ currentDetail.amount }}</span
          ><span>元</span>
        </div>
        <div class="checkItem">
          <label class="fl">审核时间:</label>
          <span class="fl">{{ currentDetail.audit_time }}</span>
        </div>
        <div class="checkItem">
          <label class="fl">审核备注:</label>
          <el-input
            v-if="isCheck"
            v-model.trim="currentDetail.audit_desc"
            class="fl remark"
            maxlength="120"
            show-word-limit
            type="textarea"
            size="small"
            placeholder="请输入..."
          ></el-input>
          <span
            v-if="!isCheck"
            class="fl remarkText"
            v-bind:title="currentDetail.audit_desc"
            >{{ currentDetail.audit_desc }}
          </span>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button v-if="isCheck" size="small" @click="showCheckAlert = false"
          >取 消</el-button
        >
        <el-button v-if="isCheck" size="small" type="primary" @click="sureCheck"
          >审核通过</el-button
        >
        <el-button v-if="!isCheck" size="small" @click="showCheckAlert = false"
          >关 闭</el-button
        >
      </span>
    </el-dialog>
  </div>
</template>

<script>
import PaginationTool from "@/components/common/PaginationTool"; // 分页
import {
  getParamModule,
  getParamDataList,
  saveSystemParam,
} from "@/api/seviceCenterManage/paramSet";
import { getSettlementList, examSettlement } from "@/api/shareSystem/index";
export default {
  components: {
    PaginationTool,
  },
  data() {
    return {
      pickerOptions: {
        shortcuts: [
          {
            text: "本月",
            onClick(picker) {
              picker.$emit("pick", [new Date(), new Date()]);
            },
          },
          {
            text: "今年至今",
            onClick(picker) {
              const end = new Date();
              const start = new Date(new Date().getFullYear(), 0);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近六个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setMonth(start.getMonth() - 6);
              picker.$emit("pick", [start, end]);
            },
          },
        ],
      },
      importData: [],
      outFile: "",
      currentDetail: "",
      operateTit: "结算审核",
      isCheck: true,
      showCheckAlert: false,
      timer: "",
      loading: true,
      noFilingClerk: true, // 导入后台有没有列表数据
      currentPage: 1,
      totalPage: 1,
      searchData: {
        begin_date: "",
        end_date: "", // 参数模块
        org_name: "",
        flag: "",
        // PageIndex: 1,
        // PageSize: 20,
        // Sorts: []
      },
      checkStuArr: [
        {
          value: 0,
          name: "待审核",
        },
        {
          value: 1,
          name: "审核通过",
        },
      ],
      serviceCenterData: [],
      tableData: [],
      colConfigs: [
        { prop: "begin_date", label: "结算开始时间", width: "100px" },
        { prop: "end_date", label: "结算结束时间", width: "100px" },
        { prop: "org_name", label: "机构名称", width: "150px" },
        { prop: "flag_desc", label: "结算状态", width: "100px" },
        { prop: "exam_cnt", label: "结算检查数", width: "100px" },
        { prop: "amount", label: "结算金额(元)", width: "100px" },
        { prop: "audit_time", label: "审核时间", width: "100px" },
        { prop: "audit_desc", label: "审核备注", width: "100px" },
      ],
      downloadLoading: false,
    };
  },
  methods: {
    resetSearchData() {
      this.timer = [];
      this.searchData = {
        begin_date: "",
        end_date: "", // 参数模块
        org_name: "",
        flag: "",
        // PageIndex: 1,
        // PageSize: 20,
        // Sorts: []
      };
      var curMonth = this.doHandleDate();
      var lastMonth = this.getLastMonth();
      this.timer.push(lastMonth);
      this.timer.push(curMonth);
      this.getMySettlementList();
    },
    // 导出结算列表
    async importOut() {
      const self = this;
      const downloaddata = [];
      if (self.importData.length === 0) {
        return false;
      }
      self.importData.forEach((item) => {
        downloaddata.push(item);
      });
      const table_header = [];
      const tabel_val = [];
      self.colConfigs.forEach((item, i) => {
        table_header.push(item.label);
        if (item.hasOwnProperty("prop")) {
          tabel_val.push(item.prop);
        } else {
          tabel_val.push(item.slot);
        }
      });
      self.downloadLoading = true;
      let list = [];
      import("@/utils/ExportExcel").then((excel) => {
        const tHeader = table_header; // 表头
        const filterVal = tabel_val; // 值
        // downloaddata.forEach(item=>{
        //   // 在导出的excel表格里 显示 中文 而不是状态值 1或 0

        //   // if (item['flag'] == 0) {
        //   //   item['flag'] = '待审核'
        //   // } else {
        //   //   item['flag'] = '审核通过'
        //   // }
        // 	// Object.keys(item).forEach(vm=>{
        // 	// 	// if(vm!=='publish_total_cnt' && !isNaN(Number(item[vm]))){
        // 	// 	// 	const pert = Math.round(item[vm]/item['publish_total_cnt']*10000/100)
        // 	// 	// 	item[vm] = `${item[vm]}/${pert}%`
        //   //   // }
        //   // })
        //   list.push(item)
        //   console.log(self.tableData)
        // })
        const data = self.formatJson(filterVal, downloaddata);
        excel.export_json_to_excel({
          header: tHeader,
          data,
          filename: "业务结算",
          autoWidth: self.autoWidth,
          bookType: self.bookType,
        });
        self.downloadLoading = false;
      });
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map((v) =>
        filterVal.map((j) => {
          if (j === "timestamp") {
            return parseTime(v[j]);
          } else {
            return v[j];
          }
        })
      );
    },
    // 获取 参数 列表
    async getMySettlementList() {
      var self = this;
      // if (self.timer && self.timer.length != 0) {
      //   self.searchData.begin_date = self.timer[0]
      //   self.searchData.end_date = self.timer[1]
      // } else {
      //   self.searchData.begin_date = ''
      //   self.searchData.end_date = ''
      // }
      self.searchData.end_date = self.searchData.begin_date;
      self.tableData = [];
      self.importData = [];
      const res = await getSettlementList(self.searchData);
      if (res.code === 0) {
        self.loading = false;
        if (res.data.length != 0) {
          res.data.forEach(function (val) {
            val.flag_desc = val.flag === 0 ? "待审核" : "审核通过";
            self.tableData.push(val);
            self.importData.push(val);
          });
        } else {
          self.tableData = [];
          self.importData = [];
        }
        // self.totalPage = res.page.total_count
      } else {
        self.loading = false;
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    //
    beganCheck(obj) {
      //this.currentDetail = obj
      this.currentDetail = {
        amount: obj.amount,
        audit_desc: obj.audit_desc,
        audit_time: obj.audit_time,
        begin_date: obj.begin_date,
        end_date: obj.end_date,
        exam_cnt: obj.exam_cnt,
        flag: obj.flag,
        id: obj.id,
        org_code: obj.org_code,
        org_name: obj.org_name,
      };
      this.operateTit = "结算审核";
      this.isCheck = true;
      this.showCheckAlert = true;
    },
    // 结算查看
    watch(obj) {
      this.currentDetail = {
        amount: obj.amount,
        audit_desc: obj.audit_desc,
        audit_time: obj.audit_time,
        begin_date: obj.begin_date,
        end_date: obj.end_date,
        exam_cnt: obj.exam_cnt,
        flag: obj.flag,
        id: obj.id,
        org_code: obj.org_code,
        org_name: obj.org_name,
      };
      this.operateTit = "结算查看";
      this.isCheck = false;
      this.showCheckAlert = true;
    },
    // 审核通过
    async sureCheck() {
      const self = this;
      const param = {
        id: self.currentDetail.id,
        exam_cnt: self.currentDetail.exam_cnt,
        amount: self.currentDetail.amount,
        flag: 1,
        audit_desc: self.currentDetail.audit_desc,
      };
      const res = await examSettlement(param);
      if (res.code === 0) {
        self.$message({ message: "审核成功", type: "success" });
        self.showCheckAlert = false;
        self.getMySettlementList();
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // csv转sheet对象
    csv2sheet(csv) {
      var sheet = {}; // 将要生成的sheet
      csv = csv.split("\n");
      csv.forEach(function (row, i) {
        row = row.split(",");
        if (i == 0)
          sheet["!ref"] =
            "A1:" + String.fromCharCode(65 + row.length - 1) + (csv.length - 1);
        row.forEach(function (col, j) {
          sheet[String.fromCharCode(65 + j) + (i + 1)] = { v: col };
        });
      });
      return sheet;
    },
    // 将一个sheet转成最终的excel文件的blob对象，然后利用URL.createObjectURL下载
    sheet2blob(sheet, sheetName) {
      sheetName = sheetName || "sheet1";
      var workbook = {
        SheetNames: [sheetName],
        Sheets: {},
      };
      workbook.Sheets[sheetName] = sheet;
      // 生成excel的配置项
      var wopts = {
        bookType: "xlsx", // 要生成的文件类型
        bookSST: false, // 是否生成Shared String Table，官方解释是，如果开启生成速度会下降，但在低版本IOS设备上有更好的兼容性
        type: "binary",
      };
      var wbout = XLSX.write(workbook, wopts);
      var blob = new Blob([s2ab(wbout)], { type: "application/octet-stream" });
      // 字符串转ArrayBuffer
      function s2ab(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xff;
        return buf;
      }
      return blob;
    },
    getLastMonth() {
      //获取上个月日期
      var date = new Date();
      var year = date.getFullYear();
      var month = date.getMonth();
      if (month == 0) {
        year = year - 1;
        month = 12;
      }
      if (month.toString().length == 1) {
        month = "0" + month;
      }
      return year + "-" + month;
    },
    doHandleDate() {
      var myDate = new Date();
      var tYear = myDate.getFullYear();
      var tMonth = myDate.getMonth();
      var m = tMonth + 1;
      if (m.toString().length == 1) {
        m = "0" + m;
      }
      return tYear + "-" + m;
    },
  },
  created() {
    this.timer = [];
    var curMonth = this.doHandleDate();
    var lastMonth = this.getLastMonth();
    this.timer.push(lastMonth);
    this.timer.push(curMonth);
    this.searchData.begin_date = curMonth;
  },
  activated() {
    // 获取参数列表
    this.getMySettlementList();
    // this.outFile = document.getElementById('downlink')
  },
};
</script>
<style lang="less" scoped>
.iconxinzeng {
  padding-right: 4px;
}
.userlist {
  width: 100%;
  height: 100%;
  overflow: hidden !important;
}
.userlist {
  .container {
    height: calc(100% - 47px);
    padding: 15px 15px;
    background: #fff;
    .search-bar {
      height: 32px;
      line-height: 32px;
      .search-bar-label {
        display: inline-block;
        min-width: 74px;
        margin-right: 4px;
        color: #303133;
        vertical-align: middle;
      }
      .search-bar-btn {
        padding: 0px 13px;
        height: 32px;
        line-height: 32px;
        border-radius: 3px;
        border: none;
        cursor: pointer;
      }
      ::v-deep .el-input__inner {
        //   width:200px;
        border-radius: 3px;
      }
      .res-bar-btn {
        padding: 0px 13px;
        height: 32px;
        line-height: 32px;
        border-radius: 3px;
        border: 1px solid #ddd;
        cursor: pointer;
        color: #606266;
      }
      .iconzhengchang {
        padding-right: 5px;
      }
    }
    .table-list {
      position: relative;
      height: calc(100% - 43px);
      border: 1px solid #ebeef5;
      border-bottom: none;
      ::v-deep .el-table--border {
        border: none;
      }
      .pageDiv {
        width: 100%;
        position: absolute;
        bottom: 0px;
        text-align: right;
        padding-right: 5px;
        border-top: 1px solid #ebeef5;
      }
    }
    .iconfont {
      margin: 0px;
    }
    .icon-btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      color: #fff;
      line-height: 24px;
      text-align: center;
      padding: 0px;
      cursor: pointer;
      border-radius: 3px;
      margin-right: 8px;
    }
  }
}
.margin_left_15 {
  margin-left: 15px;
  margin-bottom: 15px;
}
.operateBtnDiv {
  margin-left: 10px;
}
.tableDataCon {
  padding-left: 40px;
  padding-right: 20px;
}
.paramState {
  span {
    font-size: 15px;
    color: #e6a23c;
    line-height: 20px;
  }
}
.dateInput {
  width: 220px;
  ::v-deep .el-input__icon {
    line-height: 32px !important;
  }
  ::v-deep .el-range__close-icon {
    line-height: 26px !important;
  }
}
.importBtn {
  color: #0a70b0;
  border: 1px solid #dcdfe6;
  border-radius: 3px;
  i {
    padding-right: 3px;
  }
}
/* 审核弹窗 */
.checkAlert {
  .checkCon {
    height: 334px;
    padding: 15px 0px;
    .checkItem {
      height: 36px;
      line-height: 36px;
      font-size: 15px;
      margin-bottom: 8px;
      label {
        width: 115px;
        text-align: right;
        margin-right: 5px;
        color: #303133;
      }
      span {
        color: #000;
        // font-weight: bold;
      }
      .inspectNum {
        width: 120px;
        height: 36px;
        line-height: 36px;
        border: 1px solid #dcdfe6;
        border-radius: 3px;
        padding-left: 10px;
        font-size: 15px;
      }
      .money {
        color: #ff9900 !important;
        font-weight: bold;
      }
      .remark {
        width: 260px;
        height: 80px;
        ::v-deep .el-textarea__inner {
          min-height: 80px !important;
          padding: 5px 8px;
          font-size: 15px;
          color: #303133 !important;
          border-radius: 2px;
        }
        ::v-deep .el-input__count {
          line-height: initial;
          bottom: 2px;
        }
      }
      .remarkText {
        width: calc(100% - 120px);
        line-height: 26px !important;
        position: relative;
        overflow: hidden;
        top: 5px;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
      }
    }
  }
}
.operateIcon {
  margin-right: 0 !important;
}
.checkStu {
  color: #ff9900;
}
.el-table td div.belongToDescption {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
