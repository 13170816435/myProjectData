<template>
  <div class="jurisdictionlist">
    <div
      class="list-item aimListItem"
      v-for="(item, index) in systemArr"
      :key="index"
    >
      <!-- 停用标识 -->
      <el-popover
        v-if="item.state === -2"
        placement="top-start"
        trigger="hover"
      >
        <div v-if="item.operator_name">
          停用人：{{ item.operator_name }}({{ item.update_time }})
        </div>
        <div>备注：{{ item.reason }}</div>
        <div slot="reference" class="deactivated-box">
          <div>停用!</div>
          <div class="deactivated-time" v-if="item.update_time">
            {{ item.update_time.substring(0, 11) }}
          </div>
        </div>
      </el-popover>
      <div class="listItemInfor">
        <div class="flex_row">
          <img class="pacs_img" :src="AIM" />
          <div class="shareHead">
            <div class="systemNameTitle overOneLine" v-bind:title="item.name">
              {{ item.name }}
            </div>
            <div class="productIdAndType">
              <span
                class="productIdAndTypeText productName overOneLine"
                :title="item.product_name"
                >{{ item.product_name }}</span
              ><span
                class="productIdAndTypeText idNumber overOneLine"
                :title="'系统ID：' + item.id"
                >{{ item.id }}</span
              >
            </div>
          </div>
        </div>
        <!-- <div class="clr_666 mt10">
        <div class="mt5 overOneLine">
          <span class="clr_999">开通服务：</span>
          <span class="clr_303">{{ item.function_service_names }}</span>
        </div>
      </div> -->
        <div class="flex_row mt10 f14">
          <div
            class="tl adminInfor"
            v-bind:title="'管理人员：' + item.admin_name"
          >
            <span class="clr_999">管理人员：</span
            ><span class="clr_303"
              >{{ item.admin_name }}({{ item.admin_phone }})</span
            >
          </div>
        </div>
        <div class="mt10">
          <div class="flex_row tl f14">
            <div class="useInstituteLabel clr_999">使用机构：</div>
            <div
              class="clr_303 useInstituteNum overOneLine flex_row"
              v-if="item.institution_names.length != 0"
            >
              [{{ item.institution_names.length }}家]
              <tooltip-over
                :content="item.institution_names"
                placement="top-start"
                class="wid190"
                refName="tooltipOver"
              ></tooltip-over>
              <!-- <span
              v-for="(itemname, index) in item.institution_names"
              :key="itemname"
              ><span v-if="index != 0">、</span>{{ itemname }}</span> -->
            </div>
            <div class="clr_303 useInstituteNum overOneLine" v-else>无</div>
          </div>
        </div>
      </div>
      <div class="operateBtnCon">
        <div
          class="operateBtnOneBox"
          v-if="isSetUdi"
          @click="isShowinfoFn('aboutSystem', item)"
        >
          <div class="operateBtnOne">
            <span class="operateBtnTxt">关于</span>
          </div>
        </div>
        <div class="operateBtnOneBox" @click="isShowinfoFn('edit', item)">
          <div class="operateBtnOne">
            <span class="operateBtnTxt">编辑</span>
          </div>
        </div>
        <div
          class="operateBtnOneBox"
          v-if="isShowManageBtn"
          @click="isShowinfoFn('operate', item)"
        >
          <div class="operateBtnOne">
            <span class="operateBtnTxt"
              ><i class="iconfont">&#xe667;</i> 系统管理</span
            >
          </div>
        </div>
      </div>
    </div>

    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="isAiminfo"
      :show-close="false"
      :withHeader="false"
      :wrapperClosable="this.operateSystemInfo.title === '编辑' ? true : false"
      :direction="direction"
      :before-close="handleClose"
    >
      <aim-info
        ref="info"
        :pacsinfo="operateSystemInfo"
        :pageInfo="InstitutionPage"
        @closeFn="closeFn"
        @selectInstitionListFn="selectInstitionListFn"
        @selectCurRowFn="selectCurRow"
        @delInstitutionFn="delInstitutionFn"
        @changePhone="changePhone"
        @serchListFn="serchListFn"
        @getSerchName="getSerchName"
        @getAdminNameFn="getAdminNameFn"
        @pageSizeChangeFn="pageSizeChangeFn"
        @CheckOfficeidsFn="CheckOfficeidsFn"
        @submitForm="submitForm"
        @isAddInstution="isAddInstution"
        @getRowKeys="getRowKeys"
        @instclose="instclose"
      ></aim-info>
    </el-drawer>
  </div>
</template>

<script>
import Vue from "vue";
import Mgr from "@/utils/SecurityService";
import aboutSystem from "tomtaw-system-about";
import JSEncrypt from "jsencrypt";
import { mapGetters } from "vuex";
import aimInfo from "./aimInfo";
import tooltipOver from "../tooltipOver";
import {
  addPacsSystems,
  getInstitutionList,
  getintellingenceOfficeList,
  getPacsSystemsInfoByid,
  putPacsSystems,
  getPasServicecList,
  getServiceTypePower,
  getCallingService,
} from "@/api/platform_costomer/institution";
import {
  getLoginName,
  getConfigurations,
  getLoginUserInfor,
  ownMenu,
} from "@/api/commonHttp";
import moment from "moment";

export default {
  components: {
    aimInfo,
    tooltipOver,
  },
  computed: {
    ...mapGetters(["isSetUdi", "isShowManageBtn"]),
  },
  props: {
    systemArr: Array,
  },
  data() {
    return {
      AIM: require("../../../../../assets/images/AIM.png"), // 智能诊断
      info: "",
      loading: true,
      isAiminfo: false,
      direction: "rtl",
      systemList: [],
      isactive: "",
      operateSystemInfo: {
        title: "新增智能诊断系统",
        serchName: "",
        activesystem: "",
        systemList: [{ code: "", name: "" }], // 授权产品
        isAdminname: false,
        product_name: "",
        providersObj: {
          app_id: "",
          app_secret: "",
          provider_name: "WeChat",
        },
        formInfo: {
          type: 9,
          product_code: "AIM",
          name: "",
          admin_phone: "",
          admin_name: "",
          service_codes: [],
          providers: [],

          isIndefinitely: true, // 是否无限期
          start_date: moment().format("YYYY-MM-DD"), // 开始期限
          stop_date: null, // 结束期限
          state: 10, // 启用状态
          reason: "", // 停用原因
        },
        rules: {
          product_code: [
            { required: true, message: "请选择产品名称", trigger: "change" },
          ],
          name: [
            { required: true, message: "请输入系统名称", trigger: "blur" },
          ],
          admin_phone: [
            { required: true, message: "请输入管理员电话", trigger: "change" },
          ],
          admin_name: [
            { required: true, message: "请输入管理员姓名", trigger: "change" },
          ],
        },
        isChioseOrgan: false,
        institutionList: [], // 机构列表
        deplist: [],
        multipleSelection: [], // 机构列表选中机构
      },
      searchAimData: {
        contains_name: "",
        admin_info: "",
        type: 9,
      },
      isUpdate: false,
      isFirstChange: true,
      InstitutionPage: {
        eof: 1,
        page_index: 1,
        page_size: 10,
        total_count: 0,
        total_pages: 1,
      },
    };
  },
  mounted() {
    const self = this;
    self.$nextTick(() => {
      //self.getAimListFn();
      // 加密函数
      // self.getConfigurationsFn();
    });
  },
  methods: {
    async getConfigurationsFn() {
      const res = await getConfigurations("TransmissionSecurity.RSA.PublicKey");
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) {
          // 注册方法
          const pubKey = res.data; // ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt();
          encryptStr.setPublicKey(pubKey); // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()); // 进行加密
          return data;
        };
      }
    },
    changePhone() {
      if (this.isUpdate) {
        // 是否是第一次改变
        if (this.isFirstChange) {
          this.operateSystemInfo.formInfo.admin_phone = "";
          this.operateSystemInfo.formInfo.admin_name = "";
        }
        this.isFirstChange = false;
      }
    },
    // 系统列表
    async getAimListFn() {
      const res = await getintellingenceOfficeList(this.searchAimData);
      if (res.code === 0) {
        this.loading = false;
        this.systemList = res.data;
      } else {
        this.loading = false;
        this.$message({ type: "error", message: res.msg });
      }
    },
    isAddInstution() {
      if (!this.operateSystemInfo.formInfo.product_code) {
        this.$message({
          type: "warning",
          message: "请选择授权产品！",
        });
        return;
      }
      this.InstitutionPage.page_index = 1;
      this.InstitutionPage.page_size = 10;
      this.getInstitutionListFn();
      this.operateSystemInfo.isChioseOrgan = true;
    },
    // 点击管理处理跳转
    dealSkip(id) {
      const href =
        configUrl.frontEndUrl +
        "/intelligentDiagnosis/accessManagement/dataOverview";
      sessionStorage.setItem("system_id", id);
      window.open(href, "_blank");
      // 请求菜单的方式
      //  sessionStorage.setItem("system_id", id);
      //  this.getOwnMenu(id).then((url) => {
      //     var dev = process.env.NODE_ENV === 'development' ? true : false
      //     if (dev) {
      //       url = url.replace('/operate', '')
      //     }
      //     const {href} = this.$router.resolve({path: url, query: {system_id: id}})
      //     window.open(href, '_blank')
      //   })
    },
    // 获取菜单
    getOwnMenu(id) {
      return new Promise((resolve) => {
        ownMenu().then((res) => {
          if (res.code != 0) {
            this.$message.error(res.msg);
            return;
          }
          let arr = res.data.filter((item) => {
            return item.system_id == id;
          });
          let url;
          if (arr[0].children[0].children.length != 0) {
            url = arr[0].children[0].path + arr[0].children[0].children[0].path;
          } else {
            url = arr[0].children[0].path;
          }
          resolve(url);
        });
      });
    },
    // 操作按钮
    async isShowinfoFn(type, obj) {
      const self = this;
      var id;
      var code;
      var isopen;
      if (obj) {
        id = obj.id;
        code = obj.product_code;
        isopen = obj.is_jump;
      }
      if (type === "add") {
        self.isAiminfo = true;
        self.isUpdate = false;
        self.operateSystemInfo = self.$options.data().operateSystemInfo;
        self.$nextTick(() => {
          self.$refs.info.page = 1;
          self.$refs.info.size = 10;
          self.$refs.info.tableData = [];
          self.$refs.info.choosedInstituteArr = [];
          self.$refs.info.getTabelData2();
          self.$refs.info.$refs.qualityInstituTable.doLayout();
        });
      } else if (type === "operate") {
        // if (obj.type === 1 && !isopen) {
        //   // 只有云pacs 才需要判断
        //   self.$message({
        //     type: "error",
        //     message: "新增的系统，如需管理，请重新登录!",
        //   });
        //   return;
        // }
        if (code) {
          sessionStorage.setItem("currentSystemClass", code);
        }
        if (id) {
          sessionStorage.setItem("lastname", id);
        }
        self.dealSkip(id);
      } else if (type === "aboutSystem") {
        // 关于系统
        var manager = new Mgr();
        manager.getRole().then(function (item) {
          if (item) {
            aboutSystem("aim", item);
          }
        });
      } else {
        await self.$emit("closeAllDrawDetailAlert", "AIM");
        self.isactive = id;
        self.isAiminfo = true;
        self.isUpdate = true;
        self.isFirstChange = true;
        self.operateSystemInfo.title = "编辑";
        const responce = getPacsSystemsInfoByid(id); // 详情接口
        self.operateSystemInfo.multipleSelection = [];
        responce.then((res) => {
          if (res.code === 0) {
            self.operateSystemInfo.product_name = res.data.product_name;
            self.operateSystemInfo.formInfo.product_code =
              res.data.product_code;
            self.operateSystemInfo.formInfo.id = res.data.id;
            self.operateSystemInfo.formInfo.name = res.data.name;
            self.operateSystemInfo.formInfo.admin_phone = res.data.admin_phone;
            self.operateSystemInfo.formInfo.admin_name = res.data.admin_name;
            self.operateSystemInfo.multipleSelection = res.data.institutions;
            self.operateSystemInfo.institution_count =
              res.data.institution_count;
            self.operateSystemInfo.formInfo.service_codes =
              res.data.service_codes;
            self.operateSystemInfo.isAdminname = true;

            self.operateSystemInfo.formInfo.isIndefinitely =
              res.data.stop_date === "无期限" ? true : false;
            self.operateSystemInfo.formInfo.start_date = res.data.start_date;
            self.operateSystemInfo.formInfo.stop_date =
              res.data.stop_date === "无期限" ? "" : res.data.stop_date;
            self.operateSystemInfo.formInfo.state = res.data.state;
            self.operateSystemInfo.formInfo.reason = res.data.reason;

            if (res.data.providers.length != 0) {
              self.operateSystemInfo.providersObj = res.data.providers[0];
            }
            // 获取已绑定的机构 和初始化分页
            self.$refs.info.page = 1;
            self.$refs.info.size = 10;
            self.$refs.info.choosedInstituteArr = res.data.institutions;
            self.$refs.info.getTabelData2();
            self.$nextTick(() => {
              self.$refs.info.$refs.qualityInstituTable.doLayout();
            });
          }
        });
      }
    },
    // 手机号姓名匹配
    async getAdminNameFn() {
      var _phone = this.operateSystemInfo.formInfo.admin_phone;
      var phoneReg = /^1[3456789]\d{9}$/;
      if (!phoneReg.test(_phone)) {
        return;
      }
      var url = `/users/lite/${_phone}`;
      var res = await getLoginName(url);
      if (res.code === 0) {
        this.operateSystemInfo.formInfo.admin_name = res.data
          ? res.data.name
          : "";
        this.operateSystemInfo.isAdminname = true;
      } else {
        this.operateSystemInfo.isAdminname = false;
        this.operateSystemInfo.formInfo.admin_name = "";
      }
    },
    handleClose(done) {
      done();
    },
    // 关闭 选择机构
    instclose() {
      this.operateSystemInfo.institutionList.forEach((item) => {
        this.$nextTick(() => {
          this.$refs.info.$refs.institutions.toggleRowSelection(item, false);
        });
      });
      this.operateSystemInfo.isChioseOrgan = false;
    },
    closeFn() {
      var info = {
        type: "cancel",
        refs: this.$refs["info"].$refs,
        formName: "formInfo",
      };
      this.submitForm(info);
    },
    // 获取机构列表
    async getInstitutionListFn() {
      const self = this;
      let filter_system_id = "";
      if (this.operateSystemInfo.title !== "新增智能诊断系统") {
        filter_system_id = "&filter_system_id=" + this.isactive;
      }
      // 机构的获取 云pacs 跟 集中预约有区别的
      const _url =
        "/institutions?is_show_office=true" +
        "&offset=" +
        this.InstitutionPage.page_index +
        "&limit=" +
        this.InstitutionPage.page_size +
        "&name=" +
        this.operateSystemInfo.serchName +
        filter_system_id;
      const res = await getInstitutionList(_url);
      self.$nextTick(() => {
        self.$refs.info.$refs.institutions.clearSelection();
      });
      if (res.code === 0) {
        res.data.forEach((item) => {
          item.office_ids = [];
          if (item.offices.length === 1) {
            item.office_ids[0] = item.offices[0].id;
          }
        });
        self.operateSystemInfo.institutionList = res.data;
        self.InstitutionPage = res.page;
        if (self.operateSystemInfo.title === "编辑") {
          // 勾上已选中的
          res.data.forEach((itemids) => {
            self.operateSystemInfo.multipleSelection.forEach((item) => {
              if (itemids.id === item.id) {
                self.$nextTick(() => {
                  self.$refs.info.$refs.institutions.toggleRowSelection(
                    itemids,
                    true
                  );
                });
                itemids.office_ids = item.office_ids;
              }
            });
          });
        }
      }
    },
    getRowKeys(row) {
      return row.id;
    },
    // 分页
    pageSizeChangeFn(info) {
      this.InstitutionPage.page_index = info.page;
      this.InstitutionPage.page_size = info.limit;
      this.getInstitutionListFn();
    },
    // 选中某一行
    selectCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === row.id) {
            self.operateSystemInfo.multipleSelection.splice(i, 1);
          }
        });
      }
    },
    // 去掉数组元素 里面对象 id值相同的
    clearCommonId(arr) {
      let obj = {};
      let peon = arr.reduce((cur, next) => {
        obj[next.id] ? "" : (obj[next.id] = true && cur.push(next));
        return cur;
      }, []);
      return peon;
    },
    handleInstituSelectionChange(val) {
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    // 机构 select change事件
    selectInstitionListFn(val) {
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    CheckOfficeidsFn(val) {
      // console.log(val)
    },
    delInstitutionFn(id) {
      this.$confirm("是否删除这条机构信息？", "删除信息", {
        distinguishCancelAndClose: true,
        confirmButtonText: "删除",
        cancelButtonText: "取消",
      }).then(() => {
        this.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === id) {
            if (this.operateSystemInfo.institutionList.length > 0) {
              this.$refs.info.$refs.institutions.toggleRowSelection(
                item,
                false
              );
            }
            this.operateSystemInfo.multipleSelection.splice(i, 1);
            this.$message({
              type: "success",
              message: "删除成功",
            });
          }
        });
      });
    },
    async addAimSystemsFn() {
      const loading = this.$loading({
        lock: true,
        text: this.operateSystemInfo.formInfo.id
          ? "正在编辑，请稍等..."
          : "正在新增，请稍等...",
        spinner: "el-icon-loading",
        background: "rgba(255, 255, 255, 0.6)",
      });
      const _params = { ...this.operateSystemInfo.formInfo };
      var _institutionList = [];
      this.operateSystemInfo.multipleSelection.forEach((item) => {
        var info = {};
        info.id = item.id;
        info.office_ids = item.office_ids;
        _institutionList.push(info);
      });
      _params.institutions = _institutionList;
      _params.providers = [];
      _params.providers.push(this.operateSystemInfo.providersObj);
      // 对手机号加密
      var adminPhone = _params.admin_phone;
      _params.admin_phone = this.$getRsaCode(_params.admin_phone);
      var res = null;
      var tipmsg = "新增智能诊断系统成功！";

      // 特殊处理一下期限相关的字段
      _params.stop_date = _params.isIndefinitely ? null : _params.stop_date;
      _params.reason = _params.state === 10 ? "" : _params.reason;
      delete _params.isIndefinitely;

      if (_params.id) {
        delete _params["type"];
        res = await putPacsSystems(_params);
        tipmsg = "修改智能诊断系统成功！";
      } else {
        res = await addPacsSystems(_params);
      }
      loading.close();
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: tipmsg,
        });
        this.isAiminfo = false;
        //this.getAimListFn();
        this.$emit("getSystemList");
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      } else {
        this.operateSystemInfo.formInfo.admin_phone = adminPhone;
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    getSerchName(val) {
      this.operateSystemInfo.serchName = val;
    },
    // 选择机构页面 查询按钮
    async serchListFn() {
      const _url =
        "/institutions?office_type=2&product_code=" +
        this.operateSystemInfo.formInfo.product_code +
        "&offset=1" +
        "&limit=" +
        this.InstitutionPage.page_size +
        "&name=" +
        this.operateSystemInfo.serchName;
      const res = await getInstitutionList(_url);
      if (res.code === 0) {
        this.operateSystemInfo.institutionList = res.data;
      }
    },
    submitForm(info) {
      if (info.type === "commit") {
        if (!this.operateSystemInfo.formInfo.name) {
          this.$message({ type: "error", message: "请输入系统名称" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.admin_phone) {
          this.$message({ type: "error", message: "请输入管理员电话" });
          return;
        }
        var phoneReg = /^1[3456789]\d{9}$/;
        // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
        if (!this.isUpdate || (this.isUpdate && !this.isFirstChange)) {
          if (!phoneReg.test(this.operateSystemInfo.formInfo.admin_phone)) {
            this.$message({
              message: "请输入正确的手机号码!",
              type: "warning",
            });
            return false;
          }
        }
        if (!this.operateSystemInfo.formInfo.admin_name) {
          this.$message({ type: "error", message: "请输入管理员姓名" });
          return;
        }

        if (!this.operateSystemInfo.formInfo.start_date) {
          this.$message({ type: "error", message: "请选择使用开始期限" });
          return;
        }
        if (
          !this.operateSystemInfo.formInfo.isIndefinitely &&
          !this.operateSystemInfo.formInfo.stop_date
        ) {
          this.$message({ type: "error", message: "请选择使用结束期限" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.state) {
          this.$message({ type: "error", message: "请选择系统状态" });
          return;
        }
        if (
          this.operateSystemInfo.formInfo.state === -2 &&
          !this.operateSystemInfo.formInfo.reason
        ) {
          this.$message({ type: "error", message: "请输入停用备注" });
          return;
        }

        if (info.hasOwnProperty("choosedInstituteArr")) {
          // 智能诊断
          this.operateSystemInfo.multipleSelection = JSON.parse(
            JSON.stringify(info.choosedInstituteArr)
          );
        }
        this.addAimSystemsFn();
      } else {
        this.isAiminfo = false;
        this.isactive = "";
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      }
    },
  },
};
</script>

<style lang="less" scoped>
.jurisdictionlist {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  .pacsContainer {
    height: calc(100% - 47px);
    padding: 10px 15px;
    overflow: auto;
    position: relative;
    ::v-deep .el-table__body-wrapper {
      height: calc(100% - 40px) !important;
      overflow: auto;
    }
    .system_img {
      width: 36px;
      float: left;
      margin-right: 10px;
    }
    .system_name {
      line-height: 36px;
      font-size: 16px;
      color: #303133;
    }
    .operateBtn {
      display: inline-block;
      cursor: pointer;
      height: 32px;
      line-height: 30px;
      padding: 0 10px;
      font-size: 15px;
      color: #0a70b0;
      border: 1px solid #ebeef5;
      border-radius: 3px;
      i {
        padding-right: 4px;
      }
    }
    .manageBtn {
      background: #0a70b0;
      color: #fff;
      border: 1px solid #0a70b0;
    }
  }
}
.list-item {
  position: relative;
  width: calc(25% - 15px);
  margin-right: 15px;
  box-sizing: border-box;
  border: 1px solid #ebeef5;
  box-shadow: 0 1px 5px 0 rgba(26, 26, 26, 0.050980392156862744);
  border-radius: 6px;
  background: #ffffff;
  margin-bottom: 15px;

  .deactivated-box {
    position: absolute;
    top: 65px;
    right: 20px;
    padding: 4px 10px;
    border: 1px solid #f56c6c;
    color: #f56c6c;
    transform: rotate(45deg);
    text-align: center;
    cursor: pointer;

    .deactivated-time {
      font-size: 12px;
    }
  }

  .listItemInfor {
    padding: 18px 14px 14px 18px;
    //border-bottom: 1px solid #ebeef5;
  }
  .active {
    background: rgba(10, 112, 176) !important;
    color: #fff !important;
  }
  .pacs_img {
    width: 52px;
    height: 52px;
    vertical-align: middle;
  }
  .title {
    // max-width: 200px;
    width: 100%;
  }
  .systemNameTitle {
    width: 100%;
    font-size: 20px;
    color: #1f2f3d;
    font-weight: 500;
    position: relative;
    top: -3px;
  }
  .shareHead {
    width: calc(100% - 70px);
    margin-left: 16px;
  }
  .productIdAndType {
    display: flex;
    .productIdAndTypeText {
      display: inline-block;
      line-height: 22px;
    }
    .productName {
      margin-right: 10px;
    }
    .idNumber {
      display: inline-block;
      max-width: 190px;
    }
  }
  .item_btn {
    padding: 0 10px;
    height: 30px;
    line-height: 28px;
    text-align: center;
    background: rgba(255, 255, 255, 1);
    border: 1px solid rgba(10, 112, 176, 0.5);
    border-radius: 3px;
    color: #0a70b0;
    cursor: pointer;
  }
  .manageBtn {
    background-color: #0a70b0;
    color: #fff;
  }
  .border_bd {
    border-bottom: 1px dashed #dcdfe6;
  }
  .useInstituteLabel {
    width: 70px;
  }
  .useInstituteNum {
    width: calc(100% - 70px);
  }
  .overOneLine {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .contractedhospital {
    display: flex;
    .contractedLabel {
      font-size: 14px;
      color: #909399;
    }
    .contractedNum {
      font-size: 14px;
      color: #0a70b0;
      i {
        margin-left: 5px;
      }
    }
  }
  .operateBtnCon {
    display: flex;
    height: 40px;
    align-items: center;
    border-top: 1px solid #ebeef5;
    .operateBtnOneBox {
      flex: 1;
      height: 100%;
      display: flex;
      align-items: center;
      cursor: pointer;
    }
    .operateBtnOne {
      width: 100%;
      text-align: center;
      font-size: 14px;
      color: #0a70b0;
      border-right: 1px solid #dcdfe6;
    }
    .operateBtnOneBox:last-of-type {
      .operateBtnOne {
        border-right: none;
      }
    }
    .operateBtnOneBox:hover {
      background: #f2f7ff;
    }
  }
}
.aimListItem {
  display: flex;
  flex-flow: column;
  justify-content: space-between;
}
.list-item:hover {
  box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(10, 112, 176, 0.3);
}
.list-item:hover .title {
  color: #0a70b0;
}
.adminInfor {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.institutionName {
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
@media screen and (max-width: 1500px) {
  .list-item {
    width: calc(50% - 20px) !important;
  }
  .idNumber {
    max-width: initial !important;
  }
}
.borderNone {
  border: none !important;
}
</style>
