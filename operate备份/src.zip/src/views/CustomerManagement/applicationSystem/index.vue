<template>
  <div class="applicationSystemCon">
    <div class="showWayCon">
      
      <el-radio-group v-model="showWay" @change="chooseShowWay">
        <el-tooltip class="item" effect="dark" content="分类平铺模式" placement="top">
          <el-radio-button  :label="1">
            <i class="iconfont">&#xea14;</i>
          </el-radio-button>
        </el-tooltip>
      
        <el-tooltip class="item" effect="dark" content="紧凑模式" placement="top">
          <el-radio-button  :label="2">
            <i class="iconfont">&#xea15;</i>
          </el-radio-button>
        </el-tooltip>
      
      </el-radio-group>
    </div>
    
    <!---分类排版 滚动模式--->
    <scollIndex v-if="showWay == 1"></scollIndex>
    <!---不分类 紧凑模式--->
    <cardIndex v-if="showWay == 2"></cardIndex>
   </div>
</template>
<script>
import scollIndex from "./scollIndex"
import cardIndex from "./cardIndex"
import { getAllApplicationSystemList,getShowSystemWay,saveShowSystemWay } from "@/api/platform_costomer/institution";
export default {
  components: {
    scollIndex,
    cardIndex,
  },
  data () {
    return {
      showWay: 1,
      systemList: [],
      searchSystemParam: {
        contains_name: '',
        institution_id: '',
        admin_id: '',
      },
    }
  },
  methods: {
    chooseShowWay (way) {
      this.showWay = way
      this.beganSaveShowSystemWay()
    },
    // 保存 应用系统的排放模式
    async beganSaveShowSystemWay () {
      const res = await saveShowSystemWay({mode: this.showWay});
      if (res.code === 0) {
        //this.$message({ type: "success",message: "保存成功",});
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 获取排列模式
    async getShowWayFn() {
      const res = await getShowSystemWay();
      if (res.code === 0) {
        if (res.data.mode) {
          this.showWay = res.data.mode
        } else {// 如果初始化库里面还没存模式值时 根据当前建的所有业务系统个数来设置默认模式
          this.getPascListFn()
        }
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 系统列表
    async getPascListFn() {
      const self = this
      self.systemList = []
      const res = await getAllApplicationSystemList(self.searchSystemParam);
      if (res.code === 0) {
        const result = res.data
        if (result.length != 0) {
          result.forEach((item) => {
            if (item.systems.length != 0) {
              item.systems.forEach((one) => {
                one.code = item.code
                self.systemList.push(one)
              })
            }
          })
        }
        // 当前业务系统 总数 小于12个时 默认模式 是 紧凑模式
        if (self.systemList.length <= 12) {
          self.showWay = 2
        }
      } else {
        self.$message({ type: "error", message: res.msg });
      }
    },
  },
  created () {
    this.getShowWayFn()
  }
}
</script>
<style lang="less" scoped>
.applicationSystemCon{
  height: 100%;
  position: relative;
  overflow: hidden;
}
::v-deep .showWayCon{
 display: flex;
 position: absolute;
 right: 135px;
 top: 9px;
 z-index: 100;
 .el-radio-group {
    height: 32px;
    line-height: 30px;
    .el-radio-button__inner {
      height: 32px;
      line-height: 30px;
      padding: 0 10px !important;
      text-align: center;
    }
    .el-radio-button__orig-radio:checked + .el-radio-button__inner {
      background-color: #0a70b0 !important;
      border-color: #0a70b0 !important;
      color:#fff;
    }
  }
}
</style>