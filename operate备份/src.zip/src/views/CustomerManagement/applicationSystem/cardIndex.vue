<template>
  <div class="applicationSystemContainer">
    <div class="systemQuery">
      <div class="searchItem">
        <el-radio-group
          v-model="searchSystemParam.state"
          size="small"
          @change="getPascListFn"
        >
          <el-radio-button label="">全部</el-radio-button>
          <el-radio-button :label="10">在用</el-radio-button>
          <el-radio-button :label="-2">停用</el-radio-button>
        </el-radio-group>
      </div>
      <div class="searchItem ml10">
        <span class="searchLabel">使用机构</span>
        <el-select
          class="width_180_input"
          filterable
          clearable
          v-model="searchSystemParam.institution_id"
          @change="getPascListFn"
          placeholder="请选择"
        >
          <el-option label="请选择" value=""></el-option>
          <el-option
            v-for="item in institutelist"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          ></el-option>
        </el-select>
      </div>
      <div class="searchItem ml10">
        <span class="searchLabel">管理员</span>
        <el-select
          class="width_180_input"
          filterable
          clearable
          v-model="searchSystemParam.admin_id"
          placeholder="请选择"
          @change="getPascListFn"
        >
          <el-option label="请选择" value=""></el-option>
          <el-option
            v-for="item in adminList"
            :key="item.id"
            :label="item.name + '(' + item.phone + ')'"
            :value="item.id"
          ></el-option>
        </el-select>
      </div>
      <div class="searchInputDiv ml10">
        <el-input
          class="width_240_input"
          v-model="searchSystemParam.contains_name"
          v-on:keyup.enter.native="getPascListFn()"
          placeholder="按应用名称查找"
        ></el-input>
        <i class="iconfont searchIcon" @click="getPascListFn">&#xe652;</i>
      </div>

      <div class="tr col" id="addMenu">
        <!-- <el-popover
          placement="bottom"
          width="90"
          popper-class="systemTypePopover"
          :offset="50"
          trigger="hover"
        >
          <div class="addClassDiv">
            <div
              v-for="(oneSystem,index) in systemList"
              class="serviceCenterClass"
              @click="chooseSystemType(oneSystem.code)"
            >
              {{oneSystem.name}}
            </div>

          </div>
          <el-button
            slot="reference"
            class="function-btn borderNone createBtn bg_e6 clr_ff"
          >
            <i class="iconfont iconxinzeng"></i>新增系统</el-button
          >
        </el-popover> -->

        <el-menu
          class="addSystemMenuList"
          mode="horizontal"
          @select="handleSelect"
          popper-append-to-body
        >
          <el-submenu index="1" popper-class="addSystemItemMenu">
            <template slot="title">
              <span class="function-btn bg_e6 clr_ff">
                <i class="iconfont iconxinzeng addSystemIcon"></i>新增系统
              </span>
            </template>
            <div
              class="oneMenu"
              v-for="(item, menuIndex) in addSystemTypeList"
              :key="menuIndex"
            >
              <el-menu-item v-if="!item.children" :index="item.code">{{
                item.name
              }}</el-menu-item>
              <div v-if="item.children">
                <el-submenu
                  :index="`${menuIndex}-${item.code}`"
                  popper-class="addSystemSubMenu"
                >
                  <template slot="title">{{ item.name }}</template>
                  <el-menu-item
                    v-for="oneSub in item.children"
                    :key="oneSub.code"
                    :index="oneSub.code"
                    >{{ oneSub.name }}</el-menu-item
                  >
                </el-submenu>
              </div>
            </div>
          </el-submenu>
        </el-menu>
      </div>
    </div>
    <div class="tabContainer flex_row">
      <div class="crumbsCon">
        <div class="m-tab">
          <div
            class="m-tab-item"
            :class="tabIndex === index ? 'm-tab-item-active' : ''"
            v-for="(item, index) in systemTabList"
            :key="index"
            @click="toggleTab(index, item.code)"
          >
            {{ item.name }}
          </div>
        </div>
      </div>
    </div>
    <div
      class="pacsContainer"
      id="systemContainer"
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-background="rgba(255,255,255,0.6)"
      v-bind:class="{ noTableData: systemList.length === 0 }"
    >
      <div class="oneSystemType" ref="systemRef">
        <div class="listItemBox">
          <!--云pacs--->
          <div
            class="list-item pacsItem"
            id="PACS"
            :class="{ activeListItem: curProductCode == 'PACS' }"
            v-for="(item, nth) in systemList"
            v-if="item.code == 'PACS'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <div class="pacsItemCon">
              <div class="flex_row">
                <img
                  class="pacs_img"
                  :src="
                    item.product_code == 'NMIS'
                      ? HYX
                      : item.product_code == 'ECGIS'
                      ? XD
                      : item.product_code == 'UIS'
                      ? CS
                      : item.product_code == 'RIS'
                      ? FS
                      : item.product_code == 'EIS'
                      ? NJ
                      : item.product_code == 'PIS'
                      ? PS
                      : item.product_code == 'EWCSS'
                      ? ES
                      : item.product_code == 'ImageArchive'
                      ? CUND
                      : item.product_code == 'OIS'
                      ? YK
                      : item.product_code == 'DRIS'
                      ? SZJGH
                      : item.product_code == 'AIM'
                      ? AIM
                      : item.product_code == 'RTIS'
                      ? FL
                      : YY
                  "
                />
                <div class="shareHead">
                  <div class="pacsSystemNameTitle">
                    <div
                      class="systemNameText overOneLine"
                      v-bind:title="item.name"
                    >
                      {{ item.name }}
                    </div>
                    <div class="operateIcon">
                      <el-tooltip
                        placement="top"
                        class=""
                        v-if="isSetUdi && item.product_code != 'ImageCriminal'"
                        popper-class="imgModifyCheckTimeTip"
                      >
                        <div slot="content">关于系统</div>
                        <i
                          class="iconfont iconguanyuxitongxinxi operateIcon"
                          @click="isShowinfoFn('aboutSystem', item)"
                        ></i>
                      </el-tooltip>

                      <el-tooltip
                        placement="top"
                        class="ml10"
                        popper-class="imgModifyCheckTimeTip"
                      >
                        <div slot="content">编辑</div>
                        <i
                          class="iconfont iconbianji1 operateIcon"
                          @click="updateSystem(item, item.code)"
                        ></i>
                      </el-tooltip>

                      <!-- <span  class="item_btn" @click="updateSystem(item, item.code)" v-if="isSetUdi && item.product_code != 'ImageCriminal'">关于</span>
                    <span class="item_btn ml10" @click="updateSystem(item, item.code)">编辑</span> -->
                    </div>
                  </div>
                  <div class="productIdAndType">
                    <span
                      class="productIdAndTypeText productName"
                      :title="item.product_name"
                      >{{ item.product_name }}</span
                    ><span
                      class="productIdAndTypeText idNumber overOneLine"
                      :title="'系统ID：' + item.id"
                      >{{ item.id }}</span
                    >
                  </div>
                </div>
              </div>
              <div class="clr_666 mt10 f14" v-if="item.product_code == 'ECGIS'">
                <div class="overOneLine">
                  <span class="clr_999">开通服务：</span
                  ><span class="clr_303">{{
                    item.function_service_names
                  }}</span>
                </div>
              </div>
              <div class="clr_666 mt10 f14" v-else>
                <div class="overOneLine">
                  <span class="clr_999">开通服务：</span
                  ><span class="clr_303">无</span>
                </div>
              </div>
              <div class="flex_row f14 mt10">
                <div
                  class="tl adminInfor"
                  v-bind:title="'管理人员：' + item.admin_name"
                >
                  <span class="clr_999">管理人员：</span>
                  <span class="clr_303"
                    >{{ item.admin_name }}({{ item.admin_phone }})</span
                  >
                </div>
              </div>
              <div class="mt10">
                <div class="flex_row tl f14">
                  <div class="useInstituteLabel clr_999">使用机构：</div>
                  <div
                    class="clr_303 useInstituteNum overOneLine flex_row"
                    v-if="item.institution_names.length != 0"
                  >
                    [{{ item.institution_names.length }}家]

                    <tooltip-over
                      :content="item.institution_names"
                      placement="top-start"
                      class="wid190"
                      refName="tooltipOver"
                    ></tooltip-over>

                    <!-- <span v-for="(itemname, index) in item.institution_names" :key="itemname">
                    <span v-if="index!=0">、</span>{{itemname}}</span> -->
                  </div>
                  <div class="clr_303 useInstituteNum overOneLine" v-else>
                    无
                  </div>
                </div>
              </div>
            </div>
            <div class="operateBtnCon">
              <div
                class="operateBtnOneBox"
                @click="isShowinfoFn('aboutSystem', item)"
                v-if="
                  isSetUdi &&
                  item.product_code != 'ImageCriminal' &&
                  item.code != 'PACS'
                "
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt">关于</span>
                </div>
              </div>
              <div
                class="operateBtnOneBox"
                v-if="item.code != 'PACS'"
                @click="updateSystem(item, item.code)"
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt">编辑</span>
                </div>
              </div>
              <div
                class="operateBtnOneBox"
                @click="enterOfficeManage(item)"
                v-if="
                  item.product_code == 'RIS' ||
                  item.product_code == 'UIS' ||
                  item.product_code == 'ECGIS' ||
                  item.product_code == 'EIS' ||
                  item.product_code == 'RTIS' ||
                  item.product_code == 'NMIS' ||
                  item.product_code == 'PIS'
                "
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt"
                    ><i class="iconfont">&#xe643;</i> 科室管理</span
                  >
                </div>
              </div>

              <div
                class="operateBtnOneBox"
                @click="enterOfficeTeachManage(item)"
                v-if="
                  (item.product_code == 'RIS' ||
                    item.product_code == 'UIS' ||
                    item.product_code == 'ECGIS' ||
                    item.product_code == 'EIS' ||
                    item.product_code == 'RTIS' ||
                    item.product_code == 'NMIS' ||
                    item.product_code == 'PIS') &&
                  item.is_open_department_teach
                "
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt"
                    ><i class="iconfont">&#xe9e9;</i> 科室教学</span
                  >
                </div>
              </div>

              <div
                class="operateBtnOneBox"
                @click="isShowinfoFn('operate', item, item.code)"
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt"
                    ><i class="iconfont">&#xe667;</i> 系统管理</span
                  >
                </div>
              </div>
            </div>
          </div>

          <!--远程医疗--->
          <div
            class="list-item pacsItem"
            id="Telemed"
            :class="{ activeListItem: curProductCode == 'Telemed' }"
            v-for="(item, nth) in systemList"
            v-if="item.code === 'Telemed'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <telemedicineList
              ref="telemedicineListListRef"
              :oneSystem="item"
              @getSystemList="getPascListFn"
              @closeAllDrawDetailAlert="closeAllDrawDetailAlert"
            ></telemedicineList>
          </div>
          <!--远程医疗 隐藏组件 用于方便点击新增时 调用组件内部的方法--->
          <telemedicineList
            ref="telemedicineListListRefTest"
            @getSystemList="getPascListFn"
          ></telemedicineList>

          <!--远程教学--->
          <div
            class="list-item pacsItem"
            id="Teach"
            :class="{ activeListItem: curProductCode == 'Teach' }"
            v-for="(item, nth) in systemList"
            v-if="item.code === 'Teach'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <distanceTeachingList
              ref="distanceTeachingListRef"
              :oneSystem="item"
              @getSystemList="getPascListFn"
              @closeAllDrawDetailAlert="closeAllDrawDetailAlert"
            ></distanceTeachingList>
          </div>
          <!--远程教学 隐藏组件 用于方便点击新增时 调用组件内部的方法--->
          <distanceTeachingList
            ref="distanceTeachingListRefTest"
            @getSystemList="getPascListFn"
          ></distanceTeachingList>

          <!--医技质控(影像质控)--->
          <div
            class="list-item pacsItem"
            id="Quality"
            :class="{ activeListItem: curProductCode == 'Quality' }"
            v-for="(item, nth) in systemList"
            v-if="item.code == 'Quality'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <imageControlSystemList
              ref="imageControlSystemListRef"
              :oneSystem="item"
              @getSystemList="getPascListFn"
              @closeAllDrawDetailAlert="closeAllDrawDetailAlert"
            ></imageControlSystemList>
          </div>
          <imageControlSystemList
            ref="imageControlSystemListRefTest"
            @getSystemList="getPascListFn"
          ></imageControlSystemList>

          <!--影像共享--->

          <div
            class="list-item pacsItem"
            id="IDCAS"
            :class="{ activeListItem: curProductCode == 'IDCAS' }"
            v-for="(item, nth) in systemList"
            v-if="item.code == 'IDCAS'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <imageSharingList
              ref="imageSharingListRef"
              :oneSystem="item"
              @getSystemList="getPascListFn"
              @closeAllDrawDetailAlert="closeAllDrawDetailAlert"
            ></imageSharingList>
          </div>
          <imageSharingList
            ref="imageSharingListRefTest"
            @getSystemList="getPascListFn"
          ></imageSharingList>

          <!--科室管理(智能科室)--->
          <div
            class="list-item pacsItem"
            id="DMS"
            :class="{ activeListItem: curProductCode == 'DMS' }"
            v-for="(item, nth) in systemList"
            v-if="item.code == 'DMS'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <intelligenceOfficeList
              ref="intelligenceOfficeListRef"
              :oneSystem="item"
              @getSystemList="getPascListFn"
              @closeAllDrawDetailAlert="closeAllDrawDetailAlert"
            ></intelligenceOfficeList>
          </div>
          <intelligenceOfficeList
            ref="intelligenceOfficeListRefTest"
            @getSystemList="getPascListFn"
          ></intelligenceOfficeList>

          <!--患者服务--->
          <div
            class="list-item pacsItem"
            id="EWSPS"
            :class="{ activeListItem: curProductCode == 'EWSPS' }"
            v-for="(item, nth) in systemList"
            v-if="item.code == 'EWSPS'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <patientServicesList
              ref="patientServicesRef"
              :oneSystem="item"
              @getSystemList="getPascListFn"
              @closeAllDrawDetailAlert="closeAllDrawDetailAlert"
            ></patientServicesList>
          </div>
          <patientServicesList
            ref="patientServicesRefTest"
            @getSystemList="getPascListFn"
          ></patientServicesList>

          <!--全资源预约(集中预约)--->
          <div
            class="list-item pacsItem"
            id="EWCSS"
            :class="{ activeListItem: curProductCode == 'EWCSS' }"
            v-for="(item, nth) in systemList"
            v-if="item.code == 'EWCSS'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <div class="pacsItemCon">
              <div class="flex_row">
                <img class="pacs_img" :src="ES" />
                <div class="shareHead">
                  <div
                    class="systemNameTitle overOneLine"
                    v-bind:title="item.name"
                  >
                    {{ item.name }}
                  </div>
                  <div class="productIdAndType">
                    <span
                      class="productIdAndTypeText productName"
                      :title="item.product_name"
                      >{{ item.product_name }}</span
                    ><span
                      class="productIdAndTypeText idNumber overOneLine"
                      :title="'系统ID：' + item.id"
                      >{{ item.id }}</span
                    >
                  </div>
                </div>
              </div>
              <div class="clr_666 mt10 f14">
                <div class="overOneLine">
                  <span class="clr_999">开通服务：</span
                  ><span class="clr_303">{{
                    item.function_service_names
                  }}</span>
                </div>
              </div>
              <div class="flex_row mt10 f14">
                <div
                  class="tl adminInfor"
                  v-bind:title="'管理人员：' + item.admin_name"
                >
                  <span class="clr_999">管理人员：</span>
                  <span class="clr_303"
                    >{{ item.admin_name }}({{ item.admin_phone }})</span
                  >
                </div>
              </div>
              <div class="mt10 f14">
                <div class="flex_row tl">
                  <div class="useInstituteLabel clr_999">使用机构：</div>
                  <div
                    class="clr_303 useInstituteNum overOneLine flex_row"
                    v-if="item.institution_names.length != 0"
                  >
                    [{{ item.institution_names.length }}家]
                    <tooltip-over
                      :content="item.institution_names"
                      placement="top-start"
                      class="wid190"
                      refName="tooltipOver"
                    ></tooltip-over>
                    <!-- <span v-for="(itemname, index) in item.institution_names" :key="itemname"><span v-if="index!=0">、</span>{{itemname}}</span> -->
                  </div>
                  <div class="clr_303 useInstituteNum overOneLine" v-else>
                    无
                  </div>
                </div>
              </div>
            </div>
            <div class="operateBtnCon">
              <div
                class="operateBtnOneBox"
                @click="isShowinfoFn('aboutSystem', item)"
                v-if="
                  isSetUdi &&
                  item.product_code != 'ImageCriminal' &&
                  item.code != 'PACS'
                "
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt">关于</span>
                </div>
              </div>
              <div
                class="operateBtnOneBox"
                v-if="item.code != 'PACS'"
                @click="updateSystem(item, item.code)"
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt">编辑</span>
                </div>
              </div>
              <div
                class="operateBtnOneBox"
                @click="isShowinfoFn('operate', item, item.code)"
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt"
                    ><i class="iconfont">&#xe667;</i> 系统管理</span
                  >
                </div>
              </div>
            </div>
          </div>

          <!--影像存档(以前的pacs列表里面)--->
          <div
            class="list-item pacsItem"
            id="ImageArchive"
            :class="{ activeListItem: curProductCode == 'ImageArchive' }"
            v-for="(item, nth) in systemList"
            v-if="item.code == 'ImageArchive'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <div class="pacsItemCon">
              <div class="flex_row">
                <img class="pacs_img" :src="CUND" />
                <div class="shareHead">
                  <div
                    class="systemNameTitle overOneLine"
                    v-bind:title="item.name"
                  >
                    {{ item.name }}
                  </div>
                  <div class="productIdAndType">
                    <span
                      class="productIdAndTypeText productName"
                      :title="item.product_name"
                      >{{ item.product_name }}</span
                    ><span
                      class="productIdAndTypeText idNumber overOneLine"
                      :title="'系统ID：' + item.id"
                      >{{ item.id }}</span
                    >
                  </div>
                </div>
              </div>
              <div class="flex_row mt10 f14">
                <div
                  class="tl adminInfor"
                  v-bind:title="'管理人员：' + item.admin_name"
                >
                  <span class="clr_999">管理人员：</span>
                  <span class="clr_303"
                    >{{ item.admin_name }}({{ item.admin_phone }})</span
                  >
                </div>
              </div>
              <div class="mt10">
                <div class="flex_row tl f14">
                  <div class="useInstituteLabel clr_999">使用机构：</div>
                  <div
                    class="clr_303 useInstituteNum overOneLine flex_row"
                    v-if="item.institution_names.length != 0"
                  >
                    [{{ item.institution_names.length }}家]
                    <tooltip-over
                      :content="item.institution_names"
                      placement="top-start"
                      class="wid190"
                      refName="tooltipOver"
                    ></tooltip-over>
                    <!-- <span v-for="(itemname, index) in item.institution_names" :key="itemname"><span v-if="index!=0">、</span>{{itemname}}</span> -->
                  </div>
                  <div class="clr_303 useInstituteNum overOneLine" v-else>
                    无
                  </div>
                </div>
              </div>
            </div>
            <div class="operateBtnCon">
              <div
                class="operateBtnOneBox"
                @click="isShowinfoFn('aboutSystem', item)"
                v-if="
                  isSetUdi &&
                  item.product_code != 'ImageCriminal' &&
                  item.code != 'PACS'
                "
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt">关于</span>
                </div>
              </div>
              <div
                class="operateBtnOneBox"
                v-if="item.code != 'PACS'"
                @click="updateSystem(item, item.code)"
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt">编辑</span>
                </div>
              </div>
              <div
                class="operateBtnOneBox"
                @click="isShowinfoFn('operate', item, item.code)"
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt"
                    ><i class="iconfont">&#xe667;</i> 系统管理</span
                  >
                </div>
              </div>
            </div>
          </div>

          <!--排队叫号(以前的pacs列表里面)--->
          <div
            class="list-item pacsItem"
            id="Calling"
            :class="{ activeListItem: curProductCode == 'Calling' }"
            v-for="(item, nth) in systemList"
            v-if="item.code == 'Calling'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <div class="pacsItemCon">
              <div class="flex_row">
                <img class="pacs_img" :src="YY" />
                <div class="shareHead">
                  <div
                    class="systemNameTitle overOneLine"
                    v-bind:title="item.name"
                  >
                    {{ item.name }}
                  </div>
                  <div class="productIdAndType">
                    <span
                      class="productIdAndTypeText productName"
                      :title="item.product_name"
                      >{{ item.product_name }}</span
                    ><span
                      class="productIdAndTypeText idNumber overOneLine"
                      :title="'系统ID：' + item.id"
                      >{{ item.id }}</span
                    >
                  </div>
                </div>
              </div>
              <div class="flex_row mt10 f14">
                <div
                  class="tl adminInfor"
                  v-bind:title="'管理人员：' + item.admin_name"
                >
                  <span class="clr_999">管理人员：</span>
                  <span class="clr_303"
                    >{{ item.admin_name }}({{ item.admin_phone }})</span
                  >
                </div>
              </div>
              <div class="mt10">
                <div class="flex_row tl f14">
                  <div class="useInstituteLabel clr_999">使用机构：</div>
                  <div
                    class="clr_303 useInstituteNum overOneLine flex_row"
                    v-if="item.institution_names.length != 0"
                  >
                    [{{ item.institution_names.length }}家]
                    <tooltip-over
                      :content="item.institution_names"
                      placement="top-start"
                      class="wid190"
                      refName="tooltipOver"
                    ></tooltip-over>
                    <!-- <span v-for="(itemname, index) in item.institution_names" :key="itemname"><span v-if="index!=0">、</span>{{itemname}}</span> -->
                  </div>
                  <div class="clr_303 useInstituteNum overOneLine" v-else>
                    无
                  </div>
                </div>
              </div>
            </div>
            <div class="operateBtnCon">
              <div
                class="operateBtnOneBox"
                @click="isShowinfoFn('aboutSystem', item)"
                v-if="
                  isSetUdi &&
                  item.product_code != 'ImageCriminal' &&
                  item.code != 'PACS'
                "
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt">关于</span>
                </div>
              </div>
              <div
                class="operateBtnOneBox"
                v-if="item.code != 'PACS'"
                @click="updateSystem(item, item.code)"
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt">编辑</span>
                </div>
              </div>
              <div
                class="operateBtnOneBox"
                @click="isShowinfoFn('operate', item, item.code)"
              >
                <div class="operateBtnOne">
                  <span class="operateBtnTxt"
                    ><i class="iconfont">&#xe667;</i> 系统管理</span
                  >
                </div>
              </div>
            </div>
          </div>

          <!--影像大数据--->
          <div
            class="list-item pacsItem"
            id="IBDSS"
            :class="{ activeListItem: curProductCode == 'IBDSS' }"
            v-for="(item, nth) in systemList"
            v-if="item.code == 'IBDSS'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <imageBigDataList
              ref="imageBigDataListRef"
              :oneSystem="item"
              @getSystemList="getPascListFn"
              @closeAllDrawDetailAlert="closeAllDrawDetailAlert"
            ></imageBigDataList>
          </div>
          <imageBigDataList
            ref="imageBigDataListRefTest"
            @getSystemList="getPascListFn"
          ></imageBigDataList>

          <!--智能诊断--->
          <div
            class="list-item pacsItem"
            id="AIM"
            :class="{ activeListItem: curProductCode == 'AIM' }"
            v-for="(item, nth) in systemList"
            v-if="item.code == 'AIM'"
            :key="nth"
          >
            <!-- 停用标识 -->
            <el-popover
              v-if="item.state === -2"
              placement="top-start"
              trigger="hover"
            >
              <div v-if="item.operator_name">
                停用人：{{ item.operator_name }}({{ item.update_time }})
              </div>
              <div>备注：{{ item.reason }}</div>
              <div slot="reference" class="deactivated-box">
                <div>停用!</div>
                <div class="deactivated-time" v-if="item.update_time">
                  {{ item.update_time.substring(0, 11) }}
                </div>
              </div>
            </el-popover>
            <aimList
              ref="aimListRef"
              :oneSystem="item"
              @getSystemList="getPascListFn"
              @closeAllDrawDetailAlert="closeAllDrawDetailAlert"
            ></aimList>
          </div>
          <aimList
            ref="aimListRefTest"
            @getSystemList="getPascListFn"
          ></aimList>
        </div>
      </div>
    </div>
    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="isPacsinfo"
      :show-close="false"
      :withHeader="false"
      :wrapperClosable="this.operateSystemInfo.title === '编辑' ? true : false"
      :direction="direction"
      :before-close="handleClose"
    >
      <component
        :is="curSystemModule"
        ref="info"
        :pacsinfo="operateSystemInfo"
        :pageInfo="InstitutionPage"
        :pacsCooperateProductObj="pacsCooperateProductObj"
        :collab_service_codes="collab_service_codes"
        :productServiceObj="productServiceObj"
        :pacsServiceList="pacsServiceList"
        :EWCSSServicecList="EWCSSServicecList"
        :getDetailFinished="getDetailFinished"
        :isUpdate="isUpdate"
        @closeFn="closeFn"
        @selectInstitionListFn="selectInstitionListFn"
        @selectCurRowFn="selectCurRow"
        @delInstitutionFn="delInstitutionFn"
        @changePhone="changePhone"
        @ChoiceOrganFn="ChoiceOrganFn"
        @serchListFn="serchListFn"
        @getSerchName="getSerchName"
        @getAdminNameFn="getAdminNameFn"
        @pageSizeChangeFn="pageSizeChangeFn"
        @CheckOfficeidsFn="CheckOfficeidsFn"
        @activePacsSystemFn="activePacsSystemFn"
        @activeSystemFn="activeSystemFn"
        @activeVoiceSystemFn="activeVoiceSystemFn"
        @changeService="changeService"
        @changeCooperateProductObj="changeCooperateProductObj"
        @submitForm="submitForm"
        @isAddInstution="isAddInstution"
        @getRowKeys="getRowKeys"
        @instclose="instclose"
      ></component>
      <!-- <pacs-info ref="info" :pacsinfo="operateSystemInfo" :pageInfo="InstitutionPage" @closeFn="closeFn" @selectInstitionListFn="selectInstitionListFn" @selectCurRowFn="selectCurRow" @delInstitutionFn="delInstitutionFn"
        @changePhone="changePhone" @ChoiceOrganFn="ChoiceOrganFn" @serchListFn="serchListFn" @getSerchName="getSerchName" @getAdminNameFn="getAdminNameFn" @pageSizeChangeFn="pageSizeChangeFn" @CheckOfficeidsFn="CheckOfficeidsFn"
        @activeSystemFn="activeSystemFn" @submitForm="submitForm" @isAddInstution="isAddInstution" @getRowKeys="getRowKeys" @instclose="instclose"></pacs-info> -->
    </el-drawer>
  </div>
</template>

<script>
import Vue from "vue";
import Mgr from "@/utils/SecurityService";
import aboutSystem from "tomtaw-system-about";
import JSEncrypt from "jsencrypt";
import { mapGetters } from "vuex";
import pacsInfo from "./pacsinfo";
import distanceTeachingList from "./components/distanceTeaching/cardIndex";
import imageControlSystemList from "./components/imageControlSystem/cardIndex";
import imageSharingList from "./components/imageSharing/cardIndex";
import intelligenceOfficeList from "./components/intelligenceOfficeList/cardIndex";
import patientServicesList from "./components/patientServices/cardIndex";
import imageBigDataList from "./components/imageBigData/cardIndex";
import aimList from "./components/aim/cardIndex";
import telemedicineList from "./components/telemedicine/cardIndex";
import tooltipOver from "./components/tooltipOver";

import ewcssinfo from "./ewcssinfo";
import imageInfo from "./imageInfo";
import voiceCallInfo from "./voiceCallInfo";
import aimInfo from "./aimInfo";
import {
  addPacsSystems,
  getInstitutionList,
  getAllApplicationSystemList,
  getPacsSystemsInfoByid,
  putPacsSystems,
  getPasServicecList,
  getServiceTypePower,
  getCallingService,
  getApplicationSystemAdminList,
  getApplicationSystemTypeList,
  getEWCSSServicecList,
  getPacsCooperateProductList,
} from "@/api/platform_costomer/institution";
import {
  getLoginName,
  getConfigurations,
  getLoginUserInfor,
  ownMenu,
  getInstitutionListLite,
} from "@/api/commonHttp";
import moment from "moment";

export default {
  components: {
    pacsInfo,
    telemedicineList,
    distanceTeachingList,
    imageControlSystemList,
    imageSharingList,
    intelligenceOfficeList,
    imageBigDataList,
    aimList,
    ewcssinfo,
    imageInfo,
    voiceCallInfo,
    aimInfo,
    tooltipOver,
    patientServicesList,
  },
  computed: {
    ...mapGetters(["isSetUdi", "isShowManageBtn"]),
  },
  data() {
    return {
      addSystemValue: [],
      curSystemCode: "",
      curProductCode: "",
      institutelist: [],
      adminList: [],
      tabIndex: -1,
      number: 0,
      addSystemTypeList: [],
      tabList: [
        {
          label: "云pacs",
          value: "cloudPacs",
        },
        {
          label: "远程医疗",
          value: "telemedicine",
        },
        {
          label: "远程教学",
          value: "distanceTeaching",
        },
        {
          label: "医技质控",
          value: "quality",
        },
      ],
      CS: require("../../../assets/images/CS_Image.png"), // 超声
      FS: require("../../../assets/images/FS_Image.png"), // 放射
      NJ: require("../../../assets/images/NJ_Image.png"), // 内镜
      XD: require("../../../assets/images/XD_Image.png"), // 心电
      PS: require("../../../assets/images/PS_Image.png"), // 病理
      HYX: require("../../../assets/images/HYX_Image.png"), // 核医学
      ES: require("../../../assets/images/Appoint_Image.png"), // 集中预约
      CUND: require("../../../assets/images/YXCD_Image.png"), // 影像存档
      YY: require("../../../assets/images/YY_Image.png"), // 叫号
      YK: require("../../../assets/images/YK_Image.png"), // 眼科
      SZJGH: require("../../../assets/images/SZHBG_Image.png"), // 数字结构化报告
      AIM: require("../../../assets/images/AIM.png"), // 智能诊断
      FL: require("../../../assets/images/fangLiao_Image.png"), // 放疗pacs
      telemedicineLogo: require("../../../assets/images/telemedicine.png"), // 远程医疗
      info: "",
      loading: true,
      isPacsinfo: false,
      direction: "rtl",
      systemTabList: [],
      systemList: [],
      isactive: "",
      curSystemModule: "",
      curSystemType: "",
      isoperateactive: "",
      pacsServiceList: [],
      getDetailFinished: false,
      operateSystemInfo: {
        title: "新增PACS系统",
        serchName: "",
        activesystem: "",
        systemList: [{ code: "", name: "", modules: [] }], // 授权产品
        isAdminname: false,
        product_name: "",
        providersObj: {
          app_id: "",
          app_secret: "",
          provider_name: "WeChat",
        },
        formInfo: {
          type: 1,
          product_code: "",
          name: "",
          admin_phone: "",
          admin_name: "",
          collab_service_codes: [], // 协同产品
          function_services: [], // 开通的服务
          service_codes: [],
          providers: [],

          isIndefinitely: true, // 是否无限期
          start_date: moment().format("YYYY-MM-DD"), // 开始期限
          stop_date: null, // 结束期限
          state: 10, // 启用状态
          reason: "", // 停用原因
        },
        rules: {
          product_code: [
            { required: true, message: "请选择产品名称", trigger: "change" },
          ],
          name: [
            { required: true, message: "请输入系统名称", trigger: "blur" },
          ],
          admin_phone: [
            { required: true, message: "请输入管理员电话", trigger: "change" },
          ],
          admin_name: [
            { required: true, message: "请输入管理员姓名", trigger: "change" },
          ],
        },
        isChioseOrgan: false,
        institutionList: [], // 机构列表
        deplist: [],
        multipleSelection: [], // 机构列表选中机构
      },
      collab_service_codes: [],
      productServiceObj: {},
      pacsCooperateProductObj: {},
      searchSystemParam: {
        state: "",
        contains_name: "",
        institution_id: "",
        admin_id: "",
      },
      userLoginInfor: {},
      serviceTypePowerObj: {},
      isUpdate: false,
      isFirstChange: true,
      InstitutionPage: {
        eof: 1,
        page_index: 1,
        page_size: 8,
        total_count: 0,
        total_pages: 1,
      },
      choiseList: [], // select 选中机构
      isChoiceFirst: true, // 是否第一次select
      listBoxState: true, //点击导航栏时，暂时停止监听页面滚动
      updateSystemCode: "",
      EWCSSServicecList: [],
    };
  },
  mounted() {
    const self = this;
    self.getInstitutionListLiteFn();
    self.getMyApplicationSystemAdminList();
    self.getMyApplicationSystemTypeList();
    self.$nextTick(() => {
      self.getPascListFn();
      // 加密函数
      self.getConfigurationsFn();
      // 获取登录用户信息
      self.getUserLoginInfor();
    });
  },
  destroyed() {
    //离开该页面需要移除这个监听的事件
    window.removeEventListener("scroll", this.onScroll);
  },
  methods: {
    handleSelect(key, keyPath) {
      //console.log(key, keyPath);
      // console.log(keyPath)
      if (keyPath.length == 3) {
        // 选择了二级子菜单
        this.chooseSystemType(keyPath[2]);
      } else {
        // 选择一级菜单
        this.chooseSystemType(keyPath[1]);
      }
    },
    handleChange(value) {
      console.log(value);
    },
    // 获取管理员列表
    async getMyApplicationSystemAdminList() {
      const res = await getApplicationSystemAdminList();
      if (res.code === 0) {
        this.adminList = res.data;
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 获取可以新增的业务系统类型
    async getMyApplicationSystemTypeList() {
      const res = await getApplicationSystemTypeList();
      if (res.code === 0) {
        this.addSystemTypeList = res.data;
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 获取机构列表
    async getInstitutionListLiteFn() {
      const res = await getInstitutionListLite();
      if (res.code === 0) {
        this.institutelist = res.data;
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    toggleTab(index, value) {
      const self = this;
      if (self.curProductCode == value) {
        self.curProductCode = "";
        self.tabIndex = -1;
      } else {
        self.curProductCode = value;
        self.tabIndex = index;
        let id = value;

        //let navBar = document.getElementById('navHead').offsetHeight;  //固定头部的高度
        //let nodes = document.getElementById('main-container');  //跳转元素的父元素
        self.$nextTick(() => {
          // window.scrollTo({
          //   //top: anchorElementHeight-(navBar),
          //   top: anchorElementHeight,
          //   behavior: "smooth",
          // });
          let anchorElementHeight = document.getElementById(id).offsetTop; // 要跳转元素到offsetParent顶部的距离
          document.querySelector("#systemContainer").scrollTo({
            //top: anchorElementHeight-(navBar),
            top: anchorElementHeight - 10,
            behavior: "smooth",
          });
        });
      }
    },
    async getUserLoginInfor() {
      const res = await getLoginUserInfor();
      if (res.code == 0) {
        this.userLoginInfor = res.data;
        const tenancy_id =
          sessionStorage.getItem("curTenancyId") ||
          this.userLoginInfor.tenancy_id;
        this.beganGetServiceTypePower(tenancy_id);
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    async getConfigurationsFn() {
      const res = await getConfigurations("TransmissionSecurity.RSA.PublicKey");
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) {
          // 注册方法
          const pubKey = res.data; // ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt();
          encryptStr.setPublicKey(pubKey); // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()); // 进行加密
          return data;
        };
      }
    },
    // 加载相应的组件
    loadCurComponents() {
      if (this.curSystemCode === "PACS") {
        this.curSystemModule = pacsInfo;
      }
      if (this.curSystemCode === "Telemed") {
        // 远程医疗
        this.curSystemModule = pacsInfo;
      }
      if (this.curSystemCode === "EWCSS") {
        // 全资源预约(集中预约)
        this.curSystemModule = ewcssinfo;
        this.operateSystemInfo.title = "新增集中预约系统";
      }
      if (this.curSystemCode === "ImageArchive") {
        // 影像存档
        this.curSystemModule = imageInfo;
        this.operateSystemInfo.title = "新增影像存档系统";
      }
      if (this.curSystemCode === "Calling") {
        // 语音叫号
        this.curSystemModule = voiceCallInfo;
        this.operateSystemInfo.title = "新增语音叫号系统";
      }
    },
    // 选择系统
    chooseSystemType(systemCode) {
      const self = this;
      // self.curSystemType = type;
      self.curSystemCode = systemCode;
      self.loadCurComponents();
      console.log("self.curSystemCode", self.curSystemCode);
      self.$nextTick(() => {
        if (self.curSystemCode === "Self") {
          // 远程医疗--本系统服务中心
          self.$refs.telemedicineListListRefTest &&
            self.$refs.telemedicineListListRefTest.isShowinfoFn("add", {
              service_center_type: 0,
            }); // 新增本系统服务中心
          // 获取机构列表
          self.$refs.telemedicineListListRefTest &&
            self.$refs.telemedicineListListRefTest.getMyInstitutions();
        } else if (self.curSystemCode === "Other") {
          // 远程医疗--第三方服务中心
          self.$refs.telemedicineListListRefTest &&
            self.$refs.telemedicineListListRefTest.isShowinfoFn("add", {
              service_center_type: 1,
            }); // 新增第三方服务中心
          // 获取机构列表
          self.$refs.telemedicineListListRefTest &&
            self.$refs.telemedicineListListRefTest.getMyInstitutions();
        }

        // 远程教学
        if (self.curSystemCode === "Teach") {
          self.$refs.distanceTeachingListRefTest &&
            self.$refs.distanceTeachingListRefTest.isShowinfoFn("add", {
              teach_type: 0,
            });
          // 获取机构列表
          self.$refs.distanceTeachingListRefTest &&
            self.$refs.distanceTeachingListRefTest.getMyInstitutions();
        }
        // 基地教学
        if (self.curSystemCode === "ProfessionalBase") {
          self.$refs.distanceTeachingListRef[index] &&
            self.$refs.distanceTeachingListRef[index].isShowinfoFn("add", {
              teach_type: 1,
            });
          // 获取机构列表
          self.$refs.distanceTeachingListRef[index] &&
            self.$refs.distanceTeachingListRef[index].getMyInstitutions();
        }

        // 科室教学
        if (self.curSystemCode === "DepartmentTeach") {
          self.$refs.distanceTeachingListRefTest &&
            self.$refs.distanceTeachingListRefTest.isShowinfoFn("add", {
              teach_type: 2,
            });
          // 获取机构列表
          self.$refs.distanceTeachingListRefTest &&
            self.$refs.distanceTeachingListRefTest.getMyInstitutions();
        }
        // 影像质控(医技质控)
        if (self.curSystemCode === "Quality") {
          self.$refs.imageControlSystemListRefTest &&
            self.$refs.imageControlSystemListRefTest.isShowinfoFn("add");
        }
        // 影像共享
        if (self.curSystemCode === "IDCAS") {
          self.$refs.imageSharingListRefTest &&
            self.$refs.imageSharingListRefTest.chooseSystemType(2);
        }
        // 影像共享-刑侦调阅
        if (self.curSystemCode === "ImageCriminal") {
          self.$refs.imageSharingListRefTest &&
            self.$refs.imageSharingListRefTest.chooseSystemType(7);
        }
        // 科室管理(智能科室)
        if (self.curSystemCode === "DMS") {
          self.$refs.intelligenceOfficeListRefTest &&
            self.$refs.intelligenceOfficeListRefTest.isShowinfoFn("add");
        }
        // 患者服务
        if (self.curSystemCode === "EWSPS") {
          self.$refs.patientServicesRefTest &&
            self.$refs.patientServicesRefTest.isShowinfoFn("add");
        }
        // 影像大数据
        if (self.curSystemCode === "IBDSS") {
          self.$refs.imageBigDataListRefTest &&
            self.$refs.imageBigDataListRefTest.isShowinfoFn("add");
        }
        // 智能诊断
        if (self.curSystemCode === "AIM") {
          self.$refs.aimListRefTest &&
            self.$refs.aimListRefTest.isShowinfoFn("add");
        }
      });

      if (self.curSystemCode === "Calling") {
        // 叫号
        self.beganGetCallingService();
        self.isShowinfoFn("add");
      }
      if (self.curSystemCode === "PACS") {
        // 获取某个pacs 下的 开通的服务
        self.getPasServicecListFn();
        self.isShowinfoFn("add");
      }
      if (self.curSystemCode === "EWCSS") {
        self.getEWCSSServicecListFn();
        self.isShowinfoFn("add");
      }
      if (self.curSystemCode === "ImageArchive") {
        self.isShowinfoFn("add");
      }
    },
    async beganGetCallingService() {
      const res = await getCallingService();
      if (res.code === 0) {
        this.operateSystemInfo.systemList = res.data;
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    initDifferentSystemVal() {
      const self = this;
      self.operateSystemInfo.formInfo.product_code = self.curSystemCode;
      if (self.curSystemCode === "PACS") {
        self.operateSystemInfo.title = "新增PACS系统";
        self.operateSystemInfo.formInfo.product_code = "";
      }
      if (self.curSystemCode === "Telemed") {
        // 远程医疗
        self.operateSystemInfo.title = "新增服务中心";
      }
      if (self.curSystemCode === "Teach") {
        // 远程教学
        self.operateSystemInfo.title = "新增教学中心";
      }
      if (self.curSystemCode === "Quality") {
        // 医技质控
        self.operateSystemInfo.title = "新增质控系统";
      }
      if (self.curSystemCode === "DMS") {
        // 科室管理
        self.operateSystemInfo.title = "新增智能科室系统";
      }
      if (self.curSystemCode === "IDCAS") {
        // 影像共享
        self.operateSystemInfo.title = "新增影像共享系统";
      }
      if (self.curSystemCode === "EWCSS") {
        // 集中预约
        self.operateSystemInfo.title = "新增全资源预约系统";
      }
      if (self.curSystemCode === "ImageArchive") {
        // 影像存档
        self.operateSystemInfo.title = "新增影像存档系统";
      }
      if (self.curSystemCode === "Calling") {
        // 排队叫号
        self.operateSystemInfo.title = "新增排队叫号系统";
      }
      if (self.curSystemCode === "IBDSS") {
        // 影像大数据
        self.operateSystemInfo.title = "新增影像大数据系统";
      }

      if (self.curSystemCode === "AIM") {
        self.operateSystemInfo.title = "新增智能诊断系统";
        // 将之前选择的机构清空

        self.$nextTick(() => {
          self.$refs.info.page = 1;
          self.$refs.info.size = 10;
          self.$refs.info.tableData = [];
          self.$refs.info.choosedInstituteArr = [];
          self.$refs.info.getTabelData2();
          self.$refs.info.$refs.qualityInstituTable.doLayout();
        });
      }
    },
    changePhone() {
      if (this.isUpdate) {
        // 是否是第一次改变
        if (this.isFirstChange) {
          this.operateSystemInfo.formInfo.admin_phone = "";
          this.operateSystemInfo.formInfo.admin_name = "";
        }
        this.isFirstChange = false;
      }
    },
    // 系统列表
    async getPascListFn() {
      const self = this;
      self.systemList = [];
      self.systemTabList = [];
      self.tabIndex = -1;
      self.curProductCode = "";
      const res = await getAllApplicationSystemList(self.searchSystemParam);
      if (res.code === 0) {
        self.loading = false;
        const result = res.data;
        if (result.length != 0) {
          result.forEach((item) => {
            self.systemTabList.push(item);
            if (item.systems.length != 0) {
              item.systems.forEach((one) => {
                one.code = item.code;
                self.systemList.push(one);
              });
            }
          });
        }
        self.$nextTick(() => {
          self.$refs.imageSharingListRefTest.initData();
          self.$refs.imageControlSystemListRefTest.initData();
          self.$refs.intelligenceOfficeListRefTest.initData();
        });
      } else {
        self.loading = false;
        self.$message({ type: "error", message: res.msg });
      }
    },
    async beganGetServiceTypePower(id) {
      const res = await getServiceTypePower({ tenancy_id: id });
      if (res.code === 0) {
        this.serviceTypePowerObj = res.data;
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 获取 全资源预约的开通服务
    async getEWCSSServicecListFn() {
      const res = await getEWCSSServicecList();
      if (res.code === 0) {
        this.EWCSSServicecList = res.data;
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 授权产品列表
    async getPasServicecListFn() {
      const self = this;
      self.operateSystemInfo.systemList = [];
      self.pacsServiceList = [];
      const res = await getPasServicecList();
      if (res.code === 0) {
        if (res.data.length != 0) {
          res.data.forEach((val) => {
            self.operateSystemInfo.systemList.push(val);
            self.pacsServiceList.push(val);
            // 初始化协同产品对象  新增时默认勾选科室教学
            if (self.isUpdate == false) {
              // self.$set(self.pacsCooperateProductObj,val.code,[1100])
              self.$set(self.pacsCooperateProductObj, val.code, []);
            }
            // 初始化产品服务对象
            self.$set(self.productServiceObj, val.code, []);
          });
        }
        //console.log(self.pacsServiceList)
      }
    },
    isAddInstution() {
      if (!this.operateSystemInfo.formInfo.product_code) {
        this.$message({
          type: "warning",
          message: "请选择授权产品！",
        });
        return;
      }
      this.InstitutionPage.page_index = 1;
      this.InstitutionPage.page_size = 10;
      this.getInstitutionListFn();
      this.operateSystemInfo.isChioseOrgan = true;
    },
    // 获取菜单
    getOwnMenu(system_id) {
      return new Promise((resolve) => {
        ownMenu().then((res) => {
          if (res.code != 0) {
            this.$message.error(res.msg);
            return;
          }
          let arr = res.data.filter((item) => {
            //return item.name === 'serviceCenterManage' && item.service_center_id == centerId
            return item.system_id == system_id;
          });
          let url = "";
          if (arr[0].children[0].children.length != 0) {
            //有二级子菜单
            if (arr[0].children[0].children[0].children.length != 0) {
              url =
                arr[0].children[0].children[0].path +
                arr[0].children[0].children[0].children[0].path;
            } else {
              url =
                arr[0].children[0].path + arr[0].children[0].children[0].path;
            }
          } else {
            // 只有一级菜单
            url = arr[0].children[0].path;
          }
          resolve(url);
        });
      });
    },
    // 点击管理处理跳转
    dealSkip(obj, id, systemCode) {
      if (systemCode === "PACS") {
        // 云pacs
        window.sessionStorage.setItem("ChosedSystemName", "DepartmentSystem"); // 菜单name
        const href = "/operate/DepartmentSystem/UserList";
        const pisHref = "/operate/DepartmentSystem/userList";
        var newHref;
        if (obj.product_code === "PIS") {
          // 病理PACS系统 跳转时 去掉 /cloudpacs
          newHref =
            configUrl.frontEndUrl +
            "/piscloudpacs/operate/DepartmentSystem/pisSystemSet/systemParameter" +
            "?system_id=" +
            id;
          window.open(newHref, "_blank");
        } else if (obj.product_code === "NMIS" || obj.product_code === "RTIS") {
          // newHref = configUrl.frontEndUrl +'/nmis/operate/DepartMentManage/user/UserList?system_id='+id
          // window.open(newHref, "_blank");
          this.getOwnMenu(id).then((url) => {
            // 新的跳转
            const { href } = this.$router.resolve({
              path: url,
              query: { system_id: id },
            });
            window.open(href, "_blank");
          });
        } else if (
          obj.product_code === "DRIS" ||
          obj.product_code === "ECGIS" ||
          obj.product_code === "OIS"
        ) {
          // 眼科\心电\数字化报告
          newHref =
            configUrl.frontEndUrl +
            "/epis/operate/DepartmentSystem/UserList?system_id=" +
            id +
            "&ChosedSystemName=" +
            "DepartmentSystem";
          window.open(newHref, "_blank");
        }
        // else if (obj.product_code === "RTIS") { // 放疗
        //   newHref = configUrl.frontEndUrl +'/rtis/systemset/TemplateManage/FormTemplate';
        //   window.open(newHref, "_blank");
        // }
        else if (
          obj.product_code === "RIS" ||
          obj.product_code === "UIS" ||
          obj.product_code === "EIS"
        ) {
          // 放射、超声、内镜
          newHref =
            configUrl.frontEndUrl +
            "/cloudpacs/operate/DepartmentSystem/systemSet/systemParameter?system_id=" +
            id;
          window.open(newHref, "_blank");
        } else {
          newHref =
            configUrl.frontEndUrl +
            "/cloudpacs" +
            href +
            "?system_id=" +
            id +
            "&ChosedSystemName=" +
            "DepartmentSystem";
          window.open(newHref, "_blank");
        }
        // this.getOwnMenu(id).then((url) => {
        //   // 新的跳转
        //   const { href } = this.$router.resolve({ path: url, query: { system_id: id, ChosedSystemName: 'DepartmentSystem'} })
        //   window.open(href, '_blank')
        // })
      } else if (obj.product_code === "EWCSS") {
        // 检查预约 以前product_code 叫ExamSchedule
        var path = process.env.NODE_ENV === "development" ? "" : "/ewcss";
        let href;
        //如果检查预约 跟  治疗预约都开通，默认跳转到检查预约菜单
        //如果开通服务为空，，默认跳转到检查预约菜单
        if (
          obj.function_services.length == 2 ||
          obj.function_services.length == 0 ||
          (obj.function_services.length != 0 &&
            obj.function_services[0].code == 2010)
        ) {
          href = configUrl.frontEndUrl + path + "/examSchedule/request";
        } else {
          //跳转到治疗预约
          href = configUrl.frontEndUrl + path + "/treatmentSchedule/request";
        }
        sessionStorage.setItem("system_id", id);
        window.open(href, "_blank");
      } else if (obj.product_code === "Calling") {
        // 语音叫号
        var path = process.env.NODE_ENV === "development" ? "" : "/calling/";
        //const href = configUrl.frontEndUrl + path + '/ExamSchedule/ScheduleList'
        const href = configUrl.frontEndUrl + path;
        sessionStorage.setItem("system_id", id);
        window.open(href, "_blank");
      } else if (obj.product_code === "ImageArchive") {
        // 影像存档
        // var path = process.env.NODE_ENV === "development" ? "" : "/paservice";
        // const href =
        //   configUrl.frontEndUrl +
        //   path +
        //   "/?scope=" +
        //   "institution" +
        //   "&group=tenancy";
        this.getOwnMenu(id).then((url) => {
          // 新的跳转
          const { href } = this.$router.resolve({
            path: url,
            query: { group: "tenancy" },
          });
          sessionStorage.setItem("system_id", id);
          window.open(href, "_blank");
        });
      } else if (obj.product_code === "AIM") {
        // 智能诊断
        const href =
          configUrl.frontEndUrl +
          "/intelligentDiagnosis/accessManagement/dataOverview";
        sessionStorage.setItem("system_id", id);
        window.open(href, "_blank");
      }
      // 请求菜单的方式
      // this.getOwnMenu(id).then((url) => {
      //     // 新的跳转
      //     const { href } = this.$router.resolve({ path: url, query: { system_id: id } })
      //     sessionStorage.setItem("system_id", id);
      //     window.open(href, "_blank");
      //   })
    },
    // 递归拼接 跳转的URL
    getFirstChildItems(arr) {
      let result = "";
      // 参数system 只是用来辨别下 是什么系统
      function checkChildren(system, item) {
        // 影像存档特殊处理
        if (system.path == "paservice") {
          if (item.path.indexOf("paservice") == -1) {
            result = "/paservice" + item.path;
          } else {
            result = result + item.path;
          }
        } else {
          // 不是影像存档系统
          result = result + item.path;
        }

        if (item.children && item.children[0]) {
          // 如果有children的话 进行递归
          checkChildren(item, item.children[0]);
        }
      }
      // 如果子节点
      if (arr[0] && arr[0].children) {
        checkChildren(arr[0], arr[0].children[0]);
      } else {
        result = result + "/" + arr[0].path;
      }
      return result;
    },
    // 获取菜单
    getOwnMenu(id) {
      const self = this;
      return new Promise((resolve) => {
        ownMenu().then((res) => {
          if (res.code != 0) {
            self.$message.error(res.msg);
            return;
          }
          let arr = res.data.filter((item) => {
            return item.system_id == id;
          });
          const url = self.getFirstChildItems(arr);
          console.log("url", url);
          resolve(url);
        });
      });
    },
    // 进入科室管理
    enterOfficeManage(obj) {
      var id;
      var code;
      var isopen;
      id = obj.id;
      isopen = obj.is_jump;
      code = obj.product_code;
      if (obj.type === 1 && !isopen) {
        // 只有云pacs 才需要判断
        self.$message({
          type: "error",
          message: "新增的系统，如需管理，请重新登录!",
        });
        return;
      }
      if (code) {
        sessionStorage.setItem("currentSystemClass", code);
      }
      if (id) {
        sessionStorage.setItem("lastname", id);
      }
      var newHref;
      newHref = configUrl.frontEndUrl + "/dms/" + "?system_id=" + id;
      window.open(newHref, "_blank");
    },
    // 进入科室教学管理
    enterOfficeTeachManage(obj) {
      var id;
      var code;
      var isopen;
      id = obj.id;
      isopen = obj.is_jump;
      code = obj.product_code;
      if (obj.type === 1 && !isopen) {
        // 只有云pacs 才需要判断
        self.$message({
          type: "error",
          message: "新增的系统，如需管理，请重新登录!",
        });
        return;
      }
      if (code) {
        sessionStorage.setItem("currentSystemClass", code);
      }
      if (id) {
        sessionStorage.setItem("lastname", id);
      }
      var newHref;
      newHref =
        configUrl.frontEndUrl +
        `/teleeducation/${code.toLowerCase()}/index?system_id=${id}`;
      window.open(newHref, "_blank");
    },
    // 编辑非pacs 系统时 将pacs的编辑 el-draw 抽屉关闭
    closeAllDrawDetailAlert(code) {
      const self = this;
      self.$nextTick(() => {
        if (self.updateSystemCode != code) {
          // 编辑不同的 业务系统
          self.isPacsinfo = false;
          // self.$refs.telemedicineListListRef.isPacsinfo = false
          // self.$refs.distanceTeachingListRef.isPacsinfo = false
          // self.$refs.imageControlSystemListRef.isPacsinfo = false
          // self.$refs.imageSharingListRef.isPacsinfo = false
          // self.$refs.intelligenceOfficeListRef.isPacsinfo = false
          // self.$refs.imageBigDataListRef.isPacsinfo = false
          // self.$refs.aimListRef.isPacsinfo = false

          self.systemList.forEach((item, index) => {
            if (
              self.$refs.telemedicineListListRef &&
              self.$refs.telemedicineListListRef[index]
            ) {
              self.$refs.telemedicineListListRef[index].isPacsinfo = false;
            }
            if (
              self.$refs.distanceTeachingListRef &&
              self.$refs.distanceTeachingListRef[index]
            ) {
              self.$refs.distanceTeachingListRef[index].isPacsinfo = false;
            }
            if (
              self.$refs.imageControlSystemListRef &&
              self.$refs.imageControlSystemListRef[index]
            ) {
              self.$refs.imageControlSystemListRef[index].isPacsinfo = false;
            }
            if (
              self.$refs.imageSharingListRef &&
              self.$refs.imageSharingListRef[index]
            ) {
              self.$refs.imageSharingListRef[index].isPacsinfo = false;
            }
            if (
              self.$refs.intelligenceOfficeListRef &&
              self.$refs.intelligenceOfficeListRef[index]
            ) {
              self.$refs.intelligenceOfficeListRef[index].isPacsinfo = false;
            }
            if (
              self.$refs.imageBigDataListRef &&
              self.$refs.imageBigDataListRef[index]
            ) {
              self.$refs.imageBigDataListRef[index].isPacsinfo = false;
            }
            if (self.$refs.aimListRef && self.$refs.aimListRef[index]) {
              self.$refs.aimListRef[index].isPacsinfo = false;
            }
          });
        }
        self.updateSystemCode = code;
      });
    },
    // 编辑系统
    async updateSystem(systemItem, systemCode) {
      const self = this;
      self.updateSystemCode = "PACS"; // 把之前的 集中预约、影像存档、排队叫号 还是先归类为pacs
      await self.closeAllDrawDetailAlert();
      self.isactive = systemItem.id;
      self.isPacsinfo = true;
      self.isUpdate = true;
      self.curSystemCode = systemCode;
      self.loadCurComponents();
      self.isFirstChange = true;
      self.operateSystemInfo.title = "编辑";
      if (systemCode === "Calling") {
        self.beganGetCallingService();
      }
      if (systemCode === "PACS") {
        // 获取某个pacs 下的 开通的服务
        self.getPasServicecListFn();
      }
      if (systemCode === "EWCSS") {
        self.getEWCSSServicecListFn();
      }
      self.getDetailFinished = false;
      if (
        systemCode === "PACS" ||
        systemCode === "EWCSS" ||
        systemCode === "ImageArchive" ||
        systemCode === "Calling"
      ) {
        const responce = getPacsSystemsInfoByid(systemItem.id); // 详情接口
        self.operateSystemInfo.multipleSelection = [];
        responce.then((res) => {
          if (res.code === 0) {
            self.operateSystemInfo.product_name = res.data.product_name;
            self.operateSystemInfo.formInfo.product_code =
              res.data.product_code;
            self.operateSystemInfo.formInfo.id = res.data.id;
            self.operateSystemInfo.formInfo.name = res.data.name;
            self.operateSystemInfo.formInfo.admin_phone = res.data.admin_phone;
            self.operateSystemInfo.formInfo.admin_name = res.data.admin_name;

            self.operateSystemInfo.formInfo.isIndefinitely =
              res.data.stop_date === "无期限" ? true : false;
            self.operateSystemInfo.formInfo.start_date = res.data.start_date;
            self.operateSystemInfo.formInfo.stop_date =
              res.data.stop_date === "无期限" ? "" : res.data.stop_date;
            self.operateSystemInfo.formInfo.state = res.data.state;
            self.operateSystemInfo.formInfo.reason = res.data.reason;

            self.operateSystemInfo.multipleSelection = res.data.institutions;
            self.operateSystemInfo.institution_count =
              res.data.institution_count;
            self.operateSystemInfo.formInfo.service_codes =
              res.data.service_codes;
            self.operateSystemInfo.isAdminname = true;
            if (res.data.providers.length != 0) {
              self.operateSystemInfo.providersObj = res.data.providers[0];
            }
            if (systemCode === "EWCSS") {
              self.operateSystemInfo.formInfo.function_services =
                res.data.function_services;
            }
            self.$set(
              self.productServiceObj,
              res.data.product_code,
              res.data.function_services
            );
            // 赋值协同产品
            self.collab_service_codes = res.data.collab_service_codes;
            self.$set(
              self.pacsCooperateProductObj,
              res.data.product_code,
              res.data.collab_service_codes
            );
            self.isChoiceFirst = true;
            self.getDetailFinished = true;
          } else {
            self.$message({ type: "error", message: res.msg });
          }
        });
      }
    },
    // 操作按钮
    isShowinfoFn(type, obj, systemCode) {
      const self = this;
      var id;
      var code;
      var isopen;

      // 新增和编辑时重置下产品对象下开通的服务
      for (let code in self.productServiceObj) {
        self.$set(self.productServiceObj, code, []);
      }
      // 新增和编辑时重置下产品对象下开通的服务
      for (let code in self.pacsCooperateProductObj) {
        self.$set(self.pacsCooperateProductObj, code, []);
      }

      if (obj) {
        id = obj.id;
        code = obj.product_code;
        isopen = obj.is_jump;
        //self.curSystemType = obj.type;
      }
      if (type === "add") {
        self.isPacsinfo = true;
        self.isUpdate = false;
        self.operateSystemInfo = self.$options.data().operateSystemInfo;
        if (self.curSystemCode == "PACS") {
          self.$nextTick(() => {
            self.$refs.info.activesystemIndex = -1;
          });
        }
        self.initDifferentSystemVal();
      } else if (type === "operate") {
        if (obj.type === 1 && !isopen) {
          // 只有云pacs 才需要判断
          self.$message({
            type: "error",
            message: "新增的系统，如需管理，请重新登录!",
          });
          return;
        }
        if (code) {
          sessionStorage.setItem("currentSystemClass", code);
        }
        if (id) {
          sessionStorage.setItem("lastname", id);
        }
        self.dealSkip(obj, id, systemCode);
      } else if (type === "aboutSystem") {
        // 关于系统
        var manager = new Mgr();
        let appKey = obj.product_code == "PIS" ? "pis" : "cloudpacs";
        if (obj.product_code == "EWCSS") {
          // 集中预约
          appKey = "cloudcss";
        } else if (obj.product_code == "NMIS") {
          // 核医学
          appKey = "nmis";
        } else if (obj.product_code == "ECGIS") {
          // 心电
          appKey = "ecgis";
        } else if (obj.product_code == "OIS") {
          // 眼科
          appKey = "ois";
        } else if (obj.product_code == "DRIS") {
          // 数字化报告
          appKey = "dris";
        } else if (obj.product_code == "ImageArchive") {
          // 影像存档
          appKey = "archive";
        } else if (obj.product_code == "RTIS") {
          // 放疗
          appKey = "rtis";
        }
        manager.getRole().then(function (item) {
          if (item) {
            aboutSystem(appKey, item);
          }
        });
      }
    },
    changeService(arr) {
      const self = this;
      self.$set(
        self.productServiceObj,
        self.operateSystemInfo.formInfo.product_code,
        arr
      );
      if (arr.length > 0) {
        for (let code in self.productServiceObj) {
          if (code != self.operateSystemInfo.formInfo.product_code) {
            self.$set(self.productServiceObj, code, []);
          }
        }
      }
    },
    // 改变协同产品
    changeCooperateProductObj(arr) {
      const self = this;
      self.$set(
        self.pacsCooperateProductObj,
        self.operateSystemInfo.formInfo.product_code,
        arr
      );
      if (arr.length > 0) {
        for (let code in self.pacsCooperateProductObj) {
          if (code != self.operateSystemInfo.formInfo.product_code) {
            self.$set(self.pacsCooperateProductObj, code, []);
          }
        }
      }
    },
    activePacsSystemFn(index, code) {
      //console.log(this.productServiceObj)
      this.operateSystemInfo.activesystem = index;
      this.operateSystemInfo.formInfo.product_code = code;
      // 编辑时
      if (this.operateSystemInfo.title == "编辑") {
      } else {
        // 新增时
        this.operateSystemInfo.formInfo.function_services = [];
      }
    },
    // 选择产品类型
    activeSystemFn(index, code) {
      this.operateSystemInfo.activesystem = index;
      this.operateSystemInfo.formInfo.product_code = code;
    },
    // 选择产品类型
    activeVoiceSystemFn(index, obj) {
      const self = this;
      self.operateSystemInfo.activesystem = index;
      self.operateSystemInfo.formInfo.service_codes = [];
      for (var key in obj) {
        if (obj[key]) {
          self.operateSystemInfo.formInfo.service_codes.push(key);
        }
      }
    },
    // 手机号姓名匹配
    async getAdminNameFn() {
      var _phone = this.operateSystemInfo.formInfo.admin_phone;
      var phoneReg = /^1[3456789]\d{9}$/;
      if (!phoneReg.test(_phone)) {
        return;
      }
      var url = `/users/lite/${_phone}`;
      var res = await getLoginName(url);
      if (res.code === 0) {
        this.operateSystemInfo.formInfo.admin_name = res.data
          ? res.data.name
          : "";
        this.operateSystemInfo.isAdminname = true;
      } else {
        this.operateSystemInfo.isAdminname = false;
        this.operateSystemInfo.formInfo.admin_name = "";
      }
    },
    handleClose(done) {
      done();
    },
    // 关闭 选择机构
    instclose() {
      this.operateSystemInfo.institutionList.forEach((item) => {
        this.$nextTick(() => {
          this.$refs.info.$refs.institutions.toggleRowSelection(item, false);
        });
      });
      this.operateSystemInfo.isChioseOrgan = false;
    },
    closeFn() {
      var info = {
        type: "cancel",
        refs: this.$refs["info"].$refs,
        formName: "formInfo",
      };
      this.submitForm(info);
    },
    // 获取机构列表
    async getInstitutionListFn() {
      const self = this;
      let filter_system_id = "";
      if (
        self.operateSystemInfo.formInfo.product_code !== "PACS" ||
        self.operateSystemInfo.formInfo.product_code !== "EWCSS"
      ) {
        filter_system_id = "&filter_system_id=" + self.isactive;
      }
      // 机构的获取 云pacs 跟 集中预约有区别的
      let _url;
      if (this.curSystemCode === "PACS") {
        _url =
          "/institutions?office_type=2&product_code=" +
          self.operateSystemInfo.formInfo.product_code +
          "&offset=" +
          self.InstitutionPage.page_index +
          "&limit=" +
          this.InstitutionPage.page_size +
          filter_system_id;
      } else if (this.curSystemCode === "EWCSS") {
        _url =
          "/institutions?offset=" +
          self.InstitutionPage.page_index +
          "&limit=" +
          this.InstitutionPage.page_size +
          filter_system_id;
      }
      const res = await getInstitutionList(_url);
      self.$refs.info.$refs.institutions.clearSelection();
      if (res.code === 0) {
        res.data.forEach((item) => {
          item.office_ids = [];
          if (item.offices.length === 1) {
            item.office_ids[0] = item.offices[0].id;
          }
        });
        self.operateSystemInfo.institutionList = res.data;
        self.InstitutionPage = res.page;
        if (self.operateSystemInfo.title === "编辑") {
          // 勾上已选中的
          res.data.forEach((itemids) => {
            self.operateSystemInfo.multipleSelection.forEach((item) => {
              if (itemids.id === item.id) {
                self.$nextTick(() => {
                  self.$refs.info.$refs.institutions.toggleRowSelection(
                    itemids,
                    true
                  );
                });
                itemids.office_ids = item.office_ids;
              }
            });
          });
        }
      }
    },
    getRowKeys(row) {
      return row.id;
    },
    // 分页
    pageSizeChangeFn(info) {
      this.InstitutionPage.page_index = info.page;
      this.InstitutionPage.page_size = info.limit;
      this.getInstitutionListFn();
    },
    // 选中某一行
    selectCurRow(selection, row) {
      const self = this;
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1;
      // 去掉选中时
      if (!selected) {
        self.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === row.id) {
            self.operateSystemInfo.multipleSelection.splice(i, 1);
          }
        });
      }
    },
    // 去掉数组元素 里面对象 id值相同的
    clearCommonId(arr) {
      let obj = {};
      let peon = arr.reduce((cur, next) => {
        obj[next.id] ? "" : (obj[next.id] = true && cur.push(next));
        return cur;
      }, []);
      return peon;
    },
    handleInstituSelectionChange(val) {
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    // 机构 select change事件
    selectInstitionListFn(val) {
      // if (this.InstitutionPage.page_index === 1 && this.isChoiceFirst) {
      //   this.choiseList = [...this.operateSystemInfo.multipleSelection, ...rows]
      // } else {
      //   this.choiseList = rows
      // }
      // this.isChoiceFirst = false
      const self = this;
      val.forEach((item) => {
        self.operateSystemInfo.multipleSelection.push(item);
      });
      self.operateSystemInfo.multipleSelection = self.clearCommonId(
        self.operateSystemInfo.multipleSelection
      );
    },
    // 机构 提交
    ChoiceOrganFn(type) {
      // if (type === 'commit') {
      //   this.operateSystemInfo.multipleSelection = this.choiseList
      // }
      this.instclose();
    },
    CheckOfficeidsFn(row) {
      const self = this;
      if (self.operateSystemInfo.multipleSelection.length != 0) {
        self.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id == row.id) {
            self.operateSystemInfo.multipleSelection.splice(i, 1, row);
          }
        });
      }
      // console.log(val)
    },
    delInstitutionFn(id) {
      this.$confirm("是否删除这条机构信息？", "删除信息", {
        distinguishCancelAndClose: true,
        confirmButtonText: "删除",
        cancelButtonText: "取消",
      }).then(() => {
        this.operateSystemInfo.multipleSelection.forEach((item, i) => {
          if (item.id === id) {
            if (this.operateSystemInfo.institutionList.length > 0) {
              this.$refs.info.$refs.institutions.toggleRowSelection(
                item,
                false
              );
            }
            this.operateSystemInfo.multipleSelection.splice(i, 1);
            this.$message({
              type: "success",
              message: "删除成功",
            });
          }
        });
      });
    },
    // 去重
    clearCommonService(arr) {
      let newArr = [];
      if (arr.length != 0) {
        arr.forEach((item) => {
          if (newArr.indexOf(item) == -1) {
            newArr.push(item);
          }
        });
      }
      return newArr;
    },
    initPacsSystemType() {
      if (this.curSystemCode === "Calling") {
        // 排队叫号
        this.operateSystemInfo.formInfo.type = 5;
      } else if (this.curSystemCode === "EWCSS") {
        // 集中预约
        this.operateSystemInfo.formInfo.type = 4;
      } else if (this.curSystemCode === "ImageArchive") {
        // 影像存档
        this.operateSystemInfo.formInfo.type = 6;
      } else {
        // 云pacs
        this.operateSystemInfo.formInfo.type = 1;
      }
    },
    async addPacsSystemsFn() {
      let subText = "正在新增，请稍等...";
      if (this.isUpdate) {
        subText = "正在编辑，请稍等...";
      }
      const loading = this.$loading({
        lock: true,
        text: this.operateSystemInfo.formInfo.id
          ? "正在编辑，请稍等..."
          : "正在新增，请稍等...",
        spinner: "el-icon-loading",
        background: "rgba(255, 255, 255, 0.6)",
      });
      // 叫号系统
      if (this.curSystemCode === "Calling") {
        this.operateSystemInfo.formInfo.product_code = "Calling";
      }
      // 初始化 前pacs系统的type
      this.initPacsSystemType();
      const _params = { ...this.operateSystemInfo.formInfo };
      var _institutionList = [];
      this.operateSystemInfo.multipleSelection.forEach((item) => {
        var info = {};
        info.id = item.id;
        info.office_ids = item.office_ids;
        _institutionList.push(info);
      });
      _params.institutions = _institutionList;
      _params.providers = [];
      _params.providers.push(this.operateSystemInfo.providersObj);
      // 对手机号加密
      var adminPhone = _params.admin_phone;
      _params.admin_phone = this.$getRsaCode(_params.admin_phone);
      // 新增或编辑pacs时
      if (_params.type == 1 || _params.type == 5 || _params.type == 6) {
        _params.function_services = [];
        for (let code in this.productServiceObj) {
          if (
            this.productServiceObj[code] &&
            this.productServiceObj[code].length > 0 &&
            _params.product_code == code
          ) {
            this.productServiceObj[code].forEach((val) => {
              _params.function_services.push(val);
            });
          }
        }
        _params.function_services = this.clearCommonService(
          _params.function_services
        );
        // 赋值协同产品
        _params.collab_service_codes = [];
        for (let code in this.pacsCooperateProductObj) {
          if (
            this.pacsCooperateProductObj[code] &&
            this.pacsCooperateProductObj[code].length > 0 &&
            _params.product_code == code
          ) {
            this.pacsCooperateProductObj[code].forEach((val) => {
              _params.collab_service_codes.push(val);
            });
          }
        }
        _params.collab_service_codes = this.clearCommonService(
          _params.collab_service_codes
        );
      }
      var res = null;
      var tipmsg = `${this.operateSystemInfo.title}成功`;
      // 全资源预约
      if (this.curSystemCode === "EWCSS") {
        // 只有一个检查预约
        this.operateSystemInfo.formInfo.product_code = "EWCSS";
      }

      // 特殊处理一下期限相关的字段
      _params.stop_date = _params.isIndefinitely ? null : _params.stop_date;
      _params.reason = _params.state === 10 ? "" : _params.reason;
      delete _params.isIndefinitely;

      if (_params.id) {
        delete _params["type"];
        res = await putPacsSystems(_params);
        tipmsg = `修改${this.operateSystemInfo.title}成功`;
      } else {
        res = await addPacsSystems(_params);
      }
      loading.close();
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: tipmsg,
        });
        this.isPacsinfo = false;
        this.getPascListFn();
        this.pacsServiceList = [];
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      } else {
        this.operateSystemInfo.formInfo.admin_phone = adminPhone;
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    getSerchName(val) {
      this.operateSystemInfo.serchName = val;
    },
    // 选择机构页面 查询按钮
    async serchListFn() {
      const _url =
        "/institutions?office_type=2&product_code=" +
        this.operateSystemInfo.formInfo.product_code +
        "&offset=1" +
        "&limit=" +
        this.InstitutionPage.page_size +
        "&name=" +
        this.operateSystemInfo.serchName;
      const res = await getInstitutionList(_url);
      if (res.code === 0) {
        this.operateSystemInfo.institutionList = res.data;
      }
    },
    submitForm(info) {
      if (info.type === "commit") {
        if (
          this.curSystemCode !== "Calling" &&
          !this.operateSystemInfo.formInfo.product_code
        ) {
          this.$message({ type: "error", message: "请选择产品" });
          return;
        }
        if (
          this.curSystemCode === "EWCSS" &&
          this.operateSystemInfo.formInfo.function_services.length === 0
        ) {
          this.$message({ type: "error", message: "请选择要开通的服务" });
          return;
        }
        if (
          this.curSystemCode === "Calling" &&
          this.operateSystemInfo.formInfo.service_codes.length === 0
        ) {
          this.$message({ type: "error", message: "请选择产品" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.name) {
          this.$message({ type: "error", message: "请输入系统名称" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.admin_phone) {
          this.$message({ type: "error", message: "请输入管理员电话" });
          return;
        }
        var phoneReg = /^1[3456789]\d{9}$/;
        // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
        if (!this.isUpdate || (this.isUpdate && !this.isFirstChange)) {
          if (!phoneReg.test(this.operateSystemInfo.formInfo.admin_phone)) {
            this.$message({
              message: "请输入正确的手机号码!",
              type: "warning",
            });
            return false;
          }
        }
        if (!this.operateSystemInfo.formInfo.admin_name) {
          this.$message({ type: "error", message: "请输入管理员姓名" });
          return;
        }

        if (!this.operateSystemInfo.formInfo.start_date) {
          this.$message({ type: "error", message: "请选择使用开始期限" });
          return;
        }
        if (
          !this.operateSystemInfo.formInfo.isIndefinitely &&
          !this.operateSystemInfo.formInfo.stop_date
        ) {
          this.$message({ type: "error", message: "请选择使用结束期限" });
          return;
        }
        if (!this.operateSystemInfo.formInfo.state) {
          this.$message({ type: "error", message: "请选择系统状态" });
          return;
        }
        if (
          this.operateSystemInfo.formInfo.state === -2 &&
          !this.operateSystemInfo.formInfo.reason
        ) {
          this.$message({ type: "error", message: "请输入停用备注" });
          return;
        }

        if (info.hasOwnProperty("choosedInstituteArr")) {
          // 智能诊断
          this.operateSystemInfo.multipleSelection = JSON.parse(
            JSON.stringify(info.choosedInstituteArr)
          );
        }
        this.addPacsSystemsFn();
      } else {
        this.isPacsinfo = false;
        this.isactive = "";
        this.operateSystemInfo = this.$options.data().operateSystemInfo;
      }
    },
  },
};
</script>

<style lang="less" scoped>
.systemQuery {
  display: flex;
  padding: 10px;
  padding-bottom: 0px;
  .searchItem {
    display: flex;
    height: 32px;
    align-items: center;
    .searchLabel {
      font-size: 14px;
      height: 100%;
      line-height: 30px;
      color: #606266;
      border-radius: 3px 0 0 3px;
      background: #f5f7fa;
      padding: 0 10px;
      border: 1px solid #dcdfe6;
      border-right: none;
    }
  }
  .searchInputDiv {
    position: relative;
    .searchIcon {
      position: absolute;
      right: 10px;
      top: 9px;
      cursor: pointer;
      color: #c0c4cc;
      font-size: 14px;
    }
  }
}
.tabContainer {
  .crumbsCon {
    display: flex;
    line-height: 32px;
    //  box-shadow: 0 3px 3px 0 rgba(0, 0, 0, 0.06);
    z-index: 900;
    padding: 8px 10px;
    width: calc(100% - 20px);
    //  margin: 8px 0px;
    box-shadow: 0 3px 3px 0 rgba(0, 0, 0, 0.06);
    .m-tab {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .m-tab-item {
      width: 90px;
      color: #303133;
      font-size: 16px;
      text-align: center;
      cursor: pointer;
      // font-weight: 700;
      margin-right: 10px;
      background: rgba(10, 112, 176, 0.08);
      border-radius: 3px;
    }
    .m-tab-item-active {
      color: #fff;
      font-weight: 700;
      background: #0a70b0;
    }
  }
}

.applicationSystemContainer {
  height: 100%;
  overflow: hidden;
  .pacsContainer {
    height: calc(100% - 90px);
    padding: 15px 0px;
    padding-left: 20px;
    padding-top: 15px;
    overflow: auto;
    position: relative;
    background: #f7f8fa;
    .oneSystemType {
      .systemMoudleName {
        line-height: 24px;
        font-size: 19px;
        color: #1f2f3d;
        font-weight: 700;
        padding-bottom: 10px;
      }
      .listItemBox {
        display: flex;
        flex-flow: wrap;
        overflow: hidden;
        //justify-content: space-between;
      }
      .list-item {
        position: relative;
        width: calc(25% - 15px);
        margin-right: 15px;
        box-sizing: border-box;
        border: 1px solid #ebeef5;
        border-radius: 6px;
        background: #ffffff;
        box-shadow: 0 1px 5px 0 rgba(26, 26, 26, 0.050980392156862744);
        margin-bottom: 15px;

        .deactivated-box {
          position: absolute;
          top: 65px;
          right: 20px;
          padding: 4px 10px;
          border: 1px solid #f56c6c;
          color: #f56c6c;
          transform: rotate(45deg);
          text-align: center;
          cursor: pointer;

          .deactivated-time {
            font-size: 12px;
          }
        }

        .pacsItemCon {
          padding: 18px 14px 14px 18px;
          // border-bottom: 1px solid #ebeef5;
        }
        .active {
          background: rgba(10, 112, 176) !important;
          color: #fff !important;
        }
        .pacs_img {
          width: 52px;
          height: 52px;
          vertical-align: middle;
        }
        .title {
          // max-width: 200px;
          width: 100%;
        }
        .systemNameTitle {
          width: 100%;
          font-size: 20px;
          color: #1f2f3d;
          font-weight: 500;
          position: relative;
          top: -3px;
        }
        .pacsSystemNameTitle {
          width: 100%;
          font-size: 20px;
          color: #1f2f3d;
          font-weight: 500;
          position: relative;
          top: -3px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          .systemNameText {
            width: calc(100% - 50px);
          }
          .operateIcon {
            display: flex;
            .operateIcon {
              font-size: 16px;
              color: #909399;
              cursor: pointer;
            }
            .operateIcon:hover {
              color: #0a70b0;
            }
          }
          .item_btn {
            width: 64px;
            height: 30px;
            font-size: 14px;
            line-height: 28px;
            text-align: center;
            background: rgba(255, 255, 255, 1);
            border: 1px solid rgba(10, 112, 176, 0.5);
            border-radius: 3px;
            color: #0a70b0;
          }
          .manageBtn {
            background-color: #0a70b0;
            color: #fff;
          }
        }
        .shareHead {
          width: calc(100% - 70px);
          margin-left: 16px;
        }
        .productIdAndType {
          display: flex;
          .productIdAndTypeText {
            display: inline-block;
            line-height: 22px;
          }
          .productName {
            margin-right: 10px;
          }
          .idNumber {
            display: inline-block;
            max-width: 190px;
          }
        }
        .item_btn {
          padding: 0 10px;
          height: 30px;
          line-height: 28px;
          text-align: center;
          background: rgba(255, 255, 255, 1);
          border: 1px solid rgba(10, 112, 176, 0.5);
          border-radius: 3px;
          color: #0a70b0;
          cursor: pointer;
        }
        .manageBtn {
          background-color: #0a70b0;
          color: #fff;
        }
        .border_bd {
          border-bottom: 1px dashed #dcdfe6;
        }
        .useInstituteLabel {
          width: 70px;
        }
        .useInstituteNum {
          width: calc(100% - 70px);
        }
        .overOneLine {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
        .contractedhospital {
          display: flex;
          .contractedLabel {
            font-size: 14px;
            color: #909399;
          }
          .contractedNum {
            font-size: 14px;
            color: #0a70b0;
            i {
              margin-left: 5px;
            }
          }
        }
        .operateBtnCon {
          display: flex;
          height: 40px;
          align-items: center;
          border-top: 1px solid #ebeef5; // 新加的
          .operateBtnOneBox {
            flex: 1;
            height: 100%;
            display: flex;
            align-items: center;
            cursor: pointer;
          }
          .operateBtnOne {
            width: 100%;
            text-align: center;
            font-size: 14px;
            color: #0a70b0;
            border-right: 1px solid #dcdfe6;
          }
          .operateBtnOneBox:last-of-type {
            .operateBtnOne {
              border-right: none;
            }
          }
          .operateBtnOneBox:hover {
            background: #f2f7ff;
          }
        }
      }
      .activeListItem {
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(10, 112, 176, 0.5);
        outline: 1px solid rgba(10, 112, 176, 0.6);
      }
      .pacsItem {
        display: flex;
        flex-flow: column;
        justify-content: space-between;
      }
      .list-item:hover {
        box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(10, 112, 176, 0.3);
      }
      .list-item:hover .title {
        color: #0a70b0;
      }
    }
  }
}
.adminInfor {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
::v-deep #addMenu {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  .el-menu.el-menu--horizontal {
    border-bottom: none;
  }
  .el-submenu__title:hover {
    background: initial !important;
  }
  .el-submenu__title {
    height: 32px !important;
    line-height: 32px !important;
    border-bottom: none;
  }
  .function-btn {
    display: flex;
  }
  .addSystemIcon {
    font-size: 14px;
    margin-right: 3px;
  }
}
@media screen and (max-width: 1500px) {
  .list-item {
    width: calc(50% - 20px) !important;
  }
  .idNumber {
    max-width: initial !important;
  }
}
.borderNone {
  border: none !important;
}
.addClassDiv {
  text-align: center;
  .serviceCenterClass {
    line-height: 32px;
    cursor: pointer;
  }
}
.createBtn:hover {
  background: #e48e0b !important;
  color: #fff !important;
}
</style>
