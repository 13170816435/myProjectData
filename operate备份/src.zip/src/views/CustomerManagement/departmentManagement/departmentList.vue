<template>
  <div class="userlist">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr5"></i>医疗机构
          <i class="iconfont iconzhankaishouqi"></i> 科室管理
        </span>
      </div>
    </div>
    <div class="container">
      <div class="search-bar">
        <div class="fl">
          <span class="search-bar-label">机构名称 :</span>
          <el-select class="width_200_input" v-model="searchData.institution_id" filterable @change="searchOfficesListFn" placeholder="请选择">
            <el-option
              v-for="item in institutionList"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
        </div>
        <div class="fl ml20">
          <span class="search-bar-label">科室名称 :</span>
          <el-input class="width_200_input" v-model="searchData.depname" v-on:keyup.enter.native=searchOfficesListFn  placeholder="请输入"></el-input>
        </div>
        <div class="fl ml20 officeType">
          <span class="search-bar-label">科室类型 :</span>
          <el-select class="width_200_input" v-model="searchData.type" filterable @change="searchOfficesListFn" placeholder="请选择">
            <el-option
              v-for="(item, index) in baseData.office_type"
              :key="index"
              :label="item.name"
              :value="item.value">
            </el-option>
          </el-select>
        </div>
        <div class="fl ml30 queryAndResetDiv">
          <el-button type="primary" size="small" @click="searchOfficesListFn">查询</el-button>
          <el-button size="small" plain @click="resetFn">重置</el-button>
        </div>
        <div class="fr operateBtnCon">
           <span class="operate-btn clr_0a importBtn mr10" @click="importOffice"
            ><i class="iconfont icondaoru mr5"></i
            >导入科室</span
          >
          <span class="function-btn bg_e6 clr_ff" @click="readyAddOffice">
            <i class="iconfont iconxinzeng mr5"></i>新增科室
          </span>
          <!-- <span class="function-btn clr_0a ml10 border" @click="isImportList = true">
            <i class="iconfont iconxinzeng mr5"></i>批量导入
          </span> -->
        </div>
      </div>
      <div class="table-list mt10" v-bind:class="{'noTableData':officesList.length==0}">
        <el-table
          :height="tableheight"
          v-loading="loading"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          :data="officesList"
          border
          stripe
          highlight-current-row
          header-row-class-name="strong"
        >
          <el-table-column type="index" label="序号" width="60" fixed="left">
            <template slot-scope="scope">
              <span>{{(pageInfo.page_index - 1) * pageInfo.page_size + scope.$index + 1}}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="90" fixed="left">
            <template slot-scope="scope">
              <!-- <span
                class="icon-btn bg_0a"
                @click="operateDepinfo('编辑', scope.row)"
                type="text"
                size="small"
                title="查看"
              >
                <i class="iconfont iconchakan"></i>
              </span>
               <span class="icon-btn bg_f5" type="text" size="small" title="删除" @click="operateDepinfo('删除', scope.row)">
                <i class="iconfont iconshanchu"></i>
              </span> -->
              <span class="clr_0a pointer" @click="operateDepinfo('编辑', scope.row)">编辑</span>
              <span class="clr_da pointer pl10" @click="operateDepinfo('删除', scope.row)">删除</span>
            </template>
          </el-table-column>
          <common-table :propData="propData" :pageInfo="pageInfo"></common-table>
        </el-table>
        <!-- <common-table :dataList="officesList" :propData="propData" :pageInfo="pageInfo" :tableheight="tableheight"></common-table> -->
        <div class="ba">
          <pagination-tool :total="pageInfo.total_count" :page.sync="pageInfo.page_index" :limit.sync="pageInfo.page_size" @pagination="pageSizeChangeFn"/>
        </div>
      </div>
    </div>
   <el-dialog :title="dialogtitle" :visible.sync="isdialogInfo" :close-on-click-modal="false" @close="closeDialogFn" width="600px" v-dialogDrag>
      <add-department ref="addDepartment" :depart_info="depart_info" :rules="rules" :isAdd="isAdd" :isAdminname="isAdminname" :institutionList="institutionList" :OfficesType="baseData.office_type" :OfficeSystemTypeList="OfficeSystemTypeList"
      @changeOfficeType="changeOfficeType" @submitForm="submitForm" @changePhone="changePhone" @getNameFn="getNameFn"></add-department>
    </el-dialog>
    <!--导入科室--->
    <el-dialog
      title="导入科室"
      :visible.sync="isImportOffice"
      width="1000px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <a id="downlink"></a>
      <import-office
        :importList="importList"
        :name="importFileName"
        :operateType="operateType"
        :isInspectFinished="isInspectFinished"
        :isImportFinished="isImportFinished"
        :importTip="importTip"
        @chooseUploadFile="chooseUploadFile"
        @inspectOfficeFn="inspectOfficeFn"
        @importOfficeFn="importOfficeFn"
      ></import-office>
    </el-dialog>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import exportExcel from "@/components/exportExcel";
import ImportOffice from "./components/ImportOffice";
import CommonTable from "./components/CommonTable";
// import CommonTable from '@/components/common/CommonTable'
import AddDepartment from './components/AddDepartment'
import PaginationTool from '@/components/common/PaginationTool'
import { getLoginName } from '@/api/platform_operate/costomer'
import { getOfficesList, getOfficesinfoByid, addOfficesinfo, putOfficesinfo, delOfficesinfo, getInstitutionListLite, importOffice } from '@/api/platform_costomer/institution'
import { getDistinfoByType, getConfigurations } from '@/api/commonHttp'
import Vue from 'vue'
import JSEncrypt from '@/utils/jsencrypt.min'
// import JSEncrypt from 'jsencrypt'
export default {
  components: {
    CommonTable,
    AddDepartment,
    PaginationTool,
    ImportOffice
  },
  computed: {
    ...mapGetters({ // 获取store查询枚举条件
      baseData: 'enumerations'
    })
  },
  data () {
    return {
      tableheight: 700,
      value: '',
      isRouter: false,
      clearTime: false,
      loading: true,
      isFirstChangePhone: true,
      initTime: [],
      searchData: {
        institution_id: '',
        depname: '',
        type: '',
        system_type: ''
      },
      pageLayout: 'total, prev, pager, next, jumper, sizes',
      pageInfo: {
        eof: 1,
        page_index: 1,
        page_size: 20,
        total_count: 10,
        total_pages: 1
      },
      OfficesType: [], // 科室类型
      OfficeSystemTypeList: [], // add 关联系统列表
      propData: [
        // {
        //   prop: '',
        //   label: '操作',
        //   width: 100,
        //   operate: [
        //     { title: '查看', icon: 'iconchakan', class: 'bg_0a', type: '编辑' },
        //     { title: '删除', icon: 'iconshanchu', class: 'bg_f5', type: '删除' }
        //   ]
        // },
        { prop: "name", label: "科室名称", width: 150 },
        { prop: "institution_name", label: "所属机构", width: 290 },
        { prop: "type_desc", label: "科室类型", width: 150 },
        { prop: "code", label: "科室代码", width: 100 },
        { prop: "system_type_desc", label: "关联系统/治疗分类", width: 140 },
        { prop: "admin_name", label: "科室主任", width: 120 },
        { prop: "admin_phone", label: "科室主任手机号", width: 120  },
        { prop: "contact_number", label: "联系电话", width: 120  },
        { prop: "code", label: "平台科室代码", width: 120  },
        { prop: "his_name", label: "HIS科室名称", width: 150  },
        { prop: "his_code", label: "HIS科室代码" },
      ],
      isAdminname: false,
      officesList: [],
      listQuery: {
        pageIndex: 1,
        pageSize: 20
      },
      total: 10000,
      // 科室详情
      isdialogInfo: false,
      isAdd: true,
      inputedAdminPhone: '',
      dialogtitle: '新增科室',
      depart_info: {
        institution_id: '',
        name: '',
        code: '',
        his_code: '',
        his_name: '',
        type: '',
        admin_name: '',
        admin_phone: '',
        is_verify_his_code: true,
        contact_number: '',
        positions: [],
      },
      rules: {
        name: [{ required: true, message: '请输入科室名称', trigger: 'blur' }],
        //code: [{ required: true, message: '请输入科室代码', trigger: 'blur' }],
        type: [{ required: true, message: '请选择科室类型', trigger: 'change' }],
        institution_id: [{ required: true, message: '请选择机构', trigger: 'change' }],
        system_type: [{ required: true, message: '请选择', trigger: 'change' }]
      },
      institutionList: [], // select机构列表
      // 导入科室数据
      isImportOffice: false,
      name: "",
      importList: [],
      importFileName: "",
      importTip: "",
      isImportFinished: true,
      isInspectFinished: false,// 是否检测完成
      operateType: 'inspect',
      inspectErrorArr: [],
      importFormData: new CompatibleFormData(),
    }
  },
  watch: {
    $route () {
      this.initInfo()
    }
  },
  beforeMount () {
    this.$nextTick(() => {
      this.tableheight = document.documentElement.clientHeight - 230
    })
  },
  mounted () {
    // 加密
    this.getConfigurationsFn()
    this.initInfo()
    //this.getDistinfoByTypeFn()
    this.getInstitutionListLiteFn()
    //this.OfficeSystemTypeFn()
  },
  methods: {
   // 导入科室
    importOffice() {
      this.name = "";
      this.importList = [];
      this.importFileName = "";
      this.isInspectFinished = false
      this.operateType = 'inspect'
      this.inspectErrorArr = []
      this.isImportOffice = true;
    },
    // 科室导入-----------------------------------
    verifyIsFrx(file) {
      const fileName = file.raw.name;
      this.currentFileName = file.raw.name;
      const type = fileName.substring(fileName.lastIndexOf(".")).toLowerCase();
      var isFrx = null;
      isFrx = type === ".xlsk" || type === ".xls" || type === ".xlsx";
      if (!isFrx) {
        this.$message.error("上传文件只能是excel格式!");
        return false;
      }
      return isFrx;
    },
    // 上传文件
    chooseUploadFile(file, fileList) {
      if (this.verifyIsFrx(file)) {
        console.log("成功");
        this.importFileName = file.name;
        this.importFormData.delete("file");
        this.importFormData.append("file", file.raw);
        this.importList = [];
        this.isInspectFinished = false
        this.operateType = 'inspect'
        this.inspectErrorArr = []
      }
    },
    // 检测机构
    async inspectOfficeFn () {
      if (!this.importFileName) {
        this.$message.error("请选择文件！");
        return;
      }
      this.importFormData.delete("detect");
      let tips = "";
      this.importFormData.append("detect", 1);
      this.operateType = 'inspect'
      tips = "检测完成！";
      this.importTip = "检测中...";
      this.isImportFinished = false;
      this.isInspectFinished = false
      const res = await importOffice(this.importFormData.compatible());
      if (res.code === 0) {
        this.isImportFinished = true;
        this.isInspectFinished = true
        res.data.forEach((item, i) => {
          item.index = i + 1;
          if (item.result.split("：")[0] === "导入失败：") {
            item.state = 0;
          } else {
            item.state = 1;
          }
        });
        this.inspectErrorArr = res.data.filter((item) => {
          return !item.success;
        });
        if (this.inspectErrorArr.length) {
          tips = `${this.inspectErrorArr.length} 条数据检测异常`;
          this.$message.error(tips);
        } else {
          this.$message.success(tips);
        }
        this.importList = res.data;
        this.searchOfficesListFn();
      } else {
        this.isImportFinished = true;
        this.isInspectFinished = false;
        this.$message.error(res.msg);
      }
    },
    // 开始导入科室
    async beganImportOffice () {
      let tips = "";
      tips = "导入完成！";
      this.importTip = "导入中...";
      this.isImportFinished = false;
      this.isInspectFinished = false
      const res = await importOffice(this.importFormData.compatible());
      if (res.code === 0) {
        this.isImportFinished = true;
        this.isInspectFinished = true
        res.data.forEach((item, i) => {
          item.index = i + 1;
          if (item.result.split("：")[0] === "导入失败：") {
            item.state = 0;
          } else {
            item.state = 1;
          }
        });
        const arr = res.data.filter((item) => {
          return !item.success;
        });
        if (arr.length) {
          tips = `${arr.length} 条数据导入失败`;
          this.$message.error(tips);
        } else {
          this.$message.success(tips);
        }
        this.importList = res.data;
        this.searchOfficesListFn();
      } else {
        this.isImportFinished = true;
        this.isInspectFinished = true;
        this.$message.error(res.msg);
      }
    },
    // 导入科室
    importOfficeFn() {
      const self = this
      // 导入机构
      if (!self.importFileName) {
        self.$message.error("请选择文件！");
        return;
      }
      self.importFormData.delete("detect");
      // 如果存在检测异常 那就进行二次确认是否继续导入
      if (self.inspectErrorArr.length != 0) {
        if (self.inspectErrorArr.length == self.importList.length) {
          self.$message.error("当前Excel文件中的所有科室数据存在异常,无法完成导入");
          return false
        }
        self.$confirm(
          '当前检测出 <span style="color: #da4040">' +
            self.inspectErrorArr.length +
            "</span> 异常数据,是否继续导入",
          "导入科室",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            dangerouslyUseHTMLString: true,
            type: "warning",
          }
        )
          .then(() => {
            self.operateType = 'import'
            self.beganImportOffice()
          })
          .catch(() => {});
      } else {
        self.operateType = 'import'
        self.beganImportOffice()
      }
    },
    // 导入科室方法结束
    changePhone () {
      if (!this.isAdd) {
        // 是否是第一次改变  并且之前输入过了手机号
        if (this.isFirstChangePhone && this.inputedAdminPhone) {
          this.depart_info.admin_phone = ''
          this.depart_info.admin_name = ''
        }
        this.isFirstChangePhone = false
      }
    },
    // 手机号码匹配姓名
    async getNameFn (type, phone) {
      var phoneReg = /^1[3456789]\d{9}$/
      if (!phoneReg.test(phone)) {
        return
      }
      var url = `/users/lite/${phone}`
      var res = await getLoginName(url)
      if (res.code === 0) {
        if (type === 'admin') {
          this.depart_info.admin_name = res.data ? res.data.name : ''
          this.isAdminname = true
        }
      } else {
        if (this.depart_info.admin_name) {
          this.depart_info.admin_name = ''
        }
        this.isAdminname = false
      }
    },
    async getConfigurationsFn () {
      const res = await getConfigurations('TransmissionSecurity.RSA.PublicKey')
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) { // 注册方法
          const pubKey = res.data// ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt()
          encryptStr.setPublicKey(pubKey) // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()) // 进行加密
          return data
        }
      }
    },
    // 初始化
    initInfo () {
      if (this.$route.query.id) {
        this.isRouter = true
        this.searchData.institution_id = this.$route.query.id
        this.depart_info.institution_id = this.$route.query.id
      } else {
        this.searchData.institution_id = ''
        this.isRouter = false
      }
      this.getOfficesListFn()
    },
    // 获取科室类型
    async getDistinfoByTypeFn () {
      var _parmas = 'OfficeType'
      var _url = `/dict/${_parmas}`
      const res = await getDistinfoByType(_url)
      this.OfficesType = res.data
    },
    // 获取机构列表
    async getInstitutionListLiteFn () {
      const self = this
      const url = '?is_query_hospital=true'
      const res = await getInstitutionListLite(url)
      var info = {
        id: '',
        name: '全部'
      }
      res.data.unshift(info)
      self.institutionList = res.data
      // 判断当前机构 是否匹配上了
      let isHadThisInstite = false
      self.institutionList.forEach(function (val) {
        if (val.id === self.searchData.institution_id) {
          isHadThisInstite = true
        }
      })
      if (!isHadThisInstite) {
        self.searchData.institution_id = ''
      }
    },
    // 查询科室
    searchOfficesListFn () {
      this.pageInfo.page_index = 1
      this.pageInfo.page_size = 20
      this.getOfficesListFn()
    },
    // 获取科室列表
    async getOfficesListFn () {
      console.log(this.searchData)
      var _parmas = '/Offices?' + (this.searchData.institution_id ? 'institution_id=' + this.searchData.institution_id + '&' : '') + (this.searchData.depname ? 'contains_name=' + this.searchData.depname + '&' : '') + (this.searchData.type ? 'type=' + this.searchData.type + '&' : '') +'offset=' + this.pageInfo.page_index + '&limit=' + this.pageInfo.page_size
      const res = await getOfficesList(_parmas)
      if (res.code === 0) {
        this.loading = false
        res.data.forEach((item, i) => {
          item.index = i + 1
        })
        this.officesList = res.data
        this.pageInfo = res.page
      } else {
        this.loading = false
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 分页
    pageSizeChangeFn (info) {
      this.pageInfo.page_index = info.page
      this.searchData.offset = info.page
      this.getOfficesListFn()
    },
    // 修改科室类型
    changeOfficeType (val) {
      if (this.depart_info.system_type) {
        this.depart_info.system_type = ''
      }
      this.OfficeSystemTypeFn(val)
    },
    // 关联系统
    async OfficeSystemTypeFn (type) {
      var _parmas = 'OfficeSystemType'
      if (type == 6) {
        _parmas = 'TreatmentClass'
      }
      var _url = `/dict/${_parmas}`
      const res = await getDistinfoByType(_url)
      this.OfficeSystemTypeList = res.data
    },
    readyAddOffice () {
      const self = this
      self.isdialogInfo = true
      self.dialogtitle = '新增科室'
      self.isAdd = true
      self.$nextTick(() => {
        self.$refs.addDepartment.hospitalArr = []
        self.$refs.addDepartment.setOfficeAddressParamsArr =  [{
          institution_id: '',// 机构id (都放在positions字段里)
          building: '',// 楼宇
          floor: '',// 楼层
          diagnostic_area: '',// 诊区
        }]
      })
    },
    // 添加科室成功处理
    addOfficesSuc () {
      const self = this
      self.$message({
        type: 'success',
        message: '添加科室成功！'
      })
      self.depart_info.name = self.$options.data().depart_info.name
      self.$nextTick(() => {
        self.$refs.addDepartment.resetOfficeAddressParams()
      })
      self.getOfficesListFn()
      if (info.type === 'submit') {
        self.isdialogInfo = false
      }
    },
    // 新增科室
    async addOfficesinfoFn (info,setOfficeAddressParamsArr) {
      const self = this
      if (self.depart_info.type === 1) {
        self.depart_info.system_type = ''
      }

      var admin_phone = self.depart_info.admin_phone
      if (admin_phone) {
        self.depart_info.admin_phone = self.$getRsaCode(self.depart_info.admin_phone)
      }

      // 有配置科室的地址
      if (setOfficeAddressParamsArr.length != 0) {
        self.depart_info.positions = []
        setOfficeAddressParamsArr.forEach((item) => {
          if (item.diagnostic_area || item.building || item.floor) {
            let obj = {
              institution_id: item.institution_id ? item.institution_id : this.depart_info.institution_id,
              building: item.building,
              floor: item.floor,
              diagnostic_area: item.diagnostic_area,
            }
            self.depart_info.positions.push(obj)
          }
        })
      }


      const loading = self.$loading({
        lock: true,
        text: "正在添加科室",
        spinner: 'el-icon-loading',
        background: 'rgba(255, 255, 255, 0.6)'
      })
      const res = await addOfficesinfo(self.depart_info)
      if (res.code === 0) {
        loading.close();
        self.addOfficesSuc()
      }
      else if (res.code == 4120019) {// 说明 有已存在的hiscode
          self.$confirm(
            res.msg,
            "提示",
            {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              dangerouslyUseHTMLString: true,
              type: "warning",
            }
          )
            .then(() => {
              self.depart_info.is_verify_his_code = false
              addOfficesinfo(self.depart_info).then((res) => {
                if (res.code == 0) {
                  loading.close();
                  self.addOfficesSuc()
                } else {
                  self.$message.error(res.msg);
                }
              });
            })
          .catch(() => {});
        }
      else {
        self.$message({ type: 'error', message: res.msg })
        self.depart_info.admin_phone = admin_phone
        loading.close();
      }
    },
    // 修改科室成功后的处理
    putOfficeSuc () {
      this.$message({
          type: 'success',
          message: '修改科室成功！'
        })
      this.closeDialogFn()
      this.isdialogInfo = false
      this.getOfficesListFn()
    },
    // 修改科室
    async putOfficesinfoFn (setOfficeAddressParamsArr) {
      const self = this
      if (self.depart_info.type === 1) {
        self.depart_info.system_type = ''
      }
      var admin_phone = self.depart_info.admin_phone
      if (admin_phone) {
        self.depart_info.admin_phone = self.$getRsaCode(self.depart_info.admin_phone)
      }
      const param = {
        id: self.depart_info.id,
        institution_id: self.depart_info.institution_id,
        name: self.depart_info.name,
        code: self.depart_info.code,
        his_code: self.depart_info.his_code,
        his_name: self.depart_info.his_name,
        type: self.depart_info.type,
        admin_name: self.depart_info.admin_name,
        admin_phone: self.depart_info.admin_phone,
        contact_number: self.depart_info.contact_number,
        positions: [],
      }
      // 有配置科室的地址
      if (setOfficeAddressParamsArr.length != 0) {
        param.positions = []
        setOfficeAddressParamsArr.forEach((item) => {
          if (item.diagnostic_area || item.building || item.floor) {
            item.institution_id = item.institution_id ? item.institution_id : param.institution_id
            param.positions.push(item)
          }
        })
      }
      if (self.depart_info.system_type) {
        param.system_type = self.depart_info.system_type
      }
      const loading = self.$loading({
        lock: true,
        text: "正在修改科室",
        spinner: 'el-icon-loading',
        background: 'rgba(255, 255, 255, 0.6)'
      })
      const res = await putOfficesinfo(param)
      if (res.code === 0) {
        loading.close();
        self.putOfficeSuc()
      } else if (res.code == 4120019) {// 说明 有已存在的hiscode
          self.$confirm(
            res.msg,
            "提示",
            {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              dangerouslyUseHTMLString: true,
              type: "warning",
            }
          )
            .then(() => {
              param.is_verify_his_code = false
              putOfficesinfo(param).then((res) => {
                if (res.code == 0) {
                  loading.close();
                  self.putOfficeSuc()
                } else {
                  self.$message.error(res.msg);
                }
              });
            })
          .catch(() => {
            loading.close();
          });
        }
      else {
        self.$message({ type: 'error', message: res.msg })
        self.depart_info.admin_phone = admin_phone
        loading.close();
      }
    },
    // 删除科室
    async delOfficesinfoFn (id) {
      const res = await delOfficesinfo(id)
      if (res.code === 0) {
        this.$message({
          type: 'success',
          message: '删除成功！'
        })
        this.getOfficesListFn()
      } else {
        this.$message({
          type: 'error',
          message: res.msg
        })
      }
    },
    // 获取科室详情
    async getOfficesinfoByidFn (id) {
      const self = this
      const res = await getOfficesinfoByid(id)
      if (res.code === 0) {
        // res.data.type = res.data.type.toString()
        await self.OfficeSystemTypeFn(res.data.type)
        self.depart_info = res.data
        self.$nextTick(() => {
          self.$refs.addDepartment.changeInstitute(res.data.institution_id)
          if (res.data.positions.length == 0) {
            self.$refs.addDepartment.setOfficeAddressParamsArr =  [{
              institution_id: '',// 机构id (都放在positions字段里)
              building: '',// 楼宇
              floor: '',// 楼层
              diagnostic_area: '',// 诊区
            }]
          } else  {
            const positons = res.data.positions
            self.$refs.addDepartment.setOfficeAddressParamsArr = []
            positons.forEach((item) => {
              let obj = {
                institution_id: item.institution_id == res.data.institution_id ? '' : item.institution_id,
                building: item.building,
                floor: item.floor,
                diagnostic_area: item.diagnostic_area,
              }
              self.$refs.addDepartment.setOfficeAddressParamsArr.push(obj)
            })
            //self.$refs.addDepartment.setOfficeAddressParamsArr = res.data.positions
          }

        })
        self.inputedAdminPhone = res.data.admin_phone
        if (self.depart_info.admin_phone) {
          self.isAdminname = true
        } else {
          self.isAdminname = false
        }
      }
    },
    // 表格操作按钮
    operateDepinfo (type, row) {
      if (type === '编辑') {
        this.dialogtitle = '编辑科室'
        this.isdialogInfo = true
        this.isAdd = false
        this.isFirstChangePhone = true
        this.getOfficesinfoByidFn(row.id)
      } else {
        this.$confirm('是否删除这条科室信息？', '删除信息', {
          distinguishCancelAndClose: true,
          confirmButtonText: '删除',
          cancelButtonText: '取消'
        }).then(() => {
          this.delOfficesinfoFn(row.id)
        })
      }
    },

    // 验证 是否存在配置好的相同的楼宇(数组对象里面  对象里面的每个value是否都相同)
    checkUniformValue(arr) {
      for (let i = 0; i < arr.length - 1; i++) {
        const obj1 = arr[i];
        for (let j = i + 1; j < arr.length; j++) {
          const obj2 = arr[j];
          // 检查属性数量是否一致
          if (Object.keys(obj1).length !== Object.keys(obj2).length) continue;
          // 逐个属性比对（浅层比对）
          const isSame = Object.keys(obj1).every(key => obj1[key] === obj2[key]);
          if (isSame) return true;
        }
      }
      return false;
    },

    submitForm (info,setOfficeAddressParamsArr) {
      if (info.type === 'cansol') {
        info.refs[info.formName].resetFields()
        this.isdialogInfo = false
      } else {
        // 验证手机号码
        const phoneReg = /^1[3456789]\d{9}$/
        if (this.depart_info.admin_phone && !this.depart_info.admin_name) {
           this.$message({
              message: '请输入管理员名字',
              type: 'error'
            })
            return false
        }
        if (this.depart_info.admin_name && !this.depart_info.admin_phone) {
           this.$message({
              message: '请输入管理员手机号码',
              type: 'error'
            })
            return false
        }
        if (this.isAdd || (!this.isAdd && !this.isFirstChangePhone)) {
          if (this.depart_info.admin_phone.toString()!= '' && !phoneReg.test(this.depart_info.admin_phone)) {
            this.$message({
              message: '请输入正确的手机号码',
              type: 'error'
            })
            return false
          }
        }
        if (this.checkUniformValue(setOfficeAddressParamsArr)) {
           this.$message({
              message: '存在相同的楼宇,请修改后再提交',
              type: 'error'
            })
            return false
        }


        info.refs[info.formName].validate((valid) => {
          if (valid) {
            if (this.isAdd) {
              this.addOfficesinfoFn(info,setOfficeAddressParamsArr)
            } else {
              this.putOfficesinfoFn(setOfficeAddressParamsArr)
            }
          }
        })
      }
    },
    closeDialogFn () {
      this.depart_info = this.$options.data().depart_info
    },
    resetFn () {
      this.searchData = this.$options.data().searchData
      this.getOfficesListFn()
    }
  }
}
</script>
<style lang="less" scoped>
.userlist {
  height:100%;
  .container {
    height:calc(100% - 46px);
    background: #fff;
    .border{
      border:1px solid rgba(220, 223, 230, 1);
    }
    .search-bar {
      line-height: 32px;
      height: 32px;
      position: relative;
      .search-bar-label {
        display: inline-block;
        min-width: 70px;
        margin-right: 10px;
        color: #303133;
        vertical-align: middle;
      }
      .search-bar-btn {
        padding: 0px 13px;
        height: 32px;
        line-height: 32px;
        border-radius: 3px;
        border: none;
        cursor: pointer;
      }
      .res-bar-btn {
        padding: 0px 13px;
        height: 32px;
        line-height: 32px;
        border-radius: 3px;
        border: 1px solid #ddd;
        cursor: pointer;
        color: #606266;
      }
      .operateBtnCon{
        position:absolute;
        top:0px;
        right:0px;
      }
    }
    .search-bar::after {
        content: '';
        height: 0;
        display: block;
        clear: both;
        visibility: hidden;
    }
    // .iconfont {
    //   margin: 0px;
    // }
    .icon-btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      color: #fff;
      line-height: 24px;
      text-align: center;
      padding: 0px;
      cursor: pointer;
      border-radius: 3px;
      margin-right: 8px;
    }
  }
  ::v-deep .table-list{
    height:calc(100% - 42px);
    .el-table{
      height:calc(100% - 57px)!important;
    }
    .el-table__body-wrapper{
      height:calc(100% - 40px)!important;
      overflow-y: auto;
    }
  }
  .dialoginfo{
    padding-top: 20px
  }
  .commit-btn{
    height:32px;
    line-height: 32px;
    padding: 0px 10px;
    background:rgba(10,112,176,1);
    border-radius:3px;
    color: #fff;
    border:none;
    margin-left: 15px;
  }
  .consol-btn{
    height:32px;
    line-height: 32px;
    padding: 0px 10px;
    border-radius:3px;
    color: #606266;
    border: 1px solid #DCDFE6;
  }
  .import-info{
    height: 36px;
    line-height: 36px;
    color: #303133;
    background: #FFF6F7;
    font-weight: bold;
    border-radius: 4px;
    border-left: 5px solid #E6A23C;
    margin: 10px auto;
  }
  .clr_e63{
    color: #E6A23C;
  }
}
.importBtn {
  border: 1px solid rgba(220, 223, 230, 1) !important;
}
.operate-btn {
  display: inline-block;
  width: 104px;
  text-align: center;
  padding: 0;
  height: 32px;
  line-height: 30px;
  border-radius: 3px;
  border: none;
  cursor: pointer;
  border: 1px solid #dcdfe6;
}
@media screen and (max-width: 1480px) {
  .officeType{
    clear: both;
    margin-left:0px;
    margin-top:10px;
    margin-bottom: 10px;
  }
  .queryAndResetDiv{
    margin-top:10px;
  }
  .table-list{
    height: calc(100% - 84px)!important;
  }
}
</style>
