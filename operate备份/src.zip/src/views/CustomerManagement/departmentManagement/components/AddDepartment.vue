<template>
  <div class="dialoginfo">
    <el-form :model="depart_info" :rules="rules" ref="depart_info" label-width="140px" class="demo-ruleForm">
      <div>
        <el-form-item label="所属机构:" prop="institution_id">
          <el-select v-model="depart_info.institution_id" @change="changeInstitute" clearable filterable placeholder="请选择" class="w_400">
            <el-option
              v-for="item in institutionList"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="科室名称:" prop="name" class="mt20">
          <el-input class="w_400" v-model="depart_info.name"></el-input>
        </el-form-item>
        <el-form-item label="科室类型:" prop="type" class="mt20">
          <!-- <el-radio-group class="w_400" v-model="depart_info.type">
            <el-radio v-for="item in OfficesType" :key="item.dic_code" :label="item.dic_code">{{item.dic_name}}</el-radio>
          </el-radio-group> -->
          <el-select v-model="depart_info.type" @change="changeOfficeType" clearable filterable placeholder="请选择" class="w_400">
              <el-option value="">请选择</el-option>
              <el-option
                v-for="(item, index) in OfficesType"
                :key="index"
                :label="item.name"
                :value="item.value">
              </el-option>
            </el-select>
        </el-form-item>
        <el-form-item v-if="depart_info.type == 2 || depart_info.type == 6"  :label="depart_info.type == 2 ? '关联系统:' : '治疗分类:'" prop="system_type" class="mt20">
          <el-select v-model="depart_info.system_type" filterable placeholder="请选择" class="w_400">
              <el-option
                v-for="item in OfficeSystemTypeList"
                :key="item.dic_code"
                :label="item.dic_name"
                :value="item.dic_code">
              </el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="科室主任:" prop="officeHead" class="mt20">
          <el-input class="w_190 mr20" placeholder="手机号" @input="changePhone" @blur="getNameFn('admin', depart_info.admin_phone)" v-model="depart_info.admin_phone"></el-input>
          <el-input class="w_190" type="text" placeholder="姓名" @input="changeName($event)" v-model="depart_info.admin_name" :disabled="isAdminname"></el-input>
        </el-form-item>

        <el-form-item label="联系电话:" prop="contact_number" class="mt20">
          <el-input class="w_400" v-model="depart_info.contact_number"></el-input>
        </el-form-item>

        <el-form-item label="平台科室代码:" prop="code" class="mt20">
          <el-input class="w_400" v-model="depart_info.code"></el-input>
        </el-form-item>
        <el-form-item label="HIS科室名称:" prop="his_name" class="mt20">
          <el-input class="w_400" v-model="depart_info.his_name"></el-input>
        </el-form-item>
        <el-form-item label="HIS科室代码:" prop="his_code" class="mt20">
          <el-input class="w_400" v-model="depart_info.his_code"></el-input>
        </el-form-item>
      <!----填写拍影像的地方 (对应的区  几号楼 楼层)--->
        <el-form-item label="楼宇:" class="mt20">
          <div class="chooseBuildingCon">
              <div class="chooseBuilding mb10" v-for="(oneSubTable,index) in setOfficeAddressParamsArr" :key="index">

                <!----有院区的时候--->
                <el-select v-model="oneSubTable.institution_id" v-if="hospitalArr.length != 0"  filterable class="mr5" clearable style="width: 400px;margin-bottom:5px;" placeholder="请选择院区">
                  <el-option
                    v-for="(item,nth) in hospitalArr"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  ></el-option>
                </el-select><br/>

                <el-input class="w_118" :class="{'hasHospital': hospitalArr.length != 0}" placeholder="楼" v-model="oneSubTable.building" maxlength="32" show-word-limit></el-input>
                <el-input class="w_118 ml5" :class="{'hasHospital': hospitalArr.length != 0}" placeholder="层" v-model="oneSubTable.floor" maxlength="32" show-word-limit></el-input>
                <el-input class="w_118 ml5" :class="{'hasHospital': hospitalArr.length != 0}" placeholder="诊区" v-model="oneSubTable.diagnostic_area" maxlength="32" show-word-limit></el-input>
                <span class="delAddress dib ml5" v-if="index!=0" @click="deleteOneOfficeSet(index)"><i class="iconfont iconshanchu1"> </i></span>
                <el-tooltip placement="top" v-if="index==setOfficeAddressParamsArr.length-1">
                  <div slot="content">新增楼宇</div>
                  <span class="addAddress dib ml5" @click="addOneOfficeSet()">
                    <i class="iconfont iconxinzeng f16"></i>
                  </span>
                </el-tooltip>
            </div>
            </div>


        </el-form-item>
      </div>
      <div class="dialog_footer">
        <el-button size="small" plain @click="submitForm('cansol', 'depart_info')">取消</el-button>
        <el-button type="primary" size="small" @click="submitForm('', 'depart_info')">保存</el-button>
      </div>
    </el-form>
  </div>
</template>

<script>
export default {
  props: {
    isAdd: Boolean,
    isAdminname: Boolean,
    depart_info: Object,
    rules: Object,
    institutionList: Array,
    OfficesType: Array,
    OfficeSystemTypeList: Array
  },
  data () {
    return {
      curInstitutionId: '',
      hospitalArr: [],
      setOfficeAddressParamsArr: [
        {
          institution_id: '',// 机构id (都放在positions字段里)
          building: '',// 楼宇
          floor: '',// 楼层
          diagnostic_area: '',// 诊区
        },
      ],
    }
  },
  methods: {
    resetOfficeAddressParams () {
      this.setOfficeAddressParamsArr =[
        {
          institution_id: '',// 机构id (都放在positions字段里)
          building: '',// 楼宇
          floor: '',// 楼层
          diagnostic_area: '',// 诊区
        },
      ]
    },
    submitForm (type, formName) {
      var info = {
        type: type,
        formName: formName,
        refs: this.$refs
      }
      this.$emit('submitForm', info, this.setOfficeAddressParamsArr)
    },
    // 改变科室类型
    changeOfficeType (val) {
      this.$emit('changeOfficeType', val)
    },
    changePhone () {
      this.$emit('changePhone')
    },
    getNameFn (type, phone) {
      this.$emit('getNameFn', type, phone)
    },
    changeName (e) {
      this.$forceUpdate()
    },
    // 改变机构 看看是否有院区
    async changeInstitute (institute_id) {
      this.setOfficeAddressParamsArr = [
        {
          institution_id: '',// 机构id (都放在positions字段里)
          building: '',// 楼宇
          floor: '',// 楼层
          diagnostic_area: '',// 诊区
        },
      ]
      if (institute_id) {
        const result = this.institutionList.filter(item => item.id == institute_id)
        this.hospitalArr = result[0].hospitals || []
        if (this.hospitalArr && this.hospitalArr.length != 0) {// 有院区
          this.curInstitutionId = ''
        } else {// 无院区
          this.curInstitutionId = institute_id
        }
      } else {
        this.curInstitutionId = ''
        this.hospitalArr = []
      }
    },
    // 动态添加一个科室 配置
    addOneOfficeSet() {
      let obj = {
        institution_id: this.curInstitutionId ? this.curInstitutionId :'',// 机构id (都放在positions字段里)
        building: '',// 楼宇
        floor: '',// 楼层
        diagnostic_area: '',// 诊区
      };
      this.setOfficeAddressParamsArr.push(obj);
    },
    // 动态删除一个科室 配置
    deleteOneOfficeSet(index) {
      const self = this;
      self.setOfficeAddressParamsArr.forEach((item, i) => {
        if (index == i) {
          self.setOfficeAddressParamsArr.splice(i, 1);
        }
      });
    },
  }
}
</script>

<style lang="scss" scoped>
.w_400{
  width: 400px;
}
.w_190{
  width:190px;
}
.w_118{ width: 118px;}
.hasHospital {width: 118px;}
.chooseBuildingCon{
  .chooseBuilding{
    display: flex;
    flex-wrap: wrap;
  }
  .delAddress {
  width: 32px;
  height: 32px;
  line-height: 32px;
  text-align: center;
  border: 1px solid #dcdfe6;
  border-radius: 2px;
  cursor: pointer;
  i {
    color: #da4a4a;
    font-size: 16px;
  }
}

.delAddress:hover {
  border-color: #da4a4a;
  background: #da4a4a;
  i {
    color: #fff;
  }
}
.addAddress {
  width: 32px;
  height: 32px;
  line-height: 32px;
  text-align: center;
  border: 1px solid #dcdfe6;
  border-radius: 2px;
  color: #0a70b0;
  cursor: pointer;

  &:hover {
    border-color: #0a70b0;
    background: #0a70b0;
    color: #fff;
  }
 }
}

</style>
