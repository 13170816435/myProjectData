<template>
  <div class="dialoginfo"
   v-loading="!isImportFinished"
    :element-loading-text="importTip">
    <div class="flex_row lh35">
      <span >上传文件 :</span>
      <el-input v-model="name" class="width_260_input ml5" placeholder="请上传Excel文件"></el-input>
      <el-upload
        class="upload-demo ml15"
        action="#"
        :show-file-list="false"
        :on-change="chooseUploadMyFrx"
        :auto-upload="false"
        >
        <el-button size="small" type="primary">选择文件</el-button>
      </el-upload>
      <!-- <span class="function-btn bg_e6 clr_ff ml10" style="margin-top: 2px" v-bind:class="{'importFinish': !isImportFinished}" @click="importUserFn('import')">开始导入</span> -->
      <span class="function-btn bg_0a clr_ff ml10" style="margin-top: 2px" @click="inspectOfficeFn()">检测</span>
      <span class="function-btn bg_e6 clr_ff ml10" :class="{'notAllowImport': !isInspectFinished }" style="margin-top: 2px"  @click="importOfficeFn()">开始导入</span>
      <span class="importTip">文件修改后需要重新选择文件进行上传</span>
      <!-- <div class="flex_1 tr" style="margin-top: 2px"><a class="function-btn clr_0a ml10 border" :href="subdir+downHerf" download="导入科室模板.xlsx"><i class="iconfont icon-xiazai"></i>下载模板</a></div> -->
      <div class="flex_1 tr" style="margin-top: 2px"><a class="function-btn clr_0a ml10 border" :href="downHerf" download="导入科室模板.xlsx"><i class="iconfont icon-xiazai"></i>下载模板</a></div>
    </div>
    <div  class="mt15 importResultTable" v-bind:class="{'noTableData':importList.length==0}">
      <el-table :data="importList" border :height="tableHeight">
        <el-table-column property="index" label="序号" width="60" fixed="left"></el-table-column>
        <el-table-column label="检测结果" width="200" v-if="operateType == 'inspect'">
          <template slot-scope="scope">
            <span :class="scope.row.success === true ? 'clr_00' : 'clr_da'">{{scope.row.result}}</span>
          </template>
        </el-table-column>
        <el-table-column label="导入结果" width="200" v-else>
          <template slot-scope="scope">
            <span :class="scope.row.success === true ? 'clr_00' : 'clr_da'">{{scope.row.result}}</span>
          </template>
        </el-table-column>
        <el-table-column property="institution_name" label="所属机构" width="200" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column property="name" label="科室名称" width="100" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column property="type_name" label="科室类型" width="80" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column property="admin_name" label="科主任姓名" width="120" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column property="admin_phone" label="科主任手机号" width="120" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column property="system_type_desc" label="关联系统/治疗分类" width="140" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column property="code" label="平台科室代码" width="120" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column property="his_name" label="HIS科室名称" width="110" :show-overflow-tooltip="true"></el-table-column>
        <el-table-column property="his_code" label="HIS科室代码" :show-overflow-tooltip="true"></el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import CommonTable from './CommonTable'
export default {
  components: {
    CommonTable
  },
  props: {
    name: String,
    importList: Array,
    isImportFinished: Boolean,
    importTip: String,
    isInspectFinished: Boolean,
    operateType: String,
  },
  data () {
    return {
      tableHeight: '100%',
      downHerf: process.env.NODE_ENV === 'development' ? '/excel/office.xlsx' : '/operate/excel/office.xlsx',
      subdir: window.Config.subdir,
    }
  },
  methods: {
    chooseUploadMyFrx (file, fileList) {
      this.$emit('chooseUploadFile', file, fileList)
    },
    // 检测科室
    inspectOfficeFn () {
      if (this.isImportFinished) {
        this.$emit('inspectOfficeFn')
      }
    },
    // 导入科室
    importOfficeFn () {
      if (!this.isInspectFinished) {// 没检测完时不允许导入文件 (先检测完再执行导入更安全些)
        return false
      }
      if (this.isImportFinished) {
        this.$emit('importOfficeFn')
      }
    }
  }
}
</script>

<style lang="less" scoped>
.dialoginfo{
  padding: 15px 20px;
}
.importFinish {
  background:#ededed;
  cursor:not-allowed;
}
.importResultTable{
  height:500px;
  ::v-deep .el-table__body-wrapper{
    overflow: auto!important;
  }
}
.importTip{
  font-size:13px;
  color:#ff9900;
  padding-left:10px;
}
.notAllowImport{
  background:#ededed;
  cursor: not-allowed;
}
</style>
