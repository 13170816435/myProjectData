<template>
<!-- 表格： 可通过后台返回控制table显示某列 及自定义宽度 -->
  <div>
    <template v-for="(item, index) in propData">
      <el-table-column
        v-if="item.prop == 'result'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <!-- 急诊标红处理 -->
        <template  slot-scope="scope">
          <span :class="scope.row.success === true ? 'clr_00' : 'clr_da'">{{scope.row.result}}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-else-if="item.prop == 'his_code'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        min-width="160"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
      </el-table-column>
      <el-table-column
        v-else
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
      </el-table-column>
    </template>
  </div>
</template>
<script>
import mixin from '@/utils/mixin/intelligentDiagnosis'

export default {
  name: 'CommonTable',
  props: {
    propData: Array
  },
  mixins: [mixin],
}
</script>
<style lang="less">
</style>
