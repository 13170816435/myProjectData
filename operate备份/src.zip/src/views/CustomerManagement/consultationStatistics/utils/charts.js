import {createChart} from '@/views/ServiceCenterManagement/dataStatic/serviceCenterReport/utils/charts'
import {serializeDateByType} from '@/views/CustomerManagement/consultationStatistics/utils/index'
import * as echarts from 'echarts'

const createChartToolTip = () => {
  let toolTip = document.querySelector('#chartToolTip')
  if (!toolTip) {
    toolTip = document.createElement('div')
    toolTip.style.display = 'none'
    toolTip.id = 'chartToolTip'
    toolTip.classList.add('chartToolTip')
    document.body.appendChild(toolTip)
  }
  return toolTip
}

const addStyle = (dom, style) => {
  for (let [property, value] of Object.entries(style)) {
    dom.style[property] = value
  }
  return dom
}

const addToolTip = (chart, dom) => {
  const toolTip = createChartToolTip()

  chart.on('mouseover', params => {
    if (params.componentType !== "yAxis") {
      toolTip.style.display = 'none'
      return false
    }

    addStyle(toolTip, {
      position: 'fixed',
      color: '#fff',
      borderRadius: '5px',
      fontSize: '14px',
      padding: '5px 10px',
      display: 'block',
      backgroundColor: 'rgba(0, 0, 0, 0.5)'
    })

    toolTip.textContent = params.value
    dom.onmousemove = event => {
      const left = `${event.clientX + 10}px`
      const top = `${event.clientY + 10}px`
      addStyle(toolTip, {
        left,
        top
      })
    }
  })

  chart.on('mouseout', () => {
    addStyle(toolTip, {
      display: 'none'
    })
  })
}

const colorList = [
  {
    label: '放射',
    value: '#3399FF'
  },
  {
    label: '超声',
    value: '#00BF71'
  },
  {
    label: '内镜',
    value: '#DB6BCF'
  },
  {
    label: '心电',
    value: '#F383A2'
  },
  {
    label: '病理',
    value: '#FF9F63'
  },
  {
    label: '专科',
    value: '#F9BA00'
  },
  {
    label: '多学科',
    value: '#2498D1'
  }
]

export const drawChartList = (domList, dataSource, dateList, filterType) => {
  const __dateList = serializeDateByType(dateList, filterType)


  return dataSource.map((item, index) => {

    const _dataSource = item.typeList.reduce((obj, typeItem) => {
      obj.legend.push(`${typeItem.consult_kind_name}会诊`)

      for (let dataItem of typeItem.data) {
        if (!obj.xAxis.includes(dataItem.statistics_date)) {
          obj.xAxis.push(dataItem.statistics_date)
        }
      }

      return obj
    }, {
      legend: [],
      xAxis: []
    })

    const xAxis = __dateList

    // 取出所有的数据
    const _list = item.typeList.flatMap(item2 => item2.data)

    // 分组
    const __list = _list.reduce((typeList, currentItem) => {
      const index = typeList.findIndex(item3 => item3.consult_kind_code === currentItem.consult_kind_code)
      if (index !== -1) {
        typeList[index].data.push({
          ...currentItem
        })
      } else {
        typeList.push({
          consult_kind_code: currentItem.consult_kind_code,
          consult_kind_name: currentItem.consult_kind_name,
          data: [{
            ...currentItem
          }]
        })
      }
      return typeList
    }, [])

    const series = __list.map((item2, index) => {
      const ____list = __dateList.map(item3 => {
        const item4 = item2.data.find(item5 => item5.statistics_date === item3)
        if (item4) {
          return {
            ...item4,
            name: item2.consult_kind_name,
            value: item4.quantity
          }
        }
        return {
          name: item2.consult_kind_name,
          value: 0
        }
      })

      const colorItem = colorList.find(colorItem => colorItem.label === item2.consult_kind_name)
      const color = colorItem ? colorItem.value : '#3399FF'
      return {
        name: `${item2.consult_kind_name}会诊`,
        type: 'line',
        areaStyle: {
          opacity: 0.18,
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
            offset: 0,
            color,
          }, {
            offset: 1,
            color
          }]),
        },
        smooth: true,
        symbol: 'none',
        emphasis: {
          focus: 'series'
        },
        itemStyle: {
          color
        },
        data: ____list
      }
    })

    const chartInstance = createChart()
    const options = {
      title: {
        text: '会诊申请量趋势',
        textStyle: {
          fontSize: '14px',
          fontWeight: 'normal',
          color: '#303133'
        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          label: {
            backgroundColor: '#6a7985'
          }
        }
      },
      legend: {
        data: _dataSource.legend,
        x: 'right',
        y: 'top',
        padding: [8, 0, 0, 0]
      },
      grid: {
        left: '20px',
        right: '40px',
        bottom: '15px',
        top: '40px',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          boundaryGap: false,
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              type: 'dashed',
              color: '#dcdfe6'
            }
          },
          axisLabel: {
            color: '#303133'
          },
          data: xAxis
        }
      ],
      yAxis: [
        {
          type: 'value',
          splitLine: {
            lineStyle: {
              type: 'dashed',
              color: '#dcdfe6'
            }
          },
          axisLabel: {
            color: '#303133'
          }
        }
      ],
      series
    }
    return chartInstance(domList[index], options)
  })
}

export const disposeCharts = chartsList => {
  for (let chartItem of chartsList) {
    if (chartItem) {
      chartItem.dispose()
    }
  }
}


export const resizeCharts = chartsList => {
  for (let chartItem of chartsList) {
    if (chartItem) {
      chartItem.resize()
    }
  }
}


export const drawHosChart = (dom, dataSource) => {
  const labelList = dataSource.map(item => item.request_office_name)

  const colorList = ['#f56c6c', '#f59b58', '#ffb917', '#3ba1ff']

  const max = dataSource.reduce((max, item) => {
    if (item.value > max) {
      max = item.value
    }
    return max
  }, Number.MIN_VALUE)

  const maxList = new Array(dataSource.length).fill(max)

  const options = {
    tooltip: {
      show: false
    },
    legend: {
      show: false
    },
    grid: {
      left: '150',
      right: '20px',
      bottom: '20px',
      top: '40px'
    },
    xAxis: {
      type: 'value',
      position: 'top',
      lineStyle: {
        color: '#dcdfe6',
        type: 'dashed'
      }
    },
    yAxis: [{
      type: 'category',
      data: labelList,
      inverse: true,
      postion: "left",
      axisLine: {
        show: false
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        margin: 120,
        color: '#303133',
        fontSize: '14',
        rich: {
          nt1: {
            color: "#fff",
            backgroundColor: '#F56C6C',
            width: 20,
            height: 20,
            fontSize: 12,
            align: "center",
            borderRadius: 100,
            lineHeight: "15",
            padding: 0,
            fontFamily: 'Arial'
          },
          nt2: {
            color: "#fff",
            backgroundColor: '#F59B58',
            width: 20,
            height: 20,
            fontSize: 12,
            align: "center",
            borderRadius: 100,
            lineHeight: "15",
            padding: 0,
            fontFamily: 'Arial'
          },
          nt3: {
            color: "#fff",
            backgroundColor: '#FFB917',
            width: 20,
            height: 20,
            fontSize: 12,
            align: "center",
            borderRadius: 100,
            lineHeight: "15",
            padding: 0,
            fontFamily: 'Arial'
          },
          nt: {
            color: "#fff",
            backgroundColor: '#3ba1ff',
            width: 20,
            height: 20,
            fontSize: 12,
            align: "center",
            borderRadius: 100,
            lineHeight: "15",
            padding: 0,
            fontFamily: 'Arial'
          }
        },
        formatter: function (value, index) {
          index += 1
          if (index - 1 < 3) {
            return ["{nt" + index + "|" + index + "}"].join("\n")
          } else {
            return ["{nt|" + index + "}"].join("\n")
          }
        }
      },
    },
      {                                   //名称
        type: 'category',
        inverse: true,
        position: "left",
        triggerEvent: true,
        axisLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          interval: 0,
          lineHeight: 32,
          width: 110,
          fontSize: 14,
          color: "#303133",
          overflow: 'truncate'
        },
        data: labelList
      },
    ],
    series: [
      {
        type: 'bar',
        name: dataSource.length > 0 ? dataSource[0].name : '',
        label: {
          show: true,
          position: 'right'
        },

        barWidth: 16,

        itemStyle: {
          color: '#00BF71'
        },

        emphasis: {
          focus: 'series'
        },
        data: dataSource.map((item, index) => {
          return {
            ...item,
            itemStyle: {
              color: index < 3 ? colorList[index] : colorList[3],
              borderRadius: [0, 8, 8, 0]
            }
          }
        })
      },
      {
        type: "bar",
        barWidth: 16,
        barGap: "-100%",
        margin: "20",
        data: maxList,
        textStyle: {
          fontSize: 12,
          color: "#fff"
        },
        itemStyle: {
          color: "rgba(0, 147, 255, 0.1)",
          width: "100%",
          fontSize: 12,
          borderRadius: [0, 30, 30, 0],
        }
      }
    ]
  }

  const chartInstance = createChart()

  const chart = chartInstance(dom, options)

  addToolTip(chart, dom)

  return [chart]
}


export const drawTotalChartList = (dom, dataSource) => {
  const labelList = dataSource.map(item => item.name)

  const max = dataSource.reduce((max, item) => {
    if (item.value > max) {
      max = item.value
    }
    return max
  }, Number.MIN_VALUE)

  const maxList = new Array(dataSource.length).fill(max)

  const options = {
    tooltip: {
      show: false
    },
    legend: {
      show: false
    },
    grid: {
      left: '0',
      right: '40px',
      bottom: '20px',
      top: '20px',
      containLabel: true
    },
    xAxis: {
      type: 'value',
      position: 'top',
      lineStyle: {
        color: '#dcdfe6',
        type: 'dashed'
      }
    },
    yAxis: {
      type: 'category',
      inverse: true,
      position: "left",
      triggerEvent: true,
      axisLine: {
        show: false
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        interval: 0,
        lineHeight: 32,
        width: 140,
        fontSize: 14,
        color: "#303133",
        overflow: 'truncate'
      },
      data: labelList
    },
    series: [
      {
        type: 'bar',
        name: '服务中心',
        label: {
          show: true,
          position: 'right'
        },

        barWidth: 16,

        itemStyle: {
          color: '#3BA1FF'
        },

        emphasis: {
          focus: 'series'
        },
        data: dataSource.map(item => {
          return {
            ...item,
            itemStyle: {
              borderRadius: [0, 8, 8, 0]
            }
          }
        })
      },
      {
        type: "bar",
        barWidth: 16,
        barGap: "-100%",
        margin: "20",
        data: maxList,
        textStyle: {
          fontSize: 12,
          color: "#fff"
        },
        itemStyle: {
          color: "rgba(0, 147, 255, 0.1)",
          width: "100%",
          fontSize: 12,
          borderRadius: [0, 30, 30, 0],
        }
      }
    ]
  }

  const chartInstance = createChart()

  const chart = chartInstance(dom, options)

  addToolTip(chart, dom)

  return [chart]
}


export const drawWorkChartList = (domList, dataSource, dateList, filterType) => {
  const __dateList = serializeDateByType(dateList, filterType)

  return dataSource.map((item, index) => {
    const chartInstance = createChart()

    const series = item.dataList.map((item2, index) => {
      const ____list = __dateList.map(item3 => {
        const item4 = item2.data.find(item4 => item4.statistics_date === item3)
        if (item4) {
          return {
            ...item4,
            name: item2.consult_kind_name,
            value: item4.quantity
          }
        }
        return {
          name: item2.consult_kind_name,
          value: 0
        }
      })

      const colorItem = colorList.find(colorItem => colorItem.label === item2.consult_kind_name)
      const color = colorItem ? colorItem.value : '#3399FF'

      return {
        name: `${item2.consult_kind_name}会诊`,
        type: 'line',
        areaStyle: {
          opacity: 0.18,
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
            offset: 0,
            color,
          }, {
            offset: 1,
            color
          }])
        },
        smooth: true,
        symbol: 'none',
        emphasis: {
          focus: 'series'
        },
        itemStyle: {
          color
        },
        data: ____list
      }
    })

    const options = {
      title: {
        text: '会诊工作量趋势',
        textStyle: {
          fontSize: '14px',
          fontWeight: 'normal',
          color: '#303133'
        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          label: {
            backgroundColor: '#6a7985'
          }
        }
      },
      legend: {
        data: item.dataList.map(item2 => `${item2.consult_kind_name}会诊`),
        x: 'right',
        y: 'top',
        padding: [8, 0, 0, 0]
      },
      grid: {
        left: '20px',
        right: '40px',
        bottom: '15px',
        top: '40px',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          boundaryGap: false,
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              type: 'dashed',
              color: '#dcdfe6'
            }
          },
          axisLabel: {
            color: '#303133'
          },
          data: __dateList
        }
      ],
      yAxis: [
        {
          type: 'value',
          splitLine: {
            lineStyle: {
              type: 'dashed',
              color: '#dcdfe6'
            }
          },
          axisLabel: {
            color: '#303133'
          }
        }
      ],
      series
    }

    return chartInstance(domList[index], options)
  })
}
