<template>
  <div class="back-line">
    <div v-for="item of locList" :key="item.value">
      <span class="back-line-item" @click="onClickLine(item.value)">{{ item.name }}</span>
      <i class="el-icon-arrow-right arrow"></i>
    </div>
    <span class="current-loc">{{ currentLoc }}</span>
  </div>
</template>

<script>

export default {
  name: "back-line",

  props: {
    list: {
      type: Array,
      default: []
    }
  },

  data() {
    const {currentName: currentLoc} = this.list.length > 0 ? this.list[this.list.length - 1] : {
      currentName: ''
    }

    return {
      locList: [...this.list],
      currentLoc
    }
  },

  watch: {
    list(val) {
      this.locList = [...val]
      const {currentName: currentLoc} = this.list.length > 0 ? this.list[this.list.length - 1] : {
        currentName: ''
      }
      this.currentLoc = currentLoc
    }
  },

  methods: {
    onClickLine(val) {
      this.$emit('on-click', val)
    }
  }
}

</script>
