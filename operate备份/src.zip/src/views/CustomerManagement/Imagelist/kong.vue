<template>
  <div>
  </div>
</template>

<script>
export default {
  beforeRouteEnter(to, from, next) {
    // console.log('$$$$$$$$$$$$$$$$$$$$$$$$$$')
    // console.log(to)
    // console.log('$$$$$$$$$$$$$$$$$$$$$$$$$$')
    next(vm => {
      vm.$router.replace(to.query.path)
    })
  }
}
</script>
