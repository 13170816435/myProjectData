<template>
  <div>
    <iframe :src="iframeUrl" class="iframebox" style="border: 0"></iframe>
  </div>
</template>
<script>
export default {
  computed: {
    iframeUrl () {
      let Params = ''
      if (sessionStorage.getItem('CheckMemuname') === '客户管理') {
        Params = '?group=tenancy'
      } else {
        Params = '?group=dept&systemid=' + sessionStorage.getItem('lastname')
      }
      return configUrl.frontEndUrl + '/paservice/IMGLIST' + Params
    }
  },
  mounted () {
    // window.onunload = function () {
    //   const key = `oidc.user:${configUrl.crmUrl}:${clientUrl.client_id}`
    //   if (window.frames.length !== parent.frames.length) {
    //     console.log('在iframe中, 需要删除session, key: ' + key)
    //     window.sessionStorage.removeItem(key)
    //   }
    // };

  }
}
</script>
<style>
.iframebox{
  width: 100%;
  height: calc(100vh - 55px);
}
</style>
