<template>
  <div>
    <div class="pl20 pt20">
      <el-row class="lh35">
        <el-col :span="12">
          <span><i class="iconfont iconbitian clr_da"></i>用户姓名 ：</span>
          <el-input v-model="newInfo.name" class="width_200_input" placeholder="请输入真实姓名"></el-input>
        </el-col>
        <el-col :span="12">
          <span><i class="iconfont iconbitian clr_da"></i>用户性别 ：</span>
          <el-radio-group v-model="newInfo.sex">
            <el-radio :label=1>男</el-radio>
            <el-radio :label=2>女</el-radio>
          </el-radio-group>
        </el-col>
      </el-row>
      <el-row class="lh35 mt10">
        <el-col :span="12">
          <span><i class="iconfont iconbitian clr_da"></i>所属机构 ：</span>
          <el-input v-model="newInfo.related_institution" class="width_200_input" placeholder="请输入所属机构"></el-input>
        </el-col>
        <el-col :span="12">
          <span class="ml15">用户工号 ：</span>
          <el-input v-model="newInfo.work_no" class="width_200_input" placeholder="请输入用户工号"></el-input>
        </el-col>
      </el-row>
      <el-row class="lh35 mt10">
        <el-col :span="12">
          <span><i class="iconfont iconbitian clr_da"></i>手机号码 ：</span>
          <el-input v-model="newInfo.phone" @input="changePhone" class="width_200_input" placeholder="请输入手机号码"></el-input>
        </el-col>
        <el-col :span="12">
          <span class="ml15">出生日期 ：</span>
          <el-date-picker v-model="newInfo.birthday" type="date" class="width_200_input"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"></el-date-picker>
        </el-col>
      </el-row>
      <div class="flex_row lh35 mt10">
        <span class="w_80 tr"><i class="iconfont iconbitian clr_da"></i>使用时间 ：</span>
        <el-date-picker
          class="width_150_input"
          v-model="newInfo.use_start_time"
          format="yyyy-MM-dd"
          value-format="yyyy-MM-dd"
          type="date"
          placeholder="开始时间">
        </el-date-picker>
        <el-radio-group class="ml10 flex_1" v-model="endtime" @change="noEndTimeFn">
          <el-radio :label=1>
            <el-date-picker
              :disabled="endtime===1?false:true"
              v-model="newInfo.use_end_time"
              format="yyyy-MM-dd"
              value-format="yyyy-MM-dd"
              type="date"
              class="width_150_input"
              placeholder="结束时间">
            </el-date-picker>
          </el-radio>
          <el-radio class="lh40 ml10" :label=2>无限期</el-radio>
        </el-radio-group>
      </div>
      <div class="lh30 mt10 flex_row">
        <span class="ml15">通讯地址 ：</span>
        <el-cascader
          ref="cascaderAddr"
          :style="{width: '240px'}"
          v-model="city.cityValue"
          :options="city.cityJson"
          @change="getCityCodeFn"
          @active-item-change="childrenCity">
        </el-cascader>
        <el-input class="width_180_input ml10" placeholder="请输入常用地址" v-model="newInfo.address"></el-input>
      </div>
    </div>
    <div class="dialog_footer mt10">
      <el-button size="small" plain @click="submitForm('cancel', 'formData')">取消</el-button>
      <el-button size="small" type="primary" @click="submitForm('submit', 'formData')">保存</el-button>
    </div>
  </div>
</template>

<script>
import headerimg from '@/assets/images/common/doctor_boy.png'
export default {
  props: {
    newInfo: Object,
    endtime: Number,
    city: Object,
    isGetUserDetail: Boolean
  },
  data () {
    return {
      headerimg: headerimg
    }
  },
  watch: {
    isGetUserDetail (val) {
    }
  },
  methods: {
    changePhone () {
      this.$emit('changePhone')
    },
    submitForm (type) {
      this.$emit('submitForm', type)
    },
    noEndTimeFn (val) {
      this.$emit('noEndTimeFn', val)
    },
    getCityCodeFn (val) {
      this.$emit('getCityCodeFn', val)
    },
    childrenCity (val) {
      this.$emit('childrenCity', val)
    }
  },
  mounted () {
    
  }
}
</script>

<style lang="less" scoped>
  .w_85{
    // width: 90px;
  }
  .p20{
    padding: 20px;
  }
  .border_dashed{
    border: 1px dashed #dddddd;
  }
  .border_bd{
    border-bottom: 1px dashed #dddddd;
  }
  .headerimg{
    width: 120px;
    height: 120px;
    border-radius: 50%;
  }
</style>
