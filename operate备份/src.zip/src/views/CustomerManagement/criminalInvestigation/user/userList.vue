<template>
  <div class="userList">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>司法鉴定 <i class="iconfont iconzhankaishouqi"></i> 用户管理
        </span>
      </div>
      <div class="flex_1 pl20">
        <el-row class="tr">
          <span class="function-btn clr_ff bg_e6" @click="operateFn('add')"><i class="iconfont iconxinzeng mr5"></i>新增用户</span>
        </el-row>
      </div>
    </div>
    <div class="container userListContainer">
      <div class="search-bar flex_row">
        <div class="flex_1">
          <div class="flex_row">
            <div class="flex_row">
              <span class="search-bar-label ">用户状态 :</span>
              <el-select class="width_180_input" filterable v-model="searchData.state" placeholder="请选择">
                <!-- <el-option label="全部" value=""></el-option> -->
                <el-option
                  v-for="item in baseInfo.user_account_state"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value"
                ></el-option>
              </el-select>
            </div>
            <div class="flex_row">
              <span class="search-bar-label">用户姓名 :</span>
              <el-input class="width_180_input" v-model="searchData.name" placeholder="请输入用户姓名"></el-input>
            </div>
            <div class="flex_row ml30">
              <span class="search-bar-label ml5">用户手机号 :</span>
              <el-input class="width_180_input" v-model="searchData.phone" placeholder="请输入用户手机号"></el-input>
            </div>
            <div class="flex_row ml10 width_180_input tr">
              <el-button type="primary" size="small" @click="searchUserlist">查询</el-button>
              <el-button size="small" plain @click="resetSearchDataFn">重置</el-button>
            </div>
          </div>
        </div>
      </div>
      <div class="table-list mt10">
        <el-table
          width="100%"
          size="medium "
          :data="tableData"
          v-loading="loading"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          border
          stripe
          v-bind:class="{'noTableData':tableData.length==0}"
          :height="tableheight"
          highlight-current-row
          header-row-class-name="strong"
        >
          <el-table-column type="index" label="序号" width="55" fixed="left">
            <template slot-scope="scope">
              <span>{{(pageInfo.page_index - 1) * pageInfo.page_size + scope.$index + 1}}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="130" fixed="left">
            <template slot-scope="scope">
              <span class="clr_0a pointer" @click="operateFn('info', scope.row)">编辑</span>
              <span class="clr_ef89 ml5 pointer" @click="operateFn('reset', scope.row)">重置</span>
              <span class="clr_0a ml5 pointer" v-if="scope.row.is_locked"  @click="operateFn('relock', scope.row)">解锁</span>
            </template>
          </el-table-column>
          <el-table-column type="index" label="用户状态" width="80" fixed="left">
            <template slot-scope="scope">
              <el-switch @change="userStateChangeFn($event, scope.row.id)" class="switchStyle" active-color="#409EFF" inactive-color="#F56C6C" active-text="启用" inactive-text="禁用" :active-value="1" :inactive-value="0" v-model="scope.row.state"></el-switch>
            </template>
          </el-table-column>
          <el-table-column type="index" label="账号状态" width="80" fixed="left">
            <template slot-scope="scope">
              <span :class="scope.row.is_locked ? 'clr_da' : 'clr_00'">{{scope.row.is_locked ? '锁定' : '正常'}}</span>
            </template>
          </el-table-column>
          <common-table :propData="propData"></common-table>
        </el-table>
        <div class="ba">
          <pagination-tool :layout="pageLayout" :total="pageInfo.total_count" :page.sync="pageInfo.page_index" :limit.sync="pageInfo.page_size" @pagination="pageSizeChangeFn" />
        </div>
      </div>
    </div>
    <el-dialog :title="userInfoTite" :visible.sync="isUserInfo" width="700px" :close-on-click-modal="false"  v-dialogDrag>
      <user-info :userId="userId" :newInfo="userInfo" :isGetUserDetail="isGetUserDetail" :endtime="endtime" @noEndTimeFn="noEndTimeFn" :city="city"
                @changePhone="changePhone"  @getCityCodeFn="getCityCodeFn" @childrenCity="childrenCity" @submitForm="submitForm"></user-info>
    </el-dialog>
  </div>
</template>

<script>
import Vue from 'vue'
// import JSEncrypt from 'jsencrypt'
import JSEncrypt from '@/utils/jsencrypt.min'
import CommonTable from '@/components/common/CommonTable'
import PaginationTool from '@/components/common/PaginationTool'
import { mapGetters } from 'vuex'
import { getTancyUserList, getCustomerUserDetail, changeUserState, reSetPwd, unLock, addCriminalUser, putCriminalUser } from '@/api/user'
import { getCityJson, getConfigurations } from '@/api/commonHttp'
import { CityLinkedJson } from '@/components/commonJs'
import UserInfo from './userInfo.vue'

export default {
  components: {
    CommonTable,
    PaginationTool,
    UserInfo
  },
  data () {
    return {
      tableheight: '100%',
      loading: true,
      userType: [], // 用户类型
      customerList: [], // 客户列表
      institutionList: [], // 机构列表
      searchData: {
        state: '',
        name: '',
        phone: ''
      },
      userId: 0,
      pageLayout: 'total, prev, pager, next, jumper',
      pageInfo: {
        eof: 1,
        page_index: 1,
        page_size: 15,
        total_count: 0,
        total_pages: 1
      },
      propData: [
        { prop: 'name', label: '用户姓名', width: 120 },
        { prop: 'sex', label: '性别', width: 80 },
        { prop: 'phone', label: '手机号码', width: 150 },
        { prop: 'work_no', label: '工号', width: 80 },
        { prop: 'use_time', label: '使用时间', width: 200 },
        { prop: 'address', label: '通信地址', width: 180 },
        { prop: 'related_institution', label: '所属机构', width: 180 },
        { prop: 'create_time', label: '创建时间' }
      ],
      tableData: [],
      // 用户信息
      userInfoTite: '新增用户',
      isUpdate: false,
      isFirstChange: true,
      isGetUserDetail: false,
      isUserInfo: false,
      initTime: [],
      endtime: 1,
      city: {
        cityValue: [],
        cityJson: [],
        city_parmas: {
          parent_code: '1',
          level: 1
        }
      },
      userInfo: {
        name: '',
        sex: 1,
        related_institution: '',
        work_no: '',
        phone: '',
        birthday: '',
        use_start_time: '',
        use_end_time: '',
        province_code: '',
        province: '',
        city_code: '',
        city: '',
        district_code: '',
        district: '',
        address: ''
      }
    }
  },
  computed: {
    ...mapGetters({ // 获取store查询枚举条件
      baseInfo: 'enumerations'
    })
  },
  watch: {
    baseInfo (val) {
      console.log(val.user_category)
      val.user_category.forEach((item, i) => {
        if (item.value === 1 || item.value === 4) {
          val.user_category.splice(i, 1)
        }
      })
    }
  },
  beforeMount () {
    this.$nextTick(() => {
      this.tableheight = document.documentElement.clientHeight - 260
    })
  },
  mounted () {
    // 加密函数
    this.getConfigurationsFn()
    this.getCityJsonFn(this.city.city_parmas)
    this.getUserListFn()
  },
  methods: {
    async getConfigurationsFn () {
      const res = await getConfigurations('TransmissionSecurity.RSA.PublicKey')
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) { // 注册方法
          const pubKey = res.data// ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt()
          encryptStr.setPublicKey(pubKey) // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()) // 进行加密
          return data
        }
      }
    },
    changePhone () {
      if (this.isUpdate) {
        // 是否是第一次改变
        if (this.isFirstChange) {
          this.userInfo.phone = ''
        }
        this.isFirstChange = false
      }
    },
    // 获取userlist
    async getUserListFn () {
      const _parmas = this.searchData
      const _url = '?category=256&state=' + _parmas.state + '&contains_name=' + _parmas.name + '&contains_phone=' + _parmas.phone + '&offset=' + this.pageInfo.page_index + '&limit=' + this.pageInfo.page_size
      const res = await getTancyUserList(_url)
      if (res.code === 0) {
        this.loading = false
        this.tableData = res.data
        this.pageInfo = res.page
      } else {
        this.loading = false
        this.$message({ type: 'error', message: res.msg })
      }
    },
    InterceptTime (timer) {
      return timer.slice(0, 10)
    },
    // 获取用户详情
    async getUserinfoByidFn (id) {
      const res = await getCustomerUserDetail(id)
      if (res.code === 0) {
        this.isUserInfo = true
        res.data.use_start_time = this.InterceptTime(res.data.use_start_time)
        if (res.data.use_end_time) {
          res.data.use_end_time = this.InterceptTime(res.data.use_end_time)
        }
        if (res.data.birthday) {
          res.data.birthday = this.InterceptTime(res.data.birthday)
        }
        this.isGetUserDetail = true
        //this.userInfo = res.data // 赋值
        this.userInfo = {
          id: res.data.id,
          name: res.data.name,
          sex: res.data.sex,
          related_institution: res.data.related_institution,
          work_no: res.data.work_no,
          phone: res.data.phone,
          birthday: res.data.birthday,
          use_start_time: res.data.use_start_time,
          use_end_time: res.data.use_end_time,
          province_code: res.data.province_code,
          province: res.data.province,
          city_code: res.data.city_code,
          city: res.data.city,
          district_code: res.data.district_code,
          district: res.data.district,
          address: res.data.address,
        }

        // 如果有结束时间 就说明不是无限期
        if (this.userInfo.use_end_time) {
          this.endtime = 1
        } else {
          this.endtime = 2
        }
        this.echoCityinfo(this.userInfo.province_code, this.userInfo.city_code, this.userInfo.district_code)
      } else {
        this.$message({ type: 'error', message: res.msg })
      }
    },
    // 修改用户状态
    async userStateChangeFn (state, id) {
      const _parmas = {
        id: id,
        state: state
      }
      const res = await changeUserState(_parmas)
      if (res.code === 0) {
        this.$message.success('修改成功！')
        this.tableData.forEach(item => {
          if (item.id === id) {
            item.state = state
          }
        })
      } else {
        this.$message.error(res.msg)
      }
    },
    verifyAddUser () {
      if (this.userInfo.name === '') {
        this.$message.error('请输入用户姓名')
        return false
      } 
      if (this.userInfo.related_institution === '') {
        this.$message.error('请输入所属机构')
        return
      } 
      if (this.userInfo.phone === '') {
        this.$message.error('请输入用户手机号')
        return false
      } 
      if (this.userInfo.phone) {
        var phoneReg = /^1[3456789]\d{9}$/
        // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
        if (!this.isUpdate || (this.isUpdate && !this.isFirstChange)) {
          if (!phoneReg.test(this.userInfo.phone)) {
            this.$message({
              message: '请输入正确的手机号码',
              type: 'error'
            })
            return false
          }
        }
      }
      if (this.userInfo.use_start_time === '') {
        this.$message.error('请选择使用时间')
        return false
      }
      return true
    },
    // 新增编辑用户
    async submitForm (type) {
      if (type === 'cancel') {
        this.isUserInfo = false
        return
      }
      if (this.verifyAddUser()) {
        let res = null
        let tips = ''
         // 对手机号加密
        var userPhone = this.userInfo.phone
        this.userInfo.phone = this.$getRsaCode(this.userInfo.phone)
        if (!this.userInfo.id) {
          res = await addCriminalUser(this.userInfo)
          tips = '新增用户成功'
        } else {
          res = await putCriminalUser(this.userInfo)
          tips = '编辑用户成功'
        }
        if (res.code === 0) {
          this.$message.success(tips)
          this.isUserInfo = false
          this.getUserListFn()
        } else {
          this.userInfo.phone = userPhone
          this.$message.error(res.msg)
        }
      }
    },
    noEndTimeFn (val) {
      this.$emit('noEndTimeFn', val)
    },
    resetUserInfor () {
      this.userInfo = {
        name: '',
        sex: 1,
        related_institution: '',
        work_no: '',
        phone: '',
        birthday: '',
        use_start_time: '',
        use_end_time: '',
        province_code: '',
        province: '',
        city_code: '',
        city: '',
        district_code: '',
        district: '',
        address: ''
      }
      this.isGetUserDetail = false
      // 初始化查询时间
      this.initTime = this.$getDefaultTime(0, -1)
      this.userInfo.use_start_time = this.initTime[0].substr(0, 10)
      this.endtime = 2
      // 重置省市区为空
      // this.city.cityValue = [this.userInfo.province_code, this.userInfo.city_code, this.userInfo.district_code]
      this.city.cityValue = ['', '', '']
    },
    // 操作按钮
    operateFn (type, row) {
      if (type === 'add') {
        this.isUserInfo = true
        this.userInfoTite = '新增用户'
        this.isUpdate = false
        this.resetUserInfor()
      } else if (type === 'info') { // 详情
        this.isUserInfo = true
        this.userInfoTite = '编辑用户'
        this.isUpdate = true
        this.isFirstChange = true
        this.getUserinfoByidFn(row.id)
      } else if (type === 'reset') {
        this.$confirm('<i class="iconfont icontishi clr_e6 mr5"></i>确定要重置该用户密码？', '重置密码', {
          distinguishCancelAndClose: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消'
        }).then(() => {
          this.resetPwdFn(row.id)
        })
      } else {
        this.$confirm('确定要解锁该账号？', '解锁账号', {
          dangerouslyUseHTMLString: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消'
        }).then(() => {
          this.toLockFn(row)
        })
      }
    },
    async resetPwdFn (id) { // 重置密码
      const res = await reSetPwd(id, { id: id })
      if (res.code === 0) {
        const self = this
        // 防止密码被特殊字符转义
        function htmlEscape(str) {
          return String(str)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        }
        var _html = ''
        _html = '<div><i class="iconfont iconzhengchang clr_00 mr5"></i>重置密码成功！</div>' +
                '<div class="pl20">系统生成密码：' + htmlEscape(res.data) + '</div>' +
                '<div class="pl20">新密码以短信的方式发送给用户</div>'
        self.$confirm(_html, '重置密码', {
          dangerouslyUseHTMLString: true,
          distinguishCancelAndClose: true,
          confirmButtonText: '复制密码',
          cancelButtonText: '关闭'
        }).then(() => {
          self.$copyText(res.data).then(function (e) {
            self.$message.success('复制成功!')
          })
        })
      } else {
        this.$message.error(res.msg)
      }
    },
    async toLockFn (info) { // 解锁
      const params = {
        id: info.id,
        is_locked: false
      }
      const res = await unLock(params)
      if (res.code === 0) {
        this.tableData.forEach(item => {
          if (item.id === info.id) {
            this.$set(item, 'is_locked', false)
          }
        })
        this.$message.success('解锁成功!')
      } else {
        this.$message.error(res.msg)
      }
    },
    // 筛选搜索
    searchUserlist () {
      this.pageInfo.page_index = 1
      this.pageInfo.page_size = 15
      this.getUserListFn()
    },
    // 重置
    resetSearchDataFn () {
      this.s_type = this.$options.data().s_type
      this.searchData = this.$options.data().searchData
      this.getUserListFn()
    },
    // 分页
    pageSizeChangeFn (info) {
      this.pageInfo.page_index = info.page
      this.searchData.offset = info.page
      this.getUserListFn()
    },
    // 获取城市json
    async getCityJsonFn (params) {
      var self = this
      const res = await getCityJson(params)
      if (res.code === 0) {
        self.city.cityJson = CityLinkedJson(res.data, self.city.cityJson, params)
      }
    },
    async childrenCity (val) {
      var self = this
      val.forEach((item, i) => {
        self.city.city_parmas.parent_code = item
        self.city.city_parmas.level = i + 2
      })
      await self.getCityJsonFn(self.city.city_parmas)
    },
    getCityCodeFn (val) {
      var self = this
      var arr = self.getCascaderObj(val, self.city.cityJson)
      arr.forEach((item, i) => {
        if (i === 0) {
          self.userInfo.province_code = item.value
          self.userInfo.province = item.label
        } else if (i === 1) {
          self.userInfo.city_code = item.value
          self.userInfo.city = item.label
        } else if (i === 2) {
          self.userInfo.district_code = item.value
          self.userInfo.district = item.label
        }
      })
    },
    getCascaderObj (val, opt) {
      return val.map(function (value, index, array) {
        for (var itm of opt) {
          if (itm.value === value) { opt = itm.children; return itm }
        }
        return null
      })
    },
    // 获取城市json-------------------------------------------
    // 回显城市联动
    async echoCityinfo (province, city, district) {
      var self = this
      var _provinceparmas = {
        parent_code: province,
        level: 1
      }
      var _cityparmas = {
        parent_code: city,
        level: 2
      }
      var _districtparmas = {
        parent_code: district,
        level: 3
      }
      var _provincejson = []
      var _cityjson = []
      var _districtjson = []
      // 一级
      const _provinceres = await getCityJson(_provinceparmas)
      _provinceres.data.forEach(item => {
        var info = {
          label: '',
          value: ''
        }
        info.children = []
        info.label = item.name
        info.value = item.code
        _provincejson.push(info)
      })
      self.city.cityJson = _provincejson
      // 二级
      const _cityres = await getCityJson(_cityparmas)
      _cityres.data.forEach(item => {
        var info = {
          label: '',
          value: ''
        }
        info.children = []
        info.label = item.name
        info.value = item.code
        _cityjson.push(info)
      })
      self.city.cityJson.forEach(item => {
        if (item.value === _provinceparmas.parent_code) {
          item.children = _cityjson
        }
      })
      // 三级
      const _districtres = await getCityJson(_districtparmas)
      _districtres.data.forEach(item => {
        var info = {
          label: '',
          value: ''
        }
        info.label = item.name
        info.value = item.code
        _districtjson.push(info)
      })
      self.city.cityJson.forEach(itemlevel => {
        itemlevel.children.forEach(item => {
          if (item.value === _cityparmas.parent_code) {
            item.children = _districtjson
          }
        })
      })
      self.city.cityValue = [self.userInfo.province_code, self.userInfo.city_code, self.userInfo.district_code]
    },
  }
}
</script>
<style>
.el-message-box__header{
  background: #0a70b0 !important;
}
.el-message-box{
  border: none !important;
}
.el-message-box__title, .el-message-box__headerbtn .el-message-box__close{
  color: #ffffff !important;
}
.el-message-box__message{
  font-size: 15px;
}
.switchStyle .el-switch__label {
  position: absolute;
  display: none;
  color: #fff;
}
.switchStyle .el-switch__label--left {
  z-index: 9;
  left: 19px;
}
.switchStyle .el-switch__label--right {
  z-index: 9;
  left: -6px;
}
.switchStyle .el-switch__label.is-active {
  display: block;
}
.switchStyle.el-switch .el-switch__core,
.el-switch .el-switch__label {
  width: 50px !important;
}
.el-switch__label *{
  font-size: 12px !important;
}
</style>
<style lang="less" scoped>
.userList {
  height:100%;
  .userListContainer {
    height:calc(100% - 46px);
    .search-bar {
      .search-bar-label {
        display: inline-block;
        min-width: 90px;
        text-align: right;
        margin-right: 5px;
        color: #303133;
        vertical-align: middle;
      }
    }
    ::v-deep .table-list{
      height:calc(100% - 42px);
      .el-table{
        height:calc(100% - 65px)!important;
      }
    }
    ::v-deep .el-table__empty-text{
      display:none;
    }
    .operate-btn{
      display: inline-block;
      width: 104px;
      text-align: center;
      padding: 0px;
      height:32px;
      line-height: 32px;
      border-radius:3px;
      border: none;
      margin-left: 10px;
      cursor: pointer;
    }
    .border{
      border: 1px solid #DCDFE6;
    }
    .icon-btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      color: #fff;
      line-height: 24px;
      text-align: center;
      padding: 0px;
      cursor: pointer;
      border-radius: 3px;
      margin-right: 8px;
    }
  }
  .dialoginfo{
    position: relative;
  }
  .w_340{
    width: 340px;
  }
  .w_200{
    width: 200px;
  }
  .CAdialog{
    min-height: 500px;
    padding: 20px 0px;
  }
}
</style>
