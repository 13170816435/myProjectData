<template>
    <div class="inspectPage">
        <navHeader :action="2"></navHeader>
        <div class="inspectCon">
           <ConditionInquery :action="2" @getList="getList" :criminalSystemList="criminalSystemList" :consultType="consultType"></ConditionInquery>
           <div
              class="allInspect clear"
              v-loading="loading"
              element-loading-text="拼命加载中"
              element-loading-background="rgba(255,255,255,0.6)"
              v-bind:class="{'noTableData':tableData.length==0}"
              >
             <el-table :data="tableData" border stripe
              height="100%"
              ref="tableAutoScroll"
              highlight-current-row
              header-row-class-name="strong">
              <el-table-column
                fixed="left"
                align="center"
                type="index"
                label="序号"
                width="55">
                  <template slot-scope="scope">
                      <span>{{(searchData.page_index - 1) * searchData.page_size + scope.$index + 1}}</span>
                  </template>
              </el-table-column>
              <el-table-column width="60"
                align="left"
                fixed="left"
                label="操作">
                <template slot-scope="scope">
                  <el-button v-if="scope.row.request_status == 0" class="checkBtn" type="text" @click="showDetail(scope.row)">审核</el-button>
                  <el-button v-else class="watchDetailBtn" type="text" @click="showDetail(scope.row)">查看</el-button>
                </template>
              </el-table-column>
              <common-table :propData="propData" :action="1" />
            </el-table>
           </div>
          <div class="blockPage">
            <pagination-tool :total="totalCheckPage" :page.sync="searchData.page_index" :limit.sync="searchData.page_size" @pagination="beganGetCheckList"/>
          </div>
        </div>
        <!-- 详情 -->
        <el-drawer
            size="880"
            :modal="false"
            :visible.sync="drawer"
            :show-close="false"
            :withHeader="false"
            :before-close="handleClose"
            >
            <ReviewCheckDetail :checkId="checkId" :checkObj="checkObj" @closeFn="closeFn" @checkFinish="checkFinish"></ReviewCheckDetail>
        </el-drawer>
    </div>
</template>
<script>
import navHeader from './components/navHeader'
import ConditionInquery from './components/ConditionInquery'
import ReviewCheckDetail from './components/reviewCheckDetail'
import PaginationTool from '@/components/common/PaginationTool' // 分页
import CommonTable from './components/CommonTable'
import { getCheckList } from '@/api/platform_costomer/criminalInvestigation'
import { getPascList } from '@/api/platform_costomer/institution'
// import mixin from '@/utils/mixin/dataStatic'
export default {
  name: 'checkApplication',
  components: {
    navHeader,
    ConditionInquery,
    CommonTable,
    PaginationTool,
    ReviewCheckDetail
  },
  // mixins: [mixin],
  data () {
    return {
      consultType: 1,
      cellClassNameSet: '会诊申请量',
      totalDataObj: {},
      checkObj: {},
      drawer: false,
      totalCheckPage: 0,
      checkId: '',
      tableData: [],
      criminalSystemList: [],
      loading: true,
      getSystemParam: {
        type: 2,
      },
      searchData: {
        id_card_no: '',
        patient_name: '',
        system_id: '',
        start_date: '',
        end_date: '',
        audit_status: '',
        page_index: 1,
        page_size: 20
      },
      // 表头字段
      propData: [
        { prop: 'request_status', label: '状态', width: 80 },
        { prop: 'submitter_user_name', label: '申请人员', width: 100 },
        { prop: 'submitter_time', label: '申请时间', width: 180 },
        { prop: 'patient_name', label: '当事人姓名', width: 100 },
        { prop: 'patient_sex', label: '性别', width: 80, formatter: this.patientSex },
        { prop: 'id_card_no', label: '身份证号', width: 180 },
        { prop: 'reason', label: '调阅理由', width: 200 },
        { prop: 'system_id', label: '调阅系统(系统ID)', width: 280 },
        { prop: 'audit_time', label: '审阅时间' }
      ]
    }
  },
  methods: {
    handleClose (done) {
      done()
    },
    closeFn () {
      this.drawer = false
    },
    checkFinish () {
      this.checkObj.request_status = 1
    },
    myRowkey (row) {
      return row.id
    },
    showDetail (row) {
      this.drawer = true
      this.checkObj = row
      this.checkId = row.id.toString()
    },
    getList (obj) {
      this.searchData = obj
      this.beganGetCheckList()
    },
    async beganGetCheckList () {
      const self = this
      const res = await getCheckList(self.searchData)
      if (res.code === 0) {
        self.loading = false
        self.tableData = res.data
        self.totalCheckPage = res.page.total_count
      } else {
        self.loading = false
        self.$message.error(res.msg)
      }
    },
    async getSystemList () {
      const self = this
      self.criminalSystemList = []
      const res = await getPascList(self.getSystemParam.type)
      if (res.code === 0) {
        if (res.data.length != 0) {
          res.data.forEach((one) => {
             if (one.product_code == "ImageCriminal") {
               self.criminalSystemList.push(one)
             }
          })
        }
        self.criminalSystemList.unshift({name:'全部', id: ''})
      } else {
        self.$message({ type: 'error', message: res.msg })
      }
    },
  },
  mounted () {
    // 获取刑侦调阅系统
    this.getSystemList()
  }
}
</script>
<style lang="less" scoped>
.inspectPage{
  height:100%;
}
  .timeItem{
    height:50px;
    padding: 10px 10px;
    background:#fff;
    padding-left: 0px;
  ::v-deep .el-radio-group{
    height:32px;
    line-height: 30px;
    .el-radio-button__inner{
      height:32px;
      line-height: 30px;
      padding:0!important;
      width:88px;
      text-align: center;
    }
    .el-radio-button__orig-radio:checked+.el-radio-button__inner{
       background-color: #0a70b0!important;
       border-color: #0a70b0!important;
    }
  }
}
.inspectCon{
  padding:10px 15px;
  height: calc(100% - 47px);
  .allInspect{
    // border: 1px solid #ebeef5;
    height:calc(100% - 100px);
    position: relative;
    ::v-deep .ss_tableModel{
        height:100%;
        .el-table{
            height:100%!important;
              .el-table__body-wrapper{
               height:calc(100% - 105px);
               overflow: auto;
             }
        }
    }
  }
}
::v-deep .el-drawer__body{
  height:100%;
}
.watchDetailBtn{
  color:#0a70b0;
}
.checkBtn{
  color:#ef8900;
}
.blockPage{
  border:1px solid #eee;
  border-top:none;
}
@media screen and (max-width: 1450px) {
  ::v-deep .reviewTime{
    clear: both;
    margin-top:10px;
    margin-bottom: 10px;
  }
  ::v-deep .operateBtnDiv{
    margin-top:10px;
  }
  .allInspect{
    height:calc(100% - 143px)!important;
  }
}
</style>
