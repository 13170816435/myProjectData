<template>
  <div class="med-query">
          <div class="search-bar">
            <div class="searchTop mb10">
              <div class="fl mr20" v-if="action ===2 ">
                   <span class="search-bar-label fl">调阅系统 :</span>
                   <el-select
                      v-model="searchData.system_id"
                      filterable
                      @change="search"
                      class="ele-select_32 width_180_select"
                      placeholder="全部"
                      style="width:180px"
                  >
                    <el-option
                    v-for="(item,index) in criminalSystemList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                    ></el-option>
                </el-select>
              </div>
              <div class="fl mr20" v-if="action ===2 ">
                   <span class="search-bar-label statusLabel fl">状态 :</span>
                   <el-select
                      v-model="searchData.audit_status"
                      filterable
                      @change="search"
                      class="ele-select_32 width_100_select"
                      placeholder="全部"
                      style="width:100px"
                  >
                    <el-option
                    v-for="(item,index) in accessStatusArr"
                    :key="index"
                    :label="item.name"
                    :value="item.id"
                    ></el-option>
                </el-select>
              </div>
              <div class="fl mr5" v-if="action ===2 ">
                   <el-select
                      v-model="searchTypeVal"
                      filterable
                      class="ele-select_32 width_120_select"
                      placeholder="请选择"
                      style="width:120px"
                      @change="changeSearchType"
                  >
                    <el-option
                    v-for="(item,index) in searchType"
                    :key="index"
                    :label="item.name"
                    :value="item.id"
                    ></el-option>
                </el-select>
              </div>
              <div class="fl mr10" v-if="action ===2 ">
                <el-input class="fl width_180_input" v-if="searchTypeVal === 0" v-on:keyup.enter.native=search v-model="searchData.patient_name"  placeholder="请输入当事人姓名"></el-input>
                <el-input class="fl width_180_input" v-if="searchTypeVal === 1" v-on:keyup.enter.native=search v-model="searchData.id_card_no"  placeholder="请输入身份证号"></el-input>
              </div>
              <div class="reviewTime fl" v-bind:class="{'mr10': action ===2, 'mr20': action ===3}">
                <span class="search-bar-label fl">调阅时间 :</span>
                <SearchTime @getTimes="getTime" class="fl" :width="width" :clearTime="clearTime" :initTime="initTime"/>
              </div>
              <div class="fl mr10" v-if="action === 3 ">
                <span class="search-bar-label reviewPeople fl">调阅人 :</span>
                <el-input class="fl width_180_input" v-on:keyup.enter.native=search v-model="searchData.view_name"  placeholder=""></el-input>
              </div>
              <div class="fl operateBtnDiv">
                <el-button type="primary" size="small" @click="search">查询</el-button>
                <el-button size="small" plain @click="resetSearch">重置</el-button>
              </div>
            </div>
           </div>
  </div>
</template>
<script>
import eventBus from '@/utils/eventBus'
import SearchTime from './SearchTime' // 搜索时间
import { getInstitutions } from '@/api/seviceCenterManage/centerSet'
export default {
  props: {
    action: {
      type: Number
    },
    criminalSystemList: Array,
    consultType: {
      type: Number
    }
  },
  components: {
    SearchTime
  },
  data () {
    return {
      width: '240px',
      initTime: [],
      clearTime: false,
      searchTypeVal: 0,
      searchData: {
        id_card_no: '',
        patient_name: '',
        start_date: '',
        end_date: '',
        audit_status: '',
        view_name: '',
        page_index: 1,
        page_size: 20
      },
      searchType: [
        {
          name: '当事人姓名',
          id: 0
        },
        {
          name: '身份证号',
          id: 1
        }
      ],
      accessStatusArr: [
        {
          name: '全部',
          id: ''
        },
        {
          name: '待审核',
          id: 0
        },
        {
          name: '已审核',
          id: 1
        }
      ]
    }
  },
  methods: {
    // 重置
    resetSearch () {
      this.initTime = this.$getDefaultTime(6, -1)
      this.searchTypeVal = 0
      this.searchData = {
        id_card_no: '',
        patient_name: '',
        start_date: this.initTime[0],
        end_date: this.initTime[1],
        audit_status: '',
        page_index: 1,
        page_size: 20
      }
      this.search()
    },
    changeSearchType () {
      if (this.searchTypeVal === 0) {
        this.searchData.id_card_no = ''
      } else {
        this.searchData.patient_name = ''
      }
    },
    // 搜索
    search () {
      this.$emit('getList', this.searchData)
    },
    async getInstitutionData () {
      const param = {
        institution_id: '',
        institution_code: ''
      }
      const res = await getInstitutions(param)
      if (res.code === 0) {
        this.institutionArr = res.data
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 获取查询时间
    getTime (time) {
      const timer = time || []
      if (timer.length > 0) {
        this.searchData.start_date = timer[0].substr(0, 10)
        this.searchData.end_date = timer[1].substr(0, 10)
      } else {
        this.searchData.start_date = ''
        this.searchData.end_date = ''
      }
      // this.search()
    }
  },
  watch: {
    consultType: function (val) {
      if (val === 2) {
        this.searchData.date_type = 1
      } else if (val === 1) {
        this.searchData.date_type = 0
      }
    }
  },
  computed: {

  },
  created () {
    // eventBus.$on('consultShowColumnd', () => {
    //   this.setColumndShow = true
    // })
  },
  mounted () {
    // 初始化查询时间
    this.initTime = this.$getDefaultTime(6, -1)
    this.searchData.start_date = this.initTime[0].substr(0, 10)
    this.searchData.end_date = this.initTime[1].substr(0, 10)
    this.search()
  }
}
</script>
<style lang="less">
.med-query{
  .searchTop{
    min-height:32px;
  }
  .search-bar .addPadding{
    padding: 0 9px;
  }
  .search-bar .statusLabel{
    width:41px!important;
    min-width: 41px;
    text-align: left!important;
  }
  .reviewPeople{
    min-width: auto!important;
    text-align: left!important;
  }
}
</style>
