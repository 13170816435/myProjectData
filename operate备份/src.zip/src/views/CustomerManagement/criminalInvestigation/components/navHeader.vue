<template>
    <div class="title-bar flex_row">
            <div class="tl col">
                <span class="title-name clr_303">
                <i class="iconfont icondingwei mr10"></i>司法鉴定
                <i class="iconfont iconzhankaishouqi"></i> {{currentPageName}}
                </span>
            </div>
        </div>
</template>
<script>
// import { importCheckApplicationList } from '@/api/platform_departMent/dataStatistics'
export default {
  name: 'navHeader',
  props: {
    action: {
      type: Number
    }
  },
  data () {
    return {
      currentPageName: ''
    }
  },
  methods: {
    initTit () {
      if (this.action === 2) {
        this.currentPageName = '调阅审核'
      } else if (this.action === 3) {
        this.currentPageName = '调阅日志'
      } else if (this.action === 3) {
        this.currentPageName = '登记工作量'
      } else if (this.action === 4) {
        this.currentPageName = '检查工作量'
      }
    }
  },
  mounted () {
    this.initTit()
  }
}
</script>
<style lang="less" scoped>

</style>
