<template>
<!-- 表格： 可通过后台返回控制table显示某列 及自定义宽度 -->
  <div>
    <template v-for="(item, index) in propData">
      <el-table-column
        v-if="item.prop == 'request_status'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
          <span v-if="action === 1 && scope.row.request_status === 0" class="clr_red">待审核</span>
          <span v-if="action === 1 && scope.row.request_status === -1" class="clr_red">已取消</span>
          <span v-if="action === 1 && scope.row.request_status > 0 && scope.row.request_status < 4" class="clr_00">已审核</span>
          <span v-if="action === 2 && scope.row.request_status === -1" class="clr_red">拒绝</span>
          <span v-if="action === 2 && scope.row.request_status === 0" class="clr_red">待审核</span>
          <span v-if="action === 2 && scope.row.request_status === 1"  class="clr_00">同意</span>
        </template>
      </el-table-column>
      <el-table-column
        v-else-if="item.prop == 'patient_sex'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
           <span>{{scope.row.patient_sex === 1 ? '男': scope.row.patient_sex === 2 ? '女' : '未知'}}</span>
        </template>
      </el-table-column>
       <el-table-column
        v-else-if="item.prop == 'system_id' && action == 1"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
          <span>{{scope.row.system_name}}({{scope.row.system_id}})</span>
        </template>
      </el-table-column>
      <el-table-column
        v-else-if="item.prop == 'patient_age'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
          <span>{{scope.row.patient_age}} {{scope.row.age_unit}}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-else
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
      </el-table-column>
    </template>
  </div>
</template>
<script>
import mixin from '@/utils/mixin/intelligentDiagnosis'
export default {
  name: 'CommonTable',
  props: {
    propData: Array,
    action: Number
  },
  mixins: [mixin]
}
</script>
<style lang="less">
.clr_red{
  color:#da4a4a;
}
</style>
