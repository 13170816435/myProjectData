 <template>
 <!-- 时间 -->
  <div>
    <el-date-picker
      :style="{width: width}"
      v-model="time"
      type="daterange"
      align="right"
      class="searchTimePicker"
      unlink-panels
      range-separator="至"
      start-placeholder="开始日期"
      end-placeholder="结束日期"
      :picker-options="pickerOptions"
      @change="changeTime"
      value-format="yyyy-MM-dd">
    </el-date-picker>
  </div>
</template>
<script>
export default {
  name: 'SearchTime',
  props: {
    width: String,
    clearTime: { // 重置时
      type: Boolean,
      required: false
    },
    initTime: { // 初始化时给定默认时间
      type: Array,
      required: false
    }
  },
  watch: {
    clearTime: function (value) {
      if (value === true) {
        this.time = ''
      }
    },
    initTime: function (val) {
      this.time = val
      if (this.time && this.time.length !== 0) {
        var start = this.time[0]
        var end = this.time[1]
        this.$emit('getTimes', [start, end])
      }
    }
  },
  data () {
    return {
      time: '',
      // 快捷选项选择日期
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 6)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      }
    }
  },
  methods: {
    changeTime (val) {
      this.$emit('getTimes', val)
    }
  }
}
</script>
<style lang="less" scoped>
.searchTimePicker{
  ::v-deep .el-range__close-icon{
    line-height: 26px!important;
  }
}
</style>
