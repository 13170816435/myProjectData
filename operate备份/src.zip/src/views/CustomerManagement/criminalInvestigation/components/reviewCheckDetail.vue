<template>
  <div class="recordDetail" id="recordDetail">
    <div class="recordDetail-title">
      <span class="recordDetail-titleinfo">调阅查看</span>
      <span @click="closeFn" class="close-btn iconfont iconchuangjianshibai"></span>
    </div>
    <div class="contaner" v-bind:class="{'hasChecked': checkObj.request_status === 1}">
      <div class="contaner-info">
        <div class="clear">
            <span class="inforTit">申请信息</span>
        </div>
        <ul class="detail_info_list basicInforHead clear">
          <li class="applyClearFloat fl"><span class="width_80 fl">申请人员：</span><span class="width_220 fl">{{checkObj.submitter_user_name}}</span></li>
          <li class="fl"><span class="width_80 fl">申请时间：</span><span class="width_220 fl">{{checkObj.submitter_time}}</span></li>
          <li class="fl"><span class="langNameLabel fl">当事人姓名：</span><span class="width_210 fl">{{checkObj.patient_name}}</span></li>
          <li class="fl"><span class="idCardLabel fl">当事人身份证号：</span><span class="width_220 fl">{{checkObj.id_card_no}}</span></li>
          <li class="fl clear"><span class="width_80 fl moreConTit">调阅理由：</span>
          <span class="moreContent info-right moreLineEllipsis moreLineAfter medIconfont fl"
              v-html="$replaceRN(checkObj.reason)"
              @click="showAll($event)">
            </span></li>
        </ul>
        <div class="clear">
           <span class="inforTit">审核内容</span>
        </div>
        <div class="stepCon">
               <el-timeline>
                  <el-timeline-item
                    placement="top"
                    v-for="(activity, index) in activities"
                    :key="index"
                    :icon="activity.icon"
                    :type="activity.type"
                    :color="activity.color"
                    :size="activity.size"
                    :timestamp="activity.time">
                      <div v-if="index === 0">
                         <div class="firstItem"><span class="firstItemTit">留档照片</span></div>
                         <div class="imgArrCon clear">
                           <img :src="item" alt="" v-for="(item, index) in activity.imgArr" :key="index" :onerror="defaultImg">
                         </div>
                      </div>
                      <div v-else class="clear">
                            <div class="itemHead">
                                <el-checkbox @change="changeOneInspect" v-model="activity.checked" v-if="checkObj.request_status === 0" class="oneCheckbox fl mr10"></el-checkbox>
                                <span class="fl mr10 perform_time" >{{activity.perform_time}}</span>
                                <span class="fl danger word mr10" v-if="activity.critical_value">危</span>
                                <span class="fl sun word" v-if="activity.abnormal_flags === 1">阳</span>
                                <span class="fl sun word" v-else-if="activity.abnormal_flags === 0">阴</span>
                                <span class="fl noKnow twoWord" v-else>未知</span>
                                <span class="fr checkStu" v-if="checkObj.request_status > 0 && activity.request_status === 1">同意调阅</span>
                                <span class="fr refuseStu" v-if="checkObj.request_status > 0  && activity.request_status === 0">待审核</span>
                                <span class="fr refuseStu" v-if="checkObj.request_status > 0  && activity.request_status === -1">拒绝调阅</span>
                            </div>
                            <el-card class="clear">
                                  <ul class="detail_info_list clear">
                                      <li class="applyClearFloat fl"><span class="width_80 fl">检查科室：</span><span class="width_220 fl">{{activity.perform_depart_name}}</span></li>
                                      <li class="fl"><span class="width_80 fl">检查类型：</span><span class="width_220 fl">{{activity.exam_type}}</span></li>
                                      <li class="fl"><span class="width_80 fl">检查项目：</span><span class="width_220 fl">{{activity.exam_item}}</span></li>
                                      <li class="fl"><span class="width_80 fl">检查医院：</span><span class="width_220 fl">{{activity.perform_org_name}}</span></li>
                                      <li class="fl"><span class="width_80 fl">临床诊断：</span><span class="width_220 fl">{{activity.clinic_diagnosis}}</span></li>
                                      <li class="fl clear"><span class="width_80 fl moreConTit">影像所见：</span>
                                        <span class="info-right moreLineEllipsis moreLineAfter medIconfont fl"
                                          v-html="$replaceRN(activity.image_sight)"
                                          @click="showAll($event)">
                                        </span>
                                        <!-- <span class="info-right moreLineEllipsis moreLineAfter medIconfont fl" @click="showAll($event)">
                                          氨基酸东方丽景三法拉三等奖弗利萨发就拉水电费拉水电费就六点十分拉水电费的拉菲<br/>
                                          大劳动法调度<br/>
                                          <br/>
                                          <br/>
                                        </span> -->
                                      </li>
                                      <li class="fl clear"><span class="width_80 fl moreConTit">影像诊断：</span>
                                      <span class="info-right moreLineEllipsis moreLineAfter medIconfont fl"
                                          v-html="$replaceRN(activity.image_diagnosis)"
                                          @click="showAll($event)">
                                        </span></li>
                                    </ul>
                            </el-card>
                      </div>
                  </el-timeline-item>
                </el-timeline>
            </div>
      </div>
    </div>
    <div class="operate-btn-div" v-if="checkObj.request_status === 0">
      <el-checkbox v-model="checked" class="oneCheckbox" @change="chooseAll">全选</el-checkbox>
      <el-button class="operate-btn bg_0c" @click="subCheck">审核</el-button>
      <span class="checkTip">(未勾选检查将拒绝申请方调阅)</span>
    </div>
      <el-dialog v-bind:title="'提示'" append-to-body :visible.sync="showNoChooseAlert" width="750px" height="340px" :close-on-click-modal="false" v-dialogDrag>
          <div class="allNoChooseInspect">
              <div class="inspectHead">
                 <i class="iconfont icontishi pr10"></i>
                 <span class="inspectHeadTit">拒绝调阅以下检查?</span>
              </div>
              <div class="NoChooseInspectItem">
                  <el-table
                    :data="noChoosedInspect"
                    ref="interfaceTable"
                    border
                    stripe
                    height="100%"
                    :header-cell-style="{background: '#F2F2F2',color: '#333'}"
                    highlight-current-row
                    header-row-class-name="strong"
                    >
                    <common-table :propData="propNoChooseData" />
                 </el-table>
              </div>
          </div>
          <span slot="footer" class="dialog-footer">
              <el-button size="small" plain @click="showNoChooseAlert = false">取 消</el-button>
              <el-button  type="primary" size="small" @click="beganSubCheck">确 定</el-button>
          </span>
      </el-dialog>
  </div>
</template>
<script>
// import eventBus from '@/utils/eventBus'
import CommonTable from './CommonTable'
import { getAuditDetail, auditOrExam, downloadMedias } from '@/api/platform_costomer/criminalInvestigation'
export default {
  props: {
    checkId: {
      type: String
    },
    checkObj: {
      type: Object
    },
    // 1-申请 2-审核 3-调度 4-工作 5-记录 6-协助
    action: {
      type: Number
    }
  },
  components: {
    CommonTable
  },
  data () {
    return {
      defaultImg: 'this.src="' + require('@/assets/images/common/serviceCenter.jpg') + '"',
      // 详情对像
      detail: {
        referral_case_history: {}
      },
      activities: [],
      checked: false,
      showNoChooseAlert: false,
      noChoosedInspect: [],
      propNoChooseData: [
        { prop: 'perform_depart_name', label: '检查科室', width: 100 },
        { prop: 'exam_type', label: '检查类型', width: 100 },
        { prop: 'exam_item', label: '检查项目', width: 240 },
        { prop: 'perform_org_name', label: '检查医院' }
      ]
    }
  },
  watch: {
    'checkId': {
      handler (newVal) {
        if (this.checkId) {
          this.getInspectRecordDetail()
        }
      },
      deep: true,
      immediate: true
    },
    detail () {
      this.$nextTick(() => {
        this.isOmit()
      })
    }
  },
  methods: {
    // 判断是否有省略
    isOmit () {
      var oDiv = document.querySelectorAll('#recordDetail .moreLineEllipsis')
      oDiv.forEach(item => {
        if (item.scrollHeight > item.clientHeight) {
          item.classList.remove('moreLineShowAll')
          item.classList.add('showMoreLineAfter')
        } else {
          item.classList.remove('showMoreLineAfter')
          item.classList.remove('moreLineShowAll')
        }
      })
    },
    // 显示所有
    showAll ($event) {
      if ($event.target.scrollHeight > $event.target.clientHeight) {
        // $event.target.classList.remove('showMoreLineAfter')
        $event.target.classList.remove('moreLineAfter')
        $event.target.classList.add('moreLineShowAll')
      } else {
        $event.target.classList.remove('moreLineShowAll')
        // $event.target.classList.add('showMoreLineAfter')
        $event.target.classList.add('moreLineAfter')
      }
    },
    closeFn () {
      this.$emit('closeFn')
    },
    changeNav (index) { // 切换tab
      this.isActive = index
    },
    // 全选
    chooseAll (bool) {
      const self = this
      self.activities.forEach((val) => {
        val.checked = bool
      })
    },
    changeOneInspect (bool) {
      if (!bool) {
        this.checked = false
      }
    },
    // 提交审核
    subCheck () {
      const self = this
      self.noChoosedInspect = []
      self.activities.forEach((val, i) => {
        if (!val.checked && i !== 0) {
          self.noChoosedInspect.push(val)
        }
      })
      // 有 没勾选的
      if (self.noChoosedInspect.length !== 0) {
        self.showNoChooseAlert = true
      } else {
        self.beganSubCheck()
      }
    },
    async beganSubCheck () {
      const self = this
      let businessIdArr = []
      self.activities.forEach((val) => {
        let obj = {
          forensic_relation_observation_id: val.id,
          is_pass: val.checked
        }
        if (val.id) {
          businessIdArr.push(obj)
        }
      })
      const res = await auditOrExam(businessIdArr, self.checkObj.id)
      if (res.code === 0) {
        self.$message({ message: '审核成功',type: 'success'})
        self.showNoChooseAlert = false
        self.$emit('checkFinish')
        self.getInspectRecordDetail()
      } else {
        self.$message.error(res.msg)
      }
    },
    // 获取详情
    getInspectRecordDetail () {
      const _this = this
      _this.checked = false
      _this.activities = []
      getAuditDetail(_this.checkId).then(res => {
        if (res.code === 0) {
          _this.detail = res.data
          if (_this.detail.observations && _this.detail.observations.length !== 0 && _this.detail.photos && _this.detail.photos.length !== 0) {
            var obj = {
              size: 'large',
              type: 'primary',
              icon: 'el-icon-more',
              imgArr: [],
              checked: false,
            }
            for (let i = 0; i < _this.detail.photos.length; i++) {
              obj.imgArr.push(this.defaultImg)
            }
            _this.activities.push(obj)
            // 再将图片的正确路径 替换默认的
            for (let i = 0; i < _this.detail.photos.length; i++) {
              // 获取logo 图片
              let data = {
                file_token: _this.detail.photos[i].document_id
              }
              downloadMedias(data).then((res) => {
                var src ='data:image/jpg;base64,'+ btoa(new Uint8Array(res).reduce((data, byte) => data + String.fromCharCode(byte), ''))
                // obj.imgArr[i] = src
                _this.$set(_this.activities[0].imgArr, i, src)
              }).catch(error => {
                console.log(error)
              })
            }
            _this.detail.observations.forEach((val, index) => {
              // 默认为成功的颜色
              val.color = '#0bbd87'
              // 给其它加上颜色
              if (val.state === 0 || val.state === -1 || val.state === -98) {
                val.color = '#e4e7ed'
              } else if (val.state === -99 || (val.state < 0 && val.state >= -70)) { // 给所有失败加上颜色
                val.color = '#f56c6c'
              }
              _this.activities.push(val)
            })
            _this.activities.forEach((val,i) => {
              _this.$set(_this.activities[i], 'checked', false)
            })
          } else {
            _this.activities = []
          }
        } else {
          _this.$message.error(res.msg)
        }
      })
    }
  },
  created () {
    // eventBus.$on('hadBeganConsult', () => {
    //   this.getInspectRecordDetail()
    // })
  },
  mounted () {

  }
}
</script>
<style lang="less" scoped>
.recordDetail {
  width: 750px;
  height: 100%;
  padding: 0px 25px;
  .recordDetail-title {
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    .recordDetail-titleinfo {
      font-size: 16px;
      color: #303133;
      font-weight: 700;
    }
    .clr_00a {
      background: rgba(0, 173, 120, 1);
    }
    .close-btn {
      position: absolute;
      right: 0px;
      top: 0px;
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .contaner {
    height: calc(100% - 108px);
    border: 1px solid #dcdfe6;
    overflow-y: auto;
    .failreson {
      height: 42px;
      line-height: 42px;
      padding: 0px 10px;
      background: #fff6f7;
      .clr_88 {
        color: #888888;
      }
      .clr_da {
        color: #da4a4a;
      }
    }
  }
  .hasChecked {
    height: calc(100% - 65px)!important;
  }
}
.addPadding7{
  padding:0 7.5px;
}
.inforTit {
    float: left;
    padding-left: 10px;
    color: #333;
    font-size: 15px;
    height: 40px;
    line-height: 40px;
    position: relative;
    text-indent: 10px;
    width: 100%;
    background: #fafafd;
}
.inforTit:before {
    position: absolute;
    left: 10px;
    top: 14px;
    width: 3px;
    height: 14px;
    background: #0a70b0;
    content: '';
}
.detail_info_list {
    padding: 8px 10px;
}
.detail_info_list li {
    float: left;
    line-height: 30px;
    min-height: 30px;
    margin-bottom: 8px;
    position: relative;
    // width:100%;
}
.moreConTit{
  position:absolute;
  left: 0;
  top: 0;
}
.width_80 {
    float: left;
    width: 80px;
    font-size:15px;
    text-align: left;
    color: #888;
}
.width_220{
    float: left;
    width: 220px;
    font-size:15px;
    text-align: left;
    color: #303133;
}
li .langNameLabel, li .idCardLabel{
  width:auto;
  font-size:15px;
  color: #888;
}
li .width_110{
    float: left;
    width: 110px;
    font-size:15px;
    text-align: right;
    color: #888;
}
li .width_190{
    float: left;
    width: 190px;
    font-size:15px;
    text-align: left;
    color: #303133;
}
li .width_210{
    float: left;
    width: 210px;
    font-size:15px;
    text-align: left;
    color: #303133;
}
.basicInforHead{
  border-bottom: 1px dashed #d5e2f3;
}
.moreLineAfter{
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}
.moreLineEllipsis{
  padding-left:80px;
  width:100%;
}
.moreLineEllipsis:after {
    display: none;
    position: absolute;
    bottom: 0;
    right: 0;
    font-size:15px!important;
    content: '查看更多';
    // background-color: #fff;
    color: #0a70b0;
    cursor: pointer;
    text-align: right;
    font-weight: bold;
    padding-left: 13px;
    background:#fff;
}
.medIconfont{
  font-size:15px!important;
}
.moreLineShowAll:after {
    display: block;
    content: '收起';
}
.showMoreLineAfter:after {
   display: block;
}
.stepCon{
  padding: 10px;
}
.word{
  width:24px;
  height:24px;
  border-radius: 3px;
  color:#fff;
  font-size:14px;
  text-align: center;
  line-height: 24px;
}
.twoWord{
  width:48px;
  height:24px;
  border-radius: 3px;
  color:#fff;
  font-size:14px;
  text-align: center;
  line-height: 24px;
}
.danger{
  background:#da4a4a;
}
.perform_time{
  font-size:15px;
  color:#303133;
  font-weight: bold;
}
.sun {
  background:#e6a23c;
}
.noKnow {
  background:#C0C4CC;
}
.checkStu{
  color:#00a06f;
  font-weight: bold;
  font-size: 15px;
}
.refuseStu{
  color:#da4a4a;
  font-weight: bold;
  font-size: 15px;
}
::v-deep .el-timeline-item__content{
  position: relative;
  .el-checkbox{
    // position: absolute;
    // top: 1px;
    // left:0;
  }
}
::v-deep .el-timeline-item__timestamp{
  float:left;
  font-size:15px;
  color:#303133;
  font-weight: bold;
  margin-left:20px;
  margin-right:15px;
  margin-bottom: 10px;
}
::v-deep .el-timeline-item__wrapper{
  padding-left:18px;
}
::v-deep .el-card__body{
  background:#f9f9f9;
  // border:1px solid #ebeef5;
  padding:10px 15px;
  .detail_info_list{
    padding:0;
  }
}
.operate-btn-div{
  height: 60px;
  line-height: 58px;
  ::v-deep .el-checkbox__label{
    font-size:15px;
    color:#303133;
    font-weight: bold;
  }
  .operate-btn{
    width:80px;
    height:36px;
    line-height: 11px;
    background:#0a70b0;
    color:#fff;
    margin-left:20px;
    text-align: center;
    border: 1px solid #0a70b0;
  }
}
.moreContent{
  min-height: 30px;
}
.itemHead{
  position: relative;
  top: -14px;
  .oneCheckbox{
    margin-right:10px!important;
  }
}
.firstItem {
  position: relative;
  // height:30px;
  // line-height: 30px;
  .firstItemTit{
    position: absolute;
    left: 0;
    font-weight: bold;
  }
}
.imgArrCon{
  position: relative;
  top: 12px;
  img {
    width:180px;
    height:112px;
    border:1px solid #EBEEF5;
    margin-right:15px;
  }
}
::v-deep .el-card.is-always-shadow {
  box-shadow: none!important;
}
::v-deep .el-card.is-hover-shadow:focus {
  box-shadow: none!important;
}
::v-deep .el-card.is-hover-shadow:hover{
  box-shadow: none!important;
}
.inspectHead{
  height:50px;
  line-height: 50px;
  text-align: center;
  i{
    font-size:24px!important;
    color:#e6a23c;
  }
  .inspectHeadTit{
    font-size:16px;
    color:#303133;
    font-weight: bold;
  }
}
.NoChooseInspectItem{
  height:394px;
  padding: 0 20px;
  margin-bottom: 20px;
  ::v-deep .el-table__body-wrapper{
    height: calc(100% - 40px);
    overflow-y: auto;
  }
}
.checkTip{
  color: #EF8900;
  font-size:15px;
  padding-left:15px;
}
</style>
