<template>
  <div class="userlist">
    <navHeader :action="3"></navHeader>
    <div class="container">
        <ConditionInquery :action="3" @getList="getList"></ConditionInquery>
        <div class="containerLeft fl">
            <div class="table-list dictionarayClassList" v-bind:class="{'noTableData':dictionaryClassTable.length==0}">
                    <el-table
                    :data="dictionaryClassTable"
                    ref="interfaceTable"
                    @row-click="rowTypeClick"
                    border
                    stripe
                    height="100%"
                    :header-cell-style="{background: '#F2F2F2',color: '#333'}"
                    highlight-current-row
                    header-row-class-name="strong"
                    >
                    <el-table-column fixed="left" type="index" label="序号" width="50">
                        <template slot-scope="scope">
                           <span>{{(searchData.page_index - 1) * searchData.page_size + scope.$index + 1}}</span>
                        </template>
                    </el-table-column>
                    <common-table :propData="propData" :action="2"/>
                 </el-table>
          </div>
          <div class="blockPage">
            <pagination-tool :total="totalLog" :page.sync="searchData.page_index" :limit.sync="searchData.page_size" @pagination="beganGetCheckList"/>
          </div>
        </div>
        <div class="containerRight ml20 fl">
            <div class="table-list dictionarayValList" v-bind:class="{'noTableData':dictionaryValTable.length==0}">
                    <el-table
                    :data="dictionaryValTable"
                    border
                    :header-cell-style="{background: '#F2F2F2',color: '#333'}"
                    header-row-class-name="strong"
                    >
                    <el-table-column fixed="left" type="index" label="序号" width="50"></el-table-column>
                    <common-table :propData="logDetailPropData"  :action="2"/>
              </el-table>
          </div>
        </div>
    </div>
  </div>
</template>

<script>
import navHeader from './components/navHeader'
import ConditionInquery from './components/ConditionInquery'
import CommonTable from './components/CommonTable'
import PaginationTool from '@/components/common/PaginationTool' // 分页
import { getLogViewPage, getAuditDetail } from '@/api/platform_costomer/criminalInvestigation'
export default {
  components: {
    navHeader,
    ConditionInquery,
    CommonTable,
    PaginationTool
  },
  data () {
    return {
      searchData: {
        id_card_no: '',
        patient_name: '',
        start_date: '',
        end_date: '',
        audit_status: '',
        page_index: 1,
        page_size: 20
      },
      totalLog: 0,
      currentTypeCode: '',
      currentTypeId: '',
      dictionaryClassTable: [],
      dictionaryValTable: [],
      currentPage: 1,
      // 表头字段
      propData: [
        { prop: 'user_name', label: '调阅人', width: 100 },
        { prop: 'view_time', label: '调阅时间', width: 180 },
        { prop: 'patient_name', label: '当事人姓名', width: 100 },
        { prop: 'patient_sex', label: '性别', width: 80, formatter: this.patientSex },
        { prop: 'patient_age', label: '年龄', width: 80 },
        { prop: 'id_card_no', label: '身份证号', width: 180 }
      ],
      logDetailPropData: [
        { prop: 'request_status', label: '审核状态', width: 100 },
        { prop: 'perform_depart_name', label: '检查科室', width: 120 },
        { prop: 'exam_type', label: '类型', width: 80 },
        { prop: 'exam_item', label: '检查项目', width: 160 },
        { prop: 'perform_org_name', label: '检查机构', width: 180 },
        { prop: 'perform_time', label: '检查时间' }
      ]
    }
  },
  methods: {
    rowTypeClick (row, column, event) {
      if (row.request_id !== this.checkId) {
        this.checkId = row.request_id
        this.getMyDictInforList()
      }
    },
    getList (obj) {
      this.searchData = obj
      this.beganGetCheckList()
    },
    // 获取字典类型
    async beganGetCheckList () {
      const res = await getLogViewPage(this.searchData)
      if (res.code === 0) {
        this.dictionaryClassTable = res.data
        this.totalLog = res.page.total_count
        if (this.dictionaryClassTable.length !== 0) {
          this.checkId = res.data[0].request_id
          this.getMyDictInforList()
        } else {
          this.dictionaryValTable = []
        }
      }
    },
    // 获取字典信息列表
    async getMyDictInforList () {
      const res = await getAuditDetail(this.checkId)
      if (res.code === 0) {
        this.dictionaryValTable = res.data.observations
      } else {
        this.$message.error(res.msg)
      }
    }
  },
  watch: {
    dictionaryClassTable: function () {
      this.$nextTick(function () {
        this.$refs.interfaceTable.setCurrentRow(this.dictionaryClassTable[0])
      })
    }
  },
  mounted () {
  }
}
</script>
<style lang="less" scoped>
.userlist {
  width: 100%;
  height: 100%;
  overflow: hidden !important;
}
.userlist {
  .container {
    padding: 10px 10px;
    background: #fff;
    height: calc(100% - 47px);
    position: relative;
    .iconfont {
      margin: 0px;
    }
    .icon-btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      color: #fff;
      line-height: 24px;
      text-align: center;
      padding: 0px;
      cursor: pointer;
      border-radius: 3px;
      margin-right: 8px;
    }
    .table-list {
      position: relative;
      border: 1px solid #ebeef5;
      height: calc(100% - 43px);
      overflow-y: auto;
      ::v-deep .el-table--border {
        border: none;
      }
    }
  }
.containerLeft {
 width: calc(45% - 10px);
}
.containerRight{
 width: calc(55% - 10px);
}
.containerLeft ,.containerRight{
    // width: calc(50% - 10px);
    // width:600px;
    height:100%;
    ::v-deep .current-row{
        position: relative;
        td{
            position: relative;
           background:#e3f4ff!important;
        }
    }
     ::v-deep .current-row td:nth-of-type(1)::before{
        content: "";
        display: block;
        height: 41px;
        width: 3px;
        position: absolute;
        top:0px;
        left:0px;
        background: #0a70b0;
    }
}
}
.dictionarayValList{
  height:calc(100% - 47px);
   .el-table{
      height:100%!important;
      ::v-deep .el-table__body-wrapper{
        height:calc(100% - 40px);
        overflow-y: auto;
      }
    }
}
.dictionarayClassList{
  height:calc(100% - 90px)!important;
  border-bottom:none!important;
   .el-table{
      height:100%!important;
      ::v-deep .el-table__body-wrapper{
        height:calc(100% - 40px);
        overflow-y: auto;
      }
    }
}
.pagination-container{
  padding: 5px 10px;
  border: 1px solid #ededed;
  border-top:none;
}
</style>
