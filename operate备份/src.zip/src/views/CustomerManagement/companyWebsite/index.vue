<template>
  <div class="interfaceLogCon">
    <!-- <div class="title-bar flex_row">
      <div class="tl flex_1">
        <span class="title-name clr_303"
          ><i class="iconfont icondingwei mr10"></i>接口服务
          <i class="iconfont iconzhankaishouqi"></i>接口日志
          </span
        >
      </div>
    </div> -->
    <div style="height: calc(100vh - 50px); overflow: hidden">
      <iframe
        id="interfaceLogFrame"
        width="100%"
        height="100%"
        :src="frameSrc"
      ></iframe>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      frameSrc: "",
    };
  },

  // 监听,当路由发生变化的时候执行
  watch: {
    $route(to, from) {
      //console.log(to.path);
      this.initFramSrc();
    },
  },
  methods: {
    initFramSrc() {
      let path = this.$route.path;
      let index = path.indexOf("/operate");
      if (index != -1) {
        path = path.replace("/operate", "");
      }
      this.frameSrc = configUrl.frontEndUrl + "/company" + path;
      // this.frameSrc = 'https://dev-portal.mtywcloud.com/company/companyWebsite/companyInfo?isOperate=1'
    },
  },
  created() {
    this.initFramSrc();
  },
  mounted() {},
};
</script>
<style lang="less" scoped>
#interfaceLogFrame {
  border: none;
  .sideBar {
    display: none;
  }
  html,body {
    overflow: hidden!important;
  }
}
</style>