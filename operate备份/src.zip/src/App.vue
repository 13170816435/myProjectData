<template>
  <!-- <div id="app" v-title="{'plateformName': site_name}"> -->
  <div id="app">
    <router-view class="appCon"/>
    <!--如果跳转到 武汉医疗云、武汉中心医院等大屏时 不引入锁屏组件
    （因为武汉医疗云大屏不需要登录 如果引入锁屏组件的话）
     锁屏组件里面会调用接口  报401 导致跳转到登录界面-->
    <!-- <LockPage v-if="isDataCockpitPage"></LockPage> -->



      <!--病例导入--  iselectron 代表是否是云助手环境下--->
      <div class="progressContent" :class="{'activeProgress':caseImportAlertShow}"  v-dragDivLimit>
        <transition name="slide-fade">
         <div
          v-if="caseImportAlertShow"
          class="importOutCaseAlert"
         >
          <div class="caseProgressCon">
            <img class="importImg" src="@/assets/images/dataStorage/importOut.png" alt="">

             <i class="iconfont iconzhengchang finishIcon" v-if="importOutPercentage>=100"></i>
             <span class="progressTit" v-else>病例导出中，请耐心等待…</span>
             <el-progress
                v-if="importOutPercentage<100"
                :percentage="importOutPercentage"
                :format="caseImportFormat"
                class="progressBox mt20 mb20"
                :text-inside="true"
                :stroke-width="18"
              ></el-progress>

              <span v-else class="importOutSucTip mb10">病例导出成功</span>


              <el-button v-if="importOutPercentage<100" class="importOutBtn stopBtn" @click="hideCaseImportOutAlert" type="text">终止导出</el-button>
              <el-button v-else class="importOutBtn closeProgressBtn" @click="hideCaseImportOutAlert" type="text">关闭弹窗</el-button>
          </div>
        </div>
      </transition>
    </div>

  </div>
</template>
<script>
import eventBus from '@/utils/eventBus'
import Messenger from 'tomtaw-messenger';
import Mgr from '@/utils/SecurityService'
import { mapGetters } from 'vuex'
import { getBrowserLogourl } from '@/api/platform_operate/systemset'
import LockPage from '@/components/personCenter/lockPage'
import { getBase64 } from '@/components/commonJs'
import { getThisPlatformName, getScreensaverTime } from '@/api/commonHttp'
import { setTomtawFavicon } from 'tomtaw-favicon';
let messenger = new Messenger('operateMessage', 'medicalNetworkCloud');
export default {
  name: 'app',
  computed: {
    ...mapGetters(['loginTokenInfo','currentPagePath', 'borwserTitObj','lastTime','caseImportAlertShow','importOutProgressCount']),
      // 病例导出
    importOutPercentage() {
      if (this.importOutProgressCount == 0) {
        return 0
      } else {
        // console.log(Math.floor(parseFloat(this.importOutProgressCount)))
        return Math.floor(
          parseFloat(this.importOutProgressCount)
        )
      }
    },
  },
  components: {
    LockPage
  },
  data () {
    return {
      browserLogo: '<%= BASE_URL %>favicon.ico',
      loginInfo: '',
      site_name: '',
      isDataCockpitPage: false,
      openLockScreen: false,
      lockScreenTime: 0,
      msgVoiceTimeout: null,
      checkTimer: null,
    }
  },
  watch: {
    'borwserTitObj': {
      handler(newName, oldName) {
        //this.setBrowserTit()
      },
      deep: true,
    }
  },
  methods: {
    caseImportFormat(percentage) {
      return `${percentage}%`
    },
    hideCaseImportOutAlert() {
      this.$store.commit('caseImport/RESET_IMPORT_OUT_PARAM')
    },
    async getBrowserLogoFuc () {
      const self = this
      await getBrowserLogourl(self.loginInfo.profile.tenancy_id).then((imgFile) => {
        if (imgFile) {
          getBase64(imgFile).then(result => {
            self.browserLogo = result
            self.setBorswerLogo()
          })
        } else {
           self.browserLogo = '<%= BASE_URL %>favicon.ico'
           if (self.loginInfo.profile.tenancy_id !== '0') {
            // 客户没取到 网页图标 就去拿平台运营里面设置的
             self.getOperateBrowserLogo()
           } else {
             self.setBorswerLogo()
           }
        }

      }).catch(error => {
        if (self.loginInfo.profile.tenancy_id !== '0') {
          // 客户没取到 网页图标 就去拿平台运营里面设置的
          self.getOperateBrowserLogo()
        } else {
          self.setBorswerLogo()
        }
      })
    },
    // 拿平台运营里面设置的网页图标
    async getOperateBrowserLogo () {
      const self = this
      await getBrowserLogourl('0').then((imgFile) => {
        if (imgFile) {
          getBase64(imgFile).then(result => {
            self.browserLogo = result
            self.setBorswerLogo()
          })
        } else {
           self.browserLogo = '<%= BASE_URL %>favicon.ico'
           self.setBorswerLogo()
        }

      }).catch(error => {
        // 客户没取到 网页图标 就去拿平台运营里面设置的
        self.setBorswerLogo()
      })
    },
    async getPlatformName () {
      const self = this
      const res = await getThisPlatformName()
      if (res.code === 0) {
        self.site_name = res.data.site_name
      }
    },
    // setBrowserTit() {
    //   if ((this.borwserTitObj.platFormName && this.borwserTitObj.checkMemuname) || (this.borwserTitObj.platFormName && sessionStorage.getItem('checkMemuname'))) {
    //     var checkName = this.borwserTitObj.checkMemuname || sessionStorage.getItem('checkMemuname')
    //     document.title = this.borwserTitObj.platFormName + '-' + checkName
    //   }
    // },
    setBorswerLogo () {
      //window.onload = function () {
        var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
        link.type = 'image/x-icon';
        link.rel = 'shortcut icon';
        link.href = this.browserLogo
        document.getElementsByTagName('head')[0].appendChild(link);
      //}
    },
    async getLockScreeInfo () {
      // 如果停留在屏保时间设置页面  在app.vue里面请求获取屏保信息接口会因重发请求被拦截了)
      // 如果有缓存就读缓存 没有缓存就请求接口
      if (sessionStorage.getItem('screensaverTime')) {
        this.openLockScreen = JSON.parse(sessionStorage.getItem('screensaverState')) // 这里注意不json.pare的会是字符串'false'
        this.lockScreenTime = parseInt(sessionStorage.getItem('screensaverTime'))
        //console.log(this.openLockScreen)
        if (this.openLockScreen) { // 开启了自动锁屏
          clearInterval(this.checkTimer)
          this.checkTimer = setInterval(() => {
            this.checkTimeout()
          }, 3000)
        } else {
          clearInterval(this.checkTimer)
        }
      } else {
        // const res = await getScreensaverTime()
        // if (res.code === 0) {
        //     sessionStorage.setItem('screensaverState', res.data.state)
        //     sessionStorage.setItem('screensaverTime', res.data.time)
        //     this.openLockScreen = res.data.state || false
        //     this.lockScreenTime = parseInt(res.data.time) || 0 // 注意单位是分钟
        //     if (this.openLockScreen) { // 开启了自动锁屏
        //         clearInterval(this.checkTimer)
        //         this.checkTimer = setInterval(() => {
        //           this.checkTimeout()
        //         }, 3000)
        //       } else {
        //         clearInterval(this.checkTimer)
        //     }
        //   } else {
        //     this.$message({ type: 'error',message: res.msg})
        //     this.openLockScreen = false
        //     this.lockScreenTime = 0
        // }
      }

    },
    preventRefresh () {
      const isLockPage = sessionStorage.getItem('isLockPage') === 'true'
      this.$store.dispatch('lockPage/preventRefresh', isLockPage)
    },
    // 检查用户是否过了时间间隔内未操作页面
    checkTimeout () {
      const currentTime = new Date().getTime() // 得到的是ms 所以下面得转成ms
      const timeOut = this.lockScreenTime * 1000 // 设置超时时间: 30分钟 // 间隔时间以crm配置为主，如果配置了就开启自动锁屏未配置就不开启自动锁屏
      console.log(currentTime,this.lastTime)
      console.log("currentTime - this.lastTime", currentTime - this.lastTime)
      console.log("currentTime - this.lastTime >= timeOut",currentTime - this.lastTime >= timeOut)
      if (timeOut && timeOut > 0) {
        if (currentTime - this.lastTime >= timeOut) { // 判断是否超时
          console.log("已经超时了")
          this.$store.dispatch('lockPage/setLock', true)
        }
      }
    },
    handlePage () {
      const lastTime = new Date().getTime()
      this.$store.dispatch('lockPage/refashTime', lastTime)
    },
    initMessenger () {
      // 跨文档通信
      if (window.parent) {
        messenger.addTarget(window.parent, "windowParent");
      }
      messenger.listen((msg) => {
        console.log('子窗口收到消息', msg)
        let obj = JSON.parse(msg)
        if (obj.msgStr === 'backInstitutionList') {
          eventBus.$emit('backInstitutionList')
        }
      });
    },
    senMessenger (obj) {
      if (window.parent) {
        console.log('触发消息', messenger, window.parent)
        messenger.targets["windowParent"].send(JSON.stringify({
          msgStr: obj.msgStr,
          payload: obj.payload
        }))
      }
    }
  },
  created () {
    eventBus.$on('senMessenger', obj => {
      this.senMessenger(obj)
    })
  },
  mounted () {
    this.initMessenger()
    // // 监听界面长时间未操作的事件
    // document.addEventListener('click', () => {
    //   this.handlePage()
    // })
    // document.addEventListener('keydown', () => {
    //   this.handlePage()
    // })
    // document.addEventListener('mousemove', () => {
    //   this.handlePage()
    // })
    // document.addEventListener('mousewheel', () => {
    //   this.handlePage()
    // })
    // const _this = this
    // const lastTime = new Date().getTime()
    // this.$store.dispatch('lockPage/refashTime', lastTime)
    // _this.preventRefresh()
    // const pathname = window.location.pathname
    // // 如果在武汉医疗云 大屏页面 就不获取屏保时间
    // if (pathname.indexOf('customerDataCockpit/index') == -1) {
    //   _this.isDataCockpitPage = true
    //   // 获取锁屏信息
    //   _this.getLockScreeInfo()
    // } else {
    //   _this.isDataCockpitPage = false
    // }


    /**屏保方法处理结束 */
    // 保存当前的系统类型 比如 RIS(放射)
    if (sessionStorage.getItem('lastname') && sessionStorage.getItem('systemArray')) {
      var systemArr = sessionStorage.getItem('systemArray')
      for (var i = 0; i < systemArr.length; i++) {
        if (systemArr[i].id === sessionStorage.getItem('lastname')) {
          sessionStorage.setItem('currentSystemClass', systemArr[i].product_code)
        }
      }
    }
    // 影像存档 ifram嵌套pacs项目，监听连接状态
    var that = this
    window.addEventListener('message', function(result) {
      if (that.currentPagePath !== result.data.currentPage && result.data.currentPage) {
        // 当前页面发生改变 提交commit改变vuex中currentPage
        that.$store.commit('currentPage/SET_CURRENT_PAGE_PATH', result.data.currentPage)
      }
      const key = `oidc.user:${configUrl.crmUrl}:${clientid}`
      if (result.data.removeSession === true && !window.sessionStorage.getItem(key) && (!window.sessionStorage.getItem('ChosedSystemName') && !window.sessionStorage.getItem(('FileName')))) {
        location.reload()
      }
    })


    // var _this = this
    that.$nextTick(() => {
      if (that.loginTokenInfo) {
        // that.loginInfo = JSON.parse(localStorage.getItem('loginInfo'))
        that.loginInfo = JSON.parse(JSON.stringify(that.loginTokenInfo))
        setTomtawFavicon(that.loginInfo);
      } else {
        if (!that.$noNeedLogin) {
          var manager = new Mgr()
          manager.getRole().then(function (item) {
            if (item) {
              that.loginInfo = item
              setTomtawFavicon(item);
              //that.getBrowserLogoFuc()
            }
          })
        }

      }

    })
  },
//  directives: { // 自定义私有指令
//   'title': { // 设置字体粗细的
//       inserted: function (el, binding) {
//         if (this.platFormName && this.checkMemuname) {
//           document.title = this.platFormName + '-' + this.checkMemuname
//         }
//       },
//     },
//   }
}
</script>

<style lang="less">
*{
  box-sizing: border-box;
}
.appCon{
  height:100%;
}
.progressContent {
  position: absolute;
  left:200%;
  transition: all 0.3s;
  cursor: move;
 /***病例导出 进度展示***/
.importOutCaseAlert{
  width: 450px;
  height: 180px;
  background: linear-gradient(0deg, #F3FAFF 1%, #D1ECFF 100%);
  border: 2px solid #FFFFFF;
  box-shadow: 0 4px 24px 0 #0000004d;
  border-radius: 16px;
  .caseProgressCon{
    height: 100%;
    position: relative;
    display: flex;
    flex-flow: column;
    align-items: center;
    justify-content: center;
    .finishIcon{
      font-size: 40px;
      color: #1CB54A;
    }
    .importImg{
      position: absolute;
      top:-20px;
      left:3px;
    }
    .progressTit{
      font-size: 18px;
      color: #303133;
      line-height: 24px;
    }
    .importOutSucTip{
      font-weight: 700;
      font-size: 18px;
      color: #303133;
    }
    .progressBox{
      width: 366px;
      height: 18px;
      background: #B9E1FF;
      border: 1px solid #FFFFFF;
      border-radius: 10px;
      display: flex;
      align-items: center;
    }
    .importOutBtn{
      display: flex;
      align-items: center;
      justify-content: center;
      width: 88px;
      height: 32px;
      line-height: 30px!important;
      border-radius: 16px;
      font-size: 14px;
      color: #FFFFFF;
      cursor: pointer;
    }
    .closeProgressBtn{
      background: #0A70B0;
      border: 1px solid #0A70B0;
    }
    .stopBtn{
      background: #fff;
      border: 1px solid #FF6F6F;
      color:#FF6F6F;
    }
  }
  ::v-deep .el-progress-bar__inner {
    background:#409EFF;
  }
  .el-progress-bar__innerText{
    color:#fff!important;
  }
 }
}
.activeProgress{
  position: absolute;
  left: calc(100% - 470px);
  top: calc(100% - 200px);
  z-index: 1000000;
}
.fade-enter-active, .fade-leave-active { transition: all 0.3s; }
.fade-enter, .fade-leave-to {
  opacity: 0;
  // transform: translateX(460px);
}
</style>
