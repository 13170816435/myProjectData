import request from '@/utils/request'
import qs from 'qs'
const fileName = '/api-operate'
// 机构数据监测接口

// 获取科室
export function getObservationsOffice (data) {
  return request({
    url: fileName + '/cloud-observations/office',
    method: 'get',
    params: data
  })
}
// 获取机构当天的数据
export function getInstituteData (data) {
  return request({
    url: fileName + '/cloud-observations/statistic',
    method: 'get',
    params: data
  })
}
// 根据机构运行详情
export function getServiceRunDetail (data) {
  return request({
    url: fileName + '/cloud-observations/service-run/detail',
    method: 'get',
    params: data
  })
}
// 获取异常日志列表 --分页
export function getServiceRunList (data) {
  return request({
    url: fileName + '/cloud-observations/service-run/pagination',
    method: 'get',
    params: data
  })
}
// 获取大屏标题
export function getPageTitle (data) {
  return request({
    url: fileName + '/cloud-observations/service-run/pagination',
    method: 'get',
    params: data
  })
}
// 修改大屏页面标题
export function updatePageTitle(data){
  return request({
    url:  fileName + '/cloud-observations/settings',
    method: 'POST',
    data: data
  })
}
// 客户数据监测接口
// 获取机构
export function getInstituteList (data) {
  return request({
    url: fileName + '/cloud-observations/institution',
    method: 'get',
    params: data
  })
}
// 平台数据监测接口
// 获取所有的租户
export function getTenancyList (data) {
  return request({
    url: fileName + '/cloud-observations/tenancy',
    method: 'get',
    params: data
  })
}
// 云朵数据监测接口
// 获取云朵列表
export function getCloudList (data) {
  return request({
    url: fileName + '/cloud-observations/cloud',
    method: 'get',
    params: data
  })
}
// 未采集到数据的机构明细
export function getInstitutionArchiveTime (data) {
  return request({
    url: fileName + '/cloud-observations/institution-archive-time',
    method: 'get',
    params: data
  })
}
// 根据云朵与机构等级类型分组机构归档时间统计
export function getStatistical (data) {
  return request({
    url: fileName + '/cloud-observations/archive-time-group-statistical',
    method: 'get',
    params: data
  })
}