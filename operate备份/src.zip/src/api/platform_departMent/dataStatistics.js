import request from '@/utils/request'
import qs from 'qs'
// const barse = 'http://192.168.1.173:9013'
const barse = ''
const RoutBaseUrl = '/api-datamining'
// 远程会诊统计
// 导出会诊列表
export function importConsultList(data, token, SystemId) {
  return request({
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded', // 请求的数据类型为form data格式
      'Authorization': token,
      'SystemId': SystemId
    },
    responseType: 'blob',
    url: RoutBaseUrl + '/consult/export',
    method: 'GET',
    params: data
  })
}

// 会诊工作量
export function getAggreateList(data) {
  return request({
    url: RoutBaseUrl + '/consult/aggreate',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

export const getConsultDetailForDoctor = params => request({
  url: `${RoutBaseUrl}/consult/aggreate/details`,
  params,
  paramsSerializer: data => qs.stringify(data, {indices: false})
})

// 会诊申请量
export function getApplyAggreateList(data) {
  return request({
    url: RoutBaseUrl + '/consult/application-aggreate',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

export const getApplyAggreateListExt = params => request({
  url: `${RoutBaseUrl}/consult/application-aggreate-ext`,
  params,
  paramsSerializer: data => qs.stringify(data, {indices: false})
})

// 会诊申请量明细
export const getApplyAggreateExtDetails = params => request({
  url: `${RoutBaseUrl}/consult/application-aggreate-ext/details`,
  params,
  paramsSerializer: data => qs.stringify(data, {indices: false})
})

// 获取医院机构
export function getHospitalInstitution(data) {
  return request({
    url: barse + RoutBaseUrl + '/pacs/orgs',
    method: 'GET',
    params: data
  })
}

// 获取医生
export function getDoctors(data) {
  return request({
    url: barse + RoutBaseUrl + '/pacs/doctors',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取申请科室
export function getApplyOffice(data) {
  return request({
    url: RoutBaseUrl + '/pacs/application-depts',
    method: 'GET',
    params: data
  })
}

// 获取检查类型
export function getExamtypes() {
  return request({
    url: RoutBaseUrl + '/pacs/examtypes',
    method: 'GET',
    // params: data
  })
}

/**
 * 获取检查项目
 * @param {*} data 查询参数，可以传入检查部位{categories:[]}进行过滤
 * @returns
 */
export function getExamItems(data) {
  let query = ''
  if (data && data.categories && data.categories.length) {
    query = '?' + data.categories.map(e => `categories=${e}`).join('&')
  }
  return request({
    url: RoutBaseUrl + '/pacs/exam-item-defines' + query,
    method: 'GET'
  })
}

/**
 * 获取患者类别
 * @returns 患者列表查询结果
 */
export function getPatientClasses() {
  return request({
    url: RoutBaseUrl + '/pacs/patient-classes',
    method: 'GET'
  })
}

// 工作量汇总列表
export function getWorkLoadList(data) {
  return request({
    url: RoutBaseUrl + '/pacs/eworksummary-aggreate',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 工作量汇总明细列表
export function fetchWorkloadSummaryDetails(data) {
  return request({
    url: RoutBaseUrl + '/pacs/workload-summary-details',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取检查申请量 列表
export function getCheckApplicationList(data) {
  return request({
    url: RoutBaseUrl + '/pacs/application-aggreate',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取登记工作量 列表
export function getRegisterList(data) {
  return request({
    url: RoutBaseUrl + '/pacs/register-aggreate',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取检查工作量
export function getExamAggreateList(data) {
  return request({
    url: RoutBaseUrl + '/pacs/exam-aggreate',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

/**
 * 设备工作量
 * @param {*} data
 * @returns
 */
export function fetchArmariumWorkloadSummary(data) {
  return request({
    url: RoutBaseUrl + '/pacs/armarium-workload',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取诊断工作量统计
export function getDiagnosisAggreateList(data) {
  return request({
    url: RoutBaseUrl + '/pacs/diagnosis-aggreate',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取报告阳性率
export function getPositiveAggreateList(data) {
  return request({
    url: RoutBaseUrl + '/pacs/positive-aggreate',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取检查阴阳性
export function getObservationPositiveRate(data) {
  return request({
    url: RoutBaseUrl + '/pacs/observation-positive-rate',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取检查阴阳性
export function fetchObservationPositiveDetails(data) {
  return request({
    url: RoutBaseUrl + '/pacs/observation-positive-details',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 导出检查列表
export function importCheckApplicationList(data) {
  return request({
    url: RoutBaseUrl + '/pacs/application-export',
    method: 'GET',
    params: data
  })
}

// 诊断符合率
export function getDiagnosticAccordanceRate(data) {
  return request({
    url: RoutBaseUrl + '/pacs/diagnostic-accordance-rate',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 诊断及时率
export function getDiagnosticTimelinessRate(data) {
  return request({
    url: RoutBaseUrl + '/pacs/diagnostic-timeliness-rate',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 检查费用统计
export function fetchObservationChargeSummary(data) {
  return request({
    url: RoutBaseUrl + '/pacs/observation-charges-summary',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 检查费用明细
export function fetchObservationChargeDetails(data) {
  return request({
    url: RoutBaseUrl + '/pacs/observation-charges-details',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

/**
 * 获取部位统计数据
 * @param {*} data
 * @returns
 */
export function getAreaExaminations(data) {
  return request({
    url: RoutBaseUrl + '/pacs/area-examinations',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

/**
 * 获取检查机房
 * @returns
 */
export function getObservationRooms() {
  return request({
    url: RoutBaseUrl + '/pacs/observation-rooms',
    method: 'GET'
  })
}

/**
 * 获取检查设备
 * @param {*} data 查询参数，可以传入检查机房{room_ids:[]}进行过滤
 * @returns
 */
export function getObservationEquipments(data) {
  let query = ''
  if (data && data.room_ids && data.room_ids.length) {
    query = '?' + data.room_ids.map(e => `room_ids=${e}`).join('&')
  }
  return request({
    url: RoutBaseUrl + '/pacs/observation-equipments' + query,
    method: 'GET'
  })
}
