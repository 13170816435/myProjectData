import request from '@/utils/request'
import qs from 'qs'
// const barse = 'http://192.168.1.207:9020'
const RoutBaseUrl = '/api-cloudpacs'

// 检查类型列表 /DataDicDefine
export function getCheckType (data) {
  return request({
    url: RoutBaseUrl + '/Config/DicDefine',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 书写模版分类列表
// 获取列表
export function WritingTemplateCategory (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTempCategory',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 新增-模版-分类
export function AddWritingTemplate (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTempCategory',
    method: 'post',
    data: data
    // baseURL: barse
  })
}
// 修改-模版-分类
export function ModifyWritingTemplate (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTempCategory',
    method: 'put',
    data: data
    // baseURL: barse
  })
}
// 删除-模版-分类（单个）
export function DeleteWritingTemplate (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTempCategory/' + data.id,
    method: 'DELETE'
    // params: data
    // baseURL: barse
  })
}
// 模版表格-分页
export function PageWritingTemplate (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTemp/Page',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 单个模版详情
export function getSigleTemplateDatail (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTemp',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 新增书写模版
export function AddSingleTemplate (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTemp',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改书写模版
export function ModifySingleTemplate (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTemp',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}
// 删除书写模版（多个）
export function DeleteSingleOrMoreTemplate (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTemp',
    method: 'DELETE',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
    // baseURL: barse
  })
}
// 获取公共转成个人模版列表
export function FetchConvertTree (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTemp/ConvertTree',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 公共转个人
export function CommonChangePersonel (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTemp/Convert',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 批量导入模版
export function BatchImportConvertTree (data) {
  return request({
    url: RoutBaseUrl + '/Config/WriteTemp/BatchImport',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 获取-常用词库分类-Tree列表
export function FetchThesaurusCategoryTree (data) {
  return request({
    url: RoutBaseUrl + '/Config/UsePhraseCategory',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 新增-词库分类
export function AddThesaurusCategory (data) {
  return request({
    url: RoutBaseUrl + '/Config​/UsePhraseCategory',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改-词库分类
export function ModifyThesaurusCategory (data) {
  return request({
    url: RoutBaseUrl + '/Config/UsePhraseCategory',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}
// 删除-词库分类（单个）
export function DeleteThesaurusCategory (data) {
  return request({
    url: RoutBaseUrl + '/Config​/UsePhraseCategory/' + data.id,
    method: 'DELETE'
    // params: data
    // baseURL: barse
  })
}
// 获取-常用词库分页-列表
export function FetchThesaurusTable (data) {
  return request({
    url: RoutBaseUrl + '/Config/UsePhrase',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 新增-常用词库
export function AddThesaurusItem (data) {
  return request({
    url: RoutBaseUrl + '/Config/UsePhrase',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改-常用词库
export function ModifyThesaurusItem (data) {
  return request({
    url: RoutBaseUrl + '/Config/UsePhrase',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}
// 删除-常用词库（多个）
export function DeleteSingleOrMoreThesaurus (data) {
  return request({
    url: RoutBaseUrl + '/Config/UsePhrase',
    method: 'DELETE',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
    // baseURL: barse
  })
}
// 综合查询
export function ComprehensiveQuery (data) {
  return request({
    url: RoutBaseUrl + '/Composite/Query',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 获取检查信息
export function fetchExamsDetail (data) {
  return request({
    url: RoutBaseUrl + '/Composite/Exams/' + data.id,
    method: 'get'
    // params: data
    // baseURL: barse
  })
}
