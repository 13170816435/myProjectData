import request from '@/utils/request'
import qs from 'qs'
const RoutBaseUrl = '/api-cloudpacs'
// 获取洗消记录列表
// /api/Perform/Endoscopes/Cleaning/List
export function CleaningList (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Endoscopes/Cleaning/List',
    method: 'GET',
    params: data
  })
}
// 导出洗消记录
export function CleaningExportList (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Endoscopes/Cleaning/ExportList',
    method: 'GET',
    params: data
  })
}
// 获取洗消记录图表数据
export function CleaningCount (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Endoscopes/Cleaning/Count',
    method: 'GET',
    params: data
  })
}
// 基础配置接口
export function DicDefineAll (data) {
  return request({
    url: RoutBaseUrl + '/Config/DicDefine/Multiple',
    method: 'GET',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 项目分类
export function getClassify (data) {
  return request({
    url: RoutBaseUrl + '/Config/ExamItemCategory',
    method: 'GET',
    params: data
  })
}

// 自定义列
export function getColumnCustom (data) {
  return request({
    url: RoutBaseUrl + '/Config/ColumnCustom',
    method: 'GET',
    params: data
  })
}