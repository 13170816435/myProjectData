import request from '@/utils/request'
import qs from 'qs'
const RoutBaseUrl = '/api-cloudpacs'
// 获取字典分类列表
export function getDictTypeList (data) {
  return request({
    url: RoutBaseUrl + '/Config/DicType',
    method: 'GET',
    params: data
  })
}
// 删除 某个字典分类
export function DeleteThisType (data) {
  return request({
    url: RoutBaseUrl + `/Config/DicType/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 新增字典分类
export function beganAddDictType (data) {
  return request({
    url: RoutBaseUrl + '/Config/DicType',
    method: 'post',
    data: data
  })
}
// 新增字典信息
export function beganAddDictInfor (data) {
  return request({
    url: RoutBaseUrl + '/Config/DicDefine',
    method: 'post',
    data: data
  })
}
// 获取字典信息列表
export function getDictInforList (data) {
  return request({
    url: RoutBaseUrl + '/Config/DicDefine',
    method: 'GET',
    params: data
  })
}
// 删除 某个字典信息
export function DeleteThisDictInfor (data) {
  return request({
    url: RoutBaseUrl + `/Config/DicDefine/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 编辑字典类型
export function updateThisType (data) {
  return request({
    url: RoutBaseUrl + '/Config/DicType',
    method: 'put',
    data: data
  })
}
// 编辑字典信息
export function updateDictInfor (data) {
  return request({
    url: RoutBaseUrl + '/Config/DicDefine',
    method: 'put',
    data: data
  })
}


/**
 * 字典排序
 * @param data
 * @returns {*}
 */
export const sortDicOrder = data => request({
  url: `${RoutBaseUrl}/Config/DicDefine/DragSort`,
  method: 'put',
  data
})
