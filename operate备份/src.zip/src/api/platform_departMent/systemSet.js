import request from '@/utils/request'
import qs from 'qs'

const RoutBaseUrl = '/api-cloudpacs'
const medRoutBaseUrl = '/api-telemed'


// 获取设备状态
export function getDeviceStatus(data) {
  return request({
    url: RoutBaseUrl + '/Config/Enum',
    method: 'GET',
    params: data
  })
}

// 获取检查类型
export function getInspectClass(data) {
  return request({
    url: RoutBaseUrl + '/Config/DicDefine',
    method: 'GET',
    params: data
  })
}

// 获取检查设备列表 (分页)
export function getDeviceList(data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseEquipment/Page',
    method: 'GET',
    params: data
  })
}

// 获取检查设备列表 (不分页)
export function getAllDevice(data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseEquipment',
    method: 'GET',
    params: data
  })
}

// 新增设备
export function beganAddDevice(data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseEquipment',
    method: 'post',
    data: data
  })
}

// 获取维保记录(分页)
export function getMaintenanceRecordList(data) {
  return request({
    url: RoutBaseUrl + '/Config/MaintenanceRecord',
    method: 'GET',
    params: data
  })
}

// 新增维保记录
export function beganAddMaintenanceRecord(data) {
  return request({
    url: RoutBaseUrl + '/Config/MaintenanceRecord',
    method: 'post',
    data: data
  })
}

// 编辑维保记录
export function updateMaintenanceRecord(data) {
  return request({
    url: RoutBaseUrl + '/Config/MaintenanceRecord',
    method: 'put',
    data: data
  })
}

// 删除维保记录
export function deleteMaintenanceRecord(data) {
  return request({
    url: RoutBaseUrl + `/Config/MaintenanceRecord/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取放置机房
export function getObservationRoom(data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseRoom',
    method: 'GET',
    params: data
  })
}

// 编辑设备
export function updateDevice(data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseEquipment',
    method: 'put',
    data: data
  })
}

// 删除设备
export function deleteDevice(data) {
  return request({
    url: RoutBaseUrl + `/Config/ObseEquipment/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 修改检查设备状态
export function updateDeviceStu(data) {
  return request({
    url: RoutBaseUrl + `/Config/ObseEquipment/${data.id}`,
    method: 'PATCH',
    params: data
  })
}

// 项目分类【获取列表】
export function getExamItemCategory(data) {
  return request({
    url: RoutBaseUrl + '/Config/ExamItemCategory',
    method: 'GET',
    params: data,
    paramsSerializer: data => qs.stringify(data, {indices: false})
  })
}

// 项目分类--检查项目
export function getExamItem(data) {
  return request({
    url: RoutBaseUrl + '/Config/ExamItem',
    method: 'GET',
    params: data,
    paramsSerializer: data => qs.stringify(data, {indices: false})
  })
}

// 新增项目分类
export function addExamItemCategory(data) {
  return request({
    url: RoutBaseUrl + '/Config/ExamItemCategory',
    method: 'post',
    data: data
  })
}

// 删除项目分类
export function deleteExamItemCategory(data) {
  return request({
    url: RoutBaseUrl + `/Config/ExamItemCategory/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => qs.stringify(data, {indices: false})
  })
}

// 编辑分类
export function readyUpdateExamItemCategory(data) {
  return request({
    url: RoutBaseUrl + '/Config/ExamItemCategory',
    method: 'put',
    data: data
  })
}

// 获取RUV系数
export function getRvuList(data) {
  return request({
    url: RoutBaseUrl + '/Config/RvuDefine',
    method: 'GET',
    params: data
  })
}

// 获取检查设备(不分页)
export function getMyDevice(data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseEquipment',
    method: 'GET',
    params: data
  })
}

// 获取检查项目列表
export function getExamItemList(data) {
  return request({
    url: RoutBaseUrl + '/Config/ExamItem/IncludeAttr',
    method: 'GET',
    params: data
  })
}

// 新增检查项目
export function addExamItem(data) {
  return request({
    url: RoutBaseUrl + '/Config/ExamItem',
    method: 'post',
    data: data
  })
}

// 删除检查项目
export function deleteThisExamItem(data) {
  return request({
    url: RoutBaseUrl + `/Config/ExamItem/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 编辑检查项目
export function readyUpdateExamItem(data) {
  return request({
    url: RoutBaseUrl + '/Config/ExamItem',
    method: 'put',
    data: data
  })
}

// 新增Ruv
export function addRvu(data) {
  return request({
    url: RoutBaseUrl + '/Config/RvuDefine',
    method: 'post',
    data: data
  })
}

// 删除Rvu
export function deleteRvu(data) {
  return request({
    url: RoutBaseUrl + `/Config/RvuDefine/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取检查机房列表(不分页)
export function getAllInspectRoom(data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseRoom',
    method: 'GET',
    params: data
  })
}

// 获取检查机房列表(分页)
export function getInspectRoomList(data) {
  var newUrl = RoutBaseUrl + '/Config/ObseRoom/Page?' + 'RoomName=' + data.RoomName + '&PageIndex=' + data.PageIndex + '&PageSize=' + data.PageSize
  if (data.OrganizationId.length !== 0) {
    var organizeIdStr = '&OrganizationId='
    data.OrganizationId.forEach(function (val) {
      newUrl = newUrl + organizeIdStr + val
    })
  }
  return request({
    url: newUrl,
    method: 'GET'
    // params: data
  })
}

// 新增检查机房
export function addInspectRoom(data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseRoom',
    method: 'post',
    data: data
  })
}

//
export function getRoomMaxSort() {
  return request({
    url: RoutBaseUrl + '/Config/ObseRoom/MaxSort',
    method: 'GET'
  })
}

// 修改检查机房
export function updateInspectRoom(data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseRoom',
    method: 'put',
    data: data
  })
}

// 删除检查机房
export function deleteInspectRoom(data) {
  return request({
    url: RoutBaseUrl + `/Config/ObseRoom/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 检查机房(恢复)
export function enableInspectRoom(data) {
  return request({
    url: RoutBaseUrl + `/Config/ObseRoom/${data.id}/Normal`,
    method: 'PATCH',
    data: data
  })
}

// 检查机房(禁用)
export function stopInspectRoom(data) {
  return request({
    url: RoutBaseUrl + `/Config/ObseRoom/${data.id}/Stop`,
    method: 'PATCH',
    data: data
  })
}

// 获取检查机房的位置
export function getInspectRoomLocation(data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseRoom/Location',
    method: 'GET',
    params: data
  })
}

// 书写模板分类
export function getWriteTempCategory(data) {
  return request({
    url: medRoutBaseUrl + '/WriteTemplates/WriteTempCategory',
    method: 'GET',
    params: data
  })
}

// 新增模板分类
export function addWriteTempCategory(data) {
  return request({
    url: medRoutBaseUrl + '/WriteTemplates/WriteTempCategory',
    method: 'post',
    data: data
  })
}

// 修改模板分类
export function updateWriteTempCategory(data) {
  return request({
    url: medRoutBaseUrl + '/WriteTemplates/WriteTempCategory',
    method: 'put',
    data: data
  })
}

// 书写模版分类【获取列表（包含模板）】
export function getAllWriteTempCategory(data) {
  return request({
    url: RoutBaseUrl + '​/Config​/WriteTempCategory​/IncludeTemp',
    method: 'GET',
    params: data
  })
}

// 书写模版分类【删除】
export function deleteWriteTempCategory(data) {
  return request({
    url: medRoutBaseUrl + `/WriteTemplates/WriteTempCategory/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 书写模板分类拖拽
export function drageTree(data) {
  return request({
    url: medRoutBaseUrl + '/WriteTemplates/WriteTempCategory/DragSort',
    method: 'put',
    data: data
  })
}

// 书写模板拖拽排序
export const dragAndSortTemp = data => request({
  url: `${medRoutBaseUrl}/WriteTemplates/WriteTemp/DragSort`,
  method: 'put',
  data
})

// 书写模版【获取分页列表】
export function getWriteTempList(data) {
  return request({
    url: medRoutBaseUrl + '/WriteTemplates/WriteTemp/Page',
    method: 'GET',
    params: data
  })
}

// 书写模版【获取详情】
export function getWriteTempDetail(data) {
  return request({
    url: medRoutBaseUrl + `/WriteTemplates/WriteTemp​/${data.id}`,
    method: 'GET',
    params: data
  })
}

// 书写模板的新增
export function addWriteTemp(data) {
  return request({
    url: medRoutBaseUrl + '/WriteTemplates/WriteTemp',
    method: 'post',
    data: data
  })
}

// 修改书写模板
export function updateWriteTemp(data) {
  return request({
    url: medRoutBaseUrl + '/WriteTemplates/WriteTemp',
    method: 'put',
    data: data
  })
}

// 书写模版【删除】
export function deleteWriteTemp(data) {
  return request({
    url: medRoutBaseUrl + '/WriteTemplates/WriteTemp',
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 打印模版【获取模版类型】
export function getPrintTempType(data) {
  return request({
    url: RoutBaseUrl + '/Config/PrintTemp/Type',
    method: 'GET',
    params: data
  })
}

// 打印模版(分页)
export function getPrintTempTypeList(data) {
  return request({
    url: RoutBaseUrl + '/Config/PrintTemp',
    method: 'GET',
    params: data
  })
}

// 新增打印模板
export function addPrintTemp(data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: RoutBaseUrl + '/Config/PrintTemp',
    method: 'post',
    data: data
  })
}

// 修改打印模板
export function updatePrintTemp(data) {
  return request({
    url: RoutBaseUrl + '/Config/PrintTemp',
    method: 'put',
    data: data
  })
}

// 下载打印模板
export function downLoadPrintTempType(data) {
  return request({
    url: RoutBaseUrl + `/Config/PrintTemp/${data.id}/Download`,
    method: 'GET',
    params: data
  })
}

// 打印模版【删除】
export function deletePrintTemp(data) {
  return request({
    url: RoutBaseUrl + `/Config/PrintTemp/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 打印模版 文件【删除】
export function deletePrintTempFile(data) {
  return request({
    url: RoutBaseUrl + `/Config/PrintTemp/${data.id}/Content`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取模板字段
export function getTemplateFields(data) {
  return request({
    url: RoutBaseUrl + '/Composite/Prints/Fields',
    method: 'GET',
    params: data
  })
}

// 获取患者类型 (就诊类别)
export function getPatientType(data) {
  return request({
    url: RoutBaseUrl + `/Config/PrintTemp/${data.id}/Download`,
    method: 'GET',
    params: data
  })
}

/** 样图管理 */
// 新增样图
export function addOrganDrawing(data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: RoutBaseUrl + '/Config/OrganDrawing',
    method: 'post',
    data: data
  })
}

// 修改样图
export function updateOrganDrawing(data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: RoutBaseUrl + '/Config/OrganDrawing',
    method: 'put',
    data: data
  })
}

// 获取样图列表(分页)
export function getOrganDrawingList(data) {
  return request({
    url: RoutBaseUrl + '/Config/OrganDrawing/Page',
    method: 'GET',
    params: data
  })
}

// 删除样图
export function deleteOrganDrawing(data) {
  return request({
    url: RoutBaseUrl + `/Config/OrganDrawing/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 样图管理(图片上传)
export function uploadOrganDrawingPicture(data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: RoutBaseUrl + `/Config/OrganDrawing/${data.id}/picture`,
    method: 'post',
    data: data
  })
}

// 删除样图图片
export function deleteOrganDrawingPicture(data) {
  return request({
    url: RoutBaseUrl + `/Config/OrganDrawing/${data.id}/picture`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取样图标记
export function getOrganDrawingMarkCode(data) {
  return request({
    url: RoutBaseUrl + '/Config/OrganDrawingMark/Code',
    method: 'GET',
    params: data
  })
}

// 获取样图标记列表
export function getOrganDrawingMarkList(data) {
  return request({
    url: RoutBaseUrl + '/Config/OrganDrawingMark',
    method: 'GET',
    params: data
  })
}

// 新增样图标记
export function addOrganDrawingMark(data) {
  return request({
    url: RoutBaseUrl + '/Config/OrganDrawingMark',
    method: 'post',
    data: data
  })
}

// 修改样图标记
export function updateOrganDrawingMark(data) {
  return request({
    url: RoutBaseUrl + '/Config/OrganDrawingMark',
    method: 'put',
    data: data
  })
}

// 删除样图标记
export function deleteOrganDrawingMark(data) {
  return request({
    url: RoutBaseUrl + `/Config/OrganDrawingMark/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取测值绑定【获取分页列表】
export function getMeasureBindList(data) {
  return request({
    url: RoutBaseUrl + '/Config/MeasureBind/Page',
    method: 'GET',
    params: data
  })
}

// 新增测值绑定
export function addMeasureBind(data) {
  return request({
    url: RoutBaseUrl + '/Config/MeasureBind',
    method: 'post',
    data: data
  })
}

// 修改测值绑定
export function updateMeasureBind(data) {
  return request({
    url: RoutBaseUrl + '/Config/MeasureBind',
    method: 'put',
    data: data
  })
}

// 删除测值绑定
export function deleteMeasureBind(data) {
  return request({
    url: RoutBaseUrl + `/Config/MeasureBind/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取测值配置【获取分页列表】
export function getMeasureItemList(data) {
  return request({
    url: RoutBaseUrl + '/Config/MeasureItem/Page',
    method: 'GET',
    params: data
  })
}

// 测值配置【获取测值项目】
export function getMeasureItemProject(data) {
  return request({
    url: RoutBaseUrl + '/Config/MeasureItem',
    method: 'GET',
    params: data
  })
}

// 修改测值配置
export function updateMeasureItem(data) {
  return request({
    url: RoutBaseUrl + '/Config/MeasureItem',
    method: 'put',
    data: data
  })
}

// 编码规则 (获取列表)
export function getEncodeRuleList(data) {
  return request({
    url: RoutBaseUrl + '/Config/Numbering',
    method: 'GET',
    params: data
  })
}

// 修改编码规则
export function updateEncodeRule(data) {
  return request({
    url: RoutBaseUrl + '/Config/Numbering',
    method: 'post',
    data: data
  })
}

// 修改编码规则
export function getEncodeForbidden(data) {
  return request({
    url: RoutBaseUrl + '/Config/Numbering/Forbidden',
    method: 'GET',
    params: data
  })
}

// 系统设置--心电轴配置--------------------------------------------------------------------------------------
// 心电轴配置列表
export function getEcgShaftList() {
  return request({
    url: RoutBaseUrl + '/Config/MeasureThresholdAxis',
    method: 'GET'
  })
}

// 验证心电轴配置是否存在
export function checkEcgShaftIsExist() {
  return request({
    url: RoutBaseUrl + '/Config/MeasureThreshold/IsExist',
    method: 'GET'
  })
}

// 更新心电轴,配置（修改）
export function putMeasureThreshold(params) {
  return request({
    url: RoutBaseUrl + '/Config/MeasureThreshold',
    method: 'POST',
    data: params
  })
}

// 恢复默认测值，心电轴配置 /api/Config/MeasureThreshold/Reset
export function putMeasureThresholdReset(type) {
  return request({
    url: RoutBaseUrl + '/Config/MeasureThreshold/Reset?type=' + type,
    method: 'PUT'
  })
}

// 获取测量值配置列表
export function getMeasureThresholdList() {
  return request({
    url: RoutBaseUrl + '/Config/MeasureThreshold',
    method: 'GET'
  })
}

// 删除测量值配置
export function delMeasureThreshold(params) {
  return request({
    url: RoutBaseUrl + '/Config/MeasureThreshold' + params,
    method: 'DELETE'
  })
}

// 系统设置-- 质控管理--------------------------------------------------------------------------------
// 获取质控评分模板分页列表
export function getQCManageList(params) {
  return request({
    url: RoutBaseUrl + '/Config/PacsQcScoreTemplate/Page',
    method: 'GET',
    params: params
  })
}

// 获取质控评分模板列表 - 不分页
export function getQcScoreTemplate(params) {
  return request({
    url: RoutBaseUrl + '/Config/PacsQcScoreTemplate',
    method: 'GET',
    params: params
  })
}

// 新增质控评分模板
export function addQCManageInfo(params) {
  return request({
    url: RoutBaseUrl + '/Config/PacsQcScoreTemplate',
    method: 'POST',
    data: params
  })
}

// 修改质控评分模板
export function putQCManageInfo(params) {
  return request({
    url: RoutBaseUrl + '/Config/PacsQcScoreTemplate',
    method: 'PUT',
    data: params
  })
}

// 删除质控评分模板
export function delQCManageInfo(id) {
  return request({
    url: RoutBaseUrl + `/Config/PacsQcScoreTemplate/${id}`,
    method: 'DELETE'
  })
}

// 获取质控评分模板 明细 分页列表
export function getQCManageItemsList(params) {
  return request({
    url: RoutBaseUrl + '/Config/QcScoreTemplateItems/Page' + (params ? params : ''),
    method: 'GET'
  })
}

// 新增质控评分 明细 模板
export function addQCManageItemInfo(params) {
  return request({
    url: RoutBaseUrl + '/Config/QcScoreTemplateItems',
    method: 'POST',
    data: params
  })
}

// 修改质控评分 明细 模板
export function putQCManageItemInfo(params) {
  return request({
    url: RoutBaseUrl + '/Config/QcScoreTemplateItems',
    method: 'PUT',
    data: params
  })
}

// 删除质控评分 明细 模板
export function delQCManageItemInfo(id) {
  return request({
    url: RoutBaseUrl + `/Config/QcScoreTemplateItems/${id}`,
    method: 'DELETE'
  })
}

// 质控评分标准项分组-查询
export function getQcScoreStandardCategory(params) {
  return request({
    url: RoutBaseUrl + `/Config/QcScoreStandardCategory`,
    method: 'GET',
    params: params
  })
}

// 质控评分标准项分组-新增
export function postQcScoreStandardCategory(params) {
  return request({
    url: RoutBaseUrl + `/Config/QcScoreStandardCategory`,
    method: 'POST',
    data: params
  })
}

// 质控评分标准项分组-修改
export function putQcScoreStandardCategory(params) {
  return request({
    url: RoutBaseUrl + `/Config/QcScoreStandardCategory`,
    method: 'PUT',
    data: params
  })
}

// 质控评分标准项分组-删除
export function delQcScoreStandardCategory(id) {
  return request({
    url: RoutBaseUrl + `/Config/QcScoreStandardCategory/${id}`,
    method: 'DELETE',
  })
}

// 质控评分标准项-查询
export function getQcScoreStandardItem(params) {
  return request({
    url: RoutBaseUrl + `/Config/QcScoreStandardItem`,
    method: 'GET',
    params: params
  })
}

// 质控评分标准项-新增
export function postQcScoreStandardItem(params) {
  return request({
    url: RoutBaseUrl + `/Config/QcScoreStandardItem`,
    method: 'POST',
    data: params
  })
}

// 质控评分标准项-修改
export function putQcScoreStandardItem(params) {
  return request({
    url: RoutBaseUrl + `/Config/QcScoreStandardItem`,
    method: 'PUT',
    data: params
  })
}

// 质控评分标准项-删除
export function delQcScoreStandardItem(id) {
  return request({
    url: RoutBaseUrl + `/Config/QcScoreStandardItem/${id}`,
    method: 'DELETE',
  })
}

// 质控评分模板【禁用】
export function putQcScoreTemplateForbidden(params) {
  return request({
    url: RoutBaseUrl + `/Config/PacsQcScoreTemplateForbidden`,
    method: 'PUT',
    data: params
  })
}

// 质控评分模板【禁用】
export function getPacsIsApplyAsync(id) {
  return request({
    url: RoutBaseUrl + `/Config/PacsIsApplyAsync/${id}`,
    method: 'GET'
  })
}

/**
 * 获取结构化模板数据绑定字段
 * @param {*} productCode 当前授权系统代码
 * @returns
 */
export async function fetchStructureTemplateMembers(productCode) {
  // sourceSystem=900 云PACS
  const rs = await request({
    url: `/api-structure/eworldstructure/structure-template-fields?sourceSystem=900&productCode=${productCode}`,
    method: 'GET'
  })

  if (rs.code !== 0) {
    return Promise.resolve([])
  }

  const namespace = rs.data.node_code

  const members = []
  var metadata = rs.data.node_data
  Object.keys(metadata).forEach(key => {
    metadata[key].forEach(member => {
      members.push({
        name: `${namespace}.${member.field_code}`,
        displayName: member.field_name
      })
    })
  })

  return Promise.resolve(members)
}

// 危急值定义【获取分页列表】
export function getDCVList(params) {
  return request({
    headers: {
      DiagnosisMode: 'RemoteDiagnosis'
    },
    url: RoutBaseUrl + '/Config/CriticalValueDefine/Page',
    method: 'GET',
    params: params
  })
}

// 危急值定义【新增】
export function addDCV(params) {
  return request({
    headers: {
      DiagnosisMode: 'RemoteDiagnosis'
    },
    url: RoutBaseUrl + '/Config/CriticalValueDefine',
    method: 'POST',
    data: params
  })
}

// 危急值定义【修改】
export function editDCV(params) {
  return request({
    headers: {
      DiagnosisMode: 'RemoteDiagnosis'
    },
    url: RoutBaseUrl + '/Config/CriticalValueDefine',
    method: 'PUT',
    data: params
  })
}

// 危急值定义【删除】
export function delDCV(id) {
  return request({
    headers: {
      DiagnosisMode: 'RemoteDiagnosis'
    },
    url: RoutBaseUrl + `/Config/CriticalValueDefine/${id}`,
    method: 'DELETE'
  })
}

// 质控评分标准项【拖拽排序】
export function QcScoreStandardItemSort(params) {
  return request({
    url: RoutBaseUrl + `/Config/QcScoreStandardItem/DragSort`,
    method: 'PUT',
    data: params
  })
}

// 质控评分标准项分组【类型拖拽排序】
export function QcScoreStandardCategorySort(params) {
  return request({
    url: RoutBaseUrl + `/Config/QcScoreStandardCategory/DragSort`,
    method: 'PUT',
    data: params
  })
}


/**
 * 批量移动书写模板
 * @param data
 * @returns {*}
 */
export const moveWriteTemps = data => {
  return request({
    url: medRoutBaseUrl + '/WriteTemplates/WriteTemp/Movement',
    method: 'post',
    data,
    paramsSerializer: data => qs.stringify(data, {indices: false})
  })
}
