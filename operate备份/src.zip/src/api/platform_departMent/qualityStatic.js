import request from '@/utils/request'
import qs from 'qs'
const barse = ''
const RoutBaseUrl = '/api-datamining'
// 获取医院机构
export function getInstitution (data) {
  return request({
    url: barse + RoutBaseUrl + '/pacs/application-orgs',
    method: 'GET',
    params: data
  })
}
// 获取检查类型
export function getExamtypes () {
  return request({
    url: RoutBaseUrl + '/pacs/examtypes',
    method: 'GET',
    // params: data
  })
}
// 影像质量统计
export function getImagequalityList (data, token) {
  return request({
    url: RoutBaseUrl + '/pacs/quality/imagequality',
    headers: {
      'Authorization': token,
      // 'SystemId': SystemId
    },
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 影像等级质量汇总
export function getImagequalitySummary (data) {
  return request({
    url: RoutBaseUrl + '/pacs/quality/imagequality-summary',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 质量统计导出
export function importImagequalityList (data) {
  return request({
    url: RoutBaseUrl + '/pacs/quality/export-imagequality',
    method: 'GET',
    params: data
  })
}
// 小结统计首页
export function getReportIndexList (data) {
  return request({
    url: RoutBaseUrl + '/pacs/quality/reportindex',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 质控年报详情
export function getYearlyDetail (data) {
  return request({
    url: RoutBaseUrl + '/pacs/quality/yearly-detail',
    method: 'GET',
    params: data
  })
}
// 质控周报月报详情
export function getMonthweeklyDetail (data) {
  return request({
    url: RoutBaseUrl + '/pacs/quality/monthweekly-detail',
    method: 'GET',
    params: data
  })
}
/**
 * 获取申请单质控统计数据
 * @param {*} data 
 * @returns 
 */
export function fetchApplicationQualityScoreSummary (data) {
  return request({
    url: RoutBaseUrl + '/pacs/quality/application-quality-grade-summary',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
/**
 * 获取报告质控统计数据
 * @param {*} data 
 * @returns 
 */
export function fetchReportQualityScoreSummary (data) {
  return request({
    url: RoutBaseUrl + '/pacs/quality/report-quality-grade-summary',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
/**
 * 获取质控检查列表
 * @param {*} data 
 * @returns 
 */
export function fetchQualityObservations (data) {
  return request({
    url: RoutBaseUrl + '/pacs/quality/observations',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}