import request from "@/utils/request";
const fileName = "/api-archive"; // 之前是api-idcas
const operateUrl = "/api-operate";
import { encryptData, decryptUsing3DES } from "@/utils/desEncrypt";
const privateKey = "eWorldStorage#=*";
import qs from "qs";
// 获取所有的存储域
export function getAllDomains(params) {
  return request({
    url: fileName + "/Domains",
    method: "get",
    data: params,
  });
}
// 新增存储域
export function addDomains(params) {
  return request({
    url: fileName + "/Domains",
    method: "post",
    data: params,
  });
}
// 获取所有的存储设备列表
export function getAllDevices(params) {
  return request({
    url: fileName + "/Devices",
    method: "get",
    data: params,
  });
}
// 新增存储设备
export function addDevices(params) {
  let data = JSON.parse(JSON.stringify(params));
  data.access_key = encryptData(params.access_key);

  return request({
    url: fileName + "/Devices",
    method: "post",
    data,
  });
}
// 获取存储域详情
export function getDomainDetail(data) {
  return request({
    url: fileName + `/Domains/${data.id}/detail`,
    method: "get",
  });
}
// 修改设备
export function updateDevice(data, id) {
  let params = JSON.parse(JSON.stringify(data));
  params.access_key = encryptData(data.access_key);

  return request({
    url: fileName + `/Devices/${id}/update`,
    method: "post",
    data: params,
  });
}
// 修改存储域存储设备关联关系状态
export function updateDomainDeviceStu(data) {
  return request({
    url: fileName + "/Domains/domain-device/update",
    method: "post",
    data: data,
  });
}
// 修改存储域
export function updateDomain(data, id) {
  return request({
    url: fileName + `/Domains/${id}/update`,
    method: "post",
    data: data,
  });
}
// 删除存储域
export function delOneDomain(data) {
  return request({
    url: fileName + `/Domains/${data.id}/delete`,
    method: "post",
    paramsSerializer: (data) => {
      return qs.stringify(data, { indices: false });
    },
  });
}
// 获取所有的存储设备列表
export function getAuthorizationList(data) {
  return request({
    url: fileName + "/Domains/app-list",
    method: "GET",
    params: data,
  });
}
// 新增授权信息
export function addAuthorizationInfo(params) {
  return request({
    url: fileName + "/Domains/app",
    method: "post",
    data: params,
  });
}
// 修改授权信息
export function updateAuthorizationInfo(data, id) {
  return request({
    url: fileName + `/Domains/app/${id}/update`,
    method: "post",
    data: data,
  });
}
// 获取某个存储域下的 设备
export function getDomainDeviceList(data) {
  return request({
    url: fileName + `/Devices/${data.id}/domain-list`,
    method: "get",
  });
}
// 添加存储域存储设备关联关系
export function addDomainDevice(params) {
  return request({
    url: fileName + "/Domains/domain-device",
    method: "post",
    data: params,
  });
}
// 删除某个设备
export function delOneDevice(data) {
  return request({
    url: fileName + `/Devices/${data.id}/delete`,
    method: "post",
    paramsSerializer: (data) => {
      return qs.stringify(data, { indices: false });
    },
  });
}
// 删除一个授权信息
export function delOneAuthInfor(data) {
  return request({
    url: fileName + `/Domains/app/${data.id}/delete`,
    method: "post",
    paramsSerializer: (data) => {
      return qs.stringify(data, { indices: false });
    },
  });
}

// 文档管理界面列表统计
export function getDocumentListTotalize(params) {
  return request({
    url: fileName + "/storage/statistic/document-list-totalize",
    method: "get",
    params,
  });
}
//存储域用量+机构用量
export function getCurrentDomainUsages(params) {
  return request({
    url: fileName + "/storage/statistic/domain-usage",
    method: "get",
    params,
  });
}
//系统用量
export function getCurrentSystemUsages(params) {
  return request({
    url: fileName + "/storage/statistic/system-usage",
    method: "get",
    params,
  });
}
//DaysUsageDto
export function getDaysUsage(params) {
  return request({
    url: fileName + "/storage/statistic/least-usage",
    method: "get",
    params,
  });
}
//存储统计--数据范围---系统
export function getSystemDataRange(params) {
  return request({
    url: fileName + "/storage/statistic/data-region-system",
    method: "get",
    params,
  });
}
//存储统计--数据范围---存储域
export function getStatisticDataRange(params) {
  return request({
    url: fileName + "/storage/statistic/data-region",
    method: "get",
    params,
  });
}

//内容管理---策略设置---系统
export function getAllInstitutionStrategies(params) {
  return request({
    url: fileName + "/storage/strategies/system/page",
    method: "get",
    params,
  });
}
// 文档列表
export function getDocuments(params) {
  return request({
    url: fileName + "/storage/documents",
    method: "get",
    params,
  });
}
// 文档列表
export function deleteDocument(id) {
  return request({
    url: fileName + `/storage/documents/${id}/delete`,
    method: "post",
  });
}
// 获取存储域文档浏览地址
export function getDocumentUrl(id) {
  return request({
    url: fileName + `/storage/documents/${id}/view-url`,
    method: "get",
  });
}
// 通过短链获取文件的src
export function getDocumentUrlByShortChain(shortChain) {
  return request({
    url: operateUrl + `/common/short-url/${shortChain}`,
    method: "get",
  });
}
// 根据业务唯一号获取文档信息
export function getDocumentsByBusiness(params) {
  return request({
    url: fileName + `/storage/documents/by-business`,
    method: "get",
    params,
  });
}

// 平台运营下 根据业务唯一号获取文档信息
export function getOperateDocumentsByBusiness(params) {
  return request({
    url: fileName + `/Documents/${params.id}/detail`,
    method: "get",
    params,
  });
}

//暂时保留一下两个---PlatformOperation还在用
// 获取存储域存储策略
export function getStorageTrategies(params) {
  return request({
    url: fileName + `/storage/trategies`,
    method: "get",
    params,
  });
}

// 获取存储域存储策略
export function saveStorageTrategies(data) {
  return request({
    url: fileName + `/storage/trategies`,
    method: "post",
    data,
  });
}

//删除---已标记删除的数据

//获取所有存储域存储策略
export function getAllDomainStrategies(params) {
  return request({
    url: fileName + `/storage/Strategies/all`,
    method: "get",
    params,
  });
}
//获取总机构用量
export function getAllInstitutionDosage(params) {
  return request({
    url: fileName + `/storage/statistic/org-usage-statistic`,
    method: "get",
    params,
    paramsSerializer: (data) => {
      return qs.stringify(data, { indices: false });
    },
  });
}
//获取机构用量
export function getInstitutionDosageList(data) {
  return request({
    url: fileName + `/storage/statistic/org-usage`,
    method: "post",
    data,
  });
}
//获取对应系统的存储策略
export function getCurrentSystemStrategies(params) {
  return request({
    url: fileName + `/storage/Strategies/system`,
    method: "get",
    params,
  });
}
//获取存储域存储策略
export function getCurrentDomainStrategies(params) {
  return request({
    url: fileName + `/storage/Strategies`,
    method: "get",
    params,
  });
}
//更新方式的
export function updateStorageStrategiesType(data) {
  return request({
    url: fileName + `/storage/Strategies/update/strategytype`,
    method: "post",
    data,
  });
}
//更新存储域
export function updateStorageStrategies(data) {
  return request({
    url: fileName + `/storage/Strategies/update`,
    method: "post",
    data,
    paramsSerializer: (data) => {
      return qs.stringify(data, { indices: false });
    },
  });
}

///api/Domains/domain-certification
export function getAuthorityMessage(params) {
  return request({
    url: fileName + `/Domains/domain-certification`,
    method: "get",
    params,
  });
}
//删除---已标记删除的数据
export function deleteTaggedDocument(data) {
  return request({
    url: fileName + `/documents/batch/delete`,
    method: "post",
    data,
  });
}
export function deleteTaggedDocumentProgress(params) {
  return request({
    url: fileName + `/documents/batch/delete/progress`,
    method: "get",
    params,
  });
}

// 获取所有存储域标记策略
export function getMarkstrategiesAll(params) {
  return request({
    url: fileName + `/storage/markstrategies/all`,
    method: "get",
    params,
  });
}

// 获取该存储域下的标记策略
export function getMarkstrategies(params) {
  return request({
    url: fileName + `/storage/markstrategies`,
    method: "get",
    params,
  });
}

// 修改标记策略
export function updateMarkstrategies(data) {
  return request({
    url: fileName + `/storage/markstrategies/update`,
    method: "post",
    data,
    // paramsSerializer: data => {
    //   return qs.stringify(data, { indices: false })
    // }
  });
}
// 获取存储文档
export function getStorageFileType(params) {
  return request({
    url: fileName + "/devices/file-types",
    method: "get",
  });
}
// 获取备份设备列表
export function getBackupDevices(params) {
  return request({
    url: fileName + `/Backup/devices`,
    method: "get",
    params,
    paramsSerializer: (data) => {
      return qs.stringify(data, { indices: false });
    },
  });
}
// 获取在线或 进线设备
export function getDicomDeviceList(params) {
  return request({
    url: fileName + "/devices/systemdomain",
    method: "get",
    params,
  });
}
export function getReportDetails(data, headers) {
  return request({
    url: "/api-imaging/Report/Details",
    method: "post",
    data: data,
    //headers: headers
  });
}
export function downloadFile(DeviceID, FilePath, fileType) {
  return request({
    url: `/api-imaging/File/Download?DeviceID=${DeviceID}&ImagePath=${FilePath}&MimeType=application/${fileType}`,
    method: "get",
    //headers: headers,
    // responseType:"blob",
    responseType: "arraybuffer",
  });
}

export function downloadOfdFile(DeviceID, FilePath, headers) {
  return request({
    url: `/api-imaging/File/Download?DeviceID=${DeviceID}&ImagePath=${FilePath}&MimeType=application/ofd`,
    method: "get",
    //headers: headers,
    responseType: "blob",
    //responseType:"arraybuffer",
  });
}

// 通过上传文档唯一号下载文件
export function getFileByDocumentId(data, responseType, onProgress) {
  return request({
    url: configUrl.docUrl + "/download/document-id",
    method: "get",
    params: data,
    responseType: responseType || "arraybuffer",
    onDownloadProgress: onProgress
  });
}

// 通过业务id下载所有文件
export function getAllFileByBusinessId(data, responseType, onProgress) {
  return request({
    url: configUrl.docUrl + "/download/documents",
    method: "post",
    data: data,
    responseType: responseType || "arraybuffer",
    onDownloadProgress: onProgress
  });
}
