import request from '@/utils/request'
import qs from 'qs'
const fileName = '/api-operate'
//const abilityUrl = '/api-operate'
const abilityUrl = '/api-ability'
// 根据条件查询用户信息
export function getUserinfoByLite (data) {
  return request({
    url: fileName + '/users/lite',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 获取机构分页列表
export function getInstitution (params) {
  return request({
    url: fileName + '/institutions',
    method: 'get',
    params: params,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 新增机构
export function addInstitution (params) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: fileName + '/institutions',
    method: 'post',
    data: params
  })
}
// 添加机构
export function addNoBindInstitution (params) {
  return request({
    url: fileName + '/tenancies/deliver-bind-institution',
    method: 'post',
    data: params
  })
}
// 导入机构
export function importInstitution (params) {
  return request({
    url: fileName + '/institutions/import',
    method: 'post',
    data: params
  })
}

// 编辑机构
export function putInstitution (id, params) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: fileName + `/institutions/${id}/update`,
    method: 'post',
    data: params
  })
}
// 机构-> 添加机构 获取交互模式下的机构
export function getPayModelInstitution (data) {
  return request({
    url: fileName + '/institutions/deliver-pagination',
    method: 'get',
    params: data
  })
}
// 获取机构列表
export function getInstitutionList (url) {
  return request({
    url: fileName + url,
    method: 'get'
  })
}
// 获取机构列表 跟上面的接口一样 只是换了种形式
export function getTenancyInstitutionList (data) {
  return request({
    url: fileName + '/institutions',
    method: 'get',
    params: data
  })
}
// 获取机构列表精简信息
export function getInstitutionListLite (parmas) {
  return request({
    url: fileName + '/institutions/lite' + (parmas ? parmas : ''),
    method: 'get'
  })
}
// 获取任何一个客户下的机构详情(可以是跨客户)
export function getAnyInstitutionInfoDetail (data) {
  return request({
    url: fileName + '/institutions/from-all-tenancy/detail',
    method: 'get',
    params: data
  })
}
// 获取任何一个客户下的机构详情(可以是跨客户)
export function getTenancyInstituteList (data) {
  return request({
    url: fileName + '/institutions/from-all-tenancy/pagination',
    method: 'get',
    params: data
  })
}
// 获取当前客户下的机构详情(本客户)
export function getInstitutionInfoDetail (data) {
  return request({
    url: fileName + '/institutions/detail',
    method: 'get',
    params: data
  })
}
// 删除机构信息
export function delInstitutionInfoByid (id) {
  return request({
    url: fileName + `/institutions/${id}/delete`,
    method: 'post'
  })
}

// 移除机构信息
export function institutionUnbindSystem (data) {
  return request({
    url: fileName + `/institutions/unbind-system`,
    method: 'post',
    data
  })
}

export function getAimInstitutionOpenList (data) {
  return request({
    url: `/api-ai/ai/service/open/page-list`,
    method: 'post',
    data
  })
}

// 根据机构id获取机构下的服务详细列表
export function getAimInstitutionDetailOpen(params) {
  return request({
    url: `/api-ai/ai/service/open/detail`,
    method: 'get',
    params
  })
}

// --------------------科室接口------------------------------
// 获取科室列表
export function getOfficesList (url) {
  return request({
    url: fileName + url,
    method: 'get'
  })
}
// 获取科室详情
export function getOfficesinfoByid (id) {
  return request({
    url: fileName + `/Offices/${id}`,
    method: 'get'
  })
}
// 新增科室
export function addOfficesinfo (params) {
  return request({
    url: fileName + '/Offices',
    method: 'post',
    data: params
  })
}
// 编辑科室
export function putOfficesinfo (params) {
  return request({
    url: fileName + `/Offices/${params.id}/update`,
    method: 'post',
    data: params
  })
}
// 删除科室
export function delOfficesinfo (id) {
  return request({
    url: fileName + `/Offices/${id}/delete`,
    method: 'post',
    data: {
      id: id
    }
  })
}
// 导入科室
export function importOffice (params) {
  return request({
    url: fileName + '/offices/import',
    method: 'post',
    data: params
  })
}
// 获取类型 OfficeSystemType
// 获取科室详情
export function OfficeSystemType (id) {
  return request({
    url: fileName + '/OfficeSystemType',
    method: 'get'
  })
}
// -------------------------------------------pacs系统---影像共享系统---------------------------------------
// type  1: pasc系统 2: 影像共享系统
// 获取pacs列表
export function getPascList (type) {
  return request({
    url: fileName + '/systems?type=' + type,
    method: 'get'
  })
}

// 获取接口服务的业务列表
export function getInterfaceBusinessSystem (type) {
  return request({
    url: fileName + '/systems/interface/business-system',
    method: 'get'
  })
}

// 获取智能科室、影像大数据 的使用机构
export function getUseInstitute () {
  return request({
    url: fileName + '/institutions/lite',
    method: 'get'
  })
}
// 获取pacs列表
export function getintellingenceOfficeList (data) {
  return request({
    url: fileName + '/systems',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// /api/systems/pacs-page
export function getAllPacsList (data) {
  return request({
    url: fileName + '/systems/pacs-page',
    method: 'get',
    params: data
  })
}

// 22.1 新版本  应用系统列表(整和了所有的业务系统)
export function getAllApplicationSystemList (data) {
  return request({
    url: fileName + '/tenancies/application-system',
    method: 'get',
    params: data
  })
}
// 获取云pacs或 影像存档 集中预约等权限
export function getServiceTypePower (data) {
  return request({
    url: fileName + '/systems/service-type',
    method: 'get',
    params: data
  })
}
// 获取租户开通的PACS系统服务列表
export function getPasServicecList (params) {
  return request({
    url: fileName + '/systems/pacs-service',
    method: 'get'
  })
}
// 获取租户开通的pacs 列表 里面 某个pacs 下的协同产品列表
export function getPacsCooperateProductList (params) {
  return request({
    url: fileName + '/systems/pacs-service',
    method: 'get'
  })
}
// 获取全资源预约 开通的服务
export function getEWCSSServicecList (params) {
  return request({
    url: fileName + '/systems/ewcss-services',
    method: 'get'
  })
}
// 获取叫号系统下的 产品
export function getCallingService () {
  return request({
    url: fileName + '/systems/calling-service',
    method: 'get'
  })
}
// 检查是否开通的刑侦调阅服务
export function checkIsOpenImageCriminal () {
  return request({
    url: fileName + '/tenancies/check-image-criminal',
    method: 'get'
  })
}
// 获取调阅来源
export function getCriminalSource (data) {
  return request({
    url: fileName + '/systems/lite',
    method: 'get',
    params: data
  })
}
// 新增pacs
export function addPacsSystems (params) {
  return request({
    url: fileName + '/systems',
    method: 'post',
    data: params
  })
}

// 查询pacs详情
export function getPacsSystemsInfoByid (id) {
  return request({
    url: fileName + '/systems/detail?id=' + id,
    method: 'get'
  })
}
// 编辑pacs
export function putPacsSystems (params) {
  return request({
    url: fileName + `/systems/${params.id}/update`,
    method: 'post',
    data: params
  })
}
// 删除创建的业务系统 ---目前只有接口服务有删除
export function deletePacsSystems (params) {
  return request({
    url: fileName + '/systems/delete',
    method: 'post',
    data: params
  })
}
// 影像共享系统 开通服务接口
export function getImageserviceList (params) {
  return request({
    url: fileName + '/tenancies/image-archive/service',
    method: 'get'
  })
}
// 平台设置---------------------------------------------------------------------------------------------
// 平台运营外部能力--------------------------

// 获取AES密钥和向量
export function getAesPassword () {
  return request({
    // url: abilityUrl + '/common-settings/encryption-setting/1',
    url: fileName + '/common-settings/encryption-setting/1',
    method: 'get'
  })
}
// 外部能力的枚举
export function getEnums (params) {
  return request({
   // url: abilityUrl + '/definitions/enums' ,
    url: fileName + '/constants/enumerations' ,
    method: 'GET'
  })
}
// 保存配置
export function commonSettings (params) {
  return request({
    // url: abilityUrl + '/common-settings',
    url: fileName + '/common-settings',
    method: 'POST',
    data: params
  })
}
// 分页获取外部能力
export function getcommonSettingList (params) {
  return request({
    // url: abilityUrl + '/common-settings' + params,
    url: fileName + '/common-settings' + params,
    method: 'GET'
  })
}
// 能力详情
export function getcommonSettingListInfo (parmas) {
  return request({
    // url: abilityUrl + `/common-settings/detail?` + parmas,
    url: fileName + `/common-settings/detail?` + parmas,
    method: 'GET'
  })
}
// 修改外部能力详情
export function putCommonSetting (params) {
  return request({
    // url: abilityUrl + '/common-settings/update',
    url: fileName + '/common-settings/update',
    method: 'post',
    data: params
  })
}
// 删除外部能力详情
export function delCommonSetting (id) {
  return request({
    // url: abilityUrl + `/common-settings/${id}/delete`,
    url: fileName + `/common-settings/${id}/delete`,
    method: 'post'
  })
}
// 查询配置
export function getcommonSettinginfo (setType, type) {
  return request({
    // url: abilityUrl + `/common-settings/${setType}/${type}`,
    url: fileName + `/common-settings/${setType}/${type}`,
    method: 'GET'
  })
}
// 客户管理外部能力------------
// 获取能力
export function getCommonSettingTenancy (data) {
  return request({
    //url: abilityUrl + '/common-settings/tenancy',
    url: fileName + '/common-settings/tenancy',
    method: 'GET',
    params: data
  })
}
// 保存能力
export function postCommonSettingTenancy (data) {
  return request({
    //url: abilityUrl + '/common-settings/tenancy',
    url: fileName + '/common-settings/tenancy',
    method: 'POST',
    data: data
  })
}
// 参数设置-------------
// 加载客户系统配置元数据
export function getSettingsMmeta (data) {
  return request({
    url: fileName + '/tenancies/settings-meta',
    method: 'GET',
    params: data
  })
}
// 获取客户系统配置
export function getSettings (id) {
  return request({
    url: fileName + `/tenancies/${id}/settings`,
    method: 'GET'
  })
}
// 获取客户系统配置
export function postSettings (id, data) {
  return request({
    url: fileName + `/tenancies/${id}/settings`,
    method: 'post',
    data: data
  })
}
// 获取平台运营参数配置
export function getOperateSettingsMmeta (data) {
  return request({
    url: fileName + '/operates/settings-meta',
    method: 'GET',
    params: data
  })
}
// 保存平台运营 参数配置
export function postOperateSettings (data) {
  return request({
    url: fileName + '/operates/settings',
    method: 'post',
    data: data
  })
}
// 保存院内 报告配置
export function saveServiceReportSetting (data) {
  return request({
    url: fileName + '/institutions/parameter-config-settings',
    method: 'post',
    data: data
  })
}
// 获取总院报告配置
export function getReportConfigSettings (id) {
  return request({
    url: fileName + `/institutions/${id}/parameter-config-settings-meta`,
    method: 'GET',
  })
}
// 获取厂商和卫健委 分页列表
export function getAllFirmOrWeiJianList (data) {
  return request({
    url: fileName + '/factory/page',
    method: 'GET',
    params: data
  })
}
// 获取厂商和卫健委 分页列表
export function getNewAllFirmOrWeiJianList (data) {
  return request({
    url: fileName + '/factory/page',
    method: 'post',
    data: data
  })
}
// 获取厂商不分页列表
export function getAllFirmList (data) {
  return request({
    url: fileName + '/factory/page',
    method: 'GET',
    params: data
  })
}
// 新增厂商或 新增卫健委
export function addFirmOrWeiJian (data) {
  return request({
    url: fileName + '/factory/add',
    method: 'post',
    data: data
  })
}
// 删除卫健
export function beganDeleteWeiJian (params) {
  return request({
    url: fileName + '/factory/delete',
    method: 'post',
    data: params
  })
}
// 删除厂商
export function beganDeleteFirm (params) {
  return request({
    url: fileName + '/factory/delete',
    method: 'post',
    data: params
  })
}
// 获取厂商或者卫健详情
export function getFirmOrWeiJianDetail (data) {
  return request({
    url: fileName + '/factory/detail',
    method: 'GET',
    params: data
  })
}
// 编辑厂商或者卫健委
export function updateFirmOrWeiJian (params) {
  return request({
    url: fileName + '/factory/update',
    method: 'post',
    data: params
  })
}
// 获取厂商/卫健行政区域
export function getFactoryRegion (data) {
  return request({
    url: fileName + '/factory/region',
    method: 'GET',
    params: data
  })
}
// 获取厂商/卫健 关联的机构 分页
export function getFactoryInstitution (data) {
  return request({
    url: fileName + '/factory/institution-page',
    method: 'GET',
    params: data
  })
}
// 获取厂商/卫健 关联的机构 不分页
export function getAllFactoryInstitution (params) {
  return request({
    url: fileName + '/factory/institution',
    method: 'post',
    data: params
  })
}
// 禁用/启用 厂商或卫健 关联的机构
export function updateFactoryInstitutionState (params) {
  return request({
    url: fileName + '/systems/factory-institution-state',
    method: 'post',
    data: params
  })
}
// 获取厂商/卫健不分页(新增用户那边用的)
export function getFactoryList (data) {
  return request({
    url: fileName + '/factory/list',
    method: 'GET',
    params: data
  })
}
// 获取业务系统->管理员列表
export function getApplicationSystemAdminList () {
  return request({
    url: fileName + '/tenancies/application-system/admin',
    method: 'GET'
  })
}
// 获取业务系统->新增时 可以选择的系统类型
export function getApplicationSystemTypeList () {
  return request({
    url: fileName + '/tenancies/application-system/type',
    method: 'GET'
  })
}
// 获取患者服务-> 开通服务
export function getEwspsServicesList () {
  return request({
    url: fileName + '/systems/ewsps-services',
    method: 'GET'
  })
}
// 获取科室管理-> 开通服务
export function getAllOfficeServicesList () {
  return request({
    url: fileName + '/systems/dms-services',
    method: 'GET'
  })
}
// 获取大模型配置和地址
export function getLargeModelSetList () {
  return request({
    url: fileName + '/common-settings/tenancy/llm',
    method: 'GET'
  })
}
// 获取应用系统的排列模式
export function getShowSystemWay () {
  return request({
    url: fileName + '/users/application-system-display-mode',
    method: 'GET'
  })
}
// 保存应用系统的排列模式
export function saveShowSystemWay (params) {
  return request({
    url: fileName + '/users/application-system-display-mode',
    method: 'post',
    data: params
  })
}
// 获取总院列表
export function getSubordinationList () {
  return request({
    url: fileName + '/institutions/simple/list/by-subordination',
    method: 'GET'
  })
}
// 获取某一类外部能力下  被哪些机构所使用
export function getOneTypeAbilityList (data) {
  return request({
    url: fileName + '/common-settings/institutions',
    method: 'GET',
    params: data
  })
}
// 删除某个机构的 个性设置
export function delInstitutionAbility (params) {
  return request({
    url: fileName + '/common-settings/tenancy/delete',
    method: 'post',
    data: params
  })
}
