import request from '@/utils/request'
import qs from 'qs'

const RoutBaseUrl = '/api-operate'
// 获取服务工单 (分页)
export function getSeviceOrderList (data) {
  return request({
    url: RoutBaseUrl + '/service-orders',
    method: 'GET',
    params: data
  })
}
// 提交服务工单
export function subServiceOrders (data) {
  return request({
    url: RoutBaseUrl + '/service-orders',
    method: 'post',
    data: data
  })
}
// 添加服务工单
export function addServiceOrders (data) {
  return request({
    url: RoutBaseUrl + '/service-orders/directly',
    method: 'post',
    data: data
  })
}
// 获取服务工单详情
export function getSeviceOrderDetail (id) {
  return request({
    url: RoutBaseUrl + `/service-orders/${id}`,
    method: 'GET'
  })
}
// 日志相关的接口
// 获取日志列表 (分页)
export function getLogList (data) {
  return request({
    url: RoutBaseUrl + '/logs',
    method: 'GET',
    params: data
  })
}
// 获取日志列表 (分页)
export function getLogDetail (id,tenancyId, logItemId) {
  let url =  `/logs/${id}`
  if (logItemId) {
    url = `/logs/${id}/${logItemId}`
  }
  return request({
    headers: {
      'ew-tenancy-id': tenancyId
    },
    url: RoutBaseUrl + url,
    method: 'GET'
  })
}

// 日志导出
export function importLogList (data) {
  return request({
    url: RoutBaseUrl + '/log-audits/export',
    method: 'post',
    data: data
  })
}
// 获取 业务参数
export function getBusinessParam () {
  return request({
    url: RoutBaseUrl + '/logs/options',
    method: 'GET'
  })
}
// 获取 业务模块
export function getBusinessModules (data) {
  return request({
    url: RoutBaseUrl + '/tenancies/log-business-system',
    method: 'GET',
    params: data
  })
}
// 获取业务系统
export function getOrderBusinessSystem () {
  return request({
    url: RoutBaseUrl + '/service-orders/business-system',
    method: 'GET'
  })
}
// 修改工单状态 
export function putOrder (data) {
  return request({
    url: RoutBaseUrl + '/service-orders/state/update',
    method: 'post',
    data: data
  })
}
// 指派工程师
export function assignEngineer (data) {
  return request({
    url: RoutBaseUrl + '/service-orders/assign-engineer',
    method: 'post',
    data: data
  })
}
// 获取工单图片
export function getOrderImage (data) {
  return request({
    url: RoutBaseUrl + '/service-orders/image',
    method: 'GET',
    params: data
  })
}
// 获取工单详情
export function getOrderDetail (data) {
  return request({
    url: RoutBaseUrl + '/service-orders/detail',
    method: 'GET',
    params: data
  })
}
// 获取工单完整详情
export function getOrderCompleteDetail (data) {
  return request({
    url: RoutBaseUrl + '/service-orders/complete-detail',
    method: 'GET',
    params: data
  })
}
// 添加服务工单
export function addOrder (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: RoutBaseUrl + '/service-orders',
    method: 'post',
    data: data
  })
}
// 编辑服务工单
export function updateOrder (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: RoutBaseUrl + '/service-orders/update',
    method: 'post',
    data: data
  })
}
// 评价工单
export function evaluationOrder (data) {
  return request({
    url: RoutBaseUrl + '/service-orders/evaluation',
    method: 'post',
    data: data
  })
}
// 获取工单图片
export function getOrderImg (data) {
  return request({
    responseType: 'arraybuffer',
    url: RoutBaseUrl + '/service-orders/image',
    method: 'GET',
    params: data
  })
}
// 获取工单统计
export function getOrderStateStatistics (data) {
  return request({
    url: RoutBaseUrl + '/service-orders/state-statistics' + data,
    method: 'GET',
    // params: data
  })
}
// 获取所有的指派人员
export function getOperationUser (data) {
  return request({
    url: RoutBaseUrl + '/users/operation/letter',
    method: 'GET',
    params: data
  })
}
// 获取故障统计
export function getBreadDownStatistics () {
  return request({
    url: RoutBaseUrl + '/monitors/type-statistics',
    method: 'GET'
  })
}
// 获取故障列表
export function getBreadDownList (data) {
  return request({
    url: RoutBaseUrl + '/monitors',
    method: 'GET',
    params: data
  })
}
// 获取会议视频列表
export function getVideoList (data) {
  return request({
    url: RoutBaseUrl + '/meetings/page',
    method: 'GET',
    params: data
  })
}
// 删除视频文件
export function beganDeleteVideo (params) {
  return request({
    url: RoutBaseUrl + '/meetings/delete',
    method: 'post',
    data: params
  })
}
// 获取视频详情
export function getVideoDetail (data) {
  return request({
    url: RoutBaseUrl + '/meetings/detail',
    method: 'GET',
    params: data
  })
}
// 获取会议视频对应的操作日志列表
export function getVideoLogList (data) {
  return request({
    url: RoutBaseUrl + '/meetings/log/page',
    method: 'GET',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 重新存档文件
export function reArchivingVideo (params) {
  return request({
    url: RoutBaseUrl + '/meetings/re-archive',
    method: 'post',
    data: params
  })
}
// 获取门户列表
export function getPortalList (data) {
  return request({
    url: RoutBaseUrl + '/portals/list',
    method: 'GET',
    params: data
  })
}
// 获取门户的操作日志
export function getPortalLogsList (data) {
  return request({
    url: RoutBaseUrl + '/portals/page-logs',
    method: 'GET',
    params: data
  })
}
// 删除 自定义门户
export function beganDeletePortal (params) {
  return request({
    url: RoutBaseUrl + '/portals/api/portals/delete',
    method: 'post',
    data: params
  })
}