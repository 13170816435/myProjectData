import request from '@/utils/request'
import qs from 'qs'
const operateUrl = '/api-operate'
const abilityUrl = '/api-operate'

// 获取监管平台
export function getSupervisionCodeOptions (data) {
  return request({
    url: operateUrl + '/supervision/code-options',
    method: 'get'
  })
}

// 分页列出监管方
export function getSupervision (data) {
  return request({
    url: operateUrl + '/supervision',
    method: 'get',
    params: data,
    headers: {
      'Content-Type': 'application/json'
    },
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}

// 新增/修改监管方信息
export function postSupervision (data) {
  return request({
    url: operateUrl + '/supervision',
    method: 'post',
    data
  })
}

// 分页列出监管范围
export function getSupervisionScopes (data) {
  return request({
    url: operateUrl + '/supervision/scopes',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}

// 删除监管方
export function deleteSupervision (id) {
  return request({
    url: operateUrl + '/supervision/' + id +'/delete',
    method: 'post'
  })
}

// 添加监管范围
export function postSupervisionScopes (data) {
  return request({
    url: operateUrl + `/supervision/${data.supervisor_id}/scopes`,
    method: 'post',
    data
  })
}

// 更新监管范围的机构映射
export function patchSupervisionScopes (data) {
  return request({
    url: operateUrl + `/supervision/${data.id}/scopes/update`,
    method: 'post',
    data
  })
}

// 移除监管范围
export function deleteSupervisionScopes (data) {
  return request({
    url: operateUrl + `/supervision/${data.id}/scopes/delete`,
    method: 'post',
    data: data
  })
}

// 是否启用监管平台
export function getSupervisionEnabled (id) {
  return request({
    url: operateUrl + `/supervision/${id}/enabled`,
    method: 'get'
  })
}

// 列出指定字典类型下的字典映射
export function getSupervisionMaps (data) {
  return request({
    url: operateUrl + '/supervision/maps',
    params: data,
    method: 'get',
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}

// 保存指定字典类型下的字典映射
export function postSupervisionMaps (data) {
  return request({
    url: operateUrl + '/supervision/maps',
    method: 'post',
    data
  })
}

// 添加监管记录
export function postSupervisionTracks (data) {
  return request({
    url: operateUrl + '/supervision/tracks',
    method: 'post',
    data
  })
}

// 分页列出监管记录
export function getSupervisionTracks (data) {
  return request({
    url: operateUrl + '/supervision/tracks',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}

// 获取监管业务类型
export function getSupervisionKindOptions () {
  return request({
    url: operateUrl + '/supervision/kind-options',
    method: 'get'
  })
}
