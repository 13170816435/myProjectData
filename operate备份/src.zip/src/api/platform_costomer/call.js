import request from '@/utils/request'

// #region 叫号屏显示布局
/**
 * 获取叫号屏显示布局列表
 * @returns ScreenLayoutList
 */
export function GetScreenLayoutList () {
  return request({
    url: '/api-cloudpacs/Calling/ScreenLayout',
    method: 'get'
  })
}

/**
 * 新增 叫号屏显示布局
 * @param {叫号屏显示布局} data
 * @returns 新增结果
 */
export function PostScreenLayout (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: '/api-cloudpacs/Calling/ScreenLayout',
    method: 'post',
    data: data
  })
}

/**
 * 更新 叫号屏显示布局
 * @param {叫号屏显示布局} data
 * @returns 更新结果
 */
export function PutScreenLayout (id, data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: '/api-cloudpacs/Calling/ScreenLayout/' + id,
    method: 'put',
    data: data
  })
}

// #endregion

// #region 叫号屏队列定义
/**
 * 获取叫号屏队列定义列表
 * @param {对应的叫号屏Id} screenConfigId
 * @returns
 */
export function GetScreenQueueDefineList (screenConfigId) {
  return request({
    url: '/api-cloudpacs/Calling/ScreenQueueDefine/' + '?screenConfigId=' + screenConfigId,
    method: 'get'
  })
}

// /**
//  * 新增 叫号屏队列定义
//  * @param {叫号屏队列定义} data
//  * @returns 新增结果
//  */
// export function PostScreenQueueDefine (data) {
//   return request({
//     url: '/api-cloudpacs/Calling/ScreenQueueDefine',
//     method: 'post',
//     data: data
//   })
// }

/**
 * 覆盖 叫号屏队列定义
 * @param {叫号屏队列定义} data
 * @returns 更新结果
 */
export function PostScreenQueueDefine (id, data) {
  return request({
    url: '/api-cloudpacs/Calling/ScreenQueueDefine/ScreenConfig/' + id,
    method: 'post',
    data: data
  })
}

// #endregion
export function SaveParameter (data) {
  return request({
    url: '/api-cloudpacs/Calling/CallSetting/Config',
    method: 'post',
    data: data
  })
}
export function GetParameter (data) {
  return request({
    url: '/api-cloudpacs/Calling/CallSetting/Config',
    method: 'get',
    params: data
  })
}
export function GetImgBase64 (data) {
  return request({
    url: '/api-cloudpacs/Calling/Upload/ImgBase64',
    method: 'get',
    params: data
  })
}
export function GetPlayAudio (data) {
  return request({
    url: '/api-cloudpacs/Calling/Voice/AudioBase64',
    method: 'post',
    data: data
  })
}
export function GetScreens () {
  return request({
    url: '/api-cloudpacs/Calling/ScreenConfig',
    method: 'get'
  })
}
export function PostScreenConfig (data) {
  return request({
    url: '/api-cloudpacs/Calling/ScreenConfig',
    method: 'post',
    data: data
  })
}
export function PutScreenConfig (data) {
  return request({
    url: '/api-cloudpacs/Calling/ScreenConfig',
    method: 'put',
    data: data
  })
}
export function DeleteConfig (data) {
  return request({
    url: '/api-cloudpacs/Calling/ScreenConfig/' + data.id,
    method: 'delete'
    // params: data
  })
}
export function GetOnlineClient (data) {
  return request({
    url: '/api-cloudpacs/Calling/CallClient/OnlineClient',
    method: 'get',
    params: data
  })
}
export function GetClientSendLog () {
  return request({
    url: '/api-cloudpacs/Calling/CallClient/ClientSendLog',
    method: 'get'
  })
}

export function SendCloseMsgToClient (data) {
  return request({
    url: '/api-cloudpacs/Calling/CallClient/CloseMsg',
    method: 'post',
    data: data
  })
}
