import request from '@/utils/request'
const fileName = '/api-archive'
const idcasRoutBaseUrl = '/api-idcas'
import qs from 'qs'
// 获取审核列表
export function getCheckList (data) {
  return request({
    url: idcasRoutBaseUrl + '/forensicaccess/auditor-request-list',
    method: 'GET',
    params: data
  })
}
// 刑侦调阅审核人员根据调阅申请唯一号获取关联检查检验信息包含诊断信息 和检验信息
export function getAuditDetail (forensicRequestId) {
  return request({
    url: idcasRoutBaseUrl + `/ForensicAccess/${forensicRequestId}/detail-auditor`,
    method: 'GET'
  })
}
// 审核检查或者检验
export function auditOrExam (data, id) {
  return request({
    //url: fileName + `/ForensicAccess/${id}/audit-exam-list`,
    url: idcasRoutBaseUrl + `/forensicaccess/${id}/audit`,
    method: 'post',
    data: data
  })
}
//媒体文件下载
export function downloadMedias(params){
	return request({
		url: idcasRoutBaseUrl + `/Common/logo-get`,
		method: 'GET',
		params:params,
		responseType: 'arraybuffer'
	})
}
// 获取刑侦调阅查看记录
export function getLogViewPage (data) {
  return request({
    url: idcasRoutBaseUrl + '/ForensicAccess/log-view-page',
    method: 'GET',
    params: data
  })
}
// 获取某条日志信息列表
export function getLogInforList (data) {
  return request({
    url: idcasRoutBaseUrl + '/Domains/app-list',
    method: 'GET',
    params: data
  })
}
// 获取module
export function getModuleList (data) {
  return request({
    //url: fileName + '/Settings/module-list',
    url: idcasRoutBaseUrl + '/Config/system/modules',
    method: 'GET',
    params: data
  })
}
// 通过modeId 和系统id 获取参数配置
export function getParamList (data) {
  return request({
    // url: fileName + '/Settings/param-list',
    url: idcasRoutBaseUrl + '/Config/system/params-by-module-id',
    method: 'GET',
    params: data
  })
}
export function saveParam (params) {
  return request({
    //url: fileName + '/Settings/param',
    url: idcasRoutBaseUrl + '/Config/system/params',
    method: 'post',
    data: params
  })
}