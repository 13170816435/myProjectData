import request from '@/utils/request'
import qs from 'qs'

const barse = 'http://192.168.1.173:8710'
const RoutBaseUrl = '/api-operate'
const pacsRoutBaseUrl = '/api-cloudpacs'

// 获取所有的服务中心 (分页)
export function getSeviceCenterList(data) {
  return request({
    url: RoutBaseUrl + '/service-centers',
    method: 'GET',
    params: data
  })
}

// 添加服务中心
export function addSeviceCenter(data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: RoutBaseUrl + '/service-centers',
    method: 'post',
    data: data
    // baseURL: barse
  })
}

// 添加第三方服务中心
export function addThirdServiceCenter(data) {
  return request({
    url: RoutBaseUrl + '/service-centers/third-party',
    method: 'post',
    data: data
  })
}

// 删除服务中心
export function deleteServiceCenter(data) {
  return request({
    url: RoutBaseUrl + `/service-centers/${data.id}/delete`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
    // baseURL: barse
  })
}

// 删除服务中心下的所有服务
export function deleteAllService(data) {
  return request({
    url: RoutBaseUrl + `/service-centers/${data.id}/services/${data.slug}/delete`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
    // baseURL: barse
  })
}

// 获取所有的服务中心 (不分页)
export function getAllServiceCenter(data) {
  return request({
    url: RoutBaseUrl + '/service-centers/lite',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取服务中心详情
export function getServiceCenterDetail(data) {
  return request({
    url: RoutBaseUrl + `/service-centers/${data.id}`,
    method: 'GET',
    params: data
  })
}

// 获取第三方服务中心详情
// 获取服务中心详情
export function getThirdServiceCenterDetail(data) {
  return request({
    url: RoutBaseUrl + '/service-centers/third-party/detail',
    method: 'GET',
    params: data
  })
}

// 更新服务中心基本资料
export function updateServiceCenterData(data, id) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: RoutBaseUrl + `/service-centers/${id}/update`,
    method: 'post',
    data: data
    // baseURL: barse
  })
}

// 更新第三方服务中心基本资料
export function updateThirdServiceCenterData(data) {
  return request({
    url: RoutBaseUrl + '/service-centers/third-party/update',
    method: 'post',
    data: data
  })
}

// 获取某服务中心下 开通的服务
export function getServiceCenterSevice(data) {
  return request({
    url: RoutBaseUrl + '/service-centers/services',
    method: 'GET',
    params: data
  })
}

// 获取所有的管理员
// export function getAllManager (url) {
//   return request({
//     url: RoutBaseUrl + '/users/lite' + url,
//     method: 'GET'
//   })
// }
export function getAllManager(url) {
  return request({
    url: RoutBaseUrl + '/institutions/member/list' + url,
    method: 'GET'
  })
}

// 获取机构开通的服务项
export function getInstitutionServices(data) {
  return request({
    url: RoutBaseUrl + '/tenancies/telemed-service',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}

// 获取机构(不分页) --教学中心->添加签约医院
export function getUseInstitutions(data) {
  return request({
    url: RoutBaseUrl + '/service-centers/use-institution-page',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}

// 获取机构(不分页)
export function getInstitutions(data) {
  return request({
    url: RoutBaseUrl + '/institutions/lite',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}

// 获取机构(分页)
export function getAllInstituList(data) {
  return request({
    url: RoutBaseUrl + '/service-cooperations/unsigned',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}

// 删除(解约)合作医院
export function DeleteOrgan(data) {
  return request({
    url: RoutBaseUrl + `/service-cooperations/institutions/${data.id}/delete`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
    // baseURL: barse
  })
}

// 删除(解约)教学中心下的合作医院
export function DeleteTeachCenterOrgan(data) {
  return request({
    url: RoutBaseUrl + `/service-cooperations/institutions/${data.id}/2/delete`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
    // baseURL: barse
  })
}

// 停止服务合作 (点击编辑机构 里面的删除)
export function stopServiceCooperation(data) {
  return request({
    url: RoutBaseUrl + `/service-cooperations/${data.id}/delete`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
    // baseURL: barse
  })
}

// 终止合作的服务项目
export function stopThisService(data) {
  return request({
    url: RoutBaseUrl + `/service-cooperations/${data.id}/services/${data.slug}/delete`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
    // baseURL: barse
  })
}

// 开通服务合作项目
export function openThisService(data) {
  return request({
    url: RoutBaseUrl + `/service-cooperations/${data.id}/services/directly`,
    method: 'post',
    data: data
    // baseURL: barse
  })
}

// 开通服务合作项目
export function openThisDoctorService(data) {
  return request({
    url: RoutBaseUrl + `/service-doctors/${data.id}/services`,
    method: 'post',
    data: data
    // baseURL: barse
  })
}

// 获取合作医院分页列表
export function getCooperationsList(data) {
  return request({
    url: RoutBaseUrl + '/service-cooperations',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}


export const getSignedInstitutionList = params => request({
  url: `${RoutBaseUrl}/service-cooperations/telemed/dropdown/list`,
  params,
  paramsSerializer: data => qs.stringify(data, {indices: false})
})


// 获取服务合作详情
export function getCooperationsDetail(data) {
  return request({
    url: RoutBaseUrl + `/service-cooperations/${data.id}`,
    method: 'GET',
    params: data
    // baseURL: barse
  })
}

// 添加签约机构
export function addCooperations(data) {
  return request({
    url: RoutBaseUrl + '/service-cooperations',
    method: 'post',
    data: data
    // baseURL: barse
  })
}
// 获取服务机构（不分页）
export function getServiceInstitutions(data) {
  return request({
    url: RoutBaseUrl + '/institutions/service-center-institutions',
    method: 'get',
  })
}
// 获取申请机构（不分页）
export function getApplyInstitutions(data) {
  return request({
    url: RoutBaseUrl + '/institutions/service-center-signing',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {indices: false})
    }
  })
}

// 获取所有的服务医生 (分页)
export function getAllServiceDoctor(data) {
  return request({
    url: RoutBaseUrl + '/service-doctors',
    method: 'GET',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}

// 获取所有的服务医生 (不分页)
export function getServiceDoctorLite(data) {
  return request({
    url: RoutBaseUrl + '/service-doctors/lite',
    method: 'GET',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {indices: false})
    }
  })
}

// 解除某个医生 签约的服务
export function DeleteOneDoctorService(data) {
  return request({
    url: RoutBaseUrl + `/service-doctors/${data.id}/services/${data.slug}/delete`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 删除某个服务医生
export function DeleteOneServiceDoctor(data) {
  return request({
    url: RoutBaseUrl + `/service-doctors/doctors/${data.id}/delete`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 删除某个服务中心下的医生
export function DeleteOneServiceCenterDoctor(data) {
  return request({
    url: RoutBaseUrl + `/service-doctors/doctors/${data.serviceCenterId}/${data.id}/delete`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 解约 某位医生
export function DeleteOneDoctor(data) {
  return request({
    url: RoutBaseUrl + `/service-doctors/${data.id}/delete`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 添加 服务医生
export function beganAddDoctor(data) {
  return request({
    url: RoutBaseUrl + '/service-doctors',
    method: 'post',
    data: data
    // baseURL: barse
  })
}

// 获取医生详情
export function getDoctorDetail(data) {
  return request({
    url: RoutBaseUrl + `/service-doctors/${data.id}`,
    method: 'GET',
    params: data
  })
}

// 获取所有的用户
export function getAllUser(data) {
  return request({
    url: RoutBaseUrl + '/users',
    method: 'GET',
    params: data
  })
}

// 获取某组 里面的未添加的成员
export function getAllGroupUser(data) {
  return request({
    url: RoutBaseUrl + '/authority-groups/service-center/group/member',
    method: 'GET',
    params: data
  })
}

// 获取所有用户
export function getAllNoSignDoctor(data) {
  return request({
    url: RoutBaseUrl + '/users/tenancy-doctor-pagination',
    method: 'GET',
    params: data
  })
}

// // 获取所有用户医生
export function getAllUserDoctor(data) {
  return request({
    url: RoutBaseUrl + `/users/doctor/${data.offset}/${data.limit}`,
    method: 'GET',
    params: data
  })
}

// 添加组成员
export function beganAddGroupMember(data) {
  return request({
    url: RoutBaseUrl + '/users/authority-group',
    method: 'post',
    data: data
    // baseURL: barse
  })
}

// 设置 上传图片的路径
export function getUploadSrc(data) {
  //return barse + RoutBaseUrl + '/medias'
  return configUrl.apiUrl + RoutBaseUrl + '/medias'
}

// 上传图片的处理
export function uploadFile(data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: RoutBaseUrl + '/medias',
    method: 'post',
    data: data
    // baseURL: barse
  })
}

// 获取机构logo
export function getEditImg(file_token) {
  return request({
    responseType: 'arraybuffer',
    url: RoutBaseUrl + `/medias/${file_token}`,
    method: 'GET'
  })
}

// 获取科室
export function getOffices(data) {
  return request({
    url: RoutBaseUrl + '/offices/lite',
    method: 'GET',
    params: data
  })
}

// 根据机构id 获取 用户手机号码
export function getUserPhone(data) {
  return request({
    url: RoutBaseUrl + `/users/${data.id}`, // url '/offices/lite?params'
    method: 'GET',
    params: data
  })
}


/**
 * hlp: 2022-08-02 新增合同上传api
 */

export const uploadContractImageFile = (params, data) => request({
  url: `${configUrl.docUrl}/api-document/upload/exam-document`,
  method: 'POST',
  params,
  data
})

export const uploadContractFileCode = data => request({
  url: `${RoutBaseUrl}/service-agreements/single`,
  method: 'POST',
  data
})

export const deleteContractFile = data => request({
  url: `${RoutBaseUrl}/service-agreements/delete`,
  method: 'post',
  headers: {
    'Content-Type': 'application/json; charset=utf-8'
  },
  data
})


/**
 * 获取文件列表
 * @param business_id
 * @returns {*}
 */
export const getContractFileList = business_id => request({
  url: `${RoutBaseUrl}/service-agreements`,
  params: {
    business_id
  }
})

// 上传文件id列表
export const uploadFileIdList = data => request({
  url: `${RoutBaseUrl}/service-agreements`,
  method: 'POST',
  data
})

// 下载文件
export const downloadFile = params => request({
  url: `${configUrl.docUrl}/api-document/download/document-id`,
  responseType: 'blob',
  params
})

export const asyncInitialize = params => request({
  url: '/api-telemed/data-seed/async-initialize',
  method: 'post',
  data: params
})

/** ------ */
// 保存自定义参数相关配置
export const postConfigSystemParameterCustom = data => request({
  url: `${pacsRoutBaseUrl}/Config/SystemParameterCustom`,
  method: 'post',
  params: { SystemId: data.SystemId },
  data
})

// 获取自定义参数
export const getConfigSystemParameterCustom = params => request({
  url: `${pacsRoutBaseUrl}/Config/SystemParameterCustom`,
  method: 'get',
  params
})
// 获取教学授权产品
export function getTeachService(data) {
  return request({
    url: RoutBaseUrl +'/tenancies/teach-service', // url '/offices/lite?params'
    method: 'GET',
    params: data
  })
}
// 将教学系统转为正式
export function systemBecomeOfficial (params) {
  return request({
    url: RoutBaseUrl + '/service-centers/convert-official',
    method: 'POST',
    data: params
  })
}
// 远程教学  新增时 获取未被关联过的系统列表
export function getUnrelatedDeptTeachingSystemList (data) {
  return request({
    url: RoutBaseUrl + '/teaching-centers/unrelated-dept-teaching/system-page',
    method: 'GET',
    params: data
  })
}
// 远程教学-> 新增科室教学
export function addOfficeTeach (params) {
  return request({
    url: RoutBaseUrl + '/teaching-centers/system-related-dept-teaching ',
    method: 'POST',
    data: params
  })
}
// 远程教学  新增时 获取未被关联过的系统列表
export function getDeptTeachingServiceList (data) {
  return request({
    url: RoutBaseUrl + '/teaching-centers/dept-teaching-service/by-tenancy-id',
    method: 'GET',
  })
}
