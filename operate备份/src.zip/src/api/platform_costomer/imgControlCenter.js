import request from '@/utils/request'
const RoutBaseUrl = '/api-operate'
import qs from 'qs'
// 新增质控中心
export function addImgControlCenter (params) {
  return request({
    // headers: {
    //   'Content-Type': 'multipart/form-data'
    // },
    url: RoutBaseUrl + '/quality-centers',
    method: 'post',
    data: params
  })
}
// 编辑质控中心
export function updateImgControlCenter (data, id) {
  return request({
    // headers: {
    //   'Content-Type': 'multipart/form-data'
    // },
    url: RoutBaseUrl + '/quality-centers/update',
    method: 'post',
    data: data
    // baseURL: barse
  })
}
// 获取质控中心logo
export function getQualityCenterlogo (data) {
  return request({
    responseType: 'arraybuffer',
    url: RoutBaseUrl + '/quality-centers/logo',
    method: 'GET',
    params: data
  })
}
// 获取质控中心列表-不分页
export function getAllQualityCenter () {
  return request({
    url: RoutBaseUrl + '/quality-centers/list',
    method: 'GET',
    // params: data
  })
}
// 获取已选择的质控机构
export function getChoosedInstitute (data) {
  return request({
    url: RoutBaseUrl + '/quality-centers/institution/id',
    method: 'GET',
    params: data
  })
}

// 获取影像质控服务
export function getQualityCenterService () {
  return request({
    url: RoutBaseUrl + '/quality-centers/service',
    method: 'GET'
  })
}
// 删除质控中心
export function delQualityCenter (data) {
  return request({
    url: RoutBaseUrl + '/quality-centers/delete',
    method: 'post',
    data: data
  })
}
// 获取质控中心分页
export function getQualityCenterList (data) {
  return request({
    url: RoutBaseUrl + '/quality-centers',
    method: 'GET',
    params: data
  })
}
// 获取质控中心详情
export function getQualityCenterDetail (data) {
  return request({
    url: RoutBaseUrl + '/quality-centers/detail',
    method: 'GET',
    params: data
  })
}
// 不分页获取质控机构列表 /api/quality-centers/institution
export function getQualityCenterInstitute (data) {
  return request({
    url: RoutBaseUrl + '/quality-centers/institution',
    method: 'GET',
    params: data
  })
}
// 获取质控中心简洁详情
export function getQualityCenterBriefDetail (data) {
  return request({
    url: RoutBaseUrl + '/quality-centers/brief-detail',
    method: 'GET',
    params: data
  })
}
// 删除质控机构
export function delQualityInstitu (data) {
  return request({
    url: RoutBaseUrl + '/quality-centers/institution',
    method: 'DELETE',
    data: data
  })
}
// 获取所有机构
export function getInstitutionsList (data) {
  return request({
    url: RoutBaseUrl + '/institutions',
    method: 'GET',
    params: data
  })
}

// 获取所有机构
export function getInterfaceInstitutionsList (data) {
  return request({
    url: RoutBaseUrl + '/institutions',
    method: 'GET',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 添加质控机构
export function addQualityInstitute (params) {
  return request({
    url: RoutBaseUrl + '/quality-centers/institution',
    method: 'post',
    data: params
  })
}
