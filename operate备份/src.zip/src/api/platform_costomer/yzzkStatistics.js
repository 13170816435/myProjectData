import request from '@/utils/request'
import qs from 'qs'
const RoutBaseUrl = '/api-imgbd'

// 会诊申请量
export function getApplyAggreateList(code,data) {
  return request({
    url: RoutBaseUrl + `/dataapi/dynamic/invoke?code=${code}`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 会诊统计 查询条件
export function getConsultSelectList(code,data) {
  return request({
    url: RoutBaseUrl + `/dataapi/dynamic/invoke?code=${code}`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 诊断统计 查询条件
export function getDiagnosisSelectList(code,data) {
  return request({
    url: RoutBaseUrl + `/dataapi/dynamic/invoke?code=${code}`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 预约统计 查询条件
export function getReservationSelectList(code,data) {
  return request({
    url: RoutBaseUrl + `/dataapi/dynamic/invoke?code=${code}`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 诊断申请量
export function getApplyDiagnosisList(code,data) {
  return request({
    url: RoutBaseUrl + `/dataapi/dynamic/invoke?code=${code}`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 预约
export function getApplyReservationList(code,data) {
  return request({
    url: RoutBaseUrl + `/dataapi/dynamic/invoke?code=${code}`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取医生
export function getConsultDoctor(data) {
  return request({
    url: RoutBaseUrl + '/consult/doctors',
    method: 'get',
    params: data
  })
}
// 获取合作医院分页列表
export function getCooperationsList(data) {
  return request({
    url: RoutBaseUrl + '/service-cooperations',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 获取检查类型
export function getInspectClass(data) {
  return request({
    url: RoutBaseUrl + '/consult/doctors',
    method: 'get',
    params: data
  })
}
