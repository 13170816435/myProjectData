import request from '@/utils/request'
import qs from 'qs'
const fileName = '/api-operate'
const archiveName = '/api-archive'

// 获取导出列表
export function getLogList (data) {
  return request({
    url: fileName + '/tenancies/log-business-system',
    method: 'GET',
    params: data
  })
}

// 获取导出详情列表
export function getImportDetail (data) {
  return request({
    url: fileName + '/tenancies/log-business-system',
    method: 'GET',
    params: data
  })
}
// 保存导出权限设置
export function saveImoprtPermission (params) {
  return request({
    url: fileName + '/case-export-auth/save',
    method: 'post',
    data: params
  })
}
// 实际接口
// 分页获取导出申请列表
export function getCaseExportApplyList (data) {
  return request({
    url: fileName + '/case-exports/apply-page',
    method: 'GET',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 申请方的状态统计
export function getAuthApplyStateTotal () {
  return request({
    url: fileName + '/case-exports/apply-state-statistics',
    method: 'GET',
  })
}

// 导出申请列表 通过申请id  获取详情导出列表
export function getCaseExportListByApplyId (data) {
  return request({
    url: fileName + '/case-exports/apply-items',
    method: 'GET',
    params: data
  })
}

// 导出申请列表 详情里面的 审批流程
export function getCaseExportApplyLogs (data) {
  return request({
    url: fileName + '/case-exports/apply/logs',
    method: 'GET',
    params: data
  })
}
// 导出审核列表 通过审核id  获取详情导出列表
export function getCaseExportListByAuditId (data) {
  return request({
    url: fileName + '/case-exports/audit-items',
    method: 'GET',
    params: data
  })
}
// 病例导出审核   审核通过  审核不通过  
export function exportAudit (params) {
  return request({
    url: fileName + '/case-exports/audit',
    method: 'post',
    data: params
  })
}

// 审核取消
export function exportCancelAudit (params) {
  return request({
    url: fileName + '/case-exports/cancel',
    method: 'post',
    data: params
  })
}

// 分页获取导出申请列表
export function getCaseExportList (data) {
  return request({
    url: fileName + '/case-exports/apply-page',
    method: 'GET',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 获取授权 编辑列表
export function getCaseExportAuthEditList (data) {
  return request({
    url: fileName + '/case-export-auth/edit-list',
    method: 'GET',
    params: data
  })
}
// 获取所有的科室列表
export function getAllAuthOfficeList (data) {
  return request({
    url: fileName + '/case-export-auth/offices',
    method: 'GET',
    params: data
  })
}

// 获取当前审核人 有审核权限的科室
export function getUserAuditOfficeList (data) {
  return request({
    url: fileName + '/case-export-auth/user/offices',
    method: 'GET',
    params: data
  })
}

// 获取所有的审批人员
export function getAllAuditUsersList (data) {
  return request({
    url: fileName + '/case-export-auth/function-auth-users',
    method: 'GET',
    params: data
  })
}

// 获取所有的审批人员(某客户下的所有用户  客户下的所有审核人员都可以审核)
export function getCurTenancyAllCheckUserList(params) {
  return request({
    url: fileName + '/users/page/by-tenancy-id',
    method: 'post',
    data: params
  })
}

// 删除 审核授权
export function deleteExportAuth (params) {
  return request({
    url: fileName + '/case-export-auth/delete',
    method: 'post',
    data: params
  })
}
// 获取所有的审批人员
export function getExportAuthList (data) {
  return request({
    url: fileName + '/case-export-auth/list',
    method: 'GET',
    params: data
  })
}
// 获取审核方列表
export function getAuditList (data) {
  return request({
    url: fileName + '/case-exports/audit-page',
    method: 'GET',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 审核方的状态统计
export function getAuthStateTotal () {
  return request({
    url: fileName + '/case-exports/audit-state-statistics',
    method: 'GET',
  })
}

// 获取 是否有审核权限
export function getIsCheckAuth () {
  return request({
    url: fileName + '/case-export-auth/check-user-audit',
    method: 'GET',
  })
}

// 获取影像浏览地址
export function getViewUrl(data) {
  return request({
    url: configUrl.docUrl + '/documents/image-web-view-url',
    method: 'get',
    params: data,
    paramsSerializer: (params) => {
      return qs.stringify(params, { indices: false })
    },
  })
}
// 获取报告浏览地址
export function getReportViewUrl(data) {
  return request({
    url: archiveName + '/Documents/business-url',
    method: 'get',
    params: data,
    paramsSerializer: (params) => {
      return qs.stringify(params, { indices: false })
    },
  })
}

// 导出检查接口 （影像、报告、文件时，都放在压缩包里面）
export function importInspect (params) {
  return request({
    url: configUrl.docUrl + '/api-document/download/documentsasync',
    method: 'post',
    data: params,
  })
}

// 获取导出进度
export function getImportOutProgress (data) {
  return request({
    url: configUrl.docUrl + '/api-document/download/documentsasyncprogress',
    method: 'GET',
    params: data,
  })
}

// 获取导出的压缩包文件流  用于下载压缩包
export function downImportInspect (data) {
  return request({
    url: configUrl.docUrl + '/api-document/download/documentsasyncresult',
    method: 'GET',
    params: data,
    responseType: 'blob',
  })
}

// 获取是否有影像数据
export function getIsHasImageData (data) {
  return request({
    url: fileName + '/case-exports/allow-export/by-apply-id',
    method: 'GET',
    params: data,
  })
}
// 获取导出管理权限配置  界面配置的 最多导出影像数
export function getImportImgCount () {
  return request({
    url: fileName + '/case-export-auth/max-download-number',
    method: 'GET',
    //params: data,
  })
}