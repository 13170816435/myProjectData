import request from '@/utils/request'
import qs from 'qs'
const RoutBaseUrl = '/api-operate'
// const RoutBaseUrl = '/api-ability'
// 客户管理下的 权重设置
// 获取主索引规则列表
export function getV15PrimaryRulesList () {
  return request({
    url: RoutBaseUrl + '/common/empis/v15/rules',
    method: 'GET'
  })
}
// 保存主索引规则
export function saveV15PrimaryRules (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/v15/rules',
    method: 'post',
    data: data
  })
}
// 获取主索引规则列表
export function getV15ThresholdsVal () {
  return request({
    url: RoutBaseUrl + '/common/empis/v15/rules/thresholds',
    method: 'GET'
  })
}
// 保存主索引规则
export function saveV15ThresholdsVal (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/v15/rules/thresholds',
    method: 'post',
    data: data
  })
}
// 平台运营下 的 权重设置
// 获取主索引规则列表
export function getPrimaryRulesList () {
  return request({
    url: RoutBaseUrl + '/common/empis/rules',
    method: 'GET'
  })
}
// 保存主索引规则
export function savePrimaryRules (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/rules',
    method: 'post',
    data: data
  })
}
// 获取主索引规则列表
export function getThresholdsVal () {
  return request({
    url: RoutBaseUrl + '/common/empis/rules/thresholds',
    method: 'GET'
  })
}
// 保存主索引规则
export function saveThresholdsVal (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/rules/thresholds',
    method: 'post',
    data: data
  })
}
// 重置权重、阈值
export function resetEmpiRules () {
  return request({
    url: RoutBaseUrl + '/common/empis/rules/reset ',
    method: 'GET'
  })
}
// 获取患者主索引列表
export function getPrimaryIndexList (data) {
  return request({
    url: RoutBaseUrl + '/common/empis',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false });
    }
  })
}
// 获取主索引自定义列
export function getPrimaryIndexColumn (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/custom-column',
    method: 'GET',
    params: data,
  })
}
// 保存主索引自定义列
export function savePrimaryIndexColumn (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/mpi-custom-column',
    method: 'post',
    data: data
  })
}
// 保存交叉索引自定义列
export function savePixPrimaryIndexColumn (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/pix-custom-column',
    method: 'post',
    data: data
  })
}
// 获取患者交叉主索引列表
export function getPixPrimaryIndexList (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/pix',
    method: 'GET',
    params: data
  })
}
// 获取系统分类列表
export function getDomainSystem (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/domains',
    method: 'GET',
    params: data
  })
}
// 获取标识域列表
export function getRealmList (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/domains',
    method: 'GET',
    params: data
  })
}
// 删除更新日志
export function delThisRealm (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/domains/delete',
    method: 'post',
    data: data
  })
}
// 新增标识域
export function addOneRealm (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/domains',
    method: 'post',
    data: data
  })
}
// 查看单个标识域详情
export function getRealmDeatil (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/domains/detail',
    method: 'get',
    params: data
  })
}
// 是否可以删除当前标识域
export function isCanDelDomains (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/domains/del-check',
    method: 'get',
    params: data
  })
}
// 查询(或换取正式)患者主索引信息
export function getPrimaryIndexInfor (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/detail',
    method: 'get',
    params: data
  })
}
// 查询主索引关联交叉索引信息
export function getRelationPixs (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/mpi-relation-pixs',
    method: 'get',
    params: data
  })
}
// 查询主索引日志(状态跟踪)
export function getMpiLogs (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/mpi-logs',
    method: 'get',
    params: data
  })
}
// 编辑交叉索引信息
export function updatePixPrimaryInfor (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/pix',
    method: 'post',
    data: data
  })
}
// 编辑主索引信息
export function updatePrimaryInfor (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/modify',
    method: 'post',
    data: data
  })
}
// 根据身份证号和医保卡号 查询出跟患者相似的患者
export function getCommonPatient (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/list',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 获取交叉索引详情
export function getPixPrimaryDetail (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/pix/detail',
    method: 'get',
    params: data
  })
}
// 合并主索引
export function mergePrimaryIndex (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/merge',
    method: 'post',
    data: data
  })
}
// 启用主索引
export function enableCurPrimaryIndex (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/enable',
    method: 'post',
    data: data
  })
}
// 作废主索引
export function disableCurPrimaryIndex (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/disable',
    method: 'post',
    data: data
  })
}
// 拆分主索引
export function splitCurPrimaryIndex (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/split',
    method: 'post',
    data: data
  })
}
// 查询主索引合并记录
export function getMpiMergeLogs (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/mpi-merge-logs',
    method: 'get',
    params: data
  })
}
// 匹配主索引信息(仅用于合并流程)，不分页
export function getEmpisSearch (data) {
  return request({
    url: RoutBaseUrl + '/common/empis/search',
    method: 'get',
    params: data
  })
}