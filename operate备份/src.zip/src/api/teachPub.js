import request from '@/utils/request';
import qs from 'qs';
const medRoutBaseUrl = '/api-teaching';
// 获取短信模板
export function getTeachPublicSmsTemplate (params) {
  return request({
    url: `${medRoutBaseUrl}/teach-public/sms/template`,
    method: 'get',
    params
  })
}
// 发送学习未达标短信
export function postTeachPublicSmsSendNotStandard (data) {
  return request({
    url: `${medRoutBaseUrl}/teach-public/sms/send/not-standard`,
    method: 'post',
    data
  })
}