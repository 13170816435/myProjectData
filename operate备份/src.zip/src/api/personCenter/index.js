import request from '@/utils/request'
// import qs from 'qs'
const fileName = '/api-operate'

// 修改用户详情
export function putPersonalInfo (params) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: fileName + '/users/personal-info/update',
    method: 'post',
    data: params
  })
}
// 获取个人中心账号信息
export function getPersonalInfo () {
  return request({
    url: fileName + '/users/personal-info',
    method: 'get'
  })
}
// 删除用户头像
export function delUserAvatar (params) {
  return request({
    url: fileName + '/users/avatar/delete',
    method: 'post',
    data: params
  })
}
// 获取安全设置
export function getSafetySet () {
  return request({
    url: fileName + '/users/personal-safety-info',
    method: 'get'
  })
}
// 获取验证码
export function getCode (data) {
  return request({
    url: fileName + '/users/sms/verify/code',
    method: 'POST',
    data: data
  })
}
// 通过已登录用户的手机号获取验证码
export function getCodeByUserPhone (data) {
  return request({
    url: fileName + '/users/verify-code',
    method: 'get'
  })
}
// 修改手机号
export function putPhone (params) {
  return request({
    url: fileName + '/users/phone/update',
    method: 'post',
    data: params
  })
}
// 绑定手机号
export function bindPhone (params) {
  return request({
    url: fileName + '/users/bind-phone',
    method: 'post',
    data: params
  })
}

// 修改邮箱
export function putEmail (params) {
  return request({
    url: fileName + '/users/email/update',
    method: 'post',
    data: params
  })
}
// 获取角色
export function getRoleList () {
  return request({
    url: fileName + '/users/role',
    method: 'get'
  })
}
// 修改用户默认菜单配置
export function putDefaultMenuConfig (params) {
  return request({
    url: fileName + '/users/default-menu-config/update',
    method: 'post',
    data: params
  })
}
// 获取密码规则
export function getPasswordStrength () {
  return request({
    url: fileName + '/tenancies/password-strength',
    method: 'get'
  })
}