// import request from '@/utils/dataCockpitRequest'
import request from '@/utils/request'
const RoutBaseUrl = '/api-operate'
// 获取远程医疗有关的所有统计
export function getTelemedicineTotal(data) {
  return request({
    url: RoutBaseUrl + '/tenancies/telemed-data-cockpit',
    method: 'get',
    params: data
  })
}
// 修改大屏页面标题
export function updatePageTitle(data){
  return request({
    url:  RoutBaseUrl + '/tenancies/data-cockpit-settings',
    method: 'POST',
    data: data
  })
}