// import request from '@/utils/dataCockpitRequest'
import request from '@/utils/request'
// const RoutBaseUrl = '/api-operate'
const RoutBaseUrl = '/api-telemed'
// 获取概览统计
export function getGenneralTotal(data) {
  return request({
    url: RoutBaseUrl + `/cockpit/wh/overview/${data.time_type}`,
    method: 'get',
    //params: data
  })
}
// 获取放射的统计
export function getRisTotal(data) {
  return request({
    url: RoutBaseUrl + `/cockpit/wh/ris/${data.time_type}`,
    method: 'get',
    //params: data
  })
}
// 获取超声的统计
export function getUsTotal(data) {
  return request({
    url: RoutBaseUrl + `/cockpit/wh/uis/${data.time_type}`,
    method: 'get',
    //params: data
  })
}
// 获取心电的统计
export function getEcgTotal(data) {
  return request({
    url: RoutBaseUrl + `/cockpit/wh/ecg/${data.time_type}`,
    method: 'get',
    //params: data
  })
}
// 获取远程会诊的统计
export function getConsultTotal(data) {
  return request({
    url: RoutBaseUrl + `/cockpit/wh/consult/${data.time_type}`,
    method: 'get',
    params: data
  })
}
// 获取病理的统计
export function getPisTotal(data) {
  return request({
    url: RoutBaseUrl + `/cockpit/wh/pis/${data.time_type}`,
    method: 'get',
    //params: data
  })
}

export function getTelemedicineTotal(data) {
  return request({
    url: RoutBaseUrl + '/tenancies/telemed-data-cockpit',
    method: 'get',
    //params: data
  })
}
// 修改大屏页面标题
export function updatePageTitle(data){
  return request({
    url:  RoutBaseUrl + '/cockpit/wh/config/update',
    method: 'POST',
    data: data
  })
}