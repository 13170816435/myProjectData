import request from '@/utils/dataCockpitRequest'
const RoutBaseUrl = '/customer/ygt'
// 检查工作量
export function getExamWorked(data) {
  return request({
    url: RoutBaseUrl + '/examWorked',
    method: 'POST',
    data: data
  })
}
// 检查费用
export function getExamCost(data) {
  return request({
    url: RoutBaseUrl + '/examCost',
    method: 'POST',
    data: data
  })
}

// 工作质量--危急值
export function getCrisisNum(data) {
  return request({
    url: RoutBaseUrl + '/crisisNum',
    method: 'POST',
    data: data
  })
}
// 工作质量--阳性率
export function getPositiveRatio(data) {
  return request({
    url: RoutBaseUrl + '/positiveRatio',
    method: 'POST',
    data: data
  })
}
// 医共体概览--医疗机构
export function getOrgLevel(data) {
  return request({
    url: RoutBaseUrl + '/orgLevel',
    method: 'POST',
    data: data
  })
}
// 医共体概览--医护人员
export function getDocType(data) {
  return request({
    url: RoutBaseUrl + '/docType',
    method: 'POST',
    data: data
  })
}
// 医共体概览--医疗设备
export function getEquipmentType(data) {
  return request({
    url: RoutBaseUrl + '/equipmentType',
    method: 'POST',
    data: data
  })
}
// 检查检验量-- 科室分组
export function getShareNumByDep(data) {
  return request({
    url: RoutBaseUrl + '/shareNumByDep',
    method: 'POST',
    data: data
  })
}
// 检查检验量-- 医疗机构分组
export function getShareNumByOrg(data) {
  return request({
    url: RoutBaseUrl + '/shareNumByOrg',
    method: 'POST',
    data: data
  })
}
// 存储量--总使用情况
export function getStorageSum(data) {
  return request({
    url: RoutBaseUrl + '/storageSum',
    method: 'POST',
    data: data
  })
}
// 存储量-- 当前时间维度科室占比
export function getStorageByDep(data) {
  return request({
    url: RoutBaseUrl + '/storageByDep',
    method: 'POST',
    data: data
  })
}
// 存储量-- 当前时间维度机构分组
export function getStorageByOrg(data) {
  return request({
    url: RoutBaseUrl + '/storageByOrg',
    method: 'POST',
    data: data
  })
}
// 调阅量--不同终端分组占比
export function getLookByClient(data) {
  return request({
    url: RoutBaseUrl + '/lookByClient',
    method: 'POST',
    data: data
  })
}
// 调阅量--用户分组
export function getLookByUserAndDate(data) {
  return request({
    url: RoutBaseUrl + '/lookByUserAndDate',
    method: 'POST',
    data: data
  })
}
// 远程医疗--远程服务量
export function getLongType(data) {
  return request({
    url: RoutBaseUrl + '/longType',
    method: 'POST',
    data: data
  })
}
// 远程医疗--诊断占比科室分组
export function getDiagnoseRatio(data) {
  return request({
    url: RoutBaseUrl + '/diagnoseRatio',
    method: 'POST',
    data: data
  })
}
// 远程医疗--会诊占比科室分组
export function getConsultationRatio(data) {
  return request({
    url: RoutBaseUrl + '/consultationRatio',
    method: 'POST',
    data: data
  })
}
// 修改大屏页面标题
export function updatePageTitle(data){
  return request({
    url:  '/tenancy/permission/titleSave',
    method: 'POST',
    data: data
  })
}
// 查询大屏页面标题
export function getPageTitle(data){
  return request({
    url:  '/tenancy/permission/titleRead',
    method: 'POST',
    data: data
  })
}
