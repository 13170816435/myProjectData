import request from '@/utils/dataCockpitRequest'
const RoutBaseUrl = '/customer/wjw'
const PictureUrl = '/check/picture'
// 检查工作量/检查费用--医共体分组
export function getExamAndCost(data) {
  return request({
    url: RoutBaseUrl + '/examAndCost',
    method: 'POST',
    data: data
  })
}
// 检查工作量/检查费用--某医共体下科室分组
export function getExamAndCostByDep(data) {
  return request({
    url: RoutBaseUrl + '/examAndCostByDep',
    method: 'POST',
    data: data
  })
}
// 工作质量--危急值 医共体分组
export function getCrisisNum(data) {
  return request({
    url: RoutBaseUrl + '/crisisNum',
    method: 'POST',
    data: data
  })
}
// 工作质量--危急值 科室分组
export function getCrisisNumByDep(data) {
  return request({
    url: RoutBaseUrl + '/crisisNumByDep',
    method: 'POST',
    data: data
  })
}
// 工作质量--阳性率 医共体分组
export function getPositiveRatio(data) {
  return request({
    url: RoutBaseUrl + '/positiveRatio',
    method: 'POST',
    data: data
  })
}
// 工作质量--阳性率 科室分组
export function getPositiveRatioByDep(data) {
  return request({
    url: RoutBaseUrl + '/positiveRatioByDep',
    method: 'POST',
    data: data
  })
}
// 区域概览
export function getAreaView(data) {
  return request({
    url: RoutBaseUrl + '/areaView',
    method: 'POST',
    data: data
  })
}
// 数据共享 -- 检查检验量 医共体分组
export function getShareExamNum(data) {
  return request({
    url: RoutBaseUrl + '/shareExamNum',
    method: 'POST',
    data: data
  })
}
// 数据共享 -- 检查检验量 机构分组
export function getShareExamNumByOrg(data) {
  return request({
    url: RoutBaseUrl + '/shareExamNumByOrg',
    method: 'POST',
    data: data
  })
}
// 存储量 -- 总使用情况
export function getStorageSum(data) {
  return request({
    url: RoutBaseUrl + '/storageSum',
    method: 'POST',
    data: data
  })
}
// 存储量 -- 科室分组占比情况
export function getStorageUsageByDep(data) {
  return request({
    url: RoutBaseUrl + '/storageUsageByDep',
    method: 'POST',
    data: data
  })
}
// 存储量 -- 机构分组
export function getStorageUsageByOrg(data) {
  return request({
    url: RoutBaseUrl + '/storageUsageByOrg',
    method: 'POST',
    data: data
  })
}
// 调阅量 -- 不同用户调阅量
export function getViewByUser(data) {
  return request({
    url: RoutBaseUrl + '/viewByUser',
    method: 'POST',
    data: data
  })
}
// 调阅量 -- 不同终端调阅量
export function getViewByClient(data) {
  return request({
    url: RoutBaseUrl + '/viewByClient',
    method: 'POST',
    data: data
  })
}
// 调阅量 -- 机构分组概况
export function getViewByOrg(data) {
  return request({
    url: RoutBaseUrl + '/viewByOrg',
    method: 'POST',
    data: data
  })
}
// 患者流量 -- 时段分布--医共体分组
export function getHourByYiGongTi(data) {
  return request({
    url: RoutBaseUrl + '/hourByYiGongTi',
    method: 'POST',
    data: data
  })
}
// 患者流量 -- 时段分布--科室分组
export function getHourByDep(data) {
  return request({
    url: RoutBaseUrl + '/hourByDep',
    method: 'POST',
    data: data
  })
}
// 患者流量 -- 年龄分布--医共体分组
export function getAgeByYiGongTi(data) {
  return request({
    url: RoutBaseUrl + '/ageByYiGongTi',
    method: 'POST',
    data: data
  })
}
// 患者流量 -- 年龄分布--科室分组
export function getAgeByDep(data) {
  return request({
    url: RoutBaseUrl + '/ageByDep',
    method: 'POST',
    data: data
  })
}
// 远程医疗 -- 远程服务量
export function getRemote(data) {
  return request({
    url: RoutBaseUrl + '/remote',
    method: 'POST',
    data: data
  })
}
// 远程医疗 -- 科室分组诊断分布图
export function getDiagnoseByDep(data) {
  return request({
    url: RoutBaseUrl + '/diagnoseByDep',
    method: 'POST',
    data: data
  })
}
// 远程医疗 -- 会诊分布图
export function getConsultationByDep(data) {
  return request({
    url: RoutBaseUrl + '/consultationByDep',
    method: 'POST',
    data: data
  })
}

// 检查画像  医共体检查量按年分组
export function getExamYearByYiGongTi(data) {
  return request({
    url: PictureUrl + '/examYearByYiGongTi',
    method: 'POST',
    data: data
  })
}
// 检查画像  科室检查量按年分组
export function getExamYearByDep(data) {
  return request({
    url: PictureUrl + '/examYearByDep',
    method: 'POST',
    data: data
  })
}
// 检查画像   医共体检查量占比
export function getExamYiGongTiRatio(data) {
  return request({
    url: PictureUrl + '/examYiGongTiRatio',
    method: 'POST',
    data: data
  })
}
// 检查画像  科室检查量占比
export function getExamDepRatio(data) {
  return request({
    url: PictureUrl + '/examDepRatio',
    method: 'POST',
    data: data
  })
}
// 检查画像   就诊类别检查量占比
export function getExamPatientRatio(data) {
  return request({
    url: PictureUrl + '/examPatientRatio',
    method: 'POST',
    data: data
  })
}
// 检查画像   患者流量分布曲线
export function getExamByHour(data) {
  return request({
    url: PictureUrl + '/examByHour',
    method: 'POST',
    data: data
  })
}
// 检查画像   查患者年龄分布
export function getExamByAge(data) {
  return request({
    url: PictureUrl + '/examByAge',
    method: 'POST',
    data: data
  })
}
// 检查画像   检查患者性别分布
export function getExamBySex(data) {
  return request({
    url: PictureUrl + '/examBySex',
    method: 'POST',
    data: data
  })
}
