import request from '@/utils/dataCockpitRequest'
const RoutBaseUrl = '/dep/ygt'

// 检查量情况
export function getExamNum (data) {
  return request({
    url: RoutBaseUrl + '/examNum',
    method: 'POST',
    data: data
  })
}
// 预约量情况
export function getBookNum (data) {
  return request({
    url: RoutBaseUrl + '/bookNum',
    method: 'POST',
    data: data
  })
}
// 危急值报告
export function getCrisisReport (data) {
  return request({
    url: RoutBaseUrl + '/crisisReport',
    method: 'POST',
    data: data
  })
}
// 检查费用情况
export function getExamCost (data) {
  return request({
    url: RoutBaseUrl + '/examCost',
    method: 'POST',
    data: data
  })
}
// 机房排队情况
export function getRoomQueue (data) {
  return request({
    url: RoutBaseUrl + '/roomQueue',
    method: 'POST',
    data: data
  })
}
// 工作进展
export function getWorked (data) {
  return request({
    url: RoutBaseUrl + '/worked',
    method: 'POST',
    data: data
  })
}
// 报告阳性率统计——按检查类型统计
export function getPositiveRatioByExamType (data) {
  return request({
    url: RoutBaseUrl + '/positiveRatioByExamType',
    method: 'POST',
    data: data
  })
}
// 报告阳性率统计——按医院统计
export function getPositiveRatioByOrg (data) {
  return request({
    url: RoutBaseUrl + '/positiveRatioByOrg',
    method: 'POST',
    data: data
  })
}
