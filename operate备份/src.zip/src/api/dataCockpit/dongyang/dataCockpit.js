import request from '@/utils/dataCockpitRequest'
const RoutBaseUrl = '/dpManagement'

// 检查量分布情况
export function getExamNum(data) {
  return request({
    url: RoutBaseUrl + '/examNum',
    method: 'POST',
    data: data
  })
}
// 存储量分布情况
export function getStorageTotal(data) {
  return request({
    url: RoutBaseUrl + '/storageTotal',
    method: 'POST',
    data: data
  })
}
// 调阅量分布情况
export function getViewNum(data) {
  return request({
    url: RoutBaseUrl + '/viewNum',
    method: 'POST',
    data: data
  })
}
// 接入机构
export function getAccessInstitution(data) {
  return request({
    url: RoutBaseUrl + '/orgLevelList',
    method: 'GET',
    params: data
  })
}
// 平台概览
export function getSummary(data) {
  return request({
    url: RoutBaseUrl + '/summary',
    method: 'POST',
    data: data
  })
}
// 机构地图分布
export function getOrgDistribute(data) {
  return request({
    url: RoutBaseUrl + '/orgDistribute',
    method: 'POST',
    data: data
  })
}
// 阳性率
export function getPositiveRatio(data) {
  return request({
    url: RoutBaseUrl + '/positiveRatio',
    method: 'POST',
    data: data
  })
}
// 患者年龄分布
export function getPatientNumByOld(data) {
  return request({
    url: RoutBaseUrl + '/patientNumByOld',
    method: 'POST',
    data: data
  })
}
// 患者类别分布
export function getPatientRatioByClass(data) {
  return request({
    url: RoutBaseUrl + '/patientRatioByClass',
    method: 'POST',
    data: data
  })
}
// 患者性别分布
export function getPatientRatioBySex(data) {
  return request({
    url: RoutBaseUrl + '/patientRatioBySex',
    method: 'POST',
    data: data
  })
}
// 检查量趋势
export function getExamNumByMonth(data) {
  return request({
    url: RoutBaseUrl + '/examNumByMonth',
    method: 'POST',
    data: data
  })
}
// 存储量趋势
export function getStorageTotalByMonth(data) {
  return request({
    url: RoutBaseUrl + '/storageTotalByMonth',
    method: 'POST',
    data: data
  })
}
// 科室检查量趋势
export function getOfficeExamNum(data) {
  return request({
    url: RoutBaseUrl + '/examMonthByDep',
    method: 'POST',
    data: data
  })
}
// 调阅量趋势
export function getViewNumByMonth(data) {
  return request({
    url: RoutBaseUrl + '/viewNumByMonth',
    method: 'POST',
    data: data
  })
}
// 修改大屏页面标题
export function updatePageTitle(data){
  return request({
    url:  '/tenancy/permission/titleSave',
    method: 'POST',
    data: data
  })
}
// 查询大屏页面标题
export function getPageTitle(data){
  return request({
    url:  '/tenancy/permission/titleRead',
    method: 'POST',
    data: data
  })
}
