import request from '@/utils/dataCockpitRequest'
const api = '/board'

// 今日采集效率
export function getCollectEffToday() {
  return request({
    url: api + '/collectEffToday',
    method: 'get',
  })
}

// 2021年省平台下载量和调阅量趋势
export function getDownloadAndViewNum() {
  return request({
    url: api + '/downloadAndViewNum',
    method: 'get',
  })
}

// 2021年数字影像缴费量趋势
export function getPayTrend() {
  return request({
    url: api + '/payTrend',
    method: 'get',
  })
}

// 平台概览
export function getOverview() {
  return request({
    url: api + '/overview',
    method: 'get',
  })
}

// 今日动态
export function getOverviewToday() {
  return request({
    url: api + '/overviewToday',
    method: 'get',
  })
}

// 二级以上医疗机构今日数据
export function getBusinessDataToday() {
  return request({
    url: api + '/businessDataToday',
    method: 'get',
  })
}

// 近30天内放射互认量、检查量占比--市级
export function getExamRatioByCity() {
  return request({
    url: api + '/examRatioByCity',
    method: 'get',
  })
}

// 近30天内放射互认量、检查量占比--区县
export function getExamRatioByCounty() {
  return request({
    url: api + '/examRatioByCounty',
    method: 'get',
  })
}

// 2021年检查量分布--检查科室分布
export function getExamNumByDep() {
  return request({
    url: api + '/examNumByDep',
    method: 'get',
  })
}


// 2021年检查量分布--检查类型分布
export function getExamNumByExamType() {
  return request({
    url: api + '/examNumByExamType',
    method: 'get',
  })
}

// 修改大屏页面标题
export function updatePageTitle(data){
  return request({
    url:  api + '/titleSave',
    method: 'POST',
    data: data
  })
}
// 查询大屏页面标题
export function getPageTitle(data){
  return request({
    url: api + '/titleRead',
    method: 'POST',
    data: data
  })
}
