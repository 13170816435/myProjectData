import request from '@/utils/dataCockpitRequest'
const api = '/cloud/images'
// 市级 身份证
export function getIDNumberByCity(data) {
  return request({
    url: api + '/iDNumberByCity',
    method: 'POST',
    data: data
  })
}
// 市级 电话号码
export function getPhoneNumberByCity(data) {
  return request({
    url: api + '/phoneNumberByCity',
    method: 'POST',
    data: data
  })
}

// 市级 出生日期
export function getBirthDayByCity(data) {
  return request({
    url: api + '/birthDayByCity',
    method: 'POST',
    data: data
  })
}
// 区县 身份证
export function getIDNumberByCounty(data) {
  return request({
    url: api + '/iDNumberByCounty',
    method: 'POST',
    data: data
  })
}
// 区县 电话号码
export function getPhoneNumberByCounty(data) {
  return request({
    url: api + '/phoneNumberByCounty',
    method: 'POST',
    data: data
  })
}

// 区县 出生日期
export function getBirthDayByCounty(data) {
  return request({
    url: api + '/birthDayByCounty',
    method: 'POST',
    data: data
  })
}

// 省平台下载量
export function getDownLoad(data) {
  return request({
    url: api + '/downLoad',
    method: 'POST',
    data: data
  })
}
// 各维度总数
export function getSummary(data) {
  return request({
    url: api + '/summary',
    method: 'POST',
    data: data
  })
}
// 机构分布地图
export function getOrgDistribute(data) {
  return request({
    url: api + '/orgDistribute',
    method: 'POST',
    data: data
  })
}
// 市级 放射检查阳性率
export function getPositiveRatioByCity(data) {
  return request({
    url: api + '/positiveRatioByCity',
    method: 'POST',
    data: data
  })
}
// 区县 放射检查阳性率
export function getPositiveRatioByCounty(data) {
  return request({
    url: api + '/positiveRatioByCounty',
    method: 'POST',
    data: data
  })
}
// 调阅量走势
export function getViewNum(data) {
  return request({
    url: api + '/viewNum',
    method: 'POST',
    data: data
  })
}
// 市级 放射检查量
export function getExamNumByCity(data) {
  return request({
    url: api + '/examNumByCity',
    method: 'POST',
    data: data
  })
}
// 区县 放射检查量
export function getExamNumByCounty(data) {
  return request({
    url: api + '/examNumByCounty',
    method: 'POST',
    data: data
  })
}
// 修改大屏页面标题
export function updatePageTitle(data){
  return request({
    url:  '/tenancy/permission/titleSave',
    method: 'POST',
    data: data
  })
}
// 查询大屏页面标题
export function getPageTitle(data){
  return request({
    url:  '/tenancy/permission/titleRead',
    method: 'POST',
    data: data
  })
}
