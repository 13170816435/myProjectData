import request from '@/utils/request'
import qs from 'qs'
const fileName = '/api-operate'
const abilityUrl = '/api-operate'
// 平台运营-> 运维用户
//获取用户列表
export function getOperateUserList (data) {
  return request({
    url: fileName + '/users/from-all-tenancies',
    method: 'get',
    params: data
  })
}
//获取短信记录列表
export function getMessageRecordList (data) {
  return request({
    url: abilityUrl + '/common/sms/pagination-list',
    method: 'get',
    params: data
  })
}
// 重发单条短信
export function resendMessage (data) {
  return request({
    url: abilityUrl + '/common/sms/resend',
    method: 'post',
    data: data
  })
}
// 验证登录密码是否正确
export function verifyLoginPassword (data) {
  return request({
    url: fileName + '/users/verify-password',
    method: 'post',
    data: data
  })
}
// 重发多条短信
export function resendMoreMessage (data) {
  return request({
    url: fileName + '/log-audits',
    method: 'post',
    data: data
  })
}
// 短信记录详情
export function getMessageRecordDetail (id) {
  return request({
    url: abilityUrl + `/common/sms/${id}`,
    method: 'get'
  })
}
// 获取日志审计列表
export function getLogAuditList (data) {
  return request({
    url: fileName + '/log-audits',
    method: 'get',
    params: data
  })
}
// 获取日志列表
export function getLogList (data, tenancyId) {
  return request({
    headers: {
      'ew-tenancy-id': tenancyId
    },
    url: fileName + '/log-audits/log',
    method: 'get',
    params: data
  })
}

// 添加日志审计
export function readyAddLogAudit (data) {
  return request({
    url: fileName + '/log-audits',
    method: 'post',
    data: data
  })
}
// 获取日志审计详情
export function getLogAuditDetail (data) {
  return request({
    url: fileName + '/log-audits/detail',
    method: 'get',
    params: data
  })
}
// 保存日志审计结论
export function saveConclusion (data) {
  return request({
    url: fileName + '/log-audits/conclusion',
    method: 'post',
    data: data
  })
}
// 工具账号
// 获取所属系统
export function getBusinessParam (data) {
  return request({
    url: fileName + '/commons/client/business',
    method: 'get',
    params: data
  })
}
// 获取工具账号列表
export function getToolAccountList (data) {
  return request({
    url: fileName + '/users/client-page',
    method: 'get',
    params: data
  })
}
// 修改工具账号密码
export function updateToolAccountPassword (data) {
  return request({
    url: fileName + '/users/client/password/update',
    method: 'post',
    data: data
  })
}
// 修改工具账号状态
export function changeToolAccountState (data) {
  return request({
    url: fileName + '/users/from-all-tenancy/state/update',
    method: 'post',
    data: data
  })
}
// 获取工具账号详情
export function getToolAccountDetail (id) {
  return request({
    url: fileName + `/users/client/${id}`,
    method: 'get'
  })
}
// 添加工具账号
export function readyAddToolAccount (data) {
  return request({
    url: fileName + '/users/client',
    method: 'post',
    data: data
  })
}
// 编辑工具账号
export function updateToolAccount (data) {
  return request({
    url: fileName + '/users/client/update',
    method: 'post',
    data: data
  })
}
// 删除工具账号
export function delToolAccount (id) {
  return request({
    url: fileName + `/users/client/${id}/delete`,
    method: 'post'
  })
}
// 获取运营版本管理列表
export function getOperateVersionList (id) {
  return request({
    url: fileName + '/system-versions',
    method: 'get'
  })
}
// 获取数据初始化时 版本列表
export function getInitVersionList () {
  return request({
    url: fileName + '/tenancies/init-data-version',
    method: 'get'
  })
}
// 获取数据升级时 版本列表
export function getUpgradeVersionList () {
  return request({
    url: fileName + '/tenancies/upgrade-data-version',
    method: 'get'
  })
}
// 确定数据初始化
export function sureInitData (data) {
  return request({
    url: fileName + '/tenancies/init-data',
    method: 'post',
    data: data
  })
}
// 确定数据升级
export function sureUpgradeData (data) {
  return request({
    url: fileName + '/tenancies/upgrade-data',
    method: 'post',
    data: data
  })
}
// 获取数据库版本管理列表
export function getDataBaseLastVersionList () {
  return request({
    url: fileName + '/tenancies/database-latest-version',
    method: 'get'
  })
}
// 获取客户数据库详情
export function getTenancyDataBaseDetail (data) {
  return request({
    url: fileName + '/tenancies/database-upgrade/detail',
    method: 'get',
    params: data
  })
}
// 获取客户数据库更新日志
export function getTenancyDataBaseLogList (data) {
  return request({
    url: fileName + '/tenancies/database-log/pagination',
    method: 'get',
    params: data
  })
}
// 获取数据库脚本初始化状态列表
export function getInitAndUpgradeList (data) {
  return request({
    url: fileName + '/tenancies/script-init-list',
    method: 'get',
    params: data
  })
}
// 分页获取数据升级日志
export function getUpgradeLogList (data) {
  return request({
    url: fileName + '/tenancies/script-log/pagination',
    method: 'get',
    params: data
  })
}
// 获取数据库升级脚本预览
export function getDataBasePreview (data) {
  return request({
    url: fileName + '/tenancies/database-script-preview',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 更新数据库（crm、单个客户、多个客户）
export function updateCurDataBase (data) {
  return request({
    url: fileName + '/tenancies/upgrade-database/update',
    method: 'post',
    data: data
  })
}
// 获取更新内容
export function getDataBaseUpdateContent (data) {
  return request({
    url: fileName + '/tenancies/database-upgrade-script',
    method: 'get',
    params: data
  })
}

// 分页获取系统版本更新日志
export function getVersionLogList (data) {
  return request({
    url: fileName + '/tenancies/database-upgrade/pagination',
    method: 'get',
    params: data
  })
}
// 删除更新日志
export function delVersionLog (data) {
  return request({
    url: fileName + '/system-versions/log/delete',
    method: 'post',
    data: data
  })
}
// 添加系统版本更新记录
export function addVersionLog (data) {
  return request({
    url: fileName + '/system-versions/log',
    method: 'post',
    data: data
  })
}
// 获取系统版本详情
export function getVersionDetail (data) {
  return request({
    url: fileName + '/system-versions/detail',
    method: 'get',
    params: data
  })
}
// 获取系统类型
export function getSystemOption () {
  return request({
    url: fileName + '/system-versions/options',
    method: 'get',
  })
}
// 获取数据库列表(不分页)
export function getDataBaseList () {
  return request({
    url: fileName + '/system-versions/options',
    method: 'get',
  })
}
//获取运维人员的 id
export function getOperationUserId () {
  return request({
    url: fileName + '/authority-groups/maintenance',
    method: 'get'
  })
}
// 获取存档注册 服务列表
export function getArchiveServiceList (data) {
  return request({
    url: fileName + '/archives',
    method: 'GET',
    params: data
  })
}
// 新增存档服务
export function addArchiveService (data) {
  return request({
    url: fileName + '/archives',
    method: 'post',
    data: data
  })
}
// 编辑存档服务
export function updateArchiveService (data) {
  return request({
    url: fileName + '/archives/update',
    method: 'post',
    data: data
  })
}
// 删除 存档服务
export function DeleteArchiveService (data) {
  return request({
    url: fileName + '/archives/delete',
    method: 'post',
    data: data
  })
}
// 获取存档服务客户列表
export function getServiceTenancyList (data) {
  return request({
    url: fileName + '/archives/tenancy-pagination',
    method: 'GET',
    params: data
  })
}
// 新增服务客户
export function beganAddServiceTenancy (data) {
  return request({
    url: fileName + '/archives/tenancy',
    method: 'post',
    data: data
  })
}
// 删除 服务客户
export function DeleteServiceTenancy (data) {
  return request({
    url: fileName + '/archives/tenancy/delete',
    method: 'post',
    data: data
  })
}
// 获取存档服务基本参数详情
export function getArchivesBasicParams (data) {
  return request({
    url: fileName + '/archives/param-basic-detail',
    method: 'GET',
    params: data
  })
}
// 保存存档服务基本参数
export function saveArchivesBasicParams (data) {
  return request({
    url: fileName + '/archives/param-basic',
    method: 'post',
    data: data
  })
}
// 获取工具账号基本详情
export function getClientDockDetail (data) {
  return request({
    url: fileName + '/users/client-dock-detail',
    method: 'GET',
    params: data
  })
}
// 日志清理接口-----------------------
// 添加自动清理日志服务
export function saveAutoClearLogSet (data) {
  return request({
    url: fileName + '/log-clean-policy/auto-clean',
    method: 'post',
    data: data
  })
}

// 编辑自动清理日志服务
export function updateAutoClearLogSet (data) {
  return request({
    url: fileName + '/log-clean-policy/auto-clean',
    method: 'post',
    data: data
  })
}
// 获取清理策略详情
export function getLogClearPolicyDetail (data) {
  return request({
    url: fileName + '/log-clean-policy/detail',
    method: 'GET',
    params: data
  })
}

// 日志清理接口
export function getLogClearServiceList (data) {
  return request({
    url: fileName + '/log-clean-policy/list',
    method: 'post',
    data: data
  })
}
// 自动清理日志服务配置 -> crm库的 日志表
export function getCrmLogTableList () {
  return request({
    url: fileName + '/log-clean-policy/crm-table-select',
    method: 'GET',
  })
}
// 自动清理日志服务配置 -> 客户库的 日志表
export function getTenancyLogTableList () {
  return request({
    url: fileName + '/log-clean-policy/tenancy-table-select',
    method: 'GET',
  })
}
// 清理暂停接口
export function pauseLogClear (data) {
  return request({
    url: fileName + '/log-clean-policy/pause',
    method: 'GET',
    params: data
  })
}
// 继续 清理
export function resumeLogClear (data) {
  return request({
    url: fileName + '/log-clean-policy/resume',
    method: 'GET',
    params: data
  })
}
// 终止清理
export function stopLogClear (data) {
  return request({
    url: fileName + '/log-clean-policy/stop',
    method: 'GET',
    params: data
  })
}

// 删除自动清理任务
export function delLogClear (data) {
  return request({
    url: fileName + '/log-clean-policy/del',
    method: 'GET',
    params: data
  })
}

// 清理记录列表
export function getLogClearRecordList (data) {
  return request({
    url: fileName + '/log-clean-record/page-list',
    method: 'post',
    data: data
  })
}
// 日志清理->状态统计
export function getLogCleanRecordTotal (data) {
  return request({
    url: fileName + '/log-clean-record/count',
    method: 'post',
    data: data
  })
}
// 日志清理-> 日志表(crm库的 和客户库的)
export function getAllLogTableList () {
  return request({
    url: fileName + '/log-clean-policy/table-select',
    method: 'GET',
  })
}
// 添加手动清理-> 下一步时
export function saveManuallyClean (data) {
  return request({
    url: fileName + '/log-clean-policy/manually-clean',
    method: 'post',
    data: data
  })
}