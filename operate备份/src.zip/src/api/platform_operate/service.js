import request from '@/utils/request'
const fileName = '/api-operate'

// 服务报告列表
export function getServiceList (data) {
  return request({
    url: fileName + '/saas-services',
    method: 'get',
    params: data
  })
}
// 新增服务
export function sureAddService (data) {
  return request({
    url: fileName + '/saas-services',
    method: 'post',
    data: data
  })
}
// 修改服务
export function updateService (data) {
  return request({
    url: fileName + '/saas-services/update',
    method: 'post',
    data: data
  })
}
// 删除服务
export function delService (data) {
  return request({
    url: fileName + '/saas-services/delete',
    method: 'post',
    data: data
  })
}
// 修改服务状态
export function updateServiceState (data) {
  return request({
    url: fileName + '/saas-services/state/update',
    method: 'post',
    data: data
  })
}
// 获取申请服务
export function getApplyServiceFunc () {
  return request({
    url: fileName + '/saas-services/lite-list',
    method: 'get'
  })
}
// 获取服务详情
export function getServiceDetail (data) {
  return request({
    url: fileName + '/saas-services/detail',
    method: 'get',
    params: data
  })
}
// 获取服务详情
export function getServiceInfo (data) {
  return request({
    url: fileName + '/saas-services/info',
    method: 'get',
    params: data
  })
}
export function sureAddServiceItem (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: fileName + '/saas-services/item',
    method: 'post',
    data: data
  })
}
// 删除服务项
export function delServiceItem (data) {
  return request({
    url: fileName + '/saas-services/item/delete',
    method: 'post',
    data: data
  })
}
// 修改服务项
export function updateServiceItem (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: fileName + '/saas-services/item/update',
    method: 'post',
    data: data
  })
}
// 获取icon
export function getServiceIcon (data) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/saas-services/item/icon',
    method: 'get',
    params: data
  })
}
// 删除服务icon
export function delServiceIcon (data) {
  return request({
    url: fileName + '/saas-services/item/icon/delete',
    method: 'post',
    data: data
  })
}
// 服务审核
export function saveRelation (data) {
  return request({
    url: fileName + '/saas-services/relation',
    method: 'post',
    data: data
  })
}
// 添加合作客户
export function sureAddpartner (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: fileName + '/saas-services/partner',
    method: 'post',
    data: data
  })
}
// 修改合作客户
export function updatePartner (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: fileName + '/saas-services/partner/update',
    method: 'post',
    data: data
  })
}
// 删除合作客户
export function delPartner (data) {
  return request({
    url: fileName + '/saas-services/partner/delete',
    method: 'post',
    data: data
  })
}
// 获取合作列表
export function getPartnerList () {
  return request({
    url: fileName + '/saas-services/partner',
    method: 'get'
  })
}
// 获取合作客户头像
export function getPartnerIcon (data) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/saas-services/partner/image',
    method: 'get',
    params: data
  })
}
// 删除合作客户头像
export function delPartnerIcon (data) {
  return request({
    url: fileName + '/saas-services/partner/image/delete',
    method: 'post',
    data: data
  })
}
// 获取客户展示 状态
export function getPartnerStatus () {
  return request({
    url: fileName + '/saas-services/settings-meta',
    method: 'get'
  })
}
// 保存客户服务配置
export function saveSettings (data) {
  return request({
    url: fileName + '/saas-services/settings',
    method: 'post',
    data: data
  })
}
// 获取服务申请列表
export function getServiceApplyList (data) {
  return request({
    url: fileName + '/saas-services/apply',
    method: 'get',
    params: data
  })
}
// 服务申请详情
export function getServiceApplyDetail (data) {
  return request({
    url: fileName + '/saas-services/apply/detail',
    method: 'get',
    params: data
  })
}
// 服务审核
export function serviceCheck (data) {
  return request({
    url: fileName + '/saas-services/apply/audit',
    method: 'post',
    data: data
  })
}
// 申请服务统计
export function getServiceApplyTotal (data) {
  return request({
    url: fileName + '/saas-services/apply/state-statistics',
    method: 'get',
    params: data
  })
}
// 导出申请服务列表
export function importApplyServiceList (data) {
  return request({
    url: fileName + '/saas-services/apply/export',
    method: 'get',
    params: data
  })
}
// 保存合作客户拖动排序
export function savePartnerOrdinal (data) {
  return request({
    url: fileName + '/saas-services/partner/ordinal/update',
    method: 'post',
    data: data
  })
}
// 保存服务/特色优势/定价策略 拖动排序
export function saveServiceOrdinal (data) {
  return request({
    url: fileName + '/saas-services/item/ordinal/update',
    method: 'post',
    data: data
  })
}