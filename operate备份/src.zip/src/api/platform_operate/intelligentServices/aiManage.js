import request from '@/utils/request'
import qs from 'qs'

const apiBaseUrl = '/api-operate'

/**
* 数据字典--一次获取多个
* @param: dicStr 多个以分号连接，比如：Depart;AIServerType 
* Modility-检查类型
* RegisCertificate-注册证
* Depart-科室
* AIServerType-ai服务类型
* InstitutionLevel-机构等级
* AIPatientType-患者类别
*/
export function getDatadic (dicStr) {
  return request({
    url: `${apiBaseUrl}/ai/datadic/info/mul-list`,
    method: 'get',
    params: { dic_look_up: dicStr }
  })
}

/**
 * 数据字典-一次获取一个 同上一个接口入参的key值不同，value传单个，返回值相同
 * @param: dicLookUp
 * */ 
export function getDatadicList (params) {
  return request({
    url: `${apiBaseUrl}/ai/datadic/info/list`,
    method: 'get',
    params
  })
}

// 获取服务类型列表
export function getAiServerTypeList (data) {
  return request({
    url: `${apiBaseUrl}/ai/datadic/info/page-list-ai-server-type`,
    method: 'post',
    data
  })
}

// 新增服务类型
export function addAiServerTypeList (data) {
  return request({
    url: `${apiBaseUrl}/ai/datadic/info/add-ai-server-type`,
    method: 'post',
    data
  })
}

// 修改服务类型
export function updateAiServerTypeList (data) {
  return request({
    url: `${apiBaseUrl}/ai/datadic/info/update-ai-server-type`,
    method: 'post',
    data
  })
}

// 删除服务类型
export function delAiServerTypeList (params) {
  return request({
    url: `${apiBaseUrl}/ai/datadic/info/del-ai-server-type`,
    method: 'get',
    params
  })
}

/******************** 服务商城 ******************************/
// 获取服务商城列表
export function getServiceShopList (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/server-store-list`,
    method: 'post',
    data
  })
}

/******************** 前置机 ******************************/
// 新增/编辑前置机
export function addClient (data) {
  return request({
    url: `${apiBaseUrl}/ai-client/add-client`,
    method: 'post',
    data
  })
}

// 获取前置机列表
export function getClientPageList (params) {
  return request({
    url: `${apiBaseUrl}/ai-client/get-client-page-list`,
    method: 'get',
    params
  })
}

// 前置机：启用或停用，删除，采集或不采集
export function clientChangeState (params) {
  return request({
    url: `${apiBaseUrl}/ai-client/change-state`,
    method: 'get',
    params
  })
}
/****************** 厂商 ****************************/
// 查询ai厂商列表-不分页，不包含过期厂商
export function getFirmsAll () {
  return request({
    url: `${apiBaseUrl}/ai/firm/info/list`,
    method: 'get'
  })
}

// 查询ai厂商列表-不分页
export function getFirmsListAll () {
  return request({
    url: `${apiBaseUrl}/ai/firm/info/all-list`,
    method: 'get'
  })
}

// 查询ai厂商列表-分页
export function getFirms (data) {
  return request({
    url: `${apiBaseUrl}/ai/firm/info/page-list`,
    method: 'post',
    data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 添加厂商信息
export function postFirms (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: `${apiBaseUrl}/ai/firm/info/add`,
    method: 'post',
    data
  })
}

// 获取厂商详情
export function getFirmsDetail (params) {
  return request({
    url: `${apiBaseUrl}/ai/firm/info/detail`,
    method: 'get',
    params
  })
}

// 修改厂商信息
export function updateFirms (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: `${apiBaseUrl}/ai/firm/info/update`,
    method: 'post',
    data
  })
}

// 删除厂商信息
export function deleteFirms (params) {
  return request({
    url: `${apiBaseUrl}/ai/firm/info/del`,
    method: 'get',
    params
  })
}

// 启用厂商
export function enableFirms (params) {
  return request({
    url: `${apiBaseUrl}/ai/firm/info/enable`,
    method: 'get',
    params
  })
}

// 停用厂商
export function disableFirms (params) {
  return request({
    url: `${apiBaseUrl}/ai/firm/info/disable`,
    method: 'get',
    params
  })
}

/****************** 服务 **************************/
// 获取服务列表-不分页
export function getServiceAll (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/list`,
    method: 'get',
    params
  })
}
// 获取服务列表-分页
export function getServiceList (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/page-list`,
    method: 'post',
    data
  })
}

// 新增服务
export function addService (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/add`,
    method: 'post',
    data
  })
}

// 编辑服务
export function updateService (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/update`,
    method: 'post',
    data
  })
}

// 删除单个服务
export function delService (params) {
  return request({
    url: `${apiBaseUrl}/ai-service/del`,
    method: 'get',
    params
  })
}
// 批量删除服务
export function delServiceList (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/del`,
    method: 'post',
    data
  })
}

// 获取服务详情
export function getServiceDetail (params) {
  return request({
    url: `${apiBaseUrl}/ai-service/detail`,
    method: 'get',
    params
  })
}

// 上架服务
export function enableService (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/enable`,
    method: 'get',
    params
  })
}

// 禁用服务
export function disableService (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/disable`,
    method: 'get',
    params
  })
}

// 查询ai厂商开通的服务列表-详情用
export function getServerList (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/server-list`,
    method: 'get',
    params
  })
}

// 查询ai厂商开通的机构列表-详情用
export function getHospitalList (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/hospital-list`,
    method: 'get',
    params
  })
}

// 删除开通的服务
export function delOpenServer (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/del-server`,
    method: 'get',
    params
  })
}

/*******************授权**********************/
// 分页查询
export function getOpenList (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/page-list`,
    method: 'post',
    data
  })
}

// 新增授权
export function addOpen(data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/add`,
    method: 'post',
    data
  })
}

// 新增授权-多选机构
export function addOpenList(data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/add-list`,
    method: 'post',
    data
  })
}

// 删除授权
export function delOpen(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/del`,
    method: 'get',
    params
  })
}

// 开启授权
export function enableOpen(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/enable`,
    method: 'get',
    params
  })
}

// 取消授权
export function disableOpen(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/disable`,
    method: 'get',
    params
  })
}

// 参数配置
export function argsOpen(data) {
  return request({
    url: `${apiBaseUrl}/ai-service-tenancy/args`,
    method: 'post',
    data
  })
}

// 根据机构id获取机构下的服务详细列表
export function detailOpen(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/detail`,
    method: 'get',
    params
  })
}

// 获取标准检查类型
export function getStandExamType(params) {
  return request({
    url: `${apiBaseUrl}/ai-service-tenancy/get-exam-type`,
    method: 'get',
    params
  })
}

// 获取标准检查部位
export function getStandBodypart(params) {
  return request({
    url: `${apiBaseUrl}/ai-service-tenancy/get-exam-bodypart`,
    method: 'get',
    params
  })
}

// 获取标准检查项目
export function getStandExamItem(params) {
  return request({
    url: `${apiBaseUrl}/ai-service-tenancy/get-exam-item`,
    method: 'get',
    params
  })
}

// 查询机构开通的在期服务列表(详情用)
export function getOnlineServerList(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/online-server-list`,
    method: 'get',
    params
  })
}

// 查询机构授权记录(详情用) 
export function getOpenHistoryList(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/open-history-list`,
    method: 'get',
    params
  })
}

// 查询服务使用的机构信息
export function getOpenInstitutionList(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/institution-list`,
    method: 'get',
    params
  })
}

/********************* 检测列表 *****************/
// 获取检查记录列表
export function getSptExamList (params) {
  return request({
    url: `${apiBaseUrl}/ai/spt/get-exam-list`,
    method: 'get',
    params,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 查询ai结果列表
export function getSptResultList (params) {
  return request({
    url: `${apiBaseUrl}/ai/spt/get-result-list`,
    method: 'get',
    params,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 查询检测详情
export function getSptDetail (params) {
  return request({
    url: `${apiBaseUrl}/ai/spt/get-detail`,
    method: 'get',
    params
  })
}

// 修改ai检测记录
export function postSptExecState (data) {
  return request({
    url: `${apiBaseUrl}/ai/spt/exec-state`,
    method: 'post',
    data
  })
}

/*********** 数据预览 ***************/
// 顶部数据预览
export function getOverviewTop (id) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/top`,
    method: 'get'
  })
}

// 调用占比
export function getProportion (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/proportion`,
    method: 'get',
    params
  })
}

// 调用排名
export function getDataOverviewIndex (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/index`,
    method: 'get',
    params
  })
}

// 调用量
export function getDataOverviewAmount (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/amount`,
    method: 'get',
    params
  })
}

// 检测能力对比
export function getDataOverviewCompare (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/ai-ability-compare`,
    method: 'get',
    params
  })
}

// 获取开通服务的机构
export function getOpenInstitution (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/institution-select`,
    method: 'get',
    params
  })
}

// 检查效率分析 各阶段每例平均耗时（秒）
export function getPartCost (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/part-cost`,
    method: 'get',
    params
  })
}

// 指定服务下机构检测能力对比-各阶段每例平均耗时
export function getOrgPartCost (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/org-part-cost`,
    method: 'get',
    params
  })
}

// 获取各个阶段未处理最大量
export function getAiResultNoReturn (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/ai-result-no-return`,
    method: 'get',
    params
  })
}

// 获取机构授权参数配置
export function getModuleOptionList (params) {
  return request({
    url: `${apiBaseUrl}/ai/system/module/option-list`,
    method: 'get',
    params
  })
}

// 获取系统参数配置分页列表
export function getParamsPageList (data) {
  return request({
    url: `${apiBaseUrl}/ai/system/params/page-list`,
    method: 'post',
    data
  })
}

// 修改系统参数配置
export function updateSystemParams (data) {
  return request({
    url: `${apiBaseUrl}/ai/system/params/update-batch`,
    method: 'post',
    data
  })
}

// 创建查询前置机查询列表服务，同一机器码和时间，只能存在一条，如果之前的存在，那进行更新
export function addFileList (params) {
  return request({
    url: `${apiBaseUrl}/ai/filetask/add-search-list`,
    method: 'get',
    params
  })
}

// 获取前置机文件列表
export function getFileList (params) {
  return request({
    url: `${apiBaseUrl}/ai/filetask/get-file-list`,
    method: 'get',
    params
  })
}

// 创建文件上传下载删除任务；
export function createFileTask (params) {
  return request({
    url: `${apiBaseUrl}/ai/filetask/create-task`,
    method: 'get',
    params
  })
}

// 上传文件
export function serverUploadZip (obj) {
  return request({
    url: `${apiBaseUrl}/ai/filetask/server-upload-zip?machine_code=${obj.machine_code}`,
    method: 'post',
    data: obj.formData
  })
}

// 获取文件下载 上传 删除任务列表
export function getFileTaskPage (params) {
  return request({
    url: `${apiBaseUrl}/ai/filetask/get-task-page`,
    method: 'get',
    params
  })
}

// 删除任务
export function deleteTaskById (data) {
  return request({
    url: `${apiBaseUrl}/ai/filetask/delete-by-id`,
    method: 'post',
    data
  })
}

// 下载文件
export function downById (params, responseType) {
  return request({
    url: `${apiBaseUrl}/ai/filetask/down-by-id`,
    method: 'get',
    params,
    responseType: responseType || 'arraybuffer'
  })
}

/********* 偏好设置 **************/
// 根据机构id获取服务下拉（偏好设置）
export function getServiceSelect (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/service-select`,
    method: 'get',
    params
  })
}

// 保存偏好设置
export function saveServicePriority (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/save-service-priority`,
    method: 'post',
    data
  })
}

// 获取偏好设置
export function getPreference (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/get-preference`,
    method: 'get',
    params
  })
}

// 保存偏好设置
export function savePreference (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/save-preference`,
    method: 'post',
    data
  })
}

// 获取优先级别
export function getPriority (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/get-priority`,
    method: 'get',
    params
  })
}

// 保存优先级别
export function savePriority (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/save-priority`,
    method: 'post',
    data
  })
}

// 获取处理时间
export function getTimeSlot (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/get-time-slot`,
    method: 'get',
    params
  })
}

// 保存处理时间
export function saveTimeSlot (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/save-time-slot`,
    method: 'post',
    data
  })
}

// 保存机构优先级
export function saveInstitutionPriority (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/save-institution-priority`,
    method: 'post',
    data
  })
}

// 机构开通授权历史记录
export function getOpenRecordList (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/record/list`,
    method: 'get',
    params
  })
}

// 平台端批量删除机构下开通的服务
export function delBatch (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/del-batch`,
    method: 'post',
    data
  })
}

// 平台端批量服务续期
export function renewalBatch (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/renewal-batch`,
    method: 'post',
    data
  })
}

/***********************  监控配置  ****************************/
// 获取监控类型下对应参数
export function getMonitorParam (params) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/monitor-param`,
    method: 'get',
    params
  })
}

// 获取ai监控类型参数
export function getMonitorType (params) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/monitor-type`,
    method: 'get',
    params
  })
}

// 查询已配置过的列表
export function getMonitorPageList (params) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/monitor-page-list`,
    method: 'get',
    params
  })
}

// 创建或修改配置参数
export function postMonitorMonitor (data) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/modify-monitor`,
    method: 'post',
    data
  })
}

// 获取监控对象，要进行筛选，配置过的不显示在列表
export function getMonitorFirm (params) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/monitor-firm`,
    method: 'get',
    params
  })
}

// 删除选中监控
export function deleteMonitor (params) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/delete-monitor`,
    method: 'get',
    params
  })
}

// 启用或关闭监控
export function changeMonitorState (params) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/change-monitor-state`,
    method: 'get',
    params
  })
}

// 查询异常列表
export function warningPageList (params) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/warning-page-list`,
    method: 'get',
    params
  })
}

// 前置机注册心跳， 如果连通状态是-1 ，代表前置机与采集机构连通不了
export function monitorHeart (params) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/monitor-heart`,
    method: 'get',
    params
  })
}


/********  日志  ***********/
// 分页查询日志/api/ai/system/log/page-list
export function logPageList (data) {
  return request({
    url: `${apiBaseUrl}/ai/system/log/page-list`,
    method: 'post',
    data
  })
}

// 日志模块信息
export function logModuleList (params) {
  return request({
    url: `${apiBaseUrl}/ai/system/module/operate-log-option-list`,
    method: 'get',
    params
  })
}

// 日志操作类型
export function logEnumList (params) {
  return request({
    url: `${apiBaseUrl}/ai/enum/system-operate-log-type`,
    method: 'get',
    params
  })
}

/******************** 机构端数据概览 ***********************/
// 机构端获取数据概览顶部
export function getOverviewInstitutionTop (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/institution-top`,
    method: 'get',
    params
  })
}

// 获取机构调用占比
export function getOverviewInstitutionProportion (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/institution-proportion`,
    method: 'get',
    params
  })
}

// 获取机构调用量
export function getOverviewInstitutionAmount (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/institution-amount`,
    method: 'get',
    params
  })
}

// 获取机构检测能力对比
export function getOverviewInstitutionAbility (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/institution-ai-ability-compare`,
    method: 'get',
    params
  })
}

// 获取机构检测能力对比-各阶段每例平均耗时（服务）
export function getOverviewInstitutionPartCost (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/institution-part-cost`,
    method: 'get',
    params
  })
}

// 获取指定服务下机构检测能力对比-各阶段每例平均耗时
export function getInstitutionOrgPartCost (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/institution-org-part-cost`,
    method: 'get',
    params
  })
}

// 机构端申请类型/审核状态
export function getInstitutionServiceApplyCode (params) {
  return request({
    url: `${apiBaseUrl}/ai/enum/institution-service-apply-code`,
    method: 'get',
    params
  })
}

// 机构端获取服务商城列表
export function getInstitutionServiceStoreList (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/institution-server-store-list`,
    method: 'post',
    data
  })
}

// 机构端我的服务商城列表
export function getInstitutionOpenedServiceList (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/institution-opened-server-list`,
    method: 'post',
    data
  })
}


/***********************   申请记录   *****************************/
// 申请记录分页查询-平台端
export function getApplyList (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/page-list`,
    method: 'post',
    data
  })
}

// 申请记录分页查询-机构端
export function getInstitutionApplyList (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/institution-page-list`,
    method: 'post',
    data
  })
}

// 申请记录分页查询-厂商端
export function getFirmApplyList (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/firm-page-list`,
    method: 'post',
    data
  })
}

// 获取申请记录详情
export function getApplyDetail (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/detail`,
    method: 'get',
    params
  })
}

// 机构端-服务续期
export function postApplyRenewal (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/renewal`,
    method: 'post',
    data
  })
}

// 机构端-服务开通
export function postApplyOpen (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/open`,
    method: 'post',
    data
  })
}

// 机构端-配置变更
export function postChangePriority (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/change-priority`,
    method: 'post',
    data
  })
}

// 机构端-申请对象下拉
export function getInstitutionApplyObject (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/institution-apply-object-list`,
    method: 'get',
    params
  })
}

// 机构端-审核
export function postInstitutionExamine (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/institution-examine`,
    method: 'post',
    data
  })
}

// 机构端-优先级是否在审核中
export function getInstitutionPriorityState (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/institution-priority-state`,
    method: 'get',
    params
  })
}

// 开启优先级单独按钮
export function enablePriority (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/enable-priority`,
    method: 'get',
    params
  })
}

// 关闭优先级单独按钮
export function disablePriority (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/disable-priority`,
    method: 'get',
    params
  })
}

// 开启患者类别时间单独按钮
export function enablePatientTypeTime (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/enable-patient-type-time`,
    method: 'get',
    params
  })
}

// 关闭患者类别时间单独按钮
export function disablePatientTypeTime (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open/disable-patient-type-time`,
    method: 'get',
    params
  })
}

/***************** 厂商 ********************/
// 厂商端-申请对象下拉
export function getFirmApplyObject (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/firm-apply-object-list`,
    method: 'get',
    params
  })
}

// 厂商端-审核
export function postFirmExamine (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/firm-examine`,
    method: 'post',
    data
  })
}

// 厂商端上架申请
export function firmApplyEnable (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/apply-enable`,
    method: 'post',
    data
  })
}

// 厂商端下架申请
export function firmApplyDisable (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/apply-disable`,
    method: 'post',
    data
  })
}

// 厂商端-服务续期申请
export function renewalByFirm (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/renewal-by-firm`,
    method: 'post',
    data
  })
}

// 厂商端-厂商续期申请
export function firmRenewalByFirm (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/firm-renewal-by-firm`,
    method: 'post',
    data
  })
}

// 厂商端编辑申请信息
export function infoUpdateByFirm (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/info-update-by-firm`,
    method: 'post',
    data
  })
}

// 厂商端在库服务
export function firmServerList (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/firm-server-list`,
    method: 'get',
    params
  })
}

// 厂商端-申请编辑服务信息
export function updateServiceByFirm (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/service-info-update-by-firm`,
    method: 'post',
    data
  })
}

// 厂商端申请类型/审核状态
export function getFirmServiceApplyCode (params) {
  return request({
    url: `${apiBaseUrl}/ai/enum/firm-service-apply-code`,
    method: 'get',
    params
  })
}

// 厂商端-顶部数据概览
export function firmOverviewTop (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/firm-top`,
    method: 'get',
    params
  })
}

// 厂商端-调用占比
export function firmProportion (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/firm-proportion`,
    method: 'get',
    params
  })
}

// 厂商端-调用量
export function firmAmount (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/firm-amount`,
    method: 'get',
    params
  })
}

//厂商端-检测能力对比
export function firmAiAbilityCompare (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/firm-ai-ability-compare`,
    method: 'get',
    params
  })
}

// 厂商端-检测能力对比-各阶段每例平均耗时
export function firmPartCost (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/firm-part-cost`,
    method: 'get',
    params
  })
}

// 厂商端-服务管理-查询申请中的状态的服务id
export function firmApplyingServiceList (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/firm-applying-service-list`,
    method: 'get',
    params
  })
}

// 厂商端-未处理任务阈值监控数据
export function firmWaitPageList (params) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/firm-wait-page-list`,
    method: 'get',
    params
  })
}


// 指定服务下机构检测能力对比-各阶段每例平均耗时
export function firmOrgPartCost (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/firm-org-part-cost`,
    method: 'get',
    params
  })
}

// 上传文件
export function fileCenterUpload (data) {
  return request({
    url: `${apiBaseUrl}/ai/file-center/upload`,
    method: 'post',
    data
  })
}

// 获取调阅率排名列表
export function getOrgBrowseTop (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/org-browse-top`,
    method: 'get',
    params
  })
}

// 获取调阅率趋势图表
export function getOrgBrowseDetail (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/org-browse-detail`,
    method: 'get',
    params
  })
}

// 重置异常记录更新次数
export function updateAistateCount (params) {
  return request({
    url: `${apiBaseUrl}/ai/spt/update-aistate-count`,
    method: 'get',
    params
  })
}

// 获取uuid
export function getUuid (params) {
  return request({
    url: `${apiBaseUrl}/commons/uuid`,
    method: 'get',
    params
  })
}

// 厂商端服务新增申请
export function createServiceByFirm (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/apply/create-service-by-firm`,
    method: 'post',
    data
  })
}

// 清空服务操作手册关联
export function createOperatingManual (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/clear-operating-manual`,
    method: 'get',
    params
  })
}

// 获取base64图片
export function getImageBase64 (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/get-base64`,
    method: 'get',
    params
  })
}

// 获取影像回写列表
export function getReturnPage (params) {
  return request({
    url: `${apiBaseUrl}/ai/tpexamines/image-return-page`,
    method: 'get',
    params
  })
}

// 验证服务地址
export function getUrlPingState (params) {
  return request({
    url: `${apiBaseUrl}/commons/url-ping`,
    method: 'get',
    params
  })
}

// 分享服务
export function shareService (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/share-service`,
    method: 'post',
    data
  })
}


// 删除服务时调用，判断该服务在其他客户和自己客户下有未过期的记录
export function delServiceCheck (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/delete-service-check`,
    method: 'get',
    params
  })
}

// 关闭分享前调用
export function closeShareCheck (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/close-share-check`,
    method: 'get',
    params
  })
}

// 开通服务时获取本客户下的厂商列表-该接口过滤了分享过来的服务和平台端服务
export function getLocalTenancyFirm (params) {
  return request({
    url: `${apiBaseUrl}/ai/firm/info/local-tenancy-firm`,
    method: 'get',
    params
  })
}
