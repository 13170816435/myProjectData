import request from '@/utils/request'
import qs from 'qs'

const apiBaseUrl = '/api-operate'

/**
* 数据字典--一次获取多个
* @param: dicStr 多个以分号连接，比如：Depart;AIServerType 
* Modility-检查类型
* RegisCertificate-注册证
* Depart-科室
* AIServerType-ai服务类型
* InstitutionLevel-机构等级
* AIPatientType-患者类别
*/
export function getPlatformDatadic (dicStr) {
  return request({
    url: `${apiBaseUrl}/ai/datadic/info-platform/mul-list`,
    method: 'get',
    params: { dic_look_up: dicStr }
  })
}

/**
 * 数据字典-一次获取一个 同上一个接口入参的key值不同，value传单个，返回值相同
 * @param: dicLookUp
 * */ 
 export function getPlatformDatadicList (params) {
  return request({
    url: `${apiBaseUrl}/ai/datadic/info-platform/list`,
    method: 'get',
    params
  })
}

/****************** 厂商 ****************************/
// 查询ai厂商列表-不分页，不包含过期厂商
export function getPlatformFirmsAll () {
  return request({
    url: `${apiBaseUrl}/ai/firm/info-platform/list`,
    method: 'get'
  })
}

// 查询ai厂商列表-不分页
export function getPlatformFirmsListAll (params) {
  return request({
    url: `${apiBaseUrl}/ai/firm/info-platform/all-list`,
    method: 'get',
    params
  })
}

// 查询ai厂商列表-由平台创建的厂商
export function getOplateFirm (params) {
  return request({
    url: `${apiBaseUrl}/ai-firm/oplate-firm`,
    method: 'get',
    params
  })
}

// 查询ai厂商列表-分页
export function getPlatformFirms (data) {
  return request({
    url: `${apiBaseUrl}/ai-firm/page-list`,
    method: 'post',
    data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 添加厂商信息
export function postPlatformFirms (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: `${apiBaseUrl}/ai-firm/add`,
    method: 'post',
    data
  })
}

// 获取厂商详情
export function getPlatformFirmsDetail (params) {
  return request({
    url: `${apiBaseUrl}/ai-firm/detail`,
    method: 'get',
    params
  })
}

// 修改厂商信息
export function updatePlatformFirms (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: `${apiBaseUrl}/ai-firm/update`,
    method: 'post',
    data
  })
}

// 删除厂商信息
export function deletePlatformFirms (data) {
  return request({
    url: `${apiBaseUrl}/ai-firm/del`,
    method: 'post',
    data
  })
}

// 启用厂商
export function enablePlatformFirms (data) {
  return request({
    url: `${apiBaseUrl}/ai-firm/enable`,
    method: 'post',
    data
  })
}

// 停用厂商
export function disablePlatformFirms (data) {
  return request({
    url: `${apiBaseUrl}/ai-firm/disable`,
    method: 'post',
    data
  })
}

// 查询服务使用的机构信息
export function getPlatformOpenInstitutionList(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/institution-list`,
    method: 'get',
    params
  })
}

// 获取下拉机构
export function getPlatformOpenTenancySelect(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/tenancy-select`,
    method: 'get',
    params
  })
}

// 查询ai厂商开通的服务列表-详情用
export function getPlatformServerList (params) {
  return request({
    url: `${apiBaseUrl}/ai/service-platform/server-list`,
    method: 'get',
    params
  })
}

// 查询ai厂商开通的机构列表-详情用
export function getPlatformHospitalList (params) {
  return request({
    url: `${apiBaseUrl}/ai/service-platform/hospital-list`,
    method: 'get',
    params
  })
}

// 获取AI各个阶段耗时统计查询-点击单个服务显示客户的
export function getPlatformPartCostOperate (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/part-cost-operate`,
    method: 'get',
    params
  })
}

// 获取AI各个阶段耗时统计查询
export function getPlatformPartCostTenancy (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/part-cost-tenancy`,
    method: 'get',
    params
  })
}

// 运营平台下查看客户下机构各阶段每例平均耗时
export function getPlatformOrgPartCostTenancy (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview/org-part-cost-tenancy`,
    method: 'get',
    params
  })
}

// 获取base64图片
export function getPlatformImageBase64 (params) {
  return request({
    url: `${apiBaseUrl}/ai-service/get-base64`,
    method: 'get',
    params
  })
}


/****************** 服务 **************************/
// 获取服务列表-不分页
export function getPlatformServiceAll (params) {
  return request({
    url: `${apiBaseUrl}/ai/service-platform/list`,
    method: 'get',
    params
  })
}
// 获取服务列表-分页
export function getPlatformServiceList (params) {
  return request({
    url: `${apiBaseUrl}/ai-service/service-list`,
    method: 'get',
    params,
  })
}

// 获取服务列表-分页 (按类型分类)
export function getPlatformServiceListByType (params) {
  return request({
    url: `${apiBaseUrl}/ai-service/service-type-group/list`,
    method: 'get',
    params,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取服务列表-分页 (按厂商分类)
export function getPlatformServiceListByFirm (params) {
  return request({
    url: `${apiBaseUrl}/ai-service/service-firm-group/list`,
    method: 'get',
    params
  })
}

//客户管理-> 获取服务列表-分页
export function getTenancyServiceList (data) {
  return request({
    url: `${apiBaseUrl}/ai-service-tenancy/service-list`,
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false,arrayFormat: 'repeat' })
    }
  })
}

// 客户管理->  获取服务列表-分页 (按类型分类)
export function getTenancyServiceListByType (params) {
  return request({
    url: `${apiBaseUrl}/ai-service-tenancy/service-type-group/list`,
    method: 'get',
    params,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}


// 客户管理 -> 获取服务列表-分页 (按厂商分类)
export function getTenancyServiceListByFirm (params) {
  return request({
    url: `${apiBaseUrl}/ai-service-tenancy/service-firm-group/list`,
    method: 'get',
    params,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}


// 新增服务
export function addPlatformService (data) {
  return request({
    url: `${apiBaseUrl}/ai-service/add`,
    method: 'post',
    data
  })
}

// 编辑服务
export function updatePlatformService (data) {
  return request({
    url: `${apiBaseUrl}/ai-service/update`,
    method: 'post',
    data
  })
}

// 删除单个服务
export function delPlatformService (data) {
  return request({
    url: `${apiBaseUrl}/ai-service/del`,
    method: 'post',
    data
  })
}
// 批量删除服务
export function delPlatformServiceList (data) {
  return request({
    url: `${apiBaseUrl}/ai/service-platform/del`,
    method: 'post',
    data
  })
}

// 获取服务详情
export function getPlatformServiceDetail (params) {
  return request({
    url: `${apiBaseUrl}/ai-service/service-stat/detail`,
    method: 'get',
    params
  })
}

// 上架服务(启用服务)
export function enablePlatformService (data) {
  return request({
    url: `${apiBaseUrl}/ai-service/enable`,
    method: 'post',
    data
  })
}

// 下架服务(停用服务)
export function disablePlatformService (data) {
  return request({
    url: `${apiBaseUrl}/ai-service/disable`,
    method: 'post',
    data
  })
}

// 删除开通的服务
export function delPlatformOpenServer (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/del-server`,
    method: 'get',
    params
  })
}


/*******************授权**********************/
// 分页查询
export function getPlatformOpenList (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/page-list`,
    method: 'post',
    data
  })
}

// 新增授权
export function addPlatformOpen(data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/add`,
    method: 'post',
    data
  })
}

// 删除授权
export function delPlatformOpen(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/del`,
    method: 'get',
    params
  })
}

// 开启授权
export function enablePlatformOpen(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/enable`,
    method: 'get',
    params
  })
}

// 取消授权
export function disablePlatformOpen(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/disable`,
    method: 'get',
    params
  })
}

// 参数配置
export function argsPlatformOpen(data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/args`,
    method: 'post',
    data
  })
}

// 根据机构id获取机构下的服务详细列表
export function detailPlatformOpen(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/detail`,
    method: 'get',
    params
  })
}


// 查询机构开通的在期服务列表(详情用)
export function getPlatformOnlineServerList(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/online-server-list`,
    method: 'get',
    params
  })
}

// 查询机构授权记录(详情用) 
export function getPlatformOpenHistoryList(params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/open-history-list`,
    method: 'get',
    params
  })
}

// 获取开通服务的机构
export function getPlatformSelectOpenInstitution (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/institution-select`,
    method: 'get',
    params
  })
}


// 获取标准检查类型
export function getPlatformStandExamType(params) {
  return request({
    url: `${apiBaseUrl}/ai/stand/config-platform/get-exam-type`,
    method: 'get',
    params
  })
}

// 获取标准检查部位
export function getPlatformStandBodypart(params) {
  return request({
    url: `${apiBaseUrl}/ai/stand/config-platform/get-exam-bodypart`,
    method: 'get',
    params
  })
}

// 获取标准检查项目
export function getPlatformStandExamItem(params) {
  return request({
    url: `${apiBaseUrl}/ai/stand/config-platform/get-exam-item`,
    method: 'get',
    params
  })
}


/********* 偏好设置 **************/
// 根据机构id获取服务下拉（偏好设置）
export function getPlatformServiceSelect (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/service-select`,
    method: 'get',
    params
  })
}

// 保存偏好设置
export function savePlatformServicePriority (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/save-service-priority`,
    method: 'post',
    data
  })
}

// 获取偏好设置
export function getPlatformPreference (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/get-preference`,
    method: 'get',
    params
  })
}

// 保存偏好设置
export function savePlatformPreference (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/save-preference`,
    method: 'post',
    data
  })
}

// 获取优先级别
export function getPlatformPriority (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/get-priority`,
    method: 'get',
    params
  })
}

// 保存优先级别
export function savePlatformPriority (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/save-priority`,
    method: 'post',
    data
  })
}

// 获取处理时间
export function getPlatformTimeSlot (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/get-time-slot`,
    method: 'get',
    params
  })
}

// 保存处理时间
export function savePlatformTimeSlot (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/save-time-slot`,
    method: 'post',
    data
  })
}

// 保存机构优先级
export function savePlatformInstitutionPriority (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/save-institution-priority`,
    method: 'post',
    data
  })
}

// 机构开通授权历史记录
export function getPlatformOpenRecordList (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/record/list`,
    method: 'get',
    params
  })
}

// 平台端批量删除机构下开通的服务
export function delPlatformBatch (data) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/del-batch`,
    method: 'post',
    data
  })
}

// 平台端批量服务续期
export function renewalInstituteBatch (data) {
  return request({
    url: `${apiBaseUrl}/ai-service-tenancy/renewal-batch`,
    method: 'post',
    data
  })
}


// 开启优先级单独按钮
export function enablePlatformPriority (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/enable-priority`,
    method: 'get',
    params
  })
}

// 关闭优先级单独按钮
export function disablePlatformPriority (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/disable-priority`,
    method: 'get',
    params
  })
}

// 开启患者类别时间单独按钮
export function enablePlatformPatientTypeTime (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/enable-patient-type-time`,
    method: 'get',
    params
  })
}

// 关闭患者类别时间单独按钮
export function disablePlatformPatientTypeTime (params) {
  return request({
    url: `${apiBaseUrl}/ai/service/open-platform/disable-patient-type-time`,
    method: 'get',
    params
  })
}

// 上传文件
export function filePlatformCenterUpload (data) {
  return request({
    url: `${apiBaseUrl}/ai-file-center/upload`,
    method: 'post',
    data
  })
}

// 客户异常列表
export function getPlatformWarningList (params) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/warning-tenancy-list`,
    method: 'get',
    params
  })
}

// 获取异常列表
export function getPlatformWarningPageList (params) {
  return request({
    url: `${apiBaseUrl}/ai/monitor/warning-page-list`,
    method: 'get',
    params
  })
}


/*********** 数据预览 ***************/
// 顶部数据预览
export function getPlatformOverviewTop (id) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview-platform/top`,
    method: 'get'
  })
}

// 调用占比
export function getPlatformProportion (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview-platform/proportion`,
    method: 'get',
    params
  })
}

// 调用排名
export function getPlatformDataOverviewIndex (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview-platform/index`,
    method: 'get',
    params
  })
}

// 调用量
export function getPlatformDataOverviewAmount (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview-platform/amount`,
    method: 'get',
    params
  })
}

// 检测能力对比
export function getPlatformDataOverviewCompare (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview-platform/ai-ability-compare`,
    method: 'get',
    params
  })
}

// 检查效率分析 各阶段每例平均耗时（秒）
export function getPlatformPartCost (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview-platform/part-cost`,
    method: 'get',
    params
  })
}

// 检查效率分析 各阶段每例平均耗时（秒）
export function getPlatformOrgPartCost (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview-platform/org-part-cost`,
    method: 'get',
    params
  })
}

// 获取各个阶段未处理最大量
export function getPlatformAiResultNoReturn (params) {
  return request({
    url: `${apiBaseUrl}/ai/data-overview-platform/ai-result-no-return`,
    method: 'get',
    params
  })
}

// 运营平台下厂商列表
export function getPlatformFirmList (params) {
  return request({
    url: `${apiBaseUrl}/ai/firm/info/sort-firm-list`,
    method: 'get',
    params
  })
}
