import request from '@/utils/request'
import qs from 'qs'
const fileName = '/api-operate'
// 获取服务厂商列表
export function getServiceFirmList (data) {
  return request({
    url: fileName + '/informations/user/latest',
    method: 'get',
    params: data
  })
}
// 获取服务类型列表
export function getServiceTypeList (data) {
  return request({
    url: fileName + '/informations/user/latest',
    method: 'get',
    params: data
  })
}
// 获取使用记录列表
export function getUsageRecordList (data) {
  return request({
    url: fileName + '/ai-examine/examine-info/page-list',
    method: 'post',
    data: data
  })
}
// 获取使用记录界面下的   tab 统计
export function getExamTotal (data) {
  return request({
    url: fileName + '/ai-examine/state-stat',
    method: 'get',
    params: data,
  })
}
// 获取使用记录详情
export function getUsageDetail (data) {
  return request({
    url: fileName + '/ai-examine/detail',
    method: 'get',
    params: data
  })
}

// 服务评价单-> 获取试用范围
export function getTryRangeList (data) {
  return request({
    url: fileName + '/informations/user/latest',
    method: 'get',
    params: data
  })
}

// 服务详情->客户授权列表
export function getTenancyAuthByServiceId (data) {
  return request({
    url: fileName + '/ai/service/open-platform/tenancy-authority-list/by-service-id',
    method: 'get',
    params: data
  })
}
// 服务详情->客户授权 移除授权
export function delTenancyService (data) {
  return request({
    url: fileName + '/ai/service/open-platform/del-server',
    method: 'post',
    data: data
  })
}

// 服务详情->客户授权 添加授权
export function addTenancyAuth (data) {
  return request({
    url: fileName + '/ai/service/open-platform/add',
    method: 'post',
    data: data
  })
}
// 获取客户授权列表
export function getTenancyAuthList (data) {
  return request({
    url: fileName + '/ai/service/open-platform/tenancy-authority',
    method: 'get',
    params: data
  })
}

// 客户管理->智能服务-> 授权管理
export function getInstituteAuthList (data) {
  return request({
    url: fileName + '/ai/service/open-platform/institution-authority',
    method: 'get',
    params: data
  })
}

// 客户授权 开启授权
export function enableTenancyAuth (data) {
  return request({
    url: fileName + '/ai/service/open-platform/enable',
    method: 'post',
    data: data
  })
}

// 客户管理-> 机构授权 开启授权
export function enableInstituteAuth (data) {
  return request({
    url: fileName + '/ai-service-tenancy/institution-enable',
    method: 'post',
    data: data
  })
}


// 客户授权 取消授权
export function disableTenancyAuth (data) {
  return request({
    url: fileName + '/ai/service/open-platform/disable',
    method: 'post',
    data: data
  })
}

// 客户授权-> 机构授权 取消授权
export function disableInstituteAuth (data) {
  return request({
    url: fileName + '/ai-service-tenancy/institution-disable',
    method: 'post',
    data: data
  })
}

// 机构授权 获取参数模块下拉
export function getInstituteServiceSet (params) {
  return request({
    url: fileName + '/ai-service-tenancy/detail',
    method: 'get',
    params
  })
}

// 客户授权-> 机构授权 删除授权
export function delInstituteAuth (data) {
  return request({
    url: fileName + '/ai-service-tenancy/del-server',
    method: 'post',
    data: data
  })
}

// 客户授权-> 机构授权 添加授权
export function addInstituteAuth (data) {
  return request({
    url: fileName + '/ai-service-tenancy/add-list',
    method: 'post',
    data: data
  })
}

// 服务管理-> 服务状态统计
export function getServiceStateTotal (data) {
  return request({
    url: fileName + '/ai-service/state-stat',
    method: 'get',
    params: data,
  })
}

// 客户管理下 服务管理-> 服务状态统计
export function getServiceStateTotalByTenancy (data) {
  return request({
    url: fileName + '/ai-service-tenancy/state-stat',
    method: 'get',
    params: data,
  })
}

// 服务管理-> 客户授权统计
export function getTenancyAuthTotal (data) {
  return request({
    url: fileName + '/ai-service/tenancy-authorize-stat',
    method: 'get',
    params: data,
  })
}

// 服务管理-> 服务使用量统计
export function getServiceUsageTotal (data) {
  return request({
    url: fileName + '/ai-service/service-usage-stat',
    method: 'get',
    params: data,
  })
}
// 服务详情 使用量按时间统计
export function getUsageTotalByTime (data) {
  return request({
    url: fileName + '/ai-service/usage-analysis-stat',
    method: 'get',
    params: data,
  })
}
// 服务详情 使用量按客户统计
export function getUsageTotalByTenancy (data) {
  return request({
    url: fileName + '/ai-service/tenancy-usage-analysis-stat',
    method: 'get',
    params: data,
  })
}
// 服务详情 使用量按机构统计
export function getUsageTotalByInstitute (data) {
  return request({
    url: fileName + '/ai-service/institution-usage-analysis-stat',
    method: 'get',
    params: data
  })
}
// 服务 相关的数据字典
export function getServiceDataDic (params) {
  return request({
    url: fileName + `/ai-data-dic/info-platform/list?dic_look_up=${params}`,
    method: 'get',
  })
}