import request from '@/utils/request'

// 上传文件
export const uploadFileToCrm = (params, data) => request({
  url: '/api-archive/upload/crm',
  method: 'post',
  headers: {
    'Content-Type': 'multipart/form-data',
    'SystemType': 'CRM'
  },
  params,
  data
})

// 下载文件
export const downloadFile = (params) => request({
  headers: {
    'SystemType': 'CRM'
  },
  url: '/api-archive/download/crm-document-id',
  method: 'get',
  responseType: 'blob',
  params
})

// 删除文件
export const deleteFile = (data) => request({
  headers: {
    'SystemType': 'CRM'
  },
  url: `/api-archive/documents/update-tag`,
  method: 'post',
  data
})

// 获取文件浏览地址
export const getViewUrl = (id) => request({
  headers: {
    'SystemType': 'CRM'
  },
  url: `/api-archive/storage/documents/${id}/view-url`,
  method: 'get'
})

