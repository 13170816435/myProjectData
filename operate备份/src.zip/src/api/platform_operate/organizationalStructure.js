import request from '@/utils/request'
import qs from 'qs'
const fileName = '/api-operate'
// 获取标准树
export function getStandardTree(data) {
  return request({
    url: fileName + '/departs/member/tree',
    params: data,
    method: 'get'
  })
}
// 获取产品详情
export function getProductDetail(productId) {
  return request({
    url: fileName + `/products/${productId}/detail`,
    method: 'get'
  })
}
// 编辑产品
export function updateProductFn(data) {
  return request({
    method: 'post',
    url: fileName + '/products/update-product',
    data
  })
}
// 新增一个产品 添加到某个文件夹下
export function addProductToGroup(data) {
  return request({
    method: 'post',
    url: fileName + '/products/add-product-to-group',
    data
  })
}
// 添加产品
export function createProductFn(data) {
  return request({
    method: 'post',
    url: fileName + '/products/create-product',
    data
  })
}
// 获取某个文件夹(子系统)下的 微服务列表
export function getProductMicroserviceList(productId) {
  return request({
    url: fileName + `/products/${productId}/microservice-list`,
    method: 'get'
  })
}
// 添加新的微服务
export function addProductMicroservice(data) {
  return request({
    method: 'post',
    url: fileName + '/products/add-product-microservice',
    data
  })
}
// 移除某个产品下的微服务
export function removeProductMicorservice(data) {
  return request({
    method: 'post',
    url: fileName + '/products/delete-product-microservice',
    data
  })
}
// 获取所有的产品列表(不分页)
export function getAllProduct(data) {
  return request({
    url: fileName + '/products/all-list',
    method: 'get'
  })
}
// 获取所有的产品的微服务(不分页)
export function getAllProductMicroserviceList(data) {
  return request({
    url: fileName + '/micro-service/all-list',
    method: 'get'
  })
}
// 获取禅道里面的所有产品(不分页)
export function getAllZentaoProductList(data) {
  return request({
    url: fileName + '/zentao/product-list',
    method: 'get'
  })
}
// 获取某个产品 下的项目版本
export function getProductVersionList(data) {
  return request({
    url: fileName + '/products/version-list',
    method: 'get',
    params: data,
  })
}
// 将产品目录(子系统)上移一个
export function sortProduct(data) {
  return request({
    method: 'post',
    url: fileName + '/departs/sort',
    data
  })
}
// 修改过的
// 删除部门
export function removeDepart(data) {
  return request({
    method: 'post',
    url: fileName + '/departs/delete',
    data
  })
}
// 移除部门成员
export function removeMember(data) {
  return request({
    method: 'post',
    url: fileName + '/departs/member/delete',
    data
  })
}
// 获取某个部门的成员列表(分页)
export function getDepartMemberList(data) {
  return request({
    url: fileName + '/departs/member/page',
    method: 'get',
    params: data,
  })
}
// 获取某个部门的成员列表(分页)
export function getDepartDetailFn(data) {
  return request({
    url: fileName + '/departs/detail',
    method: 'get',
    params: data,
  })
}
// 添加部门
export function addDepartsFn(data) {
  return request({
    method: 'post',
    url: fileName + '/departs',
    data
  })
}
// 编辑部门
export function updateDepartFn(data) {
  return request({
    method: 'post',
    url: fileName + '/departs/update',
    data
  })
}
// 将产品分组上移一个
export function sortDeparts(data) {
  return request({
    method: 'post',
    url: fileName + '/departs/sort',
    data
  })
}
// 移动部门
export function moveDeparts(data) {
  return request({
    method: 'post',
    url: fileName + '/departs/move',
    data
  })
}
// 移动成员
export function moveMember(data) {
  return request({
    method: 'post',
    url: fileName + '/departs/member/move',
    data
  })
}
// 获取组织树(没有成员)
export function getNoMemberTree(data) {
  return request({
    url: fileName + '/departs/tree',
    method: 'get',
    params: data,
  })
}
// 获取某个客户下所有用户列表 (部门负责人展示用的) 不分页
export function getOneTenancyAllUser() {
  return request({
    url: fileName + '/tenancies/user/dropdown',
    method: 'get',
  })
}
// 获取某个客户下所有用户列表 (成员列表) 分页
export function getOneTenancyAllUserList(data) {
  return request({
    url: fileName + '/departs/un-joined/user/page',
    method: 'get',
    params: data,
  })
}
// 添加成员到某个部门
export function addMemberToDepart(data) {
  return request({
    method: 'post',
    url: fileName + '/departs/member',
    data
  })
}
// 获取某个部门成员详情
export function getOneUserDetail(data) {
  return request({
    url: fileName + '/departs/user/detail',
    method: 'get',
    params: data,
  })
}
// 修改用户信息
export function updateUserInfo(data) {
  return request({
    method: 'post',
    url: fileName + '/departs/user/info/update',
    data
  })
}
// 修改用户头像
export function updateUserHeadImg(data) {
  return request({
    method: 'post',
    url: fileName + '/departs/user/head-pic/update',
    data
  })
}
// 获取组织架构总人数
export function getDepartsMemberTotal(data) {
  return request({
    url: fileName + '/departs/member-total',
    method: 'get',
    params: data,
  })
}