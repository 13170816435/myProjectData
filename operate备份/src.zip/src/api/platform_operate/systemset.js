import request from "@/utils/request";
const fileName = "/api-operate";
const abilityUrl = "/api-operate";
// 系统设置
//  运行监控----------------------------------------------------------------------------
// 运行监控列表
export function runMonitorsList(parmas) {
  return request({
    url: fileName + "/run-monitors1" + parmas,
    method: "get",
  });
}
// 运行监控报警设置详情
export function getRunMonitorsInfo(id) {
  return request({
    url: fileName + "/run-monitors/warn-setting/detail?tenancy_id=" + id,
    method: "get",
  });
}
// 设置运行监控报警设置详情
export function setRunMonitorsInfo(data) {
  return request({
    url: fileName + "/run-monitors/warn-setting",
    method: "post",
    data: data,
  });
}
// 云朵管理----------------------------------------------------------------------------------------------
// 分页获取云朵列表
export function getCloudsList(parmas) {
  return request({
    url: fileName + "/clouds" + parmas,
    method: "get",
  });
}
// 获取云朵精简列表
export function getCloudsLiteList() {
  return request({
    url: fileName + "/clouds/lite",
    method: "get",
  });
}

// 云朵详情
export function getCloudsInfo(id) {
  return request({
    url: fileName + "/clouds/detail?id=" + id,
    method: "get",
  });
}
// 新增云朵
export function addClouds(data) {
  return request({
    url: fileName + "/clouds",
    method: "post",
    data: data,
  });
}
// 修改云朵
export function putClouds(data) {
  return request({
    url: fileName + "/clouds/update",
    method: "post",
    data: data,
  });
}
// 删除云朵
export function deleteClouds(data) {
  return request({
    url: fileName + "/clouds/delete",
    method: "post",
    data: data,
  });
}
// 获取云朵api详情
export function getCloudsApiInfo(id) {
  return request({
    url: fileName + "/clouds/api/detail?cloud_id=" + id,
    method: "get",
  });
}
// 检测
export function webUrlCheck(data) {
  return request({
    url: fileName + "/clouds/check/webstate",
    method: "post",
    data: data,
  });
}
// 保存云朵api
export function postCloudsApi(data) {
  return request({
    url: fileName + "/clouds/api",
    method: "post",
    data: data,
  });
}
// 产品管理-----------------------------------------------------------------------------
// 获取产品名称（筛选条件）
export function getSoftwareName() {
  return request({
    url: fileName + "/software-products/lite-list",
    method: "get",
  });
}
// 根据上传的文件名字获取 产品名称和版本号
export function getCurProductFileInfor(data) {
  return request({
    url: fileName + "/software-products/version/validate",
    method: "post",
    data: data,
  });
}
// 添加产品
export function addProduct(data) {
  return request({
    url: fileName + "/software-products",
    method: "post",
    data: data,
  });
}
// 产品列表
export function productsList(parmas) {
  return request({
    url: fileName + "/software-products" + parmas,
    method: "get",
  });
}
// 产品列表详情
export function productsInfo(id) {
  return request({
    url: fileName + "/software-products/detail?id=" + id,
    method: "get",
  });
}
// 修改产品
export function putProductsInfo(data) {
  return request({
    url: fileName + "/software-products/update",
    method: "post",
    data: data,
  });
}
// 删除产品
export function delProductsInfo(data) {
  return request({
    url: fileName + "/software-products/delete?id=",
    method: "post",
    data: data,
  });
}
// 下载产品
export function downProductsInfo(id) {
  return request({
    url: fileName + "/software-products/download?id=" + id,
    method: "get",
  });
}
// 发布记录
export function productsRecordList(params) {
  return request({
    url: fileName + "/software-products/log" + params,
    method: "get",
  });
}
// 删除发布记录
export function delProductsRecord(data) {
  return request({
    url: fileName + "/software-products/log/delete",
    method: "post",
    data: data,
  });
}
// 门户设置---------------------------------------------------------------------------------------
// 获取刑侦调阅门户详情
export function getCustomerPortals(data) {
  // 门户ID=0，客户管理修改平台信息ID=‘’，平台运营修改平台信息ID=租户ID
  return request({
    url: fileName + "/portals/detail",
    method: "get",
    params: data,
  });
}
// 获取平台运营 门户详情
export function getPortals(data) {
  // 门户ID=0，客户管理修改平台信息ID=‘’，平台运营修改平台信息ID=租户ID
  return request({
    url: fileName + "/portals/detail",
    method: "get",
    params: data,
  });
}
// 获取图片列表 banner、link、code /api/portals/image/list  （客户管理->刑侦调阅->门户设置）
export function getCustomerPortalsImgList(data) {
  return request({
    url: fileName + "/portals/image/list",
    method: "get",
    params: data,
  });
}
// 获取图片列表-详情 （客户管理->刑侦调阅->门户设置）
export function getCustomerPortalsImgListInfo(data) {
  return request({
    url: fileName + "/portals/image/detail",
    method: "get",
    params: data,
  });
}
// 保存门户设置
export function setPortals(params) {
  return request({
    url: fileName + "/portals",
    method: "post",
    data: params,
  });
}
// 弹框新增图片 1：横幅  2：友情链接  3：二维码/api/portals/image
export function addPortalsImg(params) {
  return request({
    url: fileName + "/portals/image",
    method: "post",
    data: params,
  });
}
// 获取详情
export function getPortalsImgInfo(id) {
  return request({
    url: fileName + "/portals/image?id=" + id,
    method: "get",
  });
}
// 修改详情
export function putPortalsImg(params) {
  return request({
    url: fileName + "/portals/image/update",
    method: "post",
    data: params,
  });
}
// 删除详情
export function delPortalsImgInfo(params) {
  return request({
    url: fileName + "/portals/image/delete",
    method: "post",
    data: params,
  });
}
// 删除平台logo
// 获取图片列表 banner、link、code /api/portals/image/list  （平台运营）
export function getPortalsImgList(type, tid) {
  return request({
    url:
      fileName + "/portals/image/list?category=" + type + "&tenancy_id=" + tid,
    method: "get",
  });
}
// 获取图片列表-详情 （平台运营）
export function getPortalsImgListInfo(id, tid) {
  return request({
    url: fileName + "/portals/image/detail?tenancy_id=" + tid + "&id=" + id,
    method: "get",
  });
}
// 获取图片信息
export function getPortalsImgurl(id) {
  return request({
    responseType: "arraybuffer",
    url: fileName + "/portals/image/url?id=" + id,
    method: "get",
  });
}
// 门户logo
export function getPortalsLogourl(tid) {
  return request({
    responseType: "arraybuffer",
    url: fileName + "/portals/logo?tenancy_id=" + tid,
    method: "get",
  });
}
// 网页图标
export function getBrowserLogourl(tid) {
  return request({
    responseType: "arraybuffer",
    url: fileName + "/portals/favicon?tenancy_id=" + tid,
    method: "get",
  });
}
// 门户logo （刑侦调阅）
export function getCriminallLogourl(data) {
  return request({
    responseType: "arraybuffer",
    url: fileName + "/portals/logo",
    method: "get",
    params: data,
  });
}
// 门户app-logo
export function getPortalsappLogourl(tid) {
  return request({
    responseType: "arraybuffer",
    url: fileName + "/portals/app-logo?tenancy_id=" + tid,
    method: "get",
  });
}
// 文案管理------------------------------------------------------------------------------
// 文案列表
export function getOfficialList(data) {
  return request({
    url: fileName + "/official-documents",
    method: "get",
    params: data,
  });
}
// 获取文案详情
export function getOfficialInfo(data) {
  return request({
    url: fileName + "/official-documents/detail",
    method: "get",
    params: data,
  });
}
// 新增文案
export function addOfficial(params) {
  return request({
    headers: {
      "Content-Type": "multipart/form-data",
    },
    url: fileName + "/official-documents",
    method: "post",
    data: params,
  });
}
// 修改文案
export function putOfficial(params) {
  return request({
    url: fileName + "/official-documents/update",
    method: "post",
    data: params,
  });
}
// 删除文案
export function delOfficial(data) {
  return request({
    url: fileName + "/official-documents/delete",
    method: "post",
    data: data,
    paramsSerializer: (data) => {
      return qs.stringify(data, { indices: false });
    },
  });
}
// 下载文案附件
export function downLoadOfficialFile(data) {
  return request({
    url: fileName + "/official-documents/download",
    method: "GET",
    params: data,
    responseType: "blob",
  });
}
// 修改文案启用状态
export function putOfficialState(parmas) {
  return request({
    url: fileName + "/official-documents/enable-state/update",
    method: "post",
    data: parmas,
  });
}
// 短信模板
// 获取短信分页列表
export function getSmsTemplateList(params) {
  return request({
    url: abilityUrl + "/common/sms-templates" + params,
    method: "get",
  });
}
// 获取客户短信模板(不分页)
export function getAllSmsTemplate(params) {
  return request({
    url: abilityUrl + "/common/sms-templates/tenancy-list" + params,
    method: "get",
  });
}
// 获取客户短信模板(分页)
export function getTenancySmsTemplateList(data) {
  return request({
    url: abilityUrl + "/common/sms-templates/tenancy-template/page",
    method: "get",
    params: data,
  });
}
// 获取客户其它短信模板(分页)--也是所有的短信模板
export function getTenancyAllSmsTemplateList(data) {
  return request({
    url: abilityUrl + "/common/sms-templates/tenancy-template/page",
    method: "get",
    params: data,
  });
}
// 保存客户短信模板启用配置
export function updateTenancySettings(params) {
  return request({
    url: abilityUrl + "/common/sms-templates/tenancy-settings",
    method: "post",
    data: params,
  });
}
// 修改短信模板的状态
export function updateTenancyTemplateState(params) {
  return request({
    url: abilityUrl + "/common/sms-templates/tenancy-template/enabled/update",
    method: "post",
    data: params,
  });
}
// 新增短信模板
export function addSmsTemplate(params) {
  return request({
    url: abilityUrl + "/common/sms-templates",
    method: "post",
    data: params,
  });
}
// 模板详情
export function getSmsTemplateInfo(id) {
  return request({
    url: abilityUrl + `/common/sms-templates/${id}`,
    method: "get",
  });
}
// 修改短信模板
export function putSmsTemplate(id, params) {
  return request({
    url: abilityUrl + `/common/sms-templates/${id}/modify`,
    method: "post",
    data: params,
  });
}
// 修改短信模板
export function delSmsTemplate(id) {
  return request({
    url: abilityUrl + `/common/sms-templates/${id}/delete`,
    method: "post",
  });
}
// 短信统计
export function getSmsStatistics(data) {
  return request({
    url: fileName + "/pub-sms-stat/system",
    method: "GET",
    params: data,
  });
}
// 短信月度统计
export function getSmsMonthStatistics(data) {
  return request({
    url: fileName + "/pub-sms-stat/month",
    method: "GET",
    params: data,
  });
}
// 获取机构短信使用量统计
export function getInstituteUseSmsData(data) {
  return request({
    url: fileName + "/pub-sms-stat/institution-top",
    method: "GET",
    params: data,
  });
}
// 短信统计界面中的短信发送量统计
export function getSmsSendCountData(data) {
  return request({
    url: fileName + "/common/sms/user-send-simple-count-stat",
    method: "GET",
    params: data,
  });
}
// 短信统计界面中的 可查看更多 短信发送量统计(每天的)
export function getSmsDaliySendCountData(data) {
  return request({
    url: fileName + "/common/sms/user-send-count-stat",
    method: "GET",
    params: data,
  });
}
// 获取锁屏banner图列表
export function getLockBanners(data) {
  return request({
    url: fileName + "/banners",
    method: "GET",
    params: data,
  });
}
// 上传锁屏banner图片
export function uploadLockBanner(params) {
  return request({
    url: fileName + "/banners/add",
    method: "post",
    data: params,
  });
}
// 删除锁屏banner图片
export function deleteLockBanner(params) {
  return request({
    url: fileName + "/banners/delete",
    method: "post",
    data: params,
  });
}
// 锁屏banner拖动排序
export function sortLockBanner(params) {
  return request({
    url: fileName + "/banners/ordinal/update",
    method: "post",
    data: params,
  });
}
// 下载 产品软件 文件
export function downloadProductFile(url) {
  return request({
    url: url,
    method: "get",
    responseType: "blob",
  });
}
// 获取黑白名单列表
export function getBlackAndWhiteList(data) {
  return request({
    url: fileName + "/sms-user-roster/page",
    method: "GET",
    params: data,
  });
}
// 移除黑名单
export function removeBlackList(params) {
  return request({
    url: fileName + "/sms-user-roster/delete",
    method: "post",
    data: params,
  });
}
// 添加黑名单
export function addBlackList(params) {
  return request({
    url: fileName + "/sms-user-roster/add",
    method: "post",
    data: params,
  });
}
// 批量添加黑名单
export function addMoreBlackList(params) {
  return request({
    url: fileName + "/sms-user-roster/batch-add",
    method: "post",
    data: params,
  });
}
// 获取短信自动监测配置
export function getMonitorSettings() {
  return request({
    url: fileName + "/sms-user-roster/monitor-settings/detail",
    method: "GET",
  });
}
// 保存短信自动监测配置
export function saveMonitorSettings(params) {
  return request({
    url: fileName + "/sms-user-roster/monitor-settings",
    method: "post",
    data: params,
  });
}
// 获取所有运维用户(不分页)
export function getAllOperationUser() {
  return request({
    url: fileName + "/users/maintenance/simple/list",
    method: "GET",
  });
}

// 微服务管理
// 获取微服务列表
export function getMicroserviceList(data) {
  return request({
    url: fileName + "/micro/service/detail/group-list",
    method: "post",
    data: data,
  });
}

// 获取更新记录
export function getMicroserviceHistory(data) {
  return request({
    url: fileName + "/micro/service/detail/history/page-list",
    method: "post",
    data: data,
  });
}

// 获取项目列表
export function getGroupList() {
  return request({
    url: fileName + "/micro/service/group/select-list",
    method: "get",
  });
}

// 获取微服务列表（用于多选下拉）
export function getServiceList() {
  return request({
    url: fileName + "/micro/service/select-list",
    method: "get",
  });
}

// 关于系统->点击微服务  查看某产品下 所依赖的全部微服务
export function watchDependencyMicroList (params) {
  return request({
    url: fileName + '/micro/service/detail/page-dependency-list',
    method: 'post',
    data: params
  })
}
