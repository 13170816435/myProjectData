import request from '@/utils/request'
import qs from 'qs'
const fileName = '/api-operate'
const RoutBaseUrl = '/api-datamining'
const medRoutBaseUrl = '/api-telemed'
const teachUrl = '/api-teaching'
const pacsRoutBaseUrl = '/api-cloudpacs'
// 获取系统列表
export function getSystemList (data) {
  return request({
    url: fileName + '/systems/lite',
    method: 'get',
    params: data
  })
}
// 获取会诊申请机构列表
export function getConsultApplyInstituteList (data) {
  return request({
    url: fileName + '/data-mining/consult-apply-institution',
    method: 'get',
    params: data
  })
}
// 获取会诊服务机构列表
export function getConsultInstituteList (data) {
  return request({
    url: fileName + '/data-mining/consult-work-institution',
    method: 'get',
    params: data
  })
}
// 获取诊断申请机构列表
export function getDiagnosisApplyInstituteList (data) {
  return request({
    url: fileName + '/data-mining/diagnostic-apply-institution',
    method: 'get',
    params: data
  })
}
// 获取诊断服务机构列表
export function getDiagnosisInstituteList (data) {
  return request({
    url: fileName + '/data-mining/diagnostic-work-institution',
    method: 'get',
    params: data
  })
}
// 获取科室列表
export function getOfficeList (data) {
  return request({
    url: fileName + '/offices/lite-list',
    method: 'get',
    params: data
  })
}
// 获取当前客户下的所有统计数据
export function getCurTenancyStatistics (data) {
  return request({
    url: fileName + '/data-mining/info',
    method: 'get',
    params: data
  })
}
// 获取当前客户下的pacs统计数据
export function getCurTenancyPacsStatistics (data) {
  return request({
    url: fileName + '/data-mining/pacs-dashboard',
    method: 'get',
    params: data
  })
}
// 获取当前客户下的远程医疗统计数据
export function getCurTenancyTeleStatistics (data) {
  return request({
    url: fileName + '/data-mining/telemed-dashboard',
    method: 'get',
    params: data
  })
}
// 获取当前客户下的教学统计数据
export function getCurTenancyEducationStatistics (data) {
  return request({
    url: fileName + '/data-mining/education-dashboard',
    method: 'get',
    params: data
  })
}
// 获取当前客户下的idcas数据
export function getCurTenancyIdcasStatistics (data) {
  return request({
    url: fileName + '/data-mining/idcas-dashboard',
    method: 'get',
    params: data
  })
}
// 获取当前客户下的基本统计数据
export function getCurTenancyBasicStatistics (data) {
  return request({
    url: fileName + '/data-mining/tenancy-basic-statistics',
    method: 'get',
    params: data
  })
}
// 远程会诊申请量 -- 表格
export function getConsultApplyQuantity(data) {
  return request({
    url: fileName + '/data-mining/consult-apply-statistics',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 远程会诊诊断量 -- 表格
export function getConsultDiagnosisQuantity(data) {
  return request({
    url: fileName + '/data-mining/consult-work-statistics',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 获取会诊的检查类型
export function getConsultExamineType (data) {
  return request({
    url: fileName + '/data-mining/consult/examine-type',
    method: 'get',
    params: data
  })
}
// 获取诊断的检查类型
export function getDiagnosticExamineType (data) {
  return request({
    url: fileName + '/data-mining/diagnostic/examine-type',
    method: 'get',
    params: data
  })
}
// 获取检查类型
export function getInspectTypeList (data) {
  return request({
    url: fileName + '/data-mining/pacs/examine-type',
    method: 'get',
    params: data
  })
}
// 客户分页列表
export function getCustomerList (data) {
  return request({
    url: fileName + '/data-mining/tenancy/pagination',
    method: 'get',
    params: data
  })
}
// 获取数据之窗基础数据统计
export function getDataMiningDashboard () {
  return request({
    url: fileName + '/data-mining/dashboard',
    method: 'get',
  })
}
// 获取某客户下的业务系统数据
export function getCurTenancyBusinessData (data) {
  return request({
    url: fileName + '/data-mining/business-system/statistic',
    method: 'get',
    params: data
  })
}
// 获取服务中心
export function getServicecenterList (data) {
  return request({
    url: fileName + '/service-centers/lite',
    method: 'get',
    params: data
  })
}
// 获取教学中心
export function getTeachCenterList (data) {
  return request({
    url: fileName + '/service-centers/lite',
    method: 'get',
    params: data
  })
}
// 获取某教学中心下的  所属机构列表
export function getInstituteListByTeachCenter (data) {
  return request({
    url: fileName + '/institutions/lite',
    method: 'get',
    params: data
  })
}
// 获取某教学中心下的  签约讲师列表
export function getServiceDoctorsByTeachCenter (data) {
  return request({
    url: fileName + '/course-teach',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 获取某教学中心下的  学员列表
export function getTeachUserByTeachCenter (data) {
  return request({
    url: teachUrl + '/study-student',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 远程医疗 诊断申请量统计
export function getDiagnosisApplyStatistics (data) {
  return request({
    url: fileName + '/data-mining/diagnostic-apply-statistics',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 远程医疗 诊断工作量统计
export function getDiagnosisWorkStatistics (data) {
  return request({
    url: fileName + '/data-mining/diagnostic-work-statistics',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 获取影像共享统计报表数据
export function getImageShareQuantity (data) {
  return request({
    url: fileName + '/data-mining/idcas-statistics',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 获取远程教学 课程量统计报表数据
export function getTeachCourseQuantity (data) {
  return request({
    url: fileName + '/data-mining/course-volume-statistics',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 获取远程教学 学习统计报表数据
export function getTeachStudyQuantity (data) {
  return request({
    url: fileName + '/data-mining/study-volume-statistics',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 获取云pacs统计报表数据
export function getPacsQuantity (data) {
  return request({
    url: fileName + '/data-mining/pacs-statistics',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 获取系统下 机构列表
export function getInstituteListBySystem (data) {
  return request({
    url: fileName + '/institutions/lite',
    method: 'get',
    params: data
  })
}