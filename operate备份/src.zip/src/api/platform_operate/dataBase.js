import request from '@/utils/request'
import qs from 'qs'
const fileName = '/api-operate'

// 获取租户概要
export function getTenancySummary (data) {
  return request({
    url: fileName + '/tenancy-db-upgrade/tenancy-summary',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 获取当前最新版本的升级情况
export function getTenancyVersionLatest () {
  return request({
    url: fileName + '/tenancy-db-upgrade/version/latest',
    method: 'get',
  })
}
// 获取更新记录列表
export function getUpdateMemoryList (data) {
  return request({
    url: fileName + '/tenancy-db-upgrade/logs',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 获取版本列表
export function getVersionList (data) {
  return request({
    url: fileName + '/tenancy-db-upgrade/version-list',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 删除某个版本
export function beganDeleteThisVersion (data) {
  return request({
    url: fileName + '/tenancy-db-upgrade/version/delete',
    method: 'post',
    data: data
  })
}
// 数据库检测
export function dataBaseCheck (data) {
  return request({
    url: fileName + '/tenancy-db-upgrade/check',
    method: 'post',
    data: data
  })
}
// 数据库更新
export function dataBaseUpdate (data) {
  return request({
    url: fileName + '/tenancy-db-upgrade/upgrade',
    method: 'post',
    data: data
  })
}
// 上传版本
export function uploadVersionFile (data) {
  return request({
    url: fileName + '/tenancy-db-upgrade/version/add',
    method: 'post',
    data: data
  })
}
// 更新数据库（crm、单个客户、多个客户）
export function updateCurDataBase (data) {
  return request({
    url: fileName + '/tenancies/upgrade-database/update',
    method: 'post',
    data: data
  })
}
// 获取更新内容
export function getDataBaseUpdateContent (data) {
  return request({
    url: fileName + '/tenancies/database-upgrade-script',
    method: 'get',
    params: data
  })
}
// 获取更新数据库更新配置
export function getDataBaseUpdateSettings () {
  return request({
    url: fileName + '/tenancy-db-upgrade/settings',
    method: 'get',
  })
}
// 获取更新人员列表(不分页)
export function getUpdatePeopleList () {
  return request({
    url: fileName + '/users/all-operations',
    method: 'get',
  })
}
// 保存更新数据库更新配置
export function saveDataBaseUpdateSettings (data) {
  return request({
    url: fileName + '/tenancy-db-upgrade/settings',
    method: 'post',
    data: data
  })
}
// 获取存档注册 服务列表
export function getArchiveServiceList (data) {
  return request({
    url: fileName + '/archives',
    method: 'GET',
    params: data
  })
}
// 新增存档服务
export function addArchiveService (data) {
  return request({
    url: fileName + '/archives',
    method: 'post',
    data: data
  })
}
// 编辑存档服务
export function updateArchiveService (data) {
  return request({
    url: fileName + '/archives/update',
    method: 'post',
    data: data
  })
}