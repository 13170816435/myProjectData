import request from '@/utils/request'
// import qs from 'qs'
const fileName = '/api-operate'
const abilityUrl = '/api-operate'
// 获取基础（search）数据--枚举
export function getConstants () {
  return request({
    url: fileName + '/constants/enumerations',
    method: 'get'
  })
}
// 获取基础（search）数据--字典接口
export function getConstantsBytype (url) {
  return request({
    url: fileName + url,
    method: 'get'
  })
}
// 获取城市联动json
export function getCityJson (parmas) {
  return request({
    url: fileName + '/regions?parent_code=' + parmas.parent_code + '&level=' + parmas.level,
    method: 'get'
  })
}
// 获取阿波罗里面 的系统版本
export function getMyCurSystemVersion () {
  return request({
    url: fileName + '/tenancies/release-version',
    method: 'get'
  })
}
// 修改客户正式版状态
export function putVersionStatus (data) {
  return request({
    url: fileName + '/tenancies/official-version-state/update',
    method: 'post',
    data: data
  })
}
// 添加客户
export function addCostomer (params) {
  return request({
    url: fileName + '/tenancies',
    method: 'post',
    data: params
  })
}
// 修改客户
export function putCostomer (id, data) {
  return request({
    url: fileName + `/tenancies/${id}/update`,
    method: 'post',
    data: data
  })
}
//分页获取客户授权日志列表
export function getServiceLogList (data) {
  return request({
    url: fileName + '/tenancies/service-log',
    method: 'get',
    params: data
  })
}
//获取系统或服务中心
export function getSystemOrServiceCenterList (data) {
  return request({
    url: fileName + '/tenancies/service-application/business-system',
    method: 'get',
    params: data
  })
}
//获取某系统/服务中心下的机构
export function getInstituteListBySystem (data) {
  return request({
    url: fileName + '/tenancies/service-application/institution',
    method: 'get',
    params: data
  })
}
// 获取平台设置好了的策略
export function getServicePolicy (data) {
  return request({
    url: fileName + '/operates/service-expiration-policy',
    method: 'get',
    params: data
  })
}
// 保存平台设置的策略
export function saveServicePolicy (data) {
  return request({
    url: fileName + '/operates/service-expiration-policy',
    method: 'post',
    data: data
  })
}
// 获取客户设置好了的策略
export function getTenancyServicePolicy (data) {
  return request({
    url: fileName + '/tenancies/service-expiration-policy',
    method: 'get',
    params: data
  })
}
// 保存客户设置的策略
export function saveTenancyServicePolicy (data) {
  return request({
    url: fileName + '/tenancies/service-expiration-policy',
    method: 'post',
    data: data
  })
}

// 根据电话获取姓名，工号等
export function getLoginName (url) {
  return request({
    url: fileName + url,
    method: 'get'
  })
}
// 客户分页列表
export function getCostomerList (url) {
  return request({
    url: fileName + url,
    method: 'get'
  })
}
// 获取某个客户的 所有信息
export function getCustomerTotalInfor (data) {
  return request({
    url: fileName + '/data-mining/data-window',
    method: 'get',
    params: data
  })
}
// 客户详情
export function getCostomerinfoByid (id) {
  var _id = id ? '?id=' + id : ''
  return request({
    url: fileName + '/tenancies/complete-details' + _id,
    method: 'get'
  })
}
// 创建客户时 详情
export function getAddCostomerinfoByid (id) {
  var _id = id ? '?id=' + id : ''
  return request({
    url: fileName + '/tenancies/create-complete-detail' + _id,
    method: 'get'
  })
}
// 平台介绍 新增
export function addPlatform (id, params) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: fileName + `/tenancies/${id}/platform-setting`,
    method: 'post',
    data: params
  })
}
// 媒体文件请求图片地址
export function getImgByid (id) {
  return request({
    url: fileName + `/medias/${id}`,
    method: 'get'
  })
}
// 获取服务授权服务列表
export function getAauthorizedService (id) {
  return request({
    url: fileName + '/tenancies/service?tenancy_id=' + id,
    method: 'get'
  })
}
// 申请客户服务授权服务
export function applyAauthorizedService (params) {
  return request({
    url: fileName + `/tenancies/apply-service`,
    method: 'post',
    data: params
  })
}
// 获取租户授权服务
export function getServiceDetail (data) {
  return request({
    url: fileName + '/tenancies/service-authorize-code',
    method: 'get',
    params: data
  })
}
// 填写服务授权码
export function putAuthorizationCode (id, code) {
  return request({
    url: fileName + `/tenancies/${id}/authorization/update`,
    method: 'post',
    data: {
      authorize_code: code
    }
  })
}
// 数据库类型
export function databaseType (id) {
  return request({
    url: fileName + `/tenancies/${id}/database-category`,
    method: 'get'
  })
}
// 获取所有的数据库类型(mysql或 oracle)
export function getAllDataBaseType () {
  return request({
    url: fileName + '/tenancies/database-type',
    method: 'get'
  })
}

// 数据库详情
export function getDatabaseDetail (data) {
  return request({
    url: fileName + '/tenancies/databases',
    method: 'get',
    params: data
  })
}
// 数据库详情---新接口（返回结果是AES加密的）
export function getCurDatabaseDetail (data) {
  return request({
    url: fileName + '/tenancies/database-info',
    method: 'get',
    params: data
  })
}
// 获取当前客户下的 业务系统
export function getCurTenancyBussessType (data) {
  return request({
    url: fileName + '/tenancies/database-upgrade-business',
    method: 'get',
    params: data
  })
}

// 获取水平分表配置
export function getHorizontalSubTable (data) {
  return request({
    url: fileName + '/tenancies/database-shardings',
    method: 'get',
    params: data
  })
}
// 保存水平分表配置
export function saveHorizontalSubTable (params) {
  return request({
    url: fileName + '/tenancies/database-sharding',
    method: 'post',
    data: params
  })
}
// 新增和修改数据库
export function saveDatabase (params) {
  return request({
    url: fileName + '/tenancies/database',
    method: 'post',
    data: params
  })
}
// 修改数据库
export function putDatabase (data) {
  return request({
    url: fileName + '/tenancies/database/update',
    method: 'post',
    data: data
  })
}
// 重新初始化数据库
export function resetDataBase (params) {
  return request({
    url: fileName + '/tenancies/database/state',
    method: 'put',
    data: params
  })
}
// 获取租户详情
export function getCostomerInfo (id) {
  return request({
    url: fileName + '/tenancies/detail?id=' + id,
    method: 'get'
  })
}
// 获取租户详情
export function getCostomerInfoDetail () {
  return request({
    url: fileName + '/tenancies/detail',
    method: 'get'
  })
}
// 获取平台详情
export function getPlatformInfoByid (id) {
  return request({
    url: fileName + '/tenancies/basis-info?id=' + id,
    method: 'get'
  })
}
// 是否应用门户
export function isSetPortals (params) {
  return request({
    url: fileName + '/tenancies/use/portal',
    method: 'post',
    data: params
  })
}
// 平台设置---------------------------------------------------------------------------------------------
// 保存配置
export function commonSettings (params) {
  return request({
    url: abilityUrl + '/common-settings',
    method: 'POST',
    data: params
  })
}

// 获取服务类型
export function getServicetypeList () {
  return request({
    url: fileName + '/tenancies/service-type/lite',
    method: 'get'
  })
}
// 获取租户管理员
export function getAdminList (data) {
  return request({
    url: fileName + '/tenancies/admin?user_name=&tenancy_id=' + data,
    method: 'get'
  })
}
// 获取客户下的所有用户不分页
export function getUserUnderTenancy (data) {
  return request({
    url: fileName + '/users/brief',
    method: 'get',
    params: data
  })
}
// 获取运维用户不分页
export function getOperationUserList () {
  return request({
    url: fileName + '/users/operation/lite',
    method: 'get'
  })
}
// 获取租户列表（简介）
export function getTenanciesLiteFn () {
  return request({
    url: fileName + '/tenancies/lite',
    method: 'get'
  })
}
// 获取客户首页大屏列表
export function getLargeScreenlist () {
  return request({
    url: fileName + '/operates/data-large-screen',
    method: 'get'
  })
}
// 新增大屏
export function addLargeScreen (params) {
  return request({
    url: fileName + '/operates/data-large-screen',
    method: 'POST',
    data: params
  })
}
// 修改客户
export function putLargeScreen (data) {
  return request({
    url: fileName + '/operates/data-large-screen/update',
    method: 'post',
    data: data
  })
}
// 删除大屏
export function delLargeScreen (data) {
  return request({
    url: fileName + '/operates/data-large-screen/delete',
    method: 'post',
    data: data
  })
}
// 获取租户类型
export function getAllTenancyType () {
  return request({
    url: fileName + '/tenancies/type',
    method: 'get'
  })
}
// 获取医网客户列表
export function getEwTenanciesLiteFn () {
  return request({
    url: fileName + '/clouds/ew-customer/list',
    method: 'get'
  })
}
// 获取医网某个客户下的项目列表
export function getEwProjectList (data) {
  return request({
    url: fileName + '/clouds/ew-project/list',
    method: 'get',
    params: data
  })
}
// 通过云朵id 项目列表
export function getProjectListByCloudId (data) {
  return request({
    url: fileName + '/clouds/customer-project/list',
    method: 'get',
    params: data
  })
}
// 获取客户开通服务与系统列表
export function getAllBusinessSystem () {
  return request({
    url: fileName + '/tenancies/open-service/systems',
    method: 'get',
  })
}

// 客户列表-客户状态数量统计
export function getCustomerStatusCount(){
  return request({
    url: fileName + '/tenancies/state/statistics',
    method: 'get',
  })
}
// 更新客户状态(比如冻结和解冻)
export function updateTenancyState (data) {
  return request({
    url: fileName + '/tenancies/state/update',
    method: 'post',
    data: data
  })
}