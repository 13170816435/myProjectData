import request from '@/utils/request'
import qs from 'qs'
const fileName = '/api-operate'
// const abilityUrl = '/api-operate'
const abilityUrl = '/api-ability'
// 获取所有的厂商 (不分页)
export function getAllFirm (parmas) {
  return request({
    url: abilityUrl + '/ai/firms/all',
    method: 'get'
  })
}
// 获取厂商(分页)
export function getFirmList (data) {
  return request({
    url: abilityUrl + '/ai/firms',
    method: 'get',
    params: data
  })
}
// 添加厂商信息
export function addFirm (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: abilityUrl + '/ai/firms',
    method: 'post',
    data: data
  })
}
// 修改厂商
export function putFirm (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: abilityUrl + '/ai/firms/update',
    method: 'post',
    data: data
  })
}
// 获取厂商详情
export function getFirmDetail (id) {
  return request({
    url: abilityUrl + `/ai/firms/${id}`,
    method: 'get'
  })
}
// 删除厂商
export function delFirm (id) {
  return request({
    url: abilityUrl + `/ai/firms/${id}/delete`,
    method: 'post'
  })
}
// 操作厂商状态
export function putFirmState (data) {
  return request({
    url: abilityUrl + `/ai/firms/${data.id}/${data.state}/update`,
    method: 'post',
    data: data
  })
}
// 查询厂商类型 (接口类型)
export function getFirmTypes () {
  return request({
    url: abilityUrl + '/ai/firms/types',
    method: 'get'
  })
}
// 查询厂商编码自定义
export function getFirmCodes () {
  return request({
    url: abilityUrl + '/ai/firms/codes',
    method: 'get'
  })
}
// 获取AI厂商接口配置项(配置项数量为0时不显示配置)
export function getFirmSetting (code) {
  return request({
    url: abilityUrl + `/ai/firms/${code}/setting-items`,
    method: 'get'
  })
}
// 浏览厂商logo
export function getFirmLogo (token) {
  return request({
    url: abilityUrl + `/ai/firms/logo/${token}`,
    method: 'get',
    responseType: 'arraybuffer'
  })
}
// 智能诊断-AI服务
// 获取AI服务(分页)
export function getServicesList (data) {
  return request({
    url: abilityUrl + '/ai/services',
    method: 'get',
    params: data
  })
}
// 添加AI服务
export function addServices (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: abilityUrl + '/ai/services',
    method: 'post',
    data: data
  })
}
// 修改AI服务
export function putServices (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: abilityUrl + '/ai/services/update',
    method: 'post',
    data: data
  })
}
// 操作服务状态
export function putServiceState (data) {
  return request({
    url: abilityUrl + `/ai/services/${data.id}/${data.state}/update`,
    method: 'post',
    data: data
  })
}
// 获取AI服务详情
export function getServicesDetail (id) {
  return request({
    url: abilityUrl + `/ai/services/${id}`,
    method: 'get'
  })
}
// 删除AI服务
export function delServices (id) {
  return request({
    url: abilityUrl + `/ai/services/${id}/delete`,
    method: 'post'
  })
}
// 客户开通AI 服务
export function addTenancyServices (data) {
  return request({
    url: abilityUrl + '/ai/services/tenancy-services',
    method: 'post',
    data: data
  })
}
// 获取客户AI服务列表(分页)
export function getTenancyServicesList (data) {
  return request({
    url: abilityUrl + '/ai/services/tenancy-services',
    method: 'get',
    params: data
  })
}
// 启用/关闭客户AI服务
export function putTenancyServiceState (data) {
  return request({
    url: abilityUrl + `/ai/services/tenancy-services/${data.id}/${data.state}/update`,
    method: 'post',
    data: data
  })
}
// 获取AI服务列表(不分页)
export function getServicesLittle (data) {
  return request({
    url: abilityUrl + '/ai/services/little',
    method: 'get',
    params: data
  })
}
// 客户关闭AI服务
export function delTenancyServices (id) {
  return request({
    url: abilityUrl + `/ai/services/tenancy-services/${id}/delete`,
    method: 'post'
  })
}
// 获取AI服务支持的 检查类型
export function getServicesExamType () {
  return request({
    url: abilityUrl + '/ai/services/examines',
    method: 'get'
  })
}
// 获取AI服务分类
export function getServicesType () {
  return request({
    url: abilityUrl + '/ai/services/ai-types',
    method: 'get'
  })
}
// 获取服务配置
export function getServiceSetting () {
  return request({
    url: abilityUrl + '/ai/services/setting-items',
    method: 'get'
  })
}
// 浏览AI服务 logo
export function getServicesLogo (token) {
  return request({
    url: abilityUrl + `/ai/Services/logo/${token}`,
    method: 'get',
    responseType: 'arraybuffer'
  })
}
// 检测记录
// 检测记录列表(分页)
export function getExamineList (data) {
  return request({
    url: abilityUrl + '/ai/examines',
    method: 'get',
    params: data
  })
}
// 客户的检测记录列表
export function getTenancyExamineList (data) {
  return request({
    url: abilityUrl + '/ai/examines/tenancy-examines',
    method: 'get',
    params: data
  })
}
// 检测记录详情
export function getExaminesDetail (id) {
  return request({
    url: abilityUrl + `/ai/examines/${id}`,
    method: 'get'
  })
}
// 获取医疗机构
export function getAllInstitutions (data) {
  return request({
    url: fileName + '/institutions/all',
    method: 'get',
    params: data
  })
}
// 获取机构列表精简信息
export function getInstitutionListLite (params) {
  var _parmas = params ? params : ''
  return request({
    url: fileName + '/institutions/lite' + _parmas,
    method: 'get'
  })
}
// 修改检测状态
export function updateExcuteState (data) {
  return request({
    url: abilityUrl + '/ai/examines/exec-state',
    method: 'post',
    data: data
  })
}
// 数据概览
// 获取橄榄统计
export function getTotalStatistics () {
  return request({
    url: abilityUrl + '/ai/examines/total-statistics',
    method: 'get'
  })
}
// 获取G2 图形数据
export function getChartData (data) {
  return request({
    url: abilityUrl + '/ai/examines/examine-statistics',
    method: 'get',
    params: data
  })
}
// 获取自定义列
export function getMyCustomeColumn () {
  return request({
    url: abilityUrl + '/ai/examines/custome-column',
    method: 'get'
  })
}
// 保存自定义列
export function SaveColumnCustom (data) {
  return request({
    url: abilityUrl + '/ai/examines/custome-column',
    method: 'post',
    data: data
  })
}
// 获取所有厂商以及接入的服务(简洁)列表
export function firmServiceLittles () {
  return request({
    url: abilityUrl + '/ai/services/firm-service-littles',
    method: 'get'
  })
}
// 服务开通
export function addOpenAiService (data) {
  return request({
    url: abilityUrl + '/ai/services/open-ai-services',
    method: 'post',
    data: data
  })
}
// 删除开通的服务
export function deleteOpenAiService (data) {
  return request({
    url: abilityUrl + `/ai/services/open-ai-services/delete`,
    method: 'post',
    data:data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 查询服务开通列表
export function openAiServiceSearch (data) {
  return request({
    url: abilityUrl + '/ai/services/open-ai-services',
    method: 'get',
    params: data
  })
}
// 保存机构AI服务配置
export function openAiServiceConfig (data) {
  return request({
    url: abilityUrl + '/ai/services/open-ai-service-config',
    method: 'post',
    data: data
  })
}
// 获取开通AI服务列表
export function openAiServiceList (id) {
  return request({
    url: abilityUrl + `/ai/services/open-ai-service-list`,
    method: 'get',
    params:id
  })
}
// 更新业务状态
export function updateAIState (data) {
  return request({
    url: abilityUrl + '/ai/tpexamines/update-aistate',
    method: 'post',
    data:data
  })
}

/* 病例管理 */
// 查询AI病例分类列表
export function getCaseTypeAll (data) {
  return request({
    url: abilityUrl + '/ai/cases/casetypeall',
    method: 'get',
    params:data
  })
}

// 查询AI病例分类列表
export function getCaseList (data) {
  return request({
    url: abilityUrl + '/ai/cases/list',
    method: 'get',
    params:data
  })
}

/* 质量评价 */
// 评价统计列表
export function getEvaluationStatisticsList (data) {
  return request({
    url: abilityUrl + '/ai/evalvation/evaluation_statistics',
    method: 'get',
    params:data
  })
}

// 查询评价结果枚举列表
export function getEvaluationType (data) {
  return request({
    url: abilityUrl + '/ai/evalvation/evaluation_type',
    method: 'get',
    params:data
  })
}

// 查询评价记录列表
export function getEvaluationList (data) {
  return request({
    url: abilityUrl + '/ai/evalvation/evaluation_list',
    method: 'get',
    params:data
  })
}

/* 诊断统计 */
// 获取诊断使用量
export function getDiagnosisStatisticsList (data) {
  return request({
    url: abilityUrl + '/ai/examines/diagnosis-statistics',
    method: 'get',
    params:data
  })
}

// 获取诊断效率
export function getDiagnosisRate (data) {
  return request({
    url: abilityUrl + '/ai/examines/diagnosis-rate',
    method: 'get',
    params:data
  })
}
