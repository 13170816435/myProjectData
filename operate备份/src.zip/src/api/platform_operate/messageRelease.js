import request from '@/utils/request'
import qs from 'qs'
const fileName = '/api-operate'
const abilityUrl = '/api-operate'
// 获取信息列表(公告和站内通知)
export function getInformationsList (data) {
  return request({
    url: fileName + '/informations',
    method: 'get',
    params: data
  })
}
// 获取站内通知列表
export function getNoticeList (data) {
  return request({
    url: fileName + '/ai/examines',
    method: 'get',
    params: data
  })
}
// 新增信息
export function addInformation (data) {
  return request({
    url: fileName + '/informations',
    method: 'post',
    data: data
  })
}
// 删除信息
export function deleteInformation (data) {
  return request({
    url: fileName + '/informations/delete',
    method: 'post',
    data: data
  })
}
// 修改信息
export function putInformation (data) {
  return request({
    url: fileName + '/informations/update',
    method: 'post',
    data: data
  })
}
// 获取信息详情
export function getInformationDetail (data) {
  return request({
    url: fileName + '/informations/detail',
    method: 'get',
    params: data
  })
}
// 获取客户列表分页
export function getTenancyList (data) {
  return request({
    url: fileName + '/tenancies',
    method: 'get',
    params: data
  })
}
// 获取租户列表（简介）
export function getTenanciesLiteFn (data) {
  return request({
    url: fileName + '/tenancies/lite',
    method: 'get',
    params: data
  })
}
// 获取机构列表（简介）
export function getInstitutionsFn (data) {
  return request({
    url: fileName + '/institutions/lite',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 获取系统列表（简介）
export function getSystemFn (data) {
  return request({
    url: fileName + '/informations/recipient',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 获取用户信息
export function getUserInforList (data) {
  return request({
    url: fileName + '/informations/user/pagination',
    method: 'get',
    params: data
  })
}
// 获取底部最新的那条公告信息
export function getUserLatest (data) {
  return request({
    url: fileName + '/informations/user/latest',
    method: 'get',
    params: data
  })
}
// 单独获取最新的通知
export function getCurLastNotice () {
  return request({
    url: fileName + '/informations/user/un-read/notice',
    method: 'get'
  })
}
// 头部消息总数
export function getInformationTotal() {
  return request({
    url: fileName + '/informations/type',
    method: 'get',
  })
}
// 修改阅读状态
export function updateReadState (data) {
  return request({
    url: fileName + '/informations/read-state/update',
    method: 'post',
    data: data
  })
}