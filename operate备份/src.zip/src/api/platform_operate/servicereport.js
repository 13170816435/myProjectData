import request from '@/utils/request'
const fileName = '/api-operate'

// 新增推送
export function addServiceReports (data) {
  return request({
    url: fileName + '/service-reports',
    method: 'post',
    data: data
  })
}
// 服务报告列表
export function getServiceReportsList (data) {
  return request({
    url: fileName + '/service-reports' + data,
    method: 'get',
  })
}
// 推送记录
export function getPushReportsList (data) {
  return request({
    url: fileName + '/service-reports/publish' + data,
    method: 'get',
  })
}
// 服务报告详情
export function getServiceReportsInfo (id) {
  return request({
    url: fileName + '/service-reports/detail?id=' + id,
    method: 'get',
  })
}
// 服务报告详情
export function putServiceReportsInfo (data) {
  return request({
    url: fileName + '/service-reports/update',
    method: 'post',
    data: data
  })
}
