import request from '@/utils/request'
// import qs from 'qs'
// const barse = 'http://192.168.1.207:9020'
const RoutBaseUrl = '/api-cloudpacs'

// 测值绑定
export function MeasureBindPage (data) {
  return request({
    url: RoutBaseUrl + '/Config/MeasureBind/Page',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}

// 测值配置
export function MeasureItemPage (data) {
  return request({
    url: RoutBaseUrl + '/Config/MeasureItem/Page',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}

// 测值-心脏测值
// /api/Report/uis/{id}/measuregynecological
// 获取心脏测值详情
export function FetchMeasureHeart (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measureheart/' + data.id,
    method: 'GET'
    // params: data
    // baseURL: barse
  })
}
// 新增-心脏-测值
export function AddMeasureHeart (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measureheart',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改-心脏-测值
export function ModifyMeasureHeart (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measureheart',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}
// 测值-妇科彩超-测值
// 获取-妇科彩超-测值详情
export function FetchMeasureGyneCological (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measuregynecological/' + data.id,
    method: 'GET'
    // params: data
    // baseURL: barse
  })
}
// 新增-妇科彩超--测值
export function AddMeasureGyneCological (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measuregynecological',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改-妇科彩超--测值
export function ModifyMeasureGyneCological (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measuregynecological',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}

// 测值-中孕早期-四维-测值
// 获取-中孕早期-四维-测值详情
export function FetchPregnancyeMeasurel4d (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurempregnancye4d/' + data.id,
    method: 'GET'
    // params: data
    // baseURL: barse
  })
}
// 新增-中孕早期-四维--测值
export function AddPregnancyeMeasurel4d (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurempregnancye4d',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改-中孕早期-四维--测值
export function ModifyPregnancyeMeasurel4d (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurempregnancye4d',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}
// 测值-中孕-四维-测值
// 获取-中孕-四维-测值详情
export function FetchMeasurelPregnancy4d (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurempregnancy4d/' + data.id,
    method: 'GET'
    // params: data
    // baseURL: barse
  })
}
// 新增-中孕-四维--测值
export function AddMeasurelPregnancy4d (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurempregnancy4d',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改-中孕-四维--测值
export function ModifyMeasurelPregnancy4d (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurempregnancy4d',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}
// 测值-晚孕-测值
// 获取-晚孕-测值详情
export function FetchMeasurelPregnancy (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurelpregnancy/' + data.id,
    method: 'GET'
    // params: data
    // baseURL: barse
  })
}
// 新增-晚孕--测值
export function AddMeasurelPregnancy (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurelpregnancy',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改-晚孕--测值
export function ModifyMeasurelPregnancy (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurelpregnancy',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}
// 测值-NT-测值
// 获取-NT-测值详情
export function FetchMeasurelNT (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurent/' + data.id,
    method: 'GET'
    // params: data
    // baseURL: barse
  })
}
// 新增-NT--测值
export function AddMeasurelNT (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurent',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改-NT--测值
export function ModifyMeasurelNT (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurent',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}

// 获取-CV-测值详情
export function FetchMeasurelCV (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurecv/' + data.id,
    method: 'GET'
    // params: data
    // baseURL: barse
  })
}
// 新增-CV--测值
export function AddMeasurelCV (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurecv',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改-CV--测值
export function ModifyMeasurelCV (data) {
  return request({
    url: RoutBaseUrl + '/Report/uis/' + data.rid + '/measurecv',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}
