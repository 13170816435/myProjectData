import request from '@/utils/request'
import qs from 'qs'
const abilityRoutBaseUrl = '/api-operate'

// 获取用户CA认证状态 
export function getCaAuthStatus (data) {
  return request({
    url: abilityRoutBaseUrl + '/ca/auth-status',
    method: 'get',
    params: data
  })
}

// CA用户鉴权
export function postCaAuth (data) {
  return request({
    url: abilityRoutBaseUrl + '/ca/auth',
    method: 'post',
    data: data
  })
}

// CA推送签名
export function postCaPush (data) {
  return request({
    url: abilityRoutBaseUrl + '/ca/push',
    method: 'post',
    data: data
  })
}

// CA验签
export function postCaVerify (data) {
  return request({
    url: abilityRoutBaseUrl + '/ca/verify',
    method: 'post',
    data: data
  })
}
