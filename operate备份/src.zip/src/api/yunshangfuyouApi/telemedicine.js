import request from '@/utils/request'
import qs from 'qs'
const medRoutBaseUrl = '/api-telemed'
const pacsRoutBaseUrl = '/api-cloudpacs'
const operateRoutBaseUrl = '/api-operate'
const idcasRoutBaseUrl = '/api-archive'  // 之前是api-idcas
// 获取省市县
export function getRegions (data) {
  return request({
    url: operateRoutBaseUrl + '/regions',
    method: 'get',
    params: data
  })
}
// 获取用户详情
export function getUserDetail () {
  return request({
    url: operateRoutBaseUrl + '/users/detail',
    method: 'get'
  })
}
// 获取雪花id
export function getId () {
  return request({
    url: medRoutBaseUrl + '/ids',
    method: 'get'
  })
}
// 获取可申请的会诊类型
export function getCanApplyConsultKinds () {
  return request({
    url: medRoutBaseUrl + '/consultations/can-apply-consult-kinds',
    method: 'get'
  })
}
// 会诊申请
export function apply (data) {
  return request({
    url: medRoutBaseUrl + '/consultations',
    method: 'post',
    data: data
  })
}
// 会诊编辑
export function edit (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_info.id}`,
    method: 'put',
    data: data
  })
}
// 获取会诊列表
export function consultations (data) {
  return request({
    url: medRoutBaseUrl + '/consultations',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 会诊统计
export function total (data) {
  return request({
    url: medRoutBaseUrl + '/consultations/total',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 获取详情
export function getConsultDetail (consultId) {
  return request({
    url: medRoutBaseUrl + `/consultations/${consultId}`,
    method: 'get'
  })
}
// 获取脱敏详情
export function getAnonymousConsultDetail (consultId) {
  return request({
    url: medRoutBaseUrl + `/consultations/${consultId}/anonymous`,
    method: 'get'
  })
}
// 取消会诊
export function cancel (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/cancel`,
    method: 'put',
    data: data
  })
}
// 获取会诊地点
export function getPlace (data) {
  return request({
    url: medRoutBaseUrl + '/places',
    method: 'get',
    params: data
  })
}
// 会诊调度
export function schedule (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/schedule`,
    method: 'post',
    data: data
  })
}
// 会诊审核
export function audit (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/audit`,
    method: 'put',
    data: data
  })
}
// 领取会诊
export function consultReceive (consult_id) {
  return request({
    url: medRoutBaseUrl + `/consultations/${consult_id}/receive`,
    method: 'put'
  })
}
// 释放会诊
export function consultFree (consult_id) {
  return request({
    url: medRoutBaseUrl + `/consultations/${consult_id}/free`,
    method: 'put'
  })
}
// 控制会诊
export function control (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/control`,
    method: 'put',
    data: data
  })
}
// 呼叫
export function videoCall (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/call`,
    method: 'get',
    params: data
  })
}
// 获取所有医生回复
export function getReplies (consultId) {
  return request({
    url: medRoutBaseUrl + `/consultations/${consultId}/replies`,
    method: 'get'
  })
}
// 获取个人回复(超声时包含模板内容)
export function getReply (consultId) {
  return request({
    url: medRoutBaseUrl + `/consultations/${consultId}/reply`,
    method: 'get'
  })
}
// 添加外邀专家
export function postInvitedExpert (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/invited-expert`,
    method: 'post',
    data: data
  })
}
// 删除外邀专家
export function deleteInvitedExpert (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/invited-expert`,
    method: 'delete',
    data: data
  })
}
// 获取ca原始签名
export function caOriginalText (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/ca-original-text`,
    method: 'post',
    data: data
  })
}
// 获取验签数据
export function getSignData (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/sign-data`,
    method: 'get'
  })
}
// 获取可信时间戳
export function timestamp (data) {
  return request({
    url: `${operateRoutBaseUrl}/sign/timestamp`,
    method: 'post',
    data: data
  })
}
// 验证时间戳
export function verifyTimestamp (data) {
  return request({
    url: `${operateRoutBaseUrl}/sign/verify-timestamp`,
    method: 'post',
    data: data
  })
}
// 会诊签名
export function signature (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/signature`,
    method: 'post',
    data: data
  })
}
// 获取历史会诊
export function histories (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/histories`,
    method: 'get',
    params: data
  })
}
// 获取系统参数serviceCenterId=&paramModule=
export function getTelemedParameters (data) {
  return request({
    url: medRoutBaseUrl + '/sysparameter/telemed-parameters',
    method: 'get',
    params: data
  })
}
// 获取合作医院
export function getInstitutions (data) {
  return request({
    url: operateRoutBaseUrl + '/service-cooperations/institutions',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 获取医院签约的服务中心
export function getServiceCenter (data) {
  return request({
    url: operateRoutBaseUrl + '/service-cooperations/signatory-service-centers',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 获取服务医生签约的服务中心
export function getDoctorServiceCenter (data) {
  return request({
    url: operateRoutBaseUrl + '/service-doctors/signatory-service-centers',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 获取服务中心精简信息
export function getServiceCenterLite (data) {
  return request({
    url: operateRoutBaseUrl + '/service-centers/lite',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 获取服务中心详情
export function getServiceCenterDetail (data) {
  return request({
    url: operateRoutBaseUrl + `/service-centers/${data.id}`,
    method: 'get',
    params: data
  })
}
// 获取服务医生
export function getServiceDoctor (data) {
  return request({
    url: operateRoutBaseUrl + '/service-doctors',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 获取服务医生不分页列表
export function getServiceDoctorLite (data) {
  return request({
    url: operateRoutBaseUrl + '/service-doctors/lite',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 获取服务医生详情
export function getServiceDoctorDetail (data) {
  return request({
    url: operateRoutBaseUrl + `/service-doctors/${data.id}`,
    method: 'get',
    params: data
  })
}
// 获取专家组
export function getGroups (data) {
  return request({
    url: operateRoutBaseUrl + '/specialist-groups',
    method: 'get',
    params: data
  })
}
// 获取指定服务中心的签约医生所属科室
export function getOffice (data) {
  return request({
    url: operateRoutBaseUrl + '/service-doctors/offices',
    method: 'get',
    params: data
  })
}
// 媒体文件上传
export function postMedias (data) {
  return request({
    url: operateRoutBaseUrl + '/medias',
    method: 'post',
    data: data
  })
}
// 媒体文件下载
export function getMedias (mediaId) {
  return request({
    url: operateRoutBaseUrl + `/medias/${mediaId}`,
    method: 'get'
  })
}
// 检查用户权限
export function checkAuthority (params) {
  return request({
    url: operateRoutBaseUrl + '/users/check-authority',
    method: 'get',
    params
  })
}
// 获取会诊过程
export function processes (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/processes`,
    method: 'get',
    params: data
  })
}
// 获取检查项目
export function getExamItems (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/examine-items/${data.examine_type}`,
    method: 'get'
  })
}
// 添加心电测值
export function postEcgMeasurements (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.service_id}/ecg-measurements`,
    method: 'post',
    data: data
  })
}
// 编辑心电测值
export function putEcgMeasurements (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.service_id}/ecg-measurements/${data.ecg_file_id}`,
    method: 'post',
    data: data
  })
}
// 获取心电测值--远程医疗
export function getEcgMeasurements (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/ecg-measurements`,
    method: 'get',
    params: data
  })
}
// 获取心电测值--idcas
export function idcasGetEcgMeasurements (data) {
  return request({
    url: idcasRoutBaseUrl + '/Documents/ecg-measurement',
    method: 'get',
    params: data
  })
}
// 获取心脏测值
export function getHeartMeasure (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/heart-measure`,
    method: 'get',
    params: data
  })
}
// 新增心脏测值
export function postHeartMeasure (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/heart-measure`,
    method: 'post',
    data: data
  })
}
// 编辑心脏测值
export function putHeartMeasure (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/heart-measure`,
    method: 'put',
    data: data
  })
}
// 获取数据字典--远程医疗 ConsultKind-会诊类型 ConsultClass-会诊方式 SexType-性别 MaritalStatus-婚姻状况 IdCardType-证件类型 ConsultState-会诊状态 GuarDianRelation-与监护人关系
export function getMedDict (id) {
  return request({
    url: medRoutBaseUrl + `/consultations/dics/${id}`,
    method: 'get'
  })
}
// 获取数据字典--平台
export function getDict (data) {
  return request({
    url: operateRoutBaseUrl + `/dict/${data.lookup_key}`,
    method: 'get',
    params: data
  })
}
// 新增申请方对会诊的评价
export function postAppEvaluation (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/app-evaluation`,
    method: 'post',
    data: data
  })
}
// 获取申请方对会诊的评价
export function getAppEvaluation (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/app-evaluation`,
    method: 'get',
    params: data
  })
}
// 新增专家对申请方的评价
export function postExpEvaluation (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/exp-evaluation`,
    method: 'post',
    data: data
  })
}
// 获取专家对申请方的评价
export function getExpEvaluation (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/exp-evaluation`,
    method: 'get',
    params: data
  })
}
// 获取资料文档列表
export function getDicItems (data) {
  return request({
    url: medRoutBaseUrl + '/docitems',
    method: 'get',
    params: data
  })
}
// 影像协作-获取房间信息
export function postRoom (data) {
  return request({
    url: medRoutBaseUrl + '/demonstration/room',
    method: 'post',
    data: data
  })
}
// 保存历史业务资料文档记录
export function postHistory (data) {
  return request({
    url: medRoutBaseUrl + '/docitems/history',
    method: 'post',
    data: data
  })
}
// 获取历史业务资料文档记录
export function getHistory (data) {
  return request({
    url: medRoutBaseUrl + '/docitems/history',
    method: 'get',
    params: data
  })
}
// 获取资料浏览地址
export function getViewUrl (data) {
  return request({
    url: medRoutBaseUrl + '/documents/view-url',
    method: 'get',
    params: data
  })
}
// 获取短链信息
export function getShortUrl (data) {
  return request({
    url: operateRoutBaseUrl + `/short-url/${data}`,
    method: 'get'
  })
}
// 获取已上传资料
export function getLoadFile (data) {
  return request({
    url: idcasRoutBaseUrl + '/Documents/by-business',
    method: 'get',
    params: data
  })
}
// 删除已上传资料
export function deleteLoadFile (data) {
  return request({
    url: idcasRoutBaseUrl + '/Documents/update-tag',
    method: 'put',
    data: data
  })
}
// 获取会议加入信息
export function getJoinInfo (data) {
  return request({
    url: operateRoutBaseUrl + '/meetings/join-info',
    method: 'get',
    params: data
  })
}
// 获取会议录播信息
export function getVideoRecords (data) {
  return request({
    url: operateRoutBaseUrl + `/meetings/${data.business_id}/${data.kind}/records`,
    method: 'get'
  })
}
// 获取报告图片
export function getPrintImage (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/report/image`,
    method: 'get',
    params: data
  })
}
// 申请远程诊断
export function applyDiagnosis (data) {
  return request({
    url: pacsRoutBaseUrl + '/report',
    method: 'post',
    data: data
  })
}
// 编辑远程诊断
export function editDiagnosis (data) {
  return request({
    url: pacsRoutBaseUrl + `/report/${data.id}`,
    method: 'put',
    data: data
  })
}
// 获取远程诊断列表
export function getDiagnosisList (data) {
  return request({
    url: pacsRoutBaseUrl + '/report',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 获取远程诊断列表tab统计
export function getDiagnosisTotal (data) {
  return request({
    url: pacsRoutBaseUrl + '/report/radiationreporteditstatistic',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 获取诊断超时列表
export function getOvertimeList (data) {
  return request({
    url: pacsRoutBaseUrl + '/report/overtime-list',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 取消远程诊断
export function cancelDiagnosis (data) {
  return request({
    url: pacsRoutBaseUrl + `/report/${data.id}/cancel`,
    method: 'patch',
    data: data
  })
}
// 获取取消远程诊断原因
export function getReportReason (data) {
  return request({
    url: pacsRoutBaseUrl + `/report/${data.id}/reportreason/${data.type}`,
    method: 'get',
    data: data
  })
}
// 获取远程诊断详情 -- 加密详情
export function getDiagnosisDetail (id) {
  return request({
    url: pacsRoutBaseUrl + `/report/${id}`,
    method: 'get'
  })
}
// 获取远程诊断详情 -- 不加密
export function getDiagnosisEditDetail (id) {
  return request({
    url: pacsRoutBaseUrl + `/report/${id}/edit`,
    method: 'get'
  })
}
// 获取远程诊断检查部位
export function getExamItemCategory (data) {
  return request({
    url: pacsRoutBaseUrl + '/Config/ExamItemCategory',
    method: 'get',
    params: data,
    headers: { ShareMode: sessionStorage.getItem('ShareMode') }
  })
}
// 获取检查项目接口
export function getIncludeAttr (data) {
  return request({
    url: pacsRoutBaseUrl + '/Config/ExamItem',
    method: 'get',
    params: data,
    headers: { ShareMode: sessionStorage.getItem('ShareMode') }
  })
}
// 获取诊断ca签名原文数据
export function diagnosisCaOriginalText (data) {
  return request({
    url: pacsRoutBaseUrl + `/report/${data.id}/ca-original-text`,
    method: 'post',
    data: data
  })
}
// 获取外部能力详情
export function getCommonSettingDetail (data) {
  return request({
    url: `${operateRoutBaseUrl}/common-settings/tenancy/detail`,
    method: 'get',
    params: data
  })
}
// 获取影像对比浏览地址
export function getCompareUrl (data) {
  return request({
    url: `${medRoutBaseUrl}/documents/compare-url`,
    method: 'get',
    params: data
  })
}

// 获取用户权限配置信息
export function getUserRightsConfig (data) {
  return request({
    url: `${medRoutBaseUrl}/composite/user-rights-config`,
    method: 'post',
    data: data
  })
}

// 获取检查检验列表
export function getObservations (data) {
  return request({
    url: `${idcasRoutBaseUrl}/Observations/pacs-exam-list`,
    method: 'get',
    params: data
  })
}

// 获取检查详情
export function getObservationsExamDetail (id) {
  return request({
    url: `${idcasRoutBaseUrl}/Observations/${id}/exam-detail`,
    method: 'get'
  })
}

// 获取icc影像浏览地址
export function getImageWebViewUrl (id) {
  return request({
    url: `${idcasRoutBaseUrl}/Observations/image-web-view-url`,
    method: 'get',
    params: { business_id: id }
  })
}

// 获取平台厂商（租户）
export function platforms () {
  return request({
    url: `${medRoutBaseUrl}/third/consultation/platforms`,
    method: 'get'
  })
}

// 列出申请机构签约服务中心列表
export function getThirdServiceCenter (data) {
  return request({
    url: `${medRoutBaseUrl}/third/consultation/service-cooperations/signatory-service-centers`,
    method: 'get',
    params: data
  })
}

// 列出服务医生列表
export function getThirdDoctor (data) {
  return request({
    url: `${medRoutBaseUrl}/third/consultation/service-doctors`,
    method: 'get',
    params: data
  })
}

// 列出服务医生所属科室列表
export function getThirdOffices (data) {
  return request({
    url: `${medRoutBaseUrl}/third/consultation/service-doctors/offices`,
    method: 'get',
    params: data
  })
}

// 第三方会诊申请
export function thirdConsultApply (data) {
  return request({
    url: `${medRoutBaseUrl}/third/consultation`,
    method: 'post',
    data: data
  })
}

// 第三方会诊申请
export function thirdConsultEdit (data) {
  return request({
    url: `${medRoutBaseUrl}/third/consultation`,
    method: 'put',
    data: data
  })
}

// 第三方平台会议地址
export function getThirdMettingUrl (data) {
  return request({
    url: `${medRoutBaseUrl}/third/consultation/meeting-url`,
    method: 'post',
    data: data
  })
}

// 第三方平台会议录播地址
export function getThirdMettingRecords (data) {
  return request({
    url: `${medRoutBaseUrl}/third/consultation/meeting-records`,
    method: 'post',
    data: data
  })
}

// 获取文档上传地址
export function getThirdUploadUrl (data) {
  return request({
    url: `${medRoutBaseUrl}/third/consultation/upload-url`,
    method: 'get',
    params: data
  })
}

// 获取第三方平台会诊对应文档目录列表
export function getThirdDocItems (data) {
  return request({
    url: `${medRoutBaseUrl}/third/consultation/doc-items`,
    method: 'get',
    params: data
  })
}

// 获取第三方平台会诊对应文档目录列表
export function getThirdFiles (data) {
  return request({
    url: `${medRoutBaseUrl}/third/consultation/files`,
    method: 'get',
    params: data
  })
}

// 获取岗位列表
export function getPositionsLite (data) {
  return request({
    url: medRoutBaseUrl + '/consultation-positions/lite',
    method: 'get',
    params: data
  })
}

// 获取排班列表
export function getSchedulesLite (data) {
  return request({
    url: medRoutBaseUrl + '/consultation-schedules/lite',
    method: 'get',
    params: data
  })
}

// 获取排班详情
export function getScheduleDetail (id) {
  return request({
    url: medRoutBaseUrl + `/consultation-schedules/${id}`,
    method: 'get'
  })
}

// 获取服务中心排班统计
export function getSchedulesStates (data) {
  return request({
    url: medRoutBaseUrl + '/consultation-schedules/service-center/stats',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取报告预览图片
export function getPreViewImage (data) {
  return request({
    url: medRoutBaseUrl + `/consultations/${data.consult_id}/report/image/pre-view`,
    method: 'post',
    data: data
  })
}

// 获取提供服务的检查类型
export function getExamineTypes (data) {
  return request({
    url: medRoutBaseUrl + '/composite/examine-types',
    method: 'get',
    params: data
  })
}

// 获取切片图片(标签图、缩略图)
export function getSectionImage (data) {
  return request({
    url: medRoutBaseUrl + '/documents/section-image',
    method: 'get',
    params: data
  })
}

// 通过上传文档唯一号下载文件
export function getDocumentId (data, responseType) {
  let urlStr = ''
  if (systermUpdateToK8S) {
    urlStr = '/api-document'
  }
  return request({
    url: configUrl.docUrl + urlStr + '/download/document-id',
    method: 'get',
    params: data,
    responseType: responseType || 'arraybuffer',
  })
}

// 更新标本配送状态
export function putSpecimenDeliveryState (data) {
  return request({
    url: `${medRoutBaseUrl}/consultations/${data.consult_id}/specimen-delivery-state`,
    method: 'put',
    data: data
  })
}

// 获取V8质控系统
export function getQcSystemUrl () {
  return request({
    url: medRoutBaseUrl + '/composite/v8/qc-system-url',
    method: 'get'
  })
}

// 获取患者信息
export function getSinglePatient (params) {
  return request({
    url: medRoutBaseUrl + '/composite/single-patient',
    method: 'get',
    params: params
  })
}

// 获取患者年龄详细信息
export function getAgeDetail (params) {
  return request({
    url: medRoutBaseUrl + '/composite/age-detail',
    method: 'get',
    params: params
  })
}

// 获取跨客户会诊归属租户已授权存储域服务中心Id
export function getAcrossTenancyCenter (params) {
  return request({
    url: medRoutBaseUrl + '/consultations/across-tenancy-center',
    method: 'get',
    params: params
  })
}

// 获取评价方案详情
export function serviceEvaluateScheme (data) {
  return request({
    url: medRoutBaseUrl + '/diagnosis/service-evaluate-scheme',
    method: 'get',
    params: data
  })
}

// 服务评价
export function addServiceEvaluate (data) {
  return request({
    url: medRoutBaseUrl + '/diagnosis/add-service-evaluate',
    method: 'post',
    data: data
  })
}

// 获取评价详情
export function serviceEvaluateDetail (id) {
  return request({
    url: medRoutBaseUrl + `/diagnosis/${id}/service-evaluate-detail`,
    method: 'get'
  })
}

// 获取历史相关检查web浏览地址
export function getHistoryRelevantExamWebViewUrl (id) {
  return request({
    url: medRoutBaseUrl + `/diagnosis/${id}/history-relevant-exam-web-view-url`,
    method: 'get'
  })
}

// 获取随访列表
export function followUpList (data) {
  return request({
    url: medRoutBaseUrl + '/follow-up/list',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}

// 添加随访
export function followUpAdd (data) {
  return request({
    url: medRoutBaseUrl + '/follow-up/add',
    method: 'post',
    data: data
  })
}

// 结束，取消，删除 随访
export function followUpAction (data) {
  return request({
    url: medRoutBaseUrl + '/follow-up/action',
    method: 'post',
    data: data
  })
}

// 增加随访明细
export function followUpAddDetail (data) {
  return request({
    url: medRoutBaseUrl + '/follow-up/add-detail',
    method: 'post',
    data: data
  })
}

// 修改随访明细
export function followUpUpdateDetail (data) {
  return request({
    url: medRoutBaseUrl + '/follow-up/update-detail',
    method: 'post',
    data: data
  })
}

// 删除随访明细
export function followUpDeleteDetail (data) {
  return request({
    url: medRoutBaseUrl + '/follow-up/delete-detail',
    method: 'delete',
    data: data
  })
}

// 随访明细列表
export function followUpDetailList (data) {
  return request({
    url: medRoutBaseUrl + '/follow-up/detail-list',
    method: 'get',
    params: data
  })
}

// 获取随访列表统计
export function getFollowUpStatistics (data) {
  return request({
    url: medRoutBaseUrl + '/follow-up/statistics',
    method: 'get',
    params: data
  })
}

// 获取随访详情
export function getFollowUpDetail (data) {
  return request({
    url: medRoutBaseUrl + '/follow-up/detail',
    method: 'get',
    params: data
  })
}

// 上传报告贴图
export function uploadReportMap (obj, fromData) {
  return request({
    url: medRoutBaseUrl + `/composite/upload-report-map?businessId=${obj.businessId}&businessType=${obj.businessType}`,
    method: 'post',
    data: fromData
  })
}

// 获取医技传上来的BASE64图文报告
export function getGraphicsReportBase64 (performedId) {
  return request({
    url: pacsRoutBaseUrl + `/report/${performedId}/graphics-report-base64`,
    method: 'get'
  })
}
