import request from '@/utils/request'
import qs from 'qs'
// }
const RoutBaseUrl = '/api-cloudpacs'
const pacsApi = {
  Upload (data) {
    return request({
      url: data.Url,
      method: 'post',
      data: data.fd
    })
  },
  // 会诊报告
  consultresult (data) {
    return request({
      url: RoutBaseUrl + '/Report/' + data.consultId + '/consultresult',
      method: 'get'
      // baseURL: barse
    })
  },
  // 会诊状态
  consultapplydetail (data) {
    return request({
      url: RoutBaseUrl + '/Report/' + data.consultId + '/consultapplydetail',
      method: 'get'
      // baseURL: barse
    })
  },
  // 删除文档文档
  deleteFile (data) {
    return request({
      url: RoutBaseUrl + '/Composite/FileArchives/' + data.id,
      method: 'DELETE'
      // baseURL: barse
    })
  },
  // 删除登记
  deleteRegistrations (data) {
    return request({
      url: RoutBaseUrl + '/Apply/Registrations/' + data.id,
      method: 'DELETE'
      // baseURL: barse
    })
  },
  // 系统参数
  SystemParameters (data) {
    return request({
      url: RoutBaseUrl + '/Composite/SystemParameters',
      method: 'get',
      params: data
      // baseURL: barse
    })
  },
  // 添加文档
  addFile (data) {
    return request({
      url: RoutBaseUrl + '/Composite/FileArchives',
      method: 'post',
      data: data
      // baseURL: barse
    })
  },
  // 确认收费
  ConfirmPayment (data) {
    return request({
      url: RoutBaseUrl + '/Apply/MoreOperation/ConfirmPayment',
      method: 'post',
      data: data
    })
  },
  ExamsDoctor (data) {
    return request({
      url: RoutBaseUrl + '/Composite/Exams/'+ data.id +'/Doctor',
      method: 'get'
    })
  },
  // 添加文档
  getdFile (data) {
    return request({
      url: RoutBaseUrl + '/Composite/FileArchives',
      method: 'get',
      params: data
      // baseURL: barse
    })
  },
  putFile (data) {
    return request({
      url: RoutBaseUrl + '/Composite/FileArchives/' + data.id,
      method: 'put',
      data: data
      // baseURL: barse
    })
  },
  // 获取IMCIS的临床申请单，并字段转换成‘登记Dto’
  RequestOrderExams (data) {
    return request({
      url: RoutBaseUrl + '/Apply/RequestOrder/Query',
      method: 'get',
      params: data,
      paramsSerializer: data => {
        return qs.stringify(data, { indices: false })
      }
      // baseURL: barse
    })
  },
  // 获取机房
  RoomRegistCount (data) {
    return request({
      url: RoutBaseUrl + '/Apply/Room/ObservationRooms',
      method: 'get',
      params: data
      // baseURL: barse
    })
  },
  // 获取IMCIS的患者信息，并字段转换成‘登记Dto’
  PatientInfos (data) {
    return request({
      url: RoutBaseUrl + '/Apply/RequestOrder/PatientInfos',
      method: 'get',
      params: data
      // baseURL: barse
    })
  },
  // 检查登记
  Registrations (data) {
    return request({
      url: RoutBaseUrl + '/Apply/Registrations',
      method: 'post',
      data: data
      // baseURL: barse
    })
  },
  ImgArchive (data) {
    return request({
      url: RoutBaseUrl + '/Perform/Images/Archive',
      method: 'post',
      data: data
      // baseURL: barse
    })
  },
  // 修改文档服务
  putImgArchive (data) {
    return request({
      url: RoutBaseUrl + '/api/Perform/Images/Archive/' + data.id,
      method: 'put',
      data: data
      // baseURL: barse
    })
  },
  ImgArchiveDelet (data) {
    return request({
      url: RoutBaseUrl + '/Perform/Images/Archive/?id=' + data.id,
      method: 'DELETE'
      // baseURL: barse
    })
  },
  getImgArchive (data) {
    return request({
      url: RoutBaseUrl + '/Perform/Images/Archive',
      method: 'get',
      params: data
      // baseURL: barse
    })
  },
  ExamCompleted (data) {
    return request({
      url: RoutBaseUrl + '/Perform/' + data.id + '/Completed',
      method: 'patch',
      data: data,
      paramsSerializer: data => {
        return qs.stringify(data, { indices: false })
      }
    })
  },
  // 修改检查登记
  PutRegistrations (data) {
    return request({
      url: RoutBaseUrl + '/Apply/Registrations',
      method: 'put',
      data: data
      // baseURL: barse
    })
  },
  DocumentsUpdatetag (data) {
    return request({
      //url: '/api-idcas/Documents/update-tag',
      url: '/api-archive/Documents/update-tag',
      method: 'put',
      data: data
      // baseURL: barse
    })
  },
  // 检查登记列表
  GetRegistrations (data) {
    return request({
      url: RoutBaseUrl + '/Apply/Registrations',
      method: 'get',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false })
      }
    })
  },
  // 获取登记信息
  GetRegistrationsInfo (data) {
    return request({
      url: RoutBaseUrl + '/Apply/Registrations/' + data.id,
      method: 'get'
    })
  },
  // 影像浏览
  ViewUrl (data) {
    return request({
      url: RoutBaseUrl + '/Composite/Image/ViewUrl',
      method: 'get',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false })
      }
    })
  },
  // 获取检查信息
  Exams (data) {
    return request({
      url: RoutBaseUrl + '/Composite/Exams/' + data.id,
      method: 'get'
    })
  },
  // 历史检查
  History (data) {
    return request({
      url: RoutBaseUrl + '/Composite/Exams/History',
      method: 'get',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false, skipNulls: true })
      }
    })
  },
  // 取消检查
  Cancel (data) {
    return request({
      url: RoutBaseUrl + '/Composite/Exams/' + data.id + '/Cancel',
      method: 'put',
      data: { reason: data.CancelReason }
    })
  },
  // 追加检查
  AppendShooting (data) {
    return request({
      url: RoutBaseUrl + '/Composite/Exams/' + data.id + '/AppendShooting',
      method: 'patch',
      data: data
    })
  },
  // 重新摄片
  ReShooting (data) {
    return request({
      url: RoutBaseUrl + '/Composite/Exams/' + data.id + '/ReShooting',
      method: 'patch',
      data: data
    })
  },
  // 获取注意事项列表
  ProcessAttentions (data) {
    return request({
      url: RoutBaseUrl + '/Composite/ProcessAttentions',
      method: 'get',
      params: data
      // baseURL: barse
    })
  },
  AddProcessAttentions (data) {
    return request({
      url: RoutBaseUrl + '/Composite/ProcessAttentions',
      method: 'post',
      data: data
      // baseURL: barse
    })
  },
  // 删除注意事项
  DeleteProcessAttentions (data) {
    return request({
      url: RoutBaseUrl + '/Composite/ProcessAttentions/' + data.id,
      method: 'delet'
    })
  },
  // 获取检查锁定信息
  GetExamLock (data) {
    return request({
      url: RoutBaseUrl + '/Composite/ExamLock',
      method: 'get',
      params: data
    })
  },
  // 锁定
  ExamLock (data) {
    return request({
      url: RoutBaseUrl + '/Composite/ExamLock',
      method: 'patch',
      data: data,
      paramsSerializer: data => {
        return qs.stringify(data, { indices: false })
      }
    })
  },
  // 危机值检查
  DetectionCriticalValues (data) {
    return request({
      url: RoutBaseUrl + '/Composite/CriticalValues/Detection',
      method: 'post',
      data: data
    })
  },
  // 疾病报卡检查
  DetectionDiseaseReports (data) {
    return request({
      url: RoutBaseUrl + '/Composite/DiseaseReports/Detection',
      method: 'post',
      data: data
    })
  },
  // 获取危机值
  CriticalValues (data) {
    var ShareMode = sessionStorage.getItem('ShareMode')
    if (ShareMode) {
      ShareMode = sessionStorage.getItem('ShareMode')
    } else {
      ShareMode = ''
    }
    return request({
      url: RoutBaseUrl + '/Composite/CriticalValues',
      method: 'get',
      params: data,
      headers: { ShareMode: ShareMode }
      // baseURL: barse
    })
  },
  // 提交危机值
  PostCriticalValues (data) {
    return request({
      url: RoutBaseUrl + '/Composite/CriticalValues',
      method: 'post',
      data: data
    })
  },
  // 危急值处理
  CriticalValuesProcess (data) {
    return request({
      url: RoutBaseUrl + '/Composite/CriticalValues/' + data.performed_procedure_id + '/Process',
      method: 'patch',
      data: { process_info: data.process_info },
      paramsSerializer: data => {
        return qs.stringify(data, { indices: false })
      }
    })
  },
  CriValueDefine (data) {
    var ShareMode = sessionStorage.getItem('ShareMode')
    if (ShareMode) {
      ShareMode = sessionStorage.getItem('ShareMode')
    } else {
      ShareMode = ''
    }
    return request({
      url: RoutBaseUrl + '/Config/CriValueDefine',
      method: 'get',
      params: data,
      headers: { ShareMode: ShareMode }
    })
  },
  DicDefine (data) {
    var ShareMode = sessionStorage.getItem('ShareMode')
    if (ShareMode) {
      ShareMode = sessionStorage.getItem('ShareMode')
    } else {
      ShareMode = ''
    }
    return request({
      url: RoutBaseUrl + '/Config/DicDefine',
      method: 'get',
      params: data,
      headers: { ShareMode: ShareMode }
    })
  },
  DicDefineAll (data) {
    return request({
      url: RoutBaseUrl + '/Config/DicDefine/Multiple',
      method: 'get',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false })
      }
    })
  },
  Bodypart (data) {
    return request({
      url: RoutBaseUrl + '/Config/ExamItemCategory',
      method: 'get',
      params: data
    })
  },
  Item (data) {
    return request({
      url: RoutBaseUrl + '/Config/ExamItem',
      method: 'get',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false })
      }
    })
  },
  addItem (data) {
    return request({
      url: RoutBaseUrl + '/Config/ExamItem',
      method: 'POST',
      data: data
    })
  },
  HisCode (data) {
    return request({
      url: RoutBaseUrl + '/Config/ExamItem/HisCode',
      method: 'PUT',
      data: data
    })
  },
  Report (data) {
    return request({
      url: RoutBaseUrl + '/Report',
      method: 'get',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false })
      }
    })
  },
  Queries (data) {
    return request({
      url: RoutBaseUrl + '/Config/Item/Queries',
      method: 'get',
      params: data
    })
  },
  radiationreporteditstatistic (data) {
    return request({
      url: RoutBaseUrl + '/Report/radiationreporteditstatistic',
      method: 'get',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false })
      }
    })
  },
  // 检查项目【HIS代码获取检查项目】
  ExamItemQueries (data) {
    return request({
      url: RoutBaseUrl + '/Config/ExamItem/Queries',
      method: 'get',
      params: data
    })
  },
  Perform (data) {
    return request({
      url: RoutBaseUrl + '/Perform',
      method: 'GET',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false })
      }
    })
  },
  getReport (data) {
    return request({
      url: RoutBaseUrl + '/Report/' + data.id,
      method: 'get'
    })
  },
  // 占用
  occupy (data) {
    return request({
      url: `${RoutBaseUrl}/Report/${data.id}/occupy?isEdit=${data.isEdit || false}`,
      method: 'patch',
      data: data,
      paramsSerializer: data => {
        return qs.stringify(data, { indices: false })
      }
    })
  },
  // 释放
  release (data) {
    return request({
      url: RoutBaseUrl + '/Report/' + data.id + '/release',
      method: 'patch',
      data: data,
      paramsSerializer: data => {
        return qs.stringify(data, { indices: false })
      }
    })
  },
  // 异常流程（报告回退、回科、重新摄片、追加摄片）
  abnormalprocess (data) {
    return request({
      url: RoutBaseUrl + '/Report/' + data.id + '/abnormalprocess',
      method: 'post',
      data: data
    })
  },
  // 报告回退原因
  reportbackreason (data) {
    return request({
      url: RoutBaseUrl + '/Report/' + data.id + '/reportreason/' + data.type,
      method: 'get'
    })
  },
  processtrace (data) {
    return request({
      url: RoutBaseUrl + '/Report/' + data.id + '/processtrace',
      method: 'get',
      params: data
    })
  },
  // 报告状态
  reportState (data) {
    var params = { ...data }
    delete params['id']
    return request({
      url: RoutBaseUrl + '/Report/' + data.id + '/report',
      method: 'post',
      data: params
    })
  },
  // 报告状态
  reportSign (data) {
    return request({
      url: RoutBaseUrl + '/Report/Sign',
      method: 'post',
      data: data
    })
  },
  // /api/Report/{id}/reportextend
  // 报告拓展 书写/审核
  reportStateExtend (data) {
    var params = { ...data }
    delete params['id']
    return request({
      url: RoutBaseUrl + '/Report/' + data.id + '/reportextend',
      method: 'post',
      data: params
    })
  },
  // 疾病报卡列表
  DiseaseReports (data) {
    return request({
      url: RoutBaseUrl + '/Composite/DiseaseReports',
      method: 'get',
      params: data
    })
  },
  AddDiseaseReports (data) {
    return request({
      url: RoutBaseUrl + '/Composite/DiseaseReports',
      method: 'post',
      data: data
    })
  },
  // 疾病报卡上报
  DiseaseReportsSubmit (data) {
    return request({
      url: RoutBaseUrl + '/Composite/DiseaseReports/' + data.id + '/Submit',
      method: 'patch'
    })
  },
  // 疾病报卡取消/api/Composite/DiseaseReports/{id}/Cancel
  DiseaseReportsCancel (data) {
    return request({
      url: RoutBaseUrl + '/Composite/DiseaseReports/' + data.id + '/Cancel',
      method: 'patch',
      params: data
    })
  },
  // 报告追踪列表
  reporttrace (data) {
    return request({
      url: RoutBaseUrl + '/Report/' + data.id + '/reporttrace',
      method: 'get'
    })
  },
  // 获取检查跟踪列表
  getProcesstrace (data) {
    return request({
      url: RoutBaseUrl + '/Report/' + data.id + '/processtrace',
      method: 'get'
    })
  },
  // 获取心电测值
  getmeasureheart (data) {
    return request({
      url: RoutBaseUrl + '/Report/ecg/' + data.id + '/measureecg',
      method: 'get'
    })
  },
  POSTmeasureheart (data) {
    return request({
      url: RoutBaseUrl + '/Report/ecg/' + data.itemid + '/measureecg',
      method: 'POST',
      data: data
    })
  },
  Putmeasureheart (data) {
    return request({
      url: RoutBaseUrl + '/Report/ecg/' + data.itemid + '/measureecg',
      method: 'PUT',
      data: data
    })
  },
  DELETEmeasureheart (data) {
    return request({
      url: RoutBaseUrl + '/Report/ecg/' + data.id + '/measureheart',
      method: 'DELETE',
      data: data
    })
  },
  signatoryservicecenters (data) {
    return request({
      url: '/api-operate/service-cooperations/signatory-service-centers',
      method: 'get',
      params: data
    })
  },
  // 用户权限
  systemAuthority (data) {
    return request({
      url: '/api-operate/users/system-authority',
      method: 'get',
      params: data
    })
  },
  Officeslite (data) {
    return request({
      url: '/api-operate/Offices/lite',
      method: 'get',
      params: data
    })
  },
  Userslite (data) {
    return request({
      url: '/api-operate/Users/lite',
      method: 'get',
      params: data
    })
  },
  printSuccess (data) {
    return request({
      url: RoutBaseUrl + '/Composite/Prints/Report/' + data.performedProcedureId + '/Success',
      method: 'patch',
      data: data
    })
  },
  // 恢复自定义列
  RecoverColumn  (data) {
    return request({
      url: RoutBaseUrl + '/Config/ColumnCustom/Recover',
      method: 'get',
      params: data
    })
  },
  // 保存自定义列
  SaveColumnCustom  (data) {
    return request({
      url: RoutBaseUrl + '/Config/ColumnCustom',
      method: 'post',
      data: data
    })
  },
  applyconsult  (data) {
    return request({
      url: RoutBaseUrl + '/Report/' + data.id + '/applyconsult',
      method: 'post',
      data: data
    })
  },
  // 获取自定义列
  getColumnCustom  (data) {
    return request({
      url: RoutBaseUrl + '/Config/ColumnCustom',
      method: 'get',
      params: data
    })
  },
  // 打印
  Prints (data) {
    return request({
      url: RoutBaseUrl + '/Composite/Prints',
      method: 'get',
      params: data
    })
  },
  // 自动打印
  AutoPrintId (data) {
    return request({
      url: RoutBaseUrl + '/Composite/Prints/AutoPrintId',
      method: 'get',
      params: data,
      paramsSerializer: data => {
        return qs.stringify(data, { indices: false })
      }
    })
  },
  PrintEcg (data) {
    return request({
      url: RoutBaseUrl + '/Composite/Prints',
      method: 'get',
      params: data
    })
  },
  replies (data) {
    return request({
      url: `/api-telemed/consultations/${data.id}/replies`,
      method: 'get'
    })
  },
  unmatchCount (data) {
    return request({
      url: '/api-archive/studys/unmatch/count',
      method: 'get',
      params: data
    })
  },
  // 获取结构化报告配置
  getStructureConfig (data) {
    return request({
      url: `/api-cloudpacs/Report/${data.id}/structureconfig`,
      method: 'get',
      params: {SourceSystem: data.SourceSystem}
    })
  },
  // 获取机构精简信息列表
  getInstitutionsLite(data) {
    return request({
      url: '/api-operate/institutions/lite',
      method: 'get',
      params: data
    })
  },
  // 检查机房【获取列表】
  getObseRoom(data) {
    return request({
      url: '/api-cloudpacs/Config/ObseRoom',
      method: 'get',
      params: data
    })
  },
  // 获取影像质控
  getQcScore (data) {
    return request({
      url: '/api-cloudpacs/config/QcScoreGradeDefine/MultipleCondition',
      method: 'get',
      params: data
    })
  },
  // 获取评分项目
  getQcScorePage (data) {
    return request({
      url: '/api-cloudpacs/Config/QcScoreTemplateItems/Page',
      method: 'get',
      params: data
    })
  },
  // 获取质控评分详情
  getQcScoreDetail (data) {
    return request({
      url: '/api-cloudpacs/Report/' + data + '/qcscore',
      method: 'get'
    })
  },
  // 获取质控评分详情
  submitQcScore (data, id) {
    return request({
      url: '/api-cloudpacs/Report/' + id + '/qcscore',
      method: 'post',
      data: data
    })
  },
  /*// 获取质控信息
  getQCScore (data) {
    return request({
      url: RoutBaseUrl + '/Manage/QCScore',
      method: 'get',
      params: data
    })
  },*/
  // 获取小组质控数据
  getGroupQCScoreData (data) {
    return request({
      url: RoutBaseUrl + `/Manage/GroupQCScore/${data.id}/Data`,
      method: 'get',
      params: data
    })
  },
  // 删除质控记录
  delGroupQCScore (id) {
    return request({
      url: RoutBaseUrl + `/Manage/GroupQCScore/${id}`,
      method: 'delete'
    })
  },
  // 保存质控信息
  saveQCScore (data) {
    return request({
      url: RoutBaseUrl + '/Manage/QCScore/Save',
      method: 'post',
      data: data
    })
  },
  // 获取质控评分数量
  getGroupQCScoreCount () {
    return request({
      url: RoutBaseUrl + '/Manage/GroupQCScore/Count',
      method: 'get'
    })
  },
  // 获取ai结果
  getAiResult (data) {
    return request({
      url: '/api-cloudpacs/Report/ai/' + data.id + '/ai-result',
      method: 'GET'
    })
  },
  // 获取报告属性详情--心电报告书写时使用
  getReportAttr (id) {
    return request({
      url: '/api-cloudpacs/Report/' + id + '/report-attr',
      method: 'get'
    })
  },
  // 保存报告属性--心电报告书写时使用
  postReportAttr (data) {
    return request({
      url: '/api-cloudpacs/Report/' + data.id + '/report-attr',
      method: 'post',
      data
    })
  },
  // 获取心电轴值和颜色配置
  getMeasureThreshold (data) {
    return request({
      url: '/api-cloudpacs/Config/MeasureThreshold/Normal',
      method: 'GET',
      params: data
    })
  },
  // 获取传染病列表
  getDiseaseReported (data) {
    return request({
      url: RoutBaseUrl + '/Manage/DiseaseReported/List',
      method: 'get',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false, skipNulls: true })
      }
    })
  },
  // 到处传染病列表
  DiseaseReportedExportExcel (data) {
    return request({
      url: RoutBaseUrl + '/Manage/DiseaseReported/Export',
      method: 'post',
      data: data,
      responseType: 'blob'
    })
  },
  // 获取危急值管理列表
  getCriticalReportList (data) {
    return request({
      url: RoutBaseUrl + '/Manage/CriticalValue/ProcessList',
      method: 'get',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false, skipNulls: true })
      }
    })
  },
  // 导出危急值管理列表
  exportCriticalReportList (data) {
    return request({
      url: RoutBaseUrl + '/Manage/CriticalValue/ExportProcessList',
      method: 'post',
      data: data,
      responseType: 'blob'
    })
  },
  // 取消危急值
  criticalValueCancel (data) {
    return request({
      url: `${RoutBaseUrl}/Composite/CriticalValues/${data.id}/Cancel`,
      method: 'patch',
      data: { process_info: data.process_info || '' }
    })
  },
  // NEW 随访接口 新增随访
  addFollowUp (data) {
    return request({
      url: `${RoutBaseUrl}/Composite/FollowUp/AddFollowUp`,
      method: 'POST',
      data: data
    })
  },
  // 随访列表
  getFollowUpList (data) {
    return request({
      url: `${RoutBaseUrl}/Composite/FollowUp/GetFollowUpList`,
      method: 'GET',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false })
      }
    })
  },
  // 结束取消随访
  setFollowUp (data) {
    return request({
      url: `${RoutBaseUrl}/Composite/FollowUp/FollowAction`,
      method: 'POST',
      data: data
    })
  },
  // 随访数量统计
  getFollowUpStatistics (data) {
    return request({
      url: `${RoutBaseUrl}/Composite/FollowUp/FollowUpStatistics`,
      method: 'GET',
      params: data
    })
  },
  // 新增随访明细
  addFollowUpDetail (data) {
    return request({
      url: `${RoutBaseUrl}/Composite/FollowUp/AddFollowUpDetail`,
      method: 'POST',
      data: data
    })
  },
  // 修改随访明细
  updateFollowUpDetail (data) {
    return request({
      url: `${RoutBaseUrl}/Composite/FollowUp/UpdateFollowUpDetail`,
      method: 'POST',
      data: data
    })
  },
  // 删除随访明细
  deleteFollowUpDetail (data) {
    return request({
      url: `${RoutBaseUrl}/Composite/FollowUp/DeleteFollowUpDetail`,
      method: 'POST',
      data: data
    })
  },
  // 获取随访明细列表
  getFollowUpDetailList (data) {
    return request({
      url: `${RoutBaseUrl}/Composite/FollowUp/GetFollowUpDetailList`,
      method: 'GET',
      params: data
    })
  },
  // 获取质控信息
  getQCScore (data) {
    return request({
      url: RoutBaseUrl + '/Manage/QCScore',
      method: 'get',
      params: data
    })
  },
}
export default {
  pacsApi
}
