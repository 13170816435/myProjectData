import request from '@/utils/request'
import qs from 'qs'
const medRoutBaseUrl = '/api-telemed'

// 获取短链
export function getPubShortUrl(obj) {
  return request({
    url: `${medRoutBaseUrl}/pub/teachs/${obj.teach_id}/short-url`,
    method: 'get',
    params: obj
  })
}

// 获取课程分页列表
export function getPubTeachs(obj) {
  return request({
    url: `${medRoutBaseUrl}/pub/teachs`,
    method: 'get',
    params: obj,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取课程信息
export function getPubDetail(teachId) {
  return request({
    url: `${medRoutBaseUrl}/pub/teachs/${teachId}`,
    method: 'get'
  })
}

// 获取公开课直播信息
export function getPubDeLiveBroadcast(data) {
  return request({
    url: `${medRoutBaseUrl}/pub/teachs/live-broadcast`,
    method: 'get',
    params: data
  })
}

// 获取我的学习
export function getMyLearning() {
  return request({
    url: `${medRoutBaseUrl}/pub/teachs/my-learning`,
    method: 'get'
  })
}

// 通过上传文档唯一号下载文件
export function getMedDownload(id) {
  return request({
    url: `${medRoutBaseUrl}/pub/media/download`,
    method: 'get',
    params: { file_token: id },
    responseType: 'arraybuffer'
  })
}

// SSO用户认证
export function getUserCheck(data) {
  return request({
    url: `${medRoutBaseUrl}/pub/user/check`,
    method: 'get',
    params: data
  })
}
