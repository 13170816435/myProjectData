import request from '@/utils/request'
// 获取结构化报告模板数据
export function FetchStructrueData (data) {
  return request({
    url: '/api-structure/EworldStructure/structure-template-data',
    method: 'GET',
    params: data
  })
}
// 保存结构化报告数据
export function SaveStructrueData (data) {
  return request({
    url: '/api-structure/EworldStructure/structure-template-data',
    method: 'POST',
    data: data
  })
}
