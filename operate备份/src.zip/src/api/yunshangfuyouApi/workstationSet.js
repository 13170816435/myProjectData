import request from '@/utils/request'
import qs from 'qs'
// const barse = 'http://192.168.1.207:9020'
const RoutBaseUrl = '/api-cloudpacs'
const TelemedUrl = '/api-telemed'

// 收藏病例列表
export function getRoomList (data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseRoom',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 检查类型
export function getCheckList (data) {
  return request({
    url: RoutBaseUrl + '/Config/DicDefine',
    method: 'GET',
    params: data
  })
}
// 检查设备
export function getEquipment (data) {
  return request({
    url: RoutBaseUrl + '/Config/ObseEquipment',
    method: 'GET',
    params: data
  })
}
// 项目分类
export function getClassify (data) {
  return request({
    url: RoutBaseUrl + '/Config/ExamItemCategory',
    method: 'GET',
    params: data
  })
}
// 获取id
export function getId (data) {
  return request({
    url: TelemedUrl + '/ids',
    method: 'GET',
    params: data
  })
}
// 获取打印机列表
export function getPrinter (data) {
  return request({
    url: RoutBaseUrl + '/Config/AppParam/Printer',
    method: 'GET',
    params: data
  })
}
// 获取工作站设置详情
export function getDetail (data) {
  return request({
    url: RoutBaseUrl + '/Config/AppParam/' + data.paramIdentifier,
    method: 'GET',
    params: data
  })
}
// 保存工作站设置
export function save (data) {
  return request({
    url: RoutBaseUrl + '/Config/AppParam',
    method: 'post',
    data: data
  })
}
