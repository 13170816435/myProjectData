import request from '@/utils/request'
import qs from 'qs'
// 获取菜单
export function ownMenu () {
  return request({
    url: '/api-operate/users/own-menu',
    method: 'GET'
  })
}
// 获取系统id
export function fetchSystemIds () {
  return request({
    url: '/api-operate/users/pacs-systems',
    method: 'GET'
  })
}
// 获取雪花id
export function fetchSnowId () {
  return request({
    url: '/api-telemed/ids',
    method: 'GET'
  })
}
// 媒体图片下载 （获取图片路径）-- 废弃
export function getImgSrcById (id) {
  return request({
    responseType: 'arraybuffer',
    url: `/api-operate/medias/${id}`,
    method: 'GET'
  })
}
// 获取用户头像 id-用户id
export function getUserAvatar (id) {
  return request({
    responseType: 'arraybuffer',
    url: '/api-operate/users/avatar',
    method: 'GET',
    params: {id: id}
  })
}
// 获取服务中心logo id-服务中心id
export function getServiceCenterLogo (id) {
  return request({
    responseType: 'arraybuffer',
    url: `/api-operate/service-centers/${id}/logo`,
    method: 'GET'
  })
}
// 获取网站名称
export function getThisPlatformName () {
  return request({
    url: '/api-operate/tenancies/basis-info/lite',
    method: 'get'
  })
}
// 获取租户logo
export function getTenanciesLogo (data) {
  return request({
    responseType: 'arraybuffer',
    url: '/api-operate/tenancies/logo',
    method: 'get',
    params: data

  })
}
// 获取医生列表
export function getChangeDoctor (data) {
  return request({
    url: '/api-operate/users',
    method: 'get',
    // params: data
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 获取密钥
export function getConfigurations (data) {
  return request({
    url: '/api-operate/configurations?key=' + data,
    method: 'get'
  })
}
// 修改用户列表
export function updateuserpassword (params) {
  return request({
    url: '/api-operate/users/password/update', // url：'/users' + params
    method: 'post',
    data: params
  })
}


// IMCIS集成第三方厂商接口-开启能力列表
export function getThirdAbilities (params) {
  return request({
    url: '/api-telemed/composite/imcis/third-party-user-interface/abilities',
    method: 'get',
    params: params
  })
}

// IMCIS集成第三方厂商接口集成方式
export function getThirdInterface (params) {
  return request({
    url: '/api-telemed/composite/imcis/third-party-user-interface',
    method: 'get',
    params: params
  })
}
