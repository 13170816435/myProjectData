import request from '@/utils/request'
import qs from 'qs'

const operateRoutBaseUrl = '/api-operate'

const IMApi = {
  // 查询单聊聊天记录
  querySingleMsg(data) {
    return request({
      url: operateRoutBaseUrl + '/im/single-messages',
      method: 'get',
      params: data
    })
  },
  // 查询聊天会话
  queryChatSessions(data) {
    return request({
      url: operateRoutBaseUrl + '/im/sessions',
      method: 'get',
      params: data
    })
  },
  // 保存聊天会话
  saveChatSessions(data) {
    return request({
      url: operateRoutBaseUrl + '/im/sessions',
      method: 'post',
      data: data
    })
  },
  // 获取申请医院
  applyHospitalList (data) {
    return request({
      url: operateRoutBaseUrl + '/institutions/lite',
      method: 'get',
      params: data
    })
  }
}

export default {
  IMApi
}
