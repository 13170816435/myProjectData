import request from '@/utils/request'
import qs from 'qs'
const medRoutBaseUrl = '/api-telemed'

// 获取教学会议分页列表
export function getTeachMeetingPage (params) {
  return request({
    url: `${medRoutBaseUrl}/teachs/meeting/page`,
    method: 'get',
    params: params,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 获取教学会议关联课程列表
export function getTeachMeetingRelationList (teachMeetingId) {
  return request({
    url: `${medRoutBaseUrl}/teachs/meeting/relation/${teachMeetingId}`,
    method: 'get'
  })
}

// 获取教学会议信息
export function getTeachMeetingInfo (teachMeetingId) {
  return request({
    url: `${medRoutBaseUrl}/teachs/meeting/${teachMeetingId}`,
    method: 'get'
  })
}

// 新增教学会议信息
export function postTeachMeeting(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/meeting`,
    method: 'post',
    data: data
  })
}

// 更新教学会议信息
export function putTeachMeeting(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/meeting/${data.id}`,
    method: 'put',
    data: data
  })
}

// 更新教学会议状态
export function putTeachMeetingState(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/meeting/${data.id}/state?state=${data.state}`,
    method: 'put'
  })
}

// 删除教学会议信息
export function deleteTeachMeeting(teachMeetingId) {
  return request({
    url: `${medRoutBaseUrl}/teachs/meeting/${teachMeetingId}`,
    method: 'delete'
  })
}

// 获取会议短链
export function getTeachMeetingShortUrl(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/meeting/${data.business_id}/short-url`,
    method: 'get',
    params: data
  })
}