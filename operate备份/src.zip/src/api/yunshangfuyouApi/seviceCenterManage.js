import request from '@/utils/request'
import qs from 'qs'
const RoutBaseUrl = '/api-telemed'
const RoutOperateUrl = '/api-operate'
const RoutPacsUrl = '/api-cloudpacs'

// 获取排班分页列表
export function getSchedules(data) {
  return request({
    url: RoutBaseUrl + '/consultation-schedules',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}

// 新增排班
export function postSchedules(data) {
  return request({
    url: RoutBaseUrl + '/consultation-schedules',
    method: 'post',
    data: data
  })
}

// 更新排班
export function putSchedules(data) {
  return request({
    url: RoutBaseUrl + `/consultation-schedules/${data.id}`,
    method: 'put',
    data: data
  })
}
// 获取排班详情
export function getScheduleDetail(id) {
  return request({
    url: RoutBaseUrl + `/consultation-schedules/${id}`,
    method: 'get'
  })
}
// 复制排班明细列表
export function postCopyDetails(data) {
  return request({
    url: RoutBaseUrl + `/consultation-schedules/${data.copy_schedule_id}/copy-details`,
    method: 'post',
    data: data
  })
}
// 获取排班列表
export function getSchedulesLite(data) {
  return request({
    url: RoutBaseUrl + '/consultation-schedules/lite',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}

export function getMedDict(id) {
  return request({
    url: RoutBaseUrl + `/consultations/dics/${id}`,
    method: 'get'
  })
}

// 获取提供服务的检查类型
export function getExamineTypes(data) {
  return request({
    url: RoutBaseUrl + '/composite/examine-types',
    method: 'GET',
    params: data
  })
}
// 新增岗位
export function postPositions(data) {
  return request({
    url: RoutBaseUrl + '/consultation-positions',
    method: 'post',
    data: data
  })
}
// 获取岗位详情
export function getPositionDetail(id) {
  return request({
    url: RoutBaseUrl + `/consultation-positions/${id}`,
    method: 'get'
  })
}
// 更新岗位
export function putPositions(data) {
  return request({
    url: RoutBaseUrl + `/consultation-positions/${data.id}`,
    method: 'put',
    data: data
  })
}
// 删除岗位
export function deletePositions(id) {
  return request({
    url: RoutBaseUrl + `/consultation-positions/${id}`,
    method: 'delete'
  })
}
// 获取岗位分页列表
export function getPositions(data) {
  return request({
    url: RoutBaseUrl + '/consultation-positions',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
// 获取岗位列表
export function getPositionsLite(data) {
  return request({
    url: RoutBaseUrl + '/consultation-positions/lite',
    method: 'get',
    params: data
  })
}

// 获取检查类型
export function getAllInspectClass (data) {
  return request({
    url: RoutOperateUrl + `/dict/${data.lookup_key}`,
    method: 'GET',
    params: data
  })
}

// 获取某服务中心下 开通的服务
export function getServiceCenterSevice (data) {
  return request({
    url: RoutOperateUrl + '/service-centers/services',
    method: 'GET',
    params: data
  })
}

// 获取所有的服务医生 (不分页)
export function getServiceDoctorLite (data) {
  return request({
    url: RoutOperateUrl + '/service-doctors/lite',
    method: 'GET',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取服务类型
export function getServiceClass (data) {
  return request({
    url: RoutOperateUrl + '/dict/types',
    method: 'GET',
    params: data
  })
}

// 获取服务项目
export function getServiceProject (data) {
  return request({
    url: RoutOperateUrl + '/dict',
    method: 'GET',
    params: data
  })
}

// 获取用户评价列表
export function getRemarkList (data) {
  return request({
    url: RoutOperateUrl + '/Composite/Evaluation',
    method: 'GET',
    params: data
  })
}

// 获取用户评价列表
export function ExportRemark (data) {
  return request({
    url: RoutOperateUrl + '/Composite/Evaluation/Export',
    method: 'GET',
    'responseType':'blob',
    params: data
  })
}

// 项目分类【获取列表】
export function getExamItemCategory (data) {
  return request({
    url: RoutPacsUrl + '/Config/ExamItemCategory',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 书写模版【获取分页列表】
export function getWriteTempList (data) {
  return request({
    url: RoutPacsUrl + '/Config/WriteTemp/Page',
    method: 'GET',
    params: data
  })
}

// 书写模板的新增
export function addWriteTemp (data) {
  return request({
    url: RoutPacsUrl + '/Config/WriteTemp',
    method: 'post',
    data: data
  })
}

// 修改书写模板
export function updateWriteTemp (data) {
  return request({
    url: RoutPacsUrl + '/Config/WriteTemp',
    method: 'put',
    data: data
  })
}

// 书写模版【删除】
export function deleteWriteTemp (data) {
  return request({
    url: RoutPacsUrl + '/Config/WriteTemp',
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 书写模板分类
export function getWriteTempCategory (data) {
  return request({
    url: RoutPacsUrl + '/Config/WriteTempCategory',
    method: 'GET',
    params: data
  })
}

// 新增模板分类
export function addWriteTempCategory (data) {
  return request({
    url: RoutPacsUrl + '/Config/WriteTempCategory',
    method: 'post',
    data: data
  })
}

// 修改模板分类
export function updateWriteTempCategory (data) {
  return request({
    url: RoutPacsUrl + '/Config/WriteTempCategory',
    method: 'put',
    data: data
  })
}

// 书写模版分类【删除】
export function deleteWriteTempCategory (data) {
  return request({
    url: RoutPacsUrl + `/Config/WriteTempCategory/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 项目分类--检查项目
export function getExamItem (data) {
  return request({
    url: RoutPacsUrl + '/Config/ExamItem',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 书写模板拖拽
export function drageTree (data) {
  return request({
    url: RoutPacsUrl + '/Config/WriteTempCategory/DragSort',
    method: 'put',
    data: data
  })
}
