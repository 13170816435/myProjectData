import request from '@/utils/request'
import qs from 'qs'
const medRoutBaseUrl = '/api-telemed'

// 获取门诊科室列表
export function getOfficeList (data) {
  return request({
    url: medRoutBaseUrl + '/clinics/offices/list',
    method: 'get',
    params: data
  })
}
// 根据门诊类型获取科室
export function getOfficeListByKind (data) {
  return request({
    url: medRoutBaseUrl + '/clinics/offices/kind/list',
    method: 'get',
    params: data
  })
}

// 获取门诊预约列表
export function getAppointment (data) {
  return request({
    url: medRoutBaseUrl + '/clinics/schedules/appointment',
    method: 'get',
    params: data
  })
}

// 获取门诊预约详细列表
export function getAppointmentDetail (data) {
  return request({
    url:
      medRoutBaseUrl +
      `/clinics/schedules/appointment/${data.schedule_detail_id}/detail`,
    method: 'get'
  })
}

// 新增门诊
export function postClinicSchedule (data) {
  return request({
    url: medRoutBaseUrl + '/clinics/applys',
    method: 'post',
    data: data
  })
}

// 更新门诊
export function putClinicApplys (data) {
  return request({
    url: medRoutBaseUrl + `/clinics/applys/${data.clinic_apply.id}`,
    method: 'put',
    data: data
  })
}

// 获取门诊申请信息
export function getClinicDetail (clinicId) {
  return request({
    url: medRoutBaseUrl + `/clinics/applys/${clinicId}`,
    method: 'get'
  })
}
// 获取门诊申请信息
export function getClinicDetailAnonymous (clinicId) {
  return request({
    url: medRoutBaseUrl + `/clinics/applys/${clinicId}/anonymous`,
    method: 'get'
  })
}

// 获取门诊申请列表
export function getClinicApplys (data) {
  return request({
    url: medRoutBaseUrl + '/clinics/applys',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 门诊申请统计
export function total (data) {
  return request({
    url: medRoutBaseUrl + '/clinics/applys/total',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 门诊取号
export function takeNumber (clinicId) {
  return request({
    url: medRoutBaseUrl + `/clinics/applys/${clinicId}/number`,
    method: 'get'
  })
}
// 更新门诊状态
export function putClinicState (data) {
  return request({
    url: medRoutBaseUrl + `/clinics/applys/${data.clinic_id}/state`,
    method: 'put',
    data: data
  })
}

// 获取候诊列表
export function getClinicWait (data) {
  return request({
    url: medRoutBaseUrl + '/clinics/applys/wait',
    method: 'get',
    params: data
  })
}

// 获取门诊报告图片
export function getClinicReportImage (clinicId) {
  return request({
    url: medRoutBaseUrl + `/clinics/applys/${clinicId}/report-image`,
    method: 'get'
  })
}

// 获取预约申请单图片
export function getClinicRequestImage (clinicId) {
  return request({
    url: medRoutBaseUrl + `/clinics/applys/${clinicId}/request-image`,
    method: 'get'
  })
}

// 门诊呼叫
export function getClinicCall (clinicId) {
  return request({
    url: medRoutBaseUrl + `/clinics/applys/${clinicId}/call`,
    method: 'get'
  })
}

// 获取门诊字典
export function getClinicDictionary (list) {
  return request({
    url: medRoutBaseUrl + '/clinics/schedules/dictionary',
    method: 'get',
    params: { keys: list },
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取门诊科室医生职称列表
export function getClinicTittle (clinicId) {
  return request({
    url: medRoutBaseUrl + '/clinics/offices/doc/title',
    method: 'get'
  })
}

// 接诊医生工作日历
export function getWorkcalendar (data) {
  return request({
    url: medRoutBaseUrl + '/clinics/applys/work-calendar',
    method: 'get',
    params: data
  })
}