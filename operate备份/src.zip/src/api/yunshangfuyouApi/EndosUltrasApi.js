import request from '@/utils/request'
import qs from 'qs'
// const barse = 'http://192.168.1.207:9020'
const RoutBaseUrl = '/api-cloudpacs'
// 综合查询 检查状态----枚举接口
export function FetchEnum (data) {
  return request({
    url: RoutBaseUrl + '/Config/Enum',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 综合查询-导出
// /api/Composite/QueryExportExcel
export function QueryExportExcel (data) {
  return request({
    url: RoutBaseUrl + '/Composite/QueryExportExcel',
    method: 'GET',
    params: data,
    responseType: 'blob'
    // baseURL: barse
  })
}
// 检查完成
export function ReportCheckCompleted (data) {
  return request({
    url: RoutBaseUrl + '/Perform/' + data.id + '/Completed',
    method: 'patch',
    data: data
    // baseURL: barse
  })
}
// 报告占用
export function occupancyReport (data) {
  return request({
    url: RoutBaseUrl + '/Report/' + data.id + '/occupy',
    method: 'patch',
    data: data
    // baseURL: barse
  })
}
// 报告释放
export function releaseReport (data) {
  return request({
    url: RoutBaseUrl + '/Report/' + data.id + '/release',
    method: 'patch',
    data: data
    // baseURL: barse
  })
}
// 内镜-活检详情
export function FetchBiopsyDetails (data) {
  return request({
    url: RoutBaseUrl + '/Report/xis/' + data.id + '/biopsy',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 内镜-活检存储
export function SaveBiopsyDetails (data) {
  return request({
    url: RoutBaseUrl + '/Report/xis/' + data.id + '/biopsy',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}

// 获取影像存储列表--
// /api/Perform/Images/Archive
export function FetchUploadListArchive (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Images/Archive',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// /api/Composite/Image/ViewUrl
// 获取影像浏览地址
export function FetchUploadViewUrl (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Image/ViewUrl',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 内镜超声dicom浏览地址
export function FetchDicomViewUrl (data) {
  return request({
    url: RoutBaseUrl + '/Composite/Image/ViewUrl',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 添加文件存储-生成imageId
export function AddEndosUltrasFileStorage (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Images/Archive',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改-文件存储
// /api/Perform/Images/Archive/{id}
export function ModifyEndosUltrasFileStorage (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Images/Archive/' + data.id,
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}

// 删除- 文件存储-通过生成的id
export function DeleteEndosUltrasFileStorage (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Images/Archive',
    method: 'DELETE',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
    // baseURL: barse
  })
}

// 获取-报告图像列表
// /api/Perform/Images/Report
export function FetchReportList (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Images/Report',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 添加-报告图像
export function AddReportCollectImage (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Images/Report',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 删除-报告图像
export function DeleteReportCollectImage (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Images/Report/' + data.id,
    method: 'DELETE'
    // params: data
    // baseURL: barse
  })
}
// 修改-报告图像
export function ModifyReportCollectImage (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Images/Report/' + data.id,
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}

// 获取内镜样图
export function FetchOrganDrawing (data) {
  return request({
    url: RoutBaseUrl + '/Config/OrganDrawing',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// /api/Config/OrganDrawingMark
// 根据样图获取样图标记
export function FetchOrganDrawingMark (data) {
  return request({
    url: RoutBaseUrl + '/Config/OrganDrawingMark',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// /api/Perform/Images/Archive/ImageSign
// 内镜标注保存
export function ArchiveImageSign (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Images/Archive/ImageSign',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}
// 获取内镜消洗  /api/Perform/Endoscopes/CleaningbyIMCIS
export function FetchCleaningbyIMCIS (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Endoscopes/CleaningbyIMCIS',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 获取洗消记录
export function FetchEndoscopesCleaningReport (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Endoscopes/Cleaning',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 添加内镜消洗记录
// /api/Perform/Endoscopes/Cleaning
export function AddEndoscopesCleaningReport (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Endoscopes/Cleaning',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
// 修改内镜消洗记录
export function ModifyEndoscopesCleaningReport (data) {
  return request({
    url: RoutBaseUrl + '/Perform/Endoscopes/Cleaning',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}
// 切换医生
export function SwitchDoctor (data) {
  return request({
    url: RoutBaseUrl + '/Perform/SwitchDoctor',
    method: 'POST',
    data: data
    // baseURL: barse
  })
}
