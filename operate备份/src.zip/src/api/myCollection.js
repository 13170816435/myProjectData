import request from '@/utils/request'
import qs from 'qs'
// const barse = 'http://192.168.1.207:9020'
const RoutBaseUrl = '/api-telemed'
const CloudpacsUrl = '/api-cloudpacs'
const OperateUrl = '/api-operate'

// 收藏病例列表
export function getCollecList (data) {
  return request({
    url: RoutBaseUrl + '/case/collection',
    method: 'GET',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false, skipNulls: true })
    }
  })
}
// 收藏夹列表
export function getFavoriteList (data) {
  return request({
    url: RoutBaseUrl + '/case',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 添加收藏夹列表
export function add (data) {
  return request({
    url: RoutBaseUrl + '/case',
    method: 'POST',
    data: data
  })
}
// 更新收藏夹列表
export function update (data) {
  return request({
    url: RoutBaseUrl + '/case',
    method: 'PUT',
    data: data
  })
}
// 删除收藏夹列表
export function deleteList (data) {
  return request({
    url: RoutBaseUrl + '/case/' + data.id,
    method: 'DELETE'
  })
}
// 收藏夹拖拽排序
export function sort (data) {
  return request({
    url: RoutBaseUrl + '/case/sort',
    method: 'PUT',
    data: data
  })
}
// 添加病例收藏
export function addCase (data, id) {
  return request({
    url: RoutBaseUrl + '/case/' + id + '/collection',
    method: 'POST',
    data: data
  })
}
// 添加病例收藏
export function editCase (data, id) {
  return request({
    url: RoutBaseUrl + '/case/' + id + '/collection',
    method: 'PUT',
    data: data
  })
}
// 获取病例收藏详情
export function getDetail (data) {
  return request({
    url: RoutBaseUrl + '/case/' + data.id + '/collection',
    method: 'GET'
  })
}
// 判断病例是否已收藏
export function getIsCollect (id) {
  return request({
    url: RoutBaseUrl + '/case/' + id + '/hascollection',
    method: 'GET'
  })
}
// 取消病例
export function deleteCollect (data, id) {
  return request({
    url: RoutBaseUrl + '/case/' + id + '/collection',
    method: 'DELETE',
    data: data
  })
}
// 业务类型
export function getBusinessList (data, str) {
  return request({
    url: OperateUrl + '/dict/' + str,
    method: 'GET',
    params: data
    // baseURL: barse
  })
}
// 检查类型
export function getCheckList (data) {
  return request({
    url: CloudpacsUrl + '/Config/DicDefine',
    method: 'GET',
    params: data
  })
}
// icd名称
export function getIcdNameList (data) {
  return request({
    url: OperateUrl + '/jbmc',
    method: 'GET',
    params: data
  })
}
// 公共收藏权限
export function getPermissionCollectGg (data) {
  return request({
    url: OperateUrl + '/users/check-authority',
    method: 'GET',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
