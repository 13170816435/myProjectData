import request from '@/utils/request'
import qs from 'qs'
// const barse = 'http://192.168.1.173:8710'
const RoutBaseUrl = '/api-telemed'
// 获取办公地点分页列表
export function getConsultRoomList(data) {
  return request({
    url: RoutBaseUrl + `/places/${data.page_index}/${data.page_size}`,
    method: 'GET',
    params: data
  })
}
// 新增会诊室
export function beganAddRoom(data) {
  return request({
    url: RoutBaseUrl + '/places',
    method: 'post',
    data: data
    // baseURL: barse
  })
}
// 编辑会诊室
export function updateRoom(data) {
  return request({
    url: RoutBaseUrl + '/places',
    method: 'PUT',
    data: data
    // baseURL: barse
  })
}
// 获取专家组信息
export function getRoomDetail(data) {
  return request({
    url: RoutBaseUrl + `/places/${data.id}`,
    method: 'GET',
    params: data
  })
}
// 删除会诊室
export function DeleteRoom(data) {
  return request({
    url: RoutBaseUrl + `/places/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}
// 获取数据字典--远程医疗 ConsultKind-会诊类型 ConsultClass-会诊方式 SexType-性别 MaritalStatus-婚姻状况 IdCardType-证件类型 ConsultState-会诊状态
export function getMedDict(id) {
  return request({
    url: RoutBaseUrl + `/consultations/dics/${id}`,
    method: 'get'
  })
}
// 获取提供服务的检查类型
export function getExamineTypes(data) {
  return request({
    url: RoutBaseUrl + '/composite/examine-types',
    method: 'GET',
    params: data
  })
}
// 新增岗位
export function postPositions(data) {
  return request({
    url: RoutBaseUrl + '/consultation-positions',
    method: 'post',
    data: data
  })
}
// 获取岗位详情
export function getPositionDetail(id) {
  return request({
    url: RoutBaseUrl + `/consultation-positions/${id}`,
    method: 'get'
  })
}
// 更新岗位
export function putPositions(data) {
  return request({
    url: RoutBaseUrl + `/consultation-positions/${data.id}`,
    method: 'put',
    data: data
  })
}
// 删除岗位
export function deletePositions(id) {
  return request({
    url: RoutBaseUrl + `/consultation-positions/${id}`,
    method: 'delete'
  })
}
// 获取岗位分页列表
export function getPositions(data) {
  return request({
    url: RoutBaseUrl + '/consultation-positions',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
// 获取岗位列表
export function getPositionsLite(data) {
  return request({
    url: RoutBaseUrl + '/consultation-positions/lite',
    method: 'get',
    params: data
  })
}
// 新增排班
export function postSchedules(data) {
  return request({
    url: RoutBaseUrl + '/consultation-schedules',
    method: 'post',
    data: data
  })
}
// 获取排班分页列表
export function getSchedules(data) {
  return request({
    url: RoutBaseUrl + '/consultation-schedules',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
// 更新排班
export function putSchedules(data) {
  return request({
    url: RoutBaseUrl + `/consultation-schedules/${data.id}`,
    method: 'put',
    data: data
  })
}
// 获取排班详情
export function getScheduleDetail(id) {
  return request({
    url: RoutBaseUrl + `/consultation-schedules/${id}`,
    method: 'get'
  })
}
// 复制排班明细列表
export function postCopyDetails(data) {
  return request({
    url: RoutBaseUrl + `/consultation-schedules/${data.copy_schedule_id}/copy-details`,
    method: 'post',
    data: data
  })
}
// 获取排班列表
export function getSchedulesLite(data) {
  return request({
    url: RoutBaseUrl + '/consultation-schedules/lite',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}

/* 门诊相关 */

// 新增门诊科室
export function postClinicOffices(data) {
  return request({
    url: RoutBaseUrl + '/clinics/offices',
    method: 'post',
    data: data
  })
}
// 获取科室分页列表
export function getClinicOfficePage(data) {
  return request({
    url: RoutBaseUrl + '/clinics/offices/page',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
// 获取科室列表
export function getClinicOfficeList(data) {
  return request({
    url: RoutBaseUrl + '/clinics/offices/list',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
// 删除门诊科室
export function deleteClinicOffice(clinicOfficeId) {
  return request({
    url: RoutBaseUrl + `/clinics/offices/${clinicOfficeId}`,
    method: 'delete'
  })
}

// 获取门诊科室详情
export function getClinicOfficeInfo(clinicOfficeId) {
  return request({
    url: RoutBaseUrl + `/clinics/offices/${clinicOfficeId}`,
    method: 'get'
  })
}
// 更新门诊科室
export function putClinicOfficeInfo(data) {
  return request({
    url: RoutBaseUrl + `/clinics/offices/${data.id}`,
    method: 'put',
    data: data
  })
}
// 新增门诊时段
export function postClinicTimeSlots(data) {
  return request({
    url: RoutBaseUrl + '/clinics/time-slots',
    method: 'post',
    data: data
  })
}
// 更新门诊时段
export function putClinicTimeSlots(data) {
  return request({
    url: RoutBaseUrl + `/clinics/time-slots/${data.id}`,
    method: 'put',
    data: data
  })
}
// 删除门诊时段
export function deleteClinicTimeSlots(clinicTimeSlotId) {
  return request({
    url: RoutBaseUrl + `/clinics/time-slots/${clinicTimeSlotId}`,
    method: 'delete'
  })
}

// 获取门诊时段分页列表
export function getClinicTimeSloats(data) {
  return request({
    url: RoutBaseUrl + '/clinics/time-slots/page',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
// 获取门诊时段列表
export function getClinicTimeSloatList(data) {
  return request({
    url: RoutBaseUrl + '/clinics/time-slots/list',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
// 新增门诊班次
export function postClinicFrequency(data) {
  return request({
    url: RoutBaseUrl + '/clinics/schedules/frequency',
    method: 'post',
    data: data
  })
}
// 更新门诊班次
export function putClinicFrequency(data) {
  return request({
    url: RoutBaseUrl + `/clinics/schedules/frequency/${data.id}`,
    method: 'put',
    data: data
  })
}
// 删除门诊班次
export function deletetClinicFrequency(id) {
  return request({
    url: RoutBaseUrl + `/clinics/schedules/frequency/${id}`,
    method: 'delete'
  })
}
// 获取门诊班次分页列表
export function getClinicFrequency(data) {
  return request({
    url: RoutBaseUrl + '/clinics/schedules/frequency/page',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
// 获取门诊班次列表
export function getClinicFrequencyList(data) {
  return request({
    url: RoutBaseUrl + '/clinics/schedules/frequency/list',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
// 获取门诊班次详情
export function getClinicFrequencyInfo(clinicFrequencyId) {
  return request({
    url: RoutBaseUrl + `/clinics/schedules/frequency/${clinicFrequencyId}`,
    method: 'get'
  })
}

// 获取门诊排班管理列表
export function getClinicSchedules(data) {
  return request({
    url: RoutBaseUrl + '/clinics/schedules/manage',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
// 获取门诊排班是否已预约
export function getClinicSchedulesApp(data) {
  return request({
    url: RoutBaseUrl + '/clinics/schedules/appointment/exist',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
// 获取门诊排班明细列表
export function getClinicScheduleDetail(data) {
  return request({
    url: RoutBaseUrl + '/clinics/schedules/detail',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}

// 获取门诊排班周次列表
export function getClinicScheduleWeek(data) {
  return request({
    url: RoutBaseUrl + `/clinics/schedules/${data.clinic_office_id}/week`,
    method: 'get',
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}

// 新增门诊排班
export function postClinicSchedules(data) {
  return request({
    url: RoutBaseUrl + '/clinics/schedules',
    method: 'post',
    data: data
  })
}
// 更新门诊排班
export function putClinicSchedules(data) {
  return request({
    url: RoutBaseUrl + `/clinics/schedules/${data.clinic_schedule.id}`,
    method: 'put',
    data: data
  })
}
// 复制门诊排班
export function copyClinicSchedules(data) {
  return request({
    url: RoutBaseUrl + '/clinics/schedules/copy',
    method: 'post',
    data: data
  })
}
// 获取门诊医生列表
export function getOfficeDocList(data) {
  return request({
    url: RoutBaseUrl + '/clinics/offices/doc/list',
    method: 'get',
    params: data
  })
}
// 获取门诊数据字典
export function getClinicDictionary(keys) {
  return request({
    url: RoutBaseUrl + '/clinics/schedules/dictionary',
    method: 'get',
    params: {keys: keys},
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  })
}
