import request from '@/utils/request'
import qs from 'qs'

const RoutBaseUrl = '/api-datamining'
const RoutOperateUrl = '/api-operate'
const medRoutBaseUrl = '/api-telemed'


/**
 * 诊断申请量 页面
 * */

// 诊断申请量 -- 表格
export function getApplyQuantity(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/apply-diagnostic-quantity',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

/** ------------ */


/**
 * 诊断工作量 页面
 * */

// 远程诊断统计- 表格
export function getDiagnosisWorkload(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/doctor-diagnostic-workload',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

/** ------------ */


/**
 * 中心诊断量 页面
 * */

// 中心诊断量- 表格
export function getServiceCenterDiagnosis(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-diagnoses',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

/** ------------ */



// 远程诊断统计-获取医生
export function getDiagnosisApplyDoctor(data) {
  return request({
    url: RoutOperateUrl + '/users/diagnosis-apply-doctor',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取服务中心参数serviceCenterId=&paramModule=
export function getTelemedParameters(data) {
  return request({
    url: medRoutBaseUrl + '/sysparameter/telemed-parameters',
    method: 'get',
    params: data
  })
}

// 远程诊断统计-获取阳性率统计
export function getReportsPositiveRate(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/reports-positive-rate',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 远程诊断统计-获取中心工作量图表
export function getServiceCenterDiagnosesTendency(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-diagnoses-tendency',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 远程诊断统计-诊断超时列表
export function getServiceCenterDiagnosesElapsedTime(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-diagnostic-elapsed-time',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 远程诊断统计-诊断耗时图表
export function getServiceCenterDiagnosesElapsedTimeAverage(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-diagnostic-elapsed-time-average',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 远程诊断统计-诊断耗时分析（就诊类型对比和耗时占比）
export function getServiceCenterDiagnosesElapsedTimeAnalysis(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-diagnostic-elapsed-time-analysis',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 远程诊断统计-医生诊断耗时排行
export function getServiceCenterDiagnosesElapsedTimeRanking(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-diagnostic-elapsed-time-ranking',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 远程诊断统计-诊断及时率
export function getServiceCenterDiagnosesTimeliness(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-diagnostic-timeliness',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 远程诊断统计-诊断耗时明细
export function getServiceCenterDiagnosesItems(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-elapsed-time-items',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 远程诊断统计-诊断及时率明细
export function getServiceCenterTimelinessItems(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-timeliness-items',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取转往机构
export function getReferralsInstitue() {
  return request({
    url: '/api-telemed/referrals/institutions',
    method: 'GET'
    // params: data
  })
}

// 双向转诊统计-服务中心转诊申请量
export function getReferralOutApplications(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-referral-out-applications',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 双向转诊统计-服务中心转诊转出审核量
export function getReferralOutReviews(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-referral-out-reviews',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 双向转诊统计-服务中心转诊转入审核量
export function getReferralInReviews(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-center-referral-in-reviews',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 病种统计-获取会诊病种量
export function getDisease(data) {
  return request({
    url: '/api-telemed/statistics/disease',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 病种统计-获取病种会诊量趋势
export function getDiseaseParticulars(data) {
  return request({
    url: '/api-telemed/statistics/disease-particulars',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 病种统计-获取病种明细性别和年龄
export function getDiseaseDistribution(data) {
  return request({
    url: '/api-telemed/statistics/disease-distribution',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}


/**
 * hlp: 2022-08-03 新增api
 */
const paramsSerializer = data => qs.stringify(data, {indices: false})


/**
 * 诊断断申请量页面图表
 * */
// 诊断断申请量-获取诊断申请量图表
export const getServiceCenterRankingChart = params => request({
  url: `${RoutBaseUrl}/diagnosis/applications-ranking`,
  method: 'get',
  params,
  paramsSerializer
})


// 诊断断申请量-机构申请量占比分析
export const getServiceCenterRankingRateChart = params => request({
  url: `${RoutBaseUrl}/diagnosis/distribution-of-applications-by-exam-types`,
  method: 'get',
  params,
  paramsSerializer
})


// 诊断断申请量- 就诊类型占比分析
export const getServiceCenterRankingDoctorChart = params => request({
  url: `${RoutBaseUrl}/diagnosis/proportion-of-applications-by-patient-classes`,
  method: 'get',
  params,
  paramsSerializer
})

/** --------- */


/**
 * 诊断工作量页面图表
 */
// 诊断工作量 - 获取医生诊断排行量
export const getServiceCenterDoctorRanking = params => request({
  url: `${RoutBaseUrl}/diagnosis/diagnoses-ranking`,
  method: 'get',
  params,
  paramsSerializer
})

// 诊断工作量- 机构申请量占比分析
export const getServiceCenterDoctorRankingRate = params => request({
  url: `${RoutBaseUrl}/diagnosis/distribution-of-diagnoses-by-exam-types`,
  method: 'get',
  params,
  paramsSerializer
})


// 诊断工作量- 就诊类型占比分析
export const getServiceCenterDoctorRankingType = params => request({
  url: `${RoutBaseUrl}/diagnosis/distribution-of-diagnoses-by-patient-classes`,
  method: 'get',
  params,
  paramsSerializer
})

/** ---服务报告统计接口---- */
const serializePath = url => `${medRoutBaseUrl}/${url}`

// 获取服务报告统计概览
export const getServiceOverview = params => request({
  url: serializePath('statistics/service-overview'),
  method: 'get',
  params,
  paramsSerializer
})


/**
 * 获取会诊量趋势图数据
 * @param params
 * @returns {*}
 */
export const getConsultQuantity = params => request({
  url: serializePath('statistics/consult-quantity'),
  params,
  paramsSerializer
})

/**
 * 获取近半年会诊量增长趋势
 * @param params
 * @returns {*}
 */
export const getLastHalfAYearIncrease = params => request({
  url: serializePath('statistics/consult-increase'),
  params,
  paramsSerializer
})

/**
 * 获取患者分布
 * @param params
 * @returns {*}
 */
export const getPatientDistribution = params => request({
  url: serializePath('statistics/patient-distribution'),
  params,
  paramsSerializer
})

/**
 * 获取疾病分布
 * @param params
 * @returns {*}
 */
export const getDiseaseList = params => request({
  url: serializePath('statistics/disease'),
  params,
  paramsSerializer
})

/**
 * 获取会诊科室耗时
 * @param params
 * @returns {*}
 */
export const getOfficeElapsedTime = params => request({
  url: serializePath('statistics/office-elapsed-time'),
  params,
  paramsSerializer
})

/**
 * 获取会诊检查类型耗时
 * @param params
 * @returns {*}
 */
export const getConsultElapsedTime = params => request({
  url: serializePath('statistics/consult-elapsed-time'),
  params,
  paramsSerializer
})

/**
 * 获取申请量统计
 * @param params
 * @returns {*}
 */
export const getRequestRank = params => request({
  url: serializePath('statistics/request-rank'),
  params,
  paramsSerializer
})

/**
 * 获取会诊类型分布统计
 * @param params
 * @returns {*}
 */
export const getConsultExamineType = params => request({
  url: serializePath('statistics/consult-examine-type'),
  params,
  paramsSerializer
})

/**
 * 获取医生排行统计
 * @param params
 * @returns {*}
 */
export const getConsultRank = params => request({
  url: serializePath('statistics/consult-rank'),
  params,
  paramsSerializer
})

/**
 * 获取科室会诊量统计
 * @param params
 * @returns {*}
 */
export const getOfficeRank = params => request({
  url: serializePath('statistics/office-rank'),
  params,
  paramsSerializer
})

/**
 * 获取科室医生排行统计
 * @param params
 * @returns {*}
 */
export const getOfficeDoctorRank = params => request({
  url: serializePath('statistics/office-doctor-rank'),
  params,
  paramsSerializer
})

/**
 * 获取专家团队排行统计
 * @param params
 * @returns {*}
 */
export const getGroupRank = params => request({
  url: serializePath('statistics/group-rank'),
  params,
  paramsSerializer
})

/**
 * 获取专家团队医生排行统计
 * @param params
 * @returns {*}
 */
export const getGroupDoctorRank = params => request({
  url: serializePath('statistics/group-doctor-rank'),
  params,
  paramsSerializer
})

/** ---服务报告统计接口---  */


/** 诊断符合率接口 **/

/**
 * 诊断符合率列表
 * @param params
 * @returns {*}
 */
export const getRateList = params => request({
  url: `${RoutBaseUrl}/consult/accordance-rate`,
  params,
  paramsSerializer
})

/**
 * 诊断符合率详情列表
 * @param params
 * @returns {*}
 */
export const getRateDetailList = params => request({
  url: `${RoutBaseUrl}/consult/accordance-rate-details`,
  params,
  paramsSerializer
})


/**
 * 获取会诊统计-会诊申请量列表
 * @param params
 * @returns {*}
 */
export const getTenancyRequest = params => request({
  url: serializePath('statistics/tenancy-consult-request-report'),
  params,
  paramsSerializer
})


/**
 * 获取会诊统计-会诊申请量图表
 * @param params
 * @returns {*}
 */
export const getTenancyRequestRank = params => request({
  url: serializePath('statistics/tenancy-request-trend'),
  params,
  paramsSerializer
})


/**
 * 点击诊断申请量的机构名称跳转的科室管理api
 * @param params
 * @returns {*}
 */
export const getTenancyRequestOffice = params => request({
  url: serializePath('statistics/tenancy-request-office'),
  params,
  paramsSerializer
})

/**
 * 获取会诊统计-获取客户内会诊工作量统计
 * @param params
 * @returns {*}
 */
 export const getTenancyWorkReport = params => request({
  url: serializePath('statistics/tenancy-work-report'),
  params,
  paramsSerializer
})

/**
 * 获取会诊统计-获取客户内服务中心工作量排行统计
 * @param params
 * @returns {*}
 */
 export const getTenancyWorkRank = params => request({
  url: serializePath('statistics/tenancy-work-rank'),
  params,
  paramsSerializer
})

/**
 * 获取会诊统计-获取客户内工作量分布统计
 * @param params
 * @returns {*}
 */
 export const getTenancyWorkTrend = params => request({
  url: serializePath('statistics/tenancy-work-trend'),
  params,
  paramsSerializer
})

/**
 * 获取会诊统计-获取客户内工作量分布统计
 * @param params
 * @returns {*}
 */
export const getTenancyWorkTrendRank = params => request({
  url: serializePath('statistics/tenancy-work-rank'),
  params,
  paramsSerializer
})

/**
 * 获取申请的详情列表
 * @param params
 * @returns {*}
 */
export const getTenancyRequestDetails = params => request({
  url: serializePath('statistics/tenancy-request-details'),
  params,
  paramsSerializer
})

/**
 * 获取申请的详情列表
 * @param params
 * @returns {*}
 */
 export const getTenancyWorkDetails = params => request({
  url: serializePath('statistics/tenancy-work-details'),
  params,
  paramsSerializer
})

/** ------------- */
// 服务机构服务开展量- 表格
export function getServiceInstituteQuantity(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/service-institution-implementation-status',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
// 申请机构服务开展量 -- 表格
export function getApplyInstituteQuantity(data) {
  return request({
    url: RoutBaseUrl + '/diagnosis/request-institution-implementation-status',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}
