import request from '@/utils/request'
import qs from 'qs'
const RoutBaseUrl = '/api-cloudpacs'
// 获取参数模块
export function getParamModule (data) {
  return request({
    url: RoutBaseUrl + '/Config/SysParameter/Modules',
    method: 'GET',
    params: data
  })
}
// 获取配置（分页）
export function getParamDataList (data) {
  return request({
    url: RoutBaseUrl + '/Config/SysParameter/Page',
    method: 'GET',
    params: data
  })
}
// 获取配置 （不分页）
export function getAllParamData (data) {
  return request({
    url: RoutBaseUrl + '/Config/SysParameter',
    method: 'GET',
    params: data
  })
}
// 获取用户评价列表
export function getRemarkList (data) {
  return request({
    url: RoutBaseUrl + '/Composite/Evaluation',
    method: 'GET',
    params: data
  })
}
// 获取用户评价列表
export function ExportRemark (data) {
  return request({
    url: RoutBaseUrl + '/Composite/Evaluation/Export',
    method: 'GET',
    'responseType':'blob',
    params: data
  })
}
// 保存参数
export function saveSystemParam (data) {
  return request({
    url: RoutBaseUrl + '/Config/SysParameter',
    method: 'PUT',
    data: data
  })
}