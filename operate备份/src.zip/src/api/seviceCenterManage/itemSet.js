/**
 * hlp: 2022-08-05
 * 检查项目对照 api */
import request from '@/utils/request'
import qs from 'qs'


const RoutBaseUrl = '/api-telemed'

const paramsSerializer = data => qs.stringify(data, {indices: false})


/**
 * 获取机构名称下拉列表
 * @returns {Promise<AxiosResponse<any>>}
 */
export const getHospitalList = () => request.get(`${RoutBaseUrl}/exam-recognition/options/hospital-items`)

/**
 * 获取检查部位下拉列表
 * @returns {Promise<AxiosResponse<any>>}
 */
export const getCheckList = params => request.get(`${RoutBaseUrl}/exam-recognition/options/exam-categories`, {
  params,
  paramsSerializer
})

/**
 * 获取检查类型下拉列表
 * @returns {Promise<AxiosResponse<any>>}
 */
export const getCheckTypeList = params => request.get(`${RoutBaseUrl}/exam-recognition/options/service-sect-ids`, {
  params
})

/**
 * 获取已对码，未对码情况
 * @param params
 * @returns {*}
 */
export const getItemCheckTotal = params => request(`${RoutBaseUrl}/exam-recognition/aggregation`, {
  params,
  paramsSerializer
})

/**
 * 列出院内检查项目
 * @returns {Promise<AxiosResponse<any>>}
 */
export const getItemList = (params, standardized) => {
  const url = standardized ? `${RoutBaseUrl}/exam-recognition/options/exam-items-standardized`:`${RoutBaseUrl}/exam-recognition/options/exam-items`
  return request.get(url, {
    params,
    paramsSerializer
  })
}

/**
 * 获取表格列表
 * @param params
 * @returns {Promise<AxiosResponse<any>>}
 */
export const getItemSetList = params => request({
  url: `${RoutBaseUrl}/exam-recognition/list`,
  params,
  paramsSerializer
})

/** ---------- */
