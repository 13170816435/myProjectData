import request from '@/utils/request'
import qs from 'qs'
const medRoutBaseUrl = '/api-telemed'
const operateRoutBaseUrl = '/api-operate'

// 获取课程栏目分页列表
export function getTeachsColumn (data) {
  return request({
    url: medRoutBaseUrl + '/teachs/column',
    method: 'get',
    params: data
  })
}
// 获取亚专科列表
export function getTeachsSpecial (data) {
  return request({
    url: medRoutBaseUrl + '/teachs/special',
    method: 'get',
    params: data
  })
}
// 保存课程信息
export function postTeachs (data) {
    return request({
      url: medRoutBaseUrl + '/teachs',
      method: 'post',
      data: data
    })
}
// 更新课程信息
export function putTeachs (data) {
  return request({
    url: medRoutBaseUrl + '/teachs/' + data.id,
    method: 'put',
    data: data
  })
}
// 获取课程列表
export function getTeachs (data) {
    return request({
      url: medRoutBaseUrl + '/teachs',
      method: 'get',
      params: data,
      paramsSerializer: params => {
        return qs.stringify(params, { indices: false })
      }
    })
}
// 获取学习管理列表
export function getStudyList (data) {
  return request({
    url: medRoutBaseUrl + '/teachs/study',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 学习情况统计
export function getStudyingTotal (data) {
  return request({
    url: medRoutBaseUrl + '/teachs/study-total',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 获取主讲人
export function getPresenter (data) {
  return request({
    url: medRoutBaseUrl + '/teachs/statistics-lecturer',
    method: 'get',
    params: data
  })
}
// 授课情况统计
export function getTeachingTotal (data) {
  return request({
    url: medRoutBaseUrl + '/teachs/teaching-total',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 获取课程详情
export function getTeachDetail (id) {
  return request({
    url: medRoutBaseUrl + '/teachs/' + id,
    method: 'get'
  })
}
// 更新课程状态
export function putState (data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${data.teachId}/state?state=${data.state}`,
    method: 'put'
  })
}
// 新增试题
export function postQuestion (data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/question`,
    method: 'post',
    data: data
  })
}
// 更新试题
export function putQuestion (data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${data.id}/question`,
    method: 'put',
    data: data
  })
}
// 删除试题
export function deleteQuestion (id) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${id}/question`,
    method: 'delete'
  })
}
// 获取习题详情
export function getQuestion (id) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${id}/question`,
    method: 'get'
  })
}

// 获取试卷详情
export function getPaper (id) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${id}/paper`,
    method: 'get'
  })
}
// 获取学员试卷
export function getStudentPaper (data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/student-paper`,
    method: 'get',
    params: data
  })
}
// 提交试卷答案
export function postPaperAnswer (data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/paper-answer`,
    method: 'post',
    data: data
  })
}
// 学习统计
export function getStatisticsStudy(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/statistics-study`,
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 学员学习明细
export function getStatisticsStudyDetail(id) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${id}/statistics-study`,
    method: 'get'
  })
}
// 授课统计
export function getStatisticsTeaching(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/statistics-teaching`,
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 授课明细
export function getStatisticsTeachingDetail(id) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${id}/statistics-teaching`,
    method: 'get'
  })
}
// 课程统计
export function getStatisticsTeach(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/statistics-teach`,
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 课程学习明细
export function getStatisticsTeachDetail(id) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${id}/statistics-teach`,
    method: 'get'
  })
}

// 获取所属机构信息
export function getStatisticsInstitution(id) {
  return request({
    url: `${medRoutBaseUrl}/teachs/statistics-institution`,
    method: 'get'
  })
}

// 获取机构下的用户信息
export function getStatisticsUser(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/statistics-user`,
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取所有课程讲师信息
export function getStatisticsLecturerData(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/statistics-lecturer`,
    method: 'get',
    params: data
  })
}
// 获取课程学员记录
export function getStudent(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/student`,
    method: 'get',
    params: data
  })
}
// 新增学员记录
export function postStudent(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/student`,
    method: 'post',
    data: data
  })
}
// 获取课程学员记录
export function getTeachStudent(teachId) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${teachId}/student`,
    method: 'get'
  })
}
// 删除课程学员记录
export function deleteTeachStudent(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${data.teach_student_id}/student`,
    method: 'delete',
    params: data
  })
}
// 获取课程来源
export function getSource(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/source`,
    method: 'get',
    params: data
  })
}
// 获取课件分页列表
export function getCourse(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/course`,
    method: 'get',
    params: data
  })
}
// 新增课程课件信息
export function postCourse(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/course`,
    method: 'post',
    data: data
  })
}
// 删除课程课件信息
export function deleteCourse(courseId) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${courseId}/course`,
    method: 'delete'
  })
}
// 获取课件信息
export function getCourseDetail(courseId) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${courseId}/course`,
    method: 'get'
  })
}
// 更新课件信息
export function putCourseDetail(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${data.id}/course`,
    method: 'put',
    data: data
  })
}
// 获取评价分页列表
export function getEvaluate(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/evaluate`,
    method: 'get',
    params: data
  })
}
// 新增课程评价信息
export function postEvaluate(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/evaluate`,
    method: 'post',
    data: data
  })
}

// 创建视频会议
export function postMetting(teachId) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${teachId}/meeting`,
    method: 'post',
    data: {teach_id: teachId}
  })
}

// 课件学习记录
export function putCourseRead(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/course-read`,
    method: 'put',
    data: data
  })
}

// 详情数量统计
export function getDetailTotal(teach_id) {
  return request({
    url: `${medRoutBaseUrl}/teachs/detail-total`,
    method: 'get',
    params: { teach_id: teach_id}
  })
}

// 查询会议直播信息
export function getMettingsLive(data) {
  return request({
    url: `${operateRoutBaseUrl}/meetings/${data.business_id}/${data.kind}/live`,
    method: 'get'
  })
}

// 获取评价是否存在
export function getEvaluateExist(teach_id) {
  return request({
    url: `${medRoutBaseUrl}/teachs/evaluate/exist`,
    method: 'get',
    params: { teach_id: teach_id}
  })
}

// 获取学员是否已考试
export function getExist(teach_id) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${teach_id}/exist`,
    method: 'get'
  })
}

// 获取用户信息列表
export function getUserLite(data) {
  return request({
    url: `${operateRoutBaseUrl}/users/lite`,
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取机构精简信息列表
export function getInstitutionsLite(data) {
  return request({
    url: `${operateRoutBaseUrl}/institutions/lite`,
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取课程类型统计/api/teachs/kind-total
export function getKindTotal(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/kind-total`,
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取我的课程信息/api/teachs/public-teachs/my-teach
export function getMyTeach() {
  return request({
    url: `${medRoutBaseUrl}/teachs/public-teachs/my-teach`,
    method: 'get'
  })
}

// 获取学习概览
export function getStudyView(teachId) {
  return request({
    url: `${medRoutBaseUrl}/teachs/public-teachs/${teachId}/study-view`,
    method: 'get'
  })
}
// 获取短链
export function getShortUrl(obj) {
  return request({
    url: `${medRoutBaseUrl}/teachs/${obj.teach_id}/short-url`,
    method: 'get',
    params: obj
  })
}
// 新增教学用户
export function postTeachsUser(data) {
  return request({
    url: `${medRoutBaseUrl}/teachs/teachs-user`,
    method: 'post',
    data: data
  })
}

// 上传媒体文件
export function postUpload(data) {
  return request({
    url: `${medRoutBaseUrl}/media/upload`,
    method: 'post',
    data: data
  })
}

// 下载媒体文件/api/media/download
export function getMedDownload(id) {
  return request({
    url: `${medRoutBaseUrl}/media/download`,
    method: 'get',
    params: { file_token: id },
    responseType: 'arraybuffer'
  })
}

// 下载媒体文件/api/media/download
export function getMedDownloadBlob(id) {
  return request({
    url: `${medRoutBaseUrl}/media/download`,
    method: 'get',
    params: { file_token: id },
    responseType: 'blob'
  })
}

// 获取数据字典--平台
export function getDict (data) {
  return request({
    url: operateRoutBaseUrl + `/dict/${data.lookup_key}`,
    method: 'get',
    params: data
  })
}
// 删除已上传资料
export function deleteLoadFile (data) {
  return request({
    url: idcasRoutBaseUrl + '/Documents/update-tag',
    method: 'put',
    data: data
  })
}
// 更新课程上架状态
export function putShelvesState (data) {
  return request({
    url: medRoutBaseUrl + '/teachs/shelves-state',
    method: 'put',
    data: data
  })
}
