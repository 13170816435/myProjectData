import request from '@/utils/request'
import qs from 'qs'
// const barse = 'http://192.168.1.173:8710'
const RoutBaseUrl = '/api-operate'
const RoutPacsUrl = '/api-datamining'
const RoutTelemed = '/api-telemed'

// 获取所有的专家团队 (分页)
export function getExpertGroup(data) {
  return request({
    url: RoutBaseUrl + '/specialist-groups',
    method: 'GET',
    params: data
  })
}

// 删除专家组
export function DeleteGroup(data) {
  return request({
    url: RoutBaseUrl + `/specialist-groups/${data.id}/delete`,
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 添加 专家组
export function beganAddGroup(data) {
  return request({
    url: RoutBaseUrl + '/specialist-groups',
    method: 'post',
    data: data
    // baseURL: barse
  })
}

// 获取专家组信息
export function getGroupDetail(data) {
  return request({
    url: RoutBaseUrl + `/specialist-groups/${data.id}`,
    method: 'GET',
    params: data
  })
}

// 获取专家组logo
export function getGroupLogo(logoId) {
  return request({
    url: RoutBaseUrl + `/specialist-groups/logo/${logoId}`,
    method: 'GET',
    responseType: 'arraybuffer',
  })
}

// 获取办公地点分页列表
export function getConsultRoomList(data) {
  return request({
    url: RoutBaseUrl + `/places/${data.page_index}/${data.page_size}`,
    method: 'GET',
    params: data
  })
}

// 获取权限组
export function getAuthorityGroups(data) {
  return request({
    url: RoutBaseUrl + '/authority-groups/lite',
    method: 'GET',
    params: data
  })
}

// 获取用户列表
export function getUserList(data) {
  return request({
    url: RoutBaseUrl + '/authority-groups/user',
    method: 'GET',
    params: data
  })
}

// 批量删除 用户
export function removeMember(data) {
  return request({
    url: RoutBaseUrl + '/users/authority-group/delete',
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取所有的用户组 (分页)
export function getAuthorityUserGroups(data) {
  return request({
    url: RoutBaseUrl + '/authority-groups',
    method: 'GET',
    params: data
  })
}

// 删除某权限组
export function delAuthorityUserGroups(data) {
  return request({
    url: RoutBaseUrl + '/authority-groups/delete',
    method: 'post',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, {indices: false})
    }
  })
}

// 获取用户权限分组 的详情
export function getAuthorityGroupDetail(data) {
  return request({
    url: RoutBaseUrl + '/authority-groups/detail',
    method: 'GET',
    params: data
  })
}

// 添加 权限用户组
export function addAuthorityGroups(data) {
  return request({
    url: RoutBaseUrl + '/authority-groups',
    method: 'post',
    data: data
  })
}

// 获取服务类型
export function getServiceClass(data) {
  return request({
    url: RoutBaseUrl + '/dict/types',
    method: 'GET',
    params: data
  })
}

// 获取服务项目
export function getServiceProject(data) {
  return request({
    url: RoutBaseUrl + '/dict',
    method: 'GET',
    params: data
  })
}

// 获取服务中心权限列表
export function getServiceCenterPower(data) {
  return request({
    url: RoutBaseUrl + '/authority-groups/service-center',
    method: 'GET',
    params: data
  })
}

// 修改权限组
export function updatePowerGroup(data) {
  return request({
    url: RoutBaseUrl + `/authority-groups/${data.id}/update`,
    method: 'post',
    data: data
  })
}

// 获取所有的医技系统
export function getAllSystem(data) {
  return request({
    url: RoutBaseUrl + '/systems',
    method: 'GET',
    params: data
  })
}

// 获取检查类型
export function getAllInspectClass(data) {
  return request({
    url: RoutBaseUrl + `/dict/${data.lookup_key}`,
    method: 'GET',
    params: data
  })
}

// 获取合作医院
export function getInstitutions(data) {
  return request({
    url: RoutBaseUrl + '/service-cooperations/institutions',
    method: 'get',
    params: data
  })
}

// 获取申请医院
export function getApplyInstitutions(data) {
  return request({
    url: RoutPacsUrl + '/consult/app-orgs',
    method: 'get',
    params: data
  })
}

// 获取会诊类型
export function getConsultType(data) {
  return request({
    url: RoutPacsUrl + '/consult/ConsultKindsCode',
    method: 'get',
    params: data
  })
}

// 获取医生
export function getConsultDoctor(data) {
  return request({
    url: RoutPacsUrl + '/consult/doctors',
    method: 'get',
    params: data
  })
}

// 添加评价方案
export function addEvaluateScheme(data) {
  return request({
    url: RoutTelemed + '/diagnosis/add-evaluate-scheme',
    method: 'post',
    data: data
  })
}

// 更新评价方案
export function updateEvaluateScheme(data) {
  return request({
    url: RoutTelemed + '/diagnosis/update-evaluate-scheme',
    method: 'post',
    data: data
  })
}

// 获取评价方案详情
export function getEvaluateSchemeDetail(id) {
  return request({
    url: RoutTelemed + `/diagnosis/${id}/get-evaluate-scheme-detail`,
    method: 'get'
  })
}

// 获取评价方案列表
export function getEvaluateSchemeList(data) {
  return request({
    url: RoutTelemed + '/diagnosis/get-evaluate-scheme-list',
    method: 'get',
    params: data
  })
}

// 删除评价方案
export function deleteEvaluateScheme(id) {
  return request({
    url: RoutTelemed + `/diagnosis/${id}/delete-evaluate-scheme`,
    method: 'delete'
  })
}

// 添加评价维度
export function addEvaluateDimension(data) {
  return request({
    url: RoutTelemed + '/diagnosis/add-evaluate-dimension',
    method: 'post',
    data: data
  })
}

// 更新评价维度
export function updateEvaluateDimension(data) {
  return request({
    url: RoutTelemed + '/diagnosis/update-evaluate-dimension',
    method: 'post',
    data: data
  })
}

// 删除评价维度
export function deleteEvaluateDimension(id) {
  return request({
    url: RoutTelemed + `/diagnosis/${id}/delete-evaluate-dimension`,
    method: 'post'
  })
}

// 启用停用评价维度
export function enableEvaluateDimension(data) {
  return request({
    url: RoutTelemed + '/diagnosis/enable-disable-evaluate-dimension',
    method: 'post',
    data: data
  })
}

// 获取评价维度列表
export function getEvaluateDimensionList(id) {
  return request({
    url: RoutTelemed + '/diagnosis/evaluate-dimension-list',
    method: 'get',
    params: {evaluate_scheme_id: id}
  })
}

// 添加评价星级
export function addEvaluateStar(data) {
  return request({
    url: RoutTelemed + '/diagnosis/add-evaluate-star',
    method: 'post',
    data: data
  })
}

// 更新评价星级
export function updateEvaluateStar(data) {
  return request({
    url: RoutTelemed + '/diagnosis/update-evaluate-star',
    method: 'post',
    data: data
  })
}

// 删除评价星级
export function deleteEvaluateStar(id) {
  return request({
    url: RoutTelemed + `/diagnosis/${id}/delete-evaluate-star`,
    method: 'post'
  })
}

// 启用、禁用评价星级
export function enableDisableEvaluateStar(data) {
  return request({
    url: RoutTelemed + '/diagnosis/enable-disable-evaluate-star',
    method: 'post',
    data: data
  })
}

// 获取评价星级列表
export function evaluateStarList(id) {
  return request({
    url: RoutTelemed + `/diagnosis/${id}/evaluate-star-list`,
    method: 'get'
  })
}

// 获取服务中心机构（所属机构、签约机构）
export function getCenterInstitution(data) {
  return request({
    url: RoutBaseUrl + '/service-centers/institution',
    method: 'get',
    params: data
  })
}

// 分页获取服务中心用户信息
export function getCenterUser(str) {
  return request({
    url: RoutBaseUrl + '/users?' + str,
    method: 'get'
  })
}

// 获取申请医院签约服务中心
export function getSignatoryServiceCenters(data) {
  return request({
    url: RoutBaseUrl + '/service-cooperations/signatory-service-centers',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 获取服务评价统计
export function getServiceEvaluateStatisticsList(data) {
  return request({
    url: RoutTelemed + '/diagnosis/service-evaluate-statistic-list',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {indices: false})
    }
  })
}

// 获取评价统计数量
export function getServiceEvaluateStatisticsCount(data) {
  return request({
    url: RoutTelemed + '/diagnosis/service-evaluate-statistic-count',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, {indices: false})
    }
  })
}

// 获取评价详情
export function serviceEvaluateDetail(id) {
  return request({
    url: RoutTelemed + `/diagnosis/${id}/service-evaluate-detail`,
    method: 'get'
  })
}

// 服务评价
export function addServiceEvaluate(data) {
  return request({
    url: RoutTelemed + '/diagnosis/add-service-evaluate',
    data,
    method: 'Post'
  })
}

// 获取评价方案详情
export function serviceEvaluateScheme(data) {
  return request({
    url: RoutTelemed + '/diagnosis/service-evaluate-scheme',
    method: 'get',
    params: data
  })
}

// 获取业务资料文档分页列表
export function getDocitems(data) {
  return request({
    url: '/api-telemed/docitems',
    method: 'get',
    params: data
  })
}

// 新增业务资料文档
export function postDocitems(data) {
  return request({
    url: '/api-telemed/docitems',
    method: 'post',
    data
  })
}

// 编辑业务资料文档
export function putDocitems(data) {
  return request({
    url: '/api-telemed/docitems',
    method: 'put',
    data
  })
}

// 删除业务资料文档
export function deleteDocitems(id) {
  return request({
    url: `/api-telemed/docitems/${id}`,
    method: 'delete',
  })
}

// 获取业务资料文档详情
export function getDocitemsDetail(id) {
  return request({
    url: `/api-telemed/docitems/${id}`,
    method: 'get'
  })
}

// 批量新增业务资料
export function postDocitemsList(data) {
  return request({
    url: '/api-telemed/docitems/list',
    method: 'post',
    data
  })
}

// 获取初始化配置数据
export function getInitialization(data) {
  return request({
    url: RoutTelemed + '/parameters/initialization',
    method: 'get',
    params: data
  })
}

// 获取配置数据
export function getParameters(data) {
  return request({
    url: RoutTelemed + '/parameters',
    method: 'get',
    params: data
  })
}

// 批量新增远程医疗配置参数
export function postParametersList(data) {
  return request({
    url: RoutTelemed + '/parameters/list',
    method: 'post',
    data: data
  })
}

// 获取病情等级
export function getiLlnessLevels(data) {
  return request({
    url: RoutTelemed + '/sysparameter/illness-levels',
    method: 'get',
    params: data
  })
}

// 获取妊娠等级
export function getGestationRiskRanks(data) {
  return request({
    url: RoutTelemed + '/sysparameter/gestation-risk-ranks',
    method: 'get',
    params: data
  })
}


/**
 * 随访表单api
 */


/**
 * 新增分类
 * @param data
 * @returns {*}
 */
export const addFormCategory = data => request({
  url: `${RoutTelemed}/follow-up-form/add-follow-up-form-category`,
  method: 'post',
  data
})

/**
 * 更新分类
 * @param data
 * @returns {*}
 */
export const editFormCategory = data => request({
  url: `${RoutTelemed}/follow-up-form/update-follow-up-form-category`,
  method: 'post',
  data
})


/**
 * 获取分类列表
 * @returns {*}
 */
export const getFormCategoryList = () => request({
  url: `${RoutTelemed}/follow-up-form/follow-up-form-category-list`
})


/**
 * 获取表单列表
 * @param params
 * @returns {*}
 */
export const getFormList = params => request({
  url: `${RoutTelemed}/follow-up-form/follow-up-form-list`,
  params
})

/**
 * 新增表单
 * @param data
 * @returns {*}
 */
export const addFormItem = data => request({
  url: `${RoutTelemed}/follow-up-form/add-follow-up-form`,
  method: 'post',
  data,
  paramsSerializer: data => {
    return qs.stringify(data, {indices: false})
  }
})

/**
 * 更新表单
 * @param data
 * @returns {*}
 */
export const editFormItem = data => request({
  url: `${RoutTelemed}/follow-up-form/update-follow-up-form`,
  method: 'post',
  data
})

/**
 * 获取表单内容
 * @param params
 * @returns {*}
 */
export const getFormItemContent = params => request({
  url: `${RoutTelemed}/follow-up-form/template-content`,
  params
})

/**
 * 删除表单
 * @param data
 * @returns {*}
 */
export const deleteFormItem = data => request({
  url: `${RoutTelemed}/follow-up-form/delete-follow-up-form`,
  method: 'post',
  data
})

/**
 * 删除表单分类
 * @param data
 * @returns {*}
 */
export const deleteFormClass = data => request({
  url: `${RoutTelemed}/follow-up-form/delete-follow-up-form-category`,
  method: 'post',
  data
})


/**
 * 更新分类拖拽排序位置
 * @param data
 * @returns {*}
 */
export const sortedFormClass = data => request({
  url: `${RoutTelemed}/follow-up-form/update-follow-up-form-category`,
  method: 'post',
  data
})



export const uploadMedias = (url, data) => request({
  url,
  method: 'post',
  data
})
