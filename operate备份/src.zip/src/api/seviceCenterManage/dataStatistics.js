import request from '@/utils/request'
import qs from 'qs'
const RoutBaseUrl = '/api-telemed'
const RoutDatamining = '/api-datamining'

// 病理-获取不合格标本统计
export function pisSpecimenStatistice(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/specimen-statistice',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 病理-获取不合格标本统计详情
export function pisSpecimenStatisticeDetail(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/statistice-detail',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 病理-获取申请量统计
export function pisAppliesQuantityStatistice(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/applies-quantity-statistice',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 病理-获取申请量统计详情
export function pisSpecimenDetail(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/statistice-detail',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 病理-获取工作量统计（机构服务量）
export function pisServiceQuantityStatistice(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/service-quantity-statistice',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 病理-获取检查项目量统计
export function pisItemQuantityStatistice(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/item-quantity-statistice',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 病理-获取诊断量统计
export function pisDiagnosisQuantityStatistice(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/diagnosis-quantity-statistice',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 病理-获取切片统计详情
export function pisSliceStatisticeDetail(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/slice/statistice-detail',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 获取病理切片申请量统计
export function pisSliceApplyQuality(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/slice/applies-quantity-statistice',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 获取病理切片工作量（机构服务量）统计
export function pisSliceServiceQuality(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/slice/service-quantity-statistice',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 获取病理切片诊断量统计
export function pisSliceDiagnosisQuality(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/slice/diagnosis-quantity-statistice',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 获取病理切片检查项目量统计
export function pisSliceItemQuality(data) {
  return request({
    url: RoutBaseUrl + '/whc-pis-diagnosis/slice/item-quantity-statistice',
    method: 'get',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, {
        indices: false
      })
    }
  })
}

// 心电-获取检查质量列表统计
export function getCheckQualityStatistic (data) {
  return request({
    url: RoutDatamining + '/diagnosis/check-quality-statistic',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取报告质量列表统计
export function getReportQualityStatistic (data) {
  return request({
    url: RoutDatamining + '/diagnosis/report-quality-statistic',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取危急值统计
export function getCriticalValueStatistic (data) {
  return request({
    url: RoutDatamining + '/diagnosis/critical-value-statistic',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取危急值明细分页列表
export function getCriticalValueList (data) {
  return request({
    url: RoutDatamining + '/diagnosis/critical-value-list',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取检查效率统计
export function getCheckEfficiencyStatistic (data) {
  return request({
    url: RoutDatamining + '/diagnosis/check-efficiency-statistic',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取检查效率明细分页数据
export function getCheckEfficiencyList (data) {
  return request({
    url: RoutDatamining + '/diagnosis/check-efficiency-list',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取分级预警统计
export function ecgHierarchicalEarlyWarnStatistic (data) {
  return request({
    url: RoutDatamining + '/diagnosis/hierarchical-early-warn-statistic',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取分级预警明细分页列表
export function ecgHierarchicalEarlyWarnListc (data) {
  return request({
    url: RoutDatamining + '/diagnosis/hierarchical-early-warn-list',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取申请工作量统计
export function ecgApplyWorkloadStatistic (data) {
  return request({
    url: RoutDatamining + '/diagnosis/apply-workload-statistic',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取申请工作量分页统计明细列表
export function ecgApplyWorkloadList (data) {
  return request({
    url: RoutDatamining + '/diagnosis/apply-workload-list',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取专家工作量统计
export function ecgExpertWorkloadStatistic (data) {
  return request({
    url: RoutDatamining + '/diagnosis/expert-workload-statistic',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取申请工作量分页统计明细列表
export function ecgExpertWorkloadList (data) {
  return request({
    url: RoutDatamining + '/diagnosis/expert-workload-list',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取报告阳性率统计
export function ecgReportPositiveRateStatistict (data) {
  return request({
    url: RoutDatamining + '/diagnosis/report-positive-rate-statistic',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取报告阳性率分页明细列表
export function ecgReportPositiveRateList (data) {
  return request({
    url: RoutDatamining + '/diagnosis/report-positive-rate-list',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取报告修改率统计
export function ecgReportEditrateStatistic (data) {
  return request({
    url: RoutDatamining + '/diagnosis/report-editrate-statistic',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取申请单质量统计
export function ecgApplicationformQualityStatistic (data) {
  return request({
    url: RoutDatamining + '/diagnosis/applicationform-quality-statistic',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取申请单质量统计分页列表
export function ecgApplicationformQualityList (data) {
  return request({
    url: RoutDatamining + '/diagnosis/applicationform-quality-list',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取异常病种统计
export function ecgAbnormalDiseaseStatistic (data) {
  return request({
    url: RoutDatamining + '/diagnosis/abnormal-disease-statistic',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-获取异常病种分页列表
export function ecgAbnormalDiseaseList (data) {
  return request({
    url: RoutDatamining + '/diagnosis/abnormal-disease-list',
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 心电-数据导出
export function ecgExport (data) {
  return request({
    url: RoutDatamining + '/diagnosis/export',
    method: 'POST',
    data: data
  })
}

// 获取服务中心相关统计
// 活动用户数
export function getActivityUsers (id) {
  return request({
    url: `${RoutDatamining}/service-centers/${id}/activity-users`,
    method: 'GET',
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 业务动态： 诊断：书写、审核、修订 会诊：调度、会诊、修订 转诊：审核 门诊：接诊 查房：调度、查房
export function getAgreeableServices (id) {
  return request({
    url: `${RoutDatamining}/service-centers/${id}/agreeable-services`,
    method: 'GET',
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 统计完成（如诊断已审核、会诊已完成）的服务数量
export function getCompletedServices (id) {
  return request({
    url: `${RoutDatamining}/service-centers/${id}/completed-services`,
    method: 'GET',
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 统计指定业务完成（如诊断已审核、会诊已完成）的服务数量
export function getCompletedServicesExpanded (data) {
  return request({
    url: `${RoutDatamining}/service-centers/${data.id}/completed-services/expanded`,
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 签约服务的完成量走势
export function getTrendOfServices (data) {
  return request({
    url: `${RoutDatamining}/service-centers/${data.id}/trend-of-services`,
    method: 'GET',
    params: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}

// 存储容量概览：累计存储量、文档总数、剩余存储量占比
export function getStorageOverview (id) {
  return request({
    url: `${RoutDatamining}/service-centers/${id}/storage-overview`,
    method: 'GET',
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
