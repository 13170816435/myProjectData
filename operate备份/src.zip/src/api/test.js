import request from '@/utils/request'
// const barse = 'http://192.168.1.207:9020'
import request from '@/utils/request'
import qs from 'qs'
// const barse = 'http://192.168.1.207:9020'
const RoutBaseUrl = '/api-cloudpacs'
// 首页顶端数据统计
// export function getHomeReqData (data) {
//   return request({
//     url: '/Common/GetDataDicInfo',
//     method: 'get',
//     params: data
//     // baseURL: barse
//   })
// }
// 检查类型列表 /DataDicDefine
export function getHomeReqData (data) {
  return request({
    url: RoutBaseUrl + '/Config/DicDefine',
    method: 'GET',
    params: data
    // baseURL: barse
  })
}