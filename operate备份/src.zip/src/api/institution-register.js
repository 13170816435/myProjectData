import request from '@/utils/request'

const service = '/api-operate'

/**
 * 机构注册 - 新增通道
 * @param data
 * @returns {*}
 */
export const addChannel = data => request({
  url: `${service}/institution-register/channel/add`,
  method: 'POST',
  data
})

/**
 * 机构注册 - 查询
 * @returns {*}
 */
export const getChannelList = () => request({
  url: `${service}/institution-register/channels/tenancy-side`
})

/**
 * 机构注册 - 编辑
 * @param data
 * @returns {*}
 */
export const editChannel = data => request({
  url: `${service}/institution-register/channel/edit/tenancy-side`,
  method: 'POST',
  data
})

export const deleteChannel = data => request({
  url: `${service}/institution-register/channel/delete/tenancy-side`,
  method: 'POST',
  data
})

export const getInstRegisterCount = () => request.get(`${service}//institution-register/apply/count`)


export const getApplyInstList = params => request.get(`${service}/institution-register/apply-page/tenancy-side`, {
  params
})

export const getPermissionGroupLite = params => request.get(`${service}/authority-groups/simple/list`, {params})

export const getPermissionGroupList = params => request.get(`${service}/institution-register/business-system/authority-groups`, {params})

export const getRegisterApplyInfo = params => request.get(`${service}/institution-register/apply/detail`, {params})

export const auditRegisterApply = data => request.post(`${service}/institution-register/apply/audit`, data)
