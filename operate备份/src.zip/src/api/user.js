import request from '@/utils/request'
// import qs from 'qs'
const fileName = '/api-operate'
// const abilityUrl = '/api-ability'
// 新增用户
export function addUser (params) {
  return request({
    url: fileName + '/users',
    method: 'post',
    data: params
  })
}
// 获取用户列表
export function getUserList (parmas) {
  return request({
    url: fileName + '/users?' + parmas, // url：'/users' + params
    method: 'get'
  })
}
// 获取用户详情
export function getUserinfoByid (id) {
  return request({
    url: fileName + `/users/${id}`,
    method: 'get'
  })
}
// 通过手机号码 获取用户详情
export function getUserinfoByPhone (data) {
  return request({
    url: fileName + '/users/business-system-user',
    method: 'get',
    params: data,
  })
}
// 删除用户所属业务系统
export function beganDeleteCenterUser (params) {
  return request({
    url: fileName + '/users/business/system/delete',
    method: 'post',
    data: params
  })
}
// 添加用户所属业务系统
export function addCenterUser (params) {
  return request({
    url: fileName + '/users/business/system',
    method: 'post',
    data: params
  })
}
// 获取ca类型
export function getCAType (id) {
  return request({
    // url: fileName + '/common-settings/tenancy/detail?tenancy_id=' + id + '&config_type=30',
    url: fileName + '/common-settings/tenancy/detail?tenancy_id=' + id + '&config_type=30',
    method: 'get'
  })
}
// CA证书绑定/api/ca-certificates
export function bindCACertificate (params) {
  return request({
    url: fileName + '/ca-certificates',
    method: 'post',
    data: params
  })
}
// 证书新绑定接口
export function userBindCACertificate (params) {
  return request({
    url: fileName + '/ca-certificates/user-bind',
    method: 'post',
    data: params
  })
}

// CA证书解绑
export function delCACertificate (params) {
  return request({
    url: fileName + '/ca-certificates/delete',
    method: 'post',
    data: params
  })
}
// CA证书解绑新接口
export function unbindCACertificate (params) {
  return request({
    url: fileName + '/ca-certificates/user-unbind',
    method: 'post',
    data: params
  })
}
// 修改用户状态 （冻结、解冻）
export function putUserState (params) {
  return request({
    url: fileName + `/users/${params.id}/state/update`,
    method: 'post',
    data: params
  })
}
// 修改用户详情
export function putUserinfo (id, params) {
  return request({
    url: fileName + `/users/${id}/update`,
    method: 'post',
    data: params
  })
}
// 导入用户
export function importUser (params) {
  return request({
    url: fileName + '/users/import-doctor',
    method: 'post',
    data: params
  })
}
// 导入ca
export function importCa (params) {
  return request({
    url: fileName + '/ca-certificates/import',
    method: 'post',
    data: params
  })
}
// 获取权限列表
export function getAuthorityList (params) {
  return request({
    url: fileName + '/systems/authority',
    method: 'get'
  })
}
// 获取权限--用户组
export function getAuthorityUserGroupsList (params) {
  return request({
    url: fileName + '/authority-groups?limit=' + params,
    method: 'get'
  })
}
// 获取平台运营里面 的权限列表
export function getOperateAuthorityList () {
  return request({
    url: fileName + '/authority-groups/operation',
    method: 'get'
  })
}
// 获取系统列表
export function getServiceListlite () {
  return request({
    url: fileName + '/systems/lite?type=1',
    method: 'GET'
  })
}
// 获取云pacs对应的业务系统列表
export function getSystemsList () {
  return request({
    url: fileName + '/tenancies/business-systems',
    method: 'GET'
  })
}
// 获取菜单权限
export function getaAthorityGroups (id) {
  return request({
    url: fileName + '/authority-groups/system?id=' + id,
    method: 'GET'
  })
}
// 获取客户权限（操作）列表
export function getaAthorityTenancy () {
  return request({
    url: fileName + '/authority-groups/tenancy',
    method: 'GET'
  })
}
// 获取权限列表
export function getServiceCenterPower (params) {
  return request({
    url: fileName + '/authority-groups/service-center',
    method: 'GET',
    data: params
  })
}
// 新增用户组（权限组）
export function addAuthorityGroups (params) {
  return request({
    url: fileName + '/authority-groups',
    method: 'post',
    data: params
  })
}
// 查看用户组（权限组）
// export function getAuthorityGroupsinfoByid (id, Sid) {
//   var _sid = Sid ? '&system_id=' + Sid : ''
//   return request({
//     url: fileName + '/authority-groups/detail?id=' + id + _sid,
//     method: 'get'
//   })
// }
// 删除用户组
export function delAuthorityGroup (params) {
  return request({
    url: fileName + '/authority-groups/delete',
    method: 'post',
    data: params
  })
}
// 新增用户权限关系users/authority-group
export function addUsersAuthorityGroup (params) {
  return request({
    url: fileName + '/users/authority-group',
    method: 'POST',
    data: params
  })
}
// 解除用户关系 /api/users/{principal_id}/family/{id}
export function delAuthorityuserlist (params) {
  return request({
    url: fileName + '/users/authority-group/delete',
    method: 'post',
    data: params
  })
}
// 查看（权限）用户列表
export function getAuthorityUserlist (parmas) {
  return request({
    url: fileName + '/authority-groups/user?' + parmas, // url：'/users' + params
    method: 'get'
  })
}
// 删除用户
export function deleteOperateUser (data) {
  return request({
    url: fileName + '/users/delete',
    method: 'post',
    data: data
  })
}
// 删除运维用户用户
export function deleteThisOperationUser (data) {
  return request({
    url: fileName + '/users/operations/delete',
    method: 'post',
    data: data
  })
}
// 获取未加入权限成员列表
export function getUnAuthorityUserlist (parmas) {
  return request({
    url: fileName + '/authority-groups/members/not-joined?' + parmas, // url：'/users' + params
    method: 'get'
  })
}
// 获取未加入权限的  运维成员列表
export function getUnAuthorityOperationUserlist (parmas) {
  return request({
    url: fileName + '/authority-groups/operations/not-joined?'+ parmas,
    method: 'get'
  })
}
// 修改用户密码
export function updateuserpassword (params) {
  return request({
    url: fileName + '/users/password/update', // url：'/users' + params
    method: 'post',
    data: params
  })
}
// 设置新密码
export function setNewPassword (params) {
  return request({
    url: fileName + '/users/mobile/password/update', // url：'/users' + params
    method: 'post',
    data: params
  })
}
// 获取运维用户列表
export function getUsersOperations (parmas) {
  return request({
    url: fileName + '/users/operations?' + parmas, // url：'/users' + params
    method: 'get'
  })
}
// 客户管理--用户列表
// 用户列表
export function getTancyUserList (data) {
  return request({
    url: fileName + '/users' + data,
    method: 'get'
  })
}
// 平台运营--用户列表
// 用户列表
export function getCustomerUserList (data) {
  return request({
    url: fileName + '/users/from-all-tenancies' + data,
    method: 'get'
  })
}
// 用户详情
export function getCustomerUserInfo (id) {
  return request({
    url: fileName + '/users/from-all-tenancy/detail?id=' + id,
    method: 'get'
  })
}
// 用户详情
export function getOperationUserDetailByPhone (data) {
  return request({
    url: fileName + '/users/from-all-tenancy/detail',
    method: 'get',
    params: data
  })
}
// 重置密码
export function reSetPwd (id, data) {
  return request({
    url: fileName + `/users/${id}/reset-password/update`,
    method: 'post',
    data: data
  })
}
// 解锁
export function unLock (data) {
  return request({
    url: fileName + '/users/unlock/update',
    method: 'post',
    data: data
  })
}
// 修改用户状态
export function changeUserState (data) {
  return request({
    url: fileName + '/users/from-all-tenancy/state/update',
    method: 'post',
    data: data
  })
}
// 修改ca状态
export function changeCaState (data) {
  return request({
    url: fileName + '/ca-certificates/enable-state/update',
    method: 'post',
    data: data
  })
}
// 开启 CA 临时关闭
export function sureTemporarilyCloseState (data) {
  return request({
    url: fileName + '/ca-certificates/temporarily-close-state/update',
    method: 'post',
    data: data
  })
}
// 刑侦调阅-------------------
// 添加用户
export function addCriminalUser (data) {
  return request({
    url: fileName + '/users/image-criminal',
    method: 'POST',
    data: data
  })
}
// 编辑用户(可能平台运营那里用到这个api)
export function putCriminalUser (data) {
  return request({
    url: fileName + '/users/image-criminal/update',
    method: 'post',
    data: data
  })
}
// 用户详情 （客户管理-> 刑侦调阅-> 用户管理）
export function getCustomerUserDetail (id) {
  return request({
    url: fileName + `/users/${id}`,
    method: 'get'
  })
}
// 删除用户头像
export function delUserAvatar (params) {
  return request({
    url: fileName + '/users/avatar/delete',
    method: 'post',
    data: params
  })
}
// 删除用户签名
export function delUserSignature (params) {
  return request({
    url: fileName + '/users/signature/delete',
    method: 'post',
    data: params
  })
}
// 编辑屏保
export function putScreensaver (data) {
  return request({
    url: fileName + '/users/screensaver/update',
    method: 'post',
    data: data
  })
}

// 获取用户拥有的菜单
export function getUsualMenu (data) {
  return request({
    url: fileName + '/users/usual-menu',
    method: 'get',
    params: data
  })
}

// 保存用户拥有的菜单
export function postUsualMenu (data) {
  return request({
    url: fileName + '/users/usual-menu',
    method: 'post',
    data: data
  })
}
// 获取电子签名的唯一标识
export function getMobileCaId (data) {
  return request({
    url: fileName + '/common/ca/doctors/info',
    method: 'get',
    params: data
  })
}
// 修改双因子状态
export function changeFactoAuthState (data) {
  return request({
    url: fileName + '/users/two-factor-auth-state/update',
    method: 'post',
    data: data
  })
}
// 验证工号是否存在
export function checkUserWorkNo (data) {
  return request({
    url: fileName + '/users/check/workno',
    method: 'get',
    params: data
  })
}
// 保存用户拥有的菜单
export function getActivationCaCode (data) {
  return request({
    url: fileName + '/common/ca/doctors/active',
    method: 'post',
    data: data
  })
}
// 将医生的手写签名统一 换成ca厂商的图片
export function synchronousMoreUserCaImg (params) {
  return request({
    url: fileName + '/users/signature/update',
    method: 'post',
    data: params
  })
}
// 获取某个用户的ca 签章图片
export function getUserCaSeals (data) {
  return request({
    url: fileName + '/common/ca/user-seals',
    method: 'get',
    params: data
  })
}
// 获取HIS 下的医生列表
export function getHisDoctorList (data) {
  return request({
    url: fileName + '/asis/his-doctor-list',
    method: 'get',
    params: data
  })
}
// 获取HIS 下的科室列表
export function getHisOfficeList (data) {
  return request({
    url: fileName + '/asis/his-dept-list',
    method: 'get',
    params: data
  })
}
// 同步HIS科室
export function syncHisOffice (params) {
  return request({
    url: fileName + '/offices/his',
    method: 'post',
    data: params
  })
}
// 同步HIS用户
export function syncHisUser (params) {
  return request({
    url: fileName + '/users/his',
    method: 'post',
    data: params
  })
}
//检查获取院内医生重复信息列表
export function doctorDuplicateList () {
  return request({
    url: fileName + '/asis/his-doctor-duplicate-list',
    method: 'get'
  })
}
// 平台运营
// 分页获取已绑定某个CA的用户列表
export function getBindOneCaUserList (data) {
  return request({
    url: fileName + '/ca-certificates/operate/bind-user-page/by-setting-id',
    method: 'get',
    params: data
  })
}
// 解绑 已绑定某个ca的用户
export function unBindCaUser (params) {
  return request({
    url: fileName + '/ca-certificates/operate/unbind/by-setting-id',
    method: 'post',
    data: params
  })
}
// 客户管理
// 获取某个客户 开通了哪些电子签名(ca)
export function getTenancyOpenCaList () {
  return request({
    url: fileName + '/common-settings/tenancy/ca-vendor',
    method: 'get',
  })
}
// 获取某个ca 绑定了多少用户
export function getTenancyCaUseCount (data) {
  return request({
    url: fileName + '/tenancies/ca/use/count',
    method: 'get',
    params: data
  })
}
// 获取某个客户 哪些电子签名(ca) 绑定了的和未绑定的
export function getTenancyCaBindStateList (data) {
  return request({
    url: fileName + '/ca-certificates/bind-state-list',
    method: 'get',
    params: data
  })
}

// 分页获取已绑定某个CA的用户列表
export function getBindOneCaUserListUnderTenancy (data) {
  return request({
    url: fileName + '/ca-certificates/tenancy/bind-user-page/by-setting-id',
    method: 'get',
    params: data
  })
}
// 解绑 已绑定某个客户下单的 某个ca的用户
export function unBindCaUserUnderTenancy (params) {
  return request({
    url: fileName + '/ca-certificates/tenancy/unbind/by-setting-id',
    method: 'post',
    data: params
  })
}
// 获取已绑定ca 的 用户列表
export function getBindUserList (data) {
  return request({
    url: fileName + '/ca-certificates/bind-user-page',
    method: 'get',
    params: data
  })
}
// 获取未绑定ca 的 用户列表
export function getUnBindUserList (data) {
  return request({
    url: fileName + '/ca-certificates/unbind-user-page',
    method: 'get',
    params: data
  })
}
// 用户组新接口
// 获取菜单权限
export function getAuthorityMenuApi (params) {
  return request({
    url: fileName + '/menus/system/tree',
    method: 'GET',
    params
  })
}
// 查看用户组（权限组）
export function getAuthorityGroupsinfoByid (params) {
  return request({
    url: fileName + '/authority-groups/detail',
    method: 'get',
    params
  })
}
// 编辑用户组（权限组）
export function putAuthorityGroupsinfo (params) {
  return request({
    url: fileName + `/authority-groups/${params.id}/update`,
    method: 'post',
    data: params
  })
}
// 用户组新接口 结束