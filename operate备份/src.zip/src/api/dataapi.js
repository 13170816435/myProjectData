// 大数据api
import request from '@/utils/request'

/**
 * @return {*}
 */
export function dynamicInvoke(code, data = {}) {
  return request({
    url: `/api-imgbd/dataapi/dynamic/invoke?code=${code}`,
    method: 'post',
    data: data
  })
}
// 获取大屏 标题
export function getCurScreenTit(data = {}) {
  return request({
    url: '/api-imgbd/admin/Config/DicDefine',
    method: 'get',
    params: data
  })
}
// 修改大屏标题
export function updateCurScreenTit(data = {}) {
  return request({
    url: '/api-imgbd/admin/Config/DicDefine/Update',
    method: 'post',
    data: data
  })
}
// 新增大屏标题
export function addScreenTit(data = {}) {
  return request({
    url: '/api-imgbd/admin/Config/DicDefine',
    method: 'post',
    data: data
  })
}