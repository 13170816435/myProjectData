import request from '@/utils/request'
import qs from 'qs'
import { _ } from 'core-js'
const fileName = '/api-operate'
const RoutBaseUrl = '/api-cloudpacs'
const archivesUrl = '/api-archive'
const teachUrl = '/api-teaching'
// 获取菜单
export function ownMenu () {
  return request({
    url: fileName + '/users/own-menu',
    method: 'GET'
  })
}
// 获取用户登录的信息
export function getLoginUserInfor () {
  return request({
    url: fileName + '/users/identity',
    method: 'GET'
  })
}
// 获取系统id
export function fetchSystemIds () {
  return request({
    url: '/api-operate/users/pacs-systems',
    method: 'GET'
  })
}
// 获取雪花id
export function fetchSnowId () {
  return request({
    url: '/api-telemed/ids',
    method: 'GET'
  })
}
// 科室管理员--获取科室id
export function PacsSystemId () {
  return request({
    url: '/api-operate/users/system-detail',
    method: 'GET'
  })
}
// 获取基础（search）数据--枚举
export function getConstants () {
  return request({
    url: fileName + '/constants/enumerations',
    method: 'get'
  })
}
// 根据类型请求字典数据dist-----------------------
export function getDistinfoByType (url) {
  return request({
    url: fileName + url, // /dict/${_parmas}
    method: 'get'
  })
}
// 获取城市联动json
export function getCityJson (parmas) {
  return request({
    url: fileName + '/regions?parent_code=' + parmas.parent_code + '&level=' + parmas.level,
    method: 'get'
  })
}
// 新增行政区
export function addAdministrativeRegion (data) {
  return request({
    url: fileName + '/regions',
    method: 'post',
    data: data
  })
}
// 编辑行政区
export function updateAdministrativeRegion (data) {
  return request({
    url: fileName + `/regions/${data.id}/update`,
    method: 'post',
    data: data
  })
}
// 删除 行政区
export function DeleteAdministrativeRegion (id) {
  return request({
    url: fileName + `/regions/${id}/delete`,
    method: 'post',
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 获取字典类型
export function getDataDictionaryType (data) {
  return request({
    url: fileName + '/dict/types',
    method: 'GET',
    params: data
  })
}
// 新增字典类型
export function addDataDictionaryType (data) {
  return request({
    url: fileName + '/dict/types',
    method: 'post',
    data: data
  })
}
// 编辑字典类型
export function updateDataDictionaryType (data) {
  return request({
    url: fileName + '/dict/types/update',
    method: 'post',
    data: data
  })
}
// 删除 字典类型
export function DeleteDataDictionaryType (param) {
  return request({
    url: fileName + `/dict/types/${param.lookup_key}/delete`,
    method: 'post',
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 获取字典信息列表
export function getDictInforList (data) {
  return request({
    url: fileName + '/dict',
    method: 'GET',
    params: data
  })
}
// 新增字典信息
export function beganAddDictInfor (data) {
  return request({
    url: fileName + '/dict',
    method: 'post',
    data: data
  })
}
// 编辑字典信息
export function updateDictInfor (data) {
  return request({
    url: fileName + '/dict/update',
    method: 'post',
    data: data
  })
}
// 删除 字典信息
export function DeleteThisDictInfor (param) {
  return request({
    url: fileName + `/dict/${param.lookup_key}/${param.dic_code}/delete`,
    method: 'post',
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 删除已上传资料
export function deleteLoadFile (data) {
  return request({
    url: archivesUrl + '/Documents/update-tag',
    method: 'post',
    data: data
  })
}
// 上传媒体资料的接口
export function uploadMediaFile (data,paramUrl,Fn) {
  return request({
    url: archivesUrl + '/upload/crm?'+paramUrl,
    //url: '/api-document/upload/crm?'+paramUrl,
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    method: 'post',
    data: data,
    onUploadProgress:Fn
    // baseURL: barse
  })
}
// 上传媒体资料的接口
export function uploadMedia (data) {
  return request({
    url: fileName + '/medias',
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    method: 'post',
    data: data
    // baseURL: barse
  })
}
// 获取api权限信息
export function getProtectedResources () {
  return request({
    url: fileName + '/commons/protected-resources',
    method: 'GET'
  })
}
// 获取业务类型
export function getBusinessType () {
  return request({
    url: fileName + '/commons/business/type',
    method: 'GET'
  })
}
// 获取业务类型 （客户管理）
export function getTenanciesBusinessType () {
  return request({
    url: fileName + '/tenancies/business/type',
    method: 'GET'
  })
}
// 媒体图片下载 （获取图片路径）
export function getImgSrcById (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + `/medias/${id}`,
    method: 'GET'
    // params: data
  })
  // return configUrl.apiUrl + `/api-operate/medias/${id}`
}
// 获取图片信息----------------------------------------------------------------
// 用户logo
export function getUserLogo (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/users/avatar?id=' + id,
    method: 'GET'
  })
}
// 手写签名
export function getSignature (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/users/signature?id=' + id,
    method: 'GET'
  })
}
// 租户(平台)logo
export function getTenanciesLogo (id, tid) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/tenancies/logo?id=' + id + '&tenancy_id=' + tid,
    method: 'GET'
  })
}
// 租户App logo
export function getTenanciesAppLogo (id, tid) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/tenancies/App/logo?id=' + id + '&tenancy_id=' + tid,
    method: 'GET'
  })
}
// 租户移动端banner
export function getTenanciesBanner (id, tid) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/tenancies/banner?id=' + id + '&tenancy_id=' + tid,
    method: 'GET'
  })
}
// 产品管理上传icon /api/software-products/icon
export function getProductsIcon (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/software-products/icon?id=' + id,
    method: 'GET'
  })
}
// 获取机构logo
export function getInstituteLogo (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/institutions/logo?id=' + id,
    method: 'GET'
  })
}
// 获取机构宣传图
export function getPropaganda (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/institutions/propaganda?id=' + id,
    method: 'GET'
  })
}
// 获取执照许可证照片
export function getLicense (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/institutions/license?id=' + id,
    method: 'GET'
  })
}
// 服务中心--宣传图
export function getServiceAdervise (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + `/service-centers/${id}/advertise`,
    method: 'GET'
  })
}
// 获取机构资质
export function getQualification (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/institutions/qualification?id=' + id,
    method: 'GET'
  })
}
// 获取等级证书
export function getLevelCertificate (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/institutions/level-certificate?id=' + id,
    method: 'GET'
  })
}
// 获取放射诊疗
export function getRadiologyLicense (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/institutions/radiology-license?id=' + id,
    method: 'GET'
  })
}


// 服务中心--banner图
export function getServiceBanner (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + `/service-centers/${id}/banner`,
    method: 'GET'
  })
}
// 服务中心--logo
export function getServiceLogo (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + `/service-centers/${id}/logo`,
    method: 'GET'
  })
}
// 获取图片信息-----------------------------------------------------------------
// 删除媒体文件
export function stopServiceCooperation (data) {
  return request({
    url: fileName + `/medias/${data.id}`,
    method: 'DELETE',
    data: data,
    paramsSerializer: data => {
      return qs.stringify(data, { indices: false })
    }
  })
}
// 获取机构列表精简信息
export function getInstitutionListLite (data) {
  return request({
    url: fileName + '/institutions/lite',
    method: 'get',
    params: data,
  })
}

// 获取科室列表精简信息
export function getOfficesLite (url) {
  return request({
    url: fileName + url, // url '/offices/lite?params'
    method: 'get'
  })
}
// 根据电话获取姓名，工号等
export function getLoginName (url) {
  return request({
    url: fileName + url,
    method: 'get'
  })
}
// 获取文案code
export function getDefinition () {
  return request({
    url: fileName + '/official-documents/type-definitions',
    method: 'get'
  })
}
// 获取文案详情 /api/official-documents/{code}
export function getDefinitioninfo (code) {
  return request({
    url: fileName + `/official-documents/${code}`,
    method: 'get'
  })
}
// 获取网站名称
export function getThisPlatformName () {
  return request({
    url: fileName + '/tenancies/basis-info/lite',
    method: 'get'
  })
}
// 获取配置项
export function getConfigurations (params) {
  return request({
    url: fileName + '/configurations?key=' + params,
    method: 'get'
  })
}
// 服务工单
// 添加服务工单
export function addServiceOrder (data) {
  return request({
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    url: fileName + '/service-orders',
    method: 'post',
    data: data
  })
}
// 修改服务工单
export function updateServiceOrder (data) {
  return request({
    url: fileName + '/service-orders/update',
    method: 'post',
    data: data
  })
}
// 获取服务工单列表
export function getServiceOrderList (data) {
  return request({
    url: fileName + '/service-orders',
    method: 'get',
    params: data
  })
}
//获取服务工单详情
export function getServiceOrderDetail (data) {
  return request({
    url: fileName + '/service-orders/detail',
    method: 'get',
    params: data
  })
}
// 获取服务工单全部详情
export function getServiceOrderAllDetail (data) {
  return request({
    url: fileName + '/service-orders/complete-detail',
    method: 'get',
    params: data
  })
}
// 评价工单
export function evaluationOrder (data) {
  return request({
    url: fileName + '/service-orders/evaluation',
    method: 'post',
    data: data
  })
}
// 指派工单
export function readyAssignEngineer (data) {
  return request({
    url: fileName + '/service-orders/assign-engineer',
    method: 'post',
    data: data
  })
}
// 修改服务工单状态
export function updateServiceOrderState (data) {
  return request({
    url: fileName + '/service-orders/state/update',
    method: 'post',
    data: data
  })
}
// 获取服务工单图片
export function getServiceOrderImg (data) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/service-orders/image',
    method: 'get',
    params: data
  })
}
// 获取服务工单状态统计
export function getstateStatistics (data) {
  return request({
    url: fileName + '/service-orders/state-statistics' + data,
    method: 'get'
  })
}
// 获取服务工单业务系统
export function getOrderBusinessSystem (data) {
  return request({
    url: fileName + '/service-orders/business-system',
    method: 'get',
    params: data
  })
}
// 获取服务工单业务系统
export function getOrderBusinessSystemAll (data) {
  return request({
    url: fileName + '/service-orders/business-system/all',
    method: 'get',
    params: data
  })
}
// 获取当前客户的工作台数据集
export function getTenancyStatistics (data) {
  return request({
    url: fileName + '/tenancies/dashboard',
    method: 'get',
    params: data
  })
}
// 获取平台运营的工作台数据集
export function getOperateStatistics (data) {
  return request({
    url: fileName + '/operates/dashboard',
    method: 'get'
  })
}
// 获取平台运营的设备统计
export function getOperateEquipmentStatistics (data) {
  return request({
    url: fileName + '/operates/equipment/dashboard',
    method: 'get'
  })
}
// 校验密码
export function checkPassword (params) {
  return request({
    url: RoutBaseUrl + '/Common/CheckPassword',
    method: 'post',
    data: params
  })
}
// 获取屏保时间
export function getScreensaverTime (data) {
  return request({
    url: fileName + '/users/screensaver',
    method: 'get'
  })
}
 // 获取影像存档配置基本信息
export function getBasicParams (data) {
  return request({
    url: archivesUrl + '/param/basic',
    method: 'get',
    data: data
  })
}
// 保存影像存档配置信息
export function saveBasicParams (data) {
  return request({
    url: archivesUrl + '/param/basic',
    method: 'put',
    data: data
  })
}
// 更新教学用户信息
export function updateTeachUserInfor (data) {
  return request({
    url: teachUrl + `/teach-user/${data.user_id}/base/update`,
    method: 'post',
    data: data
  })
}
// 获取当前客户类型
export function getCurTenancyType (data) {
  return request({
    url: fileName + `/tenancies/${data.tenancy_id}/type`,
    method: 'get'
  })
}
// 通过document_id 调用曹磊的接口来获取图片
export function getUploadImg (data) {
  return request({
    responseType: 'arraybuffer',
    url: archivesUrl + '/download/crm-document-id',
    method: 'GET',
    params: data
  })
}
// 获取自定义名称
export function getCustomerName () {
  return request({
    url: fileName + '/operates/customer-name',
    method: 'GET',
  })
}
// 获取UDI详情
export function getUdiDetail (data) {
  return request({
    url: fileName + '/operates/about-system-settings',
    method: 'get',
    params: data
  })
}
// 保存UDI 配置
export function saveUdiSet (params) {
  return request({
    url: fileName + '/operates/about-system-settings',
    method: 'post',
    data: params
  })
}