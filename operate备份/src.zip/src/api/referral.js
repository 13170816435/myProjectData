import request from '@/utils/request'
import qs from 'qs'
const RoutBaseUrl = '/api-operate'
const medRoutBaseUrl = '/api-telemed'
const idcasRoutBaseUrl = '/api-archive'  // 之前是api-idcas
// 获取城市联动json
export function getCityJson (parmas) {
  return request({
    url: RoutBaseUrl + '/regions?parent_code=' + parmas.parent_code + '&level=' + parmas.level,
    method: 'get'
  })
}
// 获取数据字典--远程医疗 ConsultKind-会诊类型 ConsultClass-会诊方式 SexType-性别 MaritalStatus-婚姻状况 IdCardType-证件类型 ConsultState-会诊状态
export function getMedDict (id) {
  return request({
    url: RoutBaseUrl + `/consultations/dics/${id}`,
    method: 'get'
  })
}
// 获取数据字典--机构
export function getDict (data) {
  return request({
    url: RoutBaseUrl + `/dict/${data.lookup_key}`,
    method: 'get',
    params: data
  })
}
// 获取科室
export function getOffices (data) {
  return request({
    url: RoutBaseUrl + '/offices/lite',
    method: 'GET',
    params: data
  })
}
// 获取转往医生
export function getDoctor (data) {
  return request({
    url: RoutBaseUrl + '/users/lite',
    method: 'GET',
    params: data
  })
}
// 转诊申请
export function referralApply (data) {
  return request({
    url: medRoutBaseUrl + '/referrals',
    method: 'post',
    data: data
  })
}
// 转诊编辑
export function edit (data) {
  return request({
    url: medRoutBaseUrl + `/referrals/${data.id}`,
    method: 'put',
    data: data
  })
}
// 获取转诊列表
export function getReferralsList (data) {
  return request({
    url: medRoutBaseUrl + '/referrals',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 获取业务资料
export function getDicItems (data) {
  return request({
    url: medRoutBaseUrl + '/docitems',
    method: 'GET',
    params: data
  })
}
// 获取已上传资料
export function getLoadFile (data) {
  return request({
    url: idcasRoutBaseUrl + '/Documents/by-business',
    method: 'get',
    params: data
  })
}
// 获取历史业务资料文档记录
// export function getHistory (data) {
//   return request({
//     url: medRoutBaseUrl + '/docitems/history',
//     method: 'get',
//     params: data
//   })
// }
// 获取转往机构
export function getInstitue () {
  return request({
    url: medRoutBaseUrl + '/referrals/institutions',
    method: 'GET'
    // params: data
  })
}
// 取消转诊
export function cancelReferra (data) {
  return request({
    url: medRoutBaseUrl + `/referrals/${data.id}/cancel`,
    method: 'post',
    data: data
  })
}
// 获取转诊详情
export function getReferralDetail (id) {
  return request({
    url: medRoutBaseUrl + `/referrals/${id}`,
    method: 'GET'
    // params: data
  })
}
// 获取匿名转诊详情
export function getReferralAnonymousDetail (id) {
  return request({
    url: medRoutBaseUrl + `/referrals/${id}/anonymous`,
    method: 'GET'
    // params: data
  })
}
// 转诊统计
export function total (data) {
  return request({
    url: medRoutBaseUrl + '/referrals/total',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}
// 驳回审核
export function refuseOrAgreeCheck (data) {
  return request({
    url: medRoutBaseUrl + `/referrals/${data.id}/audit`,
    method: 'post',
    data: data
  })
}
// 转诊受理
export function referralAcceptance (data) {
  return request({
    url: medRoutBaseUrl + `/referrals/${data.id}/acceptance`,
    method: 'post',
    data: data
  })
}
// 患者履约
export function referralPerformance (data) {
  return request({
    url: medRoutBaseUrl + `/referrals/${data.id}/performance`,
    method: 'post',
    data: data
  })
}
// 患者爽约
export function referralMiss (data) {
  return request({
    url: medRoutBaseUrl + `/referrals/${data.id}/miss`,
    method: 'post',
    data: data
  })
}
// 获取转诊过程
export function processes (data) {
  return request({
    url: medRoutBaseUrl + `/referrals/${data.id}/processes`,
    method: 'get',
    params: data
  })
}
// 获取转诊过程时间轴列表
export function referralProcessList (data) {
  return request({
    url: medRoutBaseUrl + `/referrals/${data.id}/referral-process-list`,
    method: 'get',
    params: data
  })
}
// 获取业务id 比如服务中心id
export function getSystemId (data) {
  return request({
    url: medRoutBaseUrl + `/referrals/${data.id}/${data.referralTarget}/systemid`,
    method: 'get',
    params: data
  })
}
// 江西儿童医院
// 转诊申请
export function childrenReferralApply (data) {
  return request({
    url: medRoutBaseUrl + '/third-referrals/apply',
    method: 'post',
    data: data
  })
}
// 获取出诊科室列表
export function getOutCallOfficeList (data) {
  return request({
    url: medRoutBaseUrl + '/third-referrals/department-schedule',
    method: 'get',
    params: data
  })
}
// 获取排班信息
export function getScheduleInfo (data) {
  return request({
    url: medRoutBaseUrl + '/third-referrals/schedule-info',
    method: 'get',
    params: data
  })
}
// 获取排班号源
export function getTimeReg (data) {
  return request({
    url: medRoutBaseUrl + '/third-referrals/time-reg',
    method: 'get',
    params: data
  })
}
// 挂号锁号
export function lockSource (data) {
  return request({
    url: medRoutBaseUrl + '/third-referrals/lock',
    method: 'post',
    data: data
  })
}
// 挂号解锁
export function unlockSource (data) {
  return request({
    url: medRoutBaseUrl + '/third-referrals/unlock',
    method: 'post',
    data: data
  })
}
// 获取转诊成功后的二维码
export function getReferralsCode (data) {
  return request({
    url: medRoutBaseUrl + `/third-referrals/qr-code/${data.pixel}`,
    method: 'get',
    params: data,
    responseType: 'arraybuffer'
  })
}
// 获取转诊模式
export function getReferralMode () {
  return request({
    url: medRoutBaseUrl + '/third-referrals/mode',
    method: 'get',
    // params: data
  })
}