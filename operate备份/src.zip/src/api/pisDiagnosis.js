import request from '@/utils/request'
import qs from 'qs'
const medRoutBaseUrl = '/api-telemed'

// 获取枚举列表
export function whcEnums (names) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/enums',
    method: 'get',
    params: names,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 病理诊断申请
export function whcPostApply (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis',
    method: 'post',
    data: data
  })
}

// 病理诊断编辑
export function whcPutApply (data) {
  return request({
    url: `${medRoutBaseUrl}/whc-pis-diagnosis/${data.id}`,
    method: 'put',
    data: data
  })
}

// 病理诊断取消
export function whcPatchApply (data) {
  return request({
    url: `${medRoutBaseUrl}/whc-pis-diagnosis/${data.id}/cancel`,
    method: 'patch',
    data: data
  })
}

// 病理诊断详情
export function whcGetApply (id) {
  return request({
    url: `${medRoutBaseUrl}/whc-pis-diagnosis/${id}`,
    method: 'get'
  })
}

// 病理标本配送
export function whcSpecimenDistribute (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/specimen-distribute',
    method: 'post',
    data: data
  })
}

// 病理申请列表
export function whcApplice (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/applies',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取申请列表统计
export function whcAppliceStatistice (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/applies-statistice',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 病理诊断列表
export function whcDiagnoses (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/diagnoses',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 病理诊断列表统计
export function whcDiagnosesStatistice (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/diagnoses-statistice',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取签收列表
export function whcSignDiagnoses (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/sign-diagnoses',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 病理签收列表统计
export function whcSignStatistice (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/sign-statistice',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 匹配标本信息
export function whcMatchSpecimen (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/match-specimen',
    method: 'get',
    params: data
  })
}

// 标本签收
export function whcSignSpecimen (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/sign-specimen',
    method: 'post',
    data: data
  })
}

// 标本退回
export function whcBackSpecimen (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/back-specimen',
    method: 'post',
    data: data
  })
}

// 样本缺陷上报（不合格和标本化）
export function whcDefectReporting (data) {
  return request({
    url: medRoutBaseUrl + '/SampleQc/defect-reporting',
    method: 'post',
    data: data
  })
}

// 综合查询列表
export function integratedQuery (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/integrated-query',
    method: 'get',
    params: data,
    paramsSerializer: params => {
      return qs.stringify(params, { indices: false })
    }
  })
}

// 获取病理诊断标本配送图片
export function getSpecimenDistributeImage (id) {
  return request({
    url: medRoutBaseUrl + `/whc-pis-diagnosis/${id}/specimen-distribute-image`,
    method: 'get'
  })
}

// 获取病理诊断标本标签图片
export function getSpecimenImage (data) {
  return request({
    url: medRoutBaseUrl + `/whc-pis-diagnosis/${data.id}/${data.specimenId}/specimen-image`,
    method: 'get'
  })
}

// 获取病理诊断标本拒签图片
export function getSpecimenRefusalImage (id) {
  return request({
    url: medRoutBaseUrl + `/whc-pis-diagnosis/${id}/specimen-refusal-image`,
    method: 'get'
  })
}

// 获取病理诊断报告图片
export function getReportImage (data) {
  return request({
    url: medRoutBaseUrl + `/whc-pis-diagnosis/${data.id}/report-image`,
    method: 'get'
  })
}

// 获取病理诊断报告预览图片
export function getPreviewReportImage (data) {
  return request({
    url: medRoutBaseUrl + `/whc-pis-diagnosis/${data.id}/report-image/pre-view`,
    method: 'get'
  })
}

// 申请病理切片
export function postPisSlice (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/slice',
    method: 'post',
    data
  })
}

// 编辑病理切片
export function putPisSlice (data) {
  return request({
    url: medRoutBaseUrl + '/whc-pis-diagnosis/slice',
    method: 'put',
    data
  })
}

// 取消病理切片
export function deletePisSlice (data) {
  return request({
    url: medRoutBaseUrl + `/whc-pis-diagnosis/slice/${data.consult_id}/cancel`,
    method: 'put',
    data
  })
}

// 病理切片签名
export function postSignature (data) {
  return request({
    url: medRoutBaseUrl + `/whc-pis-diagnosis/slice/${data.consult_id}/signature`,
    method: 'post',
    data
  })
}
