// 系统通用业务相关
const state = {
  unreadMsgNum: 0, // 头部 聊天消息通知数量 
}
const mutations = {
  SET_UNREAD_MSG_NUM (state, data) {
    state.unreadMsgNum = data
  },
}
const actions = {
  setUnreadMsgNum ({ commit }, data) {
    commit('SET_UNREAD_MSG_NUM', data)
  },
}

export default {
  namespaced: true,
  state,
  actions,
  mutations
}
