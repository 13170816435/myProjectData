const state = {
    cardStyle: true,
    showMenuHeader:true,
  }
 
  const mutations = {
    SET_SHOWMENUHEADER: (state, cover) => {
      console.log('有变化吗？',cover);
      state.showMenuHeader = cover
    },
  
  }


  export default {
    namespaced: true,
    state,
    mutations
  }