const state = {
  currentPagePath: ''
}

const mutations = {
  SET_CURRENT_PAGE_PATH (state, payload) { // 设置当前页面path
    state.currentPagePath = payload
  }
}

export default {
  namespaced: true,
  state,
  mutations
}
