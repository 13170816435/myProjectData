const state = {
  isLockPage: sessionStorage.getItem('isLockPage') === 'true', // 是否锁屏
  lastTime: new Date().getTime() // 最后一次操作时间
}
const mutations = {
  SET_LOCK: (state, cover) => {
    state.isLockPage = true
    sessionStorage.setItem('isLockPage', state.isLockPage)
  },
  CLEAR_LOCK: (state, cover) => {
    state.isLockPage = false
    sessionStorage.removeItem('isLockPage')
  },
  PREVENT_REFRSH: (state, cover) => {
    state.isLockPage = cover
  },
  REFASH_TIME: (state, cover) => {
    state.lastTime = cover
  }
}
const actions = {
  setLock: ({ commit }, cover) => {
    console.log('setLock', cover)
    commit('SET_LOCK', cover)
  },
  clearLock: ({ commit }, args) => {
    commit('CLEAR_LOCK', args)
  },
  preventRefresh: ({ commit }, cover) => {
    commit('PREVENT_REFRSH', cover)
  },
  refashTime: ({ commit }, cover) => {
    commit('REFASH_TIME', cover)
  }
}
export default {
  namespaced: true,
  state,
  mutations,
  actions
}
