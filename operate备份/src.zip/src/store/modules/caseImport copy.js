import { getImportOutProgress,downImportInspect } from "@/api/platform_costomer/caseExport";
import moment from 'moment';
const state = {
  caseImportAlertShow: false,
  importOutProgressCount: 0,
  mergeTotalInspect: [],
  timeId: null,
  curImportId: '',
  moreImportObj: {} //
}

const mutations = {
  SET_ALERT_SHOW (state, payload) {
    state.caseImportAlertShow = payload
  },
  CLEAR_TIME_ID (state) {
    clearInterval(state.timeId)
    state.timeId = null
  },
  SET_PROGRESS_COUNT (state, payload) {
    state.importOutProgressCount = payload
  },
  SET_TOTAL_INSPECT (state, payload) {
    state.mergeTotalInspect = payload
  },
  // 点击合并时 重置合并参数
  RESET_IMPORT_OUT_PARAM (state, payload) {
    state.caseImportAlertShow = false
    state.importOutProgressCount = 0
    state.mergeTotalInspect = []
    if (state.timeId) {
      clearInterval(state.timeId)
    }
    state.timeId = null
  }
}

let i = 0
let totalDownLoadCount = 0
const actions = {
  pollingGetImportOutProgressRate({ commit, state },param) { // 轮询获取影像发送进度
    
    commit('SET_PROGRESS_COUNT', 0)
    //展示进度条
    commit('SET_ALERT_SHOW', true)
    if(state.timeId) { // 目前有进行中的定时任务
      commit('CLEAR_TIME_ID') // 清除定时器
    }else {
      let downFileFinish = false
      state.timeId = setInterval(async () => {
        if (!downFileFinish) {
          let res = await getImportOutProgress({key: param.key})
          let { code, data } = res
          if(code === 0) {
            
          //  let progress = Math.round(
          //   (data / param.total_count) * 100
          //   )
            let progress = 0// 
            totalDownLoadCount = totalDownLoadCount + data
            progress = (data / param.total_count);
            progress = parseFloat((progress * 100).toFixed(2));

            let reallyProgress = 0
            reallyProgress = (data / param.allTotalCount);
            reallyProgress = parseFloat((reallyProgress * 100).toFixed(2));

            console.log('progress',progress)
            if (totalDownLoadCount === param.allTotalCount) {// 所有批 都下载完成了
              console.log("触发了")
              // 因进度完成了还需要 下载压缩包 所以这里 延迟5s 显示进度完成(这样5s后刚好下载完了压缩包 相对看起来比较同步)
              setTimeout(() => {
                commit('SET_PROGRESS_COUNT', reallyProgress)
              },5000)
            } else {
              commit('SET_PROGRESS_COUNT', reallyProgress)
            }
            
          }
        
          if(data === param.total_count) { // 某一批下载完成了
            downFileFinish = true
          }
        } else {
          commit('CLEAR_TIME_ID') // 清除定时器

          if(totalDownLoadCount != param.allTotalCount) { // 没有全部下载完
            return false
          }

          // 下载完了 后端会返回文件流
          let result = await downImportInspect({key: param.key})
          console.log(result)
          if (result) {
            //let index = fileName.lastIndexOf('.')
            // 获取文件类型
            // let type = fileName.substring(index)
            let type = 'x-zip-compressed'
            const curTime = moment().format('YYYY-MM-DD HH:mm:ss')
            let fileName = '病例导出' + '_' + curTime
            let blob = new Blob([result], {
              //下载的文件类型；
              type: `application/${type}`
            })
            if (window.navigator.msSaveOrOpenBlob) {
                navigator.msSaveBlob(blob, fileName)
                navigator.msSaveBlob(blob)
            } else {
              var link = document.createElement('a')
              link.href = window.URL.createObjectURL(blob)
              link.download = fileName
              link.click()
              window.URL.revokeObjectURL(link.href) //释放内存
            }
          } else{
            //this.$message.error(res.msg)
          }
        }
      }, 3000)
    }
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}