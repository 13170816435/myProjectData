/*
set sidebar open or close,and some app setting
 */
const state = {
  opened: sessionStorage.getItem('open') ? sessionStorage.getItem('open') : 'false', // 侧边栏菜单时候收起
  ServiceCenterOpen: sessionStorage.getItem('ServiceCenterOpen') ? sessionStorage.getItem('ServiceCenterOpen') : 'false', // 侧边栏菜单时候收起
  tenancyInfo: {}, // 租户信息
  enumerations: {}, // 基础数据---------------------------------------------------------------
  officeType: [], // 科室类型
  tenancyType: [], // 租户（客户）类型
  tenancyState: [], // （客户）服务状态
  userAccountState: [], // 用户状态
  serviceList: [], // （客户）开通服务列表
  caStatelist: [], // cs状态
  userMuneList: [], // 菜单栏
  showuserMuneList: [], // 菜单栏
  smsProducer: [], // 短信
  meetingCompany: [], // 视频
  caProducer: [], // ca
  commonSettingtype: [], // 外部能力-tab列表
  caaccounttype: [], // ca——类型
  caType: [], // ca类型
  iframeUrl: '', // 嵌套的iframe 是src地址
  servicePushText: '', // 服务报告推送详情
  servicePushType: '', // 服务报告推送类型
  servicePushMethods: '', // 接受类型
  siteObj: {},  // 平台信息
  borwserTitObj: {
    platFormName: '',
    checkMemuname: ''
  },
  isSetUdi: '',
  tenancyParamArr: [], // 客户下的参数配置
  isShowManageBtn: true, // 是否显示 业务系统列表页面的"管理"按钮
  loginTokenInfo: {},
  isSaveParams: false,
}
const mutations = {
  SET_OPENED (state, payload) { // 菜单栏是否展开
    state.opened = String(payload)
    sessionStorage.setItem('open', payload)
  },
  setServiceCenter_open (state, payload) { // 菜单栏是否展开
    state.ServiceCenterOpen = String(payload)
    sessionStorage.setItem('ServiceCenterOpen', payload)
  },
  save_loginTokenInfo (state, payload) {
    state.loginTokenInfo = payload
  },
  set_officeType (state, payload) { // 科室类型
    state.officeType = payload
  },
  set_tenancyType (state, payload) { // 客户类型列表
    state.tenancyType = payload
  },
  set_tenancyState (state, payload) { // 客户状态
    state.tenancyState = payload
  },
  set_userAccountState (state, payload) { // 用户状态状态
    state.userAccountState = payload
  },
  set_serviceList (state, payload) { // 客户开通服务列表
    state.serviceList = payload
  },
  set_caStatelist (state, payload) { // ca证书状态
    state.caStatelist = payload
  },
  set_smsProducer (state, payload) { // 短信
    state.smsProducer = payload
  },
  set_meetingCompany (state, payload) { // 视频
    state.meetingCompany = payload
  },
  set_caProducer (state, payload) { // ca
    state.caProducer = payload
  },
  set_userMuneList (state, payload) {
    state.userMuneList = payload
  },
  set_showuserMuneList (state, payload) {
    state.showuserMuneList = payload
  },
  set_commonSettingtype (state, payload) {
    state.commonSettingtype = payload
  },
  set_caaccounttype (state, payload) {
    state.caaccounttype = payload
  },
  set_caType (satate, payload) {
    state.caType = payload
  },
  set_iframeUrl (state, payload) {
    state.iframeUrl = payload
  },
  set_servicePushText (state, payload) {
    state.servicePushText = payload
  },
  set_servicePushType (state, payload) {
    state.servicePushType = payload
  },
  set_servicePushMethods (state, payload) {
    state.servicePushMethods = payload
  },
  set_tenancyInfo (state, payload) {
    state.tenancyInfo = payload
  },
  set_enumerations (state, payload) {
    state.enumerations = payload
  },
  set_siteObj (state, payload) {
    state.siteObj = payload
  },
  set_PlatFormName (state, payload) { // 科室类型
    state.borwserTitObj.platFormName = payload
  },
  set_CheckMemuname (state, payload) {
    state.borwserTitObj.checkMemuname = payload
  },
  tenancyParamArr (state, payload) {
    state.tenancyParamArr = payload
  },
  set_udi(state, payload) {
    state.isSetUdi = payload
  },
  set_isShowManageBtn(state, payload) {
    state.isShowManageBtn = payload
  },
  set_isSaveParams(state, payload) {//平台运营->系统设置->参数设置 点击保存
    state.isSaveParams = payload
  },
}
// const actions = {
//   set_siteObj ({ commit, state }, payload) {
//     console.log(payload)
//     state.siteObj = payload
//   }
// }
export default {
  namespaced: true,
  state,
  mutations,
  // actions,
}
