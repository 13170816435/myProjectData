const state = {
  year: new Date().getFullYear()
}
export default {
  state
}
