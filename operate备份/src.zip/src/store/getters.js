const getters = {
  opened: state => {
    if (state.app.opened === 'false') {
      return false
    } else if (state.app.opened === 'true') {
      return true
    }
  },
  ServiceCenterOpen: state => {
    if (state.app.ServiceCenterOpen === 'false') {
      return false
    } else if (state.app.ServiceCenterOpen === 'true') {
      return true
    }
  },
  loginTokenInfo: state => state.app.loginTokenInfo,
  // 屏保
  isLockPage: state => state.lockPage.isLockPage,
  lastTime: state => state.lockPage.lastTime,
  borwserTitObj: state => {
    return state.app.borwserTitObj
  },
  usertype: state => {
    return state.app.usertype
  },
  userInfo: state => {
    return state.app.userInfo
  },
  officeType: state => {
    return state.app.officeType
  },
  tenancyType: state => {
    return state.app.tenancyType
  },
  userAccountState: state => {
    return state.app.userAccountState
  },
  tenancyState: state => {
    return state.app.tenancyState
  },
  serviceList: state => {
    return state.app.serviceList
  },
  caStatelist: state => {
    return state.app.caStatelist
  },
  userMuneList: state => {
    return state.app.userMuneList
  },
  showuserMuneList: state => {
    return state.app.showuserMuneList
  },
  smsProducer: state => {
    return state.app.smsProducer
  },
  meetingCompany: state => {
    return state.app.meetingCompany
  },
  caProducer: state => {
    return state.app.caProducer
  },
  commonSettingtype: state => {
    return state.app.commonSettingtype
  },
  caaccounttype: state => {
    return state.app.caaccounttype
  },
  caType: state => {
    return state.app.caType
  },
  iframeUrl: state => {
    return state.app.iframeUrl
  },
  servicePushText: state => {
    return state.app.servicePushText
  },
  servicePushType: state => {
    return state.app.servicePushType
  },
  servicePushMethods: state => {
    return state.app.servicePushMethods
  },
  tenancyInfo: state => {
    return state.app.tenancyInfo
  },
  currentPagePath: state => {
    return state.currentPage.currentPagePath
  },
  enumerations: state => {
    return state.app.enumerations
  },
  siteObj:state => {
    return state.app.siteObj
  },
  year: state => {
    return state.dataCockpit.year
  },
  isSetUdi: state => {
    return state.app.isSetUdi
  },
  isShowManageBtn: state => {
    return state.app.isShowManageBtn
  },
  isSaveParams: state => {
    return state.app.isSaveParams
  },
  cardStyle: state =>{
    // return false
    return state.dataStorage.cardStyle
  },
  showMenuHeader: state =>{
    // return false---是否被其他业务系统引用
    return state.dataStorage.showMenuHeader
  },
  // 病例导出
  caseImportAlertShow: state => {
    return state.caseImport.caseImportAlertShow
  },
  iframeCaseImportAlertShow: state => {// 云助手 进度页面展示
    return state.caseImport.iframeCaseImportAlertShow
  },
  importOutProgressCount: state => {
    return state.caseImport.importOutProgressCount
  },
  unreadMsgNum: state => state.bussinessCommon.unreadMsgNum,
}
export default getters
