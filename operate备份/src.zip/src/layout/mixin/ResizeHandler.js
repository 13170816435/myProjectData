import store from '@/store'

export default {
  mounted () {
    window.onresize = () => {
      return (() => {
        const WIDTH = document.body.clientWidth
        const opened = sessionStorage.getItem('open') ? sessionStorage.getItem('open') : 'false'

        if (WIDTH < 1280) {
          if (opened) {
            store.commit('app/SET_OPENED', true)
          }
        }
        // if (WIDTH > 1280) {
        //   if (opened) {
        //     store.commit('app/SET_OPENED', false)
        //   }
        // }
      })()
    }
  }
}
