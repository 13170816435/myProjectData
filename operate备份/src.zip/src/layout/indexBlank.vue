<template>
  <div>
    <router-view></router-view>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import ResizeMixin from './mixin/ResizeHandler'
import { getThisPlatformName } from '@/api/commonHttp'

export default {
  computed: {
    ...mapGetters(['opened'])
  },
  mixins: [ResizeMixin],
  data () {
    return {
    }
  },
  mounted() {
    //this.getPlatformName()
  },
  methods: {
    async getPlatformName () {
      const res = await getThisPlatformName()
      if (res.code === 0) {
        document.title = res.data.site_name
      }
    },
  }
}
</script>
<style lang="less" scoped>

</style>
