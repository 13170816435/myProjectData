<template>
  <div class="wrapper" :class="{ closeBar: opened }">
    <!-- <m-header v-show="showMenuHeader" @changeUserState="changeUserState"></m-header> -->
    <m-header v-if="showMenuHeader" @changeUserState="changeUserState" @openIm="openIm"></m-header>
    <div class="wrap_content" :class="!showMenuHeader ? 'wrap_content_0' : ''">
      <!-- <silder-bar v-show="showMenuHeader"></silder-bar> --> 
      <!--用v-show时 内容管理被存储共享那边嵌套时会用她那边的token 获取菜单然后默认跳转到菜单的第一项--->
      <silder-bar v-if="showMenuHeader"></silder-bar>
      <main-content></main-content>
    </div>

    <ImChat ref="ImChat" v-show="IMWindowVisible" :IMWindowVisible.sync="IMWindowVisible"></ImChat>
  </div>
</template>
<script>
import MHeader from './components/header'
import ImChat from '@/components/common/IM/components/chat'
import SilderBar from './components/sideBar'
import MainContent from './components/mainContent'
import { mapGetters } from 'vuex'

export default {
  components: {
    MHeader,
    SilderBar,
    MainContent,
    ImChat,
  },
  computed: {
    ...mapGetters(['opened','showMenuHeader'])
  },
  data () {
    return {
      usertype: '',
      IMWindowVisible: false
    }
  },
  methods: {
    changeUserState (val) {
      //this.$store.commit('app/setUserType', { usertype: val })
    },
    openIm (bol) {
      const self = this
      self.IMWindowVisible = bol
      if (self.IMWindowVisible) {
        self.$nextTick(() => {
          self.$refs.ImChat.toggleIMVisible()
        })
      }
    }
  }
}
</script>
<style lang="less" scoped>
.wrap_content_0 {
  padding-top: 0px !important;
  .main {
    margin-left: 0px !important;
    height: 100vh !important;
  }
}
</style>
