<template>
  <div class="sideBar">
      <div class="titleSpan" >
        <el-dropdown  v-show="!opened" style="width: 155px;text-align: center;padding-left:12px;">
          <span class="el-dropdown-link over_ell" style="color:#fff;"> <span class="roleName">{{meuName | titleFilter}}</span><i class="el-icon-arrow-down el-icon--right"></i></span>
          <el-dropdown-menu slot="dropdown">
              <el-dropdown-item v-for="(item,index) in MenuData"  :key="index" @click.native="meuNameChange(item.name, index, item.meta.title)">{{item.meta.title}}</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <i class="fr"  v-bind:class="{'el-icon-s-fold': !opened,'el-icon-s-unfold': opened}" @click="toggleOpen()"></i>
      </div>
      <el-scrollbar>
        <el-menu
          :default-active="activeMenu"
          class="el-menu-vertical-demo"
          background-color="transparent"
          text-color="#FFF"
          mode="vertical"
          :collapse-transition="false"
          :unique-opened="true"
          :collapse="opened"
          @select="handleSelect"
        >
          <sidebar-item
            :FileName = "FileName"
            v-for="item in routes"
            :key="item.path"
            :item="item"
            :basePath="item.path"
          ></sidebar-item>
        </el-menu>
    </el-scrollbar>
  </div>
</template>
<script>
import Mgr from '@/utils/SecurityService'
import SidebarItem from './SideBarItem'
import { mapGetters } from 'vuex'
import { ownMenu, fetchSystemIds, getConstants, PacsSystemId, getLoginUserInfor } from '@/api/commonHttp' // 请求
export default {
  components: {
    SidebarItem
  },
  computed: {
    ...mapGetters(['loginTokenInfo','opened', 'usertype', 'currentPagePath']),
    activeMenu: {
      get () {
        var _path = this.$route.path
        if (_path.split('/')[2] === 'paservice' && this.currentPagePath !== '' && this.currentPagePath !== undefined) {
          _path = '/operate' + this.currentPagePath
          history.replaceState(null, document.title, _path)
        }
        if (_path === '/MedicalInstitution/AddOrgain') {
          _path = '/MedicalInstitution/InstitutionList'
        }
        if (_path === '/operate/PlatformOperation/OperateUserlist') {
          _path = '/operate/PlatformOperation'
        }
        if (_path === '/operate/systemOperate/productManagement/releaseRecord' || _path === '/operate/systemOperate/productManagement/releaseOperate') {
          _path = '/operate/systemOperate/productManagement'
        }
        return _path
      }
    }
  },
  watch: {
    currentPagePath (newVal) {
      console.log(newVal)
    }
  },
  data () {
    return {
      routes: [],
      MenuData: [],
      FileName: '',
      meuName: '',
      systemArray: []
    }
  },
  mounted () {
    this.$nextTick(() => {
      this.getUserinfoFn()
      this.getConstantsFn()
    })
  },
  methods: {
    handleSelect (val) {
      // if (val === 'operate') {
      //   window.location.href = ''
      // }
    },
    // 获取用户信息
    async getUserinfoFn () {
      // this.getMenu()
      let user
      if (this.loginTokenInfo) {
        user = JSON.parse(JSON.stringify(this.loginTokenInfo))
      } else {
        const manager = new Mgr()
        user = await manager.getRole()
      }
      var prmgroups = user.profile.prm_groups
      if (prmgroups.match(/Doctor/i)) {
        this.SystemInit()
      } else if (prmgroups.match(/PACSSystem/i) && !sessionStorage.getItem('lastname')) {
        this.PacsSystemInit()
      } else {
        this.getMenu()
      }
      // const res = await getLoginUserInfor()
      // if (res.code == 0) {
      //   let result = res.data
      //   if (result.permission_groups.indexOf('Doctor') != -1) {
      //     this.SystemInit()
      //   } else if (result.permission_groups.indexOf('PACSSystem') != -1 && !sessionStorage.getItem('lastname')) {
      //     this.PacsSystemInit()
      //   } else {
      //     this.getMenu()
      //   }
      // } else {
      //   this.$message({ type: "error", message: res.msg });
      // }
    },
    async SystemInit (val) {
      return new Promise(async (resolve, reject) => {
        try {
          await this.fetchSystemIds()
          await this.getMenu()
          return
        } catch (err) {
          reject(err)
          return err
        }
      })
    },
    async PacsSystemInit (val) {
      return new Promise(async (resolve, reject) => {
        try {
          await this.PacsSystemIdFn()
          await this.getMenu()
          return
        } catch (err) {
          reject(err)
          return err
        }
      })
    },
    async fetchSystemIds () {
      var res = await fetchSystemIds()
      this.systemArray = res.data
      sessionStorage.setItem('systemArray', JSON.stringify(res.data))
    },
    // 获取科室id
    async PacsSystemIdFn () {
      var res = await PacsSystemId()
      this.systemArray = res.data
      sessionStorage.setItem('currentSystemClass', res.data.product_code)
      sessionStorage.setItem('lastname', res.data.system_id)
    },

    // 菜单栏切换
    meuNameChange (name, menuindex, activetitle) {
      if (activetitle === sessionStorage.getItem('CheckMemuname')) { // 想同的菜单
        return
      }
      var Arr = this.MenuData
      var index = 0
      Arr.forEach((item, i) => {
        if (item.name === name && menuindex === i) {
          this.routes = []
          this.meuName = item.meta.title
          this.routes = item.children
          this.FileName = item.path
          window.sessionStorage.setItem('FileName', this.FileName)
          window.sessionStorage.setItem('ChosedSystemName', name) // select选中菜单
          window.sessionStorage.setItem('CheckMemuname', item.meta.title) // select选中菜单name
          this.$store.commit('app/set_CheckMemuname', item.meta.title)
          // var sid = item.name === 'DepartmentSystem' ? item.system_id : ''
          // if (sid) {
          //   window.sessionStorage.setItem('lastname', sid)
          // }
          window.sessionStorage.setItem('lastname', item.system_id)
          if (item.name === 'serviceCenterManage') {
            window.sessionStorage.setItem('serviceCenterName', item.meta.title)
            window.sessionStorage.setItem('serviceCenterId', item.service_center_id)
          }
          if (item.system_code) {
            window.sessionStorage.setItem('currentSystemClass', item.system_code)
          }
          
          if(item.path==='quality'){
            window.sessionStorage.setItem("quality_center_id", item.quality_center_id);
            window.sessionStorage.setItem("FileName", item.path); // select选中菜单
            window.sessionStorage.setItem("ChosedSystemName", item.path); // select选中菜单
            window.location.href =configUrl.frontEndUrl + item.children[0].path+item.children[0].children[0].path+ '?time=' + new Date().getTime();
            return;
          }
          if (process.env.NODE_ENV === 'development') {
            if (item.children[0].path === 'operate') {
              window.open = configUrl.frontEndUrl + item.children[0].name
            } else if (item.name.toLowerCase() === 'quality' || item.name.toLowerCase() == 'dms') {
              //window.location.href = configUrl.frontEndUrl +'/quality'+ item.children[0].path
              window.location.href = configUrl.frontEndUrl +`/${item.path}`+ item.children[0].path
            }
             else {
              window.location.href = configUrl.frontEndUrl + item.children[0].path
            }
          } else {
            if (item.name === 'serviceCenterManage') {
              var path = process.env.NODE_ENV === 'development' ? '/' : '/operate/'
              this.$router.push({ path: `${path}centerSet/serviceCenterInfor`, query: { id: item.service_center_id } })
            } else if (item.name.toLowerCase() === 'quality' || item.name.toLowerCase() == 'dms') {
              // window.location.href = configUrl.frontEndUrl +'/quality'+ item.children[0].path
              window.location.href = configUrl.frontEndUrl +`/${item.path}`+ item.children[0].path
            }
            else {
              window.location.href = configUrl.frontEndUrl + item.children[0].path
            }
          }
        }
        index = index + 1
      })
    },
    async getMenu () {
      var res = await ownMenu()
      if (!res || res.code !== 0) {
        return
      }
      var self = this
      var routePath = window.location.href.split('//')[1]  // localhost:8080/PlatformOperation/OperateUserlist
      // const isdepPath = routePath.split('/')[2]
      var isdepPath = process.env.NODE_ENV === 'development' ? routePath.split('/')[1] : routePath.split('/')[2]
      var menuNodes = res.data
      // 如果没有任何权限跳转到没有权限的页面
      if (menuNodes.length == 0) {
        var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
        self.$router.push({path: `${basepath}/noPermission`})
        return false
      }
      const userFirstRoute = menuNodes[0].children[0].path.split('/')[1]
      var appendNodes = []
      if (isdepPath === 'home' || isdepPath === userFirstRoute || (isdepPath !== 'DepartmentSystem' && isdepPath !== 'paservice' ) || (isdepPath === 'paservice') && window.sessionStorage.getItem('ChosedSystemName') === 'CustomerManagement') { // 相同用户权限范围
        menuNodes.forEach((rootNode, i) => {
          if (menuNodes.length === 1 && rootNode.children.length === 1 && rootNode.children[0].name === 'DepartmentSystem') {
            var node = rootNode.children[i]
            node.meta.title = rootNode.meta.title
            node.system_code = rootNode.system_code
            appendNodes[appendNodes.length] = node
            if (appendNodes.length) {
              menuNodes.length = 0
              menuNodes = appendNodes
            } else {
              throw new Error('菜单加载异常')
            }
          } else {
            rootNode.children.forEach((node, j) => {
              if (node.is_new_form === true) { // 如果二级菜单需要打开新页面，则移除所有子节点
                node.children.length = 0
                node.children = null
              }
            })
          }
        })
      } else { // 不同权限范围
        let index = 0
        var systemId = window.sessionStorage.getItem('lastname') || 0
        while (index < menuNodes.length) {
          var rootNode = menuNodes[index]
          for (var j = 0; j < rootNode.children.length; j++) {
            var node = rootNode.children[j]
            if ((node.is_new_form === true && (node.system_id === systemId || rootNode.children.length === 1))) { //  菜单路由前缀相同，保留菜单 || 只是科室管理员
              node.is_new_form = false
              node.meta.title = rootNode.meta.title
              node.system_code = rootNode.system_code
              appendNodes[appendNodes.length] = node
            }
          }
          index++
        }
        if (appendNodes.length) {
          menuNodes.length = 0
          menuNodes = appendNodes
        } else {
          throw new Error('菜单加载异常')
        }
      }
      if (isdepPath !== 'DepartmentSystem') {
        var arr = []
        menuNodes.forEach((item, i) => {
          if (item.is_show) {
            arr.push(item)
          }
        })
        menuNodes = JSON.parse(JSON.stringify(arr))
      }
      const imgMapping = ['PictureArchivingService', 'ArchivingHome', 'ImgList', 'ImgProofread', 'ArchivingBacisParams']
      menuNodes.forEach((item, i) => {
        item.children.forEach(itempath => {
          // if (itempath.path === 'paservice') {
          //   itempath.path = 'operate'
          //   itempath.path = '/' + itempath.path
          // }
          let bath = '/operate/'
          if (process.env.NODE_ENV === 'development') {
            itempath.path = itempath.path.replace('/operate', '') // 路由命名不能有/operate
            bath = '/'
          }
          if (imgMapping.includes(itempath.name)) { // 判断是否其他系统页面，改变路由地址
            itempath.path = bath + itempath.path
          }
        })
      })
      self.MenuData = menuNodes
      self.routes = menuNodes[0].children
      // 如果是科室管理员登录 默认保存第一科室 以及系统类型
      if ((!sessionStorage.getItem('lastname') || sessionStorage.getItem('lastname') == 0) && isdepPath === 'DepartmentSystem') {
        console.log("lastname重新赋值===",menuNodes[0].system_id)
        window.sessionStorage.setItem('lastname', menuNodes[0].system_id)
        window.sessionStorage.setItem('currentSystemClass', menuNodes[0].system_code)
      }
      var FirstEnterSystem = window.sessionStorage.getItem('FirstEnterSystem')
      var _name = window.sessionStorage.getItem('ChosedSystemName') // 菜单name
      var _menuname = window.sessionStorage.getItem('CheckMemuname') // d当前菜单
      
      if (FirstEnterSystem === 'true') {
        self.MenuData.forEach((item, i) => {
          if (_name && (isdepPath === 'DepartmentSystem' || (_name === 'DepartmentSystem' && isdepPath === 'paservice')) ) {
            if (item.system_id === sessionStorage.getItem('lastname')) {
              self.meuName = item.meta.title
              self.routes = item.children
            }
          } else {
            if (!_menuname && _name === 'CustomerManagement' && window.sessionStorage.getItem('lastname') == 0) {
              isdepPath = 'CustomerManagement'
            }
            if (item.name === _name || item.name === isdepPath || (!_name && i === 0) || (!_menuname && _name === item.name)) {
              self.FileName = item.path
              window.sessionStorage.setItem('FileName', self.FileName)
              self.meuName = item.meta.title
              self.routes = item.children
            }
          }
        })
        window.sessionStorage.setItem('CheckMemuname', self.meuName)
        self.$store.commit('app/set_CheckMemuname', self.meuName)
        if (isdepPath === 'home') {
          self.setDefaultMenu()
        }
      } else {
        self.MenuData.forEach((item, i) => {
          if (item.name === _name || (!_name && i === 0)) {
            self.FileName = item.path
            window.sessionStorage.setItem('FileName', self.FileName)
            self.meuName = item.meta.title
            self.routes = item.children
            window.sessionStorage.setItem('currentSystemClass', item.system_code)
            // 不是科室管理 默认显示第一个
            if (isdepPath !== 'DepartmentSystem') {
              self.meuName = self.MenuData[0].meta.title
            }
            // 如果进入的是科室管理 匹配得到科室名字
            if (item.system_id === sessionStorage.getItem('lastname') && isdepPath === 'DepartmentSystem') {
              self.meuName = item.meta.title
            }
            // 获取点击对应的科室菜单
            if (item.system_id === sessionStorage.getItem('lastname') && isdepPath === 'DepartmentSystem') {
              self.routes = self.MenuData[i].children
            }
          }
        })
        self.setDefaultMenu()
        window.sessionStorage.setItem('FirstEnterSystem', true)
        window.sessionStorage.setItem('CheckMemuname', self.meuName)
        self.$store.commit('app/set_CheckMemuname', self.meuName)
        
      }
    },
    setDefaultMenu () { // 加载默认地址
      var firstRoutePath = this.MenuData[0].children[0].path
      localStorage.setItem("loginStatus",'login')
      if (this.MenuData[0].name === 'serviceCenterManage') {
        window.location.href = configUrl.frontEndUrl + this.MenuData[0].children[0].path + this.MenuData[0].children[0].children[0].path + '?id=' + this.MenuData[0].service_center_id
      } else {
        window.location.href = configUrl.frontEndUrl + firstRoutePath
      }
    },
    // 设置菜单栏面包屑
    toggleOpen () {
      this.$store.commit('app/SET_OPENED', !this.opened)
    },
    // 获取后台枚举值--设置前端基础数据
    async getConstantsFn () {
      const res = await getConstants()
      var item = { name: '全部', value: '' }
      res.tenancy_type.unshift(item)
      res.tenancy_state.unshift(item)
      res.telemed_service_type.unshift(item)
      res.user_account_ca_state.unshift(item)
      res.user_account_state.unshift(item)
      res.common_setting_type.shift()
      this.$store.commit('app/set_officeType', res.office_type) // 科室类型
      this.$store.commit('app/set_tenancyType', res.tenancy_type) // 客户类型
      this.$store.commit('app/set_tenancyState', res.tenancy_state) // 客户状态
      this.$store.commit('app/set_userAccountState', res.user_account_state) // 用户状态
      this.$store.commit('app/set_serviceList', res.telemed_service_type) // 服务列表
      this.$store.commit('app/set_caStatelist', res.user_account_ca_state) // ca证书列表
      this.$store.commit('app/set_commonSettingtype', res.common_setting_type) // 外部能力-tab列表
      this.$store.commit('app/set_meetingCompany', res.meeting_company) // 外部能力-视频会议
      this.$store.commit('app/set_smsProducer', res.sms_producer) // 外部能力-短信服务
      this.$store.commit('app/set_caProducer', res.ca_producer) // 外部能力-电子签名
      this.$store.commit('app/set_caaccounttype', res.ca_account_type) // 外部能力-cs -类型
      this.$store.commit('app/set_caType', res.ca_type) // 外部能力类型
      this.$store.commit('app/set_servicePushText', res.service_report_type) // 推送内容
      this.$store.commit('app/set_servicePushType', res.service_report_cycle) // 推送类型
      this.$store.commit('app/set_servicePushMethods', res.service_report_receiver_push_method) // 接受方式
      this.$store.commit('app/set_enumerations', res) // 所有基础数据-------------------
    }
  },
  filters: {
    titleFilter: function (value) {
      if (!value) return ''
      if (value && value.length > 7) {
        value = value.substring(0, 7) + '...'
      }
      return value
    }

  }
}
</script>
<style lang="less" scoped>
.titleSpan {
  height: 46px;
  line-height: 46px;
  color: #fff;
  border-bottom: 1px solid hsla(0,0%,100%,.3);
}
.menu-bar{
    text-align: center;
    color: #fff;
    height: 47px;
    line-height: 47px;
    border-bottom: 1px solid rgba(255,255,255,0.3);
    .iconshouqizhankai1,.iconshouqizhankai{
      float: right;
      padding-right: 20px;
      cursor: pointer;
    }
  }
  .sideItem{
    ::v-deep .el-submenu__icon-arrow{
      font-weight: bold !important;
    }
  }
.el-scrollbar{
  height:calc(100% - 47px)!important;
  ::v-deep .el-menu--collapse {
    ::v-deep .el-submenu__title{
      span{
        display: none;
      }
    }
    ::v-deep .el-submenu__icon-arrow{
      display: none;
    }
  }
}
  .el-dropdown-link{
      .roleName {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        // float: left;
        max-width: 132px;
      }
      // .el-icon--right{
      //   margin-left:0px!important;
      // }
    }
</style>
