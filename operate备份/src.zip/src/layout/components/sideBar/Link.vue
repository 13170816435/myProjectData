<template>
  <div>
    <router-link :to="{path: returnTag(to)}" @click.native="menuClickFn(returnTag(to))"><slot /></router-link>
  </div>
</template>

<script>
export default {
  props: {
    to: {
      type: String,
      required: true
    },
    FileName: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      pathName: ''
    }
  },
  methods: {
    returnTag (path) {
      return path
    },
    menuClickFn (path) {
      // console.log('11111111111111111111')
      // console.log(path)
      // console.log('11111111111111111111')
      if(path.split('/')[2] === 'paservice') {
        this.$router.replace({path: '/operate/paservice/kong', query: {path: path}})
      }
      // 点击平台运营-> 大屏管理的跳转特殊处理
      if (path === '/operationDataBrain/dataCockpitManage'  || path === '/operate/operationDataBrain/dataCockpitManage') {
        window.open(`${cockpitManageIp}/ewdatascreen/home`, '_blank')
        // window.open(`${cockpitManageIp}`, '_blank')
      }
    }
  }
}
</script>
