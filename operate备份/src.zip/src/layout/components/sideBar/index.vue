<template>
  <div class="sideBar">
      <div class="titleSpan" >
        <el-dropdown  v-show="!opened" style="width: 155px;text-align: center;padding-left:12px;">
          <span class="el-dropdown-link over_ell" style="color:#fff;"> <span class="roleName">{{meuName | titleFilter}}</span><i class="el-icon-arrow-down el-icon--right"></i></span>
          <el-dropdown-menu slot="dropdown">
              <el-dropdown-item v-for="(item,index) in MenuData"
                :key="index"
                :class="{'activeMenu': currentName === item.meta.title}"
                @click.native="meuNameChange(item.name, index, item.meta.title)">{{item.meta.title}}</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <i class="fr"  v-bind:class="{'el-icon-s-fold': !opened,'el-icon-s-unfold': opened}" @click="toggleOpen()"></i>
      </div>
      <el-scrollbar>
        <el-menu
          :default-active="activeMenu"
          class="el-menu-vertical-demo"
          background-color="transparent"
          text-color="#FFF"
          mode="vertical"
          :collapse-transition="false"
          :unique-opened="true"
          :collapse="opened"
          @select="handleSelect"
        >
          <sidebar-item
            :FileName = "FileName"
            v-for="item in routes"
            :key="item.path"
            :item="item"
            :basePath="item.path"
          ></sidebar-item>
        </el-menu>
    </el-scrollbar>
  </div>
</template>
<script>
import Mgr from '@/utils/SecurityService'
import SidebarItem from './SideBarItem'
import { mapGetters } from 'vuex'
import { ownMenu, fetchSystemIds, getConstants, PacsSystemId, getLoginUserInfor } from '@/api/commonHttp' // 请求
export default {
  components: {
    SidebarItem
  },
  computed: {
    ...mapGetters(['loginTokenInfo','opened', 'usertype', 'currentPagePath','isSaveParams']),
    activeMenu: {
      get () {
        var _path = this.$route.path
        if (_path.split('/')[2] === 'paservice' && this.currentPagePath !== '' && this.currentPagePath !== undefined) {
          _path = '/operate' + this.currentPagePath
          history.replaceState(null, document.title, _path)
        }
        if (_path === '/MedicalInstitution/AddOrgain') {
          _path = '/MedicalInstitution/InstitutionList'
        }
        if (_path === '/operate/PlatformOperation/OperateUserlist') {
          _path = '/operate/PlatformOperation'
        }
        if (_path === '/operate/systemOperate/productManagement/releaseRecord' || _path === '/operate/systemOperate/productManagement/releaseOperate') {
          _path = '/operate/systemOperate/productManagement'
        }
        return _path
      }
    },
    currentName () {
      if (sessionStorage.getItem('CheckMemuname')) {
        return sessionStorage.getItem('CheckMemuname')
      } else {
        return ''
      }
    },
  },
  watch: {
    currentPagePath (newVal) {
      //console.log(newVal)
    },
    isSaveParams (val) {
      if (val) {
        this.getUserinfoFn()
      }
    },
  },
  data () {
    //const currentName = sessionStorage.getItem('CheckMemuname')
    return {
      //currentName: currentName ? currentName : '',
      routes: [],
      MenuData: [],
      FileName: '',
      meuName: '',
      systemArray: [],
      loginTenancyId: '',
    }
  },
  mounted () {
    this.$nextTick(() => {
      this.getUserinfoFn()
      this.getConstantsFn()
    })
  },
  methods: {
    handleSelect (val) {
      // if (val === 'operate') {
      //   window.location.href = ''
      // }
    },
    // 获取用户信息
    async getUserinfoFn () {
      // this.getMenu()
      let user
      if (this.loginTokenInfo) {
        user = JSON.parse(JSON.stringify(this.loginTokenInfo))
      } else {
        const manager = new Mgr()
        user = await manager.getRole()
      }
      this.loginTenancyId = user.profile.tenancy_id
      var prmgroups = user.profile.prm_groups
      if (prmgroups.match(/Doctor/i)) {
        this.SystemInit()
      } else if (prmgroups.match(/PACSSystem/i) && !sessionStorage.getItem('lastname')) {
        this.PacsSystemInit()
      } else {
        this.getMenu()
      }
      // const res = await getLoginUserInfor()
      // if (res.code == 0) {
      //   let result = res.data
      //   if (result.permission_groups.indexOf('Doctor') != -1) {
      //     this.SystemInit()
      //   } else if (result.permission_groups.indexOf('PACSSystem') != -1 && !sessionStorage.getItem('lastname')) {
      //     this.PacsSystemInit()
      //   } else {
      //     this.getMenu()
      //   }
      // } else {
      //   this.$message({ type: "error", message: res.msg });
      // }
    },
    async SystemInit (val) {
      return new Promise(async (resolve, reject) => {
        try {
          await this.fetchSystemIds()
          await this.getMenu()
          return
        } catch (err) {
          reject(err)
          return err
        }
      })
    },
    async PacsSystemInit (val) {
      return new Promise(async (resolve, reject) => {
        try {
          await this.PacsSystemIdFn()
          await this.getMenu()
          return
        } catch (err) {
          reject(err)
          return err
        }
      })
    },
    async fetchSystemIds () {
      var res = await fetchSystemIds()
      this.systemArray = res.data
      sessionStorage.setItem('systemArray', JSON.stringify(res.data))
    },
    // 获取科室id
    async PacsSystemIdFn () {
      var res = await PacsSystemId()
      this.systemArray = res.data
      sessionStorage.setItem('currentSystemClass', res.data.product_code)
      sessionStorage.setItem('lastname', res.data.system_id)
    },

    // 菜单栏切换
    meuNameChange (name, menuindex, activetitle) {
      if (activetitle === sessionStorage.getItem('CheckMemuname')) { // 相同的菜单
        return
      }
      var Arr = this.MenuData
      var index = 0
      Arr.forEach((item, i) => {
        if (item.name === name && menuindex === i) {
          this.routes = []
          this.meuName = item.meta.title
          this.routes = item.children
          this.FileName = item.path
          window.sessionStorage.setItem('FileName', this.FileName)
          window.sessionStorage.setItem('ChosedSystemName', name) // select选中菜单
          window.sessionStorage.setItem('CheckMemuname', item.meta.title) // select选中菜单name
          this.$store.commit('app/set_CheckMemuname', item.meta.title)
          // var sid = item.name === 'DepartmentSystem' ? item.system_id : ''
          // if (sid) {
          //   window.sessionStorage.setItem('lastname', sid)
          // }
          if (item.name == "CustomerManagement") {
            sessionStorage.setItem('tenancy_id',item.tenancy_id)
            sessionStorage.setItem('curTenancyId',item.tenancy_id)
          }
          window.sessionStorage.setItem('lastname', item.system_id)
          if (item.name === 'serviceCenterManage') {
            window.sessionStorage.setItem('serviceCenterName', item.meta.title)
            window.sessionStorage.setItem('serviceCenterId', item.service_center_id)
          }
          if (item.system_code) {
            window.sessionStorage.setItem('currentSystemClass', item.system_code)
          }
          
          if(item.path==='quality'){
            window.sessionStorage.setItem("quality_center_id", item.quality_center_id);
            window.sessionStorage.setItem("FileName", item.path); // select选中菜单
            window.sessionStorage.setItem("ChosedSystemName", item.path); // select选中菜单
            window.location.href =configUrl.frontEndUrl + item.children[0].path+item.children[0].children[0].path+ '?time=' + new Date().getTime();
            return;
          }
          if (process.env.NODE_ENV === 'development') {
            if (item.children[0].path === 'operate') {
              window.open = configUrl.frontEndUrl + item.children[0].name
            } else if (item.name.toLowerCase() === 'quality' || item.name.toLowerCase() == 'dms') {
              //window.location.href = configUrl.frontEndUrl +'/quality'+ item.children[0].path
              window.location.href = configUrl.frontEndUrl +`/${item.path}`+ item.children[0].path
            }
             else {
              window.location.href = configUrl.frontEndUrl + item.children[0].path
            }
          } else {
            if (item.name === 'serviceCenterManage') {
              var path = process.env.NODE_ENV === 'development' ? '/' : '/operate/'
              this.$router.push({ path: `${path}centerSet/serviceCenterInfor`, query: { id: item.service_center_id } })
            } else if (item.name.toLowerCase() === 'quality' || item.name.toLowerCase() == 'dms') {
              // window.location.href = configUrl.frontEndUrl +'/quality'+ item.children[0].path
              window.location.href = configUrl.frontEndUrl +`/${item.path}`+ item.children[0].path
            }
            else {
              if (item.children[0].children.length == 0) {//没有二级菜单
                window.location.href = configUrl.frontEndUrl + item.children[0].path
              } else {// 有二级菜单
                window.location.href = configUrl.frontEndUrl + item.children[0].path + item.children[0].children[0].path
              }
            }
          }
        }
        index = index + 1
      })
    },
    async getMenu () {
      var res = await ownMenu()
      if (!res || res.code !== 0) {
        return
      }
      var self = this
      var routePath = window.location.href.split('//')[1]  // localhost:8080/PlatformOperation/OperateUserlist
      // const isdepPath = routePath.split('/')[2]
      var isdepPath = process.env.NODE_ENV === 'development' ? routePath.split('/')[1] : routePath.split('/')[2]
      var menuNodes = res.data
      // 如果没有任何权限跳转到没有权限的页面
      if (menuNodes.length == 0) {
        var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
        // self.$router.push({path: `${basepath}/noPermission`})
        // return false
      }
      const userFirstRoute = menuNodes[0].children[0].path.split('/')[1]
      var appendNodes = []
      menuNodes.forEach((rootNode, i) => {
        rootNode.children.forEach((node, j) => {
          if (node.is_new_form === true) { // 如果二级菜单需要打开新页面，则移除所有子节点
            node.children.length = 0
            node.children = null
          }
        })
      })
      var arr = []
      menuNodes.forEach((item, i) => {
        //console.log('menuNodes', item)
        if (item.is_show) {
          arr.push(item)
        }
      })
      menuNodes = JSON.parse(JSON.stringify(arr))
      menuNodes.forEach((item, i) => {
        item.children.forEach(itempath => {
          if (process.env.NODE_ENV === 'development') {
            itempath.path = itempath.path.replace('/operate', '') // 路由命名不能有/operate
          }
          if (itempath.children) {
            // 隐藏标记策略
            // itempath.children = itempath.children.filter(son => {
            //   return son.name != 'markStrategy'
            // })
          }
        })
      })
       //隐藏storageStrategy 存储策略
      let base_path  = process.env.NODE_ENV === "development" ? "/" : "/operate/";
      menuNodes.forEach((e) => {
        e.children = e.children.map((element) => {
          if (element.path == base_path + "dataStorage") {
            element.children = element.children.filter(
              (item) => item.path != "/storageStrategy"
            );
          }
          return element;
        });
      });

     
      self.MenuData = menuNodes
      console.log('MenuData',self.MenuData)
      self.routes = menuNodes[0].children
      var FirstEnterSystem = window.sessionStorage.getItem('FirstEnterSystem')
      var _name = window.sessionStorage.getItem('ChosedSystemName') // 菜单name
      var _menuname = window.sessionStorage.getItem('CheckMemuname') // d当前菜单
      var tenancyMenuArr = []
      if (FirstEnterSystem === 'true') {
        self.MenuData.forEach((item, i) => {
          if (item.name === 'CustomerManagement') {// 客户管理员 或委托管理员
            tenancyMenuArr.push(item)
          } else {
            if (item.name === _name || (!_name && i === 0) || (!_menuname && _name === item.name)) {
              self.FileName = item.path
              window.sessionStorage.setItem('FileName', self.FileName)
              self.meuName = item.meta.title
              self.routes = item.children
            }
          }
        })
        // 多租户或 单个客户管理员
        var hasTenancy = false
        if (tenancyMenuArr.length != 0) {
          tenancyMenuArr.forEach((item) => {
            if (item.tenancy_id == sessionStorage.getItem('curTenancyId')) {
              hasTenancy = true
              self.FileName = item.path
              window.sessionStorage.setItem('FileName', self.FileName)
              self.meuName = item.meta.title
              self.routes = item.children
            }
          })
          // 没匹配到就取第一个
          if (!hasTenancy) {
            self.FileName = tenancyMenuArr[0].path
            sessionStorage.setItem('curTenancyId',tenancyMenuArr[0].tenancy_id)
            window.sessionStorage.setItem('FileName', self.FileName)
            self.meuName = tenancyMenuArr[0].meta.title
            self.routes = tenancyMenuArr[0].children
          }
        }
        window.sessionStorage.setItem('CheckMemuname', self.meuName)
        self.$store.commit('app/set_CheckMemuname', self.meuName)
        // 当前登录的人的 所属客户id   是否等于 委托管理员 委托某个客户的id  等于的话可以 点击业务系统的管理按钮 跳进去 
        // 不等于的话 隐藏 "管理" 按钮
        if (sessionStorage.getItem('curTenancyId') && self.loginTenancyId) {
          if (sessionStorage.getItem('curTenancyId') == self.loginTenancyId) {
            self.$store.commit("app/set_isShowManageBtn", true)
          } else {
            self.$store.commit("app/set_isShowManageBtn", false)
          }
        }
        
        if (isdepPath === 'home') {
          self.setDefaultMenu()
        }
      } else {
        self.MenuData.forEach((item, i) => {
          if (item.name === _name || (!_name && i === 0)) {
            self.FileName = item.path
            window.sessionStorage.setItem('FileName', self.FileName)
            self.meuName = item.meta.title
            self.routes = item.children
            window.sessionStorage.setItem('currentSystemClass', item.system_code)
            // 不是科室管理 默认显示第一个
            if (isdepPath !== 'DepartmentSystem') {
              self.meuName = self.MenuData[0].meta.title
            }
          }
        })
        self.setDefaultMenu()
        window.sessionStorage.setItem('FirstEnterSystem', true)
        window.sessionStorage.setItem('CheckMemuname', self.meuName)
        self.$store.commit('app/set_CheckMemuname', self.meuName)
      }
      // console.log('self.routes',self.routes)
      // self.$store.commit('app/set_permissionList',self.routes)
      sessionStorage.setItem('menuArr',JSON.stringify(self.routes))
    },
    setDefaultMenu() {
      // 加载默认地址
      // var firstRoutePath = this.MenuData[0].children[0].path;
      // localStorage.setItem("loginStatus", "login");
      // if (this.MenuData[0].name === "serviceCenterManage") {
      //   window.location.href =
      //     configUrl.frontEndUrl +
      //     this.MenuData[0].children[0].path +
      //     this.MenuData[0].children[0].children[0].path +
      //     "?id=" +
      //     this.MenuData[0].service_center_id;
      // } else {
      //   window.location.href = configUrl.frontEndUrl + firstRoutePath;
      // }
      localStorage.setItem("loginStatus",'login')
      const getFirstPath = (menuList, path = '') => {
        if(!Array.isArray(menuList) || menuList.length === 0) {
          return path
        }
        return getFirstPath(menuList[0].children,`${path}${menuList[0].path}`)
      }

      if (this.MenuData[0].name === 'serviceCenterManage') {
        window.location.href = configUrl.frontEndUrl + getFirstPath(this.MenuData[0].children) + '?id=' + this.MenuData[0].service_center_id
      } else {
        if (this.MenuData[0].children.length != 0 && this.MenuData[0].children[0].children.length != 0) {// 有二级菜单
          window.location.href = configUrl.frontEndUrl + this.MenuData[0].children[0].path + this.MenuData[0].children[0].children[0].path
        } else {// 没有二级菜单
          window.location.href = configUrl.frontEndUrl + getFirstPath(this.MenuData[0].children)
        }
        
      }
    },
    // 设置菜单栏面包屑
    toggleOpen () {
      this.$store.commit('app/SET_OPENED', !this.opened)
    },
    // 获取后台枚举值--设置前端基础数据
    async getConstantsFn () {
      const res = await getConstants()
      var item = { name: '全部', value: '' }
      res.tenancy_type.unshift(item)
      res.tenancy_state.unshift(item)
      res.telemed_service_type.unshift(item)
      res.user_account_ca_state.unshift(item)
      res.user_account_state.unshift(item)
      res.common_setting_type.shift()
      this.$store.commit('app/set_officeType', res.office_type) // 科室类型
      this.$store.commit('app/set_tenancyType', res.tenancy_type) // 客户类型
      this.$store.commit('app/set_tenancyState', res.tenancy_state) // 客户状态
      this.$store.commit('app/set_userAccountState', res.user_account_state) // 用户状态
      this.$store.commit('app/set_serviceList', res.telemed_service_type) // 服务列表
      this.$store.commit('app/set_caStatelist', res.user_account_ca_state) // ca证书列表
      this.$store.commit('app/set_commonSettingtype', res.common_setting_type) // 外部能力-tab列表
      this.$store.commit('app/set_meetingCompany', res.meeting_company) // 外部能力-视频会议
      this.$store.commit('app/set_smsProducer', res.sms_producer) // 外部能力-短信服务
      this.$store.commit('app/set_caProducer', res.ca_producer) // 外部能力-电子签名
      this.$store.commit('app/set_caaccounttype', res.ca_account_type) // 外部能力-cs -类型
      this.$store.commit('app/set_caType', res.ca_type) // 外部能力类型
      this.$store.commit('app/set_servicePushText', res.service_report_type) // 推送内容
      this.$store.commit('app/set_servicePushType', res.service_report_cycle) // 推送类型
      this.$store.commit('app/set_servicePushMethods', res.service_report_receiver_push_method) // 接受方式
      this.$store.commit('app/set_enumerations', res) // 所有基础数据-------------------
    }
  },
  filters: {
    titleFilter: function (value) {
      if (!value) return ''
      if (value && value.length > 7) {
        value = value.substring(0, 7) + '...'
      }
      return value
    }

  }
}
</script>
<style lang="less" scoped>
.titleSpan {
  height: 46px;
  line-height: 46px;
  color: #fff;
  border-bottom: 1px solid hsla(0,0%,100%,.3);
}
.menu-bar{
    text-align: center;
    color: #fff;
    height: 47px;
    line-height: 47px;
    border-bottom: 1px solid rgba(255,255,255,0.3);
    .iconshouqizhankai1,.iconshouqizhankai{
      float: right;
      padding-right: 20px;
      cursor: pointer;
    }
  }
  .sideItem{
    ::v-deep .el-submenu__icon-arrow{
      font-weight: bold !important;
    }
  }
.el-dropdown-menu__item.activeMenu {
  color: #fff;
  background: #0a70b0;
}
.el-scrollbar{
  height:calc(100% - 47px)!important;
  ::v-deep .el-menu--collapse {
    ::v-deep .el-submenu__title{
      span{
        display: none;
      }
    }
    ::v-deep .el-submenu__icon-arrow{
      display: none;
    }
  }
}
  .el-dropdown-link{
      .roleName {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        // float: left;
        max-width: 132px;
      }
      // .el-icon--right{
      //   margin-left:0px!important;
      // }
    }
</style>
