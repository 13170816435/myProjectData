<template>
  <div v-if="sideItemLoading">
    <div class="sideItem">
      <template v-if="hasOnlyChild(item)">
        <page-link :FileName = "FileName" :to="resolvePath(childItem.path)">
          <el-menu-item  :index="resolvePath(childItem.path, childItem.system_id)">
            <i class="iconfont" :class="childItem.meta.icon ? childItem.meta.icon : 'el-icon-lock'"></i>
            <span slot="title" class="navName">{{ childItem.meta.title }}</span>
          </el-menu-item>
        </page-link>
      </template>
      <el-submenu v-else :index="resolvePath(item.path)" popper-append-to-body>
        <template slot="title">
          <i class="iconfont" :class="item.meta.icon ? item.meta.icon : 'el-icon-lock'"></i>
          <span slot="title" class="navName">{{ item.meta.title }}</span>
        </template>
        <sidebar-item
          v-for="child in item.children"
          :key="child.path"
          :item="child"
          :basePath="resolvePath(child.path)"
        ></sidebar-item>
      </el-submenu>
    </div>
  </div>
</template>
<script>
import PageLink from './Link'
import path from 'path'
export default {
  name: 'SidebarItem',
  props: {
    item: {
      type: Object,
      required: true
    },
    basePath: {
      type: String,
      default: ''
    },
    FileName: {
      type: String,
      default: ''
    }
  },
  watch: {
    item () {
      this.sideItemLoading = false
      this.$nextTick(() => {
        this.sideItemLoading = true
      })
    }
  },
  computed: {
    menuitem () {
      return this.item
    }
  },
  data () {
    return {
      sideItemLoading: true,
      childItem: null
    }
  },
  methods: {
    hasOnlyChild (item) {
      const children = item.children
      var copyitem = null
      if (!children || children.length === 0) {
        copyitem = { ...item, path: '' }
        this.childItem = copyitem
        return true
      }
      return false
    },
    resolvePath (router) {
      return path.join(this.basePath, router)
    }
  },
  components: {
    PageLink
  }
}
</script>

<style>
.sideItem .el-menu-item i{
  color: #fff !important;
}
.sideItem .el-menu-item.is-active {
    color: #fff!important;
    background: rgba(0, 0, 0,0.15 )!important;
    position: relative;
}
.sideItem .el-menu-item.is-active::before{
   content:'';
   position: absolute;
   left:0;
   height:100%;
   width:5px;
   background:#ffa63b;
}
.sideItem .el-menu-item:hover {
    background: #08649e!important;
}
.el-submenu__title:hover{
  background-color: #08649e !important;
}
</style>
<style  lang="less"  scoped>
@import '~@/style/iconfont/iconfont.css';
  .iconfont{
    margin-right: 10px;
    color: #fff;
    font-size:20px!important;
  }
 .el-menu--collapse  {
   .navName {
    height: 0;
    width: 0;
    overflow: hidden;
    visibility: hidden;
    display: inline-block;
  }
 .el-submenu__icon-arrow  {
    display: none!important;
  }
}
</style>
