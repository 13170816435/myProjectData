<template>
  <div class="sideBar">
      <div class="titleSpan" >
        <el-dropdown  v-show="!opened" style="width: 135px;text-align: center;">
          <span class="el-dropdown-link over_ell" style="color:#fff;"> 个人中心</span>
          <!-- <el-dropdown-menu slot="dropdown">
              <el-dropdown-item v-for="(item,index) in MenuData"  :key="index" @click.native="meuNameChange(item.name, index, item.meta.title)">{{item.meta.title}}</el-dropdown-item>
          </el-dropdown-menu> -->
        </el-dropdown>
        <i class="fr"  v-bind:class="{'el-icon-s-fold': !opened,'el-icon-s-unfold': opened}" @click="toggleOpen()"></i>
      </div>
      <el-scrollbar>
        <el-menu
          :default-active="activeMenu"
          class="el-menu-vertical-demo"
          background-color="transparent"
          text-color="#FFF"
          mode="vertical"
          :collapse-transition="false"
          :unique-opened="true"
          :collapse="opened"
          @select="handleSelect"
        >
          <sidebar-item
            :FileName = "FileName"
            v-for="item in routes"
            :key="item.path"
            :item="item"
            :basePath="item.path"
          ></sidebar-item>
        </el-menu>
    </el-scrollbar>
  </div>
</template>
<script>
import SidebarItem from '../sideBar/SideBarItem'
import { mapGetters } from 'vuex'
export default {
  components: {
    SidebarItem
  },
  computed: {
    ...mapGetters(['opened']),
    activeMenu: {
      get () {
        var _path = this.$route.path
        if (_path.split('/')[2] === 'paservice' && this.currentPagePath !== '' && this.currentPagePath !== undefined) {
          _path = '/operate' + this.currentPagePath
          history.replaceState(null, document.title, _path)
        }
        return _path
      }
    }
  },
  watch: {
    currentPagePath (newVal) {
      console.log(newVal)
    }
  },
  data () {
    return {
      routes: [],
      MenuData: [],
      FileName: '',
      meuName: '',
      systemArray: []
    }
  },
  mounted () {
    this.$nextTick(() => {
      this.initMenu()
      // this.getConstantsFn()
    })
  },
  methods: {
    handleSelect (val) {
      // if (val === 'operate') {
      //   window.location.href = ''
      // }
    },
    // 设置菜单栏面包屑
    toggleOpen () {
      this.$store.commit('app/SET_OPENED', !this.opened)
    },
    initMenu () {
      let newPath = process.env.NODE_ENV === 'development' ? '' : '/operate'
      this.routes = [
        {
          children: [],
          is_show: true,
          meta: {
            icon: "iconcaidanlan_zhanghaoxinxi",
            title: "账号信息"
          },
          path: newPath + "/accountInfor/index"
        },
        {
          children: [],
          is_show: true,
          meta: {
            icon: "iconcaidanlan_anquanshezhi",
            title: "安全设置"
          },
          path: newPath+ "/safetySet/index"
        },
        {
          children: [],
          is_show: true,
          meta: {
            icon: "iconcaidanlan_jiaoseguanli",
            title: "角色管理"
          },
          path: newPath + "/personalRole/index"
        }
      ]
    }
  }
}
</script>
<style lang="less" scoped>
.titleSpan {
  height: 46px;
  line-height: 46px;
  color: #fff;
  border-bottom: 1px solid hsla(0,0%,100%,.3);
}
.menu-bar{
    text-align: center;
    color: #fff;
    height: 47px;
    line-height: 47px;
    border-bottom: 1px solid rgba(255,255,255,0.3);
    .iconshouqizhankai1,.iconshouqizhankai{
      float: right;
      padding-right: 20px;
      cursor: pointer;
    }
  }
  .sideItem{
    ::v-deep .el-submenu__icon-arrow{
      font-weight: bold !important;
    }
  }
.el-scrollbar{
  height:calc(100% - 47px)!important;
  ::v-deep .el-menu--collapse {
    ::v-deep .el-submenu__title{
      span{
        display: none;
      }
    }
    ::v-deep .el-submenu__icon-arrow{
      display: none;
    }
  }
}

</style>
