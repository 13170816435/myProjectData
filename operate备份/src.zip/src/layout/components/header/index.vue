<template>
    <div class="header" id="header">
        <div class="bn fl  head_name">
          <img class="headerimg" @error="imgError()" :src="headerimg"  v-if="headerimg"/>
          <!-- <span class="fl f18 siteName" v-cloak :style="{ color: siteObj.font_color || Platform.font_color, fontSize: (siteObj.font_size || Platform.font_size) + 'px' }">{{Platform.site_name}}</span> -->
          <span class="f26 siteName" :title="Platform.site_name" v-cloak :style="{ color: siteObj.font_color || Platform.font_color,fontSize: (siteObj.font_size || Platform.font_size) + 'px'}">{{Platform.site_name}}</span>
          <span class="ml15 customerName" :title="customerNameObj.custom_name" v-cloak :style="{ color: customerNameObj.custom_name_color,}">{{customerNameObj.custom_name}}</span>
        </div>
        <el-popover
          placement="bottom"
          width="150"
          top="38"
          class="roleOperate"
          popper-class="rolePopover"
          trigger="click">
          <ul class="head_pop_ul">
            <!-- <li><a href="#">个人设置</a></li> -->
            <li v-if="curPage != 'personCenter'"><a href="javascript:;" @click="gotoPersonCenter"><i class="iconfont f16 lh40 mr10 clr_666">&#xe682;</i>个人中心</a></li>
            <li v-if="isSetUdi"><a href="javascript:;" @click="aboutSystem" id="exist"><i class="iconfont f16 lh40 mr10 clr_666">&#xe84e;</i>关于系统</a></li>
            <li><a href="javascript:;" @click="LoginOut" id="exist"><i class="iconfont f16 lh40 mr10 clr_666">&#xe6ba;</i>退出登录</a></li>
            <!-- <li><a href="#" @click="changePath">改变path</a></li> -->

          </ul>
          <div class="fr head_login_info" slot="reference">
            <span class='fr ml10 loginName' :title="loginInfo.profile.name">{{loginInfo.profile.name}}</span>
            <img :src="userImg" class='fr ml15'/>
          </div>
        </el-popover>
        <div class="fr personInforDiv head_login_info" v-if="isOpenMessageList" @click="watchPersonInfor">
            <span class="personInfor"><i class="iconfont">&#xe76e;</i>
              <el-badge v-if="totalInforNum>0" :value="totalInforNum" class="item personInforLabel">消息</el-badge>
              <span class="informationLabel personInforLabel" v-else>消息</span>
            </span>
        </div>


        <p v-if="isOpenIM" class="fr personInforDiv head_login_info mr10" @click="openIMwindow">
          <!-- <i class="iconfont iconliaotian mr5" /> -->
          <span class="personInfor"><i class="iconfont">&#xea09;</i>
          <el-badge
            v-if="unreadMsgNum"
            :value="unreadMsgNum"
            :max="99"
            class="item informationLabel"
          >聊天</el-badge>
          <span v-else class="informationLabel">聊天</span>
          </span>
        </p>
      
        <div class="fr personInforDiv head_login_info mr10" @click="handleLock" v-if="isOpenScreen">
            <span class="personInfor"><i class="iconfont">&#xe7e9;</i>
            <span class="informationLabel personInforLabel">锁屏</span>
            </span>
        </div>
        
      <!-- 消息详情 -------------------------------------------------------------------------------------------->
      <el-drawer
        size="800"
        :modal="false"
        :visible.sync="showPersonInfor"
        :show-close="false"
        :withHeader="false"
        :direction="direction"
        :before-close="handleClose">
        <personInfor @closeFn="closeFn"></personInfor>
      </el-drawer>
      <!--这是底部自动弹出最新通知 的详情-->
      <el-dialog title="" class="watchNoticeAlert" :visible.sync="showDetailInforAlert"  :width="'750px'" :close-on-click-modal="false" append-to-body v-dialogDrag>
        <announceAndNoticeDetail :curTabIndex="'1'" :oneInformationObj="lastNoticeInforObj"></announceAndNoticeDetail>
      </el-dialog>
      <!--这是自动弹出最新公告的-->
      <el-dialog title="" class="watchAnnounceAlert" :visible.sync="showLastAnnounceAlert"  :width="'750px'" :close-on-click-modal="false" append-to-body @close="closeAnnounce" v-dialogDrag>
        <announceAndNoticeDetail :curTabIndex="'0'" :oneInformationObj="lastAnnounceInforObj"></announceAndNoticeDetail>
      </el-dialog>
  </div>
</template>
<script>
import eventBus from '@/utils/eventBus'
import aboutSystem from 'tomtaw-system-about'
import { mapGetters } from 'vuex'
import personInfor from "@/components/personCenter/personInfor.vue"
import announceAndNoticeDetail from "@/components/personCenter/announceAndNoticeDetail.vue"
import Mgr from '@/utils/SecurityService'
import { getThisPlatformName, getTenanciesLogo, getUserLogo, getScreensaverTime, getCustomerName } from '@/api/commonHttp'
import { getSettingsMmeta } from '@/api/platform_costomer/institution'
import { getBase64 } from '@/components/commonJs'
import { getUserLatest, getInformationTotal, updateReadState, getCurLastNotice } from '@/api/platform_operate/messageRelease'
import { initLockSceen } from 'tomtaw-lockpage'
import { initForwardAndNotify, openNotify, closeNotify } from 'tomtaw-forward'
import { addMoreBlackList } from "@/api/platform_operate/systemset";
import defaultImg from '@/assets/images/common/platemDefaultLogo.png'
export default {
  computed: {
    ...mapGetters(['loginTokenInfo','siteObj','isSetUdi','showMenuHeader','caseImportAlertShow','importOutProgressCount','unreadMsgNum',]),
    // 病例导出
    importOutPercentage() {
      if (this.importOutProgressCount == 0) {
        return 0
      } else {
        // console.log(Math.floor(parseFloat(this.importOutProgressCount)))
        return Math.floor(
          parseFloat(this.importOutProgressCount)
        )
      }
    },
   
  },
  props: {
    curPage:String
  },
  components: {
    personInfor,
    announceAndNoticeDetail,
  },
  watch:{
    siteObj:{
      handler(newValue,oldValue){ //当词条改变时执行事件
        console.log("vuexState====",newValue,oldValue)
        // alert("发生了呢")
        // this.queryInfo();  //刷新接口的函数
      }
    }
  },
  data () {
    return {
      loginInfo: {
        profile: {
          inst_name: ''
        }
      },
      isOpenIM: false,
      isOpenScreen: false,
      isOpenMessageList: false,
      lastNoticeTimer:null,
      showDetailInforAlert: false,
      showLastAnnounceAlert: false,
      lastNoticeInforObj:{},
      lastAnnounceInforObj: {},
      totalInforNum: 0,
      hasNoRead: true,
      direction: 'rtl',
      showPersonInfor: false,
      Platform: {
        font_size: 16,
      },
      headerimg: '',
      announceImg: require('../../../assets/images/common/bigAnnounce.png'),
      userImg: require('../../../assets/images/common/doctor_boy.png'),
      checkedTip: false,
      customerNameObj: {
        custom_name: '',
        custom_name_color: '',
      },
      messageList: [],
      noticeContent: '',
    }
  },
  created() {
    initForwardAndNotify()
  },
  mounted () {
    var self = this
    window.clickIMNotifyFn = self.clickIMNotifyFn
    eventBus.$on('handleClickTemplateLinkBtn', async msg => {
      this.handleClickTemplateLinkBtnFn(msg)
    })
    // 收到 cmd（指令） 消息
    eventBus.$on('iframeImGetCmdMsg', this.handleGetCmdMsg)
    window.aideUpdateIMMsgNum = this.handleAideUpdateIMMsgNum
    self.$nextTick(() => {

     if (self.loginTokenInfo) {
        console.log(self.loginTokenInfo)
        self.loginInfo = JSON.parse(JSON.stringify(self.loginTokenInfo))
        self.getUserIcon()
        const tenancy_id = sessionStorage.getItem('curTenancyId') || self.loginInfo.profile.tenancy_id
        self.getParamList(tenancy_id)
     } else {
        var manager = new Mgr()
        manager.getRole().then(function (item) {
          if (item) {
            self.loginInfo = item
            self.getUserIcon()
            const curTenancy_id = sessionStorage.getItem('curTenancyId') || item.profile.tenancy_id
            self.getParamList(curTenancy_id)
          }
        })
     }
      self.getCurScreensaverTime()
      self.getPlatformName()
      self.beganGetCustomerName()
    })
    window.sessionStorage.removeItem('noticeId')
  },
  methods: {
    imgError () {
      event.srcElement.src = defaultImg
    },
    openIMwindow () {
      if (window.iselectron) {
        window.changeImVisible()
        this.$store.dispatch('bussinessCommon/setUnreadMsgNum', 0)
      } else {
        this.$emit('openIm', true)
      }
    },
    handleAideUpdateIMMsgNum (param) {
      if (window.iselectron && param?.num) {
        let tempNum = this.unreadMsgNum
        if (param?.action) {
          switch (param.action) {
            case 'increase':
              tempNum += param.num
              break
            case 'reduce':
              tempNum -= param.num
              break
          }
        }
        if (tempNum < 0) {
          tempNum = 0
        }

        this.$store.dispatch('bussinessCommon/setUnreadMsgNum', tempNum)
      }
    },
    // 收到cmd消息时的回调
    handleGetCmdMsg(msg) {
      const self = this
      const code = msg.exts.code
      const needNotify = self.needNotify(code)
      if (needNotify) {
        JSON.parse(msg.exts.data)
        let templateData = JSON.parse(JSON.stringify(msg))
        openNotify(templateData,self,{
          onIMButtonClick: function (button,msg,notify) {// 点击通知下面的操作按钮的回调方法
            console.log("触发了",button,msg,notify)
            if (button.action == "ViewSMSBlackDetail") {
              eventBus.$emit('closeWindow')// 关闭IM 弹窗
              var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
              self.$router.push({path:`${basepath}/systemOperate/messageRecord`, query: {begin_time: msg.exts.begin_time,end_time:msg.exts.end_time} })  
              // 底部右小角 弹窗测试
              //self.handleGetCmdMsg(msg)
            }
            else if (button.action == "JoinSMSBlacklist") {// 加入短信黑名单
              self.beganAddMoreBlackList(msg)
            }
          }, 
          onIMCloseButtonClick: function (msg) { // 点击 图标 ‘x’ 关闭通知的回调方法
            console.log("点击了关闭按钮",msg,notify)
          },
          //duration: 3000,// 这里设置了会自动关闭  不定义就不会自动关闭
          // showClose: false, // 如果不需要那个关闭图标 ‘x’ 时 就传showClose:false 过来
        }
       )
      }

       if (msg.type == 'sendMessageListToSystem') {// msg 里面还有2个参数  messagesList(消息列表)  content（消息通知对应的HTML内容）这2个参数值需要保存起来
        this.messageList  = msg.messagesList
        this.noticeContent = msg.content
      }
      if(msg.type === 'clickIMNotifyFn') {// 这是收到了 IM 里面 点击 消息通知的 动作
   	    window.clickIMNotifyFn(msg.payload.msgId, msg.payload.buttonType)
   	  }
      
    },
    // 收到cmd消息时 根据code 业务类型判断是否需要弹窗提醒
    needNotify(code) {
      let codeList = ['TEXT_001']
      return codeList.indexOf(code) !== -1
    },
    // 点击了IM消息里面的 操作按钮 比如查看详情
    clickIMNotifyFn (msgId,buttonType) {
      //alert("触发了")
	    const msg = msgList.find(msg => msg.id === msgId)
	   	if(msg.to_system === currentSystem) {
	   		// 如果当前消息是目标系统，则业务系统中开始执行逻辑
	   	} else {
	   		// 跳去业务系统
	   		location.href =  `${msg.toSystem}?type=clickIMNotifyFn&msgId=${msg.id}&buttonType=${buttonType}`
	   	}
    },
    async handleClickTemplateLinkBtnFn (msg) {
      console.log('msg',msg)
      if (msg.action == "ViewSMSBlackDetail") {
        eventBus.$emit('closeWindow')// 关闭IM 弹窗
        var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
        this.$router.push({path:`${basepath}/systemOperate/messageRecord`, query: {begin_time: msg.exts.begin_time,end_time:msg.exts.end_time} })  
        //this.handleGetCmdMsg(msg)
      }
      else if (msg.action == "JoinSMSBlacklist") {// 加入短信黑名单
        this.beganAddMoreBlackList(msg)
      }
    },
    // 获取自定义名称
    async beganAddMoreBlackList (msg) {
      const res = await addMoreBlackList({phones:JSON.parse(msg.exts.phone)})
      if (res.code === 0) {
        this.$message({ type: 'success',message: "全部添加黑名单成功"})
      } else {
        this.$message({ type: 'error',message: res.msg})
      }
    },
    // 获取自定义名称
    async beganGetCustomerName () {
      const res = await getCustomerName()
      if (res.code === 0) {
        this.customerNameObj = res.data
      } else {
        this.$message({ type: 'error',message: res.msg})
      }
    },
    // 获取锁屏时间
    async getCurScreensaverTime () {
      const res = await getScreensaverTime()
        if (res.code === 0) {
            let lockScreenTime = parseInt(res.data.time) || 0 // 注意单位是秒
            if (!res.data.state) { // 个人中心那不开启自动锁屏时 时间默认传0
              lockScreenTime = 0
            }
            //initLockSceen(60,'/operate/')
            initLockSceen(lockScreenTime,'/operate/')

            // if (this.openLockScreen) { // 开启了自动锁屏
            //     clearInterval(this.checkTimer)
            //     this.checkTimer = setInterval(() => {
            //       this.checkTimeout()
            //     }, 3000)
            //   } else {
            //     clearInterval(this.checkTimer)
            // }
            if (localStorage.getItem('isLockPage') == 'true') {
              openLockPage()
            }
          } else {
            this.$message({ type: 'error',message: res.msg})
        }
    },
    // 关于系统
    aboutSystem () {
      var manager = new Mgr()
      manager.getRole().then(function (item) {
        if (item) {
          aboutSystem('operate',item)
        }
      })
    },
    // 获取 参数 看看是否开通了消息列表(在客户管理->平台设置->参数设置下配置)
    async getParamList (tenancy_id) {
      const self = this
      const param = {
        id: tenancy_id,
        name: ''
      }
      let isSetUdi = false
      const res = await getSettingsMmeta(param)
      if (res.code === 0) {
        res.data.forEach(item => {
          // 对options里面 的字段名称进行修改下  把options里面的Name 转成name  Value转成value
            if (item.options != undefined) {
              item.options.forEach((oneOptions) => {
                if (oneOptions.hasOwnProperty('Name')) {
                  oneOptions.name = oneOptions.Name;
                  delete oneOptions.Name;
                }
                if (oneOptions.hasOwnProperty('Value')) {
                  oneOptions.value = oneOptions.Value;
                  delete oneOptions.Value;
                }
              })
            }
          if (item['value'] == undefined) {
            item.value = null
          }
        })
        let result = res.data
        result.forEach((one) => {
          if (one.key == 'common_components') {
            if (one.value.indexOf('Message') != -1) {
               self.isOpenMessageList = true
            }
            if (one.value.indexOf('IM') != -1) {
               self.isOpenIM = true
            }
            if (one.value.indexOf('Screen') != -1) {
               self.isOpenScreen = true
            }
            if (one.value.indexOf('About') != -1){
              isSetUdi = true
              self.$store.commit('app/set_udi', isSetUdi)
            }
          }
        })
        //showMenuHeader==false --数据管理模块其他相关业务系统引用，不用显示通知
        if (self.isOpenMessageList&&self.showMenuHeader) { //客户开通了 消息列表提示 再去请求相应的消息数据
           self.beganGetInformationTotal()
          // 获取最新的公告
          self.beganGetAnnounceLatest()
          // 获取最新的通知
          self.beganGetNoticeLatest()
          // 每隔5分钟再获取 最新的 通知
          // clearImmediate(self.lastNoticeTimer)
          clearInterval(self.lastNoticeTimer)
          self.lastNoticeTimer = setInterval(() => {
            self.beganGetNoticeLatest()
          }, 1000*60*5);
          window.watchNoticeDetail = self.watchNoticeDetail
          window.watchServiceTimeOutDetail = self.watchServiceTimeOutDetail
        }
      } else {
        //this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 锁屏
    handleLock () {
      // 锁屏
      openLockPage()
      // 霸屏
      // beganShowWatchDialog({
      //   sub_title: '教学 \ 教学会议',
      //   title: '2023年医学影像中枢神经系统-正常及基本病变、常用成像技术！',
      //   content: '1.大家按劳动法就爱上了地方都是雷锋精神发af<br/>2.爱上了对方就爱上了对方萨拉地方萨拉地方九十六试试的撒萨拉地方士大夫<br/>',
      //   template_buttons: [{ // 按钮
      //     "action": null,
      //     "link_url": "/todo/detailPage?businessDataId=1739103035930443776&formId=1739103036509257728&contentStatut=3",
      //     "text": "查看详情",
      //     "type": "link_button"
      //   },
      //   ],
      // })
      this.$store.dispatch('lockPage/setLock', true)
    },
    watchNoticeDetail (obj) {
      this.showDetailInforAlert = true
      this.beganUpdateReadState('notice')
    },
    watchServiceTimeOutDetail () {
      var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
      var path = '/CustomerManagement/platformInfo'
      var manager = new Mgr()
      manager.getRole().then(function (item) {
        if (item.profile.tenancy_id == '0') { // 平台运营下 时 跳转到 客户列表去
          path = '/PlatformOperation/operateUserlist'
        }
      })
      path = basepath + path
      this.$router.push({path: path})
      this.beganUpdateReadState('serviceTimeOut') 
    },
    async beganGetInformationTotal () {
      const self = this
      self.totalInforNum = 0
      const res = await getInformationTotal()
      if (res.code === 0) {
        if (res.data.length != 0) {
          res.data.forEach((val)=>{
            self.totalInforNum = self.totalInforNum + val.count
          })
        }
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      } 
    },
    // 获取最新的公告
    async beganGetAnnounceLatest () {
      const self = this
      const res = await getUserLatest({type:1})
      if (res.code === 0) {
        self.lastAnnounceInforObj = res.data
        if (res.data && res.data.id && res.data.id === sessionStorage.getItem('announceId')) {
          return false
        }
         // 有消息时 且公告是未读状态时 自动弹出通知
        if (self.lastAnnounceInforObj && self.lastAnnounceInforObj.title && res.data && !res.data.read_state && res.data.id !== sessionStorage.getItem('announceId')) {
           self.showLastAnnounceAlert = true
        }
        // 缓存通知id下来 方便判断弹出的是否是同一个 如果是同一个就不继续弹出了
        if (res.data) {
          sessionStorage.setItem('announceId',res.data.id)
        }
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      } 
    },
    // 关闭公告
    closeAnnounce () {
      this.beganUpdateReadState('announce')
    },
    // 每隔5分钟获取最新通知的
    async beganGetNoticeLatest () {
      const self = this
      const res = await getCurLastNotice()
      if (res.code === 0) {
        self.lastNoticeInforObj = res.data
        if (res.data && res.data.id && res.data.id === sessionStorage.getItem('noticeId')) {
          return false
        }
        // 有消息时 自动弹出通知
        if (self.lastNoticeInforObj && self.lastNoticeInforObj.title && res.data && res.data.id !== sessionStorage.getItem('noticeId')) {
          self.$notify({
            dangerouslyUseHTMLString: true,
            customClass: 'noticeAutoAlert', // 定义弹窗的类名 好重新定义样式
            message: `<div class="noticeContainer"  onclick="watchNoticeDetail('${self.lastNoticeInforObj}')">
                        <div class="noticeDiv">
                        <div class="noticeHead">
                          <span class="noticeType">消息通知</span>
                        </div>
                        <div class="noticeContent fl">
                            <div class="fl noticeContentLeft">
                              <i class="iconfont">&#xe82c;</i>
                            </div>
                            <div class="fl noticeContentRight">
                              <div class="noticeTip">${self.lastNoticeInforObj.title}</div>
                              <div class="noticeText" v-html="$replaceRN(self.lastNoticeInforObj.content)">${self.lastNoticeInforObj.content}</div>
                            </div>
                        </div>
                        <div class="noticeFooter clear">
                          <span>查看详情<i class="iconfont">&#xe676;</i></span>
                        </div>
                      </div>
                      </div>`,
            position: 'bottom-right',
            duration: 0,
            onClick: () => {
              //this.toApproval(approvalQuery)
            },
            onClose: () => {
              console.log(`Notify已关闭，说明异常或已查看`)
              self.beganUpdateReadState('notice')
            }
          })
        }
        // 缓存通知id下来 方便判断弹出的是否是同一个 如果是同一个就不继续弹出了
        if (res.data) {
          sessionStorage.setItem('noticeId',res.data.id)
        }

        // 有服务授权到期消息时 自动弹出通知
        if (self.lastNoticeInforObj && self.lastNoticeInforObj.title && res.data && res.data.id !== sessionStorage.getItem('noticeId')) {
          self.$notify({
            dangerouslyUseHTMLString: true,
            customClass: 'serviceTimeoutAlert', // 定义弹窗的类名 好重新定义样式
            message: `<div class="serviceTimeOutContainer"  onclick="watchServiceTimeOutDetail('${self.lastNoticeInforObj}')">
                        <div class="noticeDiv">
                        <div class="noticeHead">
                          <span class="noticeType">消息通知</span>
                        </div>
                        <div class="noticeContent">
                            <div class="noticeContentLeft">
                              <i class="iconfont">&#xe82c;</i>
                            </div>
                            <div class="flex noticeContentRight">
                              <div class="noticeTip">服务即将到期通知</div>
                              <div class="noticeText">
                               <span>请注意！</span>
                               <span>
                                  <span class="tenancyName">【安吉县第一医共体】的</span>
                                  <span class="serviceName">远程医疗</span>还有7天到期;
                               </span>
                              </div>
                            </div>
                        </div>
                        <div class="noticeFooter clear">
                          <span>查看详情<i class="iconfont">&#xe676;</i></span>
                        </div>
                      </div>
                      </div>`,
            position: 'bottom-right',
            duration: 0,
            onClick: () => {
              //this.toApproval(approvalQuery)
            },
            onClose: () => {
              console.log(`Notify已关闭，说明异常或已查看`)
              self.beganUpdateReadState('serviceTimeOut')
            }
          })
        }
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      } 
    },
    async beganUpdateReadState (type) {
      const self = this
      let param = {
        id: ''
      }
      if (type === 'notice') {
        param.id = self.lastNoticeInforObj.id
      }
      if (type === 'announce') {
        param.id = self.lastAnnounceInforObj.id
      }
      if (type === 'serviceTimeOut') {
        param.id = self.lastAnnounceInforObj.id
      } 
      const res = await updateReadState(param)
      if (res.code == 0) {
        self.beganGetInformationTotal()
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      }
    },
    closeNotice () {
      this.showNoticeAlert = false
    },
    // 查看个人信息
    watchPersonInfor () {
      this.showPersonInfor = true
    },
    // 关闭详情弹窗
    handleClose (done) {
      done()
    },
    closeFn () {
      this.showPersonInfor = false
    },
    gotoPersonCenter () {
      var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
      var path = '/personCenter'
      path = basepath + path
      this.$router.push({path: path})      
    },
    async getUserIcon () {
      const self = this
      const userIconId = self.loginInfo.profile.sub
      if (userIconId && userIconId !== '0') {
        // 用户头像
        const imgFile = await getUserLogo(userIconId)
        if (imgFile) {
           getBase64(imgFile).then(result => {
              //console.log(result)
              self.userImg = result
           })
        }
        
      }
    },
    LoginOut () {
      window.sessionStorage.removeItem('EWTenancyId')
      window.sessionStorage.removeItem('curTenancyId')
      window.sessionStorage.removeItem('ChosedSystemName')
      window.sessionStorage.removeItem('noticeId')
      window.sessionStorage.removeItem('announceId')
      window.sessionStorage.removeItem('instituteListQueryObj')
      // 移出锁屏状态和锁屏时间字段
      window.sessionStorage.removeItem('screensaverState')
      window.sessionStorage.removeItem('screensaverTime')
      window.sessionStorage.removeItem('platFormName')
      window.sessionStorage.removeItem('menuArr')
      var manager = new Mgr()
      manager.signOut()
      localStorage.setItem("loginStatus",'loginOut')
    },
    async getPlatformName () {
      const self = this
      const res = await getThisPlatformName()
      if (res.code === 0) {
        self.Platform = res.data
        sessionStorage.setItem('platFormName', self.Platform.site_name)
        self.$store.commit('app/set_PlatFormName', self.Platform.site_name)
        // this.$store.commit('app/set_tenancyInfo', res.data) // 租户信息
        if (res.data.logo && res.data.logo !== '0') {
          // 平台logo
          const tenancy_id = sessionStorage.getItem('curTenancyId') || self.loginInfo.profile.tenancy_id
          getTenanciesLogo(res.data.logo, tenancy_id).then((imgFile) => {
            if (imgFile) {
              getBase64(imgFile).then(result => {
                self.headerimg = result
              }).catch(() => {
                self.headerimg = require('../../../assets/images/common/logo.png')
              })
            } else {
              self.headerimg = require('../../../assets/images/common/logo.png')
            }
          }).catch((error)=> {
             self.headerimg = ''
          })
          
        }
      }
    }
  },
  beforeDestroy() {
    eventBus.$off('iframeImGetCmdMsg')
  },
}
</script>
<style lang="less" scoped>
.rolePopover{
  margin-top:12px;
  padding:0px!important;
  .head_pop_ul{
    padding: 6px 0!important;
    li {
      a {
        height: 40px;
        width: 110px;
        display: block;
        line-height: 40px;
        padding-left: 20px;
      }
    }
  }
}
// .header{width:  100%;height:50px;    background: #0A70B0;;color: #fff;}
.head_pop_ul li{height: 40px;line-height: 40px;}
.head_pop_ul li:hover{cursor: pointer;background: #ecf5ff;
  a{
    color: #0a70b0;
    i{
      color: #0a70b0;
    }
  }
}
// .head_pop_ul li a{height: 40px;width: 100%!important;display: block;line-height: 40px;text-align: center;}
.head_name{font-size: 18px;line-height: 50px;padding-left: 20px;overflow: hidden;width: calc(100% - 425px);display: flex;}
.head_name img{margin-top: 6px;margin-right: 10px;}
.head_name  span{line-height: 50px;}
.head_name .customerName{ flex: 1;overflow: hidden;text-overflow:ellipsis;white-space:nowrap; }
.head_login_info img{width: 34px;height: 34px;  border-radius: 17px;  margin-top: 8px;  margin-right: 5px;}
.head_login_info span{ line-height: 50px;margin-right: 30px;}
.head_login_info .loginName{ max-width:100px; overflow:hidden; text-overflow:ellipsis;white-space:nowrap;}
.personInforDiv{cursor: pointer;}
.head_login_info .personInfor{
  margin-right:0px;
  font-size:16px;
  color:#0a70b0;
  i{
    margin-right:5px;
  }
  .informationLabel{
    margin-right: 10px;
    color:#303133!important;
  }
  ::v-deep .el-badge{
    position: relative;
    top:-2px;
  }
  ::v-deep .el-badge__content.is-fixed{
    top:12px!important;
  }
  ::v-deep .el-badge__content{
    line-height: 16px;
  }
}
.personInforLabel{
  color:#303133!important;
}
.headerimg{height: 36px;}
.noImgBox{width:36px;height: 36px;}
/***底部通知样式 */
.noticeContainer{
  width:360px;
  max-height:190px;
  border:1px solid #dcdfe6;
  border-top:4px solid #e6a23c;
  border-radius: 3px;
  position: fixed;
  bottom: 20px;
  right:-900000px;
  z-index:10000;
  display: none;
  transition: all .3s;
  .noticeHead{
    height:30px;
    line-height: 30px;
    margin-bottom: 5px;
    padding: 0 15px;
    .noticeType{
      font-size:14px;
      color:#303133;

    }
  }
  .noticeContent{
    border-bottom: 1px solid #dcdfe6;
    padding: 0 15px;
    .noticeContentLeft{
      margin-right:10px;
       i {
         font-size:40px;
         color:linear-gradient(0deg,#ff9a56 0%, #ffac68 100%); 
       }
    }
    .noticeContentRight{
      width:calc(100% - 50px);
      .noticeTip{
        font-size:14px;
        color:#303133;
        font-weight: 700;
        line-height: 16px;
        margin-bottom: 5px;
      }
      .noticeText{
        font-size:14px;
        color:#454545;
        line-height: 26px;
        height:52px;
        margin-bottom: 15px;
        padding-right:5px;
        // 2行
        text-overflow: -o-ellipsis-lastline;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        line-clamp: 2;
        -webkit-box-orient: vertical;
      }
    }
  }
  .noticeFooter{
    height:36px;
    padding: 0 15px;
    line-height: 36px;
    font-size: 14px;
    color:#0a70b0;
    cursor: pointer;
    i{
      margin-left:5px;
      position: relative;
      top:2px;
    }
  }

}
.activeNoticeContainer{
  display: block;
}
.f26{
  font-size:26px;
}
</style>
