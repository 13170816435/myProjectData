<template>
  <div class="wrapper" :class="{ closeBar: opened }">
    <m-header @changeUserState="changeUserState" :curPage="'personCenter'"></m-header>
    <div class="wrap_content">
      <silder-bar></silder-bar>
      <main-content></main-content>
    </div>
  </div>
</template>
<script>
import MHeader from './components/header'
import SilderBar from './components/personcenterSideBar'
import MainContent from './components/mainContent'
import { mapGetters } from 'vuex'

export default {
  components: {
    MHeader,
    SilderBar,
    MainContent
  },
  computed: {
    ...mapGetters(['opened'])
  },
  data () {
    return {
      usertype: ''
    }
  },
  methods: {
    changeUserState (val) {
      //this.$store.commit('app/setUserType', { usertype: val })
    }
  }
}
</script>
<style lang="less" scoped>
</style>
