<template>
  <div class="sideBar">
    <el-scrollbar>
    <div class="titleSpan">
        <el-dropdown  v-show="!ServiceCenterOpen" style="width: 155px;text-align: center;padding-left:12px;">
          <span class="el-dropdown-link over_ell" style="color:#fff;" v-bind:title="meuName"> <span class="serviceCenterName">{{meuName}}</span><i class="el-icon-arrow-down el-icon--right"></i></span>
          <el-dropdown-menu slot="dropdown">
              <el-dropdown-item v-for="(item,index) in MenuData"  :key="index" @click.native="meuNameChange(item.service_center_id)">{{item.meta.title}}</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      <!-- <span v-show="!ServiceCenterOpen">{{title}}</span> -->
      <i class="fr" @click="toggleOpen()" v-bind:class="{'el-icon-s-fold': !ServiceCenterOpen,'el-icon-s-unfold': ServiceCenterOpen}"></i>
      <!-- <i class="iconfont fr" @click="toggleOpen()" v-bind:class="{'el-icon-s-fold': !ServiceCenterOpen,'el-icon-s-unfold': ServiceCenterOpen}" :class="ServiceCenterOpen?'iconshouqizhankai':'iconshouqizhankai1'"></i> -->
      </div>
    <!-- <div class="menu-bar"><span v-show="!ServiceCenterOpen">{{title}}</span> <i class="iconfont" @click="toggleOpen()" :class="ServiceCenterOpen?'iconshouqizhankai':'iconshouqizhankai1'"></i></div> -->
      <el-menu
        :default-active="activeMenu"
        class="el-menu-vertical-demo"
        background-color="transparent"
        text-color="#FFF"
        mode="vertical"
        :collapse-transition="false"
        :unique-opened="true"
        :collapse="ServiceCenterOpen"
      >
        <sidebar-item
          v-for="(item, index) in routes"
          :key="index"
          :item="item"
          :basePath="item.path"
        ></sidebar-item>
      </el-menu>
    </el-scrollbar>
  </div>
</template>
<script>
import SidebarItem from '../../layout/components/sideBar/SideBarItem'
import { mapGetters } from 'vuex'
import { ownMenu, fetchSystemIds, getConstants, PacsSystemId } from '@/api/commonHttp' // 请求
import Mgr from '@/utils/SecurityService'
import cloneDeep from 'clone-deep'
import eventBus from '@/utils/eventBus'

export default {
  props: {
    menuList: {
      type: Array,
      default: () => []
    }
  },
  components: {
    SidebarItem
  },
  watch: {},
  computed: {
    ...mapGetters(['ServiceCenterOpen', 'usertype']),
    activeMenu () {
      if ((this.$route.path.indexOf('serviceCenterIndex') != -1 || this.$route.path.indexOf('serviceCenterInfor') != -1) && this.$route.query.id) {
        return
      }
      return this.$route.path
    }
  },
  data () {
    return {
      // ServiceCenterOpen: true,
      routes: [],
      MenuData: [],
      FileName: '',
      meuName: '',
      systemArray: []
    }
  },
  methods: {
    // 获取用户信息
    async getUserinfoFn () {
      const manager = new Mgr()
      const user = await manager.getRole()
      var prmgroups = user.profile.prm_groups
      // console.log(user)
      // // 如果是服务中心管理员
      // if (prmgroups.match(/ServiceCenter/)) {
      //   sessionStorage.setItem('serviceCenterId', centerId)
      // }
      this.getMenu()
    },
    // 菜单栏切换
    meuNameChange (service_center_id) {
      if(service_center_id === sessionStorage.getItem('serviceCenterId')) {
        return
      }

      // this.$store.commit('app/setUserType', name)
      var Arr = this.MenuData
      var index = 0
      Arr.forEach(item => {
        if (item.service_center_id === service_center_id) {
          const reg = new RegExp(`^\/${item.path}`, 'i')
          const replaceProductName2Empty = list => {
            for(let route of list) {
              route.path = route.path.replace(reg, '')
              if(route.children) {
                replaceProductName2Empty(route.children)
              }
            }
          }

          this.meuName = item.meta.title
          const routes = cloneDeep(item.children)
          if(process.env.NODE_ENV === 'development') {
            replaceProductName2Empty(routes)
          }
          this.routes = routes
          this.FileName = item.path
          sessionStorage.setItem('serviceCenterName', item.meta.title)
          document.getElementById('headerServiceCenterName').innerText = item.meta.title
        }
        this.$store.commit('app/set_CheckMemuname', item.meta.title)
        index = index + 1
      })
      window.sessionStorage.setItem('serviceCenterId', service_center_id) // select选中菜单

      const item = this.MenuData.find(item => item.service_center_id === service_center_id)
      if(item) {
        const getFirstPath = (menuList, path = '') => {
          if(!Array.isArray(menuList) || menuList.length === 0) {
            return path
          }
          return getFirstPath(menuList[0].children,`${path}${menuList[0].path}`)
        }

        const reg = new RegExp(`^\/${item.path}`, 'i')
        const firstPath = getFirstPath(item.children ? item.children : [])

        eventBus.$emit('on-service-center-changed')
        let path = process.env.NODE_ENV === 'development' ? firstPath.replace(reg, ''): firstPath


        this.$router.push({
          name: 'reloadServiceCenter',
          query: {
            path,
            id: item.service_center_id
          }
        })
      } else {
        this.$message.error('获取服务中心失败')
      }
    },
    // 设置菜单栏默认选中地址
    async getMenu () {
      var serviceCenterId = sessionStorage.getItem('serviceCenterId')
      var Arr = cloneDeep(this.menuList)
      var systemArray = this.systemArray
      var NewArr = []
      var routePath = window.location.href.split('/#/')[1]
      var isdepPath = ''
      if (routePath) { isdepPath = routePath.split('/')[0] }
      Arr.forEach((item, i) => {
        if (Arr.length > 1) {
          // 这样的话 只切换那些服务中心
          if (item.name === 'serviceCenterManage') {
            NewArr.push(item)
          }
          //NewArr.push(item)
        } else {
          NewArr.push(item)
        }
      })
      this.MenuData = NewArr
      let currentMenu = {}
      if (!serviceCenterId) {
        currentMenu = this.MenuData[0]
      } else {
        const arr = this.MenuData.filter(item => {
          return item.service_center_id == serviceCenterId
        })
        if (arr.length > 0) {
          currentMenu = arr[0]
        } else {
          currentMenu = this.MenuData[0]
        }
      }

      this.FileName = currentMenu.path
      this.meuName = currentMenu.meta.title
      this.routes = currentMenu.children

      this.routes.forEach((item, i) => {
        let bath = '/operate/'
        if (process.env.NODE_ENV === 'development') {
          item.path = item.path.replace('/operate', '') // 路由命名不能有/operate
          bath = '/'
        }
      })
      if (!sessionStorage.getItem('serviceCenterId')) {
        window.sessionStorage.setItem('serviceCenterId', this.MenuData[0].service_center_id)
      }
      if (sessionStorage.getItem('serviceCenterName')) {
        this.meuName = sessionStorage.getItem('serviceCenterName')
      } else {
        this.meuName = this.MenuData[0].meta.title
        window.sessionStorage.setItem('serviceCenterName', this.MenuData[0].meta.title)
      }
      this.$store.commit('app/set_CheckMemuname', this.meuName)
      const item = this.$router.options.routes.find(item => item.path === this.$route.path)
      if(item && item.children && item.children.length > 0) {
        const menuItem = this.routes.find(item => item.path === this.$route.path)
        if(menuItem && menuItem.children && menuItem.children.length > 0) {
          const path =  `${menuItem.path}${menuItem.children[0].path}`
          await this.$router.replace({
            path
          })
        }
      }
    },
    setDefaultMenu () { // 加载默认地址
      if (process.env.NODE_ENV === 'development') {
        this.MenuData.forEach((item, i) => {
          if (i === 0) {
            window.location.href = configUrl.frontEndUrl + '/#' + item.children[0].path
          }
        })
      } else {
        this.MenuData.forEach((item, i) => {
          if (i === 0) {
            window.location.href = configUrl.frontEndUrl + '/' + item.path + '/#' + item.children[0].path
          }
        })
      }
    },
    toggleOpen () {
      this.$store.commit('app/setServiceCenter_open', !this.ServiceCenterOpen)
    },
    // 获取后台枚举值--设置前端基础数据
    async getConstantsFn () {
      const res = await getConstants()
      var item = { name: '全部', value: '' }
      res.tenancy_type.unshift(item)
      res.tenancy_state.unshift(item)
      res.telemed_service_type.unshift(item)
      res.user_account_ca_state.unshift(item)
      res.user_account_state.unshift(item)
      res.common_setting_type.shift()
      this.$store.commit('app/set_officeType', res.office_type) // 科室类型
      this.$store.commit('app/set_tenancyType', res.tenancy_type) // 客户类型
      this.$store.commit('app/set_tenancyState', res.tenancy_state) // 客户状态
      this.$store.commit('app/set_userAccountState', res.user_account_state) // 用户状态
      this.$store.commit('app/set_serviceList', res.telemed_service_type) // 服务列表
      this.$store.commit('app/set_caStatelist', res.user_account_ca_state) // ca证书列表
      this.$store.commit('app/set_commonSettingtype', res.common_setting_type) // 外部能力-tab列表
      this.$store.commit('app/set_meetingCompany', res.meeting_company) // 外部能力-视频会议
      this.$store.commit('app/set_smsProducer', res.sms_producer) // 外部能力-短信服务
      this.$store.commit('app/set_caProducer', res.ca_producer) // 外部能力-电子签名
      this.$store.commit('app/set_caaccounttype', res.ca_account_type) // 外部能力-cs -类型
      this.$store.commit('app/set_caType', res.ca_type) // 外部能力类型
      this.$store.commit('app/set_servicePushText', res.service_report_type) // 推送内容
      this.$store.commit('app/set_servicePushType', res.service_report_cycle) // 推送类型
      this.$store.commit('app/set_servicePushMethods', res.service_report_receiver_push_method) // 接受方式
      this.$store.commit('app/set_enumerations', res) // 所有基础数据-------------------
    }
  },
  mounted () {
    // this.routes = routerData.serviceCenterManage
    this.getUserinfoFn()
    this.getConstantsFn()
    // this.toggleOpen()
  }
}
</script>
<style>

</style>
<style lang="less" scoped>
  // .menu-bar{
  //   // padding-left: 50px;
  //   text-align: center;
  //   color: #fff;
  //   height: 47px;
  //   line-height: 47px;
  //   border-bottom: 1px solid rgba(255,255,255,0.3);
  //   .iconshouqizhankai1,.iconshouqizhankai{
  //     float: right;
  //     padding-right: 20px;
  //     cursor: pointer;
  //   }
  //   ::v-deep .el-dropdown{
  //     .serviceCenterName {
  //       float:left;
  //       width:116px;
  //       overflow: hidden;
  //       text-overflow: ellipsis;
  //       white-space: nowrap;
  //     }
  //   }
  // }
.titleSpan {
  height: 46px;
  line-height: 46px;
  color: #fff;
  border-bottom: 1px solid hsla(0,0%,100%,.3);
}
.menu-bar{
    text-align: center;
    color: #fff;
    height: 47px;
    line-height: 47px;
    border-bottom: 1px solid rgba(255,255,255,0.3);
    .iconshouqizhankai1,.iconshouqizhankai{
      float: right;
      padding-right: 20px;
      cursor: pointer;
    }
  }
  .el-dropdown-link{
      .serviceCenterName {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 132px;
      }
      // .el-icon--right{
      //   margin-left:0px!important;
      // }
    }
.el-scrollbar{
  ::v-deep .el-menu--collapse {
    ::v-deep .el-submenu__title{
      span{
        display: none;
      }
    }
    ::v-deep .el-submenu__icon-arrow{
      display: none;
    }
  }
}
</style>
