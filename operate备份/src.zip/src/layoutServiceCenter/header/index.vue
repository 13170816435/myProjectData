<template>
    <div class="header">
        <div class="bn fl  head_name">
          <img class="headerimg" :src="headerimg" v-if="headerimg"/>
          <!-- <span class="fl f18" v-cloak>{{loginInfo.profile.inst_name ? loginInfo.profile.inst_name : ""}}</span> -->
          <span id="headerServiceCenterName" class="fl f18" v-cloak>{{curSeviceCenterName}}</span>
        </div>
        <el-popover
          placement="bottom"
          width="110"
          top="38"
          popper-class="rolePopover"
          trigger="click">
          <ul class="head_pop_ul">
            <li><a href="javascript:;" @click="gotoPersonCenter"><i class="iconfont f16 lh40 mr10 clr_666">&#xe682;</i>个人中心</a></li>
            <li><a href="javascript:;" @click="aboutSystem"><i class="iconfont f16 lh40 mr10 clr_666">&#xe84e;</i>关于系统</a></li>
            <li><a href="javascript:;" @click="LoginOut"><i class="iconfont f16 lh40 mr10 clr_666">&#xe6ba;</i>退出登录</a></li>
          </ul>
          <div class="fr head_login_info" slot="reference">
            <span class='fr ml10'>{{loginInfo.profile.name}}</span>
            <img :src="userImg" class='fr ml15'/>
          </div>
        </el-popover>
  </div>
</template>
<script>
import aboutSystem from 'tomtaw-system-about'
import Mgr from '@/utils/SecurityService'
import { getImgSrcById, getThisPlatformName, getTenanciesLogo } from '@/api/commonHttp'
import { getBase64 } from '@/components/commonJs'
export default {
  computed: {
  },
  data () {
    return {
      loginInfo: {
        profile: {
          inst_name: ''
        }
      },
      curSeviceCenterName: '',
      Platform: '',
      headerimg: '',
      userImg: require('../../assets/images/common/doctor_boy.png')
    }
  },
  mounted () {
    var _this = this
    _this.$nextTick(() => {
      var manager = new Mgr()
      manager.getRole().then(function (item) {
        if (item) {
          _this.loginInfo = item
          _this.getUserIcon()
        }
      })
      _this.getPlatformName()
    })
  },
  methods: {
    aboutSystem () {
      var manager = new Mgr()
      manager.getRole().then(function (item) {
        if (item) {
          aboutSystem('telemed',item)
        }
      })
    },
    gotoPersonCenter () {
      var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
      var path = '/servcieCenterPersonCenter'
      path = basepath + path
      this.$router.push({path: path})      
    },
    async getUserIcon () {
      const self = this
      const userIconId = self.loginInfo.profile.avatar_id
      if (userIconId && userIconId !== '0') {
        const imgFile = await getImgSrcById(userIconId)
        // 避免接口 404或500的时候 也赋值 userImg
        if (imgFile) {
          getBase64(imgFile).then(result => {
            self.userImg = result
          })
        }
      }
    },
    LoginOut () {
      var manager = new Mgr()
      manager.signOut()
      window.sessionStorage.removeItem('serviceCenterId')
      window.sessionStorage.removeItem('serviceCenterName')
      window.sessionStorage.removeItem('ChosedSystemName')
      window.sessionStorage.removeItem('EWTenancyId')
      // window.sessionStorage.clear()
    },
    async getPlatformName () {
      const self = this
      const res = await getThisPlatformName()
      if (res.code === 0) {
        self.Platform = res.data
        self.curSeviceCenterName = sessionStorage.getItem('serviceCenterName') || sessionStorage.getItem('ChosedSystemName')
        self.$store.commit('app/set_PlatFormName', self.Platform.site_name)
        if (res.data.logo && res.data.logo !== '0') {
          const tenancy_id = sessionStorage.getItem('curTenancyId') || self.loginInfo.profile.tenancy_id
          const imgFile = await getTenanciesLogo(res.data.logo, tenancy_id)
          if (imgFile) {
            getBase64(imgFile).then(result => {
              self.headerimg = result
            }).catch(() => {
              self.headerimg = require('../../assets/images/common/logo.png')
            })
          } else {
            self.headerimg = require('../../assets/images/common/logo.png')
          }
        }
      }
    }
  }
}
</script>
<style lang="less">
.rolePopover{
  margin-top:12px;
  padding:0px!important;
  .head_pop_ul{
    padding: 6px 0!important;
    li {
      a {
        height: 40px;
        width: 110px;
        display: block;
        line-height: 40px;
        padding-left: 20px;
      }
    }
  }
}
// .header{width:  100%;height:50px;    background: #0A70B0;;color: #fff;}
.head_pop_ul li{height: 40px;line-height: 40px;}
.head_pop_ul li:hover{
  cursor: pointer;
  background: #ecf5ff;
  a{
    color: #0a70b0;
    i{
      color: #0a70b0;
    }
  }
}
.head_pop_ul li a{height: 40px;width: 100%;display: block;line-height: 40px;text-align: center;}
.head_name{font-size: 18px;line-height: 50px;padding-left: 20px;overflow: hidden;}
.head_name img{margin-top: 6px;margin-right: 10px;float: left;}
.head_name  span{line-height: 50px;float: left;}
.head_login_info img{width: 34px;height: 34px;  border-radius: 17px;  margin-top: 8px;  margin-right: 5px;}
.head_login_info span{ line-height: 50px;margin-right: 30px;}
.headerimg{height:36px;}
</style>
