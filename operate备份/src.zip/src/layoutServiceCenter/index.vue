<template>
  <div class="wrapper" :class="{ closeBar: ServiceCenterOpen }" v-loading="isLoading">
    <template v-if="!isLoading">
      <m-header></m-header>
      <div class="wrap_content">
        <silder-bar :menu-list="menuList"></silder-bar>
        <main-content></main-content>
      </div>
    </template>
  </div>
</template>
<script>
import MHeader from './header'
import SilderBar from './sideBar'
import MainContent from '../layout/components/mainContent'
import { mapGetters } from 'vuex'
import {ownMenu} from '@/api/commonHttp'

export default {
  components: {
    MHeader,
    SilderBar,
    MainContent
  },
  computed: {
    ...mapGetters(['ServiceCenterOpen'])
  },
  data () {
    return {
      usertype: '',
      isLoading: true,
      menuList: []
    }
  },
  methods: {
    async getMenu() {
      try {
        const res = await ownMenu()
        if(res.code === 0) {
          this.menuList = res.data
          const serviceCenterId = sessionStorage.getItem('serviceCenterId')
          if(!serviceCenterId) {
            const serviceCenterItem = this.menuList.find(item => item.name === 'serviceCenterManage')
            if(serviceCenterItem) {
              sessionStorage.setItem('serviceCenterId', serviceCenterItem.service_center_id)
            }
          }
        }
      } catch (e) {

      } finally {
        this.isLoading = false
      }
    }
  },

  mounted() {
    this.getMenu()
  }
}
</script>
<style lang="less" scoped>
</style>
