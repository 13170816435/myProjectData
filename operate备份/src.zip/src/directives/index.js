
import dragTable from './dragTable'
import dragRow from './dragRow'
function install(Vue){

  Vue.directive(dragTable.name,dragTable.handler)
  Vue.directive(dragRow.name,dragRow.handler)

}

export default{
    install
}