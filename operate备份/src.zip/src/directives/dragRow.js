export default{//自定义 ----和外部交互
    name:'drag-row',
    handler:{
        unbind:function(el){
            //指令卸载之后
            let target = el
            target.onmousedown = null;
        },
        
        //元素 修饰符与数据等 当前元素是虚拟Node
        inserted:function(el,bingding,vnode){
            let target = el
            console.log('没绑定哦？');
            target.style.overflowX = 'hidden';
            target.style.cursor = 'grab';

            target.onmousedown = function(event){
                console.log('没绑定哦？');

                let startPointX = event.clientX;
                let startScrollLeft = target.scrollLeft;
                document.onmousemove = function(e){
                    let x = e.clientX - startPointX;
                    target.scrollLeft = startScrollLeft - x;
                }

                document.onmouseup =  function(e){
                    document.onmousemove = null;
                    document.onmouseup = null;
                }
            }

        }

    }
}