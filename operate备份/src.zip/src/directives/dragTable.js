export default{//自定义 ----和外部交互
    name:'drag',
    handler:{
        unbind:function(el){
            //指令卸载之后
            let target = el.getElementsByClassName('el-table__body-wrapper')[0];
            target.onmousedown = null;
        },
        
        //元素 修饰符与数据等 当前元素是虚拟Node
        inserted:function(el,bingding,vnode){
            let target = el.getElementsByClassName('el-table__body-wrapper')[0];
            target.style.overflowX = 'hidden';
            target.style.cursor = 'grab';

            //鼠标按下     clientX 相对容器的x
            target.onmousedown = function(event){
                // console.log('鼠标按下',event.clientX);
                //记录鼠标移动初始值
                let startPointX = event.clientX;
                //获取初始的scrollLeft ，后续计算使用
                let startScrollLeft = target.scrollLeft;
                //需要记录document的移动
                //超出元素移动就有问题
                // target.onmousemove = function(e){
                //     //移动到的位置
                // }
                document.onmousemove = function(e){

                    //移动的位置 - 初始点的位置
                    let x = e.clientX - startPointX;

                    target.scrollLeft = startScrollLeft - x;

                }

                document.onmouseup =  function(e){
                    //销毁
                    document.onmousemove = null;
                    document.onmouseup = null;
                }
            }

        }

    }
}