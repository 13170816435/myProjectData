import Vue from 'vue'
import { timeoutState } from '../utils/PIS/pisStatus'
// 添加顿号链接 比如 xxx、111、222、
Vue.filter('addTon', function (val) {
  var str = ''
  if (val) {
    for (var i = 0; i < val.length; i++) {
      str += val[i].CustomerName + '、'
    }
    // 去掉最后一个逗号(如果不需要去掉，就不用写)
    if (str.length > 0) {
      str = str.substr(0, str.length - 1)
    }
    return str
  }
})
// 字节B KB MB GB TB之间的转换
Vue.filter('changeBunit', function (size) {
  var size = parseInt(size)
  if (!size) return 0;
  if (size < pow1024(1)) return size + ' B';
  if (size < pow1024(2)) return (size / pow1024(1)).toFixed(2) + ' KB';
  if (size < pow1024(3)) return (size / pow1024(2)).toFixed(2) + ' MB';
  if (size < pow1024(4)) return (size / pow1024(3)).toFixed(2) + ' GB';
  return (size / pow1024(4)).toFixed(2) + ' TB'
})
// 求次幂
function pow1024(num) {
  return Math.pow(1024, num)
}
Vue.filter('getBusinessParamValue', function (key, arr) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i].key == key) {
      return arr[i].value
    }
  }
})
Vue.filter('showModuleName', function (vaule, arr) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i].value === vaule) {
      return arr[i].name
    }
  }
})
// 显示名族名字
Vue.filter ('showDicName', function(dic_code, arr) {
  let nationName = ''
  if (dic_code === '') return ''
  arr.forEach((item) => {
    if (item.dic_code === dic_code) {
      nationName = item.dic_name
    }
  })
  return nationName
})
// 处理索引状态
Vue.filter ('dealPrimaryIndexState', function(value, arr) {
  let stateName = ''
  if (value === '') return ''
  arr.forEach((item) => {
    if (item.value === value) {
      stateName = item.name
    }
  })
  return stateName
})
// 处理操作类型
Vue.filter('dealOperationType', function(value, arr) {
  let typeName = ''
  if (value === '') return ''
  arr.forEach((item) => {
    if (value === item.value) {
      typeName = item.name
    }
  })
  return typeName
})
// 处理字典类型对应的name值 比如婚姻 证件类型 医保卡类型 性别
Vue.filter('dealDictName', function(value, arr) {
  let dictName = ''
  if (value === '') return ''
  arr.forEach((item) => {
    if (value === item.value) {
      dictName = item.name
    }
  })
  return dictName
})

Vue.filter('showCompanyName', function (vaule, arr) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i].value === vaule) {
      return arr[i].name
    }
  }
})
Vue.filter('serviceName', function (val) {
  var str = ''
  if (val) {
    for (var i = 0; i < val.length; i++) {
      str += val[i] + '、'
    }
    // 去掉最后一个逗号(如果不需要去掉，就不用写)
    if (str.length > 0) {
      str = str.substr(0, str.length - 1)
    }
    return str
  }
})
Vue.filter('moreMonth', function (val) {
  var str = ''
  if (val) {
    for (var i = 0; i < val.length; i++) {
      str += val[i] + '月、'
    }
    // 去掉最后一个逗号(如果不需要去掉，就不用写)
    if (str.length > 0) {
      str = str.substr(0, str.length - 1)
    }
    return str
  }
})
Vue.filter('totalData', function (val) {
  var str = ''
  if (val && val.length > 1) {
    for (var i = 1; i < val.length; i++) {
      str += val[i] + '/'
    }
    // 去掉最后一个逗号(如果不需要去掉，就不用写)
    if (str.length > 0) {
      str = str.substr(0, str.length - 1)
    }
    return str
  }
})
Vue.filter('dealModuleClass', function (val) {
  if (val === 'RIS') {
    return '放射'
  } else if (val === 'ECG' || val === 'ECGIS') {
    return '心电'
  } else if (val === 'UIS') {
    return '超声'
  } else if (val === 'EIS') {
    return '内镜'
  } else if (val === 'PIS') {
    return '病理'
  }
})
Vue.filter('dealBusinessType', function (val) {
  if (val === 111) {
    return '远程放射诊断'
  } else if (val === 116) {
    return '远程内镜诊断'
  } else if (val === 130) {
    return '远程门诊'
  } else if (val === 150) {
    return '双向转诊'
  } else if (val === 160) {
    return '检查预约'
  } else if (val === 126) {
    return '国内多学科会诊'
  } else if (val === 114) {
    return '远程病理诊断'
  } else if (val === 113) {
    return '远程心电诊断'
  } else if (val === 112) {
    return '远程超声诊断'
  } else if (val === 121) {
    return '放射会诊'
  } else if (val === 122) {
    return '超声会诊'
  } else if (val === 127) {
    return '内镜会诊'
  } else if (val === 123) {
    return '心电会诊'
  } else if (val === 124) {
    return '病理会诊'
  } else if (val === 125) {
    return '专科会诊'
  } else if (val === 228) {
    return '国际[Mayo]多学科会诊'
  }
})
Vue.filter('deviceType', function (val) {
  if (val === 0) {
    return '亚马逊S3'
  } else if (val === 1) {
    return '阿里云OSS'
  } else if (val === 2) {
    return '华为云OSS'
  } else if (val === 3) {
    return '腾讯云OSS'
  } else if (val === 4) {
    return '电信云OSS'
  } else if (val === 5) {
    return '移动云OSS'
  } else if (val === 6) {
    return 'NAS存储'
  } else {
    return 'SAN本地存储'
  }
})

//超时设置状态
Vue.filter('formatTimeOut', function (val) {
  return timeoutState[val];
});
//所属系统显示
Vue.filter('systemTypeName', function (val,arr) {
  let curSystemName
  arr.forEach((item) => {
    if (val === item.code) {
      curSystemName = item.name
    }
  })
  return curSystemName
});
// 所属业务的显示
Vue.filter('businessTypeName', function (val,arr,curSystem) {
  let TypeName
  let businessTypeArr = []
  arr.forEach((item) => {
    if (curSystem === item.code) {
      businessTypeArr = item.business
    }
  })
  businessTypeArr.forEach((item) => {
    if (val === item.code) {
      TypeName = item.name
    }
  })
  return TypeName
});
// 时间转成 日期格式
Vue.filter('date', function (date, fmt) {
  if (!date) return ''
  if (typeof date === 'string') {
    date = new Date(date)
  }

  fmt = fmt || 'yyyy-MM-dd'
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  let o = {
    'M+': date.getMonth() + 1,
    'd+': date.getDate(),
    'h+': date.getHours(),
    'm+': date.getMinutes(),
    's+': date.getSeconds()
  }

  function padLeftZero (str) {
    return ('00' + str).substr(str.length)
  }

  for (let k in o) {
    if (new RegExp(`(${k})`).test(fmt)) {
      let str = o[k] + ''
      fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? str : padLeftZero(str))
    }
  }
  return fmt
});
/**
 * 阴阳性标签
 */
Vue.filter('positive', function(value) {
  if (!value) return '';

  if (value === 0) {
    return '阴性';
  } else if(value == 1) {
    return '阳性';
  } else if(value === 9) {
    return '未确认';
  }

  return `未知(${value})`;
});
/**
 * 名字超过6个字用省略号
 */
 Vue.filter('dealName', function(value, num) {
  if (!value) return '';
  if (value.length > num) {
    return value.substring(0, num) + '...';
  } else {
    return value;
  }
});

/**
 *时间轴转日期
 */
 Vue.filter('timestampToTime', function(timestamp) {
  // 时间戳为10位需*1000，时间戳为13位不需乘1000
     // var date = new Date(timestamp * 1000);
     var date = new Date(timestamp);
     var Y = date.getFullYear() + "-";
     var M =
       (date.getMonth() + 1 < 10
         ? "0" + (date.getMonth() + 1)
         : date.getMonth() + 1) + "-";
     var D = (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + " ";
     var h = (date.getHours()<10 ? "0" + date.getHours() :date.getHours())  + ":";
     var m = (date.getMinutes()<10 ? "0" + date.getMinutes() :date.getMinutes()) + ":";
     var s = date.getSeconds()<10 ? "0" + date.getSeconds() :date.getSeconds()
     return Y + M + D + h + m + s;
 });
