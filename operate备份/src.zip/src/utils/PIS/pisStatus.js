export const timeoutState = {
    'TotalDuration': '总时长',
    'MaterialDuration': '取材时长',
    'DehydrationDuration': '脱水时长',
    'EmbeddingDuration': '包埋时长',
    'SliceDuration': '切片时长',
    'SmearDuration': '涂片时长',
    'DyeingDuration': '染色时长',
    'SealDuration': '封片时长',
    'DiagnosisDuration': '诊断时长'
  }