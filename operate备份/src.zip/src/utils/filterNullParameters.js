function checkNullParameters(params) {
    const ignore = (key) => {
        delete params[key]
    };

    const keys = Object.keys(params);
    keys.forEach(key => {
        const param = params[key];
        if (param === null || param === undefined) {
            ignore(key);
        } else if (typeof param === 'object') {
            checkNullParameters(param);
        } else if (typeof param === 'string' && param.replace(/^\s|\s$/g, '').length === 0) {
            ignore(key);
        }
    });
}

export function filterNullParameters(params) {
    if (!params) {
        return {};
    }
    if (typeof params !== 'object') {
        throw new Error('Only the Object type is accepted');
    }

    checkNullParameters(params);

    return params;
}