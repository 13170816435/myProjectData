
export default {
    //多选下拉增加全选
    selectAll (valArr,options,oldOptions,value) {
        const allIdArr = []
        // 保存所有选项的id
        for (const argumentId of options) {
            allIdArr.push(argumentId.id)
        }
        const oldVal = oldOptions.length === 1 ? oldOptions[0] : []
        // 当前选中的有'全选'
        if (valArr.includes('all')) {
            value = allIdArr
        }
        // 旧数据包含'全选'，当前选中数据不包含全选
        if (oldVal.includes('all') && !valArr.includes('all')) {
            value = []
        }
        // 旧数据包含'全选'，当前选中数据包含全选
        if (oldVal.includes('all') && valArr.includes('all')) {
            const index = valArr.indexOf('all')
            valArr.splice(index, 1) // 排除全选选项
            value = valArr
        }
        // 旧数据不包含'全选'，当前选中数据不包含'全选'
        if (!oldVal.includes('all') && !valArr.includes('all')) {
            console.log(11)
            // 除了全选外 其他全部选中时
            if (valArr.length === allIdArr.length - 1) {
            value = ['all'].concat(valArr)
            }
        }
        // 数据发生变化时保存数据，作为下次对比的旧数据
        oldOptions[0] = value;

        return {options,oldOptions,value}
    },
    formatPrintType(val){
        let text = '';
        switch (val) {
            case 100:
                text = '报告'
                break;
            case 200:
                text = '标签';
                break;
            case 300:
                text = '检查单';
                break;
            case 400:
                text = '预约单'
                break;
            case 500:
                text = '知情同意书';
                break;
            case 600:
                text = '病理申请单';
                break;
            case 700:
                text = '活检标签';
                break;
            case 800:
                text = '手术记录单';
                break;
        }
        return text;
    },
    formatPrintType(){

    },
    //日期变化
    dateChange(val){
        let that = this;
        var day = new Date();
        var time1 ='';
        var time2 = '';
        if (val=='今天') {
            day.setTime(day.getTime());
            time1 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
            time2 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
        }else if (val=='昨天') {
            day.setTime(day.getTime()-24*60*60*1000);
            time1 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
            time2 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
        }else if (val=='三天内') {
            day.setTime(day.getTime());
            time2 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
            day.setTime(day.getTime()-2*24*60*60*1000);
            time1 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
        }else if (val=='本周内') {
            var weekday = day.getDay()||7;
            time2 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
            day.setDate(day.getDate()-weekday+1);
            time1 = that.dateFormat(day);
            time1 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
        }else if (val=='本月内') {
            time2 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
            time1 = that.dateFormat(day.setDate(1));
            time1 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
        }else if (val=='一周内') { 
            time2 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
            day.setTime(day.getTime()-3600 * 1000 * 24 * 6);
            time1 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
        }else if (val=='两周内') { 
            time2 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
            day.setTime(day.getTime()-3600 * 1000 * 24 * 13);
            time1 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
        }else if (val=='一个月内') {
            time2 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
            day.setTime(day.getTime()-3600 * 1000 * 24 * 30);
            time1 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
        }else if (val=='两个月内') {
            time2 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
            day.setTime(day.getTime()-3600 * 1000 * 24 * 601);
            time1 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
        }else if (val=='半年内') {
            time2 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
            day.setTime(day.getTime()-3600 * 1000 * 24 * 183);
            time1 = day.getFullYear()+"-" + (day.getMonth()+1) + "-" + day.getDate();
        }
        let arr = [this.dateFormat(time1,1),this.dateFormat(time2,1)]
        return arr
    },
    //日期格式化
    dateFormat(date1,type){
        let date2 =''
        if (date1!='') {
            let date_ = new Date(date1); 
            let _year = date_.getFullYear();
            let _month = (date_.getMonth() + 1)<10?'0'+(date_.getMonth() + 1):(date_.getMonth() + 1);
            let _date = date_.getDate()<10?'0'+date_.getDate():date_.getDate();
            
            let _hour = date_.getHours()<10?'0'+date_.getHours():date_.getHours();
            let _minute = date_.getMinutes()<10?'0'+date_.getMinutes():date_.getMinutes();
            let _second = date_.getSeconds()<10?'0'+date_.getSeconds():date_.getSeconds();
            if (type) {
                date2 = _year + '-' + _month + '-' + _date;
            }else{
                date2 = _year + '-' + _month + '-' + _date+' '+_hour+':'+ _minute +':'+_second;
            }
        }
        return date2
    },
}