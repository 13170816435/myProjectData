// import {exportExcelData} from '@/utils/exportTableMerge.js'
// import {ExportFun} from '@/utils/utils.js'
const mixinsStatisticTable={
  components: {
  },
  data(){
    return{ 
      userinfo: {}
    }
  },
  created(){ 
  },
  mounted(){
    //this.userinfo = this.$store.state.app.org_msg.profile
  },
  methods: {
    // 处理表头适配组件显示数据
    getHeaderTreeList(props,list, parentProp, id=null) { // props配置项,list 表头列表
      if(list&&list.length) {
        list.forEach((item,index)=>{
          let propStr = parentProp
          let idd = id?`${id}_${index}`:`${index}`
          propStr = propStr?propStr + '_' + item[props.prop]:item[props.prop]
          if(item.children && item.children.length) {
            item.label = item[props.label]
            item.prop =  propStr
            item.children = this.getHeaderTreeList(props,item[props.children],propStr,idd) || [],
            item.width =  item[props.label].length>13?'200px':item[props.label].length>4?'120px':'90px' // 单元格最小宽度
          } else {
            item.label = item[props.label]
            item.prop = propStr
            item.width =  item[props.label].length>13?'200px':item[props.label].length>4?'120px':'90px'
            item.children = []
          }
          item.idd = idd
        }) 
      }
      return list
    },
    // 计算相同层级的总数
    // getHeaderLevelTotal(list,flatList) {
    //   list.forEach((item)=> {
    //     const obj = flatList.find(vm=> {return vm.pId === item.pId})
    //     if(obj) {
    //       item.keyIndex = obj.keyIndex
    //     }
    //     if(item.children && item.children.length) {
    //       this.getHeaderLevelTotal(item.children,flatList)
    //     }
    //   })
    //   return list
    // },
    // 处理表格固定列数据
    getTableRowTreeList(list) {
      if(list&&list.length) {
        for(const item of list) {
          item.statisticalName = item.head_title // 所属区域列数据处理
          if(item.children && item.children.length) {
            this.getTableRowTreeList(item.children)
          }
        }
      }
      return list
    },
    // 将数形数据平铺开来
    getFlatList(treeList, returnList) {
      let arr = returnList || []
      if(treeList && treeList.length) {
        for (const item of treeList) {
          if(item.children&&item.children.length) {
            this.getFlatList(item.children,arr)
          } else {
            arr.push(item)
          }
        }
      }
      // arr.forEach((vm,index)=> {
      //   vm.keyIndex = index
      // })
      return arr

    },
    // 将表格数据对应prop
    getTableTree(rowList,flatHeadList,list ) {
      if(rowList&&rowList.length) {
        for (const row of rowList) {
          const rowIndex = row.index // 数据行
          const rowData = list[rowIndex]
          if(rowData) {
            for(const headerItem of flatHeadList) {
              if(headerItem.percent) { // 百分比数据
                const value = rowData[headerItem.index] || 0
                if(value) {
                  row[headerItem.prop] = (value/headerItem.precision).toFixed(String(headerItem.precision).length-1) + '%'
                } else {
                  row[headerItem.prop] = (0).toFixed(String(headerItem.precision).length-1) + '%'
                }
              } else {
                // precision表示数据的精度，实际上就是把原来的浮点数据乘以一个倍数，变成整形数据方便前后端传输(后端返回逻辑)；
                // 精度的值有集中情况：
                // 1  精度不需要做任何处理
                // 100，  除以100保留两位小数
                // 1000， 除以1000，保留三位小数
                // if(rowData[headerItem.index]!==null) {
                  if(headerItem.precision>1) { // 
                    row[headerItem.prop] = ((rowData[headerItem.index] || 0)/headerItem.precision).toFixed(String(headerItem.precision).length-1)
                  } else {
                    row[headerItem.prop] = Number(rowData[headerItem.index] || 0)
                  }
                // }
              }
            }
            if(row.children&&row.children.length) {
              this.getTableTree(row.children,flatHeadList,list)
            }
          }
        }
      }
      return rowList
    },
    // 根据子节点id获取所有父节点
    getAllParentNode(id,list) {
      for(const i in list){
        if(list[i].idd === id) {
          return [list[i]]
        }
        if(list[i].children && list[i].children.length) {
          let node = this.getAllParentNode(id,list[i].children)
          if(node) {
            return node.concat(list[i])
          }
        }
      }
    },
     // 根据prop获取树形数据对应的节点
    getTreeObj(prop,list) {
      let obj = null
      for(const item of list) {
        if(item.prop===prop) {
          return obj = item
        }
        if(item.children&&item.children.length) {
          let res = this.getTreeObj(prop,item.children)
          if(res) {
            return res
          }
        }
      }
    },
    // 通过匹配某一个字段返回树形数据的节点
    getTreeCodeObj(key,value,list) {
      let obj = null
      for(const item of list) {
        if(item[key]===value) {
          return obj = item
        }
        if(item.children&&item.children.length) {
          let res = this.getTreeObj(key,value,item.children)
          if(res) {
            return res
          }
        }
      }
    },
    // 设置表格可点击样式
    cellClassNameSet({row, column, rowIndex, columnIndex}) {
      if(column.property.includes('collectedexamratio') || column.property.includes('expectedtotalexamcnt') || column.property.includes('expectedexamcnt')) { // 检查总量,应上云量,云影像率不可查看详情
        return false
      }
      const reg = /^0{1}(\.\d*)|(^[1-9][0-9]*)+(\.\d*)?$/   // 非0的数字类型
      const columnObj = this.getTreeObj(column.property, this.columnconfig) // 获取表格列信息
      if(columnObj.percent) { // 百分数
        const value = String(row[column.property]).replace(/%/, "")
        if(this.isMore) { //
          if(Number(value)>this.criticalValue) { // 大于临界值的情况
            if(Number(value) === 0) {
              return 'clr_red'
            } else{
              return 'click_red'
            }
          }
        } else {
          if(Number(value)<this.criticalValue) { // 存在临界值的情况
            if(Number(value) === 0) {
              return 'clr_red'
            } else{
              return 'click_red'
            }
          }
        }
        if(reg.test(Number(value)) && Number(value)!==0) {
          return 'click_blue'
        }
      } else {
        if(column.property!=='statisticalName') {
          if(reg.test(row[column.property]) && Number(row[column.property])!==0) {
            return 'click_blue'
          }
        }
        const columnObj = this.getTreeObj(column.property, this.columnconfig)
        // if(row.twin_flag===1 && columnObj && columnObj.twin_flag===1) {
        //   return 'clr_c1'
        // }
        // 纵向等于1 并且横向不等于1
        if(row.twin_flag!==1 && columnObj && columnObj.twin_flag===1) {
          return 'clr_c1'
        }
        // if(!((row.twin_flag===1 && columnObj && columnObj.twin_flag===1) ||(!row.twin_flag&&!columnObj.twin_flag))) {
        //   return 'clr_c1'
        // }
      }
    },
    // 处理导出表头字段
    handleExportHeader() {
      const setObj=  JSON.parse(JSON.stringify(this.$refs.statisticHeader.getDefalut()))
      const dropDataY = setObj.dropDataY || []
      const totallistArr = dropDataY.filter(vm=> {return vm.dropCode !== 'statisticItem'})
      let totalCodeArr = []
      let fixColumn = []
      for(const item of totallistArr){
        totalCodeArr.push(item.dropCode)
        fixColumn.push({
          label: item.dropName,
          prop: item.dropCode
        })
      }

      const columnconfig =  JSON.parse(JSON.stringify(this.columnconfig))
      let allColumnList = columnconfig.concat()
      allColumnList.shift();
      allColumnList = fixColumn.concat(allColumnList)
      return {
        totalCodeArr: totalCodeArr,
        headArr: allColumnList
      }

    },
    // 处理导出表格字段
    handleExportTreeData(list) {
      for(const item of list) {
        let columnProp = ''
        if(item.head_code==='year' || item.head_code==='month' || item.head_code==='week' || item.head_code==='day' || list[0].head_code==='year' || list[0].head_code==='month' || list[0].head_code==='week' || list[0].head_code==='day') {
          columnProp = "segment"
        } else {
          columnProp = item.head_code || list[0].head_code
        }
        item[columnProp] = item.head_title
        if(item.children&&item.children.length) {
          this.handleExportTreeData(item.children)
        }
        
      }
      return list
    },
    // 表格数据导出
    handleExport() {
      const config = {
        tableList:this.handleExportTreeData(this.tableData),
        headArr:this.handleExportHeader().headArr,
        totalCodeArr:this.handleExportHeader().totalCodeArr,
        filename: this.table_name,
        excelTitle: [`${this.searchObj.date_time[0]} ~ ${this.searchObj.date_time[1]}${this.table_name}`,`制表人：${this.userinfo.name} 制表时间：${this.statisticHeaderObj.search_time}`],
        footertext: [this.$refs.statisticFoot.footStr],
      }
      //exportExcelData(config)
    }
  }
}
export default mixinsStatisticTable