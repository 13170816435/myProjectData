
const mixin = {
  // mixins: [commonMixin],
  methods: {
    // 年龄
    ageFormatter (row) {
      if (row.age) {
        return row.age + '' + row.age_unit
      }
    },
    // 性别
    patientSex (detail) {
      if (Number(detail.patient_sex) === NaN) {
        return detail.patient_sex
      }
      detail.patient_sex = Number(detail.patient_sex)
      if (detail.patient_sex === 0) {
        return '未知'
      } else if (detail.patient_sex === 1) {
        return '男性'
      } else if (detail.patient_sex === 2) {
        return '女性'
      } else {
        return '未说明'
      }
    },
    // 图片报错处理
    imgError (obj) {
      // console.log()
    }
  },
  filters: {
    // 秒转为时分秒
    formatSeconds (value) {
      const result = parseInt(value)
      const h = Math.floor(result / 3600) < 10 ? '0' + Math.floor(result / 3600) : Math.floor(result / 3600)
      const m = Math.floor((result / 60 % 60)) < 10 ? '0' + Math.floor((result / 60 % 60)) : Math.floor((result / 60 % 60))
      const s = Math.floor((result % 60)) < 10 ? '0' + Math.floor((result % 60)) : Math.floor((result % 60))
      const res = '';
      if (h !== '00') res += `${h}时`
      if (m !== '00') res += `${m}分`
      res += `${s}秒`
      return res
    },
    // 会诊类别
    consultMode (kind) {
      if (kind === 0) {
        return '普通'
      } else if (kind === 1) {
        return '紧急'
      }
    }
  }
}
export default mixin
