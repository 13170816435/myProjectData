const CryptoJS = require('crypto-js');  //引用AES源码js
import { getAesPassword, getCommonSettingTenancy, postCommonSettingTenancy } from '@/api/platform_costomer/institution'
const cryptoMix = {
   data () {
     return {
       AESkey: '',
       AESiv: ''
     }
   },
   methods: {
    // 获取AES密钥和向量
    async beganGetAesPassword () {
     const self = this
     let password =''
     let offset = ''
     if (sessionStorage.getItem('AES-password') && sessionStorage.getItem('AES-offset')) {
      password = sessionStorage.getItem('AES-password')
      offset = sessionStorage.getItem('AES-offset')
      self.AESkey = CryptoJS.enc.Utf8.parse(password);  //十六位十六进制数作为密钥
      self.AESiv = CryptoJS.enc.Utf8.parse(offset);   //十六位十六进制数作为密钥偏移量
      return false
     }
     const res = await getAesPassword()
      if (res.code === 0) {
        let arr = res.data.split(".")
        // console.log("arr", arr)
        password = arr[0]
        offset = arr[1]
        sessionStorage.setItem('AES-password',password)
        sessionStorage.setItem('AES-offset',offset)
        self.AESkey = CryptoJS.enc.Utf8.parse(password);  //十六位十六进制数作为密钥
        self.AESiv = CryptoJS.enc.Utf8.parse(offset);   //十六位十六进制数作为密钥偏移量
        
      } else {
       self.$message({ type: 'error', message: res.msg })
      }
    },
    //AES解密方法
    AESDecrypt(word, needConvertToBase64) {
      let srcs = null
      // 这是针对后台返回的加密格式为 Hex  如果是返回的是base64的 直接调用解密方法
      if (needConvertToBase64) {
        let encryptedHexStr = CryptoJS.enc.Hex.parse(word);
        srcs = CryptoJS.enc.Base64.stringify(encryptedHexStr);
      } else {
        srcs = word  
      }
      let decrypt = CryptoJS.AES.decrypt(srcs, this.AESkey, { iv: this.AESiv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
      let decryptedStr = decrypt.toString(CryptoJS.enc.Utf8);
      return decryptedStr.toString();
    },
    //AES加密方法(worde表示要加密的数据  needConvertToBase64表示是否将加密后的数据转成base64传给后台 )
    AESEncrypt(word,needConvertToBase64) {
        let srcs = CryptoJS.enc.Utf8.parse(word);
        if (needConvertToBase64) {
        // const keyHex = CryptoJS.enc.Utf8.parse(this.key);
        const encrypted = CryptoJS.AES.encrypt(srcs, this.AESkey, {
            iv: this.AESiv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        })
        return encrypted.ciphertext.toString(CryptoJS.enc.Base64);
      } else {
        let encrypted = CryptoJS.AES.encrypt(srcs, this.AESkey, { iv: this.AESiv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
        return encrypted.ciphertext.toString();
      }
     }
   },
   mounted() {
     this.beganGetAesPassword()
   }
}
export default cryptoMix