import PaginationTool from '@/components/common/PaginationTool'
import { fetchWorkloadSummaryDetails, fetchObservationChargeDetails, fetchObservationPositiveDetails } from '@/api/platform_departMent/dataStatistics'
import { fetchQualityObservations } from '@/api/platform_departMent/qualityStatic'
import { filterNullParameters } from '../filterNullParameters';

const mixinStatisticsDetailsBase = {
    components: {
        PaginationTool
    },
  data () {
    return {
        detailQuery: {
            which: null
        },
        detailColumns: [],
        detailsPageInfo: {
            eof: 1,
            page_index: 1,
            page_size: 15,
            total_count: 0,
            total_pages: 1
        },
        details: [], // 明细数据
        viewState: 0 // 视图状态：0 - 汇总视图，1 - 明细视图
    }
  },
  methods: {
    /**
     * 切换视图
     */
    toggleView () {
        if (this.viewState === 1) {
            this.viewState = 0
        } else {
            this.viewState = 1
        }
    },
    backToSummary () {
      this.resetDetailsModel()
      this.toggleView()
    },
    resetDetailsModel() {      
      this.detailsPageInfo.page_index = 1
      this.details = []
    },
    resetSearch() {
      this.resetDetailsModel()
      this.viewState = 0;
    },
    async showDetails(row, which) {
      const self = this
      self.toggleView()
      self.interceptQuery(row)
      self.detailQuery.which = which
      await self.loadDetails(row, which)
    },
    /**
     * 拦截处理行查询参数
     * @param {*} row 
     */
    interceptQuery(row) {},
    async loadDetails() {
      const self = this
      const params = Object.assign({}, self.searchData, self.detailQuery)
      params.offset = self.detailsPageInfo.page_index
      params.limit = self.detailsPageInfo.page_size
      filterNullParameters(params);
      self.loading = true
      const rs = await self.fetchDetails(params)
      self.loading = false

      if (rs.code !== 0) {
        self.$message.error(rs.msg)
        return
      }

      self.detailsPageInfo = rs.page 
      self.details = rs.data
    },
    async fetchDetails(params) { return Promise.resolve(); },
    async onChangeDetailsPage(info) {
      this.detailsPageInfo.page_index = info.page
      await this.loadDetails()
    },
    onViewStateChanged(newValue, oldValue) {

    }
  },
  watch: {
      viewState: function (newValue, oldValue) {
          this.onViewStateChanged(newValue, oldValue);
      }
  }
}

const mixinWorkloadDetails = {
    components: {
        ...mixinStatisticsDetailsBase.components
    },
    data() {
        return {
            ...mixinStatisticsDetailsBase.data(),
            detailColumns: [
                {
                    prop: 'patient_id',
                    label: '患者编号',
                    width: 100
                },
                {
                    prop: 'patient_name',
                    label: '患者姓名',
                    width: 120
                },
                {
                    prop: 'accession_number',
                    label: '检查号',
                    width: 100
                },
                {
                    prop: 'work_state',
                    label: '状态',
                    width: 100
                },
                {
                    prop: 'service_sect_id',
                    label: '检查类型',
                    width: 80
                },
                {
                    prop: 'exam_item_category',
                    label: '检查部位',
                    width: 120
                },
                {
                    prop: 'exam_item_name',
                    label: '检查项目',
                    width: 200
                },
                {
                    prop: 'register_name',
                    label: '登记医生',
                    width: 80
                },
                {
                    prop: 'nurse_rvu',
                    label: '登记RVU',
                    width: 80
                },
                {
                    prop: 'observation_name',
                    label: '检查医生',
                    width: 80
                },
                {
                    prop: 'observation_rvu',
                    label: '检查RVU',
                    width: 80
                },
                {
                    prop: 'pre_writing_doc_name',
                    label: '预写医生',
                    width: 80
                },
                {
                    prop: 'result_assistant_name',
                    label: '书写医生',
                    width: 80
                },
                {
                    prop: 'result_assistant_rvu',
                    label: '书写RVU',
                    width: 80
                },
                {
                    prop: 'result_principal_name',
                    label: '审核医生',
                    width: 80
                },
                {
                    prop: 'result_principal_rvu',
                    label: '审核RVU',
                    width: 80
                },
                {
                    prop: 'result_revise_name',
                    label: '修订医生',
                    width: 80
                },
                {
                    prop: 'result_revise_rvu',
                    label: '修订RVU',
                    width: 80
                },
                {
                    prop: 'reg_time',
                    label: '登记时间',
                    width: '180'
                },
                {
                    prop: 'observation_end_time',
                    label: '检查时间',
                    width: '180'
                },
                {
                    prop: 'preliminary_end_time',
                    label: '报告时间',
                    width: '180'
                },
                {
                    prop: 'audit_end_time',
                    label: '审核时间',
                    width: '180'
                },
                {
                    prop: 'revised_end_time',
                    label: '修订时间',
                    width: '180'
                }
            ],    
            detailQuery: {
                ...mixinStatisticsDetailsBase.data.detailQuery,
                doctor_ids: null,
                exam_item_ids: null,
                exam_types: null,
                dept_names: null, // 申请科室
                request_doctor_names: null, // 申请医生
                summary: null,
                observation_equipment_ids: null, // 检查设备
                observation_room_ids: null, // 检查机房
                start: null, // 起始日期
                end: null, // 截止日期
                timeliness: null, // boolean 过滤及时性
                accordance: null, // boolean 过滤病理一致性
                positive: null, // boolean 过滤阳性检查
                merged_exam_item_name: null // 合并的检查项目
            }
        }
    },
    methods: {
        ...mixinStatisticsDetailsBase.methods,
        interceptQuery(row) {
            if (row.doctor_id) {
                this.detailQuery.doctor_ids = [row.doctor_id]
            } else {
                this.detailQuery.doctor_ids = null
            }
            if (row.exam_item_id) {
                this.detailQuery.exam_item_ids = [row.exam_item_id]
            } else if (this.searchData.summary === true) {
                this.detailQuery.exam_item_ids = this.searchData.exam_item_ids
            } else {
                this.detailQuery.exam_item_ids = null
            }
            if (row.exam_category_id) {
                this.detailQuery.exam_types = [row.exam_category_id];
            } else if (row.exam_type && !/^总计|合计|小计$/.test(row.exam_type)) {
                this.detailQuery.exam_types = [row.exam_type];
            } else if (this.searchData.summary === true) {
                this.detailQuery.exam_types = this.searchData.exam_types
            } else {
                this.detailQuery.exam_types = null
            }
            if (row.request_dept) {
                this.detailQuery.dept_names = [row.request_dept]
            } else {
                this.detailQuery.dept_names = null
            }
            if (row.request_doctor) {
                this.detailQuery.request_doctor_names = [row.request_doctor]
            } else {
                this.detailQuery.request_doctor_names = null
            }
            if (row.patient_class && row.patient_class) {
                this.detailQuery.patient_classes = [row.patient_class]
            } else {
                this.detailQuery.patient_classes = null
                delete this.detailQuery.patient_classes;
            }
            if (row.observation_room_id) {
                this.detailQuery.observation_room_ids = [row.observation_room_id];
            } else {
                this.detailQuery.observation_room_ids = this.searchData.observation_room_ids;
            }
            if (row.observation_equipment_id) {
                this.detailQuery.observation_equipment_ids = [row.observation_equipment_id];
            } else {
                this.detailQuery.observation_equipment_ids = this.searchData.observation_equipment_ids;
            }
            if (row.start_date) {
                this.detailQuery.start = row.start_date;
            } else {
                this.detailQuery.start = this.searchData.start;
            }
            if (row.end_date) {
                this.detailQuery.end = row.end_date;
            } else {
                this.detailQuery.end = this.searchData.end;
            }
            if (typeof row.timeliness !== 'undefined' && row.timeliness != null) {
                this.detailQuery.timeliness = row.timeliness;
            } else {
                this.detailQuery.timeliness = null;
            }
            if (typeof row.accordance !== 'undefined' && row.accordance != null) {
                this.detailQuery.accordance = row.accordance;
            } else {
                this.detailQuery.accordance = null;
            }
            if (typeof row.positive !== 'undefined' && row.positive != null) {
                this.detailQuery.positive = row.positive;
            } else {
                this.detailQuery.positive = null;
            }
            if (row.merged_exam_item_name) {
                this.detailQuery.merged_exam_item_name = row.merged_exam_item_name
            } else {
                this.detailQuery.merged_exam_item_name = null
            }
        },
        async fetchDetails(params) {
            params = filterNullParameters(params);
            return await fetchWorkloadSummaryDetails(params);
        }
    },
    watch: {
        ...mixinStatisticsDetailsBase.watch
    }
}

const mixinPositiveRateDetails = {
    components: {
        ...mixinStatisticsDetailsBase.components
    },
    data() {
        return {
            ...mixinStatisticsDetailsBase.data(),            
            detailColumns: [
                {
                    prop: 'observation_end_time',
                    label: '检查时间',
                    width: '180',
                    format: 'date'
                },
                {
                    prop: 'patient_id',
                    label: '患者编号',
                    width: 100
                },
                {
                    prop: 'patient_name',
                    label: '患者姓名',
                    width: 120
                },
                {
                    prop: 'accession_number',
                    label: '检查号',
                    width: 100
                },
                {
                    prop: 'service_sect_id',
                    label: '检查类型',
                    width: 80
                },
                {
                    prop: 'exam_item_category',
                    label: '检查部位',
                    width: 120
                },
                {
                    prop: 'exam_item_name',
                    label: '检查项目'
                },
                {
                    prop: 'masculine_flag',
                    label: '阴阳性',
                    width: 100
                },
                {
                    prop: 'request_doctor_name',
                    label: '申请医生',
                    width: 80
                },
                {
                    prop: 'observation_name',
                    label: '检查医生',
                    width: 80
                },
                {
                    prop: 'result_assistant_name',
                    label: '书写医生',
                    width: 80
                },
                {
                    prop: 'result_principal_name',
                    label: '审核医生',
                    width: 80
                }
            ],    
            detailQuery: {
                ...mixinStatisticsDetailsBase.data.detailQuery,
                doctor_ids: null
            }
        }
    },
    methods: {
        ...mixinStatisticsDetailsBase.methods,
        interceptQuery(row) {
            if (row.doctor_id) {
                this.detailQuery.doctor_ids = [row.doctor_id]
            } else {
                this.detailQuery.doctor_ids = null
            }
            if (row.exam_item_id) {
                this.detailQuery.exam_item_ids = [row.exam_item_id]
            } else {
                this.detailQuery.exam_item_ids = null
            }
            if (row.exam_category_id) {
                this.detailQuery.exam_types = [row.exam_category_id];
            } else if (row.exam_type && !/^总计|合计|小计$/.test(row.exam_type)) {
                this.detailQuery.exam_types = [row.exam_type];
            } else {
                this.detailQuery.exam_types = null
            }
            if (row.request_dept) {
                this.detailQuery.dept_names = [row.request_dept]
            } else {
                this.detailQuery.dept_names = null
            }
            if (row.request_doctor) {
                this.detailQuery.request_doctor_names = [row.request_doctor]
            } else {
                this.detailQuery.request_doctor_names = null
            }
            if (typeof row.positive !== 'undefined' && row.positive != null) {
                this.detailQuery.positive = row.positive;
            } else {
                this.detailQuery.positive = null;
            }
        },
        async fetchDetails(params) {
            params = filterNullParameters(params);
            return await fetchObservationPositiveDetails(params)
        }
    },
    watch: {
        ...mixinStatisticsDetailsBase.watch
    }
}

const mixinObservationChargeDetails = {
    components: {
        ...mixinStatisticsDetailsBase.components
    },
    data() {
        return {
            ...mixinStatisticsDetailsBase.data(),            
            detailColumns: [
                {
                    prop: 'observation_end_time',
                    label: '检查时间',
                    width: '120'
                },
                {
                    prop: 'patient_id',
                    label: '患者编号',
                    width: 100
                },
                {
                    prop: 'patient_name',
                    label: '患者姓名',
                    width: 120
                },
                {
                    prop: 'accession_number',
                    label: '检查号',
                    width: 100
                },
                {
                    prop: 'patient_class',
                    label: '患者类别',
                    width: 80
                },
                {
                    prop: 'service_sect_id',
                    label: '检查类型',
                    width: 80
                },
                {
                    prop: 'exam_item_category',
                    label: '检查部位',
                    width: 120
                },
                {
                    prop: 'exam_item_name',
                    label: '检查项目'
                },
                {
                    prop: 'observation_name',
                    label: '检查医生',
                    width: 80
                },
                {
                    prop: 'request_doctor_name',
                    label: '申请医生',
                    width: 80
                },
                {
                    prop: 'charge',
                    label: '检查费用(元)',
                    width: 120
                },
                {
                    prop: 'payments_flag',
                    label: '是否收费',
                    width: 80
                }
            ],    
            detailQuery: {
                ...mixinStatisticsDetailsBase.data.detailQuery,
                start: null, // 日期开始
                end: null    // 日期截止
            }
        }
    },
    methods: {
        ...mixinStatisticsDetailsBase.methods,
        async fetchDetails(params) {
            params = filterNullParameters(params);
            return await fetchObservationChargeDetails(params)
        }
    },
    watch: {
        ...mixinStatisticsDetailsBase.watch
    }
}

/**
 * 质控检查数据列表
 */
const mixinQualityObservations = {
    components: {
        ...mixinStatisticsDetailsBase.components
    },
    data() {
        return {
            ...mixinStatisticsDetailsBase.data(),
            detailQuery: {
                ...mixinStatisticsDetailsBase.data.detailQuery,
                doctor_ids: null,
                exam_types: null,
                request_doctor_names: null, // 申请医生
                quality_grade: null // 质控评分等级
            }
        }
    },
    methods: {
        ...mixinStatisticsDetailsBase.methods,
        interceptQuery(row) {
            if (row.request_doctor_name  && !/^合计$/i.test(row.request_doctor_name)) {
                this.detailQuery.request_doctor_names = [row.request_doctor_name];
            } else {
                this.detailQuery.request_doctor_names = null;
            }
            if (row.doctor_id) {
                this.detailQuery.doctor_ids = [row.doctor_id];
            } else {
                this.detailQuery.doctor_ids = null;
            }
            if (row.exam_type && row.exam_type != '小计') {
                this.detailQuery.exam_types = [row.exam_type];
            } else if (this.searchData.exam_types) {
                this.detailQuery.exam_types = this.searchData.exam_types;
            } else {
                this.detailQuery.exam_types = null;
            }
            this.detailQuery.quality_grade = row.quality_grade;
        },
        async fetchDetails(params) {
            params = filterNullParameters(params);
            const rs = await fetchQualityObservations(params);
            if (rs.code === 0 && rs.data && rs.data.length) {
                rs.data.forEach(item => {
                    item.quality_deductions = item.quality_deductions.join('<br />');
                });
            }
            return rs;
        }
    },
    watch: {
        ...mixinStatisticsDetailsBase.watch
    }
}

export { mixinStatisticsDetailsBase, mixinWorkloadDetails, mixinObservationChargeDetails, mixinPositiveRateDetails, mixinQualityObservations }