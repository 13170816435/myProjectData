// 获取当前路由：如/EIS/index为EIS：内镜
import eventBus from '@/utils/eventBus'
import { mapGetters } from 'vuex'
export const routeType = {
  mounted () {
    if (process.env.NODE_ENV === 'development') {
      this.routeType = this.$route.path.split('/')[1]
    } else {
      this.routeType = this.$route.path.split('/')[2]
    }
    // console.log('this.routeType', this.$route.path)
  }
}
// 计时器
export const timesTool = {
  data () {
    return {
      videoTime: '00:00:00',
      hour: '00',
      minus: '00',
      seconds: '00',
      s: 0,
      m: 0,
      h: 0,
      timeOut: ''
    }
  },
  methods: {
    startTiming () {
      this.timeOut = setInterval(this.beginS, 1000)
    },
    endTiming () {
      // console.log('endTiming')
      clearInterval(this.timeOut)
      this.hour = '00'
      this.minus = '00'
      this.seconds = '00'
      this.s = 0
      this.m = 0
      this.h = 0
      this.videoTime = ''
    },
    beginS () {
      // var s = 0
      // var m = 0
      // var h = 0
      this.s++
      if (this.s < 10) {
        this.seconds = '0' + this.s
      } else if (this.s >= 10 && this.s <= 59) {
        this.seconds = this.s
      } else if (this.s > 59) {
        this.seconds = '00'
        this.s = 0
        this.m++
      }
      if (this.m < 10) {
        this.minus = '0' + this.m
      } else if (this.m >= 10 && this.m <= 59) {
        this.minus = this.m
      } else if (this.m > 59) {
        this.minus = '00'
        this.m = 0
        this.h++
      }
      if (this.h < 10) {
        this.hour = '0' + this.h
      } else if (this.h >= 10 && this.h <= 59) {
        this.hour = this.h
      }
      this.videoTime = this.hour + ':' + this.minus + ':' + this.seconds
    }
  }
}
// 计算表格高度
export const recalculateTableHeight = {
  mounted () {
    this.recalculateTableHeight()
    eventBus.$on('changeScreen', msg => {
      setTimeout(() => {
        this.recalculateTableHeight()
      }, 200)
    })
  },
  methods: {
    recalculateTableHeight () { // 重新计算表格高度
      this.$nextTick(() => {
        var condationHeight = this.$refs.condationHeight.offsetHeight // 条件高度
        var tabHeight = this.$refs.tabHeight.offsetHeight // 表格高度
        var paginationHeight = this.$refs.paginationHeight.offsetHeight // 分页高度
        var clientHeight = document.body.clientHeight // 屏幕高度
        this.tableHeight = clientHeight - condationHeight - tabHeight - paginationHeight - 60  //60 是头部的50 加 底部padding-bottom:10px;
      })
    }
  }
}

// 已知Table区域高度 把table撑开
export const tableContainerHeight = {
  mounted () {
    this.tableContainerHeight()
    eventBus.$on('changeScreen', msg => {
      setTimeout(() => {
        this.tableContainerHeight()
      }, 200)
    })
  },
  methods: {
    tableContainerHeight () { // 重新计算表格高度
      this.$nextTick(() => {
        var tableContainerHeight = this.$refs.tableContainerHeight.offsetHeight
        // console.log('表格高度', tableContainerHeight)
        setTimeout(() => {
          this.tableHeight = tableContainerHeight
        }, 1000)
      })
    }
  }
}

// 计算检查报告所见诊断textArea高度
export const calculateTextareaHeight = {
  create () {
  },
  mounted () {
    this.calculateTextareaHeight()
  },
  methods: {
    calculateTextareaHeight () { // 重新计算表格高度
      this.$nextTick(() => {
        var infoHeight = this.$refs.infoHeight.offsetHeight // infoHeight
        var customization = this.$refs.customization.offsetHeight // infoHeight
        // var customization = 200
        var clientHeight = document.body.clientHeight // 屏幕高度
        setTimeout(() => {
          // 55 +
          this.$refs.HtextareaF.style.height = ((clientHeight - infoHeight - customization - 258) / 3) * 2 + 'px'
          this.$refs.HtextareaD.style.height = (clientHeight - infoHeight - customization - 258) / 3 + 'px'
        }, 100)
      })
    }
  }
}
// 超声仅检查窗口 采集 高度
export const calculateCsCollectH = {
  // mounted () {
  //   this.calculateCsCollectH()
  // },
  methods: {
    calculateCsCollectH () { // 重新计算表格高度
      this.$nextTick(() => {
        // var btnJustCheck = this.$refs.btnJustCheck.offsetHeight // btnJustCheck
        var baseInfoJustCheck = this.$refs.baseInfoJustCheck.offsetHeight // btnJustCheck
        var clientJustCheck = this.$refs.clientJustCheck.offsetHeight // 屏幕高度
        setTimeout(() => {
          this.$refs.collectionJustCheck.style.height = clientJustCheck - baseInfoJustCheck - 160 + 'px'
        }, 0)
      })
    }
  }
}
// 计算实时视频高度
export const CalculateRealTimeVideoH = {
  mounted () {
    this.CalculateRealTimeVideoH()
  },
  methods: {
    CalculateRealTimeVideoH () {
      this.$nextTick(() => {
        var clientHeight = document.body.clientHeight // 屏幕高度
        setTimeout(() => {
          this.$refs.inspectImg.style.height = clientHeight - 386 + 'px'
          // if (clientHeight > 757) {

          // } else {
          //   this.$refs.inspectImgs.style.height = clientHeight - 386 + 'px'
          // }
        }, 0)
      })
    }
  }
}
// 移动弹框
export const mousedownMoveDia = {
  data () {
    return {
      selectElement: ''
    }
  },
  methods: {
    mousedown (event) {
      this.selectElement = document.getElementById(this.id)
      var div1 = this.selectElement
      this.selectElement.style.cursor = 'move'
      this.isDowm = true
      var distanceX = event.clientX - this.selectElement.offsetLeft
      var distanceY = event.clientY - this.selectElement.offsetTop
      document.onmousemove = function (ev) {
        var oevent = ev || event
        div1.style.left = oevent.clientX - distanceX + 'px'
        div1.style.top = oevent.clientY - distanceY + 'px'
      }
      document.onmouseup = function () {
        document.onmousemove = null
        document.onmouseup = null
        div1.style.cursor = 'default'
      }
    }
  }
}
// cookie 获取设置的医生
export const GetSetDoctorList = {
  data () {
    return {
      recordName: '',
      examineName: '',
      auditName: '',
      doctorKeys: '',
      switchDoctorToken: []
    }
  },
  computed: {
    ...mapGetters(['loginTokenInfo',])
  },
  mounted () {
    this.getDoctorNamre()
  },
  methods: {
    getDoctorNamre () {
      // var defaultName = JSON.parse(localStorage.getItem('loginInfo')).profile.name
      // var cookieName = sessionStorage.getItem('lastname') + JSON.parse(localStorage.getItem('loginInfo')).profile.sub
      var defaultName = this.loginTokenInfo.profile.name
      var cookieName = sessionStorage.getItem('lastname') + this.loginTokenInfo.profile.sub
      var getCookieStr = this.getCookie(cookieName)
      if (getCookieStr) {
        var arr = this.getCookie(cookieName).split(',')
        this.switchDoctorToken = arr
        if (arr.length > 1) {
          this.recordName = arr[0]
          this.examineName = arr[2]
          this.auditName = arr[4]
          this.doctorKeys = arr[6]
        } else {
          this.recordName = defaultName
          this.examineName = defaultName
          this.auditName = defaultName
          this.doctorKeys = ''
        }
      }
    },
    getCookie (name) {
      var prefix = name + '='
      var start = document.cookie.indexOf(prefix)
      if (start === -1) {
        return null
      }
      var end = document.cookie.indexOf(';', start + prefix.length)
      if (end === -1) {
        end = document.cookie.length
      }
      var value = document.cookie.substring(start + prefix.length, end)
      return unescape(value)
    }
  }
}
// 获取base64位
export function getBase64 (file) {
  return new Promise(function (resolve, reject) {
    let imgResult = ''
    imgResult = 'data:image/png;base64,' + btoa(new Uint8Array(file).reduce((data, byte) => data + String.fromCharCode(byte), ''))
    resolve(imgResult)
  })
}
// 判断 会诊时间是否 大于当前时间
export function timeCompare (timeStr) {
  var dB = new Date(timeStr.replace(/-/g, '/'))
  var nowTime = new Date()
  if (Date.parse(nowTime) > Date.parse(dB)) {
    return false
  }
  return true
}
// 处理城市json
export function CityLinkedJson (ajaxCityjson, _cityjson, params) {
  var arr = []
  ajaxCityjson.forEach(item => {
    var info = {
      label: '',
      value: ''
    }
    if (params.level < 3) {
      info.children = []
    }
    info.label = item.name
    info.value = item.code
    arr.push(info)
  })
  if (params.level === 1) {
    _cityjson = arr
  } else if (params.level === 2) {
    _cityjson.forEach(item => {
      if (item.value === params.parent_code) {
        item.children = arr
      }
    })
  } else if (params.level === 3) {
    _cityjson.forEach(itemlevel => {
      itemlevel.children.forEach(item => {
        if (item.value === params.parent_code) {
          item.children = arr
        }
      })
    })
  }
  return _cityjson
}
