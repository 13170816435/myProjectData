import eventBus from '@/utils/eventBus'
// 计算表格高度
export const getTableHigh = {
    mounted () {
      this.getTableHigh()
      eventBus.$on('changeScreen', msg => {
        setTimeout(() => {
          this.getTableHigh()
        }, 200)
      })
    },
    methods: {
        getTableHigh () { // 重新计算表格高度
        this.$nextTick(() => {
          var condationHeight = this.$refs.condationHeight.offsetHeight // 条件高度
          var tabHeight = this.$refs.tabHeight.offsetHeight // 表格高度
          var paginationHeight = this.$refs.paginationHeight?this.$refs.paginationHeight.offsetHeight:0; // 分页高度
          setTimeout(() => {
            this.tableHeight = 'calc(100vh - '+(condationHeight + tabHeight + paginationHeight + 70)+'px)' ;
            // console.log(this.tableHeight)
          }, 200)
        })
      }
    }
  }