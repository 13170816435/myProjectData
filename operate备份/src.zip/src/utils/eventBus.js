import Vue from 'vue'

// 使用 Event eventBus
const eventBus = new Vue()

export default eventBus
