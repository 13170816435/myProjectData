import jQuery from 'jquery'
import printThis from './print-this'
import printX from './printX'

export class PrintHelper {
  mTable

  mTitle = ''

  mHide = true
  beforeFn = null

  mHeader = null

  title(title) {
    this.mTitle = title
    return this
  }

  table(table) {
    this.mTable = table
    return this
  }

  importJQuery() {
    if (window.jQuery === undefined) {
      window.jQuery = jQuery
    }
  }

  importJQueryPrint() {
    if (window.jQuery.print === undefined) {
      printThis(window.jQuery)
    }
  }

  importJQueryPrintX() {
    if (window.jQuery.fn.printX === undefined) {
      printX(window, document, window.jQuery)
    }
  }

  prepareTable() {
    const isElementUITable = this.mTable.classList.contains('el-table') || this.mTable.querySelector('.el-table')
    if (isElementUITable) {
      const table = document.createElement('table')
      table.classList.add('printX-table')
      const thead = this.mTable.querySelector('.el-table__header thead')
      const tbody = this.mTable.querySelector('.el-table__body tbody')
      const _thead = thead.cloneNode(true)
      const _tbody = tbody.cloneNode(true)
      table.appendChild(_thead)
      table.appendChild(_tbody)
      return table
    }

    const _clonedTable = this.mTable.cloneNode(true)
    _clonedTable.classList.add('printX-table')
    return _clonedTable
  }

  hideEmptyRow(hide) {
    this.mHide = !hide

    return this
  }

  filterHideRow(table) {
    if (this.mHide === false) {
      return
    }
    const tbody = table.querySelector('tbody')
    const trList = tbody.querySelectorAll('tr')
    const _trList = Array.from(trList).filter(tr => tr.style.display && tr.style.display === 'none')
    for (let tr of _trList) {
      tbody.removeChild(tr)
    }
  }

  filterHideColumn(table) {
    const trList = table.querySelectorAll('tr')
    for (let trItem of Array.from(trList)) {
      const tdList = trItem.querySelectorAll('td, th')
      for (let tdItem of tdList) {
        if (tdItem.classList.contains('ew-hide-on-print')) {
          trItem.removeChild(tdItem)
        }
      }
    }
  }

  removeGutter(table) {
    const gutterList = table.querySelectorAll('thead .gutter')
    for (let item of Array.from(gutterList)) {
      if (item.parentNode) {
        item.parentNode.removeChild(item)
      }
    }
  }

  prepend(header) {
    this.mHeader = header
    return this
  }

  beforePrint(fn) {
    this.beforeFn = fn
    return this
  }

  beforeHook(table) {
    if (this.beforeFn === null) {
      return
    }

    this.beforeFn(table)
  }

  print(...config) {
    this.importJQuery()
    this.importJQueryPrint()
    this.importJQueryPrintX()
    const table = this.prepareTable()
    this.removeGutter(table)
    this.filterHideRow(table)
    this.filterHideColumn(table)
    this.beforeHook(table)

    const toolTipList = table.querySelectorAll('.el-tooltip')
    for (let item of Array.from(toolTipList)) {
      item.style.width = null
    }

    window.jQuery(table).printX(this.mTitle, this.mHeader, ...config)
  }
}

