// 上海长宁ca(ukey)    新疆巴州ca（ukey）目前都用这个
var websock = null
var _globalcallback = null
// 初始化weosocket
function initSzWebSocket () {
  // ws地址
  var wsuri = 'ws://127.0.0.1:9423/Laputa'
  websock = new WebSocket(wsuri)
  websock.onmessage = function (e) {
    websocketonmessage(e)
  }
  websock.onclose = function (e) {
    websocketclose(e)
  }
  websock.onopen = function () {
    websocketOpen()
  }
  // 连接发生错误的回调方法
  websock.onerror = function () {
    var websocketmsg = 'WebSocket连接发生错误'
    localStorage.setItem('websocketmsg', websocketmsg)
  }
}

// 实际调用的方法
function sendSzSock (agentData, callback) {
  if (callback) {
    _globalcallback = callback
  } // 回调
  if (websock.readyState === websock.OPEN) {
    // 若是ws开启状态
    websocketsend(agentData)
  } else if (websock.readyState === websock.CONNECTING) {
    // 若是 正在开启状态，则等待1s后重新调用
    setTimeout(function () {
      sendSzSock(agentData, callback)
    }, 1000)
  } else {
    // 若未开启 ，则等待1s后重新调用
    setTimeout(function () {
      sendSzSock(agentData, callback)
    }, 1000)
  }
}

// 数据接收
function websocketonmessage (e) {
  _globalcallback(JSON.parse(e.data))
}

// 数据发送
function websocketsend (agentData) {
  console.log('agentData', agentData)
  websock.send(JSON.stringify(agentData))
}

// 关闭websocket后的回调方法
function websocketclose (e) {
  console.log('connection closed')
}

// 关闭当前的websocket服务
function closeSzWebsocketService () {
  websock && websock.close()
}
function websocketOpen (e) {
  console.log('连接成功')
  var websocketmsg = '连接成功'
  localStorage.setItem('websocketmsg', websocketmsg)
}

// initSzWebSocket()
export {
  sendSzSock,
  initSzWebSocket,
  closeSzWebsocketService,
}
