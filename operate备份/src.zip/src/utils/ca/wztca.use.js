import { NetcaPKI } from './wztca.netcawebsocket'

export class WZTCA {
  constructor (obj) {
    this.callback = obj && obj.callback;
    this.signData = obj && obj.signData; // 原始签名值
    this.signCallBack = obj && obj.signCallBack; // 回调
    this.verify = obj && obj.verify
  }
  // 初始化ca
  initCa () {
    return new Promise((resolve, reject) => {
      // 连接客户端
      NetcaPKI.checkPKIInstall({}).Then(res => {
        if (this.signData) {
          this.sign()
        }
        resolve()
      }).Catch(res => {
        this.callback && this.callback({
          code: -1,
          msg: res.msg
        })
        reject()
      })
    })
  }
  // 获取key序列号
  getCertID () {
    return new Promise((resolve, reject) => {
      NetcaPKI.getCertStringAttribute({
        cert: {
          type: 'Device',
          condition: "IssuerCN~'NETCA' && InValidity='True' && CertType='Signature'"
        }
      }).Then(res => {
        resolve(res.serialNumber)
      }).Catch(res => {
        this.callback && this.callback({
          code: -1,
          msg: res.msg
        })
        reject()
      })
    })
  }
  // 字符base64处理
  utf8_to_b64(str) {
    return window.btoa(unescape(encodeURIComponent(str)));
  }
  // 签名
  sign () {
    let tbs = this.utf8_to_b64(this.signData)
    const params = {
      cert: { //证书(CertificateParams)
				encode: '', //证书PEM编码可选字段但不能为空
				type: 'Device', // 证书类型 Device为设备里的证书
				condition: "InValidity='True' && CertType='Signature'" // 选择证书条件
		  },
      data: { //数据(DataParams)
        text: tbs // 明文数据使用base64编码
      },
      includeCertOption: 2, // 包含证书的标识。默认值包含证书本身
      // tsaURL: '', // 可选 时间戳地址，如果不为空，将附加时间戳签名
    }
    NetcaPKI.signedDataSign(params)
		.Then(res => {
      if(res.result == -5 || res == -81) {
        this.callback && this.callback({
          code: -1,
          msg: '密码错误，密码重试次数为：' + res.retrynum
        })
        return
	    }
			this.verifySignedData(res)
		})
		.Catch(res => {
			this.callback && this.callback({
        code: -1,
        msg: res.msg
      })
		})
  }
  // 签名验证
  verifySignedData (certObj) {
    // let tbs = this.utf8_to_b64(this.signData)
    const params = {
      verifyLevel: 1, // 验证级别，默认为验证签名本身，不验证证书，默认为1
      signedData: certObj.signValue, // signedData的编码值
      // originData: {
      //   text: tbs
      // }
    }
    NetcaPKI.signedDataVerify(params).Then(res => {
      const obj = {
        caCertificate: certObj.signCert, // 证书64位编码
        certificateSn: res.certObject.serialNumber, // 证书序列号
        algorithm: res.signAlgo, // 签名算法
        signValue: certObj.signValue, // 数字签名值
      }
      this.signCallBack && this.signCallBack(obj)
    }).Catch(res => {
      this.callback && this.callback({
        code: -1,
        msg: res.msg
      })
    })
  }
}

