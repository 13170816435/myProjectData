var $_$onUsbKeyChangeCallBackFunc = null;
var WebsocketApp = null;

// set custom alert function
function SetAlertFunction(custom_alert) {
    $_$XTXAlert = custom_alert;
}

function $checkBrowserISIE() {
    return (!!window.ActiveXObject || 'ActiveXObject' in window) ? true : false;
}


//usbkey change default callback function
function $OnUsbKeyChange() {
    console.info("gxca usb change");
    if (typeof $_$onUsbKeyChangeCallBackFunc == 'function') {
        $_$onUsbKeyChangeCallBackFunc();
    }
}

// IE11 attach event
function $AttachIE11OnUSBKeychangeEvent(strObjName) {
    var handler = document.createElement("script");
    handler.setAttribute("for", strObjName);
    handler.setAttribute("event", "OnUsbKeyChange");
    handler.appendChild(document.createTextNode("$OnUsbKeyChange()"));
    document.body.appendChild(handler);
}

//load a control
function $LoadControl(CLSID, ctlName, testFuncName, addEvent) {
    var pluginDiv = document.getElementById("pluginDiv" + ctlName);
    if (pluginDiv) {
        return true;
    }
    pluginDiv = document.createElement("div");
    pluginDiv.id = "pluginDiv" + ctlName;
    document.body.appendChild(pluginDiv);

    try {
        if ($checkBrowserISIE()) {  // IE
            pluginDiv.innerHTML = '<object id="' + ctlName + '" classid="CLSID:' + CLSID + '" style="HEIGHT:0px; WIDTH:0px"></object>';
            if (addEvent) {
                var clt = eval(ctlName);
                if (clt.attachEvent) {
                    clt.attachEvent("OnUsbKeyChange", $OnUsbKeyChange);
                } else {// IE11 not support attachEvent, and addEventListener do not work well, so addEvent ourself
                    $AttachIE11OnUSBKeychangeEvent(ctlName);
                }
            }
        } else {
            var chromeVersion = window.navigator.userAgent.match(/Chrome\/(\d+)\./);
            if (chromeVersion && chromeVersion[1]) {
                if (parseInt(chromeVersion[1], 10) >= 42) { // not support npapi return false
                    document.body.removeChild(pluginDiv);
                    pluginDiv.innerHTML = "";
                    pluginDiv = null;
                    return false;
                }
            }

            if (addEvent) {
                pluginDiv.innerHTML = '<embed id=' + ctlName + ' type=application/x-xtx-axhost clsid={' + CLSID + '} event_OnUsbkeyChange=$OnUsbKeyChange width=0 height=0 />';
            } else {
                pluginDiv.innerHTML = '<embed id=' + ctlName + ' type=application/x-xtx-axhost clsid={' + CLSID + '} width=0 height=0 />';
            }
        }

        if (testFuncName != null && testFuncName != "" && eval(ctlName + "." + testFuncName) == undefined) {
            document.body.removeChild(pluginDiv);
            pluginDiv.innerHTML = "";
            pluginDiv = null;
            return false;
        }
        return true;
    } catch (e) {
        document.body.removeChild(pluginDiv);
        pluginDiv.innerHTML = "";
        pluginDiv = null;
        return false;
    }
}

function $XTXAlert(strMsg) {
    if (typeof $_$XTXAlert == 'function') {
        $_$XTXAlert(strMsg);
    } else {
        alert(strMsg);
    }
}

function $myOKRtnFunc(retVal, cb, ctx) {
    if (typeof cb == 'function') {
        var retObj = {retVal: retVal, ctx: ctx};
        cb(retObj);
    }
    return retVal;
}

//XTXAppCOM class
function CreateXTXAppObject() {
    var bOK = $LoadControl("3F367B74-92D9-4C5E-AB93-234F8A91D5E6", "XTXAPP", "SOF_GetVersion()", true);
	return bOK;
}


//webSocket client class
function CreateWebSocketObject(myonopen, myonerror) {

    var o = new Object();


    o.ws_obj = null;
    o.ws_heartbeat_id = 0;
    o.ws_queue_id = 0; // call_cmd_id
    o.ws_queue_list = {};  // call_cmd_id callback queue
    o.ws_queue_ctx = {};
    o.xtx_version = "";

    o.load_websocket = function () {

        var ws_url = "wss://127.0.0.1:21061/xtxapp/";
		ws_url = "ws://127.0.0.1:21051/xtxapp/";
        try {
            o.ws_obj = new WebSocket(ws_url);
        } catch (e) {
            console.log(e);
            return false;
        }

        o.ws_queue_list["onUsbkeyChange"] = $OnUsbKeyChange;

        o.ws_obj.onopen = function (evt) {
            if (myonopen) {
                myonopen();
            }

        };

        o.ws_obj.onerror = function (evt) {
            if (myonerror) {
                myonerror();
            }
        };

        o.ws_obj.onclose = function (evt) {

        };


        o.ws_obj.onmessage = function (evt) {

            var res = JSON.parse(evt.data);
            if (res['set-cookie']) {
                document.cookie = res['set-cookie'];
            }

            //登录失败
            if (res['loginError']) {
                alert(res['loginError']);
            }

            var call_cmd_id = res['call_cmd_id'];
            if (!call_cmd_id) {
                return;
            }

            var execFunc = o.ws_queue_list[call_cmd_id];
            if (typeof(execFunc) != 'function') {
                return;
            }

            var ctx = o.ws_queue_ctx[res['call_cmd_id']];
            ctx = ctx || {returnType: "string"};

            var ret;
            if (ctx.returnType == "bool") {
                ret = res.retVal == "true" ? true : false;
            }
            else if (ctx.returnType == "number") {
                ret = Number(res.retVal);
            }
            else {
                ret = res.retVal;
            }
            var retObj = {retVal: ret, ctx: ctx};

            execFunc(retObj);

            if (res['call_cmd_id'] != "onUsbkeyChange") {
                delete o.ws_queue_list[res['call_cmd_id']];
            }
            delete o.ws_queue_ctx[res['call_cmd_id']];

        };

        return true;
    };


    o.sendMessage = function (sendMsg) {
        if (o.ws_obj.readyState == WebSocket.OPEN) {
            o.ws_obj.send(JSON.stringify(sendMsg));
        } else {
            setTimeout(function () {
                if (sendMsg.count) {
                    sendMsg.count++;
                    if (sendMsg.count === 4) {
                        return;
                    }
                }
                else {
                    sendMsg.count = 1;
                }
                o.sendMessage(sendMsg);
            }, 500);
            console.log("Can't connect to WebSocket server!");
        }
    };

    o.callMethod = function (strMethodName, cb, ctx, returnType, argsArray) {
        console.log("mmmmm--="+strMethodName, cb, ctx, returnType, argsArray);
        o.ws_queue_id++;
        if (typeof(cb) == 'function') {
            o.ws_queue_list['i_' + o.ws_queue_id] = cb;
            ctx = ctx || {};
            ctx.returnType = returnType;
            o.ws_queue_ctx['i_' + o.ws_queue_id] = ctx;
        }

        var sendArray = {};
        sendArray['cookie'] = document.cookie;
        sendArray['xtx_func_name'] = strMethodName;
        sendArray['call_cmd_id'] = 'i_' + o.ws_queue_id;


        if (arguments.length > 4) {
            sendArray["param"] = argsArray;
        }
        o.sendMessage(sendArray);

    };

    if (!o.load_websocket()) {
        return null;
    }
    return o;
}


//Interface 
var ComInterface 		= 	{};
var WebsocketInterface 	= 	{};
var CurrentInterface    = 	{};

ComInterface.GetAllDeviceSN = function(cb,ctx){
	var ret = XTXAPP.GetAllDeviceSN();
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.GetAllDeviceSN = function(cb,ctx){
	var paramArray = [];
	WebsocketApp.callMethod('GetAllDeviceSN', cb, ctx, "string", paramArray);
}

ComInterface.SOF_GetAllContainerName = function(sDeviceSN,cb,ctx){
	var ret = XTXAPP.SOF_GetAllContainerName(sDeviceSN);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_GetAllContainerName = function(sDeviceSN,cb,ctx){
	var paramArray = [sDeviceSN];
	WebsocketApp.callMethod('SOF_GetAllContainerName', cb, ctx, "string", paramArray);
}


ComInterface.GetContainerCount = function(sDeviceSN,cb,ctx){
	var ret = XTXAPP.GetContainerCount(sDeviceSN);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.GetContainerCount = function(sDeviceSN,cb,ctx){
	var paramArray = [sDeviceSN];
	WebsocketApp.callMethod('GetContainerCount', cb, ctx, "number", paramArray);
}

ComInterface.SOF_Login = function(CertID,PassWd,cb,ctx){
	var ret = XTXAPP.SOF_Login(CertID,PassWd);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_Login = function(CertID,PassWd,cb,ctx){
	var paramArray = [CertID,PassWd];
	WebsocketApp.callMethod('SOF_Login', cb, ctx, "bool", paramArray);
}


ComInterface.SOF_GetUserList = function(cb,ctx){
	var ret = XTXAPP.SOF_GetUserList();
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_GetUserList = function(cb,ctx){
	var paramArray = [];
	WebsocketApp.callMethod('SOF_GetUserList', cb, ctx, "string", paramArray);
}

ComInterface.SOF_ChangePassWd = function(CertID,oldPass,newPass,cb,ctx){
	var ret = XTXAPP.SOF_ChangePassWd(CertID,oldPass,newPass);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_ChangePassWd = function(CertID,oldPass,newPass,cb,ctx){
	var paramArray = [CertID,oldPass,newPass];
	WebsocketApp.callMethod('SOF_ChangePassWd', cb, ctx, "bool", paramArray);
}


ComInterface.SOF_ExportUserCert = function(CertID,cb,ctx){
	var ret = XTXAPP.SOF_ExportUserCert(CertID);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_ExportUserCert = function(CertID,cb,ctx){
	var paramArray = [CertID];
	WebsocketApp.callMethod('SOF_ExportUserCert', cb, ctx, "string", paramArray);
}

ComInterface.SOF_ExportExChangeUserCert = function(CertID,cb,ctx){
	var ret = XTXAPP.SOF_ExportExChangeUserCert(CertID);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_ExportExChangeUserCert = function(CertID,cb,ctx){
	var paramArray = [CertID];
	WebsocketApp.callMethod('SOF_ExportExChangeUserCert', cb, ctx, "string", paramArray);
}


ComInterface.SOF_GetCertInfo = function (Cert, type, cb, ctx) {
	var ret = XTXAPP.SOF_GetCertInfo(Cert,type);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_GetCertInfo = function (Cert, type, cb, ctx) {
    console.log("ie" + Cert, type, cb, ctx);
	var paramArray = [Cert,type];
	WebsocketApp.callMethod('SOF_GetCertInfo', cb, ctx, "string", paramArray);
}

ComInterface.GetDeviceInfo = function(sDeviceSN,iType,cb,ctx){
	var ret = XTXAPP.GetDeviceInfo(sDeviceSN,iType);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.GetDeviceInfo = function(sDeviceSN,iType,cb,ctx){
	var paramArray = [sDeviceSN,iType];
	WebsocketApp.callMethod('GetDeviceInfo', cb, ctx, "string", paramArray);
}

ComInterface.SOF_SignData = function(CertID,InData,cb,ctx){
	var ret = XTXAPP.SOF_SignData(CertID,InData);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_SignData = function(CertID,InData,cb,ctx){
	var paramArray = [CertID,InData];
	WebsocketApp.callMethod('SOF_SignData', cb, ctx, "string", paramArray);
}


ComInterface.SOF_VerifySignedData = function(Cert,InData,SignValue,cb,ctx){
	var ret = XTXAPP.SOF_VerifySignedData(Cert,InData,SignValue);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_VerifySignedData = function(Cert,InData,SignValue,cb,ctx){
	var paramArray = [Cert,InData,SignValue];
	WebsocketApp.callMethod('SOF_VerifySignedData', cb, ctx, "bool", paramArray);
}

ComInterface.SOF_SignFile = function(CertID,InFile,cb,ctx){
	var ret = XTXAPP.SOF_SignFile(CertID,InFile);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_SignFile = function(CertID,InFile,cb,ctx){
	var paramArray = [CertID,InFile];
	WebsocketApp.callMethod('SOF_SignFile', cb, ctx, "string", paramArray);
}

ComInterface.SOF_VerifySignedFile = function(Cert,InFile,SignValue,cb,ctx){
	var ret = XTXAPP.SOF_VerifySignedFile(Cert,InFile,SignValue);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_VerifySignedFile = function(Cert,InFile,SignValue,cb,ctx){
	var paramArray = [Cert,InFile,SignValue];
	WebsocketApp.callMethod('SOF_VerifySignedFile', cb, ctx, "bool", paramArray);
}

ComInterface.SOF_EncryptData = function(Cert,InData,cb,ctx){
	var ret = XTXAPP.SOF_EncryptData(Cert,InData);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_EncryptData = function(Cert,InData,cb,ctx){
	var paramArray = [Cert,InData];
	WebsocketApp.callMethod('SOF_EncryptData', cb, ctx, "string", paramArray);
}


ComInterface.SOF_DecryptData = function(CertID,InData,cb,ctx){
	var ret = XTXAPP.SOF_DecryptData(CertID,InData);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_DecryptData = function(CertID,InData,cb,ctx){
	var paramArray = [CertID,InData];
	WebsocketApp.callMethod('SOF_DecryptData', cb, ctx, "string", paramArray);
}

ComInterface.SOF_HashData = function(hashAlg,sInData,cb,ctx){
	var ret = XTXAPP.SOF_HashData(hashAlg,sInData);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.SOF_HashData = function(hashAlg,sInData,cb,ctx){
	var paramArray = [hashAlg,sInData];
	WebsocketApp.callMethod('SOF_HashData', cb, ctx, "string", paramArray);
}

ComInterface.XJCA_CertAuth_Online = function(WebserviceAddr,Appid,Certid,cb,ctx){
	var ret = XTXAPP.XJCA_CertAuth_Online(WebserviceAddr,Appid,Certid);
	return $myOKRtnFunc(ret, cb, ctx);
}
	
	
WebsocketInterface.XJCA_CertAuth_Online = function(WebserviceAddr,Appid,Certid,cb,ctx){
	var paramArray = [WebserviceAddr,Appid,Certid];
	WebsocketApp.callMethod('XJCA_CertAuth_Online', cb, ctx, "string", paramArray);
}

ComInterface.SOF_GenRandom = function (RandomLen, cb, ctx) {
    var ret = XTXAPP.SOF_GenRandom(RandomLen);
    return $myOKRtnFunc(ret, cb, ctx);
}


WebsocketInterface.SOF_GenRandom = function (RandomLen, cb, ctx) {
    var paramArray = [RandomLen];
    WebsocketApp.callMethod('SOF_GenRandom', cb, ctx, "string", paramArray);
}




ComInterface.SOF_SymEncryptFile = function ( sKey, inFile,  outFile, cb, ctx) {
    var ret = XTXAPP.SOF_SymEncryptFile(sKey, inFile, outFile);
    return $myOKRtnFunc(ret, cb, ctx);
}


WebsocketInterface.SOF_SymEncryptFile = function (sKey, inFile, outFile, cb, ctx) {
    var paramArray = [sKey, inFile, outFile];
    WebsocketApp.callMethod('SOF_SymEncryptFile', cb, ctx, "bool", paramArray);
}



ComInterface.SOF_SymDecryptFile = function (sKey, inFile, outFile, cb, ctx) {
    var ret = XTXAPP.SOF_SymDecryptFile(sKey, inFile, outFile);
    return $myOKRtnFunc(ret, cb, ctx);
}


WebsocketInterface.SOF_SymDecryptFile = function (sKey, inFile, outFile, cb, ctx) {
    var paramArray = [sKey, inFile, outFile];
    WebsocketApp.callMethod('SOF_SymDecryptFile', cb, ctx, "bool", paramArray);
}

ComInterface.SOF_SetEncryptMethod = function (EncryptMethod, cb, ctx) {
    var ret = XTXAPP.SOF_SetEncryptMethod(EncryptMethod);
    return $myOKRtnFunc(ret, cb, ctx);
}


WebsocketInterface.SOF_SetEncryptMethod = function (EncryptMethod, cb, ctx) {
    var paramArray = [EncryptMethod];
    WebsocketApp.callMethod('SOF_SetEncryptMethod', cb, ctx, "string", paramArray);
}


//init_Interface
function init_Interface(func,altename)
{
	window[func] = function(){
		CurrentInterface[func].apply(this,arguments);
	}
	
	if(altename){
		window[altename] = window[func];
	}
	
}
init_Interface("GetAllDeviceSN");
init_Interface("SOF_GetAllContainerName","GetAllContainerName");
init_Interface("GetContainerCount");
init_Interface("SOF_Login","VerifyUserPIN");
init_Interface("SOF_GetUserList","GetUserList");
init_Interface("SOF_ChangePassWd","ChangeUserPassword");
init_Interface("SOF_ExportUserCert","GetSignCert");
init_Interface("SOF_ExportExChangeUserCert","GetExchCert");
init_Interface("SOF_GetCertInfo","GetCertBasicinfo");
init_Interface("GetDeviceInfo","GetDeviceType");
init_Interface("SOF_SignData","SignedData");
init_Interface("SOF_VerifySignedData","VerifySignedData");
init_Interface("SOF_SignFile","SignFile");
init_Interface("SOF_VerifySignedFile","VerifySignFile");
init_Interface("SOF_EncryptData","EncodeP7Enveloped");
init_Interface("SOF_DecryptData","DecodeP7Enveloped");
init_Interface("SOF_HashData", "HashData");

init_Interface("SOF_GenRandom", "GenRandom");
init_Interface("SOF_SymEncryptFile", "SymEncryptFile");

init_Interface("SOF_SymDecryptFile", "SymDecryptFile");
init_Interface("SOF_SetEncryptMethod", "SetEncryptMethod");

init_Interface("XJCA_CertAuth_Online");


// set custom usbkeychange callback
export function SetOnUsbKeyChangeCallBack(callback) 
{
	$_$onUsbKeyChangeCallBackFunc = callback;
	console.log('设置了ukeychange事件')
}



//初始化
export function XJCA_init(success, error){
	var b = CreateXTXAppObject();
	if(b){
		CurrentInterface = ComInterface;
		success();
		return;
	}
	
	WebsocketApp = CreateWebSocketObject(success, error);
	if(WebsocketApp){
		CurrentInterface = WebsocketInterface;
	}
}
