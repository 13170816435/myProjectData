import {
  BJCA_init, SetOnUsbKeyChangeCallBack
} from './bjca.XTXSAB'

export class BJCA {
  constructor(obj) {
    this.vue = obj.vue
    this.signData = obj.signData // 签名原文
    this.certID = obj.caUniqueId // 用户证书字符串
    this.certBase64 = '' // 用户证书base64编码
    this.signCallBack = obj.signCallBack // 签名回调
    this.signCallData = { // 返回出去的值
      signValue: '', // 加密后的签名值
      timeStamp: '', // 时间戳
      certID: this.certID // 证书编号
    }
    this.usbKeyChange = obj.usbKeyChange // ukey插拔回调
  }

  // 初始化ca
  initCa() {
    const _this = this
    if (this.usbKeyChange) {
      SetOnUsbKeyChangeCallBack(this.usbKeyChange)
    }
    BJCA_init(() => {
      console.log('ca连接成功')
      console.log("准备调用获取用户列表方法")
      // 获取用户列表
      SOF_GetUserList((obj) => {
        console.log("调用了获取用户列表方法")
        console.log(obj)
        if (obj.retVal === '') {
          this.vue.$message.error('证书获取失败，请检查是否插入U-key')
        } else {
          var arr = obj.retVal.split('&&&')
          arr = arr.filter((item) => {
            return item.length > 0
          })
          if (arr.length > 1) {
            this.vue.$message.error('请只保留一个证书ukey')
            return
          }
          var str = obj.retVal.split('&&&')[0]
          if (this.certID) {
            if (str.indexOf(this.certID) === -1) {
              this.vue.$message.error('您不是该证书的使用者')
              return
            }
            // 获取用户证书 base64 编码
            SOF_ExportUserCert(_this.certID, (obj) => {
              _this.certBase64 = obj.retVal
              // 效验证书有效性
              _this.caValidate()
            })
          } else {
            var arr = str.split('/')
            str = arr[1]
            _this.certID = str
          }
          console.log(_this.certID)
        }
      })
    }, () => {
      this.vue.$message.error('证书获取失败，请检查是否插入U-key')
    })
  }

  // 校验证书有效性
  caValidate () {
    const _this = this
    SOF_ValidateCert(_this.certBase64, (obj) => {
      console.log('证书有效性', obj)
      if (obj.retVal === 0) {
        // 登录ca
        _this.caLogin()
      } else if (obj.retVal === -1) {
        this.vue.$message.error('证书不被信任')
      } else if (obj.retVal === -2) {
        this.vue.$message.error('超过有效期范围')
      } else if (obj.retVal === -3) {
        this.vue.$message.error('证书已作废')
      } else if (obj.retVal === -4) {
        this.vue.$message.error('证书已冻结')
      } else if (obj.retVal === -5) {
        this.vue.$message.error('证书未生效')
      } else if (obj.retVal === -6) {
        this.vue.$message.error('其他')
      }
    })
  }

  // 登录
  caLogin () {
    const _this = this
    var password = sessionStorage.getItem('BJCApassword')
    if (!password) {
      this.vue.$prompt('请输入密码', '北京CA登录', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        beforeClose (action, instance, done) {
          if (action === 'confirm') {
            var pwd = instance.inputValue
            if (!pwd || pwd.length === 0) {
              _this.vue.$message.error('请输入密码')
              return
            }
            SOF_Login(_this.certID, pwd, (obj) => {
              console.log('证书登录密码返回值', obj)
              if (obj.retVal) {
                console.log('ca登录成功')
                // sessionStorage.setItem('BJCApassword', pwd)
                if (_this.signData) {
                  // 数据签名
                  _this.caSignData()
                }
                done()
              } else {
                _this.vue.$message.error('密码错误')
                _this.getRetryCount().then(res => {
                  if (!res) {
                    done()
                  }
                })
              }
            })
          }
        }
      })
    } else {
      SOF_Login(_this.certID, password, (obj) => {
        if (obj.retVal) {
          console.log('ca登录成功')
          if (_this.signData) {
            // 数据签名
            _this.caSignData()
          }
        } else {
          _this.vue.$message.error('密码错误')
          // sessionStorage.removeItem('BJCApassword')
          _this.caLogin()
        }
      })
    }
  }

  // 登录失败情况下-获取证书重复口令次数
  getRetryCount () {
    const _this = this
    return new Promise((resolve) => {
      SOF_GetPinRetryCount(_this.certID, (obj) => {
        if (obj.retVal > 0) {
          resolve(true)
        } else if (obj.retVal === 0) {
          _this.vue.$message.error('证书已被锁死，请联系管理员')
          resolve(false)
        } else {
          resolve(true)
        }
      })
    })
  }

  // 数据签名
  caSignData () {
    const _this = this
    SOF_SignData(_this.certID, _this.signData, res => {
      if (!res.retVal) {
        _this.vue.$message.error('获取签名值失败')
      } else {
        this.signCallData.signValue = res.retVal
        _this.signCallBack && _this.signCallBack(this.signCallData)
      }
    })
  }

  // 获取证书
  getCertID () {
    return this.certID
  }

}
