import { isIe, CerticateCollectionX } from './hbca.multibrowser'

export class HBCA {
    constructor(obj) {
        this.vue = obj.vue
        this.certID = obj.caUniqueId // 用户证书字符串
        this.signData = obj.signData // 原始签名值
        this.signCallBack = obj.signCallBack // 回调
        this.certs = null // 证书对象
        this.signedData = null // 签名值
        this.certsArr = [] // 证书数组对象
        this.pin = null // 证书密码
        this.verify = obj.verify // 验签需要数据
    }

    initCa() {
        if (isIe()) {
            //IE浏览器
            this.certs = document.getElementById("UCAPI")
        } else {
            //非IE浏览器
            this.certs = new CerticateCollectionX()
        }
        //根据属性设置过滤条件(1表示使用SKF接口，2表示CSP(CSP不能枚举SM2证书)，)
        this.certs.setCryptoInterface(1)
        //获取签名证书(0x20签名证书，0x10加密证书)
        this.certs.setCF_KeyUsage(0x20)
        //加载证书集返回值等于0表示成功
        let loadResult = this.certs.Load()
        let len = this.certs.getSize()
        if (loadResult != 0 || len < 1) {
            this.vue.$message.error('未获取到证书')
            return
        }
        this.certsArr = new Array(len)
        for (let i = 0; i < len; i++) {
            this.certsArr[i] = this.certs.GetAt(i);
        }
        // 默认选择第一个
        this.signCert = this.certsArr[0]
        if (this.signData) {
            this.sign()
        }
    }

    // 签名
    sign() {
        let _this = this
        // 验证证书是否在有效期
        let notTime = this.signCert.getNotAfterSystemTime()
        let notTimestamp = ''
        let nowTimestamp = (new Date()).getTime()
        notTime = notTime.replace(/-|:/g, ' ')
        notTime = notTime.split(' ')
        notTimestamp = (new Date(notTime[0], notTime[1], notTime[2], notTime[3], notTime[4], notTime[5])).getTime()
        if (nowTimestamp > notTimestamp) {
            this.vue.$message.error('证书已过期')
            return
        }
        // 验证是否为证书持有者
        let keyId = this.getCertID()
        if (keyId !== this.certID) {
            this.vue.$message.error('您不是该证书的持有者')
            return
        }
        //验证密码
        this.pin = sessionStorage.getItem('hbcapwd')
        if (!this.pin) {
            this.vue.$prompt('请输入密码', '湖北CA登录', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                inputType: 'password',
                beforeClose(action, instance, done) {
                    if (action === 'confirm') {
                        let pwd = instance.inputValue
                        if (!pwd || pwd.length === 0) {
                            _this.vue.$message.error('请输入密码')
                            return
                        }
                        _this.pin = pwd
                        if (!_this.verify) {
                            // 获取签名值
                            _this.getSignData()
                        } else {
                            // 数据验签
                            _this.verifySignedData()
                        }
                        done()
                    } else {
                        done()
                    }
                }
            })
        } else {
            if (!this.verify) {
                // 获取签名值
                this.getSignData()
            } else {
                // 数据验签
                this.verifySignedData()
            }
        }
    }

    // 获取key序列号
    getCertID() {
        return this.signCert.getSerialNumber()
    }

    // 获取算法
    GetInfoFromSealResultData(key) {
        return this.signCert.getAlgorithm()
    }

    // 获取签名值
    getSignData() {
        //设置pin码
        this.signCert.setUserPIN(this.pin)
        //签名(0表示attach，1表示detach)
        this.signedData = this.signCert.PKCS7String(this.signData, 1)
        if (!this.signedData || this.signedData == "") {
            this.vue.$message.error("获取签名值失败！" + this.signCert.getErrorString())
            return
        }
        sessionStorage.setItem('hbcapwd', this.pin)
        this.signCallBack && this.signCallBack({
            caCertificate: this.signCert.getContent(), // 证书64位编码
            signValue: this.signedData, // 签名值
            certificateSn: this.getCertID(),
            algorithm: this.GetInfoFromSealResultData()
        })
    }

    // 数据验签
    verifySignedData() {
        let res = this.signCert.PKCS7Verify(this.verify.signData, this.verify.signValue)
        if (res != 0) {
            this.vue.$message.error('数据验签失败')
        } else {
            this.vue.$message({
                type: 'success',
                message: '数据验签成功'
            })
        }
    }
}