import { XJCA_init, SetOnUsbKeyChangeCallBack } from './xjca.sab'
// 新疆CA 封装
export class XJCA {
  constructor (obj) {
    this.vue = obj.vue // VUE this
    this.signData = obj.signData // 签名原文
    this.certID = obj.caUniqueId // 用户证书字符串
    this.certBase64 = '' // 用户证书base64编码
    this.signCallBack = obj.signCallBack // 签名回调
    this.signCallData = { // 返回出去的值
      signValue: '', // 加密后的签名值
      certificateSn: '', // 证书序列号
      caCertificate: this.certBase64, // 证书64编码
    }
    this.usbKeyChange = obj.usbKeyChange // ukey插拔回调
    this.verify = obj.verify // 验签需要数据
  }

  // 初始化ca
  initCa() {
    const _this = this
    if (this.usbKeyChange) {
      SetOnUsbKeyChangeCallBack(this.usbKeyChange)
    }
    XJCA_init(() => {
      console.log('ca连接成功')
      // 获取用户列表
      SOF_GetUserList((obj) => {
        console.log(obj)
        if (obj.retVal === '') {
          this.vue.$message.error('证书获取失败，请检查是否插入U-key')
          this.signCallBack(null)
        } else {
          var arr = obj.retVal.split('&&&')
          arr = arr.filter((item) => {
            return item.length > 0
          })
          if (arr.length > 1) {
            this.vue.$message.error('请只保留一个证书ukey')
            this.signCallBack(null)
            return
          }
          var str = obj.retVal.split('&&&')[0]
          if (this.certID) {
            if (str.indexOf(this.certID) === -1) {
              this.vue.$message.error('您不是该证书的使用者')
              this.signCallBack(null)
              return
            }
            // 获取用户证书 base64 编码
            SOF_ExportUserCert(_this.certID, (obj) => {
              if (obj.retVal) {
                _this.certBase64 = obj.retVal
                _this.signCallData.caCertificate = this.certBase64
                // 获取证书基本信息并且验证证书的有效性
                _this.getCertInfo()
              } else {
                _this.vue.$message.error('导出用户证书失败')
                _this.signCallBack(null)
                return
              }
            })
          } else {
            var arr = str.split('||')
            str = arr[1]
            _this.certID = str
          }
          console.log('当前证书的ID：', _this.certID)
        }
      })
    }, () => {
      this.vue.$message.error('证书获取失败，请检查是否插入U-key')
      this.signCallBack(null)
    })
  }

  // 证书基本信息
  getCertInfo () {
    const _this = this
    // 获取证书序列号
    SOF_GetCertInfo(_this.certBase64, 2, res => {
      if (res.retVal) {
        _this.signCallData.certificateSn = res.retVal
        if (_this.signData) {
          // 数据签名
          _this.caSignData()
        }
        if (_this.verify) {
          // 数据验签
          _this.verifySignedData()
        }
      } else {
        _this.vue.$message.error('获取证书基本信息失败')
        _this.signCallBack(null)
        return
      }
    })
  }

  // 数据签名
  async caSignData () {
    const _this = this
    SOF_SignData(_this.certID, _this.signData, res => {
      if (!res.retVal) {
        _this.vue.$message.error('获取签名值失败')
        _this.signCallBack(null)
      } else {
        this.signCallData.signValue = res.retVal
        _this.signCallBack && _this.signCallBack(this.signCallData)
      }
    })
  }

  // 获取证书ukey序列号
  getCertID () {
    return this.certID
  }

  // 数据验签
  verifySignedData () {
    const _this = this
    SOF_VerifySignedData(_this.certBase64, _this.verify.signData, _this.verify.signValue, res => {
      if (!res.retVal) {
        _this.vue.$message.error('数据验签失败')
        _this.signCallBack(null)
      } else {
        _this.signCallData.signValue = res.retVal
        _this.vue.$message({
          type: 'success',
          message: '数据验签成功'
        })
      }
    })
  }
}
