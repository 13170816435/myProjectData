
import {
  getCaAuthStatus,
  postCaAuth,
  postCaPush,
  postCaVerify
} from '@/api/yunshangfuyouApi/ability'
// 获取用户是否已认证
export function caAuthStatus () {
  return new Promise((resolve, reject) => {
    getCaAuthStatus().then(caState => {
      if (caState.code !== 0) {
        this.$message.error(caState.msg)
        return
      }
      if (caState.data == 0) {
        reject()
      } else if (caState.data == 1) {
        resolve()
      }
    })
  })
}

// ca用户鉴权
export function caAuth (obj) {
  return new Promise((resolve, reject) => {
    postCaAuth({
      user_id: obj.userId,
      tenancy_id: obj.tenancyId
    }).then(res => {
      if (res.code !== 0) {
        this.$message.error(res.caAuth)
        return
      }
      resolve(res.data.qr_code_image)
    })
  })
}

// 显示二维码弹窗
export function caCodeClose (done) {
  clearInterval(this.caCodeTimer)
  this.caCodeState = false
  done()
}

// 推送签名
export function caPush (obj) {
  return new Promise(resolve => {
    postCaPush({
      remark: obj.remark,
      kind: obj.kind,
      ca_type: obj.openCaType,
      business_id: obj.businessId,
      original_text: JSON.stringify(obj.originalText),
      tenancy_id: obj.tenancyId
    }).then(res => {
      if (res.code !== 0) {
        this.$message.error(res.msg)
        return
      }
      resolve()
    })
  })
}

export function caVerify (obj) {
  return new Promise((resolve, reject) => {
    if (obj.caProducer == 3) {
      if (obj.openCaType == 1) {
        obj.originalText.usb_key = null
      }
      // 湖北ca走接口验签
      postCaVerify({
        business_id: obj.businessId,
        kind: obj.kind,
        original_text: JSON.stringify(obj.originalText),
        tenancy_id: obj.tenancyId
      }).then(res => {
        if (res.code !== 0) {
          reject(res.msg)
          return
        }
        resolve(res)
      })
    }
  })
}
