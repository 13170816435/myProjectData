import { BJCA } from '@/utils/ca/bjca.use'
import { HBCA } from '@/utils/ca/hbca.use'

const ca = {
    getCAsignValue (caType) {
        let num = ''
        if (caType == 3) {
          // 湖北ca
          let hbca = new HBCA({
            vue: this
          })
          hbca.initCa()
          num = hbca.getCertID()
        } else {
          // 北京CA
          let bjca = new BJCA({
            vue: this
          })
          bjca.initCa()
          num = bjca.getCertID()
        }
        return num
    }
}