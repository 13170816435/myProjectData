/**
 * 初始化连接
 * @param {object} option 参数
 * @param {string} option.url 连接的url地址
 * @param {Number} option.errrorNum 错误重试次数
 * @param {function} option.onOpen 连接成功回调
 * @param {function} option.onMessage 消息回调
 * @param {function} option.onClose 连接关闭回调
 * @param {function} option.onError 连接关闭回调
 * @returns {object} 连接的实例
 */
// var ws
var reconnectCount = 1
var lockReconnect = false // 避免重复连接
function initWebSocket (option) {
  var ws = null
  // var reconnectCount = 1
  // var lockReconnect = false // 避免重复连接
  ws = new WebSocket(option.url)
  // 连接成功回调
  ws.onopen = function (e) {
    console.log('连接成功到:' + lockReconnect, option.url, option, e)
    if (option.onOpen !== undefined) {
      option.onOpen()
    }
  }
  // 消息回调
  ws.onmessage = option.onMessage
  // var retryCount =option.errrorNum
  // 连接关闭
  // ws.onclose = option.onClose
  ws.onclose = function (event) {
    // console.log('websocket 断开: ' + option.url)
    if (option.onClose !== undefined) {
      option.onClose(0)
      if (reconnectCount >= 3) {
        reconnectCount = 1
        option.onClose(-1)
        return
      }
      if (lockReconnect) return
      lockReconnect = true

      setTimeout(function () {
        reconnectCount += 1
        initWebSocket(option)
        lockReconnect = false
      }, 500)
    }
  }
  ws.onError = option.onError
  // console.log('ssssssssssssssssssssssss', ws)
  // debugger
  return ws
}

export {
  initWebSocket
}
