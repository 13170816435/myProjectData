import axios from 'axios'

export class ThirdUpload {
  constructor (obj) {
    this.eleId = obj.eleId // inputid
    this.inputFileName = obj.inputFileName // 上传文件名称
    this.uploadUrl = obj.uploadUrl // 上传地址
    this.callback = obj.callback // 回调函数
    this.businessId = obj.businessId // 业务唯一号
    this.businessType = obj.businessType // 业务类型 影像-EaxmDiagnosis，心电-ExamDiagnosis  会诊-Consult
    this.classCode = obj.classCode // 影像-DiagnosisRequest， 心电-DiagnosisRequest， 会诊-ConsultRequest
    // this.systemId = obj.systemId // 服务中心id
    this.orgCode = obj.orgCode // 机构唯一号
    // this.departCode = obj.departCode // 检查科室代码
    // this.modality = obj.modality //检查类型
    this.partLength = 1024 * 1024 * 5 // 分段上传长度，默认5M
    this.queueList = [] // 上传队列
    this.failList = [] // 失败队列
    this.dom = document.getElementById(this.eleId)
  }

  getUuid () {
    var _time = new Date().getTime()
    var guid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = (_time + Math.random() * 16) % 16 | 0
      _time = Math.floor(_time / 16)
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16)
    })
    return guid
  }

  // 设置上传队列--文件选择时触发 paras-资料配置项
  setUploadQueue (paras) {
    if (this.dom.files.length === 0) {
      return
    }
    // this.queueList
    // 判断队列是否有相同文件
    for (var i = 0; i < this.dom.files.length; i++) {
      var _fileId = this.getUuid()
      var _file = this.dom.files[i]
      // 获取相同文件
      var sameFile = this.queueList.filter(item => {
        return item.requestParas.file_name === _file.name && item.requestParas.file_size === _file.size
      })
      if (sameFile.length > 0) {
        this.callback.sameCallBack && this.callback.sameCallBack(_file)
        break
      }
      
      var year = _file.lastModifiedDate.getFullYear()
      var month = _file.lastModifiedDate.getMonth() + 1
      var date = _file.lastModifiedDate.getDate()
      var hour = _file.lastModifiedDate.getHours()
      var minute = _file.lastModifiedDate.getMinutes()
      var second = _file.lastModifiedDate.getSeconds()
      console.log('资料修改时间', `${year}-${month}-${date} ${hour}:${minute}:${second}`)
      var FORMATCODE_ARR = {
        DICOMDIR: 'ExamImage',
        SECTION: 'ExamImage',
        AECG: 'ExamImage',
      }
      var _data = {
        file: this.dom.files[i],
        fileId: _fileId,
        start: 0,
        end: this.partLength,
        pecent: 0,
        reUpload: false, // 需要重新上传
        fileParent: paras,
        // 上传参数
        requestParas: {
          BusinessID: this.businessId,
          BusinessType: this.businessType,
          ClassCode: this.classCode,
          TypeCode: FORMATCODE_ARR[paras.format_code],
          // business_time: `${year}-${month}-${date} ${hour}:${minute}:${second}`,
          FormatCode: paras.format_code,
          FileName: _file.name,
          FileSize: _file.size,
          Position: 0,
          // ServiceCenterId: this.systemId,
          // modality: this.modality,
          OrganizationID: this.orgCode,
          // depart_code: this.departCode,
          UniqueID: paras.id,
          FileCreateUserID: '',
          FileCreateUserName: ''
        }
      }
      this.queueList.push(_data)
      if (this.callback) {
        this.callback.insert && this.callback.insert(_data)
      }
    }
  }

  // 获取文件分割片段
  getSplitData (queue) {
    queue.end = queue.end <= 0 ? this.partLength : queue.end
    queue.requestParas.Position = queue.start
    if (queue.start < queue.end) {
      var blob = queue.file.slice(queue.start, queue.end)
      var fd = new FormData()
      fd.append(this.inputFileName, blob)
      for (var key in queue.requestParas) {
        fd.append(key, queue.requestParas[key])
      }
      return fd
    }
    return null
  }

  // 文件片段上传成功回调
  uploadSuccess (res) {
    var _queue = this.queueList[0]
    if (!_queue) return
    
    if (res.position) {
      _queue.end = Number(res.position)
      _queue.pecent = 100 * (_queue.end / _queue.file.size)
    }
    if (this.callback) {
      this.callback.process && this.callback.process(_queue)
    }
    if (res.UniqueID) {
      if (this.callback) {
        this.callback.finish && this.callback.finish(_queue)
      }
      this.queueList.shift()
      this.uploadStart()
    } else {
      _queue.start = _queue.end
      _queue.end = _queue.end + this.partLength
      this.uploadStart()
    }
  }

  // 文件片段上传失败回调
  uploadFailure (queue, res) {
    if (res) {
      var errorTitle = res.toString()
      var errorText = ''
      if (errorTitle.indexOf('Cannot determine compressed stream type. Supported Archive Formats: Zip, GZip, Tar, Rar, 7Zip, LZip') > -1) {
        errorText = '文件格式不对，支持：Zip, GZip, Tar, Rar, 7Zip, LZip'
      } else if (errorTitle.indexOf('MakeDicomDir失败') >= 0) {
        errorText = '压缩包内不能包含文件夹，且文件格式必须为DCM格式影像文件'
      } else {
        errorText = '上传失败'
      }
      queue.errorText = errorText
    } else {
      queue.errorText = ''
    }
    this.failList.push(queue) // 添加到失败队列
    this.queueList.shift()
    if (this.callback) {
      this.callback.error && this.callback.error(queue)
    }
    this.uploadStart()
  }

  // 开始上传
  uploadStart () {
    if (this.queueList.length === 0) {
      if (this.callback) {
        this.callback.complete && this.callback.complete()
      }
      return
    }
    var queue = this.queueList[0]
    var _this = this
    var _url = this.uploadUrl + '?'
    for (var key in queue.requestParas) {
      _url = _url + key + '=' + queue.requestParas[key] + '&'
    }
    _url = _url.substr(0, _url.length - 1)
    axios.post(_url, this.getSplitData(queue))
    .then(res => {
      if (res.data.position || res.data.UniqueID) {
        _this.uploadSuccess(res.data)
      } else {
        queue.start = 0
        queue.end = _this.partLength
        _this.uploadFailure(queue, res.data)
      }
    }).catch((res) => {
      _this.uploadFailure(queue, res.data)
    })
  }

  // 重新上传失败文件
  uploadRecover () {
    if (this.failList.length > 0) {
      for (var i = 0; i < this.failList.length; i++) {
        this.queueList.push(this.failList[i])
      }
      if (this.queueList.length > 0) {
        this.uploadStart()
        this.failList = []
      }
    }
  }

  // 获取上传失败列表
  getFailList () {
    return this.failList
  }

  // 删除上传队列文件
  deleleQueue (queue) {
    var index = this.queueList.findIndex(item => {
      return item.fileId === queue.fileId
    })
    this.queueList.splice(index, 1)
    // 删除失败列表
    var index1 = this.failList.findIndex(item => {
      return item.fileId === queue.fileId
    })
    this.failList.splice(index1, 1)
  }

  // 获取上传队列
  getQueueList () {
    return this.queueList
  }

  // 设置上传队列
  setQueueList (arr) {
    this.queueList = arr
  }
  
}
