const testFontArr = [] // 检测数组
export const testFont = {
  data () {
    return {
      allFonts: [],
      confirmFonts: [],
      SexArr: [],
      textSex: ''
    }
  },
  mounted () {
    this.DicDefineAll()
  },
  methods: {
    testFontconfirm (item, callback) {
      var msg = ''
      var _this = this
      // if (item.name === '疾病名称') {
      //   msg = '检测出疾病名称【' + item.dic_define_value + '】--------是否添加疾病报卡？'
      // } else if (item.name === '危急值') {
      //   msg = '检测出危急字段【' + item.critical_value + '】--------是否添加危急报告？'
      // }
      _this.confirmFonts.push(item) // 避免重复检测
      if (item.name === '疾病名称' || item.name === '危急值') {
        // _this.$confirm(msg, '提示', {
        //   confirmButtonText: '确定',
        //   cancelButtonText: '取消',
        //   type: 'warning'
        // }).then(() => {
        //   callback(item)
        // }).catch(() => {
        // })
      } else {
        var Arr = this.SexArr
        var NewItem = {
          name: this.textSex,
          dic_define_value: ''
        }
        if (this.SexArr.length) {
          var obj = {}
          Arr = Arr.reduce(function (item, next) {
            obj[next.dic_define_value] ? '' : obj[next.dic_define_value] = true && item.push(next)
            return item
          }, [])
          var String = ''
          Arr.forEach(item => {
            String = String + item.dic_define_value + ','
          })
          NewItem.dic_define_value = String
        }
        callback(NewItem)
      }
    },
    // text 输入的字符， IsClear 点击下一个要清空已处理过的数据，是否清空, callback 回调函数
    testFont (IsClear, text, info, callback) {
      this.$nextTick(() => {
        var _this = this
        if (IsClear) {
          _this.allFonts = testFontArr
          _this.confirmFonts = []
          _this.SexArr = [] // 男女特性检测清空
        } else {
          _this.allFonts = testFontArr
          var Arr = _this.allFonts
          _this.SexArr = []
          if (info.sex.indexOf('男') != -1) {
             _this.textSex = '女性特征' 
          } else { 
            _this.textSex = '男性特征' 
          }
          if (Arr.length && text) {
            Arr.forEach(item => {
              if (_this.textSex === item.name && (text.indexOf(item.dic_define_value) !== -1)) {
                _this.SexArr.push(item)
              }
            })
            if (_this.SexArr.length) {
              _this.testFontconfirm({ name: _this.textSex }, callback)
            } else {
              _this.testFontconfirm({ name: _this.textSex }, callback)
            }
          } else {
            callback && callback()
          }
        }
      })
    },
    async DicDefineAll () {
      let data = []
      data = ['FemaleCharacteristics', 'MaleCharacteristics']
      const params = {
        code: data
      }
      var _this = this
      _this.$pacsApi.pacsApi.DicDefineAll(params).then(res => {
        const resData = res.data || []
        resData.forEach(item => {
          if (item.dic_type_code === 'MaleCharacteristics') {
            var Arr = item.define_list || []
            Arr.forEach(function (i) {
              i.name = '男性特征'
              testFontArr.push(i)
            })
          }
          if (item.dic_type_code === 'FemaleCharacteristics') {
            var Arrs = item.define_list || []
            Arrs.forEach(function (j) {
              j.name = '女性特征'
              testFontArr.push(j)
            })
          }
        })
      })
    }
  }
}