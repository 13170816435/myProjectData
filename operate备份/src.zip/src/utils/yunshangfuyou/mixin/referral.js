// 会诊状态，类型，方式等公共过滤器
import { getDict, getMedDict } from '@/api/referral'
import commonMixin from '@/views/telemedicine/mixins/commonMixin'
import Mgr from '../SecurityService'
const mixin = {
  mixins: [commonMixin],
  methods: {
    // 年龄
    ageFormatter (row) {
      if (row.age) {
        return row.age + '' + row.age_unit
      }
    },
    // 获取数据字典--机构
    async getDictList (key) {
      var res = await getDict({ lookup_key: key })
      if (res.code === 0) {
        return res.data
      } else {
        this.$message.error(res.msg)
        return []
      }
    },
    // 获取远程医疗数据字典
    async getMedDictList (key) {
      var res = await getMedDict(key)
      if (res.code === 0) {
        return res.data
      } else {
        this.$message.error(res.msg)
        return []
      }
    },
    // 性别
    patientSex (detail) {
      detail.patient_sex = Number(detail.patient_sex)
      if (detail.patient_sex === 0) {
        return '未知'
      } else if (detail.patient_sex === 1) {
        return '男性'
      } else if (detail.patient_sex === 2) {
        return '女性'
      } else {
        return '未说明'
      }
    },
    // 婚姻
    maritalStatus (num) {
      if (num === 10) {
        return '未婚'
      } else if (num === 20) {
        return '已婚'
      } else if (num === 21) {
        return '初婚'
      } else if (num === 22) {
        return '再婚'
      } else if (num === 23) {
        return '复婚'
      } else if (num === 30) {
        return '丧偶'
      } else if (num === 40) {
        return '离婚'
      } else {
        return '未说明'
      }
    },
    // 就诊卡类型
    attendCardType (num) {
      num = Number(num)
      if (num === 0) {
        return '社保卡'
      } else if (num === 1) {
        return '医保磁卡'
      } else if (num === 2) {
        return '统一自费就诊卡'
      } else if (num === 3) {
        return '非统一自费就诊卡'
      } else if (num === 9) {
        return '其他卡'
      }
    },
    // 患者证件类型
    ddCardType (num) {
      num = Number(num)
      if (num === 100001) {
        return '身份证'
      } else if (num === 100002) {
        return '军官证'
      } else if (num === 100003) {
        return '护照'
      } else if (num === 100004) {
        return '居民户口簿'
      } else if (num === 100005) {
        return '外国人永久居留证'
      } else if (num === 100006) {
        return '武警证'
      } else if (num === 100010) {
        return '学生证'
      } else if (num === 100016) {
        return '港澳居民来往内地通行证'
      } else if (num === 100017) {
        return '台湾居民来往大陆通行证'
      } else if (num === 100018) {
        return '其他证件'
      }
    },
    // 获取登录用户信息
    async getTokenInfo () {
      const manager = new Mgr()
      const user = await manager.getRole()
      return user
    },
    // 点名专家
    expertFormatter (row) {
      return row.consult_expert_names.join(',')
    },
    // 转诊资料
    imageView (detail) {
      var businessType = 7
      var path = process.env.NODE_ENV === 'development' ? '/' : '/telemedicine/'
      var newPage = this.$router.resolve({
        path: `${path}consult/imageView`,
        query: {
          id: detail.id,
          historyType: 40,
          businessType: businessType
        }
      })
      window.open(newPage.href, '_blank')
    }
  },
  filters: {
    // 秒转为时分秒
    formatSeconds (value) {
      const result = parseInt(value)
      const h = Math.floor(result / 3600) < 10 ? '0' + Math.floor(result / 3600) : Math.floor(result / 3600)
      const m = Math.floor((result / 60 % 60)) < 10 ? '0' + Math.floor((result / 60 % 60)) : Math.floor((result / 60 % 60))
      const s = Math.floor((result % 60)) < 10 ? '0' + Math.floor((result % 60)) : Math.floor((result % 60))
      let res = ''
      if (h !== '00') res += `${h}时`
      if (m !== '00') res += `${m}分`
      res += `${s}秒`
      return res
    },
    // 病情分级
    LevelCode (state) {
      if (state === 'A') {
        return 'A级濒危'
      } else if (state === 'B') {
        return 'B级危重'
      } else if (state === 'C') {
        return 'C级急症'
      } else if (state === 'D') {
        return 'D级非急症'
      } else if (state === '1') {
        return '急诊'
      } else if (state === '0') {
        return '普通'
      }
    },
    // 转诊状态
    referralState (state) {
      if (state === 5) {
        return '已申请'
      } else if (state === 10) {
        return '转出审核通过'
      } else if (state === 20) {
        return '转入审核通过'
      } else if (state === 30) {
        return '患者履约'
      } else if (state === -1) {
        return '已取消'
      } else if (state === -2) {
        return '转出审核不通过'
      } else if (state === -3) {
        return '转入审核不通过'
      } else if (state === -4) {
        return '患者爽约'
      }
    },
    // 就诊诊类别
    patientKind (kind) {
      if (kind === 10) {
        return '门诊'
      } else if (kind === 20) {
        return '住院'
      }
    },
    // 显示星期几
    showWeekDay (date) {
      var date = new Date(date)
      var week = '('+['周日','周一','周二','周三','周四','周五','周六'][date.getDay()]+')'
      return week
    },
    // 只显示 月 日
    showMonthAndDay (date) {
      var date = new Date(date)
      var month = (date.getMonth()+1)+'/'
      var day = date.getDate()
      return month+day
    },
    // 会诊方式
    consultClass (type) {
      if (type === 'InteractiveConsultation') {
        return '交互式会诊'
      } else if (type === 'NoneInteractiveConsultation') {
        return '非交互式会诊'
      } else if (type === 'RealTimeConsultation') {
        return '实时会诊'
      }
    },
    // 会诊类型
    consultKind (kind) {
      if (kind === 'RIS') {
        return '放射会诊'
      } else if (kind === 'ECGIS') {
        return '心电会诊'
      } else if (kind === 'UIS') {
        return '超声会诊'
      } else if (kind === 'PIS') {
        return '病理会诊'
      } else if (kind === 'CIS') {
        return '专科会诊'
      } else if (kind === 'MDT') {
        return '多学科会诊'
      }
    },
    // 检查项目
    examineDescs (list) {
      list = list || []
      return list.join(',')
    },
    // 就诊卡类型
    attendCardType (num) {
      num = Number(num)
      if (num === 0) {
        return '社保卡'
      } else if (num === 1) {
        return '医保磁卡'
      } else if (num === 2) {
        return '统一自费就诊卡'
      } else if (num === 3) {
        return '非统一自费就诊卡'
      } else if (num === 9) {
        return '其他卡'
      }
    },
    // 患者证件类型
    ddCardType (num) {
      num = Number(num)
      if (num === 100001) {
        return '身份证'
      } else if (num === 100002) {
        return '军人证'
      } else if (num === 100003) {
        return '护照'
      } else if (num === 100004) {
        return '居民户口簿'
      } else if (num === 100005) {
        return '外国人永久居留证'
      } else if (num === 100006) {
        return '武警证'
      } else if (num === 100010) {
        return '学生证'
      } else if (num === 100016) {
        return '港澳居民来往内地通行证'
      } else if (num === 100017) {
        return '台湾居民来往大陆通行证'
      } else if (num === 100018) {
        return '其他证件'
      }
    }
  }
}

export default mixin
