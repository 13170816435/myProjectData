import { formatDate } from './formatDate'
export default {
  install (vue, optioins) {
    // 验证身份证信息
    vue.prototype.$isIdCardNo = function (num) {
      var idcard = num
      if (idcard === '') {
        return true
      }
      var regex1 = /^[1-9][0-7]\d{4}((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})(((0[13578]|1[02])(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)(0[1-9]|[12][0-9]|30))|(02(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))0229))\d{3}(\d|X|x)?$/
      // 身份号码位数及格式检验
      switch (idcard.length) {
        case 15:
          var regex2 = ''
          if (
            (parseInt(idcard.substr(6, 2)) + 1900) % 4 === 0 ||
            ((parseInt(idcard.substr(6, 2)) + 1900) % 100 === 0 &&
              (parseInt(idcard.substr(6, 2)) + 1900) % 4 === 0)
          ) {
            regex2 = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$/ // 测试出生日期的合法性
          } else {
            regex2 = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$/ // 测试出生日期的合法性
          }
          if (regex2.test(idcard)) {
            return true
          } else {
            return false
          }
        case 18:
          if (regex1.test(idcard)) {
            var S =
              (parseInt(idcard[0]) + parseInt(idcard[10])) * 7 +
              (parseInt(idcard[1]) + parseInt(idcard[11])) * 9 +
              (parseInt(idcard[2]) + parseInt(idcard[12])) * 10 +
              (parseInt(idcard[3]) + parseInt(idcard[13])) * 5 +
              (parseInt(idcard[4]) + parseInt(idcard[14])) * 8 +
              (parseInt(idcard[5]) + parseInt(idcard[15])) * 4 +
              (parseInt(idcard[6]) + parseInt(idcard[16])) * 2 +
              parseInt(idcard[7]) * 1 +
              parseInt(idcard[8]) * 6 +
              parseInt(idcard[9]) * 3
            var Y = S % 11
            var M = 'F'
            var JYM = '10X98765432'
            M = JYM.substr(Y, 1)
            // 判断校验位
            if (M === idcard[17].toUpperCase()) {
              // alert(Errors[0]+"18");
              return true
            } else {
              // alert(Errors[3]);
              // showErrMsg = Errors[3];
              return false
            }
          } else {
            return false
          }
        default:
          // alert(Errors[1]);
          // showErrMsg = Errors[1];
          return false
      }
    }
    // 根据身份证获取年龄，性别，出生日期
    vue.prototype.$getInfoByIdCard = function (UUserCard, num) {
      if (num === 1) {
        // 获取出生日期
        const birth =
          UUserCard.substring(6, 10) +
          '-' +
          UUserCard.substring(10, 12) +
          '-' +
          UUserCard.substring(12, 14)
        return birth
      }
      if (num === 2) {
        // 获取性别
        if (parseInt(UUserCard.substr(16, 1)) % 2 === 1) {
          return '1'
        } else {
          return '2'
        }
      }
      if (num === 3) {
        // // 获取年龄
        // var myDate = new Date()
        // var month = myDate.getMonth() + 1
        // var day = myDate.getDate()
        // var age = myDate.getFullYear() - UUserCard.substring(6, 10) - 1
        // if ((UUserCard.substring(10, 12) < month || UUserCard.substring(10, 12) === month) && UUserCard.substring(12, 14) <= day) {
        //   age++
        // }
        // return age
        // 获取用户的身份证号码
        const identityCard = UUserCard.replace(/\s+/g, '')
        // 判断长度
        const len = identityCard.length
        // 设置新的变量
        var strBirthday = ''
        // 根据长度获取年月日
        if (len == 18) {
          strBirthday =
            identityCard.substr(6, 4) +
            '/' +
            identityCard.substr(10, 2) +
            '/' +
            identityCard.substr(12, 2)
        }
        if (len == 15) {
          strBirthday =
            '19' +
            identityCard.substr(6, 2) +
            '/' +
            identityCard.substr(8, 2) +
            '/' +
            identityCard.substr(10, 2)
        }
        // 格式化用户的年月日信息
        const birthDate = new Date(strBirthday)
        // 创建新的年月日信息
        const nowDateTime = new Date()
        // 新的年份 -  用户年份
        var age = nowDateTime.getFullYear() - birthDate.getFullYear()
        // 通过月份最终获取用户年龄
        if (
          nowDateTime.getMonth() < birthDate.getMonth() ||
          (nowDateTime.getMonth() == birthDate.getMonth() &&
            nowDateTime.getDate() < birthDate.getDate())
        ) {
          age--
        }
        return age
      }
    }
    // 获取默认时间 timeLength：时长 timeType：小于0向前，大于0向后
    vue.prototype.$getDefaultTime = function (timeLength, timeType) {
      let end = new Date()
      let start = new Date()
      if (timeType > 0) {
        end.setTime(end.getTime() + 3600 * 1000 * 24 * timeLength)
      } else {
        start.setTime(start.getTime() - 3600 * 1000 * 24 * timeLength)
      }
      let month = start.getMonth() + 1
      month = month > 9 ? month : '0' + month
      let day = start.getDate()
      day = day > 9 ? day : '0' + day
      start = start.getFullYear() + '-' + month + '-' + day
      let emonth = end.getMonth() + 1
      emonth = emonth > 9 ? emonth : '0' + emonth
      let eday = end.getDate()
      eday = eday > 9 ? eday : '0' + eday
      end = end.getFullYear() + '-' + emonth + '-' + eday
      return [start, end]
    }
    // 替换\r\n
    vue.prototype.$replaceRN = function (str) {
      str = str || ''
      var newStr = str.replace(/\n/g, '<br>')
      return newStr
      // return str.replace(/\r\n/g, '<br>')
    }
    // 手机号验证
    vue.prototype.$isPhoneNumber = function (str) {
      // var reg = /^1(3|4|5|7|8)\d{9}$/
      var reg = /^\d{11}$/
      if (reg.test(str)) {
        return true
      } else {
        return false
      }
    }
    // 获取url参数
    vue.prototype.$getUrlValue = function (name) {
      var reg = new RegExp(`(^|&)${name}=([^&]*)(&|$)`, 'i')
      var r = null
      if (window.location.href.indexOf('#') === -1) {
        r = window.location.search.substr(1).match(reg)
      } else {
        var search = window.location.href.split('?')
        if (search.length > 1) {
          r = search[1].match(reg)
        }
      }
      if (r != null) {
        r[2] = decodeURI(r[2])
        return unescape(r[2])
      }
      return null
    }
    //
    // 根据出生日期返回生日跟生日单位 传入出生日期date 2017-10-01
    vue.prototype.$AgeAndAgeUit = function (date) {
      var birArr = date.split('-')
      var birYear = birArr[0]
      var birMonth = birArr[1]
      var birDay = birArr[2]
      var d = new Date()
      var nowYear = d.getFullYear()
      var nowMonth = d.getMonth() + 1 // 记得加1
      var nowDay = d.getDate()
      var item = {
        Age: '',
        AgeUit: '岁'
      }
      if (birArr == null) {
        return item
      }
      if (parseInt(nowYear) === parseInt(birYear)) {
      } else {
        var ageDiff = parseInt(nowYear) - parseInt(birYear)
        item.AgeUit = '岁'
        if (ageDiff > 0) {
          if (nowMonth === birMonth) {
            var dayDiff = parseInt(nowDay) - parseInt(birDay)
            if (dayDiff < 0) {
              item.Age = ageDiff - 1
              return item
            } else {
              item.Age = ageDiff
              return item
            }
          } else {
            var monthDiff = parseInt(nowMonth) - parseInt(birMonth)
            if (monthDiff < 0) {
              item.Age = ageDiff - 1
              return item
            } else {
              item.Age = ageDiff
              return item
            }
          }
        }
      }
      return item
    }
    // 根据年龄和年龄单位，得到出生日期
    vue.prototype.$BirthData = function (age, ageUit) {
      var item = ''
      if (!age) {
        return ''
      }
      if (ageUit === '岁') {
        var d = new Date()
        var nowYear = d.getFullYear()
        item = nowYear - parseInt(age) + '-01-01'
      } else if (ageUit === '月') {
        var d = new Date()
        var temp = 30 * 24 * 60 * 60 * 1000 * age
        const difference = (d.getTime() - temp) / 1000
        item = formatDate(difference).split(' ')[0]
      } else if (ageUit === '周') {
        var d = new Date()
        var temp = 7 * 24 * 60 * 60 * 1000 * age
        const difference = (d.getTime() - temp) / 1000
        item = formatDate(difference).split(' ')[0]
      } else if (ageUit === '日' || ageUit === '天') {
        var d = new Date()
        var temp = 24 * 60 * 60 * 1000 * age
        const difference = (d.getTime() - temp) / 1000
        item = formatDate(difference).split(' ')[0]
      }
      return item
    }
  }
}
