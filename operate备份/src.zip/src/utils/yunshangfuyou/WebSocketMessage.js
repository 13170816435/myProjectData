import { initWebSocket } from './WebSocket.js'
import eventBus from '@/utils/eventBus'
var wsService
var WebSocketParam = {
  scanningSnapshot: function (e) {},
  videoCallback: function (e) {},
  printCallback: function (e) {},
  onErrorClose: function (e) {},
  openSuc: function (e) {},
  getPrintList: function (e) {}

}
var communicationport = 7081
// 设置的端口号改变
eventBus.$on('getPort', msg => {
  communicationport = msg
})
// 初始化weosocket
function initWebSockets () {
  wsService = initWebSocket({
    url: 'ws://127.0.0.1:' + communicationport,
    onOpen: function () {
      WebSocketParam.openSuc()
    },
    onMessage: function (event) {
      if (isString(event.data)) {
        var ret = JSON.parse(event.data)
        // console.log(ret)
        if (ret.code !== 0) {
          // alert('服务异常，请确认')
        } else {
          if (ret.type === 'scanningSnapshot') {
            WebSocketParam.scanningSnapshot(ret.msg)
          }
          if (ret.type === 'print') {
            WebSocketParam.printCallback(ret.msg)
          }
          if (ret.type === 'get_print_devices' || ret.type === 'get_scan_devices') {
            WebSocketParam.getPrintList(ret)
          }
        }
      } else {
        var reader = new FileReader()
        reader.onload = function (eve) {
          // 判断文件是否读取完成
          if (eve.target.readyState === FileReader.DONE) {
            WebSocketParam.videoCallback(this.result)
          }
        }
        reader.readAsDataURL(event.data)
      }
    },
    onClose: function (event) {
      WebSocketParam.onErrorClose(event)
    },
    onError: function (event) {
      WebSocketParam.onErrorClose(event)
    }
  })
}
function isString (str) {
  return (typeof str === 'string') && str.constructor === String
}
// initWebSockets()
export {
  wsService,
  WebSocketParam,
  initWebSockets
}
