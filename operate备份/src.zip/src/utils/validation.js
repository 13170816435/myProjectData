export default {
  install (vue, optioins) {
    // 验证身份证信息
    vue.prototype.$isIdCardNo = function (num) {
      var idcard = num
      if (idcard === '') {
        return true
      }
      var regex1 = /^[1-9][0-7]\d{4}((([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})(((0[13578]|1[02])(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)(0[1-9]|[12][0-9]|30))|(02(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))0229))\d{3}(\d|X|x)?$/
      // 身份号码位数及格式检验
      switch (idcard.length) {
        case 15:
          var regex2 = ''
          if ((parseInt(idcard.substr(6, 2)) + 1900) % 4 === 0 || ((parseInt(idcard.substr(6, 2)) + 1900) % 100 === 0 && (parseInt(idcard.substr(6, 2)) + 1900) % 4 === 0)) {
            regex2 = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$/// 测试出生日期的合法性
          } else {
            regex2 = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$/// 测试出生日期的合法性
          }
          if (regex2.test(idcard)) {
            return true
          } else {
            return false
          }
        case 18:
          if (regex1.test(idcard)) {
            var S = (parseInt(idcard[0]) + parseInt(idcard[10])) * 7 + (parseInt(idcard[1]) + parseInt(idcard[11])) * 9 + (parseInt(idcard[2]) + parseInt(idcard[12])) * 10 + (parseInt(idcard[3]) + parseInt(idcard[13])) * 5 + (parseInt(idcard[4]) + parseInt(idcard[14])) * 8 + (parseInt(idcard[5]) + parseInt(idcard[15])) * 4 + (parseInt(idcard[6]) + parseInt(idcard[16])) * 2 + parseInt(idcard[7]) * 1 + parseInt(idcard[8]) * 6 + parseInt(idcard[9]) * 3
            var Y = S % 11
            var M = 'F'
            var JYM = '10X98765432'
            M = JYM.substr(Y, 1)
            // 判断校验位
            if (M === idcard[17].toUpperCase()) {
              // alert(Errors[0]+"18");
              return true
            } else {
              // alert(Errors[3]);
              // showErrMsg = Errors[3];
              return false
            }
          } else {
            return false
          }
        default:
          // alert(Errors[1]);
          // showErrMsg = Errors[1];
          return false
      }
    }
    // 获取url参数
    vue.prototype.$getUrlValue = function (name) {
      var reg = new RegExp(`(^|&)${name}=([^&]*)(&|$)`, 'i')
      var r = null
      if (window.location.href.indexOf('#') === -1) {
        r = window.location.search.substr(1).match(reg)
      } else {
        var search = window.location.href.split('?')
        if (search.length > 1) {
          r = search[1].match(reg)
        }
      }
      if (r != null) {
        r[2] = decodeURI(r[2])
        return unescape(r[2])
      }
      return null
    },
    // 获取url参数
    vue.prototype.$getUrlValue = function (name) {
      var reg = new RegExp(`(^|&)${name}=([^&]*)(&|$)`, 'i')
      var r = null
      if (window.location.href.indexOf('#') === -1) {
        r = window.location.search.substr(1).match(reg)
      } else {
        var search = window.location.href.split('?')
        if (search.length > 1) {
          r = search[1].match(reg)
        }
      }
      if (r != null) {
        r[2] = decodeURI(r[2])
        return unescape(r[2])
      }
      return null
    }
    // 根据身份证获取年龄，性别，出生日期
    vue.prototype.$getInfoByIdCard = function (UUserCard, num) {
      if (num === 1) {
        // 获取出生日期
        const birth = UUserCard.substring(6, 10) + '-' + UUserCard.substring(10, 12) + '-' + UUserCard.substring(12, 14)
        return birth
      }
      if (num === 2) {
        // 获取性别
        if (parseInt(UUserCard.substr(16, 1)) % 2 === 1) {
          return 1
        } else  {
          return 2
        }
      }
      if (num === 3) {
        // 获取年龄
        var myDate = new Date()
        var month = myDate.getMonth() + 1
        var day = myDate.getDate()
        var age = myDate.getFullYear() - UUserCard.substring(6, 10) - 1
        if ((UUserCard.substring(10, 12) < month || UUserCard.substring(10, 12) === month) && UUserCard.substring(12, 14) <= day) {
          age++
        }
        return age
      }
    }
    // 获取默认时间 timeLength：时长 timeType：小于0向前，大于0向后
    vue.prototype.$getDefaultTime = function (timeLength, timeType) {
      let end = new Date()
      let start = new Date()
      if (timeType > 0) {
        end.setTime(end.getTime() + 3600 * 1000 * 24 * timeLength)
      } else {
        start.setTime(start.getTime() - 3600 * 1000 * 24 * timeLength)
      }
      let month = start.getMonth() + 1
      month = month > 9 ? month : '0' + month
      let day = start.getDate()
      day = day > 9 ? day : '0' + day
      start = start.getFullYear() + '-' + month + '-' + day
      let emonth = end.getMonth() + 1
      emonth = emonth > 9 ? emonth : '0' + emonth
      let eday = end.getDate()
      eday = eday > 9 ? eday : '0' + eday
      end = end.getFullYear() + '-' + emonth + '-' + eday
      return [start, end]
    }
    // 替换\r\n
    vue.prototype.$replaceRN = function (str) {
      str = str || ''
      return str.replace(/\r\n/g, '<br>')
    }

    /**
     * 节流原理：在一定时间内，只能触发一次
     * 
     * @param {Function} func 要执行的回调函数 
     * @param {Number} wait 延时的时间
     * @param {Boolean} immediate 是否立即执行
     * @return null
     */
    vue.prototype.$throttle = (awaitTime=2000) => {
      let startTimer = 0;
        //节流  一段时间只能执行一次 使用时间戳控制
        const retrunStopUpDown =  (fun, ...arrAgu) =>{
        if (typeof fun !== 'function') return
          let endTimer = new Date().getTime()
            if (endTimer - startTimer > awaitTime) {
              fun( ...arrAgu)
              startTimer = new Date().getTime()
            }
        }
        return retrunStopUpDown
      }
  }
}
