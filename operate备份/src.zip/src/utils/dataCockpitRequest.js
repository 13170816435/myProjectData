import axios from 'axios'
import Mgr from './SecurityService'

const service = axios.create({})
service.defaults.baseURL = process.env.NODE_ENV === 'development'?'/statistics': configUrl.apiUrl + '/statistics'
// 开发环境的话 用下面的
// service.defaults.baseURL = process.env.NODE_ENV === 'development'?'/api-imgbd/statistics': configUrl.apiUrl + '/api-imgbd/statistics'
service.defaults.headers['Content-Type'] = 'application/json;charset=UTF-8'
service.defaults.withCredentials = true
// 是否需要账号登录 才能访问页面
function noNeedLogin () {
  if ((_dataCockpitName == 'fogangxian' || _dataCockpitName == 'dongyang') && window.location.href.indexOf('/platformDataCockpit/index') != -1) {
    return true
  } else if (_dataCockpitName == 'jinhua' && window.location.href.indexOf('/customerDataCockpit/index') != -1) {
    return true
  } else {
    return false
  }
}
// request interceptor
service.interceptors.request.use(
  async config => {
    return Promise.resolve(config)
    if (config.url === '/api-operate/software-products') { // 平台运营-产品管理-产品包下载地址
      config.baseURL = configUrl.docUrl
    }
    // if (config.url.split('/')[1].toLocaleLowerCase() === 'callapi') { // 叫号系统api地址
    //   config.baseURL = configUrl.callapiurl
    // }
    if (config.method === 'get') {
    }
    config.headers.SystemId = sessionStorage.getItem('lastname')
    // 如果是服务中心管理的话 hearder头部需要增加这个字段
    if (JSON.parse(sessionStorage.getItem('isServiceCenterManage'))) {
      config.headers.DiagnosisMode = 'RemoteDiagnosis'
      config.headers.SystemId = sessionStorage.getItem('serviceCenterId')
    }
    try {
      if (!noNeedLogin()) {
        const manager = new Mgr()
        user = await manager.getRole()
        config.headers.common.Authorization = user.token_type + ' ' + user.access_token
      }
      return Promise.resolve(config)
    }
    catch (error) {
      return Promise.reject(error)
    }
  },
  error => {
    console.log(error)
    return Promise.reject(error)
  }
)

// response interceptor
service.interceptors.response.use(
  response => response.data,
  async error => {
    const status = error.response ? error.response.status : null
    if (status === 401) {
      if(window.hasOwnProperty('_dataCockpitName')) {
        if (!noNeedLogin()) {
          const manager = new Mgr()
          manager.signOut()
        }
      }else {
        // localStorage.removeItem('loginInfo')
        const manager = new Mgr()
        manager.signOut()
      }
      // const config = error.config
      // if (!config.__isRetryRequest) {
      //   try {
      //     const manager = new Mgr()
      //     const user = await manager.getRole()
      //     config.__isRetryRequest = true
      //     config.headers.common.Authorization = user.token_type + ' ' + user.access_token
      //     return service(config)
      //   }
      //   catch (error_1) {
      //     const manager = new Mgr()
      //     manager.signIn()
      //     return Promise.reject(error_1)
      //   }
      // }
    } else if (status === 404) {
      // rejected 状态会阻止异步程序继续执行
      // ，因此，必须将返回状态修正为resolved
      return Promise.resolve();
    }
    return Promise.reject(error)
  }
)

export default service
