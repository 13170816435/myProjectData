import axios from 'axios'
import Mgr from './SecurityService'
import qs from 'qs'
const service = axios.create({})

function setAxiosConfig () {
  // if (_dataCockpitName == 'yinzhouzhikong' && window.location.pathname.indexOf('/customerDataCockpit/index') !== -1) {
  //   service.defaults.baseURL = yzApiUrl
  // } else {
  //   service.defaults.baseURL = configUrl.apiUrl
  // }
  //alert(configUrl.apiUrl)
  service.defaults.baseURL = configUrl.apiUrl
  if (typeof _dataCockpitName !== 'undefined' && _dataCockpitName == 'jinhua' && window.location.href.indexOf('/customerDataCockpit/index') != -1) {
    service.defaults.baseURL = configUrl.apiUrl
  }
  service.defaults.headers['Content-Type'] = 'application/json;charset=UTF-8'
  service.defaults.withCredentials = true

  function generateReqKey(config) {
    const { method, url, params, data } = config;
    return [method, url, qs.stringify(params), qs.stringify(data)].join("&");
  }
  const pendingRequest = new Map();
  function addPendingRequest(config) {
    const requestKey = generateReqKey(config);
    config.cancelToken = config.cancelToken || new axios.CancelToken((cancel) => {
      if (!pendingRequest.has(requestKey)) {
         pendingRequest.set(requestKey, cancel);
      }
    });
  }
  function removePendingRequest(config) {
    const requestKey = generateReqKey(config);
    if (pendingRequest.has(requestKey)) {
       const cancelToken = pendingRequest.get(requestKey);
       cancelToken(requestKey);
       pendingRequest.delete(requestKey);
    }
  }

  // 是否需要账号登录 才能访问页面
  function noNeedLogin () {
    if (typeof _dataCockpitName !== 'undefined' && (_dataCockpitName == 'fogangxian' || _dataCockpitName == 'dongyang') && window.location.href.indexOf('/platformDataCockpit/index') != -1) {
      return true
    } else if (typeof _dataCockpitName !== 'undefined' && _dataCockpitName == 'jinhua' && window.location.href.indexOf('/customerDataCockpit/index') != -1) {
      return true
    } else {
      return false
    }
  }
  // request interceptor
  service.interceptors.request.use(
    async config => {
      if (config.method === 'get') {
      }
      if (sessionStorage.getItem('EWTenancyId')) {
        config.headers['TenancyId'] = sessionStorage.getItem('EWTenancyId')
      }
      if (sessionStorage.getItem('curTenancyId')) {
        config.headers['ew-tenancy-id'] = sessionStorage.getItem('curTenancyId')
      }
      const loginInforObj = JSON.parse(localStorage.getItem('loginInfo'))
      const locationPathName = window.location.pathname
      const requestUrl = config.url
      if (locationPathName.indexOf('/myDataStorage/storageDevice') !== -1  || locationPathName.indexOf('/myDataStorage/contentManage') !== -1 || locationPathName.indexOf('/operateFileView/index') !== -1 || locationPathName.indexOf('/operateFilePreview/index') !== -1  || requestUrl.indexOf('/upload/crm') !== -1 || requestUrl.indexOf('/download/crm-document-id') !== -1 || requestUrl.indexOf('/Documents/update-tag') !== -1) {
        config.headers.SystemType = 'CRM'
      }
      if (requestUrl.indexOf('/data-mining') != -1) { // 请求数据挖掘模块的接口时
        config.headers['TenancyId'] = sessionStorage.getItem('TenancyId')
      }
      config.headers.SystemId = sessionStorage.getItem('lastname')
      // 如果是服务中心管理的话 hearder头部需要增加这个字段
      if (JSON.parse(sessionStorage.getItem('isServiceCenterManage'))) {
        config.headers.DiagnosisMode = 'RemoteDiagnosis'
        config.headers.SystemId = sessionStorage.getItem('serviceCenterId')
      }

      try {
        let user
        // if (localStorage.getItem('loginInfo')) {
        //   user = JSON.parse(localStorage.getItem('loginInfo'))
        //   config.headers.common.Authorization = user.token_type + ' ' + user.access_token
        // } else {
        //   const manager = new Mgr()
        //   user = await manager.getRole()
        //   config.headers.common.Authorization = user.token_type + ' ' + user.access_token
        // }

        if (!noNeedLogin()) {
          const manager = new Mgr()
          user = await manager.getRole()
          config.headers.common.Authorization = user.token_type + ' ' + user.access_token
          //config.headers.common.Authorization = "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6Ijc5OEY4NTk0MTExMzE5NjE2NjEzOThCMkJGRTAyNTc1ODRCODY2N0IiLCJ0eXAiOiJhdCtqd3QiLCJ4NXQiOiJlWS1GbEJFVEdXRm1FNWl5di1BbGRZUzRabnMifQ.eyJuYmYiOjE3NTM5NDIyNjUsImV4cCI6MTc1Mzk4NTQ2NSwiaXNzIjoiaHR0cDovL29wZXJhdGUtb2F1dGgtY2VudGVyLmV3b3JsZGNsb3VkOjkwMTAvb2F1dGgiLCJhdWQiOlsiYXBpLW9wZXJhdGUiLCJhcGktY2xvdWRwYWNzIiwiYXBpLW1paXMiLCJhcGktcGlzIiwiYXBpLW5taXMiLCJhcGktZXBpcyIsImFwaS1ld2NzcyIsImFwaS1jYWxsaW5nIiwiYXBpLWRtcyIsImFwaS1pbWFnaW5nIiwiYXBpLWFyY2hpdmUiLCJhcGktYXNpcyIsImFwaS10ZWxlbWVkIiwiYXBpLXRlYWNoIiwiYXBpLWlkY2FzIiwiYXBpLXF1YWxpdHkiLCJhcGktaW1nYmQiLCJhcGktYWJpbGl0eSIsImFwaS1pbSIsImFwaS1wYWNzLWNvbW1vbiIsImFwaS1hc2lzLWFkbWluIiwiYXBpLWNvbXBhbnktd2Vic2l0ZSIsImFwaS1kZXZvcHMiLCJhcGktcnRpcyIsImFwaS1wb3J0YWwiLCJhcGktYWkiLCJhcGktY3NtcyIsImFwaS1jdWlzIiwiYXBpLWV3c3BzIl0sImNsaWVudF9pZCI6ImV3b3JsZC5zcGEuaW1hZ2VjbG91ZCIsInN1YiI6IjEyODg3MjA4NjM4NDMwNjE3NjAiLCJhdXRoX3RpbWUiOjE3NTM5NDIyNjUsImlkcCI6ImxvY2FsIiwibmFtZSI6IuW8oOW4hSIsImF2YXRhcl9pZCI6IjE4NjY4MDg3NTQ4OTUzNTU5MDQiLCJ0ZW5hbmN5X2lkIjoiMTI4ODcyMDg2MzY5NjI2MTEyMCIsImNhdGVnb3J5IjoiMTI0IiwidGlkIjoiODQ4QThBREJBQjU1QTc0QzRGNTFGRTREMTk1RUVEMTAiLCJjbGllbnRfYWdlbnQiOiJVbmtub3duIiwic2NvcGUiOlsib3BlbmlkIiwicHJvZmlsZSIsImFwaS1vcGVyYXRlIiwiYXBpLWNsb3VkcGFjcyIsImFwaS1taWlzIiwiYXBpLXBpcyIsImFwaS1ubWlzIiwiYXBpLWVwaXMiLCJhcGktZXdjc3MiLCJhcGktY2FsbGluZyIsImFwaS1kbXMiLCJhcGktaW1hZ2luZyIsImFwaS1hcmNoaXZlIiwiYXBpLWFzaXMiLCJhcGktdGVsZW1lZCIsImFwaS10ZWFjaCIsImFwaS1pZGNhcyIsImFwaS1xdWFsaXR5IiwiYXBpLWltZ2JkIiwiYXBpLWFiaWxpdHkiLCJhcGktaW0iLCJhcGktcGFjcy1jb21tb24iLCJhcGktYXNpcy1hZG1pbiIsImFwaS1jb21wYW55LXdlYnNpdGUiLCJhcGktZGV2b3BzIiwiYXBpLXJ0aXMiLCJhcGktcG9ydGFsIiwiYXBpLWFpIiwiYXBpLWNzbXMiLCJhcGktY3VpcyIsImFwaS1ld3NwcyJdLCJhbXIiOlsicHdkIl19.lks78-05N1rU2FtomEVae9SCLRYBx9l67lVtVpBoN-Q0UkJV1QGKsdNh8zYxZKN_tng_1dV7Hg8rTKKsWMPc7fZWPQIjbjUbu6j4wgZ23Cbt1pNbEdNtG0wP3Na9vy1G3QXJEKMaaSC2_tU4sRPDLsvSmxsr_Shcefmlw_gMqJMWLZiE5Dt914lUtVeoKvUOLLJfuE6-HIrFhSC1VwCHJqWzxjLfRhvV2HKtOeOAj0uLlM9kgceZfXC2dRZMSFhir-TMJ9eGILiWBMASN6n5XDcIW4wmabln5MmRJylBuBu_lXUIQRyNYRlDY2CaJ0O92cmcXg_iMEXzKwsioyOZGg"
        }

        //removePendingRequest(config) // 检查是否存在重复请求，若存在则取消已发的请求
        //addPendingRequest(config) // 把当前请求信息添加到pendingRequest对象中
        return Promise.resolve(config)
      }
      catch (error) {
        return Promise.reject(error)
      }
    },
    error => {
      console.log(error)
      return Promise.reject(error)
    }
  )

  // response interceptor
  service.interceptors.response.use(
    //response => response.data,
    (response) => {
      removePendingRequest(response.config); // 从pendingRequest对象中移除请求
      return response.data
    },
    async error => {
      const status = error.response ? error.response.status : null
      if (status === 401) {        
        window.sessionStorage.removeItem('EWTenancyId')
        window.sessionStorage.removeItem('curTenancyId')
        window.sessionStorage.removeItem('ChosedSystemName')
        window.sessionStorage.removeItem('noticeId')
        window.sessionStorage.removeItem('announceId')
        window.sessionStorage.removeItem('instituteListQueryObj')
        // 移出锁屏状态和锁屏时间字段
        window.sessionStorage.removeItem('screensaverState')
        window.sessionStorage.removeItem('screensaverTime')
        window.sessionStorage.removeItem('platFormName')
        window.sessionStorage.removeItem('menuArr')
        localStorage.setItem('isLockPage',false)
        window.localStorage.removeItem("loginStatus")
        if(window.hasOwnProperty('_dataCockpitName')) {
          if (!noNeedLogin()) {
            const manager = new Mgr()
            manager.signOut()
          }
        }else {
          // localStorage.removeItem('loginInfo')
          const manager = new Mgr()
          manager.signOut()
        }

        // const config = error.config
        // if (!config.__isRetryRequest) {
        //   try {
        //     const user = await manager.getRole()
        //     config.__isRetryRequest = true
        //     config.headers.common.Authorization = user.token_type + ' ' + user.access_token
        //     return service(config)
        //   }
        //   catch (error_1) {
        //     manager.signIn()
        //     return Promise.reject(error_1)
        //   }
        // }
      } else if (status === 404) {
        // rejected 状态会阻止异步程序继续执行
        // ，因此，必须将返回状态修正为resolved
        return Promise.resolve();
      }
      removePendingRequest(error.config || {}); // 从pendingRequest对象中移除请求
      if (axios.isCancel(error)) {
        console.log("已取消的重复请求：" + error.message);
      } else {
        // 添加异常处理
      }
      return Promise.reject(error)
    }
  )
}

export { setAxiosConfig }

export default service
