export const PARAM_CODE = 11

export const ECG_PRINT_SETTING = 'ecgPrintSettingUser'
export const ECG_PRINT_SETTING_SERVICE_CENTER = 'ecgPrintSettingServiceCenter'

export const ECG_PRINT_SETTING_FOR_USER = 'user'
export const ECG_PRINT_SETTING_FOR_SERVICE_CENTER = 'serviceCenter'

export const PARAM_TYPE_FOR_USER = 0
export const PARAMS_TYPE_FOR_SERVICE_CENTER = 3000
