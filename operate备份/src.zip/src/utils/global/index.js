export const ecgLayoutList = [
  {
    label: '默认',
    value: '1',
    list: [
      {
        label: '按照波形浏览参数打印',
        value: ''
      }
    ]
  },

  {
    label: '12导联',
    value: '12',
    list: [
      {label: '12x1', value: '12x1'},
      {label: '6x2', value: '6x2'},
      {label: '6x2+1', value: '6x2+1'},
      {label: '6x1四肢', value: '6x1四肢'},
      {label: '6x1胸部', value: '6x1胸部'},
      {label: '3x4', value: '3x4'},
      {label: '3x4+1', value: '3x4+1'},
      {label: '4x3', value: '4x3'},
      {label: '4x3+1', value: '4x3+1'},
      {label: '平均波', value: '平均波'}
    ]
  },

  {
    label: '15导联',
    value: '15',
    list: [
      {label: '5x3', value: '5x3'},
      {label: '5x3+1', value: '5x3+1'}
    ]
  },

  {
    label: '18导联',
    value: '18',
    list: [
      {label: '6x3', value: '6x3'},
      {label: '6x3+1', value: '6x3+1'}
    ]
  }
]
