import Cookies from 'js-cookie'

const TokenKey = 'CHIS_TOKEN'

export function getToken () {
  return Cookies.get(TokenKey)
}

export function setToken (token) {
  return Cookies.set(TokenKey, token)
}

export function removeToken () {
  return Cookies.remove(TokenKey)
}

export function getLS (key) {
  // return localStorage.getItem(key) ? JSON.parse(localStorage.getItem(key)) : ''
  return localStorage.getItem(key) || ''
}

export function setLS (key, value) {
  // localStorage.setItem(key, JSON.stringify(value))
  localStorage.setItem(key, value)
}

export function removeLS (key) {
  localStorage.removeItem(key)
}

export function getSS (key) {
  return sessionStorage.getItem(key) ? JSON.parse(sessionStorage.getItem(key)) : ''
}

export function setSS (key, value) {
  sessionStorage.setItem(key, JSON.stringify(value))
}
