/* eslint-disable */
import { saveAs } from 'file-saver'
import XLSX from 'xlsx-style'
var patt = new RegExp(/^(100|[1-9]?\d(\.\d\d?)?)%$/);//校验百分数
function returnNumFlg(val){
  let flag=false;
  if(val.includes("/")){
    const newArr=val.split("/");
    flag = newArr.every(vm=>!isNaN(Number(vm)));
  }
  return flag
}

function generateArray(table) {
  var out = [];
  var rows = table.querySelectorAll('tr');
  var ranges = [];
  for (var R = 0; R < rows.length; ++R) {
    var outRow = [];
    var row = rows[R];
    var columns = row.querySelectorAll('td');
    for (var C = 0; C < columns.length; ++C) {
      var cell = columns[C];
      var colspan = cell.getAttribute('colspan');
      var rowspan = cell.getAttribute('rowspan');
      var cellValue = cell.innerText;
      if (cellValue !== "" && cellValue == +cellValue) cellValue = +cellValue;
      //Skip ranges
      ranges.forEach(function (range) {
        if (R >= range.s.r && R <= range.e.r && outRow.length >= range.s.c && outRow.length <= range.e.c) {
          for (var i = 0; i <= range.e.c - range.s.c; ++i) outRow.push(null);
        }
      });
      //Handle Row Span
      if (rowspan || colspan) {
        rowspan = rowspan || 1;
        colspan = colspan || 1;
        ranges.push({
          s: {
            r: R,
            c: outRow.length
          },
          e: {
            r: R + rowspan - 1,
            c: outRow.length + colspan - 1
          }
        });
      };

      //Handle Value
      outRow.push(cellValue !== "" ? cellValue : null);

      //Handle Colspan
      if (colspan)
        for (var k = 0; k < colspan - 1; ++k) outRow.push(null);
    }
    out.push(outRow);
  }
  return [out, ranges];
};

function datenum(v, date1904) {
  if (date1904) v += 1462;
  var epoch = Date.parse(v);
  return (epoch - new Date(Date.UTC(1899, 11, 30))) / (24 * 60 * 60 * 1000);
}

//合并多层对象
function assiginObj(target = {},sources= {}){
    let obj = target;
    if(typeof target != 'object' || typeof sources != 'object'){
        return sources; // 如果其中一个不是对象 就返回sources
    }
    for(let key in sources){
        // 如果target也存在 那就再次合并
        if(target.hasOwnProperty(key)){
            obj[key] = assiginObj(target[key],sources[key]);
        } else {
            // 不存在就直接添加
            obj[key] = sources[key];
        }
    }
    return obj;
}

function sheet_from_array_of_arrays(data, opts, extraOptions){
  const optsKeys=Object.keys(opts);
  var ws = {};
  var range = {
    s: {
      c: 10000000,
      r: 10000000
    },
    e: {
      c: 0,
      r: 0
    }
  };
  for (var R = 0; R != data.length; ++R) {
    for (var C = 0; C != data[R].length; ++C) {
      if (range.s.r > R) range.s.r = R;
      if (range.s.c > C) range.s.c = C;
      if (range.e.r < R) range.e.r = R;
      if (range.e.c < C) range.e.c = C;
      var cell = {
        v: data[R][C]
      };
      if (cell.v == null) continue;
      var cell_ref = XLSX.utils.encode_cell({
        c: C,
        r: R
      });
      //设置默认换行
      cell['s'] = {
        alignment:{
            "wrapText": true,
        }
      }
      if(patt.test(cell.v) || !isNaN(Number(cell.v)) || returnNumFlg(cell.v)){ //判断数字和百分数或者"0/0"，居右
        cell['s'].alignment={
            ...cell.s.alignment,
            "horizontal": "right",
        }
      }
      if (typeof cell.v === 'number') cell.t = 'n';
      else if (typeof cell.v === 'boolean') cell.t = 'b';
      else if (cell.v instanceof Date) {
        cell.t = 'n';
        cell.z = XLSX.SSF._table[14];
        cell.v = datenum(cell.v);
      }else cell.t = 's';
      //添加样式
      if(optsKeys.findIndex(vm=>vm===cell_ref)!==-1){
          cell = assiginObj(cell,opts[cell_ref])//表头和页尾样式
      }else{
          if(extraOptions && extraOptions[cell_ref]){ //合并数据样式
            cell= assiginObj(cell,extraOptions[cell_ref])
          }
          var optsKeys_numArr = optsKeys.map(vm=>vm.replace(/[^0-9]/ig,""));
          var current_cell_ref = cell_ref.replace(/[^0-9]/ig,"");
          const flag = optsKeys_numArr.some(vm=>vm===current_cell_ref);
          if(!flag){//排除页头和页尾表格，给数据内容加边框
            cell.s = {
                ...cell.s,
                "border":{
                    'top':{ style: 'thin' },
                    'bottom':{ style: 'thin' },
                    'left':{ style: 'thin' },
                    'right':{ style: 'thin' },
                }
            }
          }
      }
      ws[cell_ref] = cell;
    }
  }
  if (range.s.c < 10000000) ws['!ref'] = XLSX.utils.encode_range(range);
  return ws;
}

function Workbook() {
  if (!(this instanceof Workbook)) return new Workbook();
  this.SheetNames = [];
  this.Sheets = {};
}

function s2ab(s) {
  var buf = new ArrayBuffer(s.length);
  var view = new Uint8Array(buf);
  for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
  return buf;
}

export function export_table_to_excel(id) {
  var theTable = document.getElementById(id);
  var oo = generateArray(theTable);
  var ranges = oo[1];

  /* original data */
  var data = oo[0];
  var ws_name = "SheetJS";

  var wb = new Workbook(),
    ws = sheet_from_array_of_arrays(data);
  /* add ranges to worksheet */
  // ws['!cols'] = ['apple', 'banan'];
  ws['!merges'] = ranges;

  /* add worksheet to workbook */
  wb.SheetNames.push(ws_name);
  wb.Sheets[ws_name] = ws;

  var wbout = XLSX.write(wb, {
    bookType: 'xlsx',
    bookSST: false,
    type: 'binary'
  });

  saveAs(new Blob([s2ab(wbout)], {
    type: "application/octet-stream"
  }), "test.xlsx")
}

export function export_json_to_excel({
  isMultipleHeader,//是否是多级表头
  multiHeader = [],
  header,
  data,
  filename,
  merges = [],
  autoWidth = true,
  bookType = 'xlsx',
  styleSheets= {}, //表格样式（页头和页尾）
  extraStyleSheets={},//表格样式（数据）
  footer=[],
} = {}) {
  /* original data */
  filename = filename || 'excel-list'
  data = [...data,...footer]
  data.unshift(header);
  for (let i = multiHeader.length - 1; i > -1; i--) {
    data.unshift(multiHeader[i])
  }
  var ws_name = "SheetJS";
  var wb = new Workbook(),
  ws = sheet_from_array_of_arrays(data,styleSheets,extraStyleSheets);

  if (merges.length > 0) {
    if (!ws['!merges']) ws['!merges'] = [];
    merges.forEach(item => {
      ws['!merges'].push(XLSX.utils.decode_range(item))
    })
  }

  if (autoWidth) {
    /*设置worksheet每列的最大宽度*/
    const header_leng = multiHeader.length
    let footer_leng=footer.length;
    const data_leng = data.length;
    let newdata=[];
    if(isMultipleHeader){//是否是多级表头
      newdata=data.slice(header_leng-1,data_leng-footer_leng);
    }else{
      newdata=data.slice(header_leng,data_leng-footer_leng);
    }
    let colWidth=[];
    newdata.forEach(item=>{
      item.forEach((vm,vm_index)=>{
        let res_wid=13;
        if(vm!==undefined&&vm!==null&&vm!==''){
          const tostr=vm.toString();
          let wid_sum=0;
          for(let i=0;i<tostr.length;i++){
            if(tostr.charCodeAt(i)>255){//中文
              wid_sum+=1
            }else{
              wid_sum+=0.5
            }
          }
          res_wid=wid_sum*3<13?13:wid_sum*3
        }
        if(colWidth[vm_index]!==undefined){
          if(colWidth[vm_index].wch<=res_wid){
            colWidth[vm_index].wch = res_wid
          }
        }else{
          colWidth.push({
            'wch': vm_index===0?res_wid+header_leng*2:res_wid
          })
        }
      })
    })
    ws['!cols'] = colWidth;
  }
  /* add worksheet to workbook */
  wb.SheetNames.push(ws_name);
  wb.Sheets[ws_name] = ws;
  var wbout = XLSX.write(wb, {
    bookType: bookType,
    bookSST: false,
    type: 'binary'
  });
  saveAs(new Blob([s2ab(wbout)], {
    type: "application/octet-stream"
  }), `${filename}.${bookType}`);
}