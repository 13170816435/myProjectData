import Vue from 'vue'
import store from '@/store'
// v-dialogDrag: 弹窗拖拽
// Vue.directive('dialogDrag', {
//   bind(el, binding, vnode, oldVnode) {
//     const dialogHeaderEl = el.querySelector('.el-dialog__header')
//     const dragDom = el.querySelector('.el-dialog')
//     dialogHeaderEl.style.cursor = 'move'

//     // 获取原有属性 ie dom元素.currentStyle 火狐谷歌 window.getComputedStyle(dom元素, null);
//     const sty = dragDom.currentStyle || window.getComputedStyle(dragDom, null)

//     dialogHeaderEl.onmousedown = (e) => {
//       // 鼠标按下，计算当前元素距离可视区的距离
//       const disX = e.clientX - dialogHeaderEl.offsetLeft
//       const disY = e.clientY - dialogHeaderEl.offsetTop

//       // 获取到的值带px 正则匹配替换
//       let styL, styT

//       // 注意在ie中 第一次获取到的值为组件自带50% 移动之后赋值为px
//       if (sty.left.includes('%')) {
//         styL = +document.body.clientWidth * (+sty.left.replace(/\%/g, '') / 100)
//         styT = +document.body.clientHeight * (+sty.top.replace(/\%/g, '') / 100)
//       } else {
//         styL = +sty.left.replace(/\px/g, '')
//         styT = +sty.top.replace(/\px/g, '')
//       }

//       document.onmousemove = function(e) {
//         // 通过事件委托，计算移动的距离
//         const l = e.clientX - disX
//         const t = e.clientY - disY

//         // 移动当前元素
//         dragDom.style.left = `${l + styL}px`
//         dragDom.style.top = `${t + styT}px`

//         // 将此时的位置传出去
//         // binding.value({x:e.pageX,y:e.pageY})
//       }

//       document.onmouseup = function(e) {
//         document.onmousemove = null
//         document.onmouseup = null
//       }
//     }
//   }
// })
Vue.directive('dialogDrag', {
  bind (el, binding, vnode, oldVnode) {
    const dialogHeaderEl = el.querySelector('.el-dialog__header')
    const dragDom = el.querySelector('.el-dialog')
    dialogHeaderEl.style.cursor = 'move'

    // 获取原有属性 ie dom元素.currentStyle 火狐谷歌 window.getComputedStyle(dom元素, null)
    const sty = dragDom.currentStyle || window.getComputedStyle(dragDom, null)

    dialogHeaderEl.onmousedown = (e) => {
      // 鼠标按下，计算当前元素距离可视区的距离
      const disX = e.clientX - dialogHeaderEl.offsetLeft
      const disY = e.clientY - dialogHeaderEl.offsetTop
      const screenWidth = document.body.clientWidth // body当前宽度

      const screenHeight = document.documentElement.clientHeight // 可见区域高度(应为body高度，可某些环境下无法获取)
      const dragDomWidth = dragDom.offsetWidth // 对话框宽度
      const dragDomheight = dragDom.offsetHeight // 对话框高度
      const minDragDomLeft = dragDom.offsetLeft
      const maxDragDomLeft = screenWidth - dragDom.offsetLeft - dragDomWidth
      const minDragDomTop = dragDom.offsetTop
      const maxDragDomTop = screenHeight - dragDom.offsetTop - dragDomheight
      // 获取到的值带px 正则匹配替换
      let styL, styT
      // 注意在ie中 第一次获取到的值为组件自带50% 移动之后赋值为px
      if (sty.left.includes('%')) {
        styL = +document.body.clientWidth * (+sty.left.replace(/\%/g, '') / 100)
        styT = +document.body.clientHeight * (+sty.top.replace(/\%/g, '') / 100)
      } else {
        styL = +sty.left.replace(/\px/g, '')
        styT = +sty.top.replace(/\px/g, '')
      }
      document.onmousemove = function (e) {
        // 通过事件委托，计算移动的距离
        let l = e.clientX - disX
        let t = e.clientY - disY
        // 边界处理
        if (-(l) > maxDragDomLeft) {
          l = -(minDragDomLeft)
        } else if (l > maxDragDomLeft) {
          l = maxDragDomLeft
        }

        if (-(t) > minDragDomTop) {
          t = -(minDragDomTop)
        } else if (t > maxDragDomTop) {
          t = maxDragDomTop
        }

        // 移动当前元素
        dragDom.style.left = `${l + styL}px`
        dragDom.style.top = `${t + styT}px`

        // 将此时的位置传出去
        // binding.value({x:e.pageX,y:e.pageY})
      }

      document.onmouseup = function (e) {
        document.onmousemove = null
        document.onmouseup = null
      }
      return false
    }
  }
})
Vue.directive('enterNumber', { //全局方法  限制input输入框只能输入纯数字 组件中调用如（<el-input v-enter-number v-model="number" ></el-input>）
  inserted: function(el) {
    el.addEventListener("keypress", function(e) {
      e = e || window.event;
      let charcode = typeof e.charCode === 'number' ? e.charCode : e.keyCode;
      let re = /\d/;
      if (!re.test(String.fromCharCode(charcode)) && charcode > 9 && !e.ctrlKey) {
        if (e.preventDefault) {
          e.preventDefault();
        } else {
          e.returnValue = false;
        }
      }
    });
  }
});

// v-dialog-drag-and-zoom: 弹窗拖拽+水平垂直对角线方向伸缩
// 注意：使用当前指令时，el-dialog中不要写slot="footer"用class代替，且不要写width=xxx，会导致内部有按钮时，点击后宽度重置，内部宽度直接写在此处
Vue.directive('dragAndZoom', {
  inserted(el, binding) {
    const dragDom = el.querySelector('.el-dialog')
    dragDom.style.display = 'none'
    if (binding?.value && dragDom) {
      getDragZoomSize(binding, dragDom)
    }
  },
  update(el, binding, vnode, oldVnode) { // update只有dialog内有变动才会被调用，纯静态页面不会
    //弹框可拉伸最小宽高
    let minWidth = 250
    let minHeight = 200
    //初始非全屏
    let isFullScreen = false
    //当前宽高
    let nowWidth = 0
    let nowHight = 0
    //当前顶部高度
    let nowMarginTop = 0
    //获取弹框头部（这部分可双击全屏）
    const dialogHeaderEl = el.querySelector('.el-dialog__header')
    //弹窗
    const dragDom = el.querySelector('.el-dialog')
    // 元素位置定位动态修改为fixed
    dragDom.style.position = 'fixed'
    //给弹窗加上overflow auto；不然缩小时框内的标签可能超出dialog；
    // dragDom.style.overflow = 'auto'
    //清除选择头部文字效果
    dialogHeaderEl.onselectstart = new Function("return false")  
    //头部加上可拖动cursor
    dialogHeaderEl.style.cursor = 'move'
    // 获取原有属性 ie dom元素.currentStyle 火狐谷歌 window.getComputedStyle(dom元素, null)
    const sty = dragDom.currentStyle || window.getComputedStyle(dragDom, null)
    let moveDown = (e) => {
      // 鼠标按下，计算当前元素距离可视区的距离
      const disX = e.clientX - dialogHeaderEl.offsetLeft
      const disY = e.clientY - dialogHeaderEl.offsetTop
      // 获取到的值带px 正则匹配替换
      let styL, styT
      // 注意在ie中 第一次获取到的值为组件自带50% 移动之后赋值为px
      if (sty.left.includes('%')) {
        styL = +document.body.clientWidth * (+sty.left.replace(/%/g, '') / 100)
        styT = +document.body.clientHeight * (+sty.top.replace(/%/g, '') / 100)
      } else {
        styL = +sty.left.replace(/px/g, '')
        styT = +sty.top.replace(/px/g, '')
      }
      const bodyWidth = document.body.clientWidth
      const bodyHeight = document.body.clientHeight // 获取屏幕高度
      let tempLeft = dragDom.offsetLeft
      let tempTop = dragDom.offsetTop
      document.onmousemove = function (e) {
        // 通过事件委托，计算移动的距离 
        const l = e.clientX - disX
        const t = e.clientY - disY
        // console.log("鼠标移动到的位置",e.clientX, e.clientY)

        // 限制不让拖出屏幕 *****

        // 移动当前元素
        tempLeft = l + styL
        tempTop = t + styT
        dragDom.style.left = `${tempLeft}px`
        dragDom.style.top = `${tempTop}px`

        const tempObj = dragDom.getBoundingClientRect()
        if (tempObj.top < 0) {
          tempTop = 0
          dragDom.style.top = `${tempTop}px`
        }
        if (tempObj.left < 0) {
          tempLeft = 0
          dragDom.style.left = `${tempLeft}px`
        }

        if ((tempObj.top + tempObj.height) > bodyHeight) {
          tempTop = bodyHeight - tempObj.height
          dragDom.style.top = `${tempTop}px`
        }
        if ((tempObj.left + tempObj.width) > bodyWidth) {
          tempLeft = bodyWidth - tempObj.width
          dragDom.style.left = `${tempLeft}px`
        }

        //将此时的位置传出去
        //binding.value({x:e.pageX,y:e.pageY})
      }
      document.onmouseup = function (e) {
        document.onmousemove = null
        document.onmouseup = null
        store.dispatch('dialogCommon/setDragZoomFixed', true)
        //setDragZoomSize(binding, dragDom.clientWidth, dragDom.clientHeight, tempLeft, tempTop)
      }
    }
    dialogHeaderEl.onmousedown = moveDown

    // 底部可以拖动 start
    const dialogFooterEl = el.querySelector('.el-dialog__footer')
    let moveDownFoot = (e) => {
      // 鼠标按下，计算当前元素距离可视区的距离
      const disX = e.clientX - dialogFooterEl.offsetLeft
      const disY = e.clientY - dialogFooterEl.offsetTop

      let  height = document.getElementsByClassName("summaryDialog")[0].getElementsByClassName('el-dialog')[0].offsetHeight 
      // console.log("99999小结height",height)
      const height2 = height -56

      // 获取到的值带px 正则匹配替换
      let styL, styT
      // 注意在ie中 第一次获取到的值为组件自带50% 移动之后赋值为px
      if (sty.left.includes('%')) {
        styL = +document.body.clientWidth * (+sty.left.replace(/%/g, '') / 100)
        styT = +document.body.clientHeight * (+sty.top.replace(/%/g, '') / 100)
      } else {
        styL = +sty.left.replace(/px/g, '')
        styT = +sty.top.replace(/px/g, '')
      }
      const bodyWidth = document.body.clientWidth
      const bodyHeight = document.body.clientHeight // 获取屏幕高度
      document.onmousemove = function (e) {
        // 通过事件委托，计算移动的距离 
        const l = e.clientX - disX
        const t = e.clientY - disY

        // 限制不让拖出屏幕 *****
        if(e.clientY<100 || e.clientY > bodyHeight -20){
          return 
        }
        if(e.clientX<100 || e.clientX > bodyWidth -100){
          return 
        }

        
        // 移动当前元素  
        dragDom.style.left = `${l + styL}px`
        dragDom.style.top = `${t + styT -height2  }px`
        //将此时的位置传出去
        //binding.value({x:e.pageX,y:e.pageY})
      }
      document.onmouseup = function (e) {
        document.onmousemove = null
        document.onmouseup = null
        store.dispatch('dialogCommon/setDragZoomFixed', true)
      }
    }
    // dialogFooterEl.style.cursor = 'move'
    // dialogFooterEl.onmousedown = moveDownFoot
    // 底部可以拖动 end
    
    //拉伸(右下方)
    let resizeEl=document.createElement("div")
    dragDom.appendChild(resizeEl) 
    //在弹窗右下角加上一个10-10px的控制块
    resizeEl.classList.add(`${binding.value}-right-bottom`)
    resizeEl.style.cursor = 'se-resize'
    resizeEl.style.position = 'absolute'
    resizeEl.style.height = '10px'
    resizeEl.style.width = '10px'
    resizeEl.style.right = '0px'
    resizeEl.style.bottom = '0px'
    resizeEl.style.zIndex = '99'
    //鼠标拉伸弹窗
    resizeEl.onmousedown = (e) => {
      // 记录初始x位置
      let clientX = e.clientX
      // 鼠标按下，计算当前元素距离可视区的距离
      let disX = e.clientX - resizeEl.offsetLeft
      let disY = e.clientY - resizeEl.offsetTop
      let tempWidth = dragDom.clientWidth
      let tempHeight = dragDom.clientHeight
      document.onmousemove = function (e) {
        e.preventDefault() // 移动时禁用默认事件
        
        // 通过事件委托，计算移动的距离
        let x = e.clientX - disX + 25//这里 由于elementUI的dialog控制居中的，所以水平拉伸效果是双倍
        let y = e.clientY - disY + 25
        const bodyWidth = document.body.clientWidth
        const bodyHeight = document.body.clientHeight // 获取屏幕高度
        //比较是否小于最小宽高
        const fixX = x > minWidth ? x : minWidth
        const fixY = y > minHeight ? y : minHeight
        const tempObj = dragDom.getBoundingClientRect()
        if ((fixX + tempObj.left) > bodyWidth) {
          tempWidth = bodyWidth - tempObj.left
          dragDom.style.width = `${tempWidth}px`
          const flagDom = document.querySelector('.el-message--warning')
          if (!flagDom) {
            Message.warning({
              message: '不可调节，已达到可调节范围上限！'
            })
          }
        } else {
          tempWidth = fixX
          dragDom.style.width = `${tempWidth}px`
        }
        if ((fixY + tempObj.top) > bodyHeight) {
          tempHeight = bodyHeight - tempObj.top
          dragDom.style.height = `${tempHeight}px`
          const flagDom = document.querySelector('.el-message--warning')
          if (!flagDom) {
            Message.warning({
              message: '不可调节，已达到可调节范围上限！'
            })
          }
        } else {
          tempHeight = fixY
          dragDom.style.height = `${tempHeight}px`
        }
      }
      //拉伸结束
      document.onmouseup = function (e) {
        document.onmousemove = null
        document.onmouseup = null
        store.dispatch('dialogCommon/setDragZoomFixed', true)
        //setDragZoomSize(binding, tempWidth, tempHeight, dragDom.offsetLeft, dragDom.offsetTop)
      }
    }
    
    //拉伸(右边)
    let resizeElR=document.createElement("div")
    dragDom.appendChild(resizeElR) 
    //在弹窗右下角加上一个10-10px的控制块
    resizeElR.style.cursor = 'w-resize'
    resizeElR.style.position = 'absolute'
    resizeElR.style.height = '100%'
    resizeElR.style.width = '10px'
    resizeElR.style.right = '0px'
    resizeElR.style.top = '0px'
    //鼠标拉伸弹窗
    resizeElR.onmousedown = (e) => {
      let elW = dragDom.clientWidth
      let EloffsetLeft = dragDom.offsetLeft
      // 记录初始x位置
      let clientX = e.clientX
      let tempWidth = dragDom.clientWidth
      document.onmousemove = function (e) {
        e.preventDefault() // 移动时禁用默认事件
        //右侧鼠标拖拽位置
        if (clientX > EloffsetLeft + elW - 10 && clientX < EloffsetLeft + elW) {
          //往左拖拽
          if (clientX > e.clientX) {
            if (dragDom.clientWidth < minWidth) {
              console.log(111)
            } else {
              dragDom.style.width = elW - (clientX - e.clientX) + 'px'
            }
          }
          //往右拖拽
          if (clientX < e.clientX) {
            tempWidth = elW + (e.clientX - clientX)
            const bodyWidth = document.body.clientWidth
            const tempObj = dragDom.getBoundingClientRect()
            if ((tempWidth + tempObj.left) > bodyWidth) {
              tempWidth = bodyWidth - tempObj.left
              const flagDom = document.querySelector('.el-message--warning')
              if (!flagDom) {
                Message.warning({
                  message: '不可调节，已达到可调节范围上限！'
                })
              }
            }
            dragDom.style.width = `${tempWidth}px`
          }
        }
      }
      //拉伸结束
      document.onmouseup = function (e) {
        document.onmousemove = null
        document.onmouseup = null
        store.dispatch('dialogCommon/setDragZoomFixed', true)
        //setDragZoomSize(binding, tempWidth, dragDom.clientHeight, dragDom.offsetLeft, dragDom.offsetTop)
      }
    }
    
    // 拉伸(下边)
    let resizeElB=document.createElement("div")
    dragDom.appendChild(resizeElB) 
    //在弹窗右下角加上一个10-10px的控制块
    resizeElB.style.cursor = 'n-resize'
    resizeElB.style.position = 'absolute'
    resizeElB.style.height = '10px'
    resizeElB.style.width = '100%'
    resizeElB.style.left = '0px'
    resizeElB.style.bottom = '0px'
    //鼠标拉伸弹窗
    resizeElB.onmousedown = (e) => {
      let EloffsetTop = dragDom.offsetTop
      let ELscrollTop = el.scrollTop
      let clientY = e.clientY
      let elH = dragDom.clientHeight
      let tempHeight = dragDom.clientHeight
      document.onmousemove = function (e) {
        e.preventDefault() // 移动时禁用默认事件
        //底部鼠标拖拽位置
        if (ELscrollTop + clientY > EloffsetTop + elH - 20 && ELscrollTop + clientY < EloffsetTop + elH) {
          //往上拖拽
          if (clientY > e.clientY) {
            if (dragDom.clientHeight < minHeight) {
              console.log(333)
            } else {
              dragDom.style.height = `${elH - (clientY - e.clientY)}px`
            }
          }
          //往下拖拽
          if (clientY < e.clientY) {
            tempHeight = elH + (e.clientY - clientY)
            const bodyHeight = document.body.clientHeight
            const tempObj = dragDom.getBoundingClientRect()
            if ((tempHeight + tempObj.top) > bodyHeight) {
              tempHeight = bodyHeight - tempObj.top
              const flagDom = document.querySelector('.el-message--warning')
              if (!flagDom) {
                Message.warning({
                  message: '不可调节，已达到可调节范围上限！'
                })
              }
            }
            dragDom.style.height = `${tempHeight}px`
          }
        }
      }
      //拉伸结束
      document.onmouseup = function (e) {
        document.onmousemove = null
        document.onmouseup = null
        store.dispatch('dialogCommon/setDragZoomFixed', true)
        //setDragZoomSize(binding, dragDom.clientWidth, tempHeight, dragDom.offsetLeft, dragDom.offsetTop)
      }
    }
  }
})

const getDragZoomSize = async (binding, dragDom) => {
  // 弹窗窗体移动/拉大/缩小后记住
  const { sub } = store.getters.userLoginInfo?.profile || {}
  const params = {
    param_identifier: `dragAndZoom.${binding?.value || ''}.${sub}`,
    param_type: 0,
    param_code: `dragAndZoom.${binding?.value || ''}`
  }
  pacsApi.pacsApi.getSystemParameterCustom(params).then(res => {
    if (res?.code === 0) {
      const windowHei = window.innerHeight
      const windowWid = window.innerWidth
      that.$nextTick(() => {
        if (res.data.custom_json_data && JSON.parse(res.data.custom_json_data)?.width) {
          const data = JSON.parse(res.data.custom_json_data)
          let widthR = data.width / (data.windowWid || windowWid) * windowWid
          if (widthR > windowWid) {
            widthR = windowWid
          }
          let heightR = data.height / (data.windowHei || windowHei) * windowHei
          if (heightR > windowHei) {
            heightR = windowHei
          }
          let leftR = data.left / (data.windowWid || windowWid) * windowWid
          if (leftR < 0) {
            leftR = 0
          } else if ((leftR + widthR) > windowWid) {
            leftR = windowWid - widthR
          }
          let topR = data.top / (data.windowHei || windowHei) * windowHei
          if (topR < 0) {
            topR = 0
          } else if ((topR + heightR) > windowHei) {
            topR = windowHei - heightR
          }
          dragDom.style.width = `${widthR || 250}px`
          dragDom.style.height = `${heightR || 250}px`
          dragDom.style.left = `${leftR}px`
          dragDom.style.top = `${topR}px`
          if (['TemplateModeDetail'].includes(binding.value)) {
            dragDom.style.transform = 'none'
          }
        } else {
          const dragObj = {
            'deleteBtn': 777,
            'ModifyDoctorDia': sessionStorage.getItem('currentSystemClass') === 'EIS' ? 1100 : 750,
            'DialogForm': 750,
            'TemplateEditIndex': 1280,
            'SaveAsModel': 800,
            'AddRadiography': 600,
            'ApplyFont': 1000,
            'ApplyList': 1200,
            'btnCustom': 570,
            'CancleCheck': 600,
            'CaseCollection': 520,
            // 'CaseReportCollection': 610,
            'CheckTrackings': 1155,
            'customRegist': 1100,
            'DepartmentComsultDetail': 600,
            'DepartmentConsultWithAuth': 600,
            'EvaluationFail': 777,
            'FastInqueryNew': 1100,
            'GreenChannel': 675,
            'History': 1200,
            'HistoryNew': 1250,
            'InfectiousDRC': 860,
            'InternalDepartConsultWithRecords': 900,
            'Lock': 500,
            // 'Photo': 1180,
            'postSelect': 1080,
            'RankQueryConditions': 670,
            'relavantApply': 1000,
            'Remark': 777,
            'returnToDept': 600,
            'ReviewRadiography': 600,
            'reviseReason': 777,
            'SetColumns': 880,
            'Tuberculosis': 1030,
            'updatePatientClass': 500,
            // 'ApplyOtherConsult': 600,
            'InternalDepartConsult': 600,
            'filmPrintConfirm': 1200,
            'assistTechnicianLogin': 380,
            'caseExportApplyAlertDialog': 450,
            'writingTemplate': 1250,
            'systemWritingTemplate': 1250,
            'searchPatient': 1060
          }
          dragDom.style.width = `${dragObj[binding.value] || 600}px`
          if (['FastInqueryNew', 'ApplyFont', 'ApplyList', 'writingTemplate', 'systemWritingTemplate', 'searchPatient'].includes(binding.value)) {
            dragDom.style.height = '100vh'
          }
        }
        dragDom.style.display = 'block'
        try {
          const bodyEl = dragDom.getElementsByClassName('el-dialog__body')[0]
          if (bodyEl) {
            bodyEl.style.height = 'calc(100% - 40px)'
            bodyEl.style['overflow'] = 'auto'
          }
          eventBus.$emit('structureHeightChange')
        } catch (error) {
          console.log(error);
        }
      })
    }
  })
}

Vue.directive('dragDivLimit', {
  bind(el) {
    let isDragging = false;
    let offsetX, offsetY;

    el.onmousedown = (e) => {
      isDragging = true;
      offsetX = e.clientX - el.offsetLeft;
      offsetY = e.clientY - el.offsetTop;
      document.body.style.userSelect = 'none'; // 禁用文本选中^^2^^5^^

      document.onmousemove = (e) => {
        if (!isDragging) return;
        
        let left = e.clientX - offsetX;
        let top = e.clientY - offsetY;

        // 边界限制逻辑
        left = Math.max(0, Math.min(left, window.innerWidth - el.offsetWidth));
        top = Math.max(0, Math.min(top, window.innerHeight - el.offsetHeight));

        el.style.left = `${left}px`;
        el.style.top = `${top}px`;
      };

      document.onmouseup = () => {
        isDragging = false;
        document.body.style.userSelect = '';
        document.onmousemove = null;
        document.onmouseup = null;
      };
    };
  }
});
