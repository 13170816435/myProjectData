/**
 * @param {string} port
 * @returns {Boolean}
 * 端口号0-65535
 */
export function validPort (port) {
  // if(/(^[1-9]\d*$)|(0)/.test(value) && value >= 0 && value <= 65535) { // 001能通过验证
  // return /(^[0-9]$)|(^[1-9]\d$)|(^[1-9]\d{2}$)|(^[1-9]\d{3}$)|(^[1-6]\d{3}[0-5]$)/.test(port)
  return /^([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/.test(port)
}

/**
 * @param {string} path
 * @returns {Boolean}
 * 文件路径
 */
export function validPath (path) {
  // return /^[a-zA-Z]:(((\\(?! )[^/:*?<>\""|\\]+)+\\?)|(\\)?)\s*$/.test(path)
  return /^\/(\w+\/?)+$/.test(path)
}

/**
 * @param {string} url
 * @returns {Boolean}
 * url地址
 */
///^(?=^.{3,255}$)(http(s)?:\/\/)?(www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\d+)*(\/\w+\.\w+)*([\?&]\w+=\w*)*$/.test(value)
export function validURL(url) {
  const reg = /^(https?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/
  return reg.test(url)
}

/**
 * @param {string} ip
 * @returns {Boolean}
 * ip地址
 */
export function validIP (ip) {
  const reg = /^(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)$/
  return reg.test(ip)
}
//不能连续字符（如123、abc、321）连续3位或3位以上
export function LXstr(str){
  var arr = str.split('');
  var flag = true;
  for (var i = 1; i < arr.length-1; i++) {
    var firstIndex = arr[i-1].charCodeAt();
    var secondIndex = arr[i].charCodeAt();
    var thirdIndex = arr[i+1].charCodeAt();
    thirdIndex - secondIndex == 1;
    secondIndex - firstIndex == 1;
    if((thirdIndex - secondIndex == 1)&&(secondIndex - firstIndex==1) || (thirdIndex - secondIndex == -1)&&(secondIndex - firstIndex== -1)){
      flag =  false;
    }
  }
  if(!flag){
      // $("#message_").text("您的工号为弱口令密码，请修改密码后登录！");
      return flag;
  }
  return flag;
}

// 键盘上不能连续字符
export function windowKeyLxstr (str) {
  var keyArr = [
    "1!", "2@", "3#", "4$","5%", "6^", "7&", "8*","9(", "0)", "-_", "=+",
    "qQ", "wW", "eE", "rR","tT", "yY", "uU", "iI","oO", "pP", "[{", "]}",
    "aA", "sS", "dD", "fF","gG", "hH", "jJ", "kK","lL", ";:", "'\"", "\\|",
    "zZ", "xX", "cC", "vV","bB", "nN", "mM", ",<",".>", "/?", "", ""
  ]
  var arr = str.split('');
  var flag = true;
  var firstIndex
  var secondIndex
  var thirdIndex
  function getArrayIndex(val) {
    let index = null
    for(var j= 0;j<keyArr.length;j++) {
      if (keyArr[j].indexOf(val) != -1) {
        index = j
      }
    }
    return index
  }
  for (var i = 1; i < arr.length-1; i++) {
    firstIndex = getArrayIndex(arr[i-1])
    secondIndex = getArrayIndex(arr[i])
    thirdIndex = getArrayIndex(arr[i+1])
    thirdIndex - secondIndex == 1;
    secondIndex - firstIndex == 1;
    if(((thirdIndex - secondIndex == 1)&&(secondIndex - firstIndex==1)) || ((thirdIndex - secondIndex == -1)&&(secondIndex - firstIndex== -1))){
      flag = false;
      break
    }
  }
  if(!flag){
    // $("#message_").text("您的工号为弱口令密码，请修改密码后登录！");
    return flag;
  }
  return flag;
}