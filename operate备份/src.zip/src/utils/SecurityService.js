import SecurityService from 'tomtaw-authority';

export default class SecurityServiceWrapper {
  constructor () {
    const that = this
    this.ss = new SecurityService({
      subdir: window.Config.subdir,
      oidcSettings: {
        authority: configUrl.crmUrl,
        scope: 'openid profile api-cloudpacs api-telemed api-idcas api-operate api-reserve api-quality api-imaging api-document api-structure api-im api-search api-archivemanage api-dms api-datamining api-pis api-ability api-ewcss api-teaching',
        //useLocalStorageStore: true,
      },
      notLoggedinHandle (resolve, reject, securityService) {
        const pathname = window.location.pathname
        // 不太明白为啥 要加上 ||pathname.indexOf('customerDataCockpit/index') !== -1(加上了的话 那金华、安吉、武汉等大屏就不能通过授权获取tenancy_id 导致大屏获取不到数据)
        // if (pathname.indexOf('educationH5/share') !== -1 ||pathname.indexOf('customerDataCockpit/index') !== -1) {
        if (pathname.indexOf('educationH5/share') !== -1) {
          return resolve({})
        }
        that.signIn()
        return reject('Unauthorized')
      },
      clearStorageBeforeUnload: false,
    });
  }
  getRole () {
    const pathname = window.location.pathname
    // if (pathname.indexOf('educationH5/share') !== -1 || pathname.indexOf('customerDataCockpit/index') !== -1) {
      if (pathname.indexOf('educationH5/share') !== -1) {  
      return new Promise(resolve => {
        resolve({})
      })
    }
    return this.ss.getRole()
  }
  // 登出
  signOut () {
    return this.ss.signOut()
  }
  // 登录
  signIn () {
    return this.ss.signIn()
  }

}