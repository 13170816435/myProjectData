import * as excel from './excel'
import { getPlatformImageBase64 } from '@/api/platform_operate/intelligentServices/platformAiManage'

const getFrontEndUrl = () => {
  return process.env.NODE_ENV === 'development'? 'https://dev-portal.mtywcloud.com': configUrl.frontEndUrl
}

export default {
  excel,
  getFrontEndUrl
}
// 验证是否未大模型
export function isLargeModel (code) {
  if (code.startsWith('09')) {
    return true
  }
  return false
}


/*
* 获取base64图片
* params:
*  id 主键
*  owner 1-厂商 2-服务
*  type 1-详情 2-logo 3-注册证
*/
export async function getPlatformImgBase64 ({id, owner, type}) {
  let res = await getPlatformImageBase64({id, owner, type})
  if (res.code != 0) {
    return ''
  }
  return res.data
}