// 格式化时间
export function formatTime (param,text){
	const y = param.getFullYear()
	let m = param.getMonth() + 1
	let d = param.getDate()
	let h = param.getHours();
	let mi = param.getMinutes();
	let s = param.getSeconds();
	m = m < 10 ? `0${m}` : m
	d = d < 10 ? `0${d}` : d
	h = h < 10 ? `0${h}` : h
	mi = mi < 10 ? `0${mi}` : mi
	s = s < 10 ? `0${s}` : s
	if(text==='h-m-s'){
		return `${y}-${m}-${d} ${h}:${mi}:${s}`
	}else{
		return `${y}-${m}-${d}`
	}
}
/**
 * 以服务器时间计算日期
 * nowTime - 当前日期,必须是new Date()格式
 */
export const online_getDate=(nowTime,text)=>{
	const parse_t = Date.parse(nowTime); //时间戳
	const oneDay = 1000 * 3600 * 24;
	let start = '';
	let end = '';
	switch(text){
		// 今天
		case 'today':
			start = parse_t
			end = parse_t
			break;
		// 昨天
		case 'lastDay':
			start = parse_t-oneDay*1;
			end = parse_t-oneDay*1
			break;
		// 昨天
		case 'yestoday':
			start = parse_t-oneDay*1;
			end = parse_t-oneDay*1
			break;
		// 最近2天(从昨天开始算)
		case 'lastTwoDay':
			start = parse_t-oneDay*2;
			end = parse_t-oneDay*1
			break;
		// 最近三天(从昨天开始算)
		case 'lastThreeDay':
			start = parse_t-oneDay*3;
			end = parse_t-oneDay*1
			break;
		// 最近1周(从昨天开始算)
		case 'lastOneWeek':
			start = parse_t-oneDay*7;
			end = parse_t-oneDay*1
			break;
		// 最近2周(从昨天开始算)
		case 'lastTwoWeek':
			start = parse_t-oneDay*14;
			end = parse_t-oneDay*1
			break;
		// 最近15天(从昨天开始算)
		case 'lastFifteen':
			start = parse_t-oneDay*15;
			end = parse_t-oneDay*1
			break;
		//最近一月(从昨天开始算)
		case 'lastOneMonth':
			const get_year = nowTime.getFullYear();
			const get_month = nowTime.getMonth();
			const get_day = nowTime.getDate();
			if(get_month===0){
				start = `${get_year-1}-12-${get_day-1}`;
			}else{
				start = `${get_year}-${get_month}-${get_day-1}`;
			}
			end = parse_t-oneDay*1;
			break;
		//不限时间
		case 'allTime':
			start = ''
			end = ''
			break;
		//最近7天(从今天开始算)
		case 'recent_oneweek':
		case 'recent_sevenDays':
			start = parse_t-oneDay*6;
			end = parse_t
			break;
		//最近3天（从今天开始算）
		case 'recent_threeDays':
			start = parse_t-oneDay*2;
			end = parse_t
			break;
		//最近15天（从今天开始算）
		case 'recent_fifteenDays':
			start = parse_t-oneDay*14;
			end = parse_t
			break;
		//最近30天（从今天开始算）
		case 'recent_thirtyDays':
			start = parse_t-oneDay*29;
			end = parse_t
			break;
	}
	const result = {
		start_date: start!==''?formatTime(new Date(start)).trim():'',
		end_date: end!==''?formatTime(new Date(end)).trim():'',
	}
	return result
}

/**
 * 根据月份计算结束日期是28,29,30,31
 */
export const getEndOfMonth=(time)=>{
	const newtime = new Date(time);
	const getyear = newtime.getFullYear();
	const getmonth=newtime.getMonth()+1;
	let endtime = ''
	endtime = `${getyear}-${getmonth<10?'0'+getmonth:getmonth}-${lastDay(getmonth,getyear)}`
	return endtime
}

//计算一个月的最后一天
function lastDay(month,year){
	let day=null
	if(month===1||month===3||month===5||month===7||month===8||month===10||month===12){
		day=31
	}else if(month===4||month===6||month===9||month===11){
		day=30
	}else if(month===2){
		//判断年份是否是闰年
		if(year%4==0&&year%100!=0||year%400==0){
			day=29
		}else{
			day=28
		}
	}
	return day
}

/**
 * 根据年计算开始年份 结束年份
 * type //0:按年 1:按月 1:按天
 */
export const getStartEndDate = (time,type)=>{
	let result=null
	if(type==='2'){
		result = [time,time]
	}else{
		const newDate = new Date(time);
		const year = newDate.getFullYear();
		const month = newDate.getMonth()+1<10?`0${newDate.getMonth()+1}`:newDate.getMonth()+1;
		const day = newDate.getDate()<10?`0${newDate.getDate()}`:newDate.getDate();
		if(type==='0'){
			result = [`${year}-${month}-${day}`,`${year}-12-31`]
		}else if(type==='1'){
			result = [`${year}-${month}-${day}`,`${year}-${month}-${lastDay(Number(month),year)}`]
		}
	}
	return result
}

/**
 * 根据yyyy-MM 计算当前月开始日期 结束日期 (当前月)
 */
export const getMonthStartEnd = (time)=>{
	let result=[];
	const year = time.slice(0,4);
	const month = time.slice(5);
	const start_time = `${year}-${month}-01`;
	const ent_time = `${year}-${month}-${lastDay(Number(month),year)}`;
	result = [start_time,ent_time]
	return result
}

/**
 * 根据yyyy-MM 计算上个月开始日期 结束日期 (上个月)
 */
export const getPrevMonthStartEnd = (time)=>{
	let result=[];
	let year = time.slice(0,4);
	const month = time.slice(5);
	let prev_month = null;
	if(Number(month)-1===0){
		prev_month = 12
	}else{
		prev_month = Number(month)-1
	}
	if(prev_month ===12) { // 如果上月是12月，年份要减1
		year =  year -1
	}
	
	const start_time = `${year}-${prev_month<10?`0${prev_month}`:prev_month}-01`;
	const ent_time = `${year}-${prev_month<10?`0${prev_month}`:prev_month}-${lastDay(Number(prev_month),year)}`;
	result = [start_time,ent_time]
	return result
}

/**
 * 根据开始时间和结束时间，返回响应text
 */
export const timeChangeText = (start,end)=>{
	let result = null;
	const current = sessionStorage.getItem('onlineTime');
	const yestoday = online_getDate(current,'yestoday').start_date
	const threeday = online_getDate(current,'recent_threeDays').start_date
	const sevenday = online_getDate(current,'recent_sevenDays').start_date
	const thirtyday = online_getDate(current,'recent_thirtyDays').start_date
	if(start===current && end===current){
		result = 'today'
	}else if(start===yestoday && end===yestoday){
		result = 'yestoday'
	}else if(start===threeday && end===current){
		result = 'recent_threeDays'
	}else if(start===sevenday && end===current){
		result = 'recent_sevenDays'
	}else if(start===thirtyday && end===current){
		result = 'recent_thirtyDays'
	}
	return result
}
// 获取默认时间 timeLength：时长 timeType：小于0向前，大于0向后
export const getDefaultTime =  (timeLength, timeType)=> {
	let end = new Date()
	let start = new Date()
	if (timeType > 0) {
		end.setTime(end.getTime() + 3600 * 1000 * 24 * timeLength)
	} else {
		start.setTime(start.getTime() - 3600 * 1000 * 24 * timeLength)
	}
	let month = start.getMonth() + 1
	month = month > 9 ? month : '0' + month
	let day = start.getDate()
	day = day > 9 ? day : '0' + day
	start = start.getFullYear() + '-' + month + '-' + day
	let emonth = end.getMonth() + 1
	emonth = emonth > 9 ? emonth : '0' + emonth
	let eday = end.getDate()
	eday = eday > 9 ? eday : '0' + eday
	end = end.getFullYear() + '-' + emonth + '-' + eday
	return [start, end]
}
// 获取当前月有多少天
export const monthDay= (month, year) => {
	console.log(999, month, year)
	if([1,3,5,7,8,10,12].includes(month)) {
		return 31
	} else if([4,6,9,11].includes(month)) {
		return 30
	} else{
		if(year%4===0&&year%100!=0||year%400===0) {
			return 29
		} else{
			return 28
		}
	}
}

// 根据当前日期获取近几个月日期范围
// date日期   num最近几个月
export const getLastMonth = (date,num)=> {
	const currentMonth =  date.getMonth() + 1 < 10? '0' + (date.getMonth() + 1): date.getMonth() + 1
	const currentYear =  date.getFullYear()
	const day = date.getDate()<10?'0'+date.getDate():date.getDate()
	let lastDate = ''
	let lastYear = ''
	let lastMonth = ''
	let lastDay = ''
	// 计算上一个日期的年月
	if (Number(currentMonth) - num<=0) { // 两个时间间隔跨年
		lastMonth = Number(currentMonth) - num + 12<10? "0"+(Number(currentMonth) - num + 12):Number(currentMonth) - num + 12
		lastYear = currentYear - 1
		console.log(55, lastMonth)
	} else {
		lastMonth = Number(currentMonth) - num<10?'0'+(Number(currentMonth) - num):Number(currentMonth) - num
		lastYear = currentYear
	}
	// 计算上一个日期的具体几号
	if(Number(day)<29) {
		lastDay = day
	} else if(Number(day)>=29&&Number(day)<=31) {
		if(Number(lastMonth) === 2) {
			if(lastYear%4===0&&lastYear%100!=0||lastYear%400===0) {
				lastDay = 29
			} else {
				lastDay = 28
			}
		} else {
			if(monthDay(lastMonth,lastYear) >= Number(day)) {
				lastDay = day
			} else {
				lastDay = monthDay(lastMonth,lastYear)
			}
		}
	}
	lastDate = `${lastYear}-${lastMonth}-${lastDay}`
	const currentDate = `${currentYear}-${currentMonth}-${day}`
	return [lastDate,currentDate]
}
// 时间戳转换成年月日时分秒
export const getDateAll =  (time) =>{
  if (!isNaN(time)) time = Number(time)
  var now = new Date(time)
  var year = now.getFullYear()
  var month = now.getMonth() + 1
  month >= 10 ? (month = month) : (month = '0' + month) // 判断小于10月份的情况
  var date = now.getDate()
  date >= 10 ? (date = date) : (date = '0' + date) // 判断小于10日的情况
  var hour = now.getHours()
  hour >= 10 ? (hour = hour) : (hour = '0' + hour) // 判断小于10的时的情况
  var minute = now.getMinutes()
  minute >= 10 ? (minute = minute) : (minute = '0' + minute) // 判断小于10的分的情况
  var second = now.getSeconds()
  second >= 10 ? (second = second) : (second = '0' + second) // 判断小于10的秒的情况

  return year + '-' + month + '-' + date + ' ' + hour + ':' + minute + ':' + second
}
// 获取本年开始和结束时间
export const getCurrentYearTime= ()=> {
	const currentTime = new Date();
	const endDate = formatTime(currentTime)
	const currentYear = currentTime.getFullYear()
	const startDate = `${currentYear}-01-01`
	return [startDate, endDate]
}
// 获取本月开始和结束时间
export const getCurrentMonthTime= ()=> {
	const currentTime = new Date();
	const endDate = formatTime(currentTime)
	const currentYear = currentTime.getFullYear()
	const currentMonth = currentTime.getMonth() + 1
	const startDate = `${currentYear}-${currentMonth}-01`
	return [startDate, endDate]
}
//根据起始日期和结束日期计算天数
export const  DateDiff = (dateArr)=>{     
	const  startDate = Date.parse(dateArr[0]);
	const  endDate = Date.parse(dateArr[1]);
	if (startDate>endDate){
			return 0;
	}
	if (startDate==endDate){
			return 1;
	}
	const days=(endDate - startDate)/(1*24*60*60*1000);
	return  days;
}