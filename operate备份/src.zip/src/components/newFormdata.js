(function(root) {
  const supportedFromDataDelete = typeof root.FormData.prototype.delete !== "undefined";
  function CompatibleFormData () {
    this.inner = supportedFromDataDelete ? new FormData() : {}
  }
  CompatibleFormData.prototype.append = function (name, value) {
    if (supportedFromDataDelete) {
      this.inner.append(name, value)
    } else {
      this.inner[name] = value
    }
    return this
  }
  CompatibleFormData.prototype.delete = function (name) {
    if (supportedFromDataDelete) {
      this.inner.delete(name)
    } else {
      while (this.inner[name]) {
        this.inner[name] = null
        delete this.inner[name]
      }
    }
    return this
  }
  CompatibleFormData.prototype.compatible = function () {
    if (supportedFromDataDelete) {
      return this.inner
    } else {
      const formData = new root.FormData()
      const inner = this.inner
      Object.keys(this.inner).forEach((name) => {
        formData.append(name, inner[name])
      })
      return formData
    }
  }
  root.CompatibleFormData = CompatibleFormData
})(window)
