<template>
  <div class="userinfo" 
    v-loading="loading"
    element-loading-text="正在新增"
    element-loading-background="rgba(255,255,255,0.6)"
>    
    <el-form :model="userInfo.formData" :rules="userInfo.rules" autocomplete="off" ref="formData" label-width="88px" class="demo-ruleForm">
      <el-row class="userInforRow">
        <el-col :span="12" class="personalInfor personInforDiv">
          <div class="leftTitCon"><span class="leftTitIcon fl"></span><span class="leftTit fl">个人信息</span></div>
           <el-form-item v-if="isServiceCenterUserPage" label="手机号码:" prop="phone" class="">
            <!--去掉了input方法 <el-input :disabled="notCanUpdateUser" v-model="userInfo.formData.phone"  @blur="getDetailByPhone" class="w_240"></el-input> -->
            <el-input :disabled="notCanUpdateUser" v-model="userInfo.formData.phone" @input="changePhone" @blur="getDetailByPhone" class="w_240"></el-input>
          </el-form-item>
          <el-form-item label="姓名:" prop="name" class="clear">
            <el-input :disabled="notCanUpdateUser" v-model="userInfo.formData.name" class="w_300"></el-input>
          </el-form-item>
          <el-form-item label="性别:" prop="sex" class="">
            <el-radio-group v-model="userInfo.formData.sex" :disabled="notCanUpdateUser || userInfo.validateIdNoResult">
              <el-radio :label=1>男</el-radio>
              <el-radio :label=2>女</el-radio>
              <el-radio v-if="userInfo.formData.sex === 0" :label=0>未知</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="出生日期:" class="">
            <el-date-picker v-model="userInfo.formData.birthday" type="date" class="w_300"
            format="yyyy-MM-dd"
            :disabled="notCanUpdateUser || userInfo.validateIdNoResult"
            value-format="yyyy-MM-dd"></el-date-picker>
          </el-form-item>
          <el-form-item label="登录名:" prop="login_name" class="clear">
            <el-input :disabled="notCanUpdateUser" v-model="userInfo.formData.login_name" class="w_300"></el-input>
          </el-form-item>
          <el-form-item v-if="!isServiceCenterUserPage" label="手机号码:" prop="phone" class="">
            <!-- 去掉了input方法 <el-input :disabled="notCanUpdateUser" v-model="userInfo.formData.phone" class="w_240"></el-input> -->
            <el-input :disabled="notCanUpdateUser" v-model="userInfo.formData.phone" @input="changePhone" @blur="getUserDetailByPhoneAtCustomer" class="w_300"></el-input>
          </el-form-item>
          <el-form-item label="手机短号:" prop="phone_short" class="">
            <el-input :disabled="notCanUpdateUser" v-model="userInfo.formData.phone_short" class="w_300"></el-input>
          </el-form-item>
          <el-form-item label="身份证号:" prop="id_number" class="clear">
            <el-input v-model="userInfo.formData.id_number" @blur="validateIdNo" class="w_300"></el-input>
          </el-form-item>
          <el-form-item label="邮箱:" prop="email" class="">
            <!--去掉了input方法 <el-input :disabled="notCanUpdateUser" v-model="userInfo.formData.email" class="w_240"></el-input> -->
            <el-input :disabled="notCanUpdateUser" v-model="userInfo.formData.email" @input="changeEmail" class="w_300"></el-input>
          </el-form-item>
          <el-form-item label="通讯地址:">
            <el-cascader
              :disabled="notCanUpdateUser"
              ref="cascaderAddr"
              :style="{width: '300px'}"
              v-model="city.cityValue"
              :options="city.cityJson"
              @change="getCityCodeFn"
              @active-item-change="childrenCity">
            </el-cascader>
          <el-input :disabled="notCanUpdateUser" placeholder="请输入常用地址" v-model="userInfo.formData.address" class="mt10" style="width: 300px"></el-input>
        </el-form-item>
         <el-form-item label="使用时间:" class="useTimeDiv" prop="use_start_time">
          <div class="flex_row">
            <el-date-picker
              class="w_140 userTime"
              v-model="userInfo.formData.use_start_time"
              format="yyyy-MM-dd"
              :disabled="notCanUpdateUser"
              value-format="yyyy-MM-dd"
              type="date"
              placeholder="开始时间">
            </el-date-picker>
            <div></div>
            <el-radio-group class="ml10" v-model="userInfo.endtime" :disabled="notCanUpdateUser" @change="noEndTimeFn">
              <el-radio :label=1>
                <el-date-picker
                :disabled="userInfo.endtime===1?false:true"
                v-model="userInfo.formData.use_end_time"
                format="yyyy-MM-dd"
                value-format="yyyy-MM-dd"
                type="date"
                class="w_140"
                placeholder="结束时间">
              </el-date-picker>
              </el-radio>
              <el-radio class="lh40" :label=2>无限期</el-radio>
            </el-radio-group>
          </div>
        </el-form-item>
        <el-form-item label="用户头像:" class="mb0 userIconDiv">
            <el-upload
              class="avatar-uploader"
              v-bind:class="{'headImgUpload': userInfo.formData.head_image}"
              name="files"
              :disabled="notCanUpdateUser"
              multiple
              :show-file-list="false"
              :action="UploadSrc"
              :auto-upload="true"
              :before-upload="chooseUploadImg"
              :http-request="uploadSuc"
            >
              <img v-if="userInfo.formData.head_image" :src="userInfo.formData.head_image" class="avatar headerimg" />
              <i v-if="!userInfo.formData.head_image" class="headIconPlus el-icon-plus"></i>
              <div class="hadUploadImg"><i class="el-icon-delete headIconDelete" @click.stop="deleteHeadImg"></i></div>
            </el-upload>
            <!-- <div v-if="!userInfo.formData.head_image" class="imgTip mt5 f14 clr_oarange">支持jpg、jpeg、bmp、gif、png格式</div>
            <div v-if="!userInfo.formData.head_image" class="imgTip f14 clr_oarange">大小不超过2M</div> -->
            <div  class="imgTip mt5 f14 clr_oarange">支持jpg、jpeg、bmp、gif、png格式</div>
            <div  class="imgTip f14 clr_oarange">大小不超过2M</div>
          </el-form-item>
        </el-col>
        <el-col :span="12" class="instituteInfor">
          <div class="leftTitCon ml15"><span class="leftTitIcon fl">
            </span><span class="leftTit fl">机构信息</span>
            <span v-if="isUpdate" class="officeTip fl">（更换机构或科室，会把之前赋予的权限组删除）</span>
          </div>
          <el-form-item label="用户类别:" prop="institution_type" class="instituteChoose">
            <el-radio-group
              :disabled="notCanUpdateUser"
              v-model="userInfo.formData.institution_type"
              @change="instituteType_change"
              size="small"
            >
              <el-radio
                v-for="(item, index) in instituteTypeArr"
                :label="item.id"
                :key="index"
              >
                {{ item.name }}
              </el-radio>
            </el-radio-group>

            <!-- <el-select
              class="w_300"
              filterable
              :disabled="notCanUpdateUser"
              v-model="userInfo.formData.institution_type"
              placeholder="请选择"
              style="width: 300px"
              @change="instituteType_change"
            >
              <el-option
                v-for="item in instituteTypeArr"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select> -->
          </el-form-item>
          <el-form-item v-if="userInfo.formData.institution_type == 0" label="医院:" prop="institution_id" class="instituteChoose">
            <el-select
              class="w_300"
              filterable
              clearable
              :disabled="notCanUpdateUser"
              v-model="userInfo.formData.institution_id"
              placeholder="请选择"
              style="width: 300px"
              @change="ins_change"
            >
            <!-- <el-option v-if="userInfo.formData.institution_id === '0'" label="请选择" :value="userInfo.formData.office_ids"></el-option> -->
              <el-option label="请选择" :value="'0'"></el-option>
              <el-option
                v-for="item in institutelist"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
            <el-checkbox class="clerkCheckbox ml5" v-model="userInfo.formData.is_clerk">科员</el-checkbox>
          </el-form-item>
          <el-form-item v-if="userInfo.formData.institution_type == 0" label="科室:" prop="office_ids" class="officeItem mb0">
            <!-- <el-select
              class="w_150 myOffice"
              :disabled="notCanUpdateUser"
              v-model="userInfo.formData.office_ids"
              placeholder="请选择"
              style="width: 150px"
            >
              <el-option
                v-for="item in depmentlist"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
            <el-select
              v-model="userInfo.formData.title_code"
              :disabled="notCanUpdateUser"
              filterable
              placeholder="请选择性质"
              class="ml5"
              style="width: 145px;"
            >
              <el-option
                v-for="item in userNatureCodeArr"
                :key="item.id"
                :label="item.dic_name"
                :value="item.dic_code"
              ></el-option>
            </el-select> -->
       
            <div class="choosedCaCon">
              <div class="choosedCa mb10" v-for="(oneSubTable,index) in setSubTableParamsArr" :key="index">
              <el-select v-model="oneSubTable.id"  @change="changedepment" filterable style="width:150px;">
                <el-option
                  v-for="(item,nth) in oneSubTable.departmentArr"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
              <el-select
                v-model="oneSubTable.nature_code"
                :disabled="notCanUpdateUser || !oneSubTable.id"
                filterable
                placeholder="请选择性质"
                class="ml5"
                style="width: 145px;"
              >
              <el-option
                v-for="item in userNatureCodeArr"
                :key="item.id"
                :label="item.dic_name"
                :value="item.dic_code"
              ></el-option>
              </el-select>
              <span class="delAddress dib ml5" v-if="index!=0 || (isUpdate&&oneSubTable.id)" @click="deleteOneOfficeSet(oneSubTable.id)"><i class="iconfont iconshanchu1"> </i></span>
              <el-tooltip placement="top" v-if="index==setSubTableParamsArr.length-1 && hasNoOpenOffice">
                <div slot="content">新增配置</div>
                <span class="addAddress dib ml5" @click="addOneOfficeSet()">
                  <i class="iconfont iconxinzeng f16"></i>
                </span>
              </el-tooltip>
            </div>
            </div>

          </el-form-item>
          <el-form-item v-if="userInfo.formData.institution_type == 0" label="职称:" prop="title_code" class="">
            <el-select
              v-model="userInfo.formData.title_kind_code"
              filterable
              :disabled="notCanUpdateUser"
              placeholder="职称类型"
              style="width: 150px"
              @change="titleChange"
            >
              <el-option
                v-for="item in title_kindlist"
                :key="item.dic_code"
                :label="item.dic_name"
                :value="item.dic_code"
              ></el-option>
            </el-select>
            <el-select
              v-model="userInfo.formData.title_code"
              :disabled="notCanUpdateUser"
              filterable
              placeholder="职称"
              class="ml5"
              style="width: 145px"
            >
              <el-option
                v-for="item in title_list"
                :key="item.dic_code"
                :label="item.dic_name"
                :value="item.dic_code"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item v-if="userInfo.formData.institution_type == 0" label="工号:" prop="work_no" class="">
            <el-input :disabled="notCanUpdateUser" v-model="userInfo.formData.work_no" class="w_240"></el-input>
          </el-form-item>
          <el-form-item label="排序号:" prop="ordinal" class="">
            <el-input :disabled="notCanUpdateUser" v-model="userInfo.formData.ordinal" class="w_240"></el-input>
          </el-form-item>
          <el-form-item v-if="userInfo.formData.institution_type == 1" label="卫健委:" prop="business_system_id" class="weiJianChoose" key="business_system_id">
            <el-select
              class="w_300"
              filterable
              :disabled="notCanUpdateUser"
              v-model="userInfo.formData.business_system_id"
              placeholder="请选择"
              style="width: 300px"
            >
              <el-option
                v-for="item in userInfo.weiJianArr"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item v-if="userInfo.formData.institution_type == 2" label="服务厂商:" prop="business_firm_id" class="firmChoose" key="business_firm_id">
            <el-select
              class="w_300"
              filterable
              :disabled="notCanUpdateUser"
              v-model="userInfo.formData.business_firm_id"
              placeholder="请选择"
              style="width: 300px"
              @change="changeFirm"
            >
              <el-option
                v-for="item in userInfo.firmArr"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item v-if="userInfo.formData.institution_type == 2" label="相关机构:" prop="institution_ids" key="institution_ids" class="relatedInstitute">
              <el-select
                class="w_300"
                filterable
                multiple
                collapse-tags
                :disabled="notCanUpdateUser"
                v-model="userInfo.formData.institution_ids"
                placeholder="请选择"
                style="width: 300px"
              >
                <el-option
                  v-for="item in userInfo.related_institutionArr"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
          </el-form-item>
          <el-form-item label="医生简介:" prop="introduction" class="">
            <el-input :disabled="notCanUpdateUser" class="fl auditTextarea" :resize="'none'" type="textarea" maxlength="1000" show-word-limit v-model="userInfo.formData.introduction"></el-input>
          </el-form-item>
          <el-form-item label="专业擅长:" prop="specialty" class="">
            <el-input :disabled="notCanUpdateUser" class="fl goodAtTextarea" :resize="'none'" type="textarea" maxlength="500" show-word-limit v-model="userInfo.formData.specialty"></el-input>
          </el-form-item>
          <el-form-item label="手写签名:" class="mb0">
            <uploadSignatureImg class="signatureImgDiv" :disabled="notCanUpdateUser" @deleteSignImg="deleteSignImg" @chooseUploadImg="chooseUploadSignImg" :isAutoUpload="true" @uploadSuc="uploadSignatureSuc" :ImgSrc="userInfo.formData.signature" :UploadSrc="UploadSrc" :imgClass="'signature'"></uploadSignatureImg>
            <!-- <div v-if="!userInfo.formData.signature_id" class="imgTip mt5 f14 clr_oarange">支持jpg、jpeg、bmp、gif、png格式</div>
            <div v-if="!userInfo.formData.signature_id" class="imgTip f14 clr_oarange">大小不超过2M</div> -->
            <div  class="imgTip mt5 f14 clr_oarange">支持jpg、jpeg、bmp、gif、png格式</div>
            <div  class="imgTip f14 clr_oarange">大小不超过2M</div>
          </el-form-item>
        </el-col>
      </el-row>
      <div class="dialog_footer">
        <el-form-item class="mt10">
          <el-button size="small" plain @click="submitForm('cancel', 'formData')">取消</el-button>
          <el-button size="small" type="primary" @click="submitForm('submit', 'formData')">保存</el-button>
        </el-form-item>
      </div>
    </el-form>
  </div>
</template>

<script>
import Mgr from '@/utils/SecurityService'
import { getCurTenancyType } from '@/api/commonHttp'
import uploadSignatureImg from '@/components/common/uploadSignatureImg'
// import headerimg from '@/assets/images/common/uploadHeadIcon.png'
export default {
  components: {
    uploadSignatureImg
  },
  props: {
    userInfo: Object,
    institutelist: Array,
    depmentlist: Array,
    title_kindlist: Array,
    title_list: Array,
    userNatureCodeArr: Array,
    city: Object,
    formData: Object,
    isUpdate: Boolean,
    isServiceCenterUserPage:Boolean,
    notCanUpdateUser: Boolean,
    setSubTableParamsArr: Array,
    hasNoOpenOffice: Boolean,
  },
  data () {
    return {
      UploadSrc: '#',
      info: '',
      loading: false,
      clearTime: false,
      initTime: [],
      hasNoOpenCa: false,
      instituteTypeArr: [
        {
          name: '机构用户',
          id: 0,
        },
        {
          name: '厂商用户',
          id: 2,
        }
      ],
    }
  },
  methods: {
    // 获取当前客户类型
    async beganGetTenancyType () {
      const manager = new Mgr();
      const user = await manager.getRole();
      const tenancy_id = sessionStorage.getItem('curTenancyId') || user.profile.tenancy_id
      if (user) {
        const res = await getCurTenancyType({tenancy_id: tenancy_id});
        if (res.code === 0) {
          if (res.data.type == 4) { // 如果客户类型是卫健委
            this.instituteTypeArr = [
              {
                name: '机构用户',
                id: 0,
              },
              {
                name: '卫健用户',
                id: 1,
              },
              {
                name: '厂商用户',
                id: 2,
              }
            ]
          }
        } else {
          this.$message({ type: "error", message: res.msg });
        }
      }
    },
    instituteType_change (val) {
      // 0 机构用户  1卫健用户  2厂商用户
      this.$emit('getFirmOrWeiJianList',val)
    },
    changeFirm (val) {
      this.$emit('changeFirm',val)
    },
    addOneOfficeSet () {
      this.$emit('addOneOfficeSet')
    },
    deleteOneOfficeSet (id) {
      this.$emit('deleteOneOfficeSet',id)
    },
    changedepment (val) {
      this.$emit('changedepment',val)
    },
    // 删除头像
    deleteHeadImg () {
      this.userInfo.formData.head_image = ''
      this.$emit('deleteHeadImg')
    },
    // 删除签名图片
    deleteSignImg () {
      this.userInfo.formData.signature = ''
      this.$emit('deleteSignatureImg')
    },
    validateIdNo () {
      this.$emit('validateIdNo')
    },
    submitForm (type, formName) {
      var info = {
        type: type,
        formName: formName,
        refs: this.$refs
      }
      this.$emit('submitForm', info)
    },
    changePhone () {
      this.$emit('changePhone')
    },
    getUserDetailByPhoneAtCustomer () {
      if (this.isUpdate) {
        return false
      }
      this.$emit('getUserDetailByPhoneAtCustomer')
    },
    changeEmail () {
      this.$emit('changeEmail')
    },
    ins_change (val) {
      this.$emit('ins_change', val, 'add')
    },
    titleChange (val) {
      this.$emit('titleChange', val)
    },
    getCityCodeFn (val) {
      this.$emit('getCityCodeFn', val)
    },
    childrenCity (val) {
      this.$emit('childrenCity', val)
    },
    noEndTimeFn (val) {
      this.$emit('noEndTimeFn', val)
    },
    getDetailByPhone () {
      this.$emit('getDetailByPhone')
    },
    // 文件上传成功
    uploadSuc (param) {
      this.$emit('uploadImgSuc', param, 'user_avator')
    },
    uploadSignatureSuc (param,imgClass) {
      this.$emit('uploadImgSuc', param, imgClass)
    },
    chooseUploadImg (file) {
      this.$emit('chooseUploadImg', file)
    },
    chooseUploadSignImg (file, className, bool) {
      this.$emit('chooseUploadImg', file, className, bool)
    },
  },
  mounted () {
    this.beganGetTenancyType()
    if (!this.isUpdate) {
      this.userInfo.formData.signature = ''
    }
  }
}
</script>
<style scoped lang="less">
  .userinfo{
    .userInforRow{
      padding: 0 20px;
      padding-right:0px;
    }
    ::v-deep .el-form-item{
      margin-bottom:15px;
    }
    .personalInfor,.instituteInfor{
      padding-bottom: 10px;
      width:calc(100% - 408px);
    }
    .instituteInfor{
      max-height: 744px;
      overflow-x: hidden;
      overflow-y: auto;
    }
    .personInforDiv{
      border-right:1px solid #DCDFE6;
      width:408px;
    }
    .userIconDiv{
      // margin-top:15px!important;
    }
    .leftTitCon{
      width:100%;
      height:40px;
      line-height: 40px;
    .leftTitIcon{
      width: 3px;
      height: 15px;
      margin-top:13px;
      background: #0a70b0;
    }
    .leftTit{
      font-weight: 700;
      color: #000000;
      font-size:15px;
      margin-left:8px;
    }
    }
    .userTime{
      height:36px!important;
      line-height: 36px!important;
      ::v-deep .el-input__inner{
        width:140px!important;
      }
      ::v-deep .el-input__icon:after {
        height: initial!important;
      }
    }
   ::v-deep .auditTextarea{
      width:320px;
      height:140px!important;
      .el-textarea__inner{
        height:140px!important;
      }
    }
   ::v-deep .goodAtTextarea{
      width:320px;
      height:118px!important;
      .el-textarea__inner{
        height:118px!important;
      }
   }
  }
  .w_200{
    width: 200px;
  }
  .w_240{
    width: 240px;
  }
  .w_140{
    width: 140px;
  }
  .w_340{
    width: 340px;
  }
  .w_300{
    width: 300px;
  }
  .avatar-uploader{
    height:100px;
    ::v-deep .el-upload--text{
      height:100px;
      width:100px;
      border-radius: 50%;
      border: 1px dashed #c0ccda;
    }
  }
  ::v-deep .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 150px;
    height: 150px;
    line-height: 150px;
    text-align: center;
    background: #f9f9f9;
    border-radius: 50%;
    margin-bottom: 10px;
    border: 1px solid #d9d9d9;
  }
  ::v-deep .signatureImgDiv{
   .avatar-uploader{
     width:200px!important;
     height:80px!important;
   }
  }
  .headerimg{
    width: 100px;
    height: 100px;
    border-radius: 50%;
    padding:5px;
  }
  .headIconPlus{
    font-size: 28px;
    margin-top: 34px;
    color: #8c939d;
  }
  .imgTip{
    line-height: initial!important;
  }
  .officeSelect{
    width:100%;
  }
  .officeTip{
    font-size:14px;
    color:#ff9900;
  }
  .dialog_footer{
    padding-top:0!important;
  }
  .hadUploadImg{
    position: absolute;
    top:0px;
    left:0px;
    width:100px;
    height:100px;
    border-radius: 50%;
    background-color: rgba(0,0,0,.5);
    display: none;
    .headIconDelete{
      font-size:20px;
      color:#fff;
      position: relative;
      top: 40px;
    }
  }

  ::v-deep .headImgUpload{
    .el-upload:hover{
      .hadUploadImg{
        display: block;
      }
    }
  }
  .mb0{
    margin-bottom:0px!important;
  }
  .useTimeDiv{
    margin-bottom:0px;
  }
 ::v-deep .clerkCheckbox{
   .el-checkbox__label{
     padding-left:5px;
   }
 }
.delAddress {
  width: 32px;
  height: 32px;
  line-height: 32px;
  text-align: center;
  border: 1px solid #dcdfe6;
  border-radius: 2px;
  cursor: pointer;
  i {
    color: #da4a4a;
    font-size: 16px;
  }
}

.delAddress:hover {
  border-color: #da4a4a;
  background: #da4a4a;
  i {
    color: #fff;
  }
}
.addAddress {
  width: 32px;
  height: 32px;
  line-height: 32px;
  text-align: center;
  border: 1px solid #dcdfe6;
  border-radius: 2px;
  color: #0a70b0;
  cursor: pointer;

  &:hover {
    border-color: #0a70b0;
    background: #0a70b0;
    color: #fff;
  }
}
::v-deep .instituteChoose{
 .el-form-item__content{
   width:100%;
 }
}
.choosedCa{
  display: flex;
}
::v-deep .relatedInstitute{
  .el-input__inner{
    height:32px!important;
  }
}
::v-deep .officeItem{
  .el-form-item__error{
    top:26px!important;
  }
}
</style>
