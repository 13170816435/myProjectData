<template>
  <div class="CAdialog">
    <div class="caContainer">
    <div class="twoStep">
      <div class="queryDiv">
        <span class="institute-label">所属机构 :</span>
         <el-select
          :disabled="institutionId ? true : false"
          filterable
          v-model="searchData.institution_id"
          placeholder="请选择"
          class="width_240_input"
          @change="insticutionChangeFn"
        >
          <el-option
            v-for="item in institutelist"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          ></el-option>
        </el-select>
        <span class="ml10">关键字 :</span>
        <el-input class="width_180_input ml10"  v-model="searchData.keywords" placeholder="请输入用户姓名或手机号"></el-input>
        <el-button class="searchBtn" type="primary" size="small" @click="getUserListFn('unBind')">查询</el-button>
        <el-button size="small" plain @click="resetSearchDataFn">重置</el-button>
        <div class="mt8">
           <span class="office-label">所属科室 :</span>
          <el-select
            class=""
            filterable
            style="width: 240px"
            :disabled="depmentlist.length === 0"
            v-model="searchData.office_id"
            placeholder="所属科室"
          >
            <el-option
              v-for="item in depmentlist"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>

          <span class="ml10">CA厂商 :</span>
          <el-select
            class="ml4"
            filterable
            style="width: 180px;"
            v-model="searchData.setting_id"
            placeholder="所属厂商"
          >
            <el-option
              v-for="item in tenancyOpenCaList"
              :key="item.setting_id"
              :label="item.name"
              :value="item.setting_id"
            ></el-option>
          </el-select>
        </div>
        
      </div>
      <div class="tableDiv" :class="{ 'noTableData': CAlist.length == 0 }">
        <el-table
          ref="tableList"
          border
          :data="CAlist"
          :height="tableHeight"
          :header-cell-style="{background: '#f5f5f5',color: '#1E1D22'}"
          tooltip-effect="dark"
          style="width: 100%;max-height: 452px"
          :row-key="getRowKeys"
          @selection-change="handleSelectionChange"
          >
          <el-table-column type="selection" width="55" :reserve-selection="true"></el-table-column>
          <el-table-column prop="index" fixed="left" label="序号" width="50">
            <template slot-scope="scope">
              <span>{{(CA_pageInfo.page_index - 1) * CA_pageInfo.page_size + scope.$index + 1}}</span>
            </template>
          </el-table-column>
          <common-table :propData="caUnbindPropData"></common-table>
        </el-table>
      </div>
      <div>
        <pagination-tool :layout="pageLayout" :total="CA_pageInfo.total_count" :page.sync="CA_pageInfo.page_index" :limit.sync="CA_pageInfo.page_size" @pagination="getUserListFn('unBind')" />
      </div>

    </div>
  </div>
   <div slot="footer" class="dialog_footer">
      <el-button plain size="small" @click="closeCAUnBind()">取 消</el-button>
      <el-button type="primary" size="small" @click="finishCaUnBind()">解除绑定</el-button>
    </div>
  </div>
</template>

<script>
import CommonTable from '@/components/common/CommonTable'
import PaginationTool from '@/components/common/PaginationTool'
import { getUserList,getTenancyOpenCaList,getBindUserList } from '@/api/user'
import { getCenterUser }  from '@/api/seviceCenterManage/centerSet'
import { getOfficesLite } from '@/api/commonHttp'
import { UnshiftToArray } from '@/components/commonJs'
export default {
  props: {
    // CAlist: Array,
    CA_bind_userinfo: Object,
    // CA_Pageinfo: Object,
    institutelist:Array,
    serviceCenterId: String
  },
  components: {
    CommonTable,
    PaginationTool
  },
  data () {
    return {
      tableHeight: '100%',
      institutionId: null,
      depmentlist: [],
      CAlist: [],
      tenancyOpenCaList: [],
      currentRowObj: {},
      CA_pageInfo: {
        eof: 1,
        page_index: 1,
        page_size: 10,
        total_count: 0,
        total_pages: 1
      },
      searchData: {
        institution_id: '',
        keywords: '',
        office_id: '',
        setting_id: '',
      },
      pageLayout: 'total, prev, pager, next, jumper',
      caUnbindPropData: [
        { prop: 'name', label: '用户姓名', width: 90 },
        { prop: 'phone', label: '手机号码', width: 130 },
        { prop: 'setting_name', label: 'CA厂商', width: 140},
        { prop: 'institution_name', label: '所属机构', width: 220 },
        { prop: 'office_name', label: '所属科室', width: 200 },
        { prop: 'work_no', label: '工号', width: 95 },
      ],
    }
  },
  methods: {
    // 重置
    resetSearchDataFn () {
     this.searchData = {
        institution_id: '',
        keywords: '',
        office_id: '',
        setting_id: '',
      }
      this.CA_pageInfo = {
        eof: 1,
        page_index: 1,
        page_size: 10,
        total_count: 0,
        total_pages: 1
      }
      this.getUserListFn ('unBind')
    },
    // 机构change
    insticutionChangeFn (val, type) {
      if (val) {
        this.searchData.office_id = ''
        this.getOfficesLiteFn(val)
      }
    },
    // 获取科室列表
    async getOfficesLiteFn (id) {
      var _url = '/offices/lite?institution_id=' + id
      const res = await getOfficesLite(_url)
      if (res.code === 0) {
        this.depmentlist = UnshiftToArray(res.data)
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 获取客户开通了哪些电子签名(ca)
    async beganGetTenancyOpenCaList () {
      const res = await getTenancyOpenCaList()
      if (res.code === 0) {
        this.tenancyOpenCaList = res.data
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 获取userlist type=bind 查询绑定ca用户数据
    async getUserListFn (type) {
      var self = this
      var _parmas = Object.assign({}, self.searchData)
      var _phoneName = ''
      _phoneName = '&keywords=' + _parmas.keywords
      _parmas.offset = self.CA_pageInfo.page_index
      _parmas.limit = self.CA_pageInfo.page_size
      // _parmas.ca_state = 1
      // var CateGory = ''
      // CateGory = '&category=8'
      // var _url = 'state=' + _parmas.state + '&institution_id=' + _parmas.institution_id + '&office_id=' + _parmas.office_id +
      //  '&ca_state=' + _parmas.ca_state + _phoneName + '&offset=' + _parmas.page_index + '&limit=' + _parmas.page_size + CateGory
      let res = {}
      if (this.serviceCenterId) {
        //_url = _url + '&service_center_id=' + this.serviceCenterId
        _url = _url + '&business_system_id=' + this.serviceCenterId + '&business_system_type=telemed'
        res = await getCenterUser(_url)
      } else {
        res = await getBindUserList(_parmas)
      }
      if (res.code === 0) {
        self.loading = false
        res.data.forEach((item, i) => {
          item.index = i + 1
        })
        if (!type) {
          self.tableData = res.data
          self.pageInfo = res.page
        } else {
          self.CAlist = res.data
          self.CA_pageInfo = res.page
        }
      } else {
        self.loading = false
        self.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    handleSelectionChange (val) {
      this.$emit('selectCAListFn', val)
    },
    toBIndKeyFn (type, userObj, rowIndex) {
      if (type === 'cancel') {
        this.kindVal = ''
      }
      this.inputCAKey = ''
      if (userObj) {
        this.currentRowObj = userObj
      }
      if (rowIndex) {
        this.currentRowObj.rowIndex = rowIndex
      }
      this.$emit('tohiddenBindlistFn', type, userObj)
    },
    getRowKeys (val) {
      return val.user_ca_certificate_id
    },
    finishCaUnBind () {
      this.$emit('finishCaUnBind')
    },
    closeCAUnBind () {
      this.$emit('closeCAUnBind')
    }
  },
  mounted () {
    //this.getUserListFn('unBind')
  }
}
</script>
<style lang="less" scoped>
.caContainer{
  padding:0 20px;
}
.queryDiv{
  margin-bottom:10px;
  .institute-label{
    display: inline-block;
    width:75px;
  }
  .office-label{
    display: inline-block;
    width:75px;
  }
  .width_95_input{
    width:95px;
  }
  .width_160_input{
    width:160px;
  }
  .width_240_input{
    width:240px;
  }
  .ml4{
    margin-left:4px;
  }
  .searchBtn{
    margin-left:18px;
  }
  .shortSearchBtn{
    margin-left:8px;
  }
  .bg_e6{
    border:none!important;
    margin-left:8px;
  }
  .bg_e6:hover{
    background:#E6A23C!important;
  }
}
.bindCaStatus{
  color:#19b955;
}
.caSucStatus{
  color:#19B955;
}
.caFailStatus{
  color:#F56C6C;
}
::v-deep .tableDiv{
  height:452px;
  border: 1px solid #EBEEF5;
  border-bottom: none;
  .el-table{
    border:none;
  }
}
</style>
<style>
.CAdialog{
  padding-top: 15px!important;
  padding-bottom:0px!important;
  /* overflow: auto; */
}
</style>
