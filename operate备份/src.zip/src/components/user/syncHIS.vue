<template>
   <div class="syncHisCon">
      <div class="peopleTabDiv">
          <el-radio-group v-model="tabTypeVal" @change="changePeopleType">
            <el-radio-button :label="item.value" v-for="(item, index) in typeArr" :key="index">{{item.name}}</el-radio-button>
           </el-radio-group>
        <el-button v-if="tabTypeVal == 2" type="primary" size="small" @click="handleHis" class="button-right">检测</el-button></div>
        <el-checkbox class="ml10 mb10" v-show="tabTypeVal == 1" :indeterminate="isOfficeIndeterminate" v-model="isCheckedAllOffice" @change="changeCheckedAllOffice">全选/全不选</el-checkbox>
       <div class="tableBox" v-show="tabTypeVal == 1"  :class="{'noTableData':officeTableData.length===0}">
            <el-table
              ref="tableOfficeList"
              border
              :data="officeTableData"
              :height="tableHeight"
              :header-cell-style="{background: '#f5f5f5',color: '#1E1D22'}"
              tooltip-effect="dark"
              :row-key="getOfficeRowKeys"
              @select="selectOfficeCurRow"
              @select-all="selectAllOffice"
              >
              <el-table-column type="selection" width="50" :reserve-selection="true"></el-table-column>
              <el-table-column prop="index" fixed="left" label="序号" width="50">
                <template slot-scope="scope">
                  <span>{{
                    (searchDataOffice.offset - 1) * searchDataOffice.limit + scope.$index + 1
                  }}</span>
                </template>
              </el-table-column>
              <!-- <el-table-column property="name" label="用户姓名" width="100" :show-overflow-tooltip="true"></el-table-column> -->
              <el-table-column prop="office_name" width="200" label="所属科室" :show-overflow-tooltip="true"></el-table-column>
              <el-table-column prop="institution_name" label="所属机构" :show-overflow-tooltip="true"></el-table-column>
            </el-table>
            <div class="blockPage">
              <!-- <pagination-tool  :total="totalOffice" :page.sync="searchDataOffice.offset" :limit.sync="searchDataOffice.limit" @pagination="beganGetHisOfficeList()" /> -->

               <el-pagination :background="true" @size-change="sizeOfficeChange" @current-change="currentOfficeChange"
                :current-page="searchDataOffice.offset" :page-size="searchDataOffice.limit" :page-sizes="pageSizes"
                layout="total, sizes, prev, pager, next, jumper" :total="totalOffice">
              </el-pagination>
            </div>
          </div>

          <el-checkbox class="ml10 mb10" v-show="tabTypeVal == 2" :indeterminate="isUserIndeterminate" v-model="isCheckedAllUser" @change="changeCheckedAllUser">全选/全不选</el-checkbox>
          <div class="tableBox" v-show="tabTypeVal == 2" :class="{'noTableData':userTableData.length===0}">
            <el-table
              ref="tableUserList"
              border
              :data="userTableData"
              :height="tableHeight"
              :header-cell-style="{background: '#f5f5f5',color: '#1E1D22'}"
              tooltip-effect="dark"
              :row-key="getUserRowKeys"
              @select="selectUserCurRow"
              @select-all="selectAllUser"
              >
              <el-table-column type="selection" width="50" :reserve-selection="true" :selectable='selectEnable'></el-table-column>
              <el-table-column prop="index" fixed="left" label="序号" width="50">
                <template slot-scope="scope">
                  <span>{{
                    (searchDataOffice.offset - 1) * searchDataOffice.limit + scope.$index + 1
                  }}</span>
                </template>
              </el-table-column>
              <common-table :propData="userPropData"></common-table>
            </el-table>
            <div class="blockPage">
              <!-- <pagination-tool  :total="totalOffice" :page.sync="searchDataOffice.offset" :limit.sync="searchDataOffice.limit" @pagination="beganGetHisOfficeList()" /> -->

               <el-pagination :background="true" @size-change="sizeUserChange" @current-change="currentUserChange"
                :current-page="searchDataUser.offset" :page-size="searchDataUser.limit" :page-sizes="pageSizes"
                layout="total, sizes, prev, pager, next, jumper" :total="totalUser">
              </el-pagination>
            </div>
          </div>


      <div class="dialog_footer">
        <el-button size="small" plain @click="cancelSyncHis()">取消</el-button>
        <el-button type="primary" size="small" @click="sureSync()"
          >确定</el-button
        >
      </div>
     <el-dialog title="检测结果" :visible.sync="showTestResult" width="900px" :append-to-body="true" :close-on-click-modal="false" v-dialogDrag>
       <div class="inspectTableCon" :class="{'noTableData':userTestResultData.length===0}">
          <el-table
            ref="tableUserList"
            border
            :data="userTestResultData"
            :height="tableHeight"
            :header-cell-style="{background: '#f5f5f5',color: '#1E1D22'}"
            tooltip-effect="dark"
            :row-key="getUserRowKeys"
          >
            <el-table-column prop="index" fixed="left" label="序号" width="50">
              <template slot-scope="scope">
                      <span>{{
                          (searchDataOffice.offset - 1) * searchDataOffice.limit + scope.$index + 1
                        }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="duplicate_phone"  fixed="right" label="手机号是否重复">
              <template slot-scope="scope">
                      <span>{{scope?'是':'否'}}</span>
    <!--             <span>{{scope}}</span>-->
              </template>
            </el-table-column>
            <el-table-column prop="duplicate_work_no" fixed="right" label="工号是否重复">
              <template slot-scope="scope">
                <span>{{scope?'是':'否'}}</span>
                <!--             <span>{{scope}}</span>-->
              </template>
            </el-table-column>


            <common-table :propData="userTestData"></common-table>
          </el-table>
       </div>
       <span slot="footer" class="dialog-footer">
            <el-button size="small" plain @click="showTestResult = false">关 闭</el-button>
           </span>
     </el-dialog>
   </div>
</template>
<script>
import CommonTable from '@/components/common/CommonTable'
import PaginationTool from '@/components/common/PaginationTool'
import {doctorDuplicateList, getHisDoctorList, getHisOfficeList, syncHisOffice, syncHisUser} from '@/api/user'
import chooseAccount from "@/views/PlatformOperation/systemOperate/components/chooseAccount.vue";
export default {
   components: {
     chooseAccount,
    CommonTable,
    PaginationTool
   },
   props: {
     tenancy_id: String
   },
   data () {
     return {
       showTestResult:false,
      isOfficeIndeterminate:true,
      isCheckedAllOffice: false,
      isCheckedAllUser: false,
      isUserIndeterminate:true,
      tabTypeVal: 1,
      pageSizes: [5, 10, 20, 50, 100, 200, 300, 400, 500, 1000], //可选择的一页多少条
      typeArr:[
      {
        name: '科室列表',
        value: 1,
      },
      {
        name: '医生列表',
        value: 2,
      },
     ],
      tableHeight: '100%',
      searchDataOffice: {
        offset:1,
        limit:20,
      },
      CheckedOfficeList: [],
      officeList: [],
      officeTableData: [],
      totalOffice: 0,
      userPropData: [
      { prop: 'name', label: '用户姓名', width: 90 },
      { prop: 'phone', label: '手机号码', width: 150 },
      { prop: 'institution_name', label: '所属机构', width: 220 },
      { prop: 'office_name', label: '所属科室'},
      ],
       userTestData: [
         { prop: 'name', label: '员工姓名', width: 90 },
         { prop: 'phone', label: '手机号码', width: 150 },
         { prop: 'work_no', label: '员工工号' },
         { prop: 'office_name', label: '所属科室'},
         // { prop: 'duplicate_phone', label: '手机号是否重复'},
         // { prop: 'duplicate_work_no', label: '工号是否重复'},
       ],
      searchDataUser: {
        offset:1,
        limit:20,
      },
      userList: [],
      userTableData: [],
       userTestResultData:[],
      totalUser: 0,
      CheckedUserList: [],
      canChooseUserList: [],
     }
   },
   methods: {
    selectEnable(row) {
      var phoneReg = /^1[3456789]\d{9}$/;
      if (phoneReg.test(row.phone)) {
        return true;
      }
    },
    initTableSelect() {
      const self = this
      self.isOfficeIndeterminate = true
      self.isCheckedAllOffice = false
      self.isCheckedAllUser = false
      self.isUserIndeterminate = true
      self.searchDataOffice = {
        offset:1,
        limit:20,
      }
      self.searchDataUser = {
        offset:1,
        limit:20,
      }
      self.$nextTick(() => {
        self.$refs.tableOfficeList.clearSelection()
        self.$refs.tableUserList.clearSelection()
      })
    },
     handleHis (val) {
       this.getDoctorDuplicateList()
       this.showTestResult=true
     },
    changePeopleType (val) {
      // this.userType = val
      // this.adduserlist_pageInfo.page_index = 1
      // this.adduserlist_pageInfo.page_size = 10
      if (val == 1) {
        this.beganGetHisOfficeList()
      } else {
        this.beganGetHisDoctorList()
      }
    },
    //page改变时的回调函数，参数为当前页码
     currentOfficeChange(val) {
      //console.log("翻页，当前为第几页", val);
      this.searchDataOffice.offset = val;
      this.getOfficeTabelData();
    },
    //size改变时回调的函数，参数为当前的size
    sizeOfficeChange(val) {
      //console.log("改变每页多少条，当前一页多少条数据", val);
      this.searchDataOffice.limit = val;
      this.searchDataOffice.offset = 1;
      this.getOfficeTabelData();
    },
    //获取表格数据，自行分页（splice）
    getOfficeTabelData() {
      let data=JSON.parse(JSON.stringify(this.officeList))
      this.officeTableData = data.splice(
        (this.searchDataOffice.offset - 1) * this.searchDataOffice.limit,
        this.searchDataOffice.limit
      );
      this.totalOffice=this.officeList.length
      // 点击下一页时 将下一页的数据行 是否选中
      this.changeCheckedAllOffice(this.isCheckedAllOffice)
    },
    // 获取HIS 科室列表
    async beganGetHisOfficeList() {
      // const res = await getHisOfficeList({ id: this.userInfo.formData.id });
      const res = await getHisOfficeList({tenancy_id: this.tenancy_id});
      if (res.code === 0) {
        this.officeList = res.data
        this.getOfficeTabelData()
      } else {
        this.$message.error(res.msg);
      }
    },
    // 获取HIS 用户列表
    async beganGetHisDoctorList() {
      const self = this
      self.canChooseUserList = []
      const res = await getHisDoctorList({tenancy_id: this.tenancy_id});
      if (res.code === 0) {
        self.userList = res.data
        var phoneReg = /^1[3456789]\d{9}$/;
        if (self.userList.length != 0 ) {
          self.userList.forEach((item) => {
            if (phoneReg.test(item.phone)) {
              self.canChooseUserList.push(item)
            }
          })
          
        }
        self.getUserTabelData();
      } else {
        self.$message.error(res.msg);
      }
    },
    //page改变时的回调函数，参数为当前页码（用户列表分页）
     currentUserChange(val) {
      //console.log("翻页，当前为第几页", val);
      this.searchDataUser.offset = val;
      this.getUserTabelData();
    },
    //size改变时回调的函数，参数为当前的size
    sizeUserChange(val) {
      //console.log("改变每页多少条，当前一页多少条数据", val);
      this.searchDataUser.limit = val;
      this.searchDataUser.offset = 1;
      this.getUserTabelData();
    },
    //获取表格数据，自行分页（splice）
    getUserTabelData() {
      let data=JSON.parse(JSON.stringify(this.userList))
      this.userTableData = data.splice(
        (this.searchDataUser.offset - 1) * this.searchDataUser.limit,
        this.searchDataUser.limit
      );
      this.totalUser=this.userList.length
      // 点击下一页时 将下一页的数据行 是否选中
      this.changeCheckedAllUser(this.isCheckedAllUser)
    },
    getOfficeRowKeys (val) {
      return val.his_dept_id
    },
    getUserRowKeys (val) {
      return val.his_user_id
    },
    // 去重数组对象里面id值相等的
    clearCommonOfficeId (arr) {
      var result = [];
      var obj = {};
      for(var i =0; i<arr.length; i++){
          if(!obj[arr[i].his_dept_id]){
            result.push(arr[i]);
            obj[arr[i].his_dept_id] = true;
          }
      }
      return result
    },
    // 去重数组对象里面id值相等的
    clearCommonUserId (arr) {
      var result = [];
      var obj = {};
      for(var i =0; i<arr.length; i++){
          if(!obj[arr[i].his_user_id]){
            result.push(arr[i]);
            obj[arr[i].his_user_id] = true;
          }
      }
      return result
    },
    // 选择全部的科室
    changeCheckedAllOffice (val) {
      const self = this
      self.isOfficeIndeterminate = false
      // self.officeList.forEach((one, j) => { // 如果用officeList来遍历的话 全选/全不选时 下面的table行不会跟着选中或不选中
      self.officeTableData.forEach((one, j) => {
        self.$nextTick(() => {
          self.$refs.tableOfficeList.toggleRowSelection(one, val);
        });
      });
      if (val) {
        self.CheckedOfficeList = []
        self.CheckedOfficeList = JSON.parse(JSON.stringify(self.officeList))
      } else {
        self.CheckedOfficeList = []
      }
    },
    // 全选科室
    selectAllOffice (val) {
      const self = this
      self.CheckedOfficeList = val
      self.isCheckedAllOffice = (self.CheckedOfficeList.length === self.officeList.length);
      self.isOfficeIndeterminate = self.CheckedOfficeList.length > 0 && self.CheckedOfficeList.length < self.officeList.length;
    },
    // 选中某一行科室
    selectOfficeCurRow (selection, row) {
      const self = this
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1
      // 去掉选中时
      if (!selected) {
        self.CheckedOfficeList.forEach((val,i) => {
           if (val.his_dept_id === row.his_dept_id) {
             self.CheckedOfficeList.splice(i,1)
           }
        })
      } else {
        self.CheckedOfficeList.push(row)
        self.CheckedOfficeList = self.clearCommonOfficeId(self.CheckedOfficeList)
      }
      self.isCheckedAllOffice = (self.CheckedOfficeList.length === self.officeList.length);
      // console.log(self.CheckedOfficeList.length,self.isCheckedAllOffice)
      self.isOfficeIndeterminate = (self.CheckedOfficeList.length > 0 && self.CheckedOfficeList.length < self.officeList.length);
    },
    // 选择全部的用户
    changeCheckedAllUser (val) {
      const self = this
      self.isUserIndeterminate = false
      var phoneReg = /^1[3456789]\d{9}$/;
      // self.userList.forEach((one, j) => {
        self.userTableData.forEach((one, j) => {
          self.$nextTick(() => {
           if (phoneReg.test(one.phone)) {
             self.$refs.tableUserList.toggleRowSelection(one, val);
           }
          });
      });
      if (val) {
        self.CheckedUserList = []
        self.CheckedUserList = JSON.parse(JSON.stringify(self.canChooseUserList))
      } else {
        self.CheckedUserList = []
      }

    },
    // 全选用户
    selectAllUser (val) {
      const self = this
      self.CheckedUserList = val
      self.isCheckedAllUser = (self.CheckedUserList.length === self.canChooseUserList.length);
      self.isUserIndeterminate = (self.CheckedUserList.length > 0 && self.CheckedUserList.length < self.canChooseUserList.length);
      // console.log(val)
      // if (val.length != 0) {// 选中
      //   val.forEach((one) => {
      //     self.CheckedUserList.push(one)
      //   })
      //   // 去重
      //   self.CheckedUserList = self.clearCommonId(self.CheckedUserList)
      // } else { // 不选中
      //   self.userList.forEach((item) => {
      //     self.CheckedUserList.forEach((nth,i)=> {
      //       if (nth.id == item.id) {
      //         self.CheckedUserList.splice(i,1)
      //       }
      //     })
      //   })
      // }
    },
    // 选中某一行用户
    selectUserCurRow (selection, row) {
      const self = this
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1
      // 去掉选中时
      if (!selected) {
        self.CheckedUserList.forEach((val,i) => {
           if (val.his_user_id === row.his_user_id) {
             self.CheckedUserList.splice(i,1)
           }
        })
      } else {
        self.CheckedUserList.push(row)
        self.CheckedUserList = self.clearCommonUserId(self.CheckedUserList)
      }
      self.isCheckedAllUser = (self.CheckedUserList.length === self.canChooseUserList.length);
      self.isUserIndeterminate = (self.CheckedUserList.length > 0 && self.CheckedUserList.length < self.canChooseUserList.length);
    },
    // 取消
    cancelSyncHis() {
      this.$emit('cancelSyncHis')
    },
     //同步医生重复
     async getDoctorDuplicateList() {
       const res = await doctorDuplicateList();
       if (res.code === 0) {
         this.userTestResultData=res.data
       } else {
         this.$message.error(res.msg);
       }
     },
    // 同步科室
    async sureSyncOffice() {
      const res = await syncHisOffice({tenancy_id: this.tenancy_id,offices: this.CheckedOfficeList});
      if (res.code === 0) {
        ///this.userList = res.data
      } else {
        this.$message.error(res.msg);
      }
    },
    // 同步用户
    async sureSyncUser() {
      const res = await syncHisUser({tenancy_id: this.tenancy_id, users: this.CheckedUserList});
      if (res.code === 0) {
        this.$message({type: "success",message: "同步HIS成功",});
        this.$emit('syncHisDataSuc')
      } else {
        this.$message.error(res.msg);
      }
    },
    // 确定同步
    sureSync () {
      // 同步科室
      if (this.tabTypeVal == 1) {
        this.sureSyncOffice()
      } else {
        // 同步用户
        this.sureSyncUser()
      }
    },
   }
}
</script>
<style lang="less" scoped>
.syncHisCon{
  padding:10px 20px;
  padding-bottom: 0px;
  ::v-deep .peopleTabDiv{
   margin-bottom:10px;
    .button-right{
      float: right;
    }
  .el-radio-group{
   height:32px;
   line-height: 30px;
  .el-radio-button__inner{
    height:32px;
    line-height: 30px;
    padding:0 10px!important;
    text-align: center;

  }
  .el-radio-button__orig-radio:checked+.el-radio-button__inner{
      background-color: #0a70b0!important;
      border-color: #0a70b0!important;
  }
 }
}
  ::v-deep .tableBox{
    height:400px;
    .el-table{
      height: calc(100% - 56px)!important;
      .el-table__body-wrapper{
        height: calc(100% - 40px)!important;
        overflow-y: auto;
      }
      .el-table__fixed-body-wrapper{
        height: calc(100% - 42px)!important;
      }
    }
  }
  .dialog_footer{
    padding-right:0px!important;
  }
}
.blockPage{
  border:1px solid #eee;
  border-top:none;
  padding:10px;
}
::v-deep .inspectTableCon{
  padding: 10px 15px;
  height:400px;
  .el-table__body-wrapper{
    height: calc(100% - 40px)!important;
    overflow-y: auto;
  }
  .el-table__fixed-body-wrapper{
    height: calc(100% - 42px)!important;
  }
}
</style>
