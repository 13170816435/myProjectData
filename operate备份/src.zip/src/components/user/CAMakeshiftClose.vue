<template>
   <div class="caCloseCon">
      <div class="tipText">确认要将【{{curUserName}}】的CA进行"临时关闭"吗?</div>
      <div class="tipText">CA默认于次日的00:00:00后重新开启，也可手动配置开启日期</div>
      <el-date-picker
        v-model="closeCaParam.close_time"
        type="datetime"
        value-format="yyyy-MM-dd HH:mm:ss"
        placeholder="选择日期时间">
      </el-date-picker>
      <el-input
        class="reasonInput mt10"
        type="textarea"
        placeholder="请输入原因"
        :resize="'none'"
        maxlength="200" show-word-limit
        v-model="closeCaParam.reason">
      </el-input>
      <div class="warnText">当前操作存在医疗风险,请跟科室确认后再执行</div>
   </div> 
</template>
<script>
export default {
  props: {
    closeCaParam: Object,
    curUserName: String,
  },
  data () {
    return {

    }
  },
  methods: {

  } 
}
</script>
<style lang="less" scoped>
.caCloseCon{
  padding: 10px 20px;
  .tipText{
    line-height: 32px;
    font-size:15px;
    color:#303133;
  }
  .reasonInput {
    height:80px;
    ::v-deep .el-textarea__inner{
      height:80px;
    }
  }
  .warnText{
    line-height: 24px;
    font-size:14px;
    color: #ff9900;
  }
}
</style>
