<template>
  <div class="dialoginfo"
    v-loading="!isImportFinished"
    :element-loading-text="importTip">
    <div class="flex_row lh35">
      <span >上传文件 :</span>
      <el-input v-model="name" class="width_260_input ml5" placeholder="请上传Excel文件"></el-input>
      <el-upload
        class="upload-demo ml15"
        action="#"
        :show-file-list="false"
        :on-change="chooseUploadMyFrx"
        :auto-upload="false"
        >
        <el-button size="small" type="primary">选择文件</el-button>
      </el-upload>
      <!-- <span class="function-btn bg_e6 clr_ff ml10" style="margin-top: 2px" v-bind:class="{'importUsering': !isImportFinished}" @click="importUserFn('import')">开始导入</span> -->
      <span class="function-btn bg_0a clr_ff ml10" style="margin-top: 2px" @click="inspectUserFn()">检测</span>
      <span class="function-btn bg_e6 clr_ff ml10" :class="{'notAllowImport': !isInspectFinished }" style="margin-top: 2px" @click="importUserFn()">开始导入</span>
      <span class="importTip">文件修改后需要重新选择文件进行上传</span>
      <div class="flex_1 tr" style="margin-top: 2px"><a class="function-btn clr_0a ml10 border" :href="subdir+downHerf" download="导入用户模板.xlsx"><i class="iconfont icon-xiazai"></i>下载模板</a></div>
    </div>
    <el-table :data="importUserList" border class="mt15" :height="500">
      <el-table-column property="index" label="序号" width="60"></el-table-column>
      <el-table-column label="检测结果" width="200" v-if="operateType == 'inspect'">
        <template slot-scope="scope">
          <span :class="scope.row.success === true ? 'clr_00' : 'clr_da'">{{scope.row.result}}</span>
        </template>
      </el-table-column>
      <el-table-column label="导入结果" width="200" v-else>
        <template slot-scope="scope">
          <span :class="scope.row.success === true ? 'clr_00' : 'clr_da'">{{scope.row.result}}</span>
        </template>
      </el-table-column>
      <el-table-column property="name" label="姓名" width="80" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="sex" label="性别"  width="80":show-overflow-tooltip="true"></el-table-column>
      <!--等阳总 把云上妇幼的导入 合并到17上来后 得把下面的注释放出来-->
      <!-- <el-table-column property="login_name" label="用户名"  width="120":show-overflow-tooltip="true"></el-table-column> -->
      <!-- <el-table-column property="use_time" label="使用时间"  width="200":show-overflow-tooltip="true"></el-table-column> -->
      <el-table-column property="phone" label="手机号码" width="120" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="id_number" label="身份证号" width="170" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="email" label="邮箱" width="170" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="institution_name" label="所属机构" width="200" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="office_name" label="所属科室" width="110" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="group_name" label="所属用户组" width="120" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="title_kind" label="职称分类" width="80" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="title" label="职称"  width="80" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="work_no" label="工号" width="80" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="address" label="通讯地址" width="200" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="introduction" label="医生简介" width="200" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column property="specialty" label="专业擅长" :show-overflow-tooltip="true"></el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  props: {
    name: String,
    importUserList: Array,
    isImportFinished: Boolean,
    importTip: String,
    isInspectFinished: Boolean,
    operateType: String,
  },
  data () {
    return {
      excel: '',
      importinfo: {
        total: '',
        success: '',
        faild: ''
      },
      downHerf: process.env.NODE_ENV === 'development' ? '/excel/doctorList.xlsx' : '/operate/excel/doctorList.xlsx',
      subdir: window.Config.subdir,
      gridData: []
    }
  },
  methods: {
    chooseUploadMyFrx (file, fileList) {
      this.$emit('chooseUploadFile', file, fileList)
    },
    // 检测用户
    inspectUserFn () {
      if (this.isImportFinished) {
        this.$emit('inspectUserFn')
      }
    },
    // 导入用户
    importUserFn () {
      if (!this.isInspectFinished) {// 没检测完时不允许导入文件 (先检测完再执行导入更安全些)
        return false
      }
      if (this.isImportFinished) {
        this.$emit('importUserFn')
      }
    }
  }
}
</script>

<style lang="less" scoped>
.dialoginfo{
  padding: 15px 20px;
}
.importTip{
  font-size:13px;
  color:#ff9900;
  padding-left:10px;
}
.notAllowImport{
  background:#ededed;
  cursor: not-allowed;
}
</style>
