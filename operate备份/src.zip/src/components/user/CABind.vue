<template>
  <div class="CAdialog">
    <div class="caContainer">
    <div class="stepDiv">
      <el-steps :active="active">
        <el-step title="绑定服务"></el-step>
        <el-step title="绑定用户"></el-step>
        <el-step title="完成绑定"></el-step>
      </el-steps>
    </div>
    <div class="firstStep" v-if="active === 0">
       <div class="stepTit">请选择绑定服务</div>
       <div class="twoKind">
          <div class="oneKind ukeyKind" @click="chooseKind(item)"
            v-for="(item,index) in tenancyOpenCaList"
            :key="index"
            v-bind:class="{'lastKind': (index+1)%3 === 0,'activeKind': (setting_id === item.setting_id),'noOpen':caBindWay !== 0}">
             <!--ukey 方式-->
             <div class="ukeyCon" v-if="item.ca_type === 0">
                <div class="factoryName" :title="item.vendor_name">{{item.vendor_name}}</div>
                <i class="iconfont">&#xe7ba;</i>
                <div class="kindTit">U-KEY</div>
                <div class="kindDesc">需要插入U-Key，自动获取证书 与用户绑定</div>
             </div>
             <!--数字签名 方式-->
             <div class="numberCa" v-if="item.ca_type === 1">
               <div class="factoryName" :title="item.vendor_name">{{item.vendor_name}}</div>
               <i class="iconfont">&#xe7e0;</i>
               <div class="kindTit">移动数字证书</div>
               <div class="kindDesc">支持单个或批量绑定CA唯一标识</div>
             </div>

          </div>

          <!-- <div v-if="caBindWay === 1" class="oneKind" @click="chooseKind(2)" v-bind:class="{'activeKind': kindVal === 2,'noOpen':caBindWay !== 1}">
             <i class="iconfont">&#xe7e0;</i>
             <div class="kindTit">移动数字证书</div>
             <div class="kindDesc">支持单个或批量绑定CA唯一标识</div>
          </div> -->

       </div>
    </div>
    <div class="twoStep" v-if="active === 1">
      <div class="queryDiv">
        <span class="institute-label">所属机构 :</span>
         <el-select
          :disabled="institutionId ? true : false"
          filterable
          v-model="searchData.institution_id"
          placeholder="请选择"
          class="width_180_input"
          @change="insticutionChangeFn"
        >
          <el-option
            v-for="item in institutelist"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          ></el-option>
        </el-select>
        <span class="office-label">所属科室 :</span>
        <el-select
          class=""
          filterable
          style="width: 160px"
          v-bind:class="{'shortInput':kindVal == 1}"
          :disabled="depmentlist.length === 0"
          v-model="searchData.office"
          placeholder="所属科室"
        >
          <el-option
            v-for="item in depmentlist"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          ></el-option>
        </el-select>
        <!-- <el-select class="width_95_input ml10" v-model="s_type" filterable @change="searchData.keywords = ''">
          <el-option label="姓名" value="1"></el-option>
          <el-option label="手机号码" value="2"></el-option>
        </el-select> -->
        <span class="ml10">关键字 :</span>
        <el-input class="width_160_input ml4" v-bind:class="{'shortInput':kindVal == 1}" v-model="searchData.keywords" placeholder="请输入姓名或手机号"></el-input>
        <el-button v-bind:class="{'shortSearchBtn':kindVal == 1}" class="searchBtn" type="primary" size="small" @click="getUserListFn('bind')">查询</el-button>
        <el-button v-bind:class="{'shortSearchBtn':kindVal == 1}" size="small" plain @click="resetSearchDataFn">重置</el-button>
        <!-- <el-button v-if="kindVal == 2" class="bg_e6" type="primary" size="small" @click="moreBindCa">批量绑定</el-button> -->
        <span v-if="kindVal == 1" class="moreBindCaBtn bg_e6"  @click="moreBindCa">批量绑定</span>
      </div>
      <div class="tableDiv" :class="{ 'noTableData': CAlist.length == 0 }">
        <el-table
          ref="tableList"
          border
          :data="CAlist"
          :height="tableHeight"
          :header-cell-style="{background: '#f5f5f5',color: '#1E1D22'}"
          tooltip-effect="dark"
          style="width: 100%;"
          :row-key="getRowKeys"
          >
          <!-- <el-table-column type="selection" width="55" :reserve-selection="true"></el-table-column> -->
          <el-table-column prop="index" fixed="left" label="序号" width="50"></el-table-column>
          <el-table-column prop="index" fixed="left" label="操作" width="70">
            <template slot-scope="scope">
              <span class="clr_0a pointer" @click="toBIndKeyFn('bind',scope.row, scope.$index)">绑定</span>
              <!-- <span class="caFailStatus pointer" v-if="scope.row.ca_state_desc === '已绑定'" @click="toBIndKeyFn('unBind',scope.row, scope.$index)">解绑</span> -->
            </template>
          </el-table-column>
          <!-- <el-table-column prop="ca_state_desc" fixed="left" label="绑定状态" width="90">
            <template slot-scope="scope">
              <span class="caStatus" v-bind:class="{'bindCaStatus':scope.row.ca_state_desc === '已绑定'}">{{scope.row.ca_state_desc}}</span>
            </template>
          </el-table-column> -->
          <common-table :propData="caUnbindPropData"></common-table>
          <!-- <el-table-column prop="name" label="用户姓名" width="90"></el-table-column>
          <el-table-column prop="phone" label="手机号码" width="130"></el-table-column>
          <el-table-column prop="work_on" label="工号" width="95"></el-table-column>
          <el-table-column prop="institution_name"  width="220" label="所属机构"></el-table-column>
          <el-table-column prop="deps" label="所属科室"></el-table-column> -->
        </el-table>
      </div>
      <div>
        <pagination-tool :layout="pageLayout" :total="CA_pageInfo.total_count" :page.sync="CA_pageInfo.page_index" :limit.sync="CA_pageInfo.page_size" @pagination="getUserListFn('bind')" />
      </div>

    </div>
    <!--第三步-->
    <div class="twoStep" v-if="active === 2">
      <div class="caBindStuDiv mb5">
         <span class="firstIcon"></span>
         <i class="iconfont ml10 sucIcon">&#xe634;</i>
         <span class="ml6 caBindLabel">绑定成功：</span>
         <span class="sucNum">{{importCaSucNum}}</span>
         <span class="ml6">条</span>
         <i class="iconfont failIcon ml25">&#xe632;</i>
         <span class="ml6 caBindLabel">绑定失败：</span>
         <span class="failNum">{{importCaFailNum}}</span>
         <span class="ml6">条</span>
      </div>
      <el-table
        ref="bindOvertableList"
        border
        :data="importCAlist"
        height="500"
        :header-cell-style="{background: '#f5f5f5',color: '#1E1D22'}"
        tooltip-effect="dark"
        style="width: 100%;max-height: 450px;margin-bottom:20px;"
        :row-key="getRowKeys"
        >
        <!-- <el-table-column type="selection" width="55" :reserve-selection="true"></el-table-column> -->
        <el-table-column prop="index" fixed="left" label="序号" width="50"></el-table-column>
        <el-table-column prop="result" fixed="left" label="绑定状态" width="230">
          <template slot-scope="scope">
            <span class="caSucStatus" v-bind:class="{'caFailStatus':scope.row.success===false}">{{scope.row.result}}</span>
          </template>
        </el-table-column>
        <common-table :propData="caFinishbindPropData"></common-table>
      </el-table>
      <!-- <div>
        <pagination-tool :layout="pageLayout" :total="CA_pageInfo.total_count" :page.sync="CA_pageInfo.page_index" :limit.sync="CA_pageInfo.page_size" @pagination="getUserListFn('bind')" />
      </div> -->
    </div>
    <el-dialog  width="400px" title="CA证书绑定" :visible.sync="isCABind" append-to-body :before-close="closeCABind" :close-on-click-modal="false" v-dialogDrag>
      <div class="isCAdialog_box">
        <div class="caUserInforDiv">
          <!-- <div class="CA_tips mt15">请提交成功后，再移除UKEY.</div> -->
          <div class="CA_bind_user">
            <div class="flex_row userInforItem"><span class="caUserInforLabel">用户姓名：</span><span class="caUserInforVal userName">{{CA_bind_userinfo.name}}</span></div>
            <div class="flex_row userInforItem"><span class="caUserInforLabel">手机号码：</span><span class="caUserInforVal">{{CA_bind_userinfo.phone}}</span></div>
            <div class="flex_row userInforItem"><span class="caUserInforLabel">工号：</span><span class="caUserInforVal">{{CA_bind_userinfo.work_no}}</span></div>
            <div class="flex_row userInforItem"><span class="caUserInforLabel">所属机构：</span><span class="caUserInforVal">{{CA_bind_userinfo.institution_name}}</span></div>
            <div class="flex_row userInforItem"><span class="caUserInforLabel">CA唯一标识：</span>
               <el-input v-if="kindVal == 0" type="text" class="width_250_input" :value="CAKey" :disabled="true" ></el-input>
               <el-input v-if="kindVal == 1" type="text" class="width_250_input" v-model="inputCAKey" placeholder="请输入"></el-input>
            </div>
          </div>
          <!-- <div class="CA_bind_keyinput flex_row mt15">
            <div class="caKeyLabel">CA唯一标识</div>
            <el-input type="text" class="width_360_input ml5" :value="CAKey" :disabled="true" ></el-input>
          </div> -->
        </div>
        <div class="dialog_footer mt15">
          <el-button plain size="small" @click="closeCABind">取 消</el-button>
          <el-button size="small" type="primary" @click="bindCAlistFn('commit')">确 定</el-button>
        </div>
      </div>
    </el-dialog>

    <el-dialog  width="400px" title="批量绑定" :visible.sync="showMoreBind" append-to-body :close-on-click-modal="false" v-dialogDrag>
      <div class="dialoginfo"
        v-loading="!isImportFinished"
        :element-loading-text="importTip">
        <div class="uploadDiv">
          <div class="uploadFileLabel">上传文件 :</div>
          <el-input v-model="importUserName" class="width_270_input fl" placeholder="请上传Excel文件"></el-input>
          <el-upload
            class="upload-demo fl"
            action="#"
            :show-file-list="false"
            :on-change="chooseUploadFile"
            :auto-upload="false"
            >
            <el-button size="small" type="primary" class="fl chooseFileBtn ml10">选择文件</el-button>
          </el-upload>
          <div class="clear fr mt10 mb20"><a class="function-btn clr_0a ml10 border" href="/operate/excel/caBind.xlsx" download="CA绑定批量导入模板.xlsx"><i class="iconfont icon-xiazai"></i>下载模板</a></div>
        </div>
        <div class="clear dialog_footer mt15">
          <el-button plain size="small" @click="showMoreBind=false">取 消</el-button>
          <el-button size="small" type="primary" @click="beganMoreCaBind">确 定</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
   <div slot="footer" class="dialog_footer">
      <el-button v-if="active === 0" plain size="small" @click="finishCaBind()">取 消</el-button>
      <el-button v-if="active === 1" plain size="small" @click="prevStep()">上一步</el-button>
      <el-button v-if="active === 0" size="small" type="primary" @click="nextStep()">下一步</el-button>
      <el-button v-if="active === 1 || active === 2" type="primary" size="small" @click="finishCaBind()">完成</el-button>
    </div>
  </div>
</template>

<script>
import CommonTable from '@/components/common/CommonTable'
import PaginationTool from '@/components/common/PaginationTool'
import { getUserList, getUnBindUserList, importCa, getTenancyOpenCaList } from '@/api/user'
import { getCenterUser }  from '@/api/seviceCenterManage/centerSet'
import { getOfficesLite } from '@/api/commonHttp'
import { UnshiftToArray } from '@/components/commonJs'
import { getCommonSettingTenancy } from '@/api/platform_costomer/institution'
export default {
  props: {
    caBindWay: Number,
    // CAlist: Array,
    CA_bind_userinfo: Object,
    // CA_Pageinfo: Object,
    isCABind: Boolean,
    CAKey: String,
    institutelist:Array,
    serviceCenterId: String
  },
  components: {
    CommonTable,
    PaginationTool
  },
  data () {
    return {
      tableHeight: '100%',
      active: 0,
      tenancyOpenCaList: [],
      kindVal: "",
      bindCaType: '',
      setting_id: '',
      caConfigVaule: '',
      inputCAKey: '',
      s_type: '1',
      institutionId: null,
      opendCaArr: [],
      depmentlist: [],
      importCAlist: [],
      CAlist: [],
      showMoreBind: false,
      currentRowObj: {},
      CA_pageInfo: {
        eof: 1,
        page_index: 1,
        page_size: 10,
        total_count: 0,
        total_pages: 1
      },
      importCaSucNum: 0,
      importCaFailNum: 0,
      importCAFormData: new CompatibleFormData(),
      searchData: {
        institution_id: '',
        office_id: '',
        keywords: '',
        setting_id: '',
      },
      openedCa: false, // 是否开启了电子签名
      pageLayout: 'total, prev, pager, next, jumper',
      // 批量绑定
      importUserName: '',
      isImportFinished: true,
      importTip: '正在导入中, 请稍后...',
      caUnbindPropData: [
        { prop: 'name', label: '用户姓名', width: 90 },
        { prop: 'phone', label: '手机号码', width: 130 },
        { prop: 'work_no', label: '工号', width: 95 },
        { prop: 'institution_name', label: '所属机构', width: 220 },
        { prop: 'office_name', label: '所属科室'},
      ],
      caFinishbindPropData: [
        { prop: 'name', label: '用户姓名', width: 90 },
        { prop: 'phone', label: '手机号码', width: 130 },
        { prop: 'work_no', label: '工号', width: 95 },
        { prop: 'institution_name', label: '所属机构', width: 220 },
        { prop: 'institution_code', label: '组织机构代码'},
      ]
    }
  },
  methods: {
    // 重置
    resetSearchDataFn () {
     this.searchData = {
        institution_id: '',
        office_id: '',
        keywords: '',
        setting_id: this.setting_id,
      }
      this.CA_pageInfo = {
        eof: 1,
        page_index: 1,
        page_size: 10,
        total_count: 0,
        total_pages: 1
      }
      this.getUserListFn ('bind')
    },
    // 选择绑定方式
    chooseKind (item) {
      this.kindVal = item.ca_type
      this.bindCaType = item.vendor_id
      this.setting_id = item.setting_id
      this.caConfigVaule = item.config_value
      this.searchData.setting_id = item.setting_id
      // caBindWay: 0 是 ukey  1是数字证书
      // if (this.caBindWay === 0 && val !== 0) {
      //   return false
      // }
      // if (this.caBindWay === 1 && val !== 1 ) {
      //   return false
      // }
    },
    // 上一步
    prevStep () {
      this.active = this.active - 1
    },
    // 验证该客户是否开启了 电子签名
    async getcommonSettinginfoFn () {
      const self = this
      self.openedCa = false
      const res = await getCommonSettingTenancy()
      if (res.code === 0) {
        res.data.forEach((val)=> {
          if (val.config_type === 30 && val.state === 1) {
            self.openedCa = true
          }
        })
      } else {
        self.$message({ type: 'error', message: res.msg })
      }
    },
    // 下一步
    async nextStep () {
      if (this.setting_id === '') {
        this.$message({ message: '请选择一种绑定方式', type: 'error' })
        return false
      }
      // 获取配置 读取电子签名是否 开启
      await this.getcommonSettinginfoFn()
      if (!this.openedCa) {
        this.$message({ message: '暂未开启电子签名，请在【外部能力-基础能力】中进行配置', type: 'error' })
        return false
      }
      this.active = this.active + 1
      this.getUserListFn('bind')
      this.$emit('beganInitCa',this.kindVal,this.bindCaType,this.setting_id,this.caConfigVaule)
    },
    // 机构change
    insticutionChangeFn (val, type) {
      if (val) {
        this.searchData.office_id = ''
        this.getOfficesLiteFn(val)
      }
    },
    // 批量绑定
    moreBindCa () {
      this.showMoreBind = true
    },
    // 点击确定 开始批量导入
    async beganMoreCaBind () {
      const self = this
      if (self.importUserName === '') {
        self.$message({ message: '请上传模板文件', type: 'error' })
        return false
      }
      self.isImportFinished = false
      const res = await importCa(self.importCAFormData.compatible())
      if (res.code === 0) {
        self.isImportFinished = true
        self.$message.success('导入完成')
        self.showMoreBind = false
        self.active = 2
        self.importCaSucNum =  0
        self.importCaFailNum = 0
        res.data.forEach((item, i) => {
          item.index = i + 1
          // if (item.result.split('：')[0] === '导入失败：') {
          //   item.state = 0
          // } else {
          //   item.state = 1
          // }
          if (item.success) {
            self.importCaSucNum = self.importCaSucNum + 1
          } else {
            self.importCaFailNum = self.importCaFailNum + 1
          }
        })
        self.importCAlist = res.data
      } else {
        self.$message({ message: `${res.msg}`, type: 'error' })
      }
      
    },
    // 批量绑定上传文档
    chooseUploadFile (file, fileList) {
      if (this.verifyIsFrx(file)) {
        this.importUserName = file.name
        this.importCAFormData.delete('file')
        this.importCAFormData.append('file', file.raw)
        this.importCAFormData.delete('setting_id')
        this.importCAFormData.append('setting_id', this.setting_id)
      }
    },
    verifyIsFrx (file) {
      const fileName = file.raw.name
      //this.currentFileName = file.raw.name
      const type = fileName.substring(fileName.lastIndexOf('.')).toLowerCase()
      var isFrx = null
      isFrx = type === '.xlsk' || type === '.xls' || type === '.xlsx'
      if (!isFrx) {
        this.$message.error('上传文件只能是excel格式!')
        return false
      }
      return isFrx
    },
    // 获取客户开通了哪些电子签名(ca)
    async beganGetTenancyOpenCaList () {
      const res = await getTenancyOpenCaList()
      if (res.code === 0) {
        this.tenancyOpenCaList = res.data
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 获取科室列表
    async getOfficesLiteFn (id) {
      var _url = '/offices/lite?institution_id=' + id
      const res = await getOfficesLite(_url)
      if (res.code === 0) {
        this.depmentlist = UnshiftToArray(res.data)
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 获取userlist type=bind 查询绑定ca用户数据
    async getUserListFn (type) {
      var self = this
      var _parmas = Object.assign({}, self.searchData)
      if (type) {
        _parmas.offset = self.CA_pageInfo.page_index
        _parmas.limit = self.CA_pageInfo.page_size
        //_parmas.ca_state = type === 'bind' ? '0' : '1'
      }
      // var CateGory = ''
      // if (type === 'bind') {
      //   CateGory = '&category=8'
      // }
      // var _url = 'state=' + _parmas.state + '&institution_id=' + _parmas.institution_id + '&office_id=' + _parmas.office +
      //  '&ca_state=' + _parmas.ca_state + _phoneName + '&offset=' + _parmas.page_index + '&limit=' + _parmas.page_size + CateGory
      let res = {}
      if (this.serviceCenterId) {
        //_url = _url + '&service_center_id=' + this.serviceCenterId
        _url = _url + '&business_system_id=' + this.serviceCenterId + '&business_system_type=telemed'
        res = await getCenterUser(_url)
      } else {
        res = await getUnBindUserList(_parmas)
      }
      if (res.code === 0) {
        self.loading = false
        res.data.forEach((item, i) => {
          item.index = i + 1
        })
        if (!type) {
          self.tableData = res.data
          self.pageInfo = res.page
        } else {
          self.CAlist = res.data
          self.CA_pageInfo = res.page
        }
      } else {
        self.loading = false
        self.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    handleSelectionChange (val) {
      this.$emit('selectCAListFn', val)
    },
    toBIndKeyFn (type, userObj, rowIndex) {
      if (type === 'cancel') {
        this.kindVal = ''
        this.setting_id = ''
      }
      this.inputCAKey = ''
      if (userObj) {
        this.currentRowObj = userObj
      }
      if (rowIndex) {
        this.currentRowObj.rowIndex = rowIndex
      }
      this.$emit('tohiddenBindlistFn', type, userObj,this.kindVal)
    },
    bindCAlistFn () {
      if (this.kindVal === 1) {// 数字证书
        if (!this.inputCAKey) {
          this.$message.error('请输入CA唯一标识')
          return false
        }
      }
      this.$emit('bindCAlistFn', this.currentRowObj, this.inputCAKey,this.kindVal)
    },
    finishCaBind () {
      this.active = 0
      this.$emit('finishCaBind')
    },
    // pageSizeChangeFn (info) {
    //   this.$emit('pageSizeChangeFn', info, 'bind')
    // },
    getRowKeys (val) {
      return val.id
    },
    closeCABind () {
      this.$emit('closeCABind')
    },
  },
  mounted () {
    this.beganGetTenancyOpenCaList()
  }
}
</script>
<style lang="less" scoped>
.caContainer{
  padding:0 20px;
  .firstStep{
    padding: 0 15px;
  }
}
::v-deep .stepDiv{
  display: flex;
  justify-content: center;
  margin-bottom:30px;
 .el-step{
   width:204px;
   flex-basis: initial!important;
   .el-step__line{
     left: 32px;
     right: 8px;
     background:#ededed;
   }
   .el-step__icon{
      background:#e1e8ed;
      color:#606266;
      font-size:15px;
      font-family: Arial;
      border:none;
    }
    .el-step__head.is-process{
      .el-step__icon{
        background:#0a70b0;
        color:#fff;
      }
    }
    .el-step__head.is-finish{
      .el-step__icon{
        background:#0a70b0;
        color:#fff;
      }
      .el-step__line{
        background:#0a70b0;
      }
    }
    .el-step__title.is-finish{
      color:#0a70b0!important;
    }
    .el-step__main{
      .el-step__title{
        font-size:14px;
        color:#606266;
        line-height: 18px;
        position: relative;
        left: -15px;
        margin-top: 8px;
      }
      .is-process{
        color:#0a70b0;
        font-weight: initial;
      }
    }
 }
 .el-step:last-of-type{
   width:auto!important;
 }
}
.stepTit{
  font-size:28px;
  line-height: 48px;
  letter-spacing: 2px;
  color:#303133;
  text-align: center;
}
.twoKind{
  display: flex;
  flex-flow: wrap;
  margin-bottom: 25px;
  .oneKind{
    width:280px;
    height:180px;
    margin-top:20px;
    padding:15px 25px 0px 25px;
    border-radius: 3px;
    border:1px solid rgba(10,112,176,0.3);
    cursor: pointer;
    margin-right: 20px;
    .factoryName{
      font-size: 18px;
      font-weight: 700;
      text-align: center;
      overflow:hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
    i{
      font-size:28px;
      color:#e6a23c;
      display: block;
      text-align: center;
    }
    .kindTit{
      font-size:18px;
      margin-bottom: 8px;
      margin-top: 5px;
      line-height: 20px;
      text-align: center;
      color:#1a1a1a;
    }
    .kindDesc{
      font-size:15px;
      color:#303133;
      line-height: 24px;
      text-align: justify;
    }
  }
  .lastKind{
    margin-right: 0!important;
  }
  .oneKind:hover{
    border: 1px solid #0a70b0;
    background: #F1F6FD;
    box-shadow: 0px 4px 8px 0px rgba(0,0,0,0.10);
  }
  .activeKind{
    border: 1px solid #0a70b0;
    box-shadow: 0px 4px 8px 0px rgba(0,0,0,0.10);
    background:#f4f5ff;
  }
  // .noOpen{
  //   cursor: not-allowed;
  //   background:#f9f9f9;
  //   font-size:#909399;
  //   i{
  //     color:#c0c4cc;
  //   }
  // }
}
.queryDiv{
  margin-bottom:10px;
  .institute-label{
    display: inline-block;
    width:75px;
  }
  .office-label{
    display: inline-block;
    width:85px;
    text-align: center;
  }
  .width_95_input{
    width:95px;
  }
  .width_160_input{
    width:160px;
  }
  .shortInput{
    width:145px!important;
  }
  .ml4{
    margin-left:4px;
  }
  .searchBtn{
    margin-left:18px;
  }
  .shortSearchBtn{
    margin-left:8px;
  }
  .bg_e6{
    border:none!important;
    margin-left:8px;
  }
  .bg_e6:hover{
    background:#E6A23C!important;
  }
}
.caStatus{

}
.bindCaStatus{
  color:#19b955;
}
//U-KEY绑定弹窗样式
.caUserInforDiv{
  padding-top:15px;
  .userInforItem{
    margin-bottom:15px;
  }
  .caUserInforLabel{
    width:120px;
    font-size:15px;
    color:#006266;
    line-height: 24px;
    text-align: right;
  }
  .caUserInforVal{
    font-size:15px;
    color:#303133;
    line-height: 24px;
  }
  .userName{
    font-weight: bold;
  }
  .width_250_input{
    width:250px;
  }
}
// 批量绑定样式
.dialoginfo{
  .uploadDiv{
    padding:20px;
  }
  .uploadFileLabel{
    font-size: 14px;
    color:#303133;
    font-weight: bold;
    line-height: 26px;
  }
  .width_270_input{
    width:270px;
  }
  .chooseFileBtn{
    width:80px;
  }
}
// 第三步的样式
.caBindStuDiv{
  background:#faecd8;
  height:30px;
  display: flex;
  align-items: center;
  border-radius: 3px;
  .firstIcon{
    width:3px;
    height:30px;
    border-radius: 1px;
    background:#e6a23c;
  }
  .sucIcon{
    font-size:16px;
    color:#19b955;
  }
  .failIcon{
    font-size:16px;
    color:#f56c6c;
  }
  .caBindLabel{
    font-size:14px;
    color:#303133;
  }
  .sucNum{
    font-size:16px;
    color:#19b955;
    font-weight: bold;
  }
  .failNum{
    font-size:16px;
    color:#f56c6c;
    font-weight: bold;
  }
  .ml6{
    margin-left:6px;
  }
}
.moreBindCaBtn{
  display: inline-block;
  width: 80px;
  height: 32px;
  text-align: center;
  border-radius: 3px;
  line-height: 32px;
  cursor: pointer;
  color:#fff;
  font-size:14px;
}
.caSucStatus{
  color:#19B955;
}
.caFailStatus{
  color:#F56C6C;
}
::v-deep .tableDiv{
  height: 490px;
}
</style>
<style>
.CAdialog{
  padding-top: 15px!important;
  padding-bottom:0px!important;
  /* overflow: auto; */
}
</style>
