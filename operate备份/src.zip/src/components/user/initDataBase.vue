<template>
  <div class="initDataBaseCon">
     <div class="logCon" v-if="initDataBaseList.length != 0">
        <span v-for="(item,index) in initDataBaseList" :key="index" v-html="$replaceRN(item)"></span>
     </div>
     <div class="delLogTit">
        <span class="border-left"></span>删除处理
     </div>
     <div class="delLogCon" :class="{'oneDeletLog': initDataBaseList.length == 0}">
        <span v-for="(item,index) in delLogList" :key="index" v-html="$replaceRN(item)"></span>
     </div>
     <!-- <div class="switchCon">
        <el-switch
          v-model="initDataBaseParam.isOpen"
          active-color="#0a70b0"
          inactive-color="#DCDFE6">
        </el-switch>
        <span class="switchTip">只增不删</span>
     </div> -->
  </div>
</template>
<script>
import { getDataBasePreview } from '@/api/platform_operate/operateUser'
export default {
  props: {
    tenancy_id: String,
    codes: Array,
  },
  data () {
    return { 
      initDataBaseParam: {
        log: '',
        delLog: '',
        isOpen: false,
      },
      delLogList: [],
      initDataBaseList: []
    }
  },
  methods: {
    // 获取数据库升级脚本预览
    async getCurBussessPreview(tenancy_id) {
      const self = this
      const res = await getDataBasePreview({codes: self.codes, tenancy_id: tenancy_id})
      if (res.code === 0) {
        let logResultList = res.data.script
        if (logResultList.length != 0) {
          // 筛选出那些 删除日志  出来
          logResultList.forEach((one) => {
            if (one.indexOf('drop') != -1 || one.indexOf('DROP') != -1) {
              self.delLogList.push(one)
            } else {
              self.initDataBaseList.push(one)
            }
          })
        }
      } else {
        self.$message({ type: 'error', message: res.msg })
      }
    }
  },
  mounted () {
    const self = this
    self.getCurBussessPreview(self.tenancy_id)
  }
}
</script>
<style lang="less" scoped>
.initDataBaseCon{
  padding: 15px 20px 0px 20px;
  position: relative;
  .logCon{
    min-height: 300px;
    max-height: calc(100vh - 357px);
    background:#fafbfc;
    border:1px solid #dcdfe6;
    overflow: auto;
    color:#303133;
    line-height: 18px;
    font-size:14px;
    padding: 10px 15px;
  }
  .delLogTit{
    height: 36px;
    line-height: 36px;
    color:#303133;
    font-size: 15px;
    font-weight: 700;
  }
  .border-left {
    display: inline-block;
    width: 3px;
    height: 14px;
    background: rgba(9, 113, 176, 1);
    margin-right: 7px;
    vertical-align: middle;
    position: relative;
    top: -1.5px;
  }
  .delLogCon{
    height:160px;
    background:#fff6e7;
    border:1px solid rgba(230, 162, 60, 0.5);
    color: #EF5350;
    font-size:14px;
    padding: 10px 15px;
    overflow-y: auto;
    span{
      line-height: 18px;
    }
  }
  .oneDeletLog{
    height:500px;
  }
}
.switchCon{
  position: absolute;
  bottom:-38px;
  .switchTip{
    font-size:15px;
    color:#303133;
    padding-left: 10px;
    position: relative;
    top: 2px;
  }
}
</style>