<template>
   <div class="stopUserCon">
      <div class="stopTit">您是否禁用该用户? 请选择禁用类型</div>
      <div class="userTypeCon mb10">
          <el-radio-group v-model="stopUserParams.disable_type">
              <el-radio :label="item.value" v-for="(item,index) in user_account_disable_type" :key="index">{{item.name}}</el-radio>
          </el-radio-group> 
      </div>
   </div> 
</template>
<script>
export default {
   props: {
    user_account_disable_type: Array,
    stopUserParams: Object,
   },
   data () {
     return {
       sex: 1,
     }
   },
   methods: {

   }
}
</script>
<style lang="less" scoped>
.stopUserCon{
  padding:10px 20px;
  .stopTit{
    line-height: 48px;
    font-size:15px;
    color:#303133;
  }
}
</style>
