<template>
  <div>
    <el-form :model="platformInfo" :rules="rules" ref="platformInfo" label-width="130px" class="demo-ruleForm">
      <div class="container-item-border">
        <div class="container-item-title">网页端信息</div>
        <el-form-item label="平台名称:" prop="name">
          <el-input v-model="platformInfo.name" class="w_300"></el-input>
        </el-form-item>
        <el-form-item class="mt20" label="平台Logo:">
          <el-upload
            class="upload-demo"
            action="#"
            :file-list="uploadInfo.fileList"
            :on-change="chooseUploadMyImg('platform')"
            :auto-upload="false"
            list-type="picture">
            <div v-if="uploadInfo.fileList">
              <el-button size="small" class="operate-btn"><i class="iconfont iconxinzeng mr10"></i>点击上传</el-button>
              <span slot="tip" class="el-upload__tip clr_oarange">（作为网站的Logo显示，格式支持 *.png、*.jpg、*.jpeg、*.bmp等）</span>
            </div>
          </el-upload>
        </el-form-item>
        <!-- <el-form-item class="mt20" label="平台介绍:">
          <quill-editor :content="platformInfo.introduction" :editorOption="editorOption"></quill-editor>
        </el-form-item> -->
        <el-form-item class="mt20" label="网站尾页:" prop="footer">
          <el-input type="textarea" v-model="platformInfo.footer" style="width: 100%;min-height:100px"></el-input>
        </el-form-item>
      </div>
      <div class="container-item-border">
        <div class="container-item-title">移动端信息</div>
        <el-form-item class="mt20" label="移动端Logo:">
          <el-upload
            class="upload-demo"
            action="https://jsonplaceholder.typicode.com/posts/"
            :file-list="uploadInfo.applogoList"
            list-type="picture">
            <el-button size="small" class="operate-btn"><i class="iconfont iconxinzeng mr10"></i>点击上传</el-button>
            <span slot="tip" class="el-upload__tip clr_oarange">（作为网站的Logo显示，格式支持 *.png、*.jpg、*.jpeg、*.bmp等）</span>
          </el-upload>
        </el-form-item>
        <el-form-item class="mt20" label="移动端Banner图:">
          <el-upload
            action="https://jsonplaceholder.typicode.com/posts/"
            list-type="picture-card">
            <i class="el-icon-plus"></i>
          </el-upload>
          <el-dialog :visible.sync="uploadInfo.appbannerVisible">
            <img width="100%" :src="uploadInfo.appbannerList" alt="">
          </el-dialog>
          <div class="clr_oarange f12">(作为移动端首页banner进行轮播，目前支持3张，图片格式支持 *.png、*.jpg、*.jpeg、*.bmp等)</div>
        </el-form-item>
      </div>
      <el-form-item class="tc">
        <el-button class="operate-btn" @click="onSubmit('goback')">上一步</el-button>
        <el-button class="regist-btn" @click="onSubmit('submit', 'platformInfo')">保存</el-button>
        <el-button class="operate-btn" @click="onSubmit('skip')">跳过</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import QuillEditor from '@/components/common/QuillEditor'
export default {
  components: {
    QuillEditor
  },
  props: {
    platformInfo: Object,
    uploadInfo: Object,
    rules: Object,
    editorOption: Array
  }, 
  methods: {
    chooseUploadMyImg (file, fileList) {
      this.$emit('chooseUploadMyImg', {file, fileList})
    },
    onSubmit (type, formName) {
      var info = {
        type: type,
        formName: formName,
        refs: this.$refs
      }
      this.$emit('onSubmit', info)
    }
  }
}
</script>

<style lang="less" scoped>
.regist-btn{
  padding: 0px 20px;
  height:40px;
  line-height: 40px;
  background:rgba(10,112,176,1);
  border:1px solid rgba(10, 112, 176, 1);
  border-radius:4px;
  color: #fff;
}
</style>
