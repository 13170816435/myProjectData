<template>
  <div>
    <el-form :model="customerInfo" :rules="rules" ref="customerInfo" label-width="130px" class="demo-ruleForm mt20">
      <div class="container-item-border">
        <div class="container-item-title">客户类型</div>
        <div class="tc">
          <span class="customer-type" :class="customerparmas.active_customerType == item.value?'active-customer': ''" v-show="item.value" v-for="(item, index) in (customerType)" :key="index" @click="CustomerType(index, item.value)">{{item.name}}</span>
        </div>
      </div>
      <div class="container-item-border">
        <div class="container-item-title">客户信息</div>
        <el-row>
          <el-col :span="12">
            <el-form-item label="客户名称:" prop="name">
              <el-input v-model="customerInfo.name" class="w_300"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="机构入驻日期:" prop="settling_time">
              <el-date-picker v-model="customerInfo.settling_time" type="date" placeholder="选择日期" value-format="yyyy-MM-dd"  class="w_300"> </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row class="mt10">
          <el-form-item label="所  在  地:">
            <el-cascader
              ref="cascaderAddr"
              :style="{width: '300px'}"
              v-model="customerparmas.cityValue"
              :options="customerparmas.cityJson"
              :key="1"
              @change="getCityCodeFn"
              @active-item-change="childrenCity">
            </el-cascader>
          </el-form-item>
        </el-row>
      </div>
      <div class="container-item-border">
      <div class="container-item-title">客户管理员</div>
        <el-row>
          <el-col :span="12">
            <el-form-item label="管理员电话:" prop="admin_phone">
              <el-input type="tel" v-model="customerInfo.admin_phone" class="w_300"  @blur="getNameFn('admin', customerInfo.admin_phone)"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="管理员姓名:" prop="admin_name">
              <el-input type="tel" v-model="customerInfo.admin_name" :disabled="customerparmas.adminnameDisabled?true:false" class="w_300"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </div>
      <div class="container-item-border">
        <div class="container-item-title">管理委托</div>
          <el-form-item label="是否委托:">
            <el-switch v-model="customerparmas.ismandator" @change="changeSwitch($event)">是</el-switch>
          </el-form-item>
          <el-row v-if="customerparmas.ismandator">
            <el-col :span="12">
              <el-form-item label="委托管理人电话:" prop="mandator_phone">
                <el-input type="tel" v-model="customerInfo.mandator_phone" class="w_300" @blur="getNameFn('mandator', customerInfo.mandator_phone)"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="委托管理人姓名:" prop="mandator_name">
                <el-input type="tel" v-model="customerInfo.mandator_name" :disabled="customerparmas.mandatornameDisabled?true:false" class="w_300"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
      </div>
      <el-form-item v-if="customerparmas.isadd">
        <div class="tc mb15">
          <el-checkbox v-model="customerparmas.isagree" class="fz16">我已阅读并同意用户协议</el-checkbox>
          <span class="clr_0a pointer" @click="showDefinitioninfo(definition.use.code, definition.use.name)">《{{definition.use.name}}》</span>
            和<span class="clr_0a pointer" @click="showDefinitioninfo(definition.privacy.code, definition.privacy.name)">《{{definition.privacy.name}}》</span>
        </div>
        <el-button class="regist-btn" @click="onSubmit('customerInfo')">同意协议并注册</el-button>
      </el-form-item>
      <el-form-item v-else>
        <el-button class="regist-btn" :disabled="customerparmas.isCommit" @click="onSubmit('customerInfo', 'update')">保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  props: {
    customerparmas: Object,
    customerInfo: Object,
    rules: Object,
    definition: Object
  },
  data () {
    return {
      cascaderAddr: '',
      props: {
        lable: '',
        value: ''
      }
    }
  },
  computed: {
    ...mapGetters({ customerType: 'tenancyType' })
  },
  methods: {
    CustomerType (index, code) {
      this.$emit('CustomerType', { index: index, code: code })
    },
    onSubmit (formName, type) {
      var info = {
        type: type,
        formName: formName,
        refs: this.$refs
      }
      this.$emit('onSubmit', info)
    },
    // 城市联动
    childrenCity (val) {
      this.$emit('childrenCity', val)
    },
    getCityCodeFn (val, form, thsAreaCode) {
      this.$emit('getCityCodeFn', val)
    },
    getNameFn (type, phone) {
      this.$emit('getNameFn', type, phone)
    },
    showDefinitioninfo (code, name) {
      this.$emit('showDefinitioninfo', code, name)
    },
    changeSwitch (e) {
      this.$emit('changeSwitch', e)
    }
  }
}
</script>

<style lang="less" scoped>
.regist-btn{
  padding: 0px 20px;
  height:40px;
  line-height: 40px;
  background:rgba(10,112,176,1);
  border:1px solid rgba(10, 112, 176, 1);
  border-radius:4px;
  color: #fff;
  margin-left: 38%;
}
</style>
