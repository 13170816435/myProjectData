<template>
  <div class="container">
    <div class="container-servicelist">
      <el-collapse v-model="activeName" @change="setName">
        <el-collapse-item v-for="(item, index) in serviceList" :key="index" @click='stopProp'>
          <div class="flex_row">
            <div class="collapse-title flex_1" slot="title">{{item.name}}</div>
            <div class="flex_1 tr" slot="title">
              <el-switch
                v-model="item.isOpen"
                active-color="#13ce66"
                inactive-color="#409EFF">
              </el-switch>
            </div>
          </div>
          <div class="container-servicelist-collapseitmeinfo">
            <div class="row clr666 mt15">
              <span class="mr5">机构数量 :</span>
              <el-input v-model="serviceinfo.institution_count" type="number" class="w_300"></el-input>
            </div>
            <div class="row clr666 mt15">
              <span class="mr5">用户数量 :</span>
              <el-input v-model="serviceinfo.user_count" type="number" class="w_300" min=0></el-input>
            </div>
            <div class="row clr666 mt15">
              <span class="mr5">设备数量 :</span>
              <el-input v-model="serviceinfo.equipment_count" type="number" class="w_300"></el-input>
            </div>
          </div>
        </el-collapse-item>
      </el-collapse>
      <el-row class="tc mt30">
        <el-button class="regist-btn" @click="onSubmit('platformInfo')">保存</el-button>
      </el-row>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      value: '',
      activeName: '1',
      serviceList: [
        { id: '10001', name: '放射PACS', isOpen: false },
        { id: '10002', name: '超声PACS', isOpen: false },
        { id: '10001', name: '心电PACS', isOpen: false },
        { id: '10001', name: '内镜PACS', isOpen: false },
        { id: '10001', name: '远程影像诊断', isOpen: false },
        { id: '10001', name: '远程心电诊断', isOpen: false },
        { id: '10001', name: '远程会诊', isOpen: false },
        { id: '10001', name: '双向转诊', isOpen: false },
        { id: '10001', name: '影像云存储', isOpen: false }
      ],
      serviceinfo: {
        code: '',
        institution_count: 0,
        user_count: 0,
        equipment_count: 0
      }
    }
  },
  mounted () { },
  methods: {
    BackFn () { },
    goBack () {
      this.$router.go(-1)
    },
    skipFn () {
      this.$router.push('databaseinfo')
    },
    setName () {

    },
    stopProp: function (e) {
      e.stopPropagation()
    },
    handleChange (val) {
      console.log(val)
    },
    onSubmit (formName) { }
  }
}
</script>
<style>
  .collapse-title {
    flex: 1 0 90%;
    order: 1;
    color: #303133;
    font-weight: bold;
  }
  .el-collapse-item__header {
    flex: 1 0 auto;
    order: -1;
  }
</style>

<style lang="less" scoped>
.container-servicelist{
  width: 650px;
  margin: auto;
}
.container-servicelist-collapseitmeinfo{
  padding-left: 120px;
}
.regist-btn{
  padding: 0px 20px;
  height:40px;
  line-height: 40px;
  background:rgba(10,112,176,1);
  border:1px solid rgba(10, 112, 176, 1);
  border-radius:4px;
  color: #fff;
  margin-right: 20px;
}
</style>
