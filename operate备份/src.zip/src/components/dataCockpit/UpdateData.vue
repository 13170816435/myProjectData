<template>
  <div class="update-container">
    <span class="update-label">自动刷新</span>
    <el-select v-model="value" placeholder="请选择" style="width: 100px;">
      <el-option
        v-for="item in options"
        :key="item.value"
        :label="item.label"
        :value="item.value">
      </el-option>
    </el-select>
    <div class="countdown">
      {{countdown}}
    </div>
    <div class="refresh-btn" @click="refresh">
      <img src="@/assets/images/dataCockpit/common/refresh.png" alt="">
    </div>
  </div>
</template>
<script>
export default {
  props: {
    interval: {
      type: Number,
      default: 60
    }
  },
  data() {
    return {
      timer: null,
      countdown: '',
      value: this.interval,
      options: [
        {
          value: 60,
          label: '1分钟'
        },
        {
          value: 600,
          label: '10分钟'
        },
        {
          value: 1800,
          label: '30分钟'
        },
        {
          value: 3600,
          label: '60分钟'
        },
      ]
    }
  },
  watch: {
    value(val) {
      clearInterval(this.timer)
      this.timer = null
      this.startTimer()
    }
  },
  mounted() {
    this.startTimer()
  },
  methods: {
    startTimer() {
      if(this.timer) {
        clearInterval(this.timer)
        this.timer = null
      }
      let time = this.value
      this.setCountdown(time)
      this.timer = setInterval(() => {
        time--
        if(time < 0) {
          time = this.value
          this.refresh()
        }
        this.setCountdown(time)

      }, 1000);
    },
    setCountdown(time) {
      let seconds = 0
      let minutes = 0
      let secondsStr = ''
      let minutesStr = ''
      if(time >= 60) {
        seconds = time%60
        minutes = (time-seconds)/60
      }else {
        seconds = time
      }
      if(seconds < 10) {
        secondsStr = `0${seconds}`
      }else {
        secondsStr = seconds
      }
      if(minutes < 10) {
        minutesStr = `0${minutes}`
      }else {
        minutesStr = minutes
      }
      this.countdown = `${minutesStr}:${secondsStr}`
    },
    refresh() {
      this.$emit('updateData')
    }
  }
}
</script>
<style lang="less" scoped>
.update-container {
  display: flex;
  align-items: center;
  ::v-deep .el-input__inner{
    color: #fff;
    border: 1px solid rgba(106,127,197,.7);
    background: rgba(5,18,52,.5);
  }
}
.update-label {
  margin-right: 5px;
}
.refresh-btn {
  margin-left: 20px;
  cursor: pointer;
}
.countdown {
  margin-left: 5px;
  width: 42px;
}
</style>
