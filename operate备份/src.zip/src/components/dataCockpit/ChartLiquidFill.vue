<template>
  <div class="chart-container" ref="chartContainer">

  </div>
</template>
<script>
import * as echarts from 'echarts'
import 'echarts-liquidfill'

export default {
  props: {
    option: {
      type: Object,
      require: true
    }
  },
  data() {
    return {
      charObj: null
    }
  },
  watch: {
    option:{
      handler () {
        this.charObj = this.charObj || echarts.init(this.$refs.chartContainer)
        const option = this.option
        option && this.charObj.setOption(option)
      } 
    } 
  },
  mounted() {
    if (this.option) {
      this.charObj = echarts.init(this.$refs.chartContainer)
    }
  }
}
</script>
<style lang="less" scoped>
.chart-container {
  width: 100%;
  height: 100%;
}
</style>