<template>
  <div class="chart-container" ref="chartContainer">

  </div>
</template>
<script>
import * as echarts from 'echarts'
export default {
  props: {
    option: {
      type: Object,
      require: true
    },
    page: String,
  },
  data() {
    return {
      charObj: null
    }
  },
  watch: {
    option:{
      handler () {
        this.charObj = this.charObj || echarts.init(this.$refs.chartContainer)
        const option = this.option
        option && this.charObj.setOption(option, { notMerge: true })
        if (this.page == 'intelligentServiceInfo') {// 智能服务->服务详情
          this.charObj.on('legendselectchanged', (params) => {// 监听legend的 切换
            //console.log(params)
            const legendObj = params.selected
            if (params.name == "使用量") {
              option.yAxis[0].name = legendObj[params.name] ? '单位/次':''
              option.series[0].show = legendObj[params.name]
            } else if (params.name == "平均耗时") {
              option.yAxis[1].name = legendObj[params.name] ? '单位/秒':''
              option.series[1].show = legendObj[params.name]
            }
            // 强制同步图例选中状态
            option.legend.selected = params.selected
            
            option && this.charObj.setOption(option, { notMerge: true })
          });
        }
      } 
    } 
  },
  mounted() {
    if (this.option) {
      this.charObj = echarts.init(this.$refs.chartContainer)
      this.charObj.setOption(this.option, { notMerge: true })
    }
  }
}
</script>
<style lang="less" scoped>
.chart-container {
  width: 100%;
  height: 100%;
}
</style>