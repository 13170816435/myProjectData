<template>
  <div class="powerSet">
    <div class="rangDiv">
      <div class="fieldPowerHead">
        <span class="powerIcon fl"></span>
        <span class="fl fieldTit">权重匹配范围</span>
      </div>
      <div class="allRange">
        <!-- <vue-slider class="vueSlideDiv" v-model="value" tooltip="none" :process="process" :min-range="10"> -->
        <!--1.把 change事件和 拖动结束事件 drag-end都加上 （如果只加change事件那拖动事件不会触发 如果只加拖动事件呢 点击时不触发）
                 2. enable-cross设置成false 第二个滑块 不能滑到第一个的前面去
             -->
        <div class="allRangeBox">
          <vue-slider
            class="vueSlideDiv"
            :min="min"
            :enable-cross="false"
            @change="beganChangeThresholdVal"
            :max="max"
            :marks="[0, 100]"
            @drag-end="changeThresholdsVal"
            v-model="value"
            tooltip="none"
            :process="process"
          >
            <template v-slot:process="{ start, end, style, index }">
              <!-- <div class="vue-slider-process" :style="style">
                          <div :class="[
                          'merge-tooltip',
                          'vue-slider-dot-tooltip-inner',
                          'vue-slider-dot-tooltip-inner-top',
                          ]">
                          {{ value[index] }} - {{ value[index + 1] }}
                          </div>
                      </div> -->
              <div class="vue-slider-process" :style="style">
                <div
                  :class="[
                    'merge-tooltip',
                    'vue-slider-dot-tooltip-inner',
                    'vue-slider-dot-tooltip-inner-top',
                  ]"
                >
                  {{ value[index + 1] }}
                </div>
              </div>
            </template>
          </vue-slider>
          <div class="rangFooter">
            <span class="fl rangIconItem"
              ><span class="rangIcon firstIcon"></span>新建索引（不同患者）</span
            >
            <span class="twoIconItem rangIconItem"
              ><span class="rangIcon twoIcon"></span>手动处理（相似患者）</span
            >
            <span class="fr rangIconItem"
              ><span class="rangIcon threeIcon"></span>自动合并（同一患者）</span
            >
          </div>
        </div>

      </div>
    </div>
    <!--字段权重-->
    <div class="fieldPower">
      <div class="fieldPowerHead">
        <span class="powerIcon fl"></span>
        <span class="fl fieldTit">字段权重</span>
        <span class="fl fieldTip">（匹配优先级：支持拖放排序)</span>
        <span class="fl">
          <el-popover
            placement="bottom-start"
            title=""
            popper-class="powerDescPopover"
            width="500"
            trigger="hover"
          >
            <div>
              首先通过“号码+姓名”进行查询。按照身份证号、医保卡号、健康卡号、就诊卡号的顺序。如果身份证号+姓名没检索到，则使用医保卡号+姓名继续检索，直到健康卡号、就诊卡号。如果都没检索到，则作为一个新的患者注册。
              医院请求注册患者记录后，则进行患者信息匹配。匹配的信息如下：医保号、健康卡号、就诊卡号、性别、出生日期、民族、联系电话、婚姻状况、家庭地址、工作单位、邮编、门诊号、住院号等信息。每个信息项完全相同=1；不相同=0，匹配的权重值进行相加。
              <div class="mt15">
                1）自动合并：如果值大于自动合并阈值，默认为90，则判断为同一个患者，进行信息合并；<br />
                2）手工合并：如果值大于手工合并阈值，默认为65，则分配新的临时ID，并记录患者信息到待确认表，由管理人员后续人工处理。<br />
                3）新建索引：如果值小于手工合并阈值，则插入一条新记录到主索引表，分配新的ID。
              </div>
            </div>
            <el-button class="tipButton" slot="reference"
              ><i class="iconfont tipIcon">&#xe720;</i></el-button
            >
          </el-popover>
        </span>
      </div>
      <div class="fieldCon">
        <div class="fieldHead">
          <div class="fieldLabel statusLabel">启用状态</div>
          <div class="fieldLabel level">匹配优先级</div>
          <div class="fieldLabel fieldName">字段名称</div>
          <div class="fieldLabel powerVal pl15">权重值</div>
        </div>
        <div class="allFiled clear" @dragover="dragover($event)">
          <transition-group class="transition-wrapper" name="sort">
            <div
              class="itemFiled"
              v-for="(item, index) in rulesList"
              :key="index - 1"
              :draggable="true"
              @dragstart="dragstart(item)"
              @dragenter="dragenter(item, $event)"
              @dragend="dragend(item, $event)"
              @dragover="dragover($event)"
            >
              <span class="statusLabel">
                <el-switch
                  @change="beganSavePrimaryRules"
                  class="switchStyle"
                  active-color="#409EFF"
                  inactive-color="#F56C6C"
                  active-text="启用"
                  inactive-text="禁用"
                  :active-value="1"
                  :inactive-value="0"
                  v-model="item.status"
                >
                </el-switch>
              </span>
              <span class="level">{{ item.priority }}</span>
              <span class="fieldName">{{ item.item_name }}</span>
              <span class="powerVal">
                <el-slider
                  class="pl15"
                  v-model="item.weight"
                  @change="changeOnePowerVal(item)"
                ></el-slider>
                <el-input-number
                  class="ml10"
                  v-model="item.weight"
                  :min="1"
                  @change="changeOnePowerVal(item)"
                  :max="100"
                  label="描述文字"
                ></el-input-number>

                  <el-tooltip
                      placement="top"
                      class=""
                      v-if="item.item_code == 'MedicalRecordNo' || item.item_code == 'HospitalizationNo'"
                      popper-class="imgModifyCheckTimeTip"
                    >
                      <div slot="content">
                        该属性值由第三方系统动态生成，存在非唯一性风险，不符合患者主索引的静态属性认证规范。原则上不推荐将其作为权重因素。如果项目团队决定在实际应用中采用，必须向医院明确风险，并确保有正式的确认记录。
                      </div>
                    <span class="powerValDesc">该属性值由第三方系统动态生成，存在非唯一性风险，不符合患者主索引的静态属性认证规范。原则上不推荐将其作为权重因素。如果项目团队决定在实际应用中采用，必须向医院明确风险，并确保有正式的确认记录。</span>
                  </el-tooltip>
                  
              </span>
            </div>
          </transition-group>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { changeUserState } from "@/api/user";
import VueSlider from "vue-slider-component";
import "vue-slider-component/theme/antd.css";
import {
  getPrimaryRulesList,
  savePrimaryRules,
  getThresholdsVal,
  saveThresholdsVal,
  getV15PrimaryRulesList,
  saveV15PrimaryRules,
  getV15ThresholdsVal,
  saveV15ThresholdsVal,
} from "@/api/platform_costomer/primaryIndex";
let stopUpDownFun; // 声明节流函数
export default {
  components: {
    VueSlider,
  },
  props: {
    role: String,
  },
  data() {
    return {
      oldData: null, // 开始排序时按住的旧数据
      newData: null, // 拖拽过程的数据
      customerShowObj: {
        value: "",
        num: "",
        rangVal1: 65,
        rangVal2: 48,
        rangVal3: 48,
      },
      min: 0,
      max: 100,
      num1: 65,
      value: [0, 40, 80],
      thresholdsVal: [],
      process: (val) => [
        [val[0], val[1]],
        [val[1], val[2]],
      ],
      rulesList: [],
    };
  },
  methods: {
    // 修改用户状态
    async userStateChangeFn(state, id) {
      const _parmas = {
        id: id,
        state: state,
      };
      const res = await changeUserState(_parmas);
      if (res.code === 0) {
        this.$message.success("修改成功！");
        this.tableData.forEach((item) => {
          if (item.id === id) {
            item.state = state;
          }
        });
      } else {
        this.$message.error(res.msg);
      }
    },
    handleChange() {},
    stateChangeFn() {},
    // 拖动有关的 方法
    dragstart(value) {
      this.oldData = value;
    },
    // 记录移动过程中信息
    dragenter(value, e) {
      this.newData = value;
      e.preventDefault();
    },
    // 拖拽最终操作
    dragend(value, e) {
      if (this.oldData !== this.newData) {
        let oldIndex = this.rulesList.indexOf(this.oldData);
        let newIndex = this.rulesList.indexOf(this.newData);
        let newItems = [...this.rulesList];
        // 删除老的节点
        newItems.splice(oldIndex, 1);
        // 在列表中目标位置增加新的节点
        newItems.splice(newIndex, 0, this.oldData);
        this.rulesList = [...newItems];
        // console.log('this.dataList', this.rulesList)
        this.beganSavePrimaryRules();
      }
    },
    // 拖动事件（主要是为了拖动时鼠标光标不变为禁止）
    dragover(e) {
      e.preventDefault();
    },
    // 获取主索引规则列表
    async beganGetPrimaryRulesList() {
      let res;
      if (this.role === "operate") {
        res = await getPrimaryRulesList();
      } else {
        res = await getV15PrimaryRulesList();
      }

      if (res.code === 0) {
        this.rulesList = res.data;
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // 修改某一项权重值
    async changeOnePowerVal(item) {
      const self = this
      let onePower = [];
      self.rulesList.forEach((val) => {
        if (val.id === item.id) {
          let obj = {
            id: val.id,
            item_code: val.item_code,
            item_name:val.item_name,
            priority: val.priority,
            rule_type: val.rule_type,
            status: val.status,
            weight: val.weight,
          }
          onePower.push(obj);
        }
      });
      //let res;

      
       // 启用 病历号或住院号
      if (item.weight >= 20  && (item.item_code == 'MedicalRecordNo' || item.item_code == 'HospitalizationNo')) {
        self.$confirm(
          '<i class="iconfont icontishi clr_e6 mr5"></i><span class="clr_red">该属性值由第三方系统动态生成，存在非唯一性风险，不符合患者主索引的静态属性认证规范。原则上不推荐将其作为权重因素。如果项目团队决定在实际应用中采用，必须向医院明确风险，并确保有正式的确认记录。</span>',
          "提示",
          {
            distinguishCancelAndClose: true,
            dangerouslyUseHTMLString: true,
            customClass: "primaryChangeStatusAlert",
            confirmButtonText: "确定",
            cancelButtonText: "取消",
          }
        ).then(() => {
          self.beganSavePrimaryRules();
        }).catch(() => {// 取消修改状态
          self.rulesList.forEach((one) => {
            if (item.item_code === one.item_code) {
              self.$set(one, "weight", item.weight);
            }
          });
        }); 
      } else {
        self.beganSavePrimaryRules()
      }



      // if (this.role === "operate") {
      //   res = await savePrimaryRules(onePower);
      // } else {
      //   res = await saveV15PrimaryRules(onePower);
      // }
      // if (res.code === 0) {
      //   //this.rulesList = res.data
      // } else {
      //   this.$message({ message: `${res.msg}`, type: "error" });
      // }
    },
    // 改变状态
    changeStatus (state,item) {
      const self = this
       // 启用 病历号或住院号
      if (state == 1 && (item.item_code == 'MedicalRecordNo' || item.item_code == 'HospitalizationNo')) {
        self.$confirm(
          '<i class="iconfont icontishi clr_e6 mr5"></i><span class="clr_red">该属性值由第三方系统动态生成，存在非唯一性风险，不符合患者主索引的静态属性认证规范。原则上不推荐将其作为权重因素。如果项目团队决定在实际应用中采用，必须向医院明确风险，并确保有正式的确认记录。</span>',
          "提示",
          {
            distinguishCancelAndClose: true,
            dangerouslyUseHTMLString: true,
            customClass: "primaryChangeStatusAlert",
            confirmButtonText: "确定",
            cancelButtonText: "取消",
          }
        ).then(() => {
          self.beganSavePrimaryRules();
        }).catch(() => {// 取消修改状态
          self.rulesList.forEach((one) => {
            if (item.item_code === one.item_code) {
              self.$set(one, "status", 0);
            }
          });
        }); 
      } else {
        self.beganSavePrimaryRules()
      }
    },
    // 保存拖动后 的主索引顺序
    async beganSavePrimaryRules() {
      const self = this
      let ruleParam = []
      self.rulesList.forEach((val, index) => {
        val.priority = index + 1;
        let obj = {
          id: val.id,
          item_code: val.item_code,
          item_name:val.item_name,
          priority: val.priority,
          rule_type: val.rule_type,
          status: val.status,
          weight: val.weight,
        }
        ruleParam.push(obj)
      });
      let res;
      if (self.role === "operate") {
        res = await savePrimaryRules(ruleParam);
      } else {
        res = await saveV15PrimaryRules(ruleParam);
      }
      if (res.code === 0) {
        //self.rulesList = res.data
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // 获取主索引规则列表
    async beganGetThresholdsVal() {
      let res;
      if (this.role === "operate") {
        res = await getThresholdsVal();
      } else {
        res = await getV15ThresholdsVal();
      }
      if (res.code === 0) {
        this.value = [];
        this.value.push(0);
        this.value.push(res.data.new_built);
        this.value.push(res.data.auto_merge);
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    //增加 节流处理
    beganChangeThresholdVal() {
      const self = this;
      stopUpDownFun(() => {
        self.changeThresholdsVal();
      });
    },
    // 保存阈值
    async changeThresholdsVal() {
      let obj = {};
      obj.new_built = this.value[1];
      obj.auto_merge = this.value[2];
      let res;
      if (!this.draging) {
        if (this.role === "operate") {
          res = await saveThresholdsVal(obj);
        } else {
          res = await saveV15ThresholdsVal(obj);
        }
      } else if (this.dragEnd) {
        if (this.role === "operate") {
          res = await saveThresholdsVal(obj);
        } else {
          res = await saveV15ThresholdsVal(obj);
        }
      }

      if (res.code === 0) {
        //this.rulesList = res.data
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
  },
  mounted() {
    let that = this;
    // 初始化节流函数
    stopUpDownFun = that.$throttle(2000);
    // let mySlider = that.$refs.mySlider;
    // let propo = mySlider.children[1]
    // let rightBtn = mySlider.children[3]
    // let leftBtn = mySlider.children[0]
    // leftBtn.style.display = 'none'
    // let myWidth = 0
    that.beganGetPrimaryRulesList();
    that.beganGetThresholdsVal();
    that.$nextTick(() => {
      var leftBtn = document.getElementsByClassName("vue-slider-dot")[0];
      leftBtn.style.display = "none";
    });
  },
};
</script>
<style lang="less" scoped>
.powerSet {
  height: 100%;
  .fieldPower {
    height: calc(100% - 177px);
  }
}
::v-deep .vueSlideDiv {
  margin: 0 164px;
  margin-top: 56px;
  height: 16px !important;
  padding: 0 !important;
  .vue-slider-rail {
    background: #19b955;
  }
  .vue-slider-process {
    background: #409eff;
  }
  .vue-slider-process:first-of-type {
    background: #f56c6c;
  }
  .vue-slider-rail {
    .vue-slider-dot:first-child {
      display: none !important;
    }
    .vue-slider-dot {
      width: 32px !important;
      height: 32px !important;
    }
  }
  .vue-slider-dot-handle {
    border: 4px solid #409eff !important;
  }
  // .vue-slider-dot-handle:first-of-type(1){
  //   border: 4px solid #f56c6c;
  // }
}
.allRange {
  //width: 1050px;
  width:100%;
  height: 135px;
  border: 1px solid #ebeef5;
  .allRangeBox{
    max-width: 1200px;
    margin: 0 auto;
  }
  .rangFooter {
    margin: 0 164px;
    margin-top: 25px;
    text-align: center;
    .rangIconItem {
      .rangIcon {
        float: left;
        width: 14px;
        height: 14px;
        border-radius: 50%;
        top: 4px;
        position: relative;
        margin-right: 5px;
      }
      .firstIcon {
        background: #f56c6c;
      }
      .twoIcon {
        background: #409eff;
      }
      .threeIcon {
        background: #19b955;
      }
    }
    .twoIconItem {
      display: inline-block;
    }
  }
}
.fieldPowerHead {
  // width: 1050px;
  width:100%;
  height: 42px;
  line-height: 42px;
  //   border-bottom: 1px solid #ebeef5;
  .powerIcon {
    width: 4px;
    height: 16px;
    margin-right: 8px;
    background: #0a70b0;
    margin-top: 13px;
  }
  .fieldTit {
    font-size: 15px;
    color: #303133;
    font-weight: bold;
  }
  .fieldTip {
    font-size: 15px;
    color: #909399;
  }
}
.tipButton {
  padding: 0 !important;
  margin-left: 10px;
  border: none;
  .tipIcon {
    font-size: 16px;
    color: #ff9900;
  }
}
.fieldCon {
  // width: 1050px;
  width:100%;
  height: calc(100% - 42px);
  border: 1px solid #ebeef5;
  .fieldHead {
    height: 40px;
    background: #f5f5f5;
    font-size: 15px;
    color: #303133;
    border-bottom: 1px solid #ebeef5;
    display: flex;
  }
  .allFiled {
    height: calc(100% - 40px);
  }
}
.itemFiled {
  color: #606266;
  height: 40px;
  font-size: 14px;
  border-bottom: 1px solid #ebeef5;
  cursor: move;
  display: flex;
  align-items: center;
}
.itemFiled:last-of-type {
  //   border-bottom:none;
}
.powerValDesc{
  flex:1;
  font-size: 15px;
  margin-left:10px;
  color: #e6a23c;
  overflow:hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
::v-deep .statusLabel {
  width: 90px;
  height: 40px;
  line-height: 39px;
  text-align: center;
  border-right: 1px solid #ebeef5;

  .switchStyle .el-switch__label {
    position: absolute;
    display: none;
    color: #fff;
  }
  .switchStyle .el-switch__label--left {
    z-index: 9;
    left: 9px;
  }
  .switchStyle .el-switch__label--right {
    z-index: 9;
    left: -15px;
  }
  .switchStyle .el-switch__label.is-active {
    display: block;
  }
  .switchStyle.el-switch .el-switch__core,
  .el-switch .el-switch__label {
    width: 50px !important;
  }
  .el-switch__label * {
    font-size: 12px !important;
  }
}
.level {
  width: 100px;
  height: 40px;
  line-height: 39px;
  text-align: center;
  border-right: 1px solid #ebeef5;
}
.fieldName {
  width: 130px;
  height: 40px;
  line-height: 39px;
  text-align: center;
  border-right: 1px solid #ebeef5;
}
::v-deep .powerVal {
  width: calc(100% - 320px);
  height: 40px;
  line-height: 39px;
  display: flex;
  //   border-right: 1px solid #ebeef5;

  .el-input-number {
    width: 120px;
    line-height: 32px;
    margin-top: 4px;
    .el-input__inner {
      color: #303133;
      font-weight: bold;
      padding: 0 8px !important;
    }
  }
  .el-input-number__decrease {
    top: 1px;
    width: 34px;
    height: 30px;
  }
  .el-input-number__increase {
    top: 1px;
    width: 34px;
    height: 30px;
  }
  .el-slider {
    width: 240px;
  }
}
.transition-wrapper {
  display: block;
  overflow: auto;
  height: 100%;
}
::v-deep .vue-slider-mark-step {
  display: none;
}
::v-deep .vue-slider-mark-label {
  margin-top: 0px !important;
  font-size: 15px;
  font-weight: bold;
  color: #303133;
}
</style>
<style>
.merge-tooltip {
  position: absolute;
  left: 100%;
  bottom: 100%;
  transform: translate(-50%, -15px);
}
</style>