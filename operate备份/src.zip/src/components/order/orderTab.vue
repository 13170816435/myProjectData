<template>
    <div class="orderTab">
        <div class="oneTab hadSubTab fl mr20" v-bind:class="{'activeHadSub': activeTabNum === 0}"  @click="chooseTab($event,0)">
            <img class="fl" v-if="role === 'customer'" src="@/assets/images/hadSub.png" alt="">
            <img class="fl" v-if="role === 'operation'" src="@/assets/images/waitAssign.png" alt="">
            <div class="fl totalContent">
                <div class="totalNum">{{statisticsObj.pending}}</div>
                <div class="orderStu" v-if="role === 'customer'">已提交</div>
                <div class="orderStu" v-if="role === 'operation'">待分配</div>
            </div>
        </div>
        <div class="oneTab dealingTab fl mr20" v-bind:class="{'activeDealingTab': activeTabNum === 10}"  @click="chooseTab($event,10)">
            <img class="fl" src="@/assets/images/dealing.png" alt="">
            <div class="fl totalContent">
                <div class="totalNum">{{statisticsObj.processing}}</div>
                <div class="orderStu">处理中</div>
            </div>
        </div>
        <div class="oneTab finished fl mr20" v-bind:class="{'activeFinished': activeTabNum === 20}" @click="chooseTab($event,20)">
            <img class="fl" src="@/assets/images/finished.png" alt="">
            <div class="fl totalContent">
                <div class="totalNum">{{statisticsObj.completed}}</div>
                <div class="orderStu">已完成</div>
            </div>
        </div>
        <div class="oneTab closed fl mr20" v-bind:class="{'activeClosed': activeTabNum === 30}" @click="chooseTab($event,30)">
            <img class="fl" src="@/assets/images/closed.png" alt="">
            <div class="fl totalContent">
                <div class="totalNum">{{statisticsObj.closed}}</div>
                <div class="orderStu">已关闭</div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
  props: {
    statisticsObj: {
      type: Object
    },
    role: {
      type: String
    }
  },
  data () {
    return {
      activeTabNum: 0
    }
  },
  methods: {
    chooseTab (e,num) {
     const obj = e.currentTarget
     const arrObj = document.getElementsByClassName('oneTab')
     for (let i = 0; i < arrObj.length; i++) {
        arrObj[i].classList.remove('activeTab')
     }
     obj.classList.add('activeTab')
     if (this.activeTabNum !== num) {
       this.$emit('changTab', num)
     }
     this.activeTabNum = num
    }  
  }
}
</script>
<style lang="less" scoped>
.orderTab{
    margin:15px;
    .oneTab{
        width:247px;
        height:96px;
        border: 1px solid #DCDFE6;
        border-radius: 3px;
        cursor: pointer;
        padding: 15px;
        img {
        //   padding: 15px;
        }
        .totalContent{
            width: 130px;
            font-size: 15px;
            color:#000;
            text-align: center;
          .totalNum{
            font-size:34px;
            font-weight: 700;
            line-height: 34px;
            font-family: arial;
          }
          .orderStu{
            letter-spacing: 2px;
            line-height: 30px;
          }
        }
    }
    .activeTab{
      background: rgba(230,162,60,0.1)
    }
    .activeHadSub, .hadSubTab:hover{
      border-color:rgba(230,162,60,1);
      background: rgba(230,162,60,0.1);
    }
    .activeDealingTab, .dealingTab:hover{
      border-color: rgba(87,151,245,1);
      background:rgba(87,151,245,0.1);
    }
    .activeFinished, .finished:hover{
      border-color: rgba(58,215,120,1);
      background: rgba(58,215,120,0.1); 
    }
    .activeClosed, .closed:hover {
      border-color:rgba(236,127,139,1);
      background:rgba(236,127,139,0.1);
    }
}
.orderTab::after{
    content: '';
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;    
}
@media screen and (max-width:1360px) {
    .oneTab{
        margin-right:15px!important;
    }
}
</style>
