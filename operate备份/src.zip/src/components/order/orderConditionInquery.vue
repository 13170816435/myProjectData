<template>
  <div class="inspectRecord-query">
          <div class="search-bar mb10">
            <div class="searchTop mb10">
              <div class="fl mr5">
                <el-select
                      @change="search"
                      filterable
                      v-model="orderListParam.date_type"
                      class="ele-select_32 width_100_select timeType mr5"
                      placeholder="全部"
                      style="width:100px"
                  >
                    <el-option
                      v-for="(item,index) in timeTypeArr"
                      :key="index"
                      :label="item.name"
                      :value="item.value">
                    </el-option>
                </el-select>
                <el-date-picker
                  @change="search"
                  class="chooseIntervalsPick searchTimePicker"
                  v-model="timer"
                  type="daterange"
                  align="right"
                  value-format="yyyy-MM-dd"
                  unlink-panels
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  :picker-options="pickerOptions"
                ></el-date-picker>
                  
              </div>
              <div class="fl ml15" v-if="role === 'operation'">
                <span class="search-bar-label fl">所属客户 :</span>
                <el-select
                    @change="search"
                    filterable
                    v-model="orderListParam.tenancy_id"
                    placeholder="全部"
                    class="ele-select_32 width_180_select"
                    style="width:180px"
                >
                <el-option value="">全部</el-option>
                    <el-option
                    v-for="(item,index) in customerList"
                    :key="index"
                    :label="item.name"
                    :value="item.id"
                    ></el-option>
                </el-select>
              </div>
              <div class="fl ml15">
                <span class="search-bar-label fl">业务系统 :</span>
                  <el-select
                      @change="search"
                      filterable
                      v-model="orderListParam.business_system"
                      class="ele-select_32 width_180_select"
                      placeholder="全部"
                      style="width:180px"
                  >
                    <el-option value="">全部</el-option>
                    <el-option
                      v-for="(item,index) in systemTypeArr"
                      :key="index"
                      :label="item.name"
                      :value="item.value">
                    </el-option>
                </el-select>
              </div>
            </div>
            <div class="searchBottom clear mt10">
              <div class="fl">
                <span class="search-bar-label fl">工单信息 :</span>
                <el-input class="fl width_265_input" v-on:keyup.enter.native=search v-model="orderListParam.keywords"  placeholder="请输入工单编号或问题描述"></el-input>
              </div>
              <div class="fl ml15" v-if="curTab === 10 || curTab === 20">
                <span class="search-bar-label fl">工<span class="addPadding">程</span>师 :</span>
                <el-input class="fl width_180_input" v-on:keyup.enter.native=search v-model="orderListParam.engineer_info"  placeholder="请输入工程师姓名/手机号"></el-input>
              </div>
              <div class="fl ml15" v-if="curTab === 20">
                <span class="search-bar-label fl">是否评价 :</span>
                <el-select
                    @change="search"
                    filterable
                    v-model="orderListParam.evaluation_state"
                    placeholder="全部"
                    class="ele-select_32 width_180_select"
                    style="width:180px"
                >
                <el-option value="">全部</el-option>
                    <el-option
                    v-for="(item,index) in evateArr"
                    :key="index"
                    :label="item.name"
                    :value="item.value"
                    ></el-option>
                </el-select>
              </div>
              <div class="fl ml15" v-if="curTab === 30">
                <span class="search-bar-label fl">关<span class="addPadding">闭</span>人 :</span>
                <el-input class="fl width_180_input" v-on:keyup.enter.native=search v-model="orderListParam.close_user_info"  placeholder="请输入关闭人姓名/手机号"></el-input>
              </div>
              <div class="fl operateBtnDiv ml20">
                <el-button type="primary" size="small" @click="search">查询</el-button>
                <el-button size="small" plain @click="resetSearch">重置</el-button>
              </div>
            </div>
        </div>
  </div>
</template>
<script>
import { getOrderBusinessSystemAll, getOrderBusinessSystem }  from '@/api/commonHttp'
import { getTenanciesLiteFn } from '@/api/platform_operate/costomer'
export default {
  props: {
    action: {
      type: Number
    },
    timeTypeArr: {
      type: Array
    },
    curTab: {
      type: Number 
    },
    role: {
      type: String
    }
  },
  watch: {
    // 切换tab时  重置查询条件
    curTab: function () {
      this.timer = []
      this.orderListParam = this.$options.data().orderListParam
    }
  },
  data () {
    return {
      timer: [],
      customerList: [],
      pickerOptions: {
        shortcuts: [
          {
            text: '今天',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              // start.setTime(start.getTime() - 3600 * 1000 * 24 * 6);
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 6)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 29)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 89)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      evateArr: [
        {
          name: '已评价',
          value: true
        },
        {
          name: '未评价',
          value: false
        }  
      ],
      width: '240px',
      systemTypeArr: [],
      orderListParam: {
        state: 0,
        keywords: '',
        category: 16,
        tenancy_id: '',
        business_system: '',
        begin_date: '',
        end_date: '',
        date_type: 0,
        engineer_info: '',
        evaluation_state: '',
        close_user_info: '',
        offset: 1,
        limit: 20
      }
    }
  },
  methods: {
    setCategory () {
      if (this.role === 'engineer') {
        this.orderListParam.category = 1024
      } else if (this.role === 'customer') {
        this.orderListParam.category = 16
      } else if (this.role === 'operation') {
        this.orderListParam.category = 4
        this.getCustomerLiteFn()
      } 
    },
    // 获取租户列表
    async getCustomerLiteFn () {
      const res = await getTenanciesLiteFn()
      if (res.code === 0) {
        this.customerList =  res.data
      } else {
        this.$message({ type: 'error', message: res.msg })
      }
    },
    // 重置
    resetSearch () {
      // 初始化查询时间
      this.timer = []
      this.orderListParam = {
        state: 0,
        keywords: '',
        category: 16,
        tenancy_id: '',
        business_system: '',
        begin_date: '',
        end_date: '',
        date_type: 0,
        engineer_info: '',
        evaluation_state: '',
        close_user_info: '',
        offset: 1,
        limit: 20
      }
      // this.timer = []
      this.businessTypeArr = []
      this.setCategory()
      this.$emit('getList', this.orderListParam)
    },
    // 搜索
    search () {
      this.orderListParam.offset = 1
      this.orderListParam.limit = 20
      if (this.timer && this.timer.length !== 0) {
        this.orderListParam.begin_date = this.timer[0]
        this.orderListParam.end_date = this.timer[1]
      } else {
        this.orderListParam.begin_date = ''
        this.orderListParam.end_date = ''
      }
      // console.log(this.orderListParam)
      this.$emit('getList', this.orderListParam)
    },
    // 获取业务系统
    async getBussinessSystem () {
      let res
      if (this.role === 'customer') {   //客户管理里面 是显示已授权过的 业务系统
        res = await getOrderBusinessSystem()
      } else {
        res = await getOrderBusinessSystemAll() // 平台运营那边显示的是所有业务系统
      }
      if (res.code === 0) {
        this.systemTypeArr = res.data
      } else {
        this.$message({ message: `${res.msg}`, type: 'error' })
      }
    }
  },
  created () {
  },
  mounted () {
    // 初始化查询时间
    // this.timer = this.$getDefaultTime(0, -1)
    // this.orderListParam.begin_date = this.timer[0].substr(0, 10)
    // this.orderListParam.end_date = this.timer[1].substr(0, 10)
    this.setCategory()
    this.getBussinessSystem()
    this.search()
  }
}
</script>
<style lang="less" scoped>
.inspectRecord-query{
  margin: 10px;
  .searchTop{
    min-height:32px;
  }
  .timeType{
    position: relative;
    top: -1px;
  }
  .width_265_input{
    width:265px;
  }
  .search-bar .addPadding{
    padding: 0 11px;
  }
  .search-bar .statusLabel{
    width:39px!important;
    min-width: 39px;
    text-align: left!important;
  }
  .operateBtnDiv{
    // margin-left:5px;
  }
}
</style>
