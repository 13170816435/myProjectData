<template>
  <div class="elRateCon">
    <div class="logItem">
      <span class="logLabel fl">
        <!-- <i class="iconfont iconbitian mustIcon"></i> -->
        评价等级：</span
      >
      <el-rate v-model="elRateParam.score"></el-rate>
    </div>
    <div class="logItem">
      <span class="logLabel fl">评价内容：</span>
      <el-input
        class="fl auditTextarea"
        type="textarea"
        :resize="'none'"
        maxlength="100"
        show-word-limit
        v-model="elRateParam.content"
      ></el-input>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    elRateParam: {
      type: Object,
    },
  },
};
</script>
<style lang="less" scoped>
.elRateCon {
  padding: 25px 0px 15px 0px;
  .logItem::after {
    content: "";
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  ::v-deep .logItem {
    clear: both;
    margin-bottom: 10px;
    .logLabel {
      width: 110px;
      text-align: right;
      font-size: 15px;
      color: #303133;
      height: 36px;
      line-height: 36px;
    }
    .auditTextarea {
      width: 360px;
      height: 120px;
      .el-textarea__inner {
        height: 120px;
      }
    }
    .el-rate__icon {
      font-size: 30px;
    }
  }
}
</style>