<template>
  <div class="assignCon">
    <div class="logItem">
      <span class="logLabel fl">工程师：</span>
      <el-input
        class="fl engineerInput mr10"
        v-on:keyup.enter.native="onlyGetOperateUser"
        placeholder="请输入工程师姓名"
        v-model="opertionUserParam.contains_name"
      ></el-input>
      <span class="logLabel fl">手机号：</span>
      <el-input
        class="fl engineerInput mr10"
        v-on:keyup.enter.native="onlyGetOperateUser"
        placeholder="请输入工程师手机号"
        v-model="opertionUserParam.contains_phone"
      ></el-input>
      <el-button type="primary" size="small" @click="onlyGetOperateUser"
        >查询</el-button
      >
      <el-button size="small" plain @click="resetSearch">重置</el-button>
    </div>
    <div
      class="operationUser"
      v-bind:class="{ noTableData: opertionUserArr.length == 0 }"
    >
      <el-table
        :data="opertionUserArr"
        border
        stripe
        height="100%"
        ref="tableAutoScroll"
        highlight-current-row
        @current-change="handleCurrentChange"
        header-row-class-name="strong"
      >
        <!-- <el-table-column
                    type="selection"
                    width="55">
                </el-table-column> -->
        <el-table-column prop="name" label="工程师姓名" width="200">
        </el-table-column>
        <el-table-column prop="phone" label="手机号码"> </el-table-column>
      </el-table>
    </div>
    <div class="logItem mt15">
      <span class="answerLabel logLabel fl">备注信息：</span>
      <el-input
        class="fl auditTextarea"
        type="textarea"
        :resize="'none'"
        maxlength="200"
        show-word-limit
        v-model="assignEngineerParam.remark"
      ></el-input>
    </div>
  </div>
</template>
<script>
import { getUserinfoByLite } from "@/api/platform_costomer/institution";
export default {
  props: {
    closeOrderParam: {
      type: Object,
    },
    assignEngineerParam: Object,
  },
  data() {
    return {
      opertionUserParam: {
        contains_name: "",
        contains_phone: "",
        category: 1024,
      },
      opertionUserArr: [],
    };
  },
  methods: {
    resetSearch() {
      this.opertionUserParam = this.$options.data().opertionUserParam;
      this.onlyGetOperateUser();
    },
    // 获取运维用户
    async onlyGetOperateUser() {
      const self = this;
      //   self.classNameArr = []
      const res = await getUserinfoByLite(self.opertionUserParam);
      if (res.code === 0) {
        self.opertionUserArr = res.data;
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    handleCurrentChange(val) {
      this.$emit("choosedOneEngineer", val);
    },
  },
  mounted() {
    this.onlyGetOperateUser();
  },
};
</script>
<style lang="less" scoped>
.assignCon {
  padding: 10px 20px;
  .logItem::after {
    content: "";
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  .engineerInput {
    width: 148px;
  }
  .operationUser {
    height: 324px;
    ::v-deep .el-table__body-wrapper {
      height: calc(100% - 40px);
      overflow: auto;
    }
  }
  ::v-deep .logItem {
    clear: both;
    margin-bottom: 10px;
    .logLabel {
      //   width: 110px;
      //   text-align: right;
      font-size: 15px;
      color: #303133;
      height: 36px;
      line-height: 36px;
    }
    .answerLabel {
      line-height: initial;
    }
    .auditTextarea {
      width: calc(100% - 75px);
      height: 100px;
      .el-textarea__inner {
        height: 100%;
      }
    }
  }
  .operationUser {
    ::v-deep .current-row td {
      background: #0a70b0 !important;
      color: #fff !important;
      cursor: pointer;
    }
  }
}
</style>