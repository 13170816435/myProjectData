<template>
    <div class="addOrderCon">
         <div class="logItem">
            <span class="logLabel fl">
             <i class="iconfont iconbitian mustIcon"></i>
             业务系统：</span>
            <el-select
                    v-model="addOrderParam.business_system"
                    filterable
                    placeholder="全部"
                    class="ele-select_32 width_360_select fl"
                    style="width:360px"
                >
                <el-option value="">全部</el-option>
                    <el-option
                    v-for="(item,index) in systemTypeArr"
                    :key="index"
                    :label="item.name"
                    :value="item.value"
                    ></el-option>
                </el-select>
        </div>
        <div class="logItem">
            <span class="logLabel fl"><i class="iconfont iconbitian mustIcon"></i>问题描述：</span>
            <el-input class="fl auditTextarea" type="textarea" :resize="'none'" maxlength="500" show-word-limit v-model="addOrderParam.question"></el-input>
        </div>
        <div class="logItem">
            <div class="logLabel uploadTitle fl">上传图片：
                <p class="imgCountTip">(最多5张)</p>
            </div>
            <el-upload
            class="uploadDiv"
            v-bind:class="{'disabledUpload':disabledUpload}"
            action="#"
            :limit="5"
            :disabled="disabledUpload"
            :on-change="handleChange"
            :http-request="uploadSuc"
            :file-list="fileList"
            ref="upload"
            :multiple="true"
            list-type="picture-card"
            :auto-upload="true">
                <i slot="default" class="el-icon-plus"></i>
                <div class="imgDiv" slot="file" slot-scope="{file}">
                <img
                    class="el-upload-list__item-thumbnail"
                    :src="file.url" alt=""
                >
               <span class="el-upload-list__item-actions">
                <span
                class="el-upload-list__item-preview"
                @click="handlePictureCardPreview(file)"
                >
                <i class="el-icon-zoom-in"></i>
                </span>
                <!-- <span
                v-if="!disabled"
                class="el-upload-list__item-delete"
                @click="handleDownload(file)"
                >
                <i class="el-icon-download"></i>
                </span> -->
            <span
              class="el-upload-list__item-delete"
              @click="handleRemove(file)"
            >
              <i class="el-icon-delete"></i>
            </span>
          </span>
        </div>
      </el-upload>
    </div>
    <div class="logItem">
      <span class="logLabel fl">提交人员：</span>
      <el-input
        class="fl subPeopleInput"
        v-model="addOrderParam.submitter_name"
      ></el-input>
      <el-input
        class="fl subPeopleInput ml10"
        v-model="addOrderParam.submitter_phone"
      ></el-input>
    </div>
    <el-dialog :visible.sync="dialogVisible" :append-to-body="true">
      <img width="100%" :src="dialogImageUrl" alt="" />
    </el-dialog>
  </div>
</template>
<script>
import { getOrderBusinessSystem } from "@/api/commonHttp";
export default {
  props: {
    addOrderParam: {
      type: Object,
    },
    isUpdate: {
      type: Boolean,
    },
    fileList: {
      type: Array,
    },
  },
  data() {
    return {
      // fileList 编辑时回显用的
      // fileList: [{name: 'food.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}],
      systemTypeArr: [],
      dialogImageUrl: "",
      dialogVisible: false,
      disabled: false,
      disabledUpload: false,
    };
  },
  methods: {
    // 获取业务系统
    async getBussinessSystem() {
      const res = await getOrderBusinessSystem();
      if (res.code === 0) {
        this.systemTypeArr = res.data;
      } else {
        this.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    handleChange(file, fileList) {
      if (fileList.length === 5) {
        this.disabledUpload = true;
      } else {
        this.disabledUpload = false;
      }
      this.$emit("changeUploadFile", fileList);
    },
    // 上传成功后
    uploadSuc (params) {
      this.$emit('uploadSuc', params)
    },
    handleRemove(file) {
      if (!file.id) {
        let fileList = this.$refs.upload.uploadFiles;
        let index = fileList.findIndex((fileItem) => {
          return fileItem.uid === file.uid;
        });
        fileList.splice(index, 1);
        this.$emit("changeUploadFile", fileList);
        this.disabledUpload = false;
      } else {
        // 说明是删除了已上传的
        let index = this.fileList.findIndex((fileItem) => {
          return fileItem.uid === file.uid;
        });
        this.fileList.splice(index, 1);
        this.$emit("saveToDeleteFile", file);
      }
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    handleDownload(file) {
      console.log(file);
    },
  },
  mounted() {
    this.getBussinessSystem();
  },
};
</script>
<style lang="less" scoped>
.addOrderCon {
  padding: 20px 0px;
  .logItem::after {
    content: "";
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  ::v-deep .logItem {
    clear: both;
    margin-bottom: 10px;
    position: relative;
    .logLabel {
      width: 110px;
      text-align: right;
      font-size: 15px;
      color: #303133;
      height: 36px;
      line-height: 36px;
      .imgCountTip {
        color: #ffbc3a;
        line-height: initial;
        padding-right: 10px;
      }
    }
    .el-upload--picture-card {
      width: 85px !important;
      height: 85px !important;
      line-height: 90px;
    }
    .el-upload-list__item {
      width: 85px !important;
      height: 85px !important;
    }
    .auditTextarea {
      width: 360px;
      height: 120px;
      .el-textarea__inner {
        height: 120px;
      }
    }
    .el-input__inner {
      width: 360px;
      height: 36px;
      line-height: 34px;
    }
    .subPeopleInput {
      width: 175px;
      .el-input__inner {
        width: 175px;
        height: 36px;
        line-height: 34px;
      }
    }
  }
  .uploadTitle {
    position: absolute;
    left: 0;
    top: 0;
  }
  .uploadDiv {
    padding-left: 110px;
  }
  .disabledUpload {
    ::v-deep .el-upload {
      cursor: not-allowed;
    }
  }
}
.imgDiv {
  height: 100%;
}
</style>
