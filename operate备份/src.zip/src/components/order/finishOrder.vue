<template>
  <div class="finishCon">
    <div class="logItem">
      <span class="logLabel fl" v-if="closeOrderParam.state === 20"
        ><i class="iconfont iconbitian mustIcon"></i>处理结果：</span
      >
      <span class="logLabel fl" v-else
        ><i class="iconfont iconbitian mustIcon"></i>关闭原因：</span
      >
      <el-input
        class="fl auditTextarea"
        type="textarea"
        :resize="'none'"
        maxlength="100"
        show-word-limit
        v-model="closeOrderParam.answer"
      ></el-input>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    closeOrderParam: {
      type: Object,
    },
  },
};
</script>
<style lang="less" scoped>
.finishCon {
  padding: 20px 0px 10px 0px;
  .logItem::after {
    content: "";
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  ::v-deep .logItem {
    clear: both;
    margin-bottom: 10px;
    .logLabel {
      width: 110px;
      text-align: right;
      font-size: 15px;
      color: #303133;
      height: 36px;
      line-height: 36px;
    }
    .auditTextarea {
      width: 360px;
      height: 200px;
      .el-textarea__inner {
        height: 200px;
      }
    }
  }
}
</style>