<template>
  <div class="recordDetail" id="recordDetail">
    <div class="recordDetail-title">
      <span class="recordDetail-titleinfo">工单详情</span>
      <span class="orderStatus ml20" v-bind:class="{'hadSubStu': detail.state ===0, 'dealingStu':detail.state ===10, 'finishedStu':detail.state ===20, 'closedStu':detail.state ===30}">{{detail.state_desc}}</span>
      <span @click="closeFn" class="close-btn iconfont iconchuangjianshibai"></span>
    </div>
    <div class="contaner">
      <div class="contaner-info">
        <div class="clear">
            <span class="inforTit">工单信息</span>
        </div>
        <ul class="detail_info_list basicInforHead clear">
          <li class="applyClearFloat fl"><span class="width_80 fl">工单编号：</span><span class="width_220 fl">{{detail.serial_number}}</span></li>
          <li class="fl"><span class="width_80 fl">业务系统：</span><span class="width_220 fl">{{detail.business_system_desc}}</span></li>
          <li class="fl"><span class="width_80 moreContentTit fl">问题描述：</span>
            <span class="info-right moreLineEllipsis moreLineAfter medIconfont diagnosisCon fl" v-html="$replaceRN(detail.question)"
              @click="showAll($event)"></span>
          </li>
          <li class="fl clear"><span class="width_80 fl">图<span class="imgPadding"></span>片：</span>
            <div class="imgShowDiv fl mr10" v-for="(item,index) in imgList" @click="showWatchImg(item, index)" :key="index" v-if="item.src">
              <img class="rateImg" :src="item.src" alt="">
            </div>
            
            
            <!-- <img class="rateImg fl mr10" src="@/assets/images/hadSub.png" alt="">
            <img class="rateImg fl mr10" src="@/assets/images/hadSub.png" alt=""> -->
          </li>
        </ul>
        <div class="clear" v-if="detail.evaluation_state">
           <span class="inforTit">评价信息</span>
           <ul class="detail_info_list clear">
            <li class="applyClearFloat fl"><span class="width_80 fl">评价等级：</span>
              <span class="width_220 fl"><el-rate disabled v-model="detail.score"></el-rate></span>
            </li>
            <li class="fl clear mh30"><span class="width_80 fl moreConTit">评价内容：</span>
            <span class="info-right moreLineEllipsis moreLineAfter medIconfont diagnosisCon fl"
                v-html="$replaceRN(detail.content)"
                @click="showAll($event)">
              </span></li>
          </ul>
        </div>

        <div class="clear">
           <span class="inforTit">状态跟踪</span>
        </div>
        <div class="stepCon">
               <el-timeline>
                  <el-timeline-item
                    v-for="(activity, index) in activities"
                    :key="index"
                    :icon="activity.icon"
                    :type="activity.orderType"
                    :color="activity.color"
                    :size="activity.size"
                    >
                    <span class="stateName" v-bind:class="{'hadSubColor':activity.type === 0, 'updateColor':(activity.type === 5 || activity.type === 20) , 'dealingColor':activity.type === 10 , 'closedColor':activity.type === 30, 'evateColor':activity.type === 40}">{{activity.type_desc}}</span>
                    <span class="timeStamp">{{activity.add_time}}</span>
                    <div class="mt10 detailStateDiv" 
                           >
                          <span class="peopleInfor">操作人：</span>
                          <span class="detailState">{{activity.user_name}}（<span>{{activity.user_phone}}</span>）</span>
                    </div>
                    <div class="mt10 detailStateDiv" v-if="activity.type === 30">
                          <span class="stateDescTip">关闭原因：</span>
                          <span class="moreLineEllipsis moreLineAfter medIconfont detailState" @click="showAllState($event,activity.answer)" v-html="$replaceRN(activity.answer)"></span>
                    </div>
                     <div class="mt10 detailStateDiv" v-if="activity.type === 10">
                          <span class="peopleInfor">工程师：</span>
                          <span class="detailState">{{activity.engineer_name}}（<span>{{activity.engineer_phone}}</span>）</span>
                    </div>
                    <div class="mt10 detailStateDiv" v-if="activity.type === 10">
                          <span class="stateDescTip">备注信息：</span>
                          <span class="moreLineEllipsis moreLineAfter medIconfont detailState" @click="showAllState($event,activity.remark)" v-html="$replaceRN(activity.remark)"></span>
                    </div>
                     <div class="mt10 detailStateDiv" v-if="activity.type === 20">
                          <span class="stateDescTip">处理结果：</span>
                          <span class="moreLineEllipsis moreLineAfter medIconfont detailState" @click="showAllState($event,activity.answer)" v-html="$replaceRN(activity.answer)"></span>
                    </div>
                  </el-timeline-item>
                </el-timeline>
            </div>
      </div>
    </div>
    <el-dialog :append-to-body="true" class="stateDesAlert"  v-bind:title="'详细信息'"  :visible.sync="showDetailStateAlert" width="500px" height="500px" :close-on-click-modal="false" v-dialogDrag>
       <textarea class="curContent" ref="stateDescCon" v-html="$replaceRN(curDetailContent)"></textarea>
       <span slot="footer" class="dialog-footer">
            <el-button size="small" plain @click="showDetailStateAlert = false">取 消</el-button>
            <el-button size="small" type="primary" @click="copyContent">复 制</el-button>
        </span>
    </el-dialog>
    <!-- <div class="operate-btn-div"> -->
      <!-- <el-button class="operate-btn bg_0c" @click="subInfor" icon="iconfont iconzhengchang">提交</el-button> -->
    <!-- </div> -->
    <el-dialog :append-to-body="true" class="stateDesAlert"  v-bind:title="'查看图片'"  :visible.sync="showWatchImgAlert"  :close-on-click-modal="false" v-dialogDrag>
       <watchImg :imgArr="imgList" :currentImgSrc="currentImgSrc" :key="watchImgKey" :currentImgIndex="currentImgIndex"></watchImg>
       <!-- <span slot="footer" class="dialog-footer">
            <el-button size="small" plain @click="showWatchImgAlert = false">关 闭</el-button>
        </span> -->
    </el-dialog>

  </div>
</template>
<script>
// import eventBus from '@/utils/eventBus'
import watchImg from '@/components/common/watchImg' // 分页
import { getServiceOrderAllDetail, getServiceOrderImg } from '@/api/commonHttp'
export default {
  props: {
    orderId: {
      type: String
    },
    // 1-申请 2-审核 3-调度 4-工作 5-记录 6-协助
    action: {
      type: Number
    }
  },
  components: {
    watchImg
    // CommonTable,
    // detail,
    // detailTab
  },
  data () {
    return {
      currentImgIndex:0,
      watchImgKey: 0,
      currentImgSrc:"",
      showWatchImgAlert: false,
      // 详情对像
      detail: {
        referral_case_history: {}
      },
      imgList: [],
      value1: 4,
      activities: [],
      curDetailContent: '',
      showDetailStateAlert: false
    }
  },
  watch: {
    detail () {
      this.$nextTick(() => {
        this.isOmit()
      })
    }
  },
  methods: {
   showWatchImg(obj,nth){
      this.currentImgSrc=obj.src
      this.currentImgIndex = nth
      this.watchImgKey++
      this.showWatchImgAlert=true
    },
    // 判断是否有省略
    isOmit () {
      var oDiv = document.querySelectorAll('#recordDetail .moreLineEllipsis')
      oDiv.forEach(item => {
        if (item.scrollHeight > item.clientHeight) {
          item.classList.remove('moreLineShowAll')
          item.classList.add('showMoreLineAfter')
        } else {
          item.classList.remove('showMoreLineAfter')
          item.classList.remove('moreLineShowAll')
        }
      })
    },
    // 显示所有
    showAll ($event) {
      if ($event.target.scrollHeight > $event.target.clientHeight) {
        // $event.target.classList.remove('showMoreLineAfter')
        $event.target.classList.remove('moreLineAfter')
        $event.target.classList.add('moreLineShowAll')
      } else {
        $event.target.classList.remove('moreLineShowAll')
        // $event.target.classList.add('showMoreLineAfter')
        $event.target.classList.add('moreLineAfter')
      }
    },
    showAllState ($event,content) {
      this.showDetailStateAlert = true
      this.curDetailContent = content
    },
    // 复制
    copyContent () {
      this.$refs.stateDescCon.select()
      document.execCommand("copy")
      this.$message({ message: '复制成功', type: 'success' })
    },
    closeFn () {
      this.$emit('closeFn')
    },
    changeNav (index) { // 切换tab
      this.isActive = index
    },
    async getImgSrc (imgIdsArr) {
        const self = this
       for (var m = 0; m < imgIdsArr.length; m++) {
          var param = {
            src: ''
          }
          self.imgList.push(param)
        }
        for (var m = 0; m < imgIdsArr.length; m++) {
          //res.data.certificate_img[m].id = res.data.certificate_ids[m]
          self.imgList[m].src = ''
          await getServiceOrderImg({id:imgIdsArr[m]}).then((imgFile) => {
              var src='data:image/jpg;base64,'+ btoa(new Uint8Array(imgFile).reduce((data, byte) => data + String.fromCharCode(byte), ''));
              self.imgList[m].src = src
          }).catch(error => {
            self.imgList[m].src = ''
            console.log(error)
          })
        }
        console.log('self.imgList',self.imgList)
      },
    // 获取详情
    getOrderDetail () {
      const _this = this
      _this.activities = []
      getServiceOrderAllDetail({id: _this.orderId}).then(res => {
        if (res.code === 0) {
          _this.detail = res.data
          // 获取图片
          _this.getImgSrc(res.data.images)
          if (_this.detail.logs && _this.detail.logs.length !== 0) {
            _this.detail.logs.forEach((val, index) => {
              if (val.type === 0) {
                val.size = 'large'
                val.orderType = 'primary'
                val.icon = 'el-icon-more'
              }
              // 默认为成功的颜色
              val.color = '#409eff'
              // 给其它加上颜色
              if (val.type === 0) {
                val.color = '#ff9900'
              } else if (val.type === 10 ) { // 指派工程师
                val.color = '#409eff'
              } else if (val.type === 20 || val.type ===  5) { // 给所有失败加上颜色
                val.color = '#19b955'
              } else if (val.type === 30) { // 给所有失败加上颜色
                val.color = '#f56c6c'
              } else if (val.type === 40) {
                val.color = '#E6A23C'
              }
              _this.activities.unshift(val)
            })
          } else {
            _this.activities = []
          }
        } else {
          _this.$message.error(res.msg)
        }
      })
    }
  },
  created () {
    if (this.orderId) {
     this.getOrderDetail(this.orderId)
    }
    
    // eventBus.$on('hadBeganConsult', () => {
    //   this.getOrderDetail()
    // })
  },
  mounted () {

  }
}
</script>
<style lang="less" scoped>
.recordDetail {
  width: 750px;
  height: 100%;
  padding: 0px 25px;
  .recordDetail-title {
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    .recordDetail-titleinfo {
      font-size: 16px;
      color: #303133;
      font-weight: 700;
    }
    .clr_00a {
      background: rgba(0, 173, 120, 1);
    }
    .close-btn {
      position: absolute;
      right: 0px;
      top: 0px;
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .contaner {
    height: calc(100% - 65px);
    border: 1px solid #dcdfe6;
    overflow-y: auto;
    .failreson {
      height: 42px;
      line-height: 42px;
      padding: 0px 10px;
      background: #fff6f7;
      .clr_88 {
        color: #888888;
      }
      .clr_da {
        color: #da4a4a;
      }
    }
  }

}
.addPadding7{
  padding:0 7.5px;
}
.inforTit {
    float: left;
    padding-left: 10px;
    color: #333;
    font-size: 15px;
    height: 40px;
    line-height: 40px;
    position: relative;
    text-indent: 10px;
    width: 100%;
    background: #fafafd;
}
.inforTit:before {
    position: absolute;
    left: 10px;
    top: 14px;
    width: 3px;
    height: 14px;
    background: #0a70b0;
    content: '';
}
.detail_info_list {
    padding: 8px 10px;
    border-bottom: 1px dashed #d5e2f3;
}
.detail_info_list li {
    float: left;
    line-height: 30px;
    margin-bottom: 8px;
    position: relative;
}
.imgShowDiv{
  width:80px;
  height:80px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  cursor: pointer;
  img {
    width:auto;
    height:auto;
    max-width: 100%;
    max-height: 100%;
  }
}
.moreConTit{
  position:absolute;
  left: 0;
  top: 0;
}
.width_80 {
    float: left;
    width: 80px;
    font-size:15px;
    text-align: left;
    color: #888;
}
.width_220{
    float: left;
    width: 220px;
    font-size:15px;
    text-align: left;
    color: #303133;
    ::v-deep .el-rate{
      // margin-top:5px;
    }
    ::v-deep .el-rate__icon{
      font-size:30px;
    }
}
li{
  min-height:30px;
}
li::after{
        content: '';
        /*建议加个height:0*/
        height: 0;
        display: block;
        clear: both;
        visibility: hidden;
} 
li .width_110{
    float: left;
    width: 110px;
    font-size:15px;
    text-align: right;
    color: #888;
}
li .width_190{
    float: left;
    width: 190px;
    font-size:15px;
    text-align: left;
    color: #303133;
}
.basicInforHead{
  // border-bottom: 1px dashed #d5e2f3;
}
.moreContentTit{
  position: absolute;
  left:0;
  top:0;
}
.moreLineAfter{
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}
.moreLineEllipsis{
  padding-left:80px;
}
.moreLineEllipsis:after {
    display: none;
    position: absolute;
    bottom: 0;
    right: 0;
    font-size:15px!important;
    content: '查看更多';
    background-color: #fff;
    color: #0a70b0;
    cursor: pointer;
    text-align: right;
    font-weight: bold;
    padding-left: 13px;
}
.medIconfont{
  font-size:15px!important;
}
.diagnosisCon::after{
   content: '展开';
}
.moreLineShowAll:after {
    display: block;
    content: '收起';
}
.showMoreLineAfter:after {
   display: block;
}
.stepCon{
  padding: 10px;
}
.mh30{
  min-height: 30px;
}
.detailState{
  // padding-left:0!important;
}
.stateName{
  color:#0bbd87;
  font-size:15px;
  font-weight: 700;
}
.timeStamp{
  color: #909399;
  line-height: 1;
  font-size: 15px;
  padding-left:15px;
}
.otherState {
  color:#303133;
}
.failState{
  color: #f56c6c;
}
.curContent{
  display: block;
  width: 100%;
  border: none;
  padding:20px 30px;
  min-height: 360px;
  max-height: 450px;
  text-align: justify;
  font-size:15px;
  color:#303133;
  overflow-y: auto;
  resize: none;
}
.detailStateDiv{
  position: relative;
}
.imgPadding{
  padding: 0 15px;
}
.stateDescTip{
  color:#888;
  position: absolute;
  left: 0;
  top: 0;
}
.rateImg{
  width:100px;
  cursor: pointer;
}
.orderStatus{
  display: inline-block;
  font-size:15px;
  padding:0px 5px;
  border-radius: 3px;
  line-height: 24px!important;
}
.hadSubStu{
  background:rgba(255,153,0,.15);
  color: #ff9900;
}
.dealingStu{
  background:rgba(64,158,255,.15);
  color: #409eff;
}
.finishedStu {
  color: #19b955;
  background:rgba(25,185,85,.15);
}
.closedStu {
  background:rgba(245,108,108,.15);
  color: #f56c6c;
}
.hadSubColor {
  color: #ff9900!important;
}
.updateColor{
  color:#19b955!important;
}
.dealingColor{
  color: #409eff!important;
}
.finishedColor {
  color: #19b955!important;
}
.closedColor {
  color: #f56c6c!important;
}
.evateColor {
  color:#E6A23C!important;
}
</style>
