<template>
  <div class="roleCon" v-bind:class="{'noTableData':roleList.length==0}">
        <el-table
          width="100%"
          size="medium "
          :data="roleList"
          border
          stripe
          :height="tableheight"
          highlight-current-row
          header-row-class-name="strong"
        >
          <!-- <common-table :propData="propData"></common-table> -->
          <el-table-column prop="tenancy_name" label="所属客户" width="260" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="institution_name" label="所属机构" width="260" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="system_name" label="所属系统" width="150" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="group_names" label="权限组" width="190" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <div class="operateBtnDiv mr10">
                <el-button class="openBtn" size="small" plain @click="openCurRole(scope.row)">打开</el-button>
                <!-- <el-button v-if="!scope.row.is_default" class="curLoginBtn" size="small" plain @click="setDefaultLogin(scope.row)">设为默认</el-button> -->
                <span class="curLoginBtn ml10">
                  <el-radio v-if="scope.row.is_default" v-model="scope.row.is_default" :label="true" border>默认登录</el-radio>
                  <el-radio v-else v-model="scope.row.is_default" border @change="setDefaultLogin(scope.row)">设为默认</el-radio>
                </span>
              </div>
            </template>
          </el-table-column>
        </el-table>
  </div>
</template>
<script>
import { getRoleList, putDefaultMenuConfig } from '@/api/personCenter/index'
import CommonTable from '@/components/common/CommonTable'
// import { setCachedSystemId,setCachedLastName,setCachedServiceCenterId,setCachedTeachCenterId } from 'tomtaw-caches';
export default {
   components: {
     CommonTable
   },
   data () {
    return {
      tableheight: '100%',
      roleList: [],
      propData: [
        { prop: 'tenancy_name', label: '所属客户', width: 260 },
        { prop: 'institution_name', label: '所属机构', width: 260 },
        { prop: 'system_name', label: '所属系统', width: 150 },
        { prop: 'group_names', label: '权限组', width: 200 }
      ]
    }
   },
   methods: {
     openCurRole (oneRoleObj) {
       // 放射、心电、超声、内镜 存的系统id 名字叫  lastname  存的系统类型 名字叫 currentSystemClass
       // 集中预约存的系统id 名字叫 system_id
       // 服务中心要存的id 名字叫   serviceCenterId  另外服务中心名字也要存 存的名字叫 sessionStorage.setItem('serviceCenterName', decodeURI(name))
       // 远程教学 要存的id 名字叫 teachCenterId
       // 影像质控 传的值 是在url里面 参数叫id  const href = configUrl.frontEndUrl + '/quality/dashboard?id=' +id
       // 智能科室 传的值 是在url里面 参数叫 dms_id const href = configUrl.frontEndUrl + '/dms?dms_id=' +id
       // 影像共享 存的id  名字叫  idcas_systemid
      if (parseInt(oneRoleObj.system_id)>0) {
        sessionStorage.setItem('currentSystemClass', oneRoleObj.system_code) //比如 RIS、US
      }
      // system_type  1.云pacs 2.影像共享系统 3.智能科室管理系统 4.集中预约 5.语音叫号 6.影像存档
      if (oneRoleObj.system_type === 1) {
        sessionStorage.setItem('lastname', oneRoleObj.system_id)
      }
      if (oneRoleObj.system_type === 2) {
        sessionStorage.setItem('idcas_systemid', oneRoleObj.system_id)
        sessionStorage.setItem('lastCode', oneRoleObj.name)
      }
      if (oneRoleObj.system_type === 4 || oneRoleObj.system_type === 5 || oneRoleObj.system_type === 6) {
        sessionStorage.setItem('system_id', oneRoleObj.system_id)
      }
      // service_center_type  1.远程医疗（服务中心） 2.远程教学
      if (oneRoleObj.service_center_type === 1) {
        sessionStorage.setItem('serviceCenterId', oneRoleObj.service_center_id)
        sessionStorage.setItem('serviceCenterName', decodeURI(oneRoleObj.system_name))
       
      } else if (oneRoleObj.service_center_type === 2) {
        sessionStorage.setItem('teachCenterId', oneRoleObj.service_center_id)
        sessionStorage.setItem('teachCenterName', decodeURI(oneRoleObj.system_name))
        sessionStorage.setItem('ChosedFileName', decodeURI(oneRoleObj.name))
      }
      sessionStorage.setItem('FirstEnterSystem', true)
      let href = configUrl.frontEndUrl + oneRoleObj.url
      if (parseInt(oneRoleObj.quality_center_id) > 0) {
        href = configUrl.frontEndUrl + oneRoleObj.url + '?id=' + oneRoleObj.quality_center_id
      }
      if (oneRoleObj.system_type === 3) {
        href = configUrl.frontEndUrl + oneRoleObj.url + '?dms_id=' + oneRoleObj.system_id
      }
      window.open(href, '_blank')    

     },
     async beganGetRole () {
       const res = await getRoleList()
       if (res.code === 0)  {
         this.roleList = res.data
       } else {
         this.$message({ type: 'error', message: res.msg })
       }
     },
     // 设置默认登录
     async setDefaultLogin (obj) {
       let param = {
        tenancy_id: obj.tenancy_id,
        service_center_id: obj.service_center_id,
        system_id: obj.system_id,
        quality_center_id: obj.quality_center_id
       }
       const res = await putDefaultMenuConfig(param)
       if (res.code === 0)  {
         this.beganGetRole()
       } else {
         this.$message({ type: 'error', message: res.msg })
       }
     },
   },
   mounted () {
     this.beganGetRole()
   }
}
</script>
<style lang="less" scoped>
.roleCon{
 position: relative;
 height:100%;
 ::v-deep .el-table{
  height:100%;
  border: none;
  .el-table__body-wrapper{
    height:calc(100% - 40px);
    overflow: auto;
  }
 }
::v-deep .el-table--border::after, .el-table--group::after, .el-table::before{
   display: none;
 }
}
.openBtn{
   width:72px;
   height:32px;
   text-align: center;
   color:#0a70b0;
   font-size:15px;
}
.openBtn:hover{
  color:#fff;
  background:#0a70b0;
}
.operateBtnDiv{
  display:flex;
}
::v-deep .curLoginBtn{
  .el-radio.is-bordered{
    padding:0px;
    height: 32px;
    width: 100px;
    line-height: 30px;
    text-align: center;
  }
  .el-radio__inner{
    width:12px;
    height:12px;
  }
}
</style>