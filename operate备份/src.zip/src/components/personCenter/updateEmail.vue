<template>
  <div class="addOrderCon">
    <div class="logItem">
      <span class="logLabel fl">
        <i class="iconfont iconbitian mustIcon"></i>
        邮箱：</span
      >
      <el-input class="fl passwordInput" v-model="emailParam.email"></el-input>
    </div>
    <div class="dialog_footer">
      <el-button size="small" @click="cancle()">取消</el-button>
      <el-button type="primary" size="small" @click="confirm()">确定</el-button>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    emailParam: Object,
  },
  data() {
    return {};
  },
  methods: {
    cancle() {
      this.$emit("cancelUpdateEmail");
    },
    confirm() {
      this.$emit("sureUpdateEmail");
    },
  },
};
</script>
<style lang="less" scoped>
.addOrderCon {
  padding: 25px 0px;
  padding-bottom: 0px;
  .logItem::after {
    content: "";
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  ::v-deep .logItem {
    clear: both;
    margin-bottom: 15px;
    position: relative;
    .logLabel {
      width: 130px;
      text-align: right;
      font-size: 15px;
      color: #303133;
      height: 36px;
      line-height: 36px;
    }
    .el-input__inner {
      width: 360px;
      height: 36px;
      line-height: 34px;
    }
    .passwordInput {
      width: 320px;
      .el-input__inner {
        width: 320px;
      }
    }
  }
}
</style>