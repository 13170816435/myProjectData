<template>
   <div class="addOrderCon">
         <div class="logItem">
            <span class="logLabel fl">
             <i class="iconfont iconbitian mustIcon"></i>
             旧密码：</span>
            <el-input class="fl passwordInput" v-model="passwordParam.old_password" show-password></el-input>
        </div>
        <div class="logItem">
            <span class="logLabel fl">
             <i class="iconfont iconbitian mustIcon"></i>
             新密码：</span>
            <el-input class="fl passwordInput"  v-model="passwordParam.new_password" show-password></el-input>
        </div>
        <div class="logItem">
            <span class="logLabel fl">
             <i class="iconfont iconbitian mustIcon"></i>
             确认密码：</span>
            <el-input class="fl passwordInput" v-model="passwordParam.oknew_password" show-password></el-input>
        </div>
        <div class="passwordTip" v-html="$replaceRN(passwordStrengthObj.description)"></div>
        <div class="forgetPassword" @click="forgetPassword()">忘记密码?</div>
        <div class="dialog_footer">
          <el-button size="small" @click="cancle()">取消</el-button>
          <el-button type="primary" size="small" @click="confirm()">确定</el-button>
        </div>

        <!--修改密码-->
      <el-dialog :title="'忘记密码'" :visible.sync="showGetCodeAlert" @close="closePhoneDialogFn" width="500px" :close-on-click-modal="false"  append-to-body v-dialogDrag>
        <div class="addOrderCon">
         <div class="logItem">
            <span class="logLabel fl">
             <i class="iconfont iconbitian mustIcon"></i>
             手机号：</span>
            <el-input class="fl passwordInput" disabled  v-model="phoneParam.phone"></el-input>
        </div>
        <div class="logItem">
            <span class="logLabel fl">
             <i class="iconfont iconbitian mustIcon"></i>
             验证码：</span>
            <el-input class="fl codeInput mr10"  v-model="phoneParam.code" v-bind:class="{'disabledInput':disabled}"></el-input>
            <!-- <span class="getCodeBtn">获取验证码</span> -->
            <el-button type="primary" class="getCodeBtn" v-bind:class="{'disabledBtn':disabled}" :disabled="disabled" @click="sendcode">
                {{btntxt}}
            </el-button>
        </div>
        <div class="logItem">
            <span class="logLabel fl">
             <i class="iconfont iconbitian mustIcon"></i>
             新密码：</span>
            <el-input class="fl passwordInput"  v-model="resetPasswordParam.new_password" show-password></el-input>
        </div>
        <div class="logItem">
            <span class="logLabel fl">
             <i class="iconfont iconbitian mustIcon"></i>
             确认密码：</span>
            <el-input class="fl passwordInput"  v-model="resetPasswordParam.oknew_password" show-password></el-input>
        </div>
        <div class="passwordTip mb20" v-html="$replaceRN(passwordStrengthObj.description)"></div>
        <div class="dialog_footer">
          <el-button size="small" @click="showGetCodeAlert=false">取消</el-button>
          <el-button type="primary" size="small" @click="sureResetPassword">确定</el-button>
        </div>
        </div>
      </el-dialog>
    </div>  
</template>
<script>
import Vue from 'vue'
// import JSEncrypt from 'jsencrypt'
import JSEncrypt from '@/utils/jsencrypt.min'
import Mgr from '@/utils/SecurityService'
import { getConfigurations } from '@/api/commonHttp'
import { getCodeByUserPhone } from '@/api/personCenter/index'
import { setNewPassword } from '@/api/user'
import { LXstr, windowKeyLxstr } from '@/utils/validate'
export default {
  props: {
    passwordParam:Object,
    passwordStrengthObj:Object
  },
  components: {
  },
  data () {
    return {
      showGetCodeAlert: false,
      phoneParam: {
        phone: '',
        code: ''
      },
      resetPasswordParam: {
        new_password: '',
        oknew_password: '',
      },
      btntxt:"获取验证码",
      disabled:false,
      time:0,
    }
  },
  methods: {
    async getConfigurationsFn () {
      const res = await getConfigurations('TransmissionSecurity.RSA.PublicKey')
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) { // 注册方法
          const pubKey = res.data// ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt()
          encryptStr.setPublicKey(pubKey) // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()) // 进行加密
          return data
        }
      }
    }, 
    cancle () {
      this.$emit('cancelUpdatePassword')
    },
    confirm () {
      this.$emit('sureUpdatePassword')
    },
    closePhoneDialogFn () {
      const self = this
      self.phoneParam = self.$options.data().phoneParam
      const manager = new Mgr()
      manager.getRole().then(item => {
        self.phoneParam.phone = item.profile.phone_number
      })
    },
    forgetPassword () {
      this.showGetCodeAlert = true
      this.time=0
      this.btntxt="获取验证码"
      this.disabled=false
    },
    //验证手机号码部分
    async sendcode(){
      this.time = 61
      this.disabled=true
      this.timer()
      this.getCurCode()
    },
    timer() {
      if (this.time > 0) {
        this.time--
        this.btntxt=this.time+"s后重新获取验证码"
        setTimeout(this.timer, 1000)
      } else{
        this.time=0
        this.btntxt="获取验证码"
        this.disabled=false
      }
    },
    async getCurCode () {
      const self = this
      let param = {
        phone: self.$getRsaCode(self.phoneParam.phone),
        type: 'UpdatePhone'
      }
      const res = await getCodeByUserPhone(param)
      if (res.code === 0) {
        // self.phonedata=res.data
      } else {
        self.$message({ type: 'error', message: res.msg })
        setTimeout(() => {
          self.time = 0
          self.btntxt = "获取验证码"
          self.disabled = false
        },4)
      }
    },
    cancelResetPassword () {
      this.showResetPasswordAlert = false
    },
    verifyStrongPassword (reg) {
      var bool = reg.test(this.resetPasswordParam.new_password)
      return bool
    },
    async sureResetPassword () {
      const self = this
      if (self.phoneParam.code == '') {
        self.$message({message: '请输入验证码',type: 'error'})
        return  
      }
      if (self.resetPasswordParam.new_password === '') {
        self.$message({ type: 'error', message: '请输入新密码' })
        return
      }
      // value -1 0 1 分别是 弱 中 强密码
      var weakPasswordReg = /^[0-9a-zA-Z\u007b-\u007e\u005b-\u005f\u003a-\u0040\u0021-\u002f]{6,20}$/
      var middlePasswordReg = /^(?![0-9]+$)(?![a-zA-Z]+$)(?![\u007b-\u007e\u005b-\u005f\u003a-\u0040\u0021-\u002f]+$)[0-9a-zA-Z\u007b-\u007e\u005b-\u005f\u003a-\u0040\u0021-\u002f]{8,20}$/
      // 验证弱密码
      if (self.passwordStrengthObj.value === -1 && !weakPasswordReg.test(self.resetPasswordParam.new_password)) {
        self.$message({ type: 'error', message: '新密码不符合规范' })
        return
      }
      // 验证 中等强度密码
      if (self.passwordStrengthObj.value === 0 && !middlePasswordReg.test(self.resetPasswordParam.new_password)) {
        self.$message({ type: 'error', message: '新密码不符合规范' })
        return
      }
      // 验证强密码
      // var strongPasswordReg = /^[a-zA-Z0-9\u007b-\u007e\u005b-\u005f\u003a-\u0040\u0021-\u002f]/
      const resetPassword = self.resetPasswordParam.new_password.trim()
      // 验证强密码
      if (self.passwordStrengthObj.value === 1) {
        // if (!strongPasswordReg.test(self.resetPasswordParam.new_password)) {
        //   self.$message({ type: 'error', message: '新密码不符合规范' })
        //   return
        // }
        if (!LXstr(resetPassword) || !windowKeyLxstr(resetPassword)) {
          self.$message({ type: 'error', message: '新密码不符合规范' })
          return false
        }
        if (self.resetPasswordParam.new_password.length < 10 || self.resetPasswordParam.new_password.length > 20)
        {
          self.$message({ type: 'error', message: '新密码不符合规范' })
          return
        }
        var includeLowerCaseReg = /[a-z]/
        var includeUppercaseReg =/[A-Z]/
        var includeNumeralReg = /[0-9]/
        var includeSymbolReg = /[\u007b-\u007e\u005b-\u005f\u003a-\u0040\u0021-\u002f]/
        var includeLowercase = self.verifyStrongPassword(includeLowerCaseReg)
        var includeUppercase = self.verifyStrongPassword(includeUppercaseReg)
        var includeNumeral = self.verifyStrongPassword(includeNumeralReg)
        var includeSymbol = self.verifyStrongPassword(includeSymbolReg)

        // 必须同时包含大写字母、小写字母、数字 和 特殊字符（除空格、重音符）
        if (!(includeLowercase && includeUppercase && includeNumeral && includeSymbol))
        {
          self.$message({ type: 'error', message: '新密码不符合规范' })
          return false
        }
      }
      if (self.resetPasswordParam.oknew_password === '') {
        self.$message({ type: 'error', message: '请再次输入新密码' })
        return
      }
      if (self.resetPasswordParam.oknew_password !== self.resetPasswordParam.new_password) {
        self.$message({ type: 'error', message: '确认密码错误，请重新输入' })
        return
      }
      var params = {
        code: self.phoneParam.code,
        password: self.$getRsaCode(self.resetPasswordParam.new_password)
      }
      const res = await setNewPassword(params)
      if (res.code === 0) {
        self.showGetCodeAlert = false
        self.$emit('cancelUpdatePassword')
        // self.$emit('reGetPower')
        self.$message({ type: 'success', message: '新密码设置成功' })
      } else {
        self.$message({ type: 'error', message: res.msg })
        self.time=0
        self.btntxt="获取验证码"
        self.disabled=false
      }
    },
  },
  mounted () {
    const self = this
    self.getConfigurationsFn()
    const manager = new Mgr()
    manager.getRole().then(item => {
     self.phoneParam.phone = item.profile.phone_number
    })
  }
}
</script>
<style lang="less" scoped>
.addOrderCon{
  padding: 25px 0px;
  padding-bottom:0px;
  .logItem::after{
    content: '';
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  ::v-deep .logItem {
    clear:both;
    margin-bottom: 15px;
    position: relative;
    .logLabel{
      width: 130px;
      text-align: right;
      font-size:15px;
      color:#303133;
      height:36px;
      line-height: 36px;
    }
    .el-input__inner {
      width:360px;
      height:36px;
      line-height: 34px;
    }
    .passwordInput{
      width:320px;
      .el-input__inner {
        width:320px;
      }
    }
  }
}
.passwordTip{
  margin-left:45px;
  margin-right:50px;
  // margin-bottom:25px;
  background:#fff6e8;
  border-radius: 3px;
  padding:8px 10px;
  font-size:15px;
  color:#ff9900;
}
.forgetPassword{
  margin-bottom: 20px;
  margin-left: 384px;
  font-size: 15px;
  line-height: 32px;
  color: #0a70b0;
  cursor: pointer;
}
/**获取验证码弹窗样式 */
.addOrderCon{
  padding: 25px 0px;
  padding-bottom:0px;
  .logItem::after{
    content: '';
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  ::v-deep .logItem {
    clear:both;
    margin-bottom: 15px;
    position: relative;
    .logLabel{
      width: 130px;
      text-align: right;
      font-size:15px;
      color:#303133;
      height:36px;
      line-height: 36px;
    }
    .el-input__inner {
      width:360px;
      height:36px;
      line-height: 34px;
    }
    .passwordInput{
      width:320px;
      .el-input__inner {
        width:320px;
      }
    }
    .codeInput{
      width:200px;
      .el-input__inner {
        width:200px;
      }
    }
    .disabledInput{
      width:130px;
      .el-input__inner {
        width:130px;
      }
    }
  }
}
  .getCodeBtn{
    display: inline-block;
    // width: 110px;
    height: 36px;
    background: #ffffff;
    border: 1px solid #dcdfe6;
    border-radius: 3px;
    color:#0a70b0;
    padding:0px 16px!important;
    text-align: center;
    margin-right:48px;
    cursor: pointer;
  }
  .getCodeBtn:hover{
    background:#0a70b0;
    border-color:#0a70b0;
    color:#fff;
  }
</style>
