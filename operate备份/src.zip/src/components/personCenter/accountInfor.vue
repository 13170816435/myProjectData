<template>
  <div class="curAccountInfor pt10">
      <div class="accountHead mb10">
          <span class="headIcon fl"></span>
          <span class="headTit fl">个人信息</span>
          <span class="updateBtn fr" v-if="isDisabled" @click="updateInfor">编辑</span>
      </div>
      <div class="peopleInfo"
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-background="rgba(255,255,255,0.6)">
          <div class="fl peopleInfoItem mr25 mb15">
             <div class="infoLabel">用户头像</div>
             <el-upload
              class="avatar-uploader"
              v-bind:class="{'headImgUpload': userInfo.head_image, 'canUpload':(!isDisabled && userInfo.head_image), 'disableUpload':isDisabled}"
              name="files"
              multiple
              :disabled="isDisabled"
              :show-file-list="false"
              :action="UploadSrc"
              :auto-upload="true"
              :before-upload="chooseUploadImg"
              :http-request="uploadSuc"
            >
              <div class="headImgDiv" v-if="isDisabled"><img :src="userInfo.head_image ? userInfo.head_image : defaultImg" class="avatar headerimg" /></div>
              <div class="headImgDiv" v-else>
                <img :src="userInfo.head_image ? userInfo.head_image : defaultImg" class="avatar headerimg" />
                <img v-if="!userInfo.head_image" :src="defaultUploadImg" class="avatar defaultUploadImg" />
              </div>
              <div class="hadUploadImg"><i class="el-icon-delete headIconDelete" @click.stop="deleteHeadImg"></i></div>
            </el-upload>
          </div>

          <div class="fl peopleInfoItem mr20">
              <div class="infoLabel">姓名<i class="iconfont iconbitian mustIcon" v-if="!isDisabled"></i></div>
              <div class="inputName mb10">
                  <el-input
                   class="inputTag phoneInput"
                    placeholder="请输入姓名"
                    v-model="userInfo.name"
                    :disabled="isDisabled">
                    </el-input>
              </div>
              <div class="infoLabel" v-if="!powerObj.isOperationAdmin">出生日期</div>
              <div class="borthDate" v-if="!powerObj.isOperationAdmin">
                  <el-date-picker
                    class="inputTag phoneInput"
                    v-model="userInfo.birthday"
                    type="date"
                    value-format="yyyy-MM-dd"
                    :disabled="isDisabled"
                    placeholder="选择日期">
                    </el-date-picker>
              </div>

            <div class="infoLabel" v-if="powerObj.isOperationAdmin">手机号码</div>
            <el-input
                v-if="powerObj.isOperationAdmin"
                class="inputTag mr20"
                placeholder="请输入手机号码"
                v-model="userInfo.phone"
                @input="changePhone"
                :disabled="true">
            </el-input>
          </div>
          <div class="fl peopleInfoItem mr20">
              <div class="infoLabel fl">性别<i class="iconfont iconbitian mustIcon" v-if="!isDisabled"></i></div>
              <div class="infoLabel fl ml210">用户名<i class="iconfont iconbitian mustIcon" v-if="!isDisabled"></i></div>
              <div class="fl clear radioGroup mt5 mb20">
                <el-radio v-model="userInfo.sex" :label="1" :disabled="isDisabled">男</el-radio>
                <el-radio v-model="userInfo.sex" :label="2" :disabled="isDisabled">女</el-radio>
                <el-radio v-model="userInfo.sex" :label="0" :disabled="isDisabled">未知</el-radio>
              </div>
              <!-- <div class="fl userNameDiv" v-if="powerObj.isOperationAdmin"> -->
              <div class="fl userNameDiv">
                    <el-input
                    class="inputTag phoneInput"
                    placeholder="请输入用户名"
                    v-model="userInfo.login_name"
                    :disabled="isDisabled">
                    </el-input>
              </div>
              <div class="clear phoneDiv" v-if="!powerObj.isOperationAdmin">
                  <div class="fl">
                      <div class="infoLabel">手机号码<i class="iconfont iconbitian mustIcon" v-if="!isDisabled"></i></div>
                      <el-input
                        class="inputTag w_220 mr20"
                        placeholder="请输入手机号码"
                        v-model="userInfo.phone"
                        @input="changePhone"
                        :disabled="true">
                    </el-input>
                  </div>
                  
                   <div class="fl shortDiv">
                       <div class="infoLabel">手机短号</div>
                       <el-input
                        class="inputTag phoneInput"
                        :maxlength="6"
                        placeholder="请输入手机短号"
                        v-model="userInfo.phone_short"
                        :disabled="isDisabled">
                       </el-input>
                   </div>
              </div>
          </div>
          <!---新增加一个手写签名-->
          <div class="fl peopleInfoItem mb15" :class="{'canUpload':(!isDisabled && userInfo.signature), 'disableUploadSign':isDisabled}">
             <div class="infoLabel">手写签名</div>
             <uploadSignatureImg class="signatureImgDiv" :disabled="isDisabled" @deleteSignImg="deleteSignatureImg" @chooseUploadImg="chooseUploadSignImg" :isAutoUpload="true" @uploadSuc="uploadSignatureSuc" :ImgSrc="userInfo.signature" :UploadSrc="UploadSrc" :imgClass="'signature'"></uploadSignatureImg>

             <div  class="w_200 imgTip mt5 f14 clr_oarange" v-if="!isDisabled">支持jpg、jpeg、bmp、gif、png格式大小不超过2M</div>
          </div>
          <div  class="clear imgTip mt5 f14 clr_oarange" v-if="!isDisabled">支持jpg、jpeg、bmp、gif、png格式大小不超过2M</div>
          <div class="clear peopleInfoItem mt15" v-if="powerObj.isOperationAdmin">
            <div class="engineerDiv"><span class="infoLabel">是否工程师：</span> <span>否</span></div>
          </div>  
          <div class="clear peopleInfoItem mt15">
             <div class="infoLabel">通讯地址</div>
             <el-cascader
                class="inputTag"
                :disabled="isDisabled"
                ref="cascaderAddr"
                :style="{width: '250px'}"
                v-model="city.cityValue"
                :options="city.cityJson"
                @change="getCityCodeFn"
                @active-item-change="childrenCity">
            </el-cascader>
            <el-input placeholder="请输入常用地址" v-model="userInfo.address" :disabled="isDisabled" class="inputTag mt10 ml10" style="width: 670px"></el-input>
          </div>
          <div class="clear peopleInfoItem mt10" v-if="!powerObj.isOperationAdmin">
             <div class="infoLabel">医生简介</div>
             <el-input
                type="textarea"
                class="introTextarea"
                placeholder="请输入..."
                v-model="userInfo.introduction"
                :disabled="isDisabled"
                maxlength="500"
                show-word-limit
                >
                </el-input>
          </div>
          <div class="clear peopleInfoItem mt10 mb15" v-if="!powerObj.isOperationAdmin">
             <div class="infoLabel">专业擅长</div>
             <el-input
                type="textarea"
                class="specialtyTextarea"
                placeholder="请输入..."
                v-model="userInfo.specialty"
                :disabled="isDisabled"
                maxlength="500"
                show-word-limit
                >
                </el-input>
          </div>
          <div class="operateBtnDiv mt20 mb15" v-if="!isDisabled">
            <el-button size="small" type="primary" @click="submitForm('submit')">确定</el-button>
            <el-button size="small" plain @click="submitForm('cancel')">取消</el-button>
          </div>
      </div>
  </div>
</template>
<script>
import defaultImg from '@/assets/images/common/defaultDoctorHead.png'
import defaultUploadImg from '@/assets/images/common/defaultUploadImg.png'
import uploadSignatureImg from '@/components/common/uploadSignatureImg'
import headerimg from '@/assets/images/common/uploadHeadIcon.png'
export default {
  components: {
    uploadSignatureImg
  },
   data () {
     return {
       isDisabled: true,
       UploadSrc: '#',
       defaultImg: defaultImg,
       defaultUploadImg: defaultUploadImg,
       loading: false,
     }
   },
  props: {
    city: Object,
    userInfo: Object,
    powerObj: Object
  },
   methods: {
    updateInfor () {
      this.isDisabled = false   
    },
    getCityCodeFn (val) {
      this.$emit('getCityCodeFn', val)
    },
    childrenCity (val) {
      this.$emit('childrenCity', val)
    },
    // 删除头像
    deleteHeadImg () {
      if (this.isDisabled) {
        return
      }
      this.userInfo.head_image = ''
      this.$emit('deleteHeadImg')
    },
    // 删除头像
    deleteSignatureImg () {
      if (this.isDisabled) {
        return
      }
      this.userInfo.signature = ''
      this.$emit('deleteSignatureImg')
    },
    // 文件上传成功
    uploadSuc (params) {
      this.$emit('uploadImgSuc', params, this.imgClass)
    },
    uploadSignatureSuc (param,imgClass) {
      this.$emit('uploadImgSuc', param, imgClass)
    },
    chooseUploadImg (file, className) {
      this.$emit('chooseUploadImg', file, className)
    },
    chooseUploadSignImg (file, className, bool) {
      this.$emit('chooseUploadImg', file, className, bool)
    },
    changePhone () {
      this.$emit('changePhone')
    },
    submitForm (type) {
      if (type === 'cancel') {
        this.isDisabled = true
      } else{
        this.isDisabled = true
        this.loading = true
        this.$emit('updateAccountInfor')
      }
    }
   },
   mounted () {

   }
}
</script>
<style lang="less" scoped>
.accountHead{
  padding-left:20px;
  height:36px;
  line-height: 36px;
  .headIcon{
    width:4px;
    height:16px;
    background:#0a70b0;
    margin-right:10px;
    margin-top: 11px;
  }
  .headTit{
    font-size:15px;
    color:#303133;
    font-weight: bold;
  }
  .updateBtn{
    width: 80px;
    height: 36px;
    background: #ffffff;
    border: 1px solid #dcdfe6;
    border-radius: 3px;
    color:#0A70B0;
    line-height: 34px;
    text-align: center;
    margin-right:48px;
    cursor: pointer;
  }
  .updateBtn:hover{
    background:#0a70b0;
    border-color:#0a70b0;
    color:#fff;
  }
}
.peopleInfo{
  padding-left:40px;
  .peopleInfoItem{
    .infoLabel{
      font-size:15px;
      color:#303133;
      line-height: 30px;
    }
    .userNameDiv{
      margin-left:54px;
    }
    .ml210{
      margin-left:210px;
    }
    ::v-deep .avatar-uploader .el-upload--text {
        height: 114px;
        width: 114px;
        border-radius: 50%;
    }
    ::v-deep .avatar-uploader{
      position: relative;
    }
    .headImgDiv{
       height: 114px;
       width: 114px;
       border-radius: 50%;
       padding: 5px;
       border: 1px dashed #c0ccda;
       display: flex;
       justify-content: center;
       align-items: center;
       overflow: hidden;
       position: relative;
       .defaultUploadImg{
         position:absolute;
         top: 6px;
         left: 6px;
       }
    }
    .headerimg {
        width:auto;
        height:auto;
        max-width: 100%;
        max-height: 100%;
        border-radius: 50%;
    }
  .hadUploadImg{
    position: absolute;
    top:0px;
    left:0px;
    height: 114px;
    width: 114px;
    border-radius: 50%;
    background-color: rgba(0,0,0,.5);
    display: none;
    .headIconDelete{
      font-size:20px;
      color:#fff;
      position: relative;
      top: 47px;
    }
  }

  ::v-deep .canUpload{
    .el-upload:hover{
      .hadUploadImg{
        display: block;
      }
    }
  }
    ::v-deep .inputTag{
      width:240px;
      .el-input__inner{
        height:36px;
        line-height: 34px;
      }
    }
    .w_220{
      width:220px;
    }
    .phoneInput{
      width:155px;
    }
  }  
}
.disableUpload{
  cursor:not-allowed;
  ::v-deep .el-upload{
    cursor: initial!important;
  }
}
::v-deep .disableUploadSign{
  .hadUploadImg{
    display: none!important;
  }
  .el-upload-dragger{
    cursor: not-allowed;
  }
}

::v-deep .introTextarea{
  width:930px;
  .el-textarea__inner{
     min-height: 150px!important;
     padding:10px 15px;
     text-align: justify;
  }
}
::v-deep .specialtyTextarea{
  width:930px;
  .el-textarea__inner{
     min-height: 120px!important;
     padding:10px 15px;
     text-align: justify;
  }
}
::v-deep .el-input.is-disabled .el-input__inner{
   border:none;
   color:#303133;
   cursor: initial;
}
::v-deep .el-textarea.is-disabled .el-textarea__inner{
   border:none;
   color:#303133;
   cursor: initial;
}
::v-deep .el-input.is-disabled .el-input__icon{
  cursor: initial;
}
::v-deep .el-radio.is-disabled{
  cursor: initial;
}
::v-deep .borthDate{
   .el-input__icon{
       line-height: 36px;
   } 
}
::v-deep .operateBtnDiv{
 .el-button{
   width:80px;
   height:36px;
   text-align: center;
 }
}
.w_200{
  width:200px;
}
::v-deep .signatureImgDiv{
  .avatar-uploader{
    width:200px!important;
    height:80px!important;
    margin-right: 0!important;
  }
  .el-upload--text{
    width:auto!important;
    height: auto!important;;
  }
  .el-upload-dragger img{
    max-width: 100%;
  }
}
</style>