<template>
   <div class="safetySetCon pt10">
      <div class="setItem">
          <div class="fl">
              <div class="iconDiv fl"><i class="iconfont">&#xe79a7;</i></div>
              <div class="safetyHead fl">
                <div class="passwordTit"><span class="loginPasswordLabel">登录密码</span><span class="passwordTip pl10" v-if="safetyObj.use_day!==0">您已超过{{safetyObj.use_day}} 天未修改密码！</span></div>
                <div class="passwordLevel"><span v-if="safetyObj.password_strength_desc">当前密码等级：</span><span class="levelVal" v-if="safetyObj.password_strength_desc">{{safetyObj.password_strength_desc}}</span>为了您的账户安全，建议您定期修改密码；</div>
              </div>
          </div>
          <div class="fr operateBtn" @click="updatePassword">修改</div>
      </div>
      <div class="setItem">
          <div class="fl">
              <div class="iconDiv fl"><i class="iconfont">&#xe7977;</i></div>
              <div class="safetyHead fl">
                <div class="passwordTit"><span class="loginPasswordLabel">手机绑定</span></div>
                <div class="passwordLevel" v-if="safetyObj.phone">你已绑定了手机：<span class="levelVal">{{safetyObj.phone}}</span>您可以用绑定的手机号码登录账户，也可以找回密码</div>
                <div class="passwordLevel" v-else>您未绑定手机号码，绑定后可更便捷地登录和找回密码。</div>
              </div>
          </div>

          <div class="fr operateBtn" v-if="safetyObj.phone"  @click="updatePhone">修改</div>
          <div class="fr operateBtn" v-else  @click="updatePhone">绑定</div>
      </div>
      <div class="setItem">
          <div class="fl">
              <div class="iconDiv fl"><i class="iconfont">&#xe7997;</i></div>
              <div class="safetyHead fl">
                <div class="passwordTit"><span class="loginPasswordLabel">联系邮箱</span><span class="passwordTip pl10" v-if="!safetyObj.email">未绑定</span></div>
                <div class="passwordLevel" v-if="!safetyObj.email">联系邮箱绑定后可用来接收平台发送的服务报告、服务通知等</div>
                <div class="passwordLevel" v-if="safetyObj.email">您已绑定了邮箱<span class="levelVal">{{safetyObj.email}}</span>联系邮箱绑定后可用来接收平台发送的服务报告、服务通知等</div>
              </div>
          </div>
          <div class="fr operateBtn" v-if="!safetyObj.email" @click="setEmail">设置</div>
          <div class="fr operateBtn"v-if="safetyObj.email"  @click="updateEmail">修改</div>
      </div>
      <div class="setItem">
          <div class="fl">
              <div class="iconDiv fl"><i class="iconfont">&#xe7e8;</i></div>
              <div class="safetyHead fl">
                <div class="passwordTit"><span class="loginPasswordLabel">屏幕保护</span></div>
                <div class="passwordLevel">在没有任何操作情况下，到达设定时间后,系统将进入屏幕保护状态，解锁后解除屏幕保护</div>
                <div class="passwordLevel screenSaverDiv mt10">
                  <span class="screensaverLabel">是否启用屏幕保护：</span>
                  <!-- <el-switch v-model="safetyObj.screensaver_state" class=""></el-switch> -->
                  <el-switch @change="changeScreensave" class="switchStyle" active-color="#409EFF" inactive-color="#F56C6C" active-text="启用" inactive-text="禁用" :active-value="true" :inactive-value="false" v-model="safetyObj.screensaver_state"></el-switch>
                  <span v-if="safetyObj.screensaver_state" class="screensaverLabel pl20">屏保间隔时间：</span>
                  <el-select
                    v-if="safetyObj.screensaver_state"
                    @change="changeScreensave"
                    filterable
                    v-model="safetyObj.screensaver_time"
                    class="ele-select_32 width_120_select"
                    placeholder="全部"
                    style="width:120px"
                    >
                    <el-option
                      v-for="(item,index) in safetyObj.screensaver_time_options"
                      :key="index"
                      :label="item.name"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </div>
              </div>
          </div>
          <!-- <div class="fr operateBtn" v-if="!safetyObj.email" @click="setEmail">设置</div>
          <div class="fr operateBtn"v-if="safetyObj.email"  @click="updateEmail">修改</div> -->
      </div>
      <div class="setItem caSetItem" v-if="!powerObj.isOperationAdmin">
          <div class="fl">
              <div class="iconDiv fl"><i class="iconfont">&#xe7b9;</i></div>
              <div class="safetyHead fl">
                <div class="passwordTit"><span class="loginPasswordLabel">CA绑定</span><span class="passwordTip pl10" v-if="safetyObj.ca_state===0">未绑定</span></div>
                <div class="passwordLevel" v-if="safetyObj.ca_state===0">绑定CA之后，可使用U-key登录或进行签名</div>
                <div class="passwordLevel" v-if="safetyObj.ca_state===1">您已绑定了CA ，可使用U-key登录或进行签名</div>
              </div>
          </div>
          <!--北京ca 显示激活按钮-->
          <!-- <div class="fr operateBtn ml10" v-if="showActivationBth" @click="activationCa">激活</div>
          <div class="fr operateBtn" v-if="safetyObj.ca_state === 0" @click="bindCa">绑定</div>
          <div class="fr operateBtn"v-if="safetyObj.ca_state===1"  @click="unBindCa">解绑</div> -->
          
          <div class="clear caFactoryList">
            <div class="oneFactory" v-for="(item,index) in caBindStateList" :key="index">
              <div class="caTypeCon">
                <span class="caTypeDesc" v-if="item.ca_type === 0">U-KEY</span>
                <span class="caTypeDesc numberCa" v-if="item.ca_type === 1">数字签名</span>
                <span class="factoryName">{{item.vendor_name}}</span>
              </div>
              <div class="operateBtnBox">
                <div class="operateBtn ml10 mr10" v-if="(item.vendor_id == 1 || item.vendor_id == 6) && !item.is_bind" @click="activationCa">激活</div>
                <div class="operateBtn" v-if="!item.is_bind" @click="bindCa(item)">绑定</div>
                <div class="operateBtn"v-if="item.is_bind"  @click="unBindCa(item)">解绑</div>
              </div>
            </div>

            <!-- <div class="oneFactory">
              <div class="caTypeCon">
                <span class="caTypeDesc numberCa">数字签名</span>
                <span class="factoryName">上海市数字证书认证中心有限公司</span>
              </div>
              <div class="operateBtnBox">
                <div class="operateBtn ml10 mr10" v-if="showActivationBth" @click="activationCa">激活</div>
                <div class="operateBtn" v-if="safetyObj.ca_state === 0" @click="bindCa">绑定</div>
                <div class="operateBtn"v-if="safetyObj.ca_state===1"  @click="unBindCa">解绑</div>
              </div>
            </div> -->
          </div>
      </div>
      <div class="setItem btNone">
          <div class="fl">
              <div class="iconDiv cancelIconDiv fl"><i class="iconfont">&#xe7997;</i></div>
              <div class="safetyHead fl">
                <div class="passwordTit"><span class="loginPasswordLabel">注销账户</span></div>
                <div class="passwordLevel">如果您不再使用此账号，可以将其注销。账号注销成功后，其下所有服务、数据及隐私信息将会被删除并将无法恢复</div>
              </div>
          </div>
          <div class="fr operateBtn cancelBtn">注销</div>
      </div>
      <!--修改密码-->
      <el-dialog :title="'修改密码'" :visible.sync="showUpdatePasswordAlert" @close="closePasswordDialogFn" width="500px" :close-on-click-modal="false" v-dialogDrag>
         <updatePassword :passwordStrengthObj="passwordStrengthObj" :passwordParam="passwordParam" @sureUpdatePassword="sureUpdatePassword" @cancelUpdatePassword="cancelUpdatePassword"></updatePassword>
      </el-dialog>
      <!--修改手机号-->
      <el-dialog :title="safetyObj.phone ? '修改手机号' : '绑定手机号'" :visible.sync="showUpdatePhoneAlert" @close="closePhoneDialogFn" width="500px" :close-on-click-modal="false" v-dialogDrag>
         <updatePhone v-if="showUpdatePhoneAlert" ref="updatePhone" :curPhone="safetyObj.phone" :phoneParam="phoneParam" @getCurCode="getCurCode" @sureUpdatePhone="sureUpdatePhone" @cancelUpdatePhone="cancelUpdatePhone"></updatePhone>
      </el-dialog>
      <!--修改邮箱-->
      <el-dialog :title="'修改邮箱'" :visible.sync="showUpdateEmailAlert" @close="closeEmailDialogFn" width="500px" :close-on-click-modal="false" v-dialogDrag>
         <updateEmail :emailParam="emailParam" @sureUpdateEmail="sureUpdateEmail" @cancelUpdateEmail="cancelUpdateEmail"></updateEmail>
      </el-dialog>
      <!--CA绑定-->
      <el-dialog :title="'CA绑定'" :visible.sync="showSetCaAlert" @close="closeCaDialogFn" width="500px" :close-on-click-modal="false" v-dialogDrag>
         <caBind :caBindParam="caBindParam" :caInfo="caInfo" :loginName="tenancy_name" @readCa="readCa" @sureBindCa="sureBindCa" @cancelBindCa="cancelBindCa"></caBind>
      </el-dialog>
      <!--CA绑定-->
      <el-dialog :title="'CA绑定'" :visible.sync="showMobileCaAlert" @close="closeInputCaDialogFn" width="500px" :close-on-click-modal="false" v-dialogDrag>
         <mobileCaBind :caMobileBindParam="caMobileBindParam" :bindCaType="bindCaType" :loginName="tenancy_name" @sureBindMobileCa="sureBindMobileCa" @cancelBindMobileCa="cancelBindMobileCa"></mobileCaBind>
      </el-dialog>
      <!--CA激活-->
      <el-dialog :title="'CA激活码'" :visible.sync="showActivationCaAlert" @close="cancelActivationCa" width="500px" :close-on-click-modal="false" v-dialogDrag>
         <activationCa ref="activationCaRef" :userId="safetyObj.id" @cancelActivationCa="cancelActivationCa"></activationCa>
      </el-dialog>
    <!-- 上海ca  巴州(新疆)ca ukey密码 -->
    <el-dialog
      title="Ukey验证"
      :top="'10vh'"
      :visible.sync="showUkeyPasswordAlert"
      width="400px"
      :close-on-click-modal="false"
      v-dialogDrag
    > 
      <div class="ukeyPassword">
        <div class="ukeyItem">
          <span class="ukeyLabel">Ukey密码：</span>
          <el-input v-model="ukeyPasswordObj.password" class="w_300" show-password></el-input>
        </div>
      </div>
      
      <div class="dialog_footer">
        <el-button size="small" plain @click="showUkeyPasswordAlert=false">取消</el-button>
        <el-button type="primary" size="small" @click="getShanghaiCaCertId"
          >确定</el-button
        >
      </div>
    </el-dialog>
   </div>
</template>
<script>
import Vue from 'vue'
import updatePassword from './updatePassword'
import updatePhone from './updatePhone'
import updateEmail from './updateEmail'
import caBind from './caBind'
import activationCa from './activationCa'
import mobileCaBind from './mobileCaBind'
import JSEncrypt from 'jsencrypt'
import cryptoMix from '@/utils/mixin/crypto'
import { updateuserpassword } from '@/api/user.js'
import { getConfigurations, updateTeachUserInfor, uploadMediaFile } from '@/api/commonHttp'
import { getCode, putPhone, bindPhone, putEmail, getPasswordStrength } from '@/api/personCenter/index'
import { userBindCACertificate, unbindCACertificate, getCAType, putScreensaver, getMobileCaId, getActivationCaCode, getTenancyCaBindStateList } from '@/api/user'
import Mgr from '@/utils/SecurityService'
import { BJCA } from '@/utils/ca/bjca.use'
import { HBCA } from '@/utils/ca/hbca.use'
import { XJCA } from '@/utils/ca/xjca.use'
import { WZTCA } from '@/utils/ca/wztca.use'
import '@/utils/ca/bjca.xtxasyn.js'
import { initWebSocket, sendSock, closeWebsocketService } from '@/utils/ca/shAndBzCaWebsocket'
import { sendSzSock,initSzWebSocket,closeSzWebsocketService,} from '@/utils/ca/szSglCaWebsocket'
import { LXstr, windowKeyLxstr } from '@/utils/validate'
import { connectUrlParam } from "@/components/commonJs";
export default {
  components: {
     updatePassword,
     updatePhone,
     updateEmail,
     caBind,
     mobileCaBind,
     activationCa,
  },
  props: {
    powerObj: Object,
    safetyObj: Object,
  },
  mixins: [cryptoMix],
  data () {
    return {
      enable_state: false,
      showUpdatePasswordAlert: false,
      showUpdatePhoneAlert: false,
      showUpdateEmailAlert: false,
      showSetCaAlert: false,
      showMobileCaAlert:false,
      caBindWay: -1,
      showActivationCaAlert: false,
      showActivationBth: false, // 展示激活按钮
      passwordStrengthObj: {},
      caBindMsg: '',
      passwordParam: {
        old_password: '',
        new_password: '',
        oknew_password: '' 
      },
      caDocumentId: '',
      bjCaVersion: '3.2.0.0',
      caVersion:null,
      phoneParam:{
        phone: '',
        code: ''
      },
      emailParam: {
        email: ''
      },
      caBindParam: {
        uKey: ''
      },
      caMobileBindParam: {// 电子签名绑定参数
        unique_id: '', 
      },
      setting_id: '',
      bindCaType: 3,
      caInfo: {
        certID: ''
      },
      CA_bind_userinfo: {
        id: ''
      },
      tenancy_name: '',
      teachUserObj:{
        sex: -1,
        user_id: '',
        user_name: '',
        user_phone: ''
      },
      showUkeyPasswordAlert: false,
      ukeyPasswordObj: {
        password: '',
      },
      caBindStateList: [],
    }
  },
  methods: {
    async changeScreensave () {
      let param = {
        state:this.safetyObj.screensaver_state,
      }
      if (this.safetyObj.screensaver_state) {
        param.time = parseInt(this.safetyObj.screensaver_time)
      }
      const res = await putScreensaver(param)
      if (res.code === 0) {
        sessionStorage.setItem('screensaverState',this.safetyObj.screensaver_state)
        sessionStorage.setItem('screensaverTime',this.safetyObj.screensaver_time)
        this.$message({ type: 'success', message: '修改成功' })
      } else {
        this.$message({ type: 'error', message: res.msg })
      }
    },
    async getConfigurationsFn () {
      const res = await getConfigurations('TransmissionSecurity.RSA.PublicKey')
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) { // 注册方法
          const pubKey = res.data// ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt()
          encryptStr.setPublicKey(pubKey) // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()) // 进行加密
          return data
        }
      }
    }, 
    updatePassword () {
      this.showUpdatePasswordAlert = true 
    },
    cancelUpdatePassword () {
       this.showUpdatePasswordAlert = false 
    },
    closePasswordDialogFn () {
      this.passwordParam = this.$options.data().passwordParam
    },
    verifyStrongPassword (reg) {
      var bool = reg.test(this.passwordParam.new_password)
      return bool
    },
    async sureUpdatePassword () {
      const self = this
      if (self.passwordParam.old_password === '') {
        self.$message({ type: 'error', message: '请输入旧密码' })
        return
      }
      if (self.passwordParam.new_password === '') {
        self.$message({ type: 'error', message: '请输入新密码' })
        return
      }
      // value -1 0 1 分别是 弱 中 强密码
      var weakPasswordReg = /^[0-9a-zA-Z\u007b-\u007e\u005b-\u005f\u003a-\u0040\u0021-\u002f]{6,20}$/
      var middlePasswordReg = /^(?![0-9]+$)(?![a-zA-Z]+$)(?![\u007b-\u007e\u005b-\u005f\u003a-\u0040\u0021-\u002f]+$)[0-9a-zA-Z\u007b-\u007e\u005b-\u005f\u003a-\u0040\u0021-\u002f]{8,20}$/
      // 验证弱密码
      if (self.passwordStrengthObj.value === -1 && !weakPasswordReg.test(self.passwordParam.new_password)) {
        self.$message({ type: 'error', message: '新密码不符合规范' })
        return
      }
      // 验证 中等强度密码
      if (self.passwordStrengthObj.value === 0 && !middlePasswordReg.test(self.passwordParam.new_password)) {
        self.$message({ type: 'error', message: '新密码不符合规范' })
        return
      }
      //var strongPasswordReg = /^[a-zA-Z0-9\u007b-\u007e\u005b-\u005f\u003a-\u0040\u0021-\u002f]/
      const new_password = self.passwordParam.new_password.trim()
      // 验证强密码
      if (self.passwordStrengthObj.value === 1) {
        // if (!strongPasswordReg.test(self.passwordParam.new_password)) {
        //   self.$message({ type: 'error', message: '新密码不符合规范' })
        //   return
        // }
        if (!LXstr(new_password) || !windowKeyLxstr(new_password)) {
          self.$message({ type: 'error', message: '新密码不符合规范' })
          return false
        }
        if (self.passwordParam.new_password.length < 10 || self.passwordParam.new_password.length > 20)
        {
          self.$message({ type: 'error', message: '新密码不符合规范' })
          return
        }
        var includeLowerCaseReg = /[a-z]/
        var includeUppercaseReg =/[A-Z]/
        var includeNumeralReg = /[0-9]/
        var includeSymbolReg = /[\u007b-\u007e\u005b-\u005f\u003a-\u0040\u0021-\u002f]/
        
        var includeLowercase = self.verifyStrongPassword(includeLowerCaseReg)
        var includeUppercase = self.verifyStrongPassword(includeUppercaseReg)
        var includeNumeral = self.verifyStrongPassword(includeNumeralReg)
        var includeSymbol = self.verifyStrongPassword(includeSymbolReg)

        // 必须同时包含大写字母、小写字母、数字 和 特殊字符（除空格、重音符）
        if (!(includeLowercase && includeUppercase && includeNumeral && includeSymbol))
        {
          self.$message({ type: 'error', message: '新密码不符合规范' })
          return false
        }

      }
      
      if (self.passwordParam.oknew_password === '') {
        self.$message({ type: 'error', message: '请再次输入新密码' })
        return
      }
      if (self.passwordParam.oknew_password !== self.passwordParam.new_password) {
        self.$message({ type: 'error', message: '确认密码错误，请重新输入' })
        return
      }
      var params = {
        old_password: this.$getRsaCode(self.passwordParam.old_password),
        new_password: this.$getRsaCode(self.passwordParam.new_password)
       }
      const res = await updateuserpassword(params)
      if (res.code === 0) {
        self.showUpdatePasswordAlert = false
        self.$emit('reGetPower')
        self.$message({ type: 'success', message: '修改成功' })
      } else {
        self.$message({ type: 'error', message: res.msg })
      }
    },
    // 修改手机号码
    async getCurCode () {
      let param = {
        phone: this.$getRsaCode(this.phoneParam.phone),
        type: 'UpdatePhone'
      }
      const res = await getCode(param)
      if (res.code === 0) {
        // this.phonedata=res.data
      } else {
        this.$message({ type: 'error', message: res.msg })
        setTimeout(() => {
          this.$refs.updatePhone.time = 0
          this.$refs.updatePhone.btntxt = "获取验证码"
          this.$refs.updatePhone.disabled = false
        },4)
        
      }
    },
    updatePhone () {
      this.phoneParam = this.$options.data().phoneParam
      this.showUpdatePhoneAlert = true    
    },
    closePhoneDialogFn () {
      this.phoneParam = this.$options.data().phoneParam
    },
    cancelUpdatePhone () {
      this.showUpdatePhoneAlert = false  
    },
    // 同步更新教学用户信息
    async updateCurTeachUserInfor () {
      this.teachUserObj.user_phone = this.phoneParam.phone
      const res = await updateTeachUserInfor(this.teachUserObj)
      if (res.code === 0) {
        //this.teachUserObj = res.data  
      } else {
        this.$message({
          type: 'error',
          message: res.msg
        })
      }
    },
    async sureUpdatePhone () {
      const self = this
      var phoneReg = /^1[3456789]\d{9}$/
      if (self.phoneParam.phone === '') {
        self.$message({ type: 'error', message: '请输入手机号码' })
        return
      }
      if (!phoneReg.test(self.phoneParam.phone)) {
        self.$message({message: '请输入正确的手机号码',type: 'error'})
        return
      }
      if (self.safetyObj.phone && self.phoneParam.code === '') {
        self.$message({ type: 'error', message: '请输入验证码' })
        return
      }
      let param = {
        phone: self.$getRsaCode(self.phoneParam.phone),
        code: self.phoneParam.code
      }
      let tip = ''
      let res = null
      if (self.safetyObj.phone) {
        tip = '修改手机号成功'
        res = await putPhone(param)
      } else {
        tip = '绑定手机号成功'
        const bindPhoneParam = {
          phone: self.$getRsaCode(self.phoneParam.phone),
        }
        res = await bindPhone(bindPhoneParam)
      }
      if (res.code === 0) {
        self.showUpdatePhoneAlert = false
        // 修改绑定手机号后  教学那边也需要同步 bussinessName
        if (sessionStorage.getItem('bussinessName') == 'teleeducation') {
          self.updateCurTeachUserInfor()
        }
        self.$emit('reGetPower')
        self.$message({ type: 'success', message: tip })
      } else {
        self.$message({ type: 'error', message: res.msg })
      }
      
    },
    // 修改邮箱
    setEmail () {
      this.showUpdateEmailAlert = true
    },
    updateEmail () {
      this.emailParam.email = this.safetyObj.email
      this.showUpdateEmailAlert = true 
    },
    closeEmailDialogFn () {
     this.emailParam = this.$options.data().emailParam
     //this.emailParam.email = this.safetyObj.email
    },
    cancelUpdateEmail () {
      this.showUpdateEmailAlert = false
    },
    async sureUpdateEmail () {
      const self = this
      var emailReg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/
      if (self.emailParam.email === '') {
        self.$message({ type: 'error', message: '请输入邮箱' })
        return
      }
      if (!emailReg.test(self.emailParam.email)) {
        self.$message({message: '请输入正确的邮箱',type: 'error'})
        return
      }
      let param = {
        email: self.$getRsaCode(self.emailParam.email),
      }
      const res = await putEmail(param)
      if (res.code === 0) {
        self.showUpdateEmailAlert = false
        self.$emit('reGetPower')
        self.$message({ type: 'success', message: '修改成功' })
      } else {
        self.$message({ type: 'error', message: res.msg })
      }        
    },
    cancelActivationCa () {
      this.showActivationCaAlert = false
    },
    // 激活ca --北京ca 需要医生自己扫码激活才能使用
    async activationCa () {
      const self = this
      const param = {
        user_id: self.safetyObj.id
      }
      const res = await getActivationCaCode(param)
      if (res.code === 0) {
        self.showActivationCaAlert = true
        self.$nextTick(() => {
          self.$refs.activationCaRef.creatQrCode(res.data)
        })
      } else {
        self.$message({ type: 'error', message: res.msg })
      }  
    },
    // 绑定Ca
    async bindCa (item) {
      const self = this
      // if (self.caBindMsg) { // 如果没配置好ca
      //   self.$message({ type: 'error', message: self.caBindMsg })
      //   return false
      // }
      self.caBindWay = item.ca_type
      self.setting_id = item.setting_id
      self.bindCaType = item.vendor_id
      let config_value = JSON.parse(self.AESDecrypt(item.config_value, false));
      //console.log(config_value)
      if (config_value.Version) {
        self.caVersion = config_value.Version
        if (self.bindCaType === 1) {
          self.bjCaVersion = parseInt(
          config_value.Version.split(".").join("").substr(0, 2)
          ); // 只拿版本号的 前2位
        }
        
      } else {
        self.caVersion = null
        if (self.bindCaType === 1) {
          self.bjCaVersion = parseInt(
          self.bjCaVersion.split(".").join("").substr(0, 2)
        ); //没配版本号 默认是老版本20
        }
      }

      //console.log(self.caBindWay)
      if (self.caBindWay == 0) {   // ca绑定方式是 ukey
        self.showSetCaAlert = true
        self.caInfo.certID = ''
      } else {  // ca绑定方式是电子签名
        // bindCaType：5 广东ca     bindCaType:11 安徽淮南ca
        if (self.bindCaType == 5 || self.bindCaType == 11) {//网政通 广东ca  和安徽淮南ca 他们是直接通过手动输入来绑定 不调用接口拿unique_id
          self.showMobileCaAlert = true
          self.caMobileBindParam.unique_id = ''
        } 
        else if (self.bindCaType === 3) {// 湖北云签
          const work_no = self.AESDecrypt(self.safetyObj.work_no_encrypt)
          self.caMobileBindParam.unique_id = work_no
          self.showMobileCaAlert = true
          if (!work_no) { // 没有工号
            setTimeout(function(){
              self.$message.error("未识别到工号")
            },500)
          }
        }
        else {
          const res = await getMobileCaId({user_id: self.CA_bind_userinfo.id,ability_setting_id:self.setting_id})
          if (res.code == 0) { // 成功获取到了ca
            if (res.data.open_id) {
              self.caMobileBindParam.unique_id = res.data.open_id
              self.sureBindMobileCa()
            } else {
              self.$message.error("绑定失败，未找到匹配的CA账户")
            }
            
          } else {
            self.showMobileCaAlert = true
            setTimeout(function(){
              self.$message.error(res.msg)
            },500)
            self.caMobileBindParam.unique_id = ''
          }
        }
      }
    },
    // 读取Ca 
    readCa () {
      if (this.bindCaType === 1 && this.bjCaVersion >= 30) { // 北京ca 新版本
        this.initCAFn()
      } else if (this.bindCaType === 4 && this.caVersion) { // 新疆巴州ca--ukey
        this.initCAFn()
      } else if (this.bindCaType == 2 || this.bindCaType == 17) {// 上海长宁 和深圳圣格林 ca--ukey
        this.initCAFn()
      }
       else {
        this.initCAFn()
        this.getCAInfoFn()
        this.caInfo.initCa()
      }
      
    },
    // 确定解绑
    async sureUnBindCa (item) {
      const self = this
      const ids = []
      //ids.push(this.CA_bind_userinfo.id)
      ids.push(item.user_ca_certificate_id)
      const params = {
        // setting_id: self.setting_id,
        // user_ids: ids,
        user_ca_certificate_ids:ids,
      }
      const res = await unbindCACertificate(params)
      if (res.code === 0) {
        self.$message.success('解绑成功！')
        // 重新获取绑定列表
        self.beaganGetTenancyCaBindStateList()
        self.$emit('reGetPower')
      } else {
        self.$message.error(res.msg)
      }
    },
    // 解绑
    unBindCa (item) {
      this.$confirm('<i class="iconfont icontishi clr_e6 mr5"></i>是否解除绑定的CA，解绑后可重新绑定', '解绑CA', {
        distinguishCancelAndClose: true,
        dangerouslyUseHTMLString: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(() => {
        this.sureUnBindCa(item)
      })
    },
    closeCaDialogFn () {
      this.caBindParam = this.$options.data().caBindParam
    },
    closeInputCaDialogFn () {
      this.caMobileBindParam = this.$options.data().caMobileBindParam
    },
    cancelBindCa () {
      this.showSetCaAlert = false
    },
    dataURLtoFile(dataurl, filename) {
      let arr = dataurl.split(',');
      let mime = arr[0].match(/:(.*?);/)[1];
      let bstr = atob(arr[1]);
      let n = bstr.length;
      let u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      return new File([u8arr], filename, {
        type: mime
      })
   },
    cancelBindMobileCa () {
      this.showMobileCaAlert = false
    },
    async sureBindCa () {
      const self = this
      if (self.caInfo.certID === '') {
        self.$message({ type: 'error', message: '请先读取Ukey值' })
        return
      }
      const params = {
        // user_ca_certificates: [
        //   {
        //     user_id: self.CA_bind_userinfo.id,
        //     unique_id: self.caInfo.certID
        //   }
        // ]
        setting_id: self.setting_id,
        user_id: self.CA_bind_userinfo.id,
        unique_id: self.caInfo.certID,
        //type:1,
      }
      if (this.caDocumentId != '') {// ca图片文件id
        params.signature = this.caDocumentId
      }
      const res = await userBindCACertificate(params)
      if (res.code === 0) {
        self.$message({ type: 'success', message: 'U-KEY绑定完毕' })
        self.showSetCaAlert = false
        // 重新获取绑定列表
        self.beaganGetTenancyCaBindStateList()
        self.$emit('reGetPower')
      } else {
        self.$message({ type: 'error', message: res.msg })
      }
    },
    // 电子签名方式绑定ca
    async sureBindMobileCa () {
      const self = this
      if (self.caMobileBindParam.unique_id === '') {
        self.$message({ type: 'error', message: '请输入用户唯一标识' })
        return
      }
      const params = {
        setting_id: self.setting_id,
        user_id: self.CA_bind_userinfo.id,
        unique_id: self.caMobileBindParam.unique_id,
        //type: 2,
      }
      if (this.caDocumentId != '') {// ca图片文件id
        params.signature = this.caDocumentId
      }
      const res = await userBindCACertificate(params)
      if (res.code === 0) {
        self.$message({ type: 'success', message: '电子签名绑定成功' })
        self.showMobileCaAlert = false
        // 重新获取绑定列表
        self.beaganGetTenancyCaBindStateList()
        self.$emit('reGetPower')
      } else {
        self.$message({ type: 'error', message: res.msg })
      }
    },
    async getCurPasswordStrength () {
      const res = await getPasswordStrength()
      if (res.code === 0) {
        this.passwordStrengthObj = res.data   
      } else {
        this.$message({ type: 'error', message: res.msg })
      }     
    },
   // 获取ca类型信息
    async getCATypeFn () {
      const manager = new Mgr()
      const user = await manager.getRole()
      const tenancy_id = sessionStorage.getItem('curTenancyId') || user.profile.tenancy_id
      const res = await getCAType(tenancy_id)
      if (res.code === 0) {
        // this.bindCaType = res.code
        this.bindCaType = res.data.vendor_id
        if (this.bindCaType == 1 || this.bindCaType == 6) { // 是北京ca的话 得展示激活按钮
          this.showActivationBth = true;
        }
        let config_value = JSON.parse(this.AESDecrypt(res.data.config_value, false))
        console.log(config_value)
        if (config_value.Version) {
          this.caVersion = config_value.Version
          this.bjCaVersion = parseInt(config_value.Version.split('.').join('').substr(0, 2))
        }
        this.caBindWay = config_value.CAType; // CAType=1 表示数字证书；CAType=0 表示UKEY绑定方式
      } else {
        this.caBindMsg = res.msg
        // this.$message({ type: 'error', message: res.msg })
      }
    },
    // 获取ca id
    getCAInfoFn () {
      const self = this
      self.caInfo.getCertID()
    },
    // 这个方法主要针对上传ca图片
    async uploadCaImg (curFile) {
      //console.log(params)
      let res
      const formData = new FormData()
      let param = {
        file_name: curFile.name,
        file_size: curFile.size, 
        position: 0,
        file_type: 0,
      }
      let paramUrl = connectUrlParam(param)
      formData.append('file',curFile) 
      res = await uploadMediaFile(formData,paramUrl)
      if (res.code == 0) {
        this.caDocumentId = res.document_id
      } else {
        this.$message({ type: 'error', message: res.msg })
      }
    },
    // testCaImgUploadFn (base64) {
          // const timestamp = Math.round(new Date());
          // let dataurl = "data:image/png;base64," + retObj.retVal;
          // let file = self.dataURLtoFile(dataurl,timestamp)
    //   //this.uploadCaImg(file)
    // },
  //指定证书ID，获取指定用户Key中印章图片
  GetKeyPicByCert(CertID) {
    const self = this
    if(CertID == null || CertID == "") {
      self.$message({ type: 'error', message: '证书ID为空' })
    } else {
      GetPic(CertID, function(retObj) {
        if (retObj.retVal != "") {
          // document.getElementById("keypic").value = retObj.retVal;
          // img_src = "data:image/gif;base64," + retObj.retVal;
          // document.getElementById("base64_image").setAttribute("src", img_src);
          console.log("获取签章图片成功...");
          let timestamp = Math.round(new Date())+ '.png';
          let dataurl = "data:image/png;base64," + retObj.retVal;
          let file = self.dataURLtoFile(dataurl,timestamp) // 将base64转成文件流
          self.uploadCaImg(file)
        } else {
          self.$message({ type: 'error', message: '获取签章图片失败！' })
        }
      });
     }
    },
   // 初始化ca
    initCAFn () {
      const self = this
      if (self.bindCaType === 3) { // 湖北ca
        self.caInfo = new HBCA({
          vue: self
        })
        self.caInfo.initCa()
        self.caInfo.certID = self.caInfo.getCertID()
      } else if (self.bindCaType === 1) { // 北京ca 上海 2
        if (self.bjCaVersion >= 30) {
          //北京ca新版本
            // SOF_GetVersion(function(version) {
            //   console.log('version',version)
            // })
            SOF_GetUserList(function(userList) {
              const userListArr = userList.retVal.split('&&&')
              const curUserInforArr = userListArr[0].split("||")
              //self.caInfo.certID = curUserInforArr[1]
              const cetIdStr = curUserInforArr[1]
              if (cetIdStr.indexOf("/") == -1) {
                self.caInfo.certID = cetIdStr
              } else {
                let index = cetIdStr.indexOf("/")
                self.caInfo.certID = cetIdStr.substring(index+1,cetIdStr.length)
              }
              self.GetKeyPicByCert(self.caInfo.certID)
            })  

            // SOF_GetUserList(function(userList) { // 获取用户列表
            //   const userListArr = userList.retVal.split('&&&')
            //   let curUserInforArr = userListArr[0].split("||")
            //   SOF_ExportUserCert(curUserInforArr[1],function(Base64){ // 导出证书
            //      SOF_GetCertEntity(Base64,function(certID) { // 获取唯一标识
            //         console.log('certID',certID)
            //         let certIdStr = certID
            //         if (certIdStr.indexOf("SF") == -1) {
            //           self.caInfo.certID = certIdStr
            //         } else {
            //           let index = str.indexOf("SF")
            //           self.caInfo.certID = str.substring(index+2,str.length)
            //         }
                  
            //      })
            //   })
            // })
        } else {
           self.caInfo = new BJCA({
            vue: self,
            // ukey变化事件
            usbKeyChange () {
              console.log('ukey变化了')
              self.initCAFn()
              self.getCAInfoFn()
            }
          })
        }
      } else if (self.bindCaType === 4) { //新疆ca是 4
        if (self.caVersion) {// 有版本号的话是 新疆的巴州UKEY
          self.showUkeyPasswordAlert = true
          self.ukeyPasswordObj = {
            password: '',
          }
          // 初始化上海ca或新疆巴州 的 websocket
          initWebSocket()

         } else {
            self.caInfo = new XJCA({
              vue: self,
              // ukey变化事件
              // usbKeyChange () {
              //   console.log('ukey变化了')
              //   self.initCa()
              //   self.getCAInfoFn()
              // }
            })
            self.caInfo.initCa()
            self.caInfo.certID = self.caInfo.getCertID()
         }
      } else if (self.bindCaType === 5) { //网政通ca是 5
        self.caInfo = new WZTCA({
          vue: self,
        })
        self.caInfo.initCa()
        self.caInfo.certID = self.caInfo.getCertID()
      } else if (self.bindCaType === 2) {// 上海ca
        self.showUkeyPasswordAlert = true
        self.ukeyPasswordObj = {
          password: '',
        }
        // 初始化上海ca 的 websocket
        initWebSocket()
      } else if (self.bindCaType === 17) {// 深圳 圣格林ca
        // 初始化深圳 圣格林ca的 websocket
        initSzWebSocket()
        const websocketValidateParam = {
          "Method": "registCa",   //获取证书序列号
          "WorkNo":self.AESDecrypt(self.safetyObj.work_no_encrypt)   //ukey秘钥
        }
        sendSzSock(websocketValidateParam,function(res) {
          if (res.code == 0) {
            self.caInfo.certID = res.checkKey
            // 关闭webscoket
            closeSzWebsocketService()
          } else {
            self.$message.error(res.msg);
          }
        })
      }
    },
    // 获取上海ca id
    getShanghaiCaCertId () {

      const self = this
      if (self.ukeyPasswordObj.password == '') {
        self.$message.error("请输入UKEY密码！");
        return;
      }
      // 验证输入的 Ukey 密码
      let validatePassword = false
      const websocketValidateParam = {
        "Method": "verifyPassword",   //获取证书序列号
        "CertPwd":self.ukeyPasswordObj.password   //ukey秘钥
      }
      sendSock(websocketValidateParam,function(res) {
        if (res.code == 0) {
          validatePassword = true
        } else {
          validatePassword = false
        }

        if (!validatePassword) {
          self.$message.error("密码错误,请输入正确的密码！");
          return;
        }
        // 获取证书id
        const websocketParam = {
          "Method": "getCertSN",   //获取证书序列号
          "CertPwd":self.ukeyPasswordObj.password,   //ukey秘钥
          "UserId": self.CA_bind_userinfo.id,
        }
        sendSock(websocketParam,function(res) {
          //console.log(res)
          self.isCABind = true;
          if (res.code == 0) {
            self.showUkeyPasswordAlert = false;
            self.caInfo.certID = res.certSN
            closeWebsocketService()
          } else {
            self.showUkeyPasswordAlert = false;
            self.$message.error(res.msg);
          }
        })

      })
    },
    async getUserinfoFn () {
      const manager = new Mgr()
      const user = await manager.getRole()
      this.tenancy_name = user.profile.name
      this.CA_bind_userinfo.id = user.profile.sub
      this.teachUserObj.user_name = user.profile.name
      this.teachUserObj.user_id = user.profile.sub
    },
    // 获取该客户 已绑定和未绑定 哪些ca
    async beaganGetTenancyCaBindStateList () {
      const res = await getTenancyCaBindStateList()
      if (res.code == 0) {
        this.caBindStateList = res.data
      } else {
        this.$message({ type: 'error', message: res.msg })
      }
    },
    
  },
  mounted () {
    this.beaganGetTenancyCaBindStateList()
    this.getConfigurationsFn()
    // if (!this.powerObj.isOperationAdmin) {
    //   this.getCATypeFn() 
    // }
    if (this.safetyObj.phone) {
      this.phoneParam.phone = this.safetyObj.phone
    }
    if (this.safetyObj.email) {
      this.emailParam.email = this.safetyObj.email
    }
    // 获取密码规则
    this.getCurPasswordStrength()
    this.$nextTick(() => {
      this.getUserinfoFn()
    })
  }
}
</script>
<style lang="less" scoped>
.safetySetCon{
  padding: 5px 25px;
  .setItem::after{
    content: '';
    height: 0;
    display: block;
    clear: both;
    visibility: hidden; 
  }
  .setItem{
    padding: 20px 0px;
    border-bottom: 1px dashed #DCDFE6;
    .iconDiv{
      width:48px;
      height:48px;
      border-radius: 6px;
      background:#0bb27a;
      text-align: center;
      line-height: 48px;
      margin-right:18px;
       i{
         font-size:26px;
         color:#fff;
        }
    }
    .cancelIconDiv{
      background:#dcdfe2;
    }

    .passwordTit{
      line-height: 20px;
      margin-bottom: 8px;
      .loginPasswordLabel{
        font-size: 16px;
        font-weight: bold;
        color:#303133;
      }
      .passwordTip{
        font-size:14px;
        color:#ff9900;
      }
    }
    .passwordLevel{
      font-size:14px;
      color:#888;
    }
  .operateBtn{
    width: 80px;
    height: 36px;
    background: #ffffff;
    border: 1px solid #dcdfe6;
    border-radius: 3px;
    color:#0A70B0;
    line-height: 34px;
    text-align: center;
    cursor: pointer;
    margin-top:7px;
   }
   .cancelBtn{
     cursor: not-allowed;
     color:#909399;
     border-color:#f5f7fa;
     background:#f5f7fa;
   }
  .operateBtn:hover{
    background:#0a70b0;
    border-color:#0a70b0;
    color:#fff;
   }
   .cancelBtn:hover{
    border-color:#dcdfe6;
    color:#f56c6c;
    background:#fff;
   }
   .caFactoryList{
    margin-left:65px;
     .oneFactory{
       display: flex;
       align-items: center;
       height: 56px;
       justify-content: space-between;
       border-bottom: 1px dashed #EBEEF5;
       .caTypeCon{
        display: flex;
        .caTypeDesc{
          padding: 0px 5px;
          border-radius: 3px;
          background: #e6a23c;
          color:#fff;
        }
        .numberCa{
          background:#409EFF;
        }
        .factoryName{
          font-size: 14px;
          color: #303133;
          font-weight: 700;
          margin-left:10px;
        }
       }
       .operateBtn{
          margin-top:0px!important;
        }
     }
     .oneFactory:last-of-type{
        border-bottom: none;
     }
   }

  }
  .caSetItem{
    padding-bottom: 0;
  }
  .btNone{
    border-bottom: none;  
  }
}
  .setItem:last-child{
    border-bottom: none;
  }
  .levelVal{
    color:#409eff;
    padding-right:20px;
  }
  .screensaverLabel{
    color:#303133;
    font-size:15px;
  }
  ::v-deep .screenSaverDiv{
    .el-switch.is-checked .el-switch__core{
      border-color:#0a70b0!important;
      background:#0a70b0!important;
    }
    .switchStyle .el-switch__label {
      position: absolute;
      display: none;
      color: #fff;
    }
    .switchStyle .el-switch__label--left {
      z-index: 9;
      left: 19px;
    }
    .switchStyle .el-switch__label--right {
      z-index: 9;
      left: -6px;
    }
    .switchStyle .el-switch__label.is-active {
      display: block;
    }
    .switchStyle.el-switch .el-switch__core,
    .el-switch .el-switch__label {
      width: 50px !important;
    }
    .el-switch__label *{
      font-size: 12px !important;
    }
  }
.ukeyPassword{
  padding: 20px 20px;
  .ukeyItem {
    display: flex;
    .ukeyLabel{
      width: 90px;
      text-align: right;
      font-size: 15px;
      color: #303133;
      height: 36px;
      line-height: 36px;
    }
  }
}
.operateBtnBox{
  display: flex;
}
</style>
