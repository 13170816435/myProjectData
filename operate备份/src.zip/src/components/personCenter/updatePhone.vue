<template>
  <div class="addOrderCon">
    <div class="logItem">
      <span class="logLabel fl">
        <i class="iconfont iconbitian mustIcon"></i>
        手机号：</span
      >
      <el-input class="fl passwordInput" v-model="phoneParam.phone"></el-input>
    </div>
    <div class="logItem" v-if="curPhone">
      <span class="logLabel fl">
        <i class="iconfont iconbitian mustIcon"></i>
        验证码：</span
      >
      <el-input
        class="fl codeInput mr10"
        v-model="phoneParam.code"
        v-bind:class="{ disabledInput: disabled }"
      ></el-input>
      <!-- <span class="getCodeBtn">获取验证码</span> -->
      <el-button
        type="primary"
        class="getCodeBtn"
        v-bind:class="{ disabledBtn: disabled }"
        :disabled="disabled"
        @click="sendcode"
      >
        {{ btntxt }}
      </el-button>
    </div>
    <div class="dialog_footer">
      <el-button size="small" @click="cancle()">取消</el-button>
      <el-button type="primary" size="small" @click="confirm()">确定</el-button>
    </div>
  </div>
</template>
<script>
import { getCode } from "@/api/personCenter/index";
export default {
  props: {
    phoneParam: Object,
    curPhone: String,
  },
  data() {
    return {
      btntxt: "获取验证码",
      disabled: false,
      time: 0,
    };
  },
  methods: {
    cancle() {
      this.$emit("cancelUpdatePhone");
    },
    confirm() {
      this.$emit("sureUpdatePhone");
    },
    //验证手机号码部分
    async sendcode() {
      var phoneReg = /^1[3456789]\d{9}$/;
      if (this.phoneParam.phone === "") {
        this.$message({ type: "error", message: "请输入手机号码" });
        return;
      }
      if (!phoneReg.test(this.phoneParam.phone)) {
        this.$message({ message: "请输入正确的手机号码", type: "error" });
        return;
      }
      if (this.phoneParam.phone == "") {
        return;
      }
      // this.time=35
      this.time = 61;
      this.disabled = true;
      this.timer();
      this.$emit("getCurCode");
    },
    timer() {
      if (this.time > 0) {
        this.time--;
        this.btntxt = this.time + "s后重新获取验证码";
        setTimeout(this.timer, 1000);
      } else {
        this.time = 0;
        this.btntxt = "获取验证码";
        this.disabled = false;
      }
    },
  },
};
</script>
<style lang="less" scoped>
.addOrderCon {
  padding: 25px 0px;
  padding-bottom: 0px;
  .logItem::after {
    content: "";
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  ::v-deep .logItem {
    clear: both;
    margin-bottom: 15px;
    position: relative;
    .logLabel {
      width: 130px;
      text-align: right;
      font-size: 15px;
      color: #303133;
      height: 36px;
      line-height: 36px;
    }
    .el-input__inner {
      width: 360px;
      height: 36px;
      line-height: 34px;
    }
    .passwordInput {
      width: 320px;
      .el-input__inner {
        width: 320px;
      }
    }
    .codeInput {
      width: 200px;
      .el-input__inner {
        width: 200px;
      }
    }
    .disabledInput {
      width: 130px;
      .el-input__inner {
        width: 130px;
      }
    }
  }
}
.getCodeBtn {
  display: inline-block;
  // width: 110px;
  height: 36px;
  background: #ffffff;
  border: 1px solid #dcdfe6;
  border-radius: 3px;
  color: #0a70b0;
  padding: 0px 16px !important;
  text-align: center;
  margin-right: 48px;
  cursor: pointer;
}
.getCodeBtn:hover {
  background: #0a70b0;
  border-color: #0a70b0;
  color: #fff;
}
</style>