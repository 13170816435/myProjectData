<template>
   <div class="detailPage">
    <div class="detailHead">
       <img v-if="curTabIndex === '0'" src="@/assets/images/common/bigAnnounce.png" alt="">
       <img v-if="curTabIndex === '1'" src="@/assets/images/common/bigNotice.png" alt="">
       <div class="detailTit">{{oneInformationObj.title}}</div>
       <div class="detailTime">发布时间：{{oneInformationObj.add_time}}</div>
       <div class="line mb5"></div>
       <div class="line"></div>
       <div class="detailContent" v-html="$replaceRN(oneInformationObj.content)">
       </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    oneInformationObj: Object,
    curTabIndex: String
  },
  methods: {
  }
}
</script>
<style lang="less" scoped>
.detailPage{
  padding:0px 50px 35px 50px;
}
.detailHead{
  position: relative; 
  img{
    position: absolute;
    left:-40px;
    top:-76px;
  }
  .detailTit{
    font-size:24px;
    color:#0d1525;
    padding:5px 0;
    line-height: 30px;
    letter-spacing: 1.5px;
    text-align: center;
    width: 420px;
    margin: 0 auto;
    font-weight: 700;
  }
  .detailTime{
    font-size:14px;
    color: #909399;
    line-height: 24px;
    padding-bottom: 8px;
    text-align: center;
  }
  .line{
    height:1px;
    background:#dcdfe6;
  }
}
.detailContent{
  padding-top:15px;
  font-size:15px;
  color:#0d1525;
  text-align: justify;
  min-height: 480px;
  max-height: 480px;
  line-height: 26px;
  overflow: auto;
}
</style>