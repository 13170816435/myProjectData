<template>
  <div class="activationCaCon">
    <div class="activationCaBox">
       <div class="activationCaTip" v-if="content_type == 1">
         <div class="activationCaTipItem">【第一步】 请先绑定ca用户</div>
         <div class="activationCaTipItem">【第二步】 请打开手机APP【协同签名】,在登录界面下方点击【下载证书】,扫二维码下载证书</div>
        </div>
        <!--二维码-->
       <div class="qrcode" ref="qrCodeUrl" v-if="content_type == 1"></div>
       <!--图片-->
       <img :src="codeSrc" alt="" class="currentImg" v-if="content_type == 0 && codeSrc">
       <!--网址链接-->
        <div class="iframe-container" v-if="content_type == 2 && iframeUrl">
          <iframe :src="iframeUrl" frameborder="0"></iframe>
        </div>
    </div>
    <div class="dialog_footer">
      <el-button class="hadScanCodeBtn fl mt10 ml15" size="small" @click="activationCa()">刷新</el-button><span class="scanTip fl ml5">(二维码失效时可点击刷新)</span>
      <el-button class="hadScanCodeBtn" size="small" @click="cancle()">已扫码</el-button>
    </div>
  </div>
</template>
<script>
import { getActivationCaCode } from '@/api/user'
import QRCode from "qrcodejs2";
export default {
  data () {
    return {
      codeSrc: null,
      iframeUrl: null,
      content_type: -1,
    }
  },
  props: {
    userId: String
  },
  methods: {
 // 生成二维码
    async creatQrCode(result) {
      const self = this
      self.content_type = result.content_type
       //self.codeSrc = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANYAAABVCAIAAAC6pY0PAAAQTUlEQVR4Ae2dXYxURRbHu3t6pntmGBYEZlhYYWAXFkSNiLqJEtEHTdTE+KAx0axRNxoTY/x4Mn48+fnkR9QX10RjoonKw4ZE3Y0vagyJiMGAgiuwMEQQGGAYmI/umenu/VWd7po793bf7r7dM33jrbttT91Tp75O/e//nKq6zca///77WM1XoVCIx+Py7VOoqoJPWZsVNQsk6how+ENfvn0KVlXwKWuzomaB+iDosg5sJxKTcCnYW2uBqhZoCILCdtbtVrWyVfCxQEMQlHqt2/Wxr82qaoEmQLBqG1bBWsDHAhaCPsaxWXNhAQvBubCybcPHAhaCPsaxWXNhAQvBubCybcPHAhaCPsaxWXNhAQvBubCybcPHAhaCPsaxWXNhgUYh+IG+5qKnto3fqQUaheDv1Cx2WHNnAQvBubO1bamsBZJlpS0XJpPJFStWVH0BB4VcLjc1NTU5OZnJZEZGRlrec9uBei0QUgjm8/kFCxZUHYxAcGJiAvydOHFiyZIlZ86cqVrKKoTKAq2HILiZN2+eyyjDw8MuSdlbIJhIJNrb28nNZrNtbW2LFi06ffp0WWUrDKcFWg9BALRw4UKXdcCTS1L2Vjy1oJDvxYsXnzx5Evo8e/ZsWX0rDKEFwrIcOXhq/N97h/6zb+jf+9T3wVMZY6yR0fHjg2fKfk4MDiHne/D0cCY7mU6n+/r62tuTtThxU3/gBD+7eeSRR44ePRq4hkYK3nfffZs2bfr888/LVkLfyH3yySfL5oZBSA9//vlnetJ6FhRz7B/MbNtzpq0tnssX+H3KpsXZa2qxE6oF/b9YDBb88ssveX+WpQmrmWXLlo2OjtZSR2CdQ4cObd++/eWXX37hhRfmz58fuB5m4q233rrjjjuuvfbaGivZunXr7t2777777ptuuqlska+++go5T0jZ3FkSun4K99NPP0lDY2Njhw8flvQXX3xhWr/hhhuwXlggCJbaErGOtngqlWhviy+dX/xViulu2QSwwxezdiF3Rf8qVsfzujpTHUnGfOrUqVQqVaNDL1t5VeHtt9++c+fOX375Zf/+/VBOVf1KCgJl2LS3t3fdunWV1IwcyL700kvcVjoX2LZtG1ko3HrrraaUSTDxF1100euvv24kJuGTZXQk8fbbb5shw8c8Dy4F7+2ll16Kj6IJsuiAUQgLBPkhFPyXSsZHJ/Kg6uz4lOmifwLaEyB2dHSQ7uxKd6VTpHHKBw4cYIHC5V+Df+77779fdracpR588EHnrTP96KOP3nPPPU6JNy1M9swzz8DiVSEI/p566ikque2221auXPndd99deeWVrjo/+ugjJDQ9MDBAcOxSYP1HrkABRwGRCzgQ9vf3880FvxJYS5rho3D99dfL7d69e51MhvCWW24xudx2dXWtWrWK5+rDDz+kA6+++qo/u4cFgjFokE8sloPVCoXMpCI2ueZ1d/Ip3VX5m8vlc/k8SxxZqUCQDUJQ2hN6qNL2zGxoWKjIKSY4c82fM/ef+nJKJE3rOCzSgj/mFYg88cQTuGMAxHyTNqXwhjwSDzzwANCnORRuvvlmr78WCcooACDznPDIUdWWLVsMyQFB2Mup4BoC3sC0TuLcuXPvvPOOjJ3H4LLLLvPmIjF9TrKFwUaGU6k16UIszycGcoAg4d30xXJkZGycHETdGoujY9OLFYSok0kpMNzVme5MpwvxZCKppM36aRWOw8wBK4DPPvvs4Ycf9mcsZtcLQRmVMND0CCunhKVMPgHu2rVrgZcAiLk/cuQIrbCNT5oWP/nkE7pK/XfddReliAWJE+BXYOrfW9NEIwnA9y99yUNy5513Ll++3FkhPXzzzTfx2ldffTXKEkAn1eyF4AJ8mv9iUyq2E7xNd8v0UfXV099CXsMXeb6ANweL6oonPYpa3tgX+GNGqQPy8KmJp3/Dhg2VFITSKuU65cJSRsKcucrCJbjaiy++GJ2lS5fCT2Duvffek9kFAWARmIJdU0ktCVdoQbVcPgWhZx7Lb775BvDxALz44osuxAM4/DIsTyWu4CRpXL5PA3OQBYG1JeKJeKxNBXew18w24zAdoiI9KldNvmJN/mkHhVd1rxEX1wLq0ApaNLOmeu8gP8N/r7zyihCbxGHeqozzJR7CkQEgr07TJQaUAI7ZxW8y2Q899JA05PKSNbZeVyzIMA1kwR80vGPHDh4D05aBL7kQs4sawxILQl0TufxkLpGZygOwqVwRPUUk6T8KZEWxGh2YVEBzCjVyi/gjx5CnMUbQBE85+yYsWmWOd+3axR6K60FnJtidoQUcZbCJr6V3/tGk1FAppiQXEBjI+jRXVyzIw8Z6BffKN3WyXnHWLPhj5WTiB2cu6bBAEPAkE3G9HdOOI17QNd1PTYma60oyhTqNxRnwK6FRHLGiRidgS2UD/JVFMeGL+BdWlMwxy1J8nEANaLIIhSAx9PPPP++N/QM06l/EyVL+mibXMLSRNDHx7rvvemvjmYQLsQlOg4vYADeyfv16l33CAkECwexULjMVHx7PkV6ZJibUKBMyK6VlnDPwJ1olFy2oUwqUL0aFXuPUISGIYfJ4ggGcBFhYkOgeUmRz7tNPP73kkkuMd77//vtdXqaOlupRdbJUjeUAhPQTfafr5BbfzUUCjpfajGOVWxUJ+saComa+TeTHowJti00QslNDH/bt22eWwxQJCwTxnsm2BOEgH2CUKAWDGkzFoSlclYhNp0u8p+VoCvAEf5QxIDamCZAAdk57SQ09PT2AgBUJ3ocLIRyJa64Rf2a/I0B/cKPiSWuvRMJ/Z2za3d2NR6Z1174gBD84OIjcybKg039f0DWKr7/+GlLkyWSH3GkQLEmgQmfkSTBWDQUEFWHl87BgNhfPcsTBW4AKPrIkAVfq4s+pwcHfJsZJT+VyAsWhoSF5xUEpFVhNJ9izEOgpRCowNu3C2x48eJBAh3MnWQ7jYm688Ua+P/74YyRcpDdu3Mi3LIcroUSmv5aeuTZlXEWcyHBlyW0l50sUKziGDul2g/uCpmlM9MYbb3DGQzTCU8qh0fHjx00uFMip1erVq3loQSELeYIZcBkKCNJLwALxwYCJRBwHqla0DgAJwsbHxy9c3meGROLkid860x1G8t8DA53pFB/R5w1CDMG2qlGoN8EDzREcxmKng+0GKQ7h4Zc5cjAIwzWzXuFsA3SyL+ZqRUjICAGoTL+R+CQEIpUUnDvGZXWczresglfo3AHw5iIpqyCGMo7eJMrWIEI8Ow8YvNh6CAIXCI+wbTJfmMoXJuFD9vZKhyMKTCU6U5r6Xo9BpTZefrnO1wK84d8WORRwjtfs2VP97LJYuNwfHmisCWlt3ryZgBpuW7NmjUSELnV4hQshEQ9PP1iEgcAuErOnQxq7106B6Du9J7euSwVo9YRoruLNujV7pbCyPPDsy0jlcppn5AgxKfuA0CFLOgiYFV7rIagIUAGnAAVChPLBCbM/rYahjz1Utvoo1wy3dXV3cbNG+VwlV5dKqKWzQBDhyPnzfAyURaveb1AFkUgp1sWuIN2nNnDmpTrQSRHiMJ+CdWUFdsQ+rRhqd+p4se4cIE6AF3MIhb1lMRplnY7eVHvdddexpLv33ntDAEHdKXUuTCw4lchO5gkEoUMBVwl8RQzy65AuplADDedY5DwFw9J/Zog6wTv9MwWN3jnj9Ep1yerSm/vDDz8gxBF7s4JJqjpiqjVRf41NeEkaDNFnFWQ7rv7+fsddzPu8OXMlzROIZahK3AKPN4EjWa2HIFiTAzn2BXlfiw8EyJfCFFcRinIT61vaZySaOot3hvx0sWJRwsujv/5aLNmkP7XshlSCoOzZ+hzc1dtHLzn51OAKSZ2axAy88UDUiwP1golWwJ9X7qxB0ngMNgL9T88xDm/3mJ0aCrYegqr3eNs8LJifyBU4I+GcN2eOiYGT/miQFVIdKa2ueFAkKqFFSmCwpypV10wAi6xl399++y0c4PVWgTtU1RFLzRKQuVoBLixRgR1ys3pwcZuriM8tDCdHwAyQaiUsdukTQz/77LMogEKO6R577DF5iSvJE9DyY2KBGZGchpvuOWmDJ8lWkOOFVrXaFaiBOIU/hbJioljeFIzHeG/QZYhW3RKzsxmBH29iB2pxxDQnAZmz3eeee86s3MEEG0lXXHEFgHZu4zn1/dOyEcjocOLeI2BXWbwwQH/ttdcef/xxNhY4y07yvqdLaY5vizDSyw4iQBUE6o9AUOAnsNOQK0KTdCaTzWSzSqgxp0upVE9P6R16wWZTx1P7isTVLHuHSHh/ySVv5LYuR+xsCMCxWmdf6aqrrjKMBS+WfcuagmUbAnAsJvC85IJj9gJdJ28UlJ0sV+wB+bEuZi3Copitg+QFF1zg7Fxr0gp5OF+8scKQeidGBYQaWeot3HRnpyKz0RH1y06toRR4KZ+3owFiR0cKNKqiYE69saVy5XIkS6LG/gZbjsBDQoHBaKZSlwM7YrDihYs5MqnUnEsOmfEOGGBynl6i43qRAnTyFpmrLLhnR/Dpp5/mddq42XRwKdV4K2FEI/6lr++PS5b0bd1z8oNdJzqS8XS7YuXNvfl/bFHv2ykMaWCBsIGBw3/9y2okwnzDw+cUBLPZdg3EEgQL0ywYi+3csX3hgp4axzJ7aoRKbIDJYcDstRKSmgk55MdT9AdYAzL/8Lf1yxEgBeGxEZNlIRKLD09MQYJjE/wuSWJDDUKNOx3yTdsZZGpHHMMfF/FHJdksv4tHXTOp8ulhuIjEa1lRhqGrjfehLMX6VNt6CErnNvR1//3ypaxIwCIIujCVPTJwiONiRXloaCQd++3Y2jV/1vlKANuRxncrifqoRHePTugS8j6hz+BtVhgsEAoIQnjre7vX9bLnrMGmwST8pZPKUMArV5CVk1bS2eqL/0r4U0n0SpdUVrqzf0NqgdZDcGxs9Nz/DmiMaRtpCBVxpP5MY+r4sWML/6BOtxQuhf/Ur0aUguxuayhqEJesPTJyftHC1seCpe7Yv2Us0HoIDp05zb/OVqZrHlE2M/rjj7sV52mYqZWvAp2+Yc8wro5UtKxYknBw5DzHsvX9csfTrBXMrgVaD0F+88tVyygD7Gj8aVlvLTVbnRZaoMX70i0cuW06JBawEAzJRES3GxaC0Z37kIzcQjAkExHdbjR6QBddy9mRN8kClgWbZEhbTVALWAgGtZwt1yQLNARBfn/epG7YaqJrgYYgGF2z2ZE3zwIWgs2zpa0pkAWC/xOXeGFecw7UqC1kLTBtgeAQ1G+oTFdkU9YCwSyQrPEtlWC121LWAlUtkOT/KKaqklWwFpg9CyT5/7Csq3b8r92LqctiVtnfAnH+jSN/DZtrLTCrFgi+HJnVbtnKo2MBC8HozHVIR2ohGNKJiU63LASjM9chHamFYEgnJjrdStpDtuhMdjhHalkwnPMSoV7F7VFvhGY7lEO1L2uFclqi1CkLwSjNdijHaiEYymmJUqcsBKM026Ecq4VgKKclSp2yEIzSbIdyrBaCoZyWKHXKQjBKsx3KsVoIhnJaotQpC8EozXYox2ohGMppiVKnLASjNNuhHOv/AeqOTkMTZm1oAAAAAElFTkSuQmCC'
      //  内容类型 0=二维码（显示二维码弹出框）；1=普通文本（需要转成二维码，然后显示弹出框）；2=网址（弹出框嵌入网址）
      if (self.content_type == 0) { // 内容类型 base64图片
        self.codeSrc = "data:image/png;base64," + result.content;
        
      } else if (self.content_type == 1) { // 普通文本
        self.$nextTick(() => {
          self.$refs.qrCodeUrl.innerHTML = "";
          var qrcode = new QRCode(self.$refs.qrCodeUrl, {
              text: result.content, // 需要转换为二维码的内容
              width: 280,
              height: 280,
              colorDark: "#000000",
              colorLight: "#ffffff",
              correctLevel: QRCode.CorrectLevel.L,
          });
        })
      } else if (self.content_type == 2) { // 网址 需要iframe嵌套
        self.iframeUrl = result.content
        //self.iframeUrl = 'https://www.baidu.com'
      }
    
    },
    async activationCa () {
      const self = this
      const param = {
        user_id: self.userId
      }
      const res = await getActivationCaCode(param)
      if (res.code === 0) {
        self.creatQrCode(res.data)
      } else {
        self.$message({ type: 'error', message: res.msg })
      }  
    },
    cancle() {
      this.$emit("cancelActivationCa");
    },
  }
}
</script>
<style lang="less" scoped>
.activationCaBox {
  padding:15px 20px;
  .activationCaTip{
    .activationCaTipItem{
      font-size:15px;
      color:#303133;
      line-height: 24px;
    }
  }
  .currentImg{
    display: flex;
    margin: 0 auto;
    max-height: 400px;
  }
}
.qrcode{
    margin: 0 auto;
    margin-top:15px;
    text-align: center;
    width: 300px;
    height: 300px;
    border: 1px solid #DCDFE6;
    background: #fff;
    padding: 10px 0px 0px 10px;
img {
    width: 300px;
    height: 300px;
    background-color: #fff; //设置白色背景色
    padding: 6px; // 利用padding的特性，挤出白边
    box-sizing: border-box;
 }
}
.iframe-container {
  flex-grow: 1;
  height: 300px;
  iframe {
    width: 100%;
    height: 100%;
  }
}
.dialog_footer{
  .hadScanCodeBtn{
    background:#0a70b0;
    border-color:#0a70b0;
    color:#fff;
    
  }
  .scanTip{
      font-size:14px;
      color:#ff9900;
    }
}
</style>