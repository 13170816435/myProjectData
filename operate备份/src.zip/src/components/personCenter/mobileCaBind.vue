<template>
  <div class="addOrderCon">
    <div class="ukeyCon">
      <div class="logItem">
      <!---bindCaType == 5网政通ca(广东ca) 不需要调用接口查询ca信息 直接受到输入的--->
      <div class="ukeyTip" v-if="bindCaType != 5"
        ><i class="iconfont ukeyIcon">&#xe646;</i
        >查询ca相关信息失败,手动输入用户唯一标识或联系管理员</div
      >
     </div>
     <div class="logItem">
      <span class="logLabel fl"> 姓名：</span>
      <el-input
        class="fl passwordInput"
        disabled
        v-model="loginName"
      ></el-input>
     </div>
      <div class="logItem">
        <span class="logLabel fl">用户唯一标识：</span>
        <el-input
          class="fl passwordInput"
          v-model="caMobileBindParam.unique_id"
        ></el-input>
      </div>
    </div>
    <div class="dialog_footer">
      <el-button size="small" @click="cancle()">取消</el-button>
      <el-button type="primary" size="small" @click="confirm()">确定</el-button>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    bindCaType: Number,
    caMobileBindParam: Object,
    loginName: String,
  },
  data() {
    return {};
  },
  methods: {
    cancle() {
      this.$emit("cancelBindMobileCa");
    },
    confirm() {
      this.$emit("sureBindMobileCa");
    },
  },
  mounted() {},
};
</script>
<style lang="less" scoped>
.addOrderCon {
  padding: 30px 0px;
  padding-bottom: 0px;
  .logItem::after {
    content: "";
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  ::v-deep .logItem {
    clear: both;
    margin-bottom: 15px;
    position: relative;
    .logLabel {
      width: 152px;
      text-align: right;
      font-size: 15px;
      color: #303133;
      height: 36px;
      line-height: 36px;
    }
    .ukeyIcon {
      font-size: 24px;
      padding-right: 5px;
      position: relative;
      top: 3px;
    }
    .ukeyTip {
      font-size: 16px;
      color: #e6a23c;
      line-height: 24px;
      text-align: center;
    }
    .doctorName {
      font-size: 15px;
      color: #303133;
      line-height: 36px;
    }
    .readCaBtn {
      padding: 9px 12px !important;
      margin-left: 15px;
    }
    .el-input__inner {
      width: 360px;
      height: 36px;
      line-height: 34px;
    }
    .passwordInput {
      width: 240px;
      .el-input__inner {
        width: 240px;
      }
    }
  }
}
.dialog_footer {
  margin-top: 40px;
}
</style>