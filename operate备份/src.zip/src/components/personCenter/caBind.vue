<template>
  <div class="addOrderCon">
    <div class="ukeyCon">
      <div class="logItem">
      <span class="logLabel fl"></span>
      <span class="ukeyTip"
        ><i class="iconfont ukeyIcon">&#xe7ba;</i
        >请插入U-key,再点击按钮读取CA</span
      >
     </div>
     <div class="logItem">
      <span class="logLabel fl"> 姓名：</span>
      <el-input
        class="fl passwordInput"
        disabled
        v-model="loginName"
      ></el-input>
     </div>
      <div class="logItem">
        <span class="logLabel fl">U-key值：</span>
        <el-input
          class="fl passwordInput"
          disabled
          v-model="caInfo.certID"
        ></el-input>
        <el-button
          class="fl readCaBtn"
          type="primary"
          size="small"
          @click="initCAFn()"
          >读取CA</el-button
        >
      </div>
    </div>
    <div class="dialog_footer">
      <el-button size="small" @click="cancle()">取消</el-button>
      <el-button type="primary" size="small" @click="confirm()">确定</el-button>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    caInfo: Object,
    loginName: String,
  },
  data() {
    return {};
  },
  methods: {
    cancle() {
      this.$emit("cancelBindCa");
    },
    confirm() {
      this.$emit("sureBindCa");
    },
    initCAFn() {
      this.$emit("readCa");
    },
  },
  mounted() {},
};
</script>
<style lang="less" scoped>
.addOrderCon {
  padding: 30px 0px;
  padding-bottom: 0px;
  .logItem::after {
    content: "";
    /*建议加个height:0*/
    height: 0;
    display: block;
    clear: both;
    visibility: hidden;
  }
  ::v-deep .logItem {
    clear: both;
    margin-bottom: 15px;
    position: relative;
    .logLabel {
      width: 120px;
      text-align: right;
      font-size: 15px;
      color: #303133;
      height: 36px;
      line-height: 36px;
    }
    .ukeyIcon {
      font-size: 24px;
      padding-right: 5px;
      position: relative;
      top: 3px;
    }
    .ukeyTip {
      font-size: 16px;
      color: #e6a23c;
    }
    .doctorName {
      font-size: 15px;
      color: #303133;
      line-height: 36px;
    }
    .readCaBtn {
      padding: 9px 12px !important;
      margin-left: 15px;
    }
    .el-input__inner {
      width: 360px;
      height: 36px;
      line-height: 34px;
    }
    .passwordInput {
      width: 240px;
      .el-input__inner {
        width: 240px;
      }
    }
  }
}
.dialog_footer {
  margin-top: 40px;
}
</style>