<template>
  <div class="personInforContainer">
    <div class="userinfo-title">
      <span class="titleName">消息中心</span>
      <span @click="closeFn" class="close-btn iconfont iconchuangjianshibai"></span>
    </div>
    <div class="personContent" v-bind:class="{'noAnnounce': messageList.length ==0 && activeName== 'first','noNotice': messageList.length ==0 && activeName== 'second'}">
        <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick">
          <el-tab-pane name="first">
            <span slot="label">
              <el-badge v-if="totalArr[0] && totalArr[0].count!=0" is-dot class="item">平台公告</el-badge>
              <span v-else>平台公告</span>
            </span>
            <div class="announceCon" v-loadmore="loadMore">
              <div class="oneInformation" @click="watchDetail(item)" v-for="(item,index) in messageList"  :key="item.add_time">
                 <div class="informationHeadCon">
                    <span class="readIcon" v-bind:class="{'noReadIcon': item.read_state}"></span>
                    <span class="informationTit">【{{item.title}}】
                      <img v-if="index==0" src="@/assets/images/common/new.png" alt="">
                    </span>
                    <span class="informationTime fr">{{item.add_time}}</span>
                 </div>
                 <div class="informationText" v-html="$replaceRN(item.content)">
                 </div>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane name="second">
            <span slot="label">
              <el-badge v-if="totalArr[1] && totalArr[1].count!=0" is-dot class="item">平台通知</el-badge>
              <span v-else>平台通知</span>
            </span>
            <div class="noticeCon" v-loadmore="loadMore">
              <div class="oneInformation" @click="watchDetail(item)" v-for="(item,index) in messageList"  :key="item.add_time">
                 <div class="informationHeadCon">
                    <span class="readIcon" v-bind:class="{'noReadIcon': item.read_state}"></span>
                    <span class="informationTit">【{{item.title}}】
                      <img v-if="index==0" src="@/assets/images/common/new.png" alt="">
                    </span>
                    <span class="informationTime fr">{{item.add_time}}</span>
                 </div>
                 <div class="informationText" v-html="$replaceRN(item.content)">
                 </div>
              </div>
            </div>
          </el-tab-pane>
        </el-tabs>
    </div>
    <el-dialog title="" class="watchAnnounceAlert" v-bind:class="{'watchNoticeAlert':curTabIndex=='1'}" :visible.sync="showDetailInforAlert"  :width="'750px'" :close-on-click-modal="false" append-to-body v-dialogDrag>
        <announceAndNoticeDetail :curTabIndex="curTabIndex" :oneInformationObj="oneInformationObj"></announceAndNoticeDetail>
    </el-dialog>
  </div>
</template>
<script>
import announceAndNoticeDetail from './announceAndNoticeDetail'
import { getUserInforList, updateReadState, getInformationTotal } from '@/api/platform_operate/messageRelease'
export default {
   components: {
     announceAndNoticeDetail
   },
   data () {
     return {
       activeName: 'first',
       showDetailInforAlert: false,
       searchData: {
         type: 1,
         offset: 1,
         limit: 13
       },
       totalArr: [],
       hasNoRead: false,
       curTabIndex: '0',
       oneInformationObj: {},
       aq: true,
       messageList: []
     }
   },
   methods: {
    closeFn () {
      this.$emit('closeFn')
    },
    handleClose () {
      this.showDetailInforAlert = false
    },
    handleClick(tab, event) {
      // console.log(tab);
      if (this.curTabIndex != tab.index) {
        this.searchData.offset = 1
        this.aq = true
        this.messageList = []
        this.getUserInforListFn()
        this.curTabIndex = tab.index
      }
    },
    // 查看公告或通知
    watchDetail (obj) {
      this.showDetailInforAlert = true
      this.oneInformationObj = obj
      // 点击了就表示阅读了 状态就是已阅读
      this.beganUpdateReadState(obj)
    },
    async beganUpdateReadState (oneInformationObj) {
      const self = this
      const res = await updateReadState({id: oneInformationObj.id})
      if (res.code === 0) {
        self.searchData.offset = 1
        //self.messageList = []
        //self.getUserInforListFn()
        // 手动更新状态
        self.messageList.forEach((oneMessage,i) => {
          if (oneMessage.id == oneInformationObj.id) {
            oneMessage.read_state = true
            var obj = oneMessage
            self.$set(self.messageList,i, obj)
          }
        })
        self.beganGetInformationTotal()
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      } 
    },
    async beganGetInformationTotal () {
      const self = this
      const res = await getInformationTotal()
      if (res.code === 0) {
        self.totalArr = res.data
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      } 
    },
    loadMore () {
      if (this.aq === false) {
        return
      }
      if (this.searchData.offset === 1) {
        this.searchData.offset++
      }
      this.getUserInforListFn()
    },
    async getUserInforListFn () {
      const self = this
      if (self.activeName == 'first') {
        self.searchData.type = 1
      } else {
        self.searchData.type = 2
      }
      const res = await getUserInforList(self.searchData)
      if (res.code === 0) {
        if (res.data.length > 0) {
          self.searchData.offset++
          const result = res.data
          for (let i = 0; i < result.length; i++) {
            if (result[i].read_state == false) {
              self.hasNoRead = true
            }
            self.messageList.push(result[i])
          }
          if (res.data.length < self.searchData.limit) {
            self.aq = false
          }
          // console.log('到底了', this.page)
        } else {
          self.aq = false
        }
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      }
    } 
  },
  mounted () {
    this.searchData.offset = 1
    this.messageList = []
    this.beganGetInformationTotal()
    this.getUserInforListFn()
  }
}
</script>
<style lang="less" scoped>
.personInforContainer{
  width:880px;
  padding: 0 25px;
  position: relative;
  overflow: hidden;
  height: 100%;
  .userinfo-title{
    position: relative;
    width: 100%;
    height: 48px;
    line-height: 48px;
    .titleName{
      font-size:18px;
      color:#303133;
      font-weight: 700;
    }
  }
  .close-btn {
    position: absolute;
    right: -5px;
    top: 0px;
    color: #9facc3;
    font-size: 24px !important;
    cursor: pointer;
  }
  ::v-deep .personContent{
    height:calc(100% - 68px);
    // border:1px solid #dcdfe6;
    .el-tabs{
      height:100%;
      box-shadow: none;
    }
    .el-tabs__content{
      height:calc(100% - 40px);
      padding:15px 20px;
      padding-top: 0px;
      padding-bottom: 0px;
      padding-right: 0px;
      // overflow-y:auto;
      .el-tab-pane{
        height: 100%;
      }
    }
  }
  ::v-deep .noAnnounce{
    .el-tabs__content{
      background:url('../../assets/images/common/noAnnounce.png') no-repeat center;
    }
  }
  ::v-deep .noNotice{
    .el-tabs__content{
      background:url('../../assets/images/common/noNotice.png') no-repeat center;
    }
  }
  .clr_88 {
    color: #888888;
  }
  ::v-deep .el-tabs__item{
    font-size:15px;
    font-weight: 700;
    color:#303133;
  }
  ::v-deep .el-tabs__item:first-of-type{
    border-right: 1px solid #dcdfe6!important;
  }
  ::v-deep .el-tabs__item.is-active{
    // border:none!important;
    box-shadow: none!important;
    color:#0a70b0;
    border-bottom: 1px solid #dcdfe6!important;
  }
  ::v-deep .el-tabs__header{
    background-color: #f9f9f9;
    border-bottom: 1px solid #dcdfe6;
  }
  ::v-deep .el-badge__content.is-fixed.is-dot{
    right: -4px;
    top: 10px;
  }
  .announceCon,.noticeCon{
    height: 100%;
    overflow: auto;
    .oneInformation{
      border-bottom: 1px dashed #dcdfe6;
      cursor: pointer;
      padding-right: 20px;
      .informationHeadCon{
        height: 36px;
        line-height: 36px;
        margin-top: 8px;
        .readIcon{
          display: inline-block;
          width:8px;
          height:8px;
          border-radius: 50%;
          background:#f56c6c;
        }
        .noReadIcon{
          background:#dcdfe6;
        }
        .informationTit{
          font-size:15px;
          color:#303133;
          font-weight: 700;
          line-height: 24px;
          margin-bottom:5px;
          letter-spacing: 1px;
          position: relative;
          img{
            position: absolute;
            top: -3px;
            right: -24px;
          }
        }
        .informationTime{
          font-size: 14px;
          font-family: arial;
          color:#909399;
        }
      }
      .informationText{
        margin-bottom: 10px;
        max-height: 48px;
        font-size:14px;
        padding-left:16px;
        color:#303133;
        line-height: 24px;
        text-align: justify;
        // 2行
        text-overflow: -o-ellipsis-lastline;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        line-clamp: 2;
        -webkit-box-orient: vertical;
      }
    }
  }
}
</style>