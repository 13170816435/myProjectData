<template>
  <div class="uploadImgDiv">
     <el-upload
      class="avatar-uploader"
      drag
      :disabled="disabled"
      name="files"
      v-bind:show-file-list="false"
      :action="UploadSrc"
      multiple
      :before-upload="chooseUploadMyImg"
      :auto-upload="isAutoUpload"
      :http-request="uploadSuc"
    >
      <img v-if="currentImgSrc" v-bind:src="currentImgSrc" class="avatar" />
      <i v-if="!currentImgSrc" class="el-icon-upload"></i>
      <div v-if="!currentImgSrc" class="el-upload__text">
        将文件拖到此处，或<em>点击上传</em>
      </div>
    </el-upload>
    <!-- <div v-if="!currentImgSrc" class="el-upload__tip clr_oarange">（图片大小不超过2MB,格式支持 png、jpg、jpeg等)</div> -->
  </div>
</template>

<script>
export default {
  props: {
    imgClass: String, // 主要是用来区分上传的是logo、banner、advertise (如果只需要上传一种类型的图片可以不传过来)
    ImgSrc: String,
    disabled: Boolean,
    isAutoUpload: Boolean,
    UploadSrc: String
  },
  data () {
    return {
      currentImgSrc: this.ImgSrc
    }
  },
  watch: {
    ImgSrc: function (val) {
      this.currentImgSrc = val
    }
  },
  methods: {
    verifyIsImg (file) {
      const types = ['image/jpeg', 'image/gif', 'image/bmp', 'image/png', 'image/jpg']
      const isJPG = types.includes(file.type)
      const isLt2M = file.size / 1024 / 1024 < 2
      if (!isJPG) {
        this.$message.error('图片只能是 jpg、jpeg、bmp、gif、png格式!')
        return false
      }
      if (!isLt2M) {
        this.$message.error('图片大小不能超过 2MB!')
        return false
      }
      return isJPG && isLt2M
    },
    // 文件上传成功
    uploadSuc (params) {
      this.$emit('uploadSuc', params, this.imgClass)
    },
    chooseUploadMyImg (file) {
      if (this.verifyIsImg(file)) {
        this.currentImgSrc = URL.createObjectURL(file)
        if (this.imgClass) {
          this.$emit('chooseUploadImg', file, this.imgClass, true)
        } else {
          this.$emit('chooseUploadImg', file, '',true)
        }
      } else {
        this.$emit('chooseUploadImg', file, '',false)
      }
    }
  },
  mounted () {
  }
}
</script>
<style lang="less" scoped>
  .avatar-uploader {
    background-color: #f9f9f9;
    border: 1px solid #e6e6e6;
    border-radius: 2px;
    box-sizing: border-box;
    width: 312px;
    height: 160px;
    margin-right: 22px;
    /* line-height: 122px; */
    vertical-align: top;
    text-align: center;
    ::v-deep .el-upload {
      display: inline-block;
      .meetingIcon {
        font-size: 52px;
        display: inline-block;
        color: #c0c4cc;
        margin: 20px 0 10px;
        line-height: 50px;
      }
       .el-upload-dragger {
        width: 309px;
        height: 156px;
        border: none;
        background: #f9f9f9;
        img{
          // width:100%;
          height:100%;
        }
      }
    }
  }
  .el-upload__tip{
    margin-top: 0px;
    line-height: 20px;
    padding: 0;
  }
</style>
