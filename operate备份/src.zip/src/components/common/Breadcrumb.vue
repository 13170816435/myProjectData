<template>
  <div class="title-bar flex_row bgf">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="eduIconfont edu-dingwei mr10"></i>
          <span v-for="(item, index) in breadCrumbs" :key="item.name">
            {{item}}
            <i class="eduIconfont edu-zhankaishouqi" v-if="index < breadCrumbs.length-1"></i>
          </span>
        </span>
      </div>
      <div class="tr col">
        <slot></slot>
      </div>
    </div>
</template>
<script>
export default {
  props: {
    breadCrumbs: {
      type: Array,
      require: true
    }
  }
}
</script>
<style lang="less" scoped>
.title-bar{
  height: 46px;
  line-height: 46px;
  padding: 0px 20px;
  color: #303133;
  font-size: 15px;
  border-bottom: 1px solid #ddd;
  .title-name{
      display: inline-block;            
  }
}
.edu-xinzeng {
  padding-right: 4px;
}
.pointer {
  color: #ED6481;
  cursor: pointer;
}
</style>
