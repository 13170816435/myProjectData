<template>
  <div class="tab-wrap">
    <div class="m-tab">
      <div
        class="m-tab-item"
        :class="value === item.code ? 'm-tab-item-active' : ''"
        v-for="(item, index) in tabList"
        :key="index"
        @click="toggleTab(item.code)"
      >
        {{ item.name }}
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    tabList: Array,
    value: String,
  },
  methods: {
    toggleTab(code) {
      this.$emit("input", code);
    },
  },
};
</script>
<style lang="less" scoped>
.tab-wrap {
  padding: 0 10px;
  display: flex;
  background-color: #fff;
  .m-tab {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .m-tab-item {
    padding: 16px 20px;
    color: #303133;
    font-size: 15px;
    text-align: center;
    cursor: pointer;
    font-weight: 700;
     border-bottom: 2px solid transparent;
  }
  .m-tab-item-active {
    color: #0a70b0;
    font-weight: 700;
    border-bottom: 2px solid #0a70b0;
  }
  .tab-line {
    height: 2px;
    width: 95px;
    background: #0a70b0;
    position: absolute;
    bottom: 0;
    left: 0;
    transition: all 0.3s ease;
  }
}
</style>
