<style lang="less" scoped>
.Column_font{position: absolute;top: -40px;
  left: 95px;}
::v-deep .el-dialog__header{text-align: left; position: relative;}
.column_table_div .el-table td{padding: 0px;height: 40px; line-height: 40px;}
.cloumnAlert {::v-deep .el-dialog__body{padding: 10px 25px 25px!important;}}
.clr_fff {
    color: #fff;
}
</style>
<template>
  <el-dialog
    title="表格自定义列"
    :visible.sync="SetColumndShow"
    width="880px"
    top="2%"
    :before-close="SetColumnClose"
    class="cloumnAlert"
    center>
    <div style="width:828px;max-height:600px;position: relative" class="column_table_div">
      <div class="Column_font clr_fff" >(拖动整条可以调整行的前后顺序)</div>
      <el-table :data="tableData"
            border
            width="780px"
            max-height="550"
            stripe
            row-key="sortNo"
            align='center'
            ref="ColumnTable"
            highlight-current-row
            header-row-class-name="strong"
             >
           <el-table-column v-for="(item, index) in col"
              :key="`col_${index}`"
              :prop="dropCol[index].prop"
               align='center'
              :label="item.label">
              <template slot-scope="scope" >
                <p v-if="scope.column.property=='checked'" @click="ColumnRowChange(scope.row)">
                  <i class="iconfont f16 clr_main" v-show="scope.row[scope.column.property]">&#xeb23;</i>
                  <i class="iconfont f16 clr_666" v-show="!scope.row[scope.column.property]">&#xeb22;</i>
                </p>
                 <p v-else @dblclick="ColumncellChange(scope.row)">
                    <span v-show="!scope.row.disabled">{{scope.row[scope.column.property]}}</span>
                    <el-input v-model="scope.row[scope.column.property]"  v-show="scope.row.disabled"></el-input>
                 </p>
              </template>
            </el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer mt20 fr of">
          <el-button @click="SetColumnClose">取消</el-button>
          <el-button type="primary" @click="ReSetColumn" >还原</el-button>
          <el-button type="primary" @click="SetColumnSave" >保存</el-button>
      </div>

     </div>
  </el-dialog>
</template>
<script>
import Sortable from 'sortablejs'
import api from '@/api/yunshangfuyouApi/pacs'
export default {
  name: 'SetColumns',
  data () {
    return {
      SetColumndialog: false,
      col: [
        {
          label: '显示列',
          prop: 'checked'
        },
        {
          label: '列名',
          prop: 'dataKey'
        },
        {
          label: '列宽',
          prop: 'dataValue'
        }
      ],
      dropCol: [
        {
          label: '显示列',
          prop: 'checked'
        },
        {
          label: '列名',
          prop: 'dataKey'
        },
        {
          label: '列宽',
          prop: 'dataValue'
        }
      ],
      tableData: []
    }
  },
  methods: {
    // 列拖拽
    rowDrop () {
      // 此时找到的元素是要拖拽元素的父容器
      const tbody = document.querySelector('.column_table_div  .el-table__body-wrapper  tbody')
      const _this = this
      Sortable.create(tbody, {
      //  指定父元素下可被拖拽的子元素
        draggable: '.el-table__row',
        onEnd ({ newIndex, oldIndex }) {
          const currRow = _this.tableData.splice(oldIndex, 1)[0]
          _this.tableData.splice(newIndex, 0, currRow)
        }
      })
    },
    // 列改变是否选中
    ColumnRowChange (row, event, column) {
      var _this = this
      var Old = _this.tableData
      Old.forEach(item => {
        if (item.columnField === row.columnField) {
          item.checked = !item.checked
        }
      })
      _this.tableData = Old
    },
    // 表格改变是否可编辑
    ColumncellChange (row, event, column) {
      var _this = this
      var Old = _this.tableData
      Old.forEach(item => {
        item.disabled = false
        if (item.columnField === row.columnField) {
          item.disabled = !item.disabled
        }
      })
      _this.tableData = []
      _this.tableData = Old
    },
    // 重置
    ReSetColumn () {
      var _this = this
      var data = {
        owner: _this.owner
      }
      if (this.platformService === 1) {
        api.pacsApi.RecoverColumn(data).then(res => {
          if (res.code === 0) {
            _this.getColumn()
          } else {
            // _this.$message.error(res.msg)
            var NewArr = []
            _this.defaultColumn.forEach(item => {
              var checked = false
              if (item.visibility) { checked = true }
              item.disabled = false
              item.checked = checked
              item.sortNo = item.sort
              item.columnField = item.field_code
              item.dataKey = item.field_name
              item.dataValue = item.column_width
              NewArr.push(item)
            })
            _this.tableData = NewArr
          }
        })
      } else {
        // 其他系统恢复默认调用保存接口
        this.tableData = this.defaultColumn
        this.SetColumnSave()
      }
    },
    // 获取列
    getColumn () {
      var _this = this
      var data = {
        owner: _this.owner,
        platform_service: _this.platformService
      }
      api.pacsApi.getColumnCustom(data).then(res => {
        if (res.code === 0) {
          if (res.data) {
            var Arr = []
            if (res.data.length > 0) {
              Arr = res.data
              Arr = Arr.sort((a, b) => {
                return a.sort - b.sort
              })
            } else {
              Arr = _this.defaultColumn
            }
            var NewArr = []
            Arr.forEach(item => {
              var checked = false
              if (item.visibility) { checked = true }
              item.disabled = false
              item.checked = checked
              item.sortNo = item.sort
              item.columnField = item.field_code
              item.dataKey = item.field_name
              item.dataValue = item.column_width
              NewArr.push(item)
            })
            _this.tableData = NewArr
          }
        } else {
          _this.$message.error(res.msg)
        }
      })
    },
    // 设置关闭
    SetColumnClose () {
      this.$emit('SetColumndBack', '')
    },
    // 头部拖动保存
    headSetColumnSave (_value) {
      var key = _value
      var _this = this
      var Arr = _this.tableData
      Arr.forEach(item => {
        if (item.columnField === key.prop) {
          item.column_width = key.width
        }
      })
      var data = {
        views: Arr,
        platform_service: _this.platformService
      }
      api.pacsApi.SaveColumnCustom(data).then(res => {
        if (res.code === 0) {
          _this.$emit('SetColumndBack', true)
        } else {
          _this.$message.error(res.msg)
        }
      })
    },
    // 保存
    SetColumnSave () {
      var _this = this
      var Arr = _this.tableData
      var newArr = []
      Arr.forEach(item => {
        var visibility = 0
        if (item.checked) {
          visibility = 1
        }

        if (_this.platformService === 2) {
          if (!item.columnField) {
            item.columnField = item.field_code
          }
          if (Arr === this.defaultColumn) {
            visibility = 1
          }
        }
        var oneitem = {
          id: item.id,
          owner: item.owner,
          field_code: item.columnField || item.column_field,
          field_name: item.dataKey || item.field_name,
          column_width: item.dataValue || item.column_width,
          essential: item.essential,
          visibility: visibility,
          fixed: item.fixed,
          sort: item.sort,
          organization_id: item.organization_id,
          department_id: item.department_id,
          user_id: item.user_id,
          system_instance_id: item.system_instance_id
        }
        newArr.push(oneitem)
      })
      var data = {
        views: newArr,
        platform_service: _this.platformService
      }
      api.pacsApi.SaveColumnCustom(data).then(res => {
        if (res.code === 0) {
          _this.$emit('SetColumndBack', true)
        } else {
          _this.$message.error(res.msg)
        }
      })
    }
  },
  props: {
    owner: {},
    SetColumndShow: {},
    defaultColumn: {},
    // 云PACS = 1, 远程医疗 = 2, 云存储 = 3
    platformService: {
      default: 1
    }
  },
  watch: {
    SetColumndShow (val) {
      if (val) {
        this.getColumn()
        setTimeout(() => {
          this.rowDrop()
        }, 0)
      }
    }
  },
  mounted () {}
}
</script>
