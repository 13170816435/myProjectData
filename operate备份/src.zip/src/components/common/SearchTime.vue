 <template>
 <!-- 时间 -->
  <div>
    <el-date-picker
      :style="{width: width}"
      v-model="time"
      type="daterange"
      align="right"
      unlink-panels
      range-separator="至"
      start-placeholder="开始日期"
      end-placeholder="结束日期"
      :picker-options="pickerOptions"
      @change="changeTime"
      value-format="yyyy-MM-dd HH:mm:ss">
    </el-date-picker>
  </div>
</template>
<script>
export default {
  name: 'SearchTime',
  props: {
    width: String,
    clearTime: { // 重置时
      type: Boolean,
      required: false
    },
    initTime: { // 初始化时给定默认时间
      type: Array,
      required: false
    }
  },
  watch: {
    clearTime: function (value) {
      if (value === true) {
        this.time = ''
      }
    },
    initTime: function (val) {
      // this.time = val
      // var start = val[0].getFullYear() + '-' + (val[0].getMonth() + 1) + '-' + val[0].getDate()
      // var end = val[1].getFullYear() + '-' + (val[1].getMonth() + 1) + '-' + val[1].getDate()
      // this.$emit('getTimes', [start, end])
      this.time = [new Date(val[0]), new Date(val[1])]
      this.$emit('getTimes', [val[0], val[1]])
    }
  },
  data () {
    return {
      time: '',
      // 快捷选项选择日期
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 6)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      }
    }
  },
  // initTime初始化时会不生效，在这初始化处理一下
  created() {
    if (this.initTime && this.initTime.length === 2) {
      this.time = [new Date(this.initTime[0]), new Date(this.initTime[1])];
      this.$emit('getTimes', [this.initTime[0], this.initTime[1]]);
    }
  },
  methods: {
    changeTime (val) {
      this.$emit('getTimes', val)
    }
  }
}
</script>
