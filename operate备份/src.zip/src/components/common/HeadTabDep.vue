<template>
    <div>
        <!-- <div class="modeNavBar row">
        <ul class="chooseOpton row f14 clr_333 bbd ">
          <li>{{navTitle}}</li>
          <li class="pl5" v-if="secondTitle">{{secondTitle}}</li>
          <li class="optionItem pl20 pr20 f16 fwb"  v-for="(item, index) in list" :key="index" :class="isActive == index ? 'active':''"  v-show="item.Ishow" @click="changeNav(index,item)">{{item.name}} {{item.num}}</li>
        </ul>
      </div> -->

        <div class="title-bar flex_row">
            <div class="tl col" style="display: flex;">
                <span class="title-name clr_303">
                    <i class="iconfont icondingwei mr10"></i>{{modularTitle}} <i class="iconfont iconzhankaishouqi"></i>
                    {{navTitle}}

                </span>
                <ul class="chooseOpton row f14 clr_333 ml20">
                    <li class="optionItem pl20 pr20 fwb" v-for="(item, index) in list" :key="index"
                        :class="isActive == index ? 'active':''" v-show="item.Ishow" @click="changeNav(index,item)">
                        {{item.name}} {{item.num}}</li>
                </ul>
            </div>
        </div>

    </div>
</template>

<script>
    export default {
        name: 'HeadTabDep',
        data() {
            return {
                // isActive: 0
            }
        },
        watch: {
            isActive: function (val) {
                console.log('this.isActive111', val)
            }
        },
        mounted() {

        },
        methods: {
            changeNav(index, item) {
                this.$emit('changeNav', item)
            }
        },
        props: {
            modularTitle: String,
            navTitle: {
                type: String,
                required: true
            },
            isActive: {
                type: String,
                required: false
            },




            secondTitle: {
                type: String,
                required: false
            },
            list: {
                type: Array,
                required: false
            },
            
        },
        components: {
        }
    }
</script>

<style lang="less" scoped>
    .chooseOpton {
        cursor: pointer;
    }

    .active {
        border-bottom: 2px solid #0099FA !important;
        color: #0099FA !important;
    }
</style>