<template>
  <div>
    <div class="modeNavBar row boxs">
      <ul class="col chooseOpton row f14 clr_333 bbd boxs">
        <li v-if="navTitle" class="">
          <i class="iconfont clr_main f16 mr5 boxs">&#xe6ac;</i>{{ navTitle }}
        </li>
        <li class="pl5 boxs" v-if="secondTitle">{{ secondTitle }}</li>
        <li
          class="optionItem mr20 pl5 pr5 f14 fwb cursor boxs"
          v-for="(item, index) in list"
          :key="index"
          :class="{active: isActive == item.index, clr_red: item.needRed && item.num > 0}"
          v-show="item.Ishow"
          @click="changeNav(index, item)"
        >
          {{ item.name }} {{ item.num }}
          <el-popover v-if="item.isOverTime"
            trigger="hover">
            <div class="popoverClass">
              即将超时或已超时的诊断任务，请优先处理
            </div>
            <i slot="reference" class="medIconfont med_tishi"></i>
          </el-popover>
        </li>
      </ul>
      <slot name="btn"></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HeadTabSwitch',
  data () {
    return {
    }
  },
  methods: {
    changeNav (index, item) {
      this.$emit('changeNav', item)
    }
  },
  props: {
    navTitle: {
      type: String,
    },
    secondTitle: {
      type: String,
      required: false
    },
    list: {
      type: Array,
      required: false
    },
    isActive: {
      type: String,
      required: false
    }
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less" scoped>
.modeNavBar {
  height: 35px;
  width: 100%;
}
.chooseOpton {
  width: 100%;
  height: 100%;
  line-height: 35px;
  font-size: 14px;
}
.chooseOpton li {
  position: relative;
}
.chooseOpton li.active:after {
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 2px;
  background: #0a70b0 !important;
  content: '';
}
.el-icon-location-outline {
  font-size: 16px;
  margin-right: 8px;
  color: #0a70b0;
}
.popoverClass{
  padding: 10px;
  border-radius: 4px;
  background: rgba(0, 0, 0, 0.7);
  color: #fff;
}
</style>
