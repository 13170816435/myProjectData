<template>
  <div class="title-bar flex_row">
    <div class="tl col">
      <span class="title-name clr_303">
        <i class="iconfont icondingwei mr10"></i>{{Titlebar.A}}
        <i v-if="Titlebar.B" class="iconfont iconzhankaishouqi"></i> {{Titlebar.B}}
        <i v-if="Titlebar.C" class="iconfont iconzhankaishouqi"></i> {{Titlebar.C}}
      </span>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    Titlebar: Object
  }
}
</script>
