<template>
  <div>
    <el-cascader
      v-model="value"
      :options="cityJson"
      @change="childrenCity"></el-cascader>
    <!-- <el-cascader :options="cityJson"  @change="childrenCity" clearable></el-cascader> -->
  </div>
</template>

<script>
export default {
  props: {
    value: Array,
    cityJson: Array
  },
  methods: {
    childrenCity (val) {
      this.$emit('childrenCity', val)
    }
  }
}
</script>

<style lang="stylus" scoped>

</style>