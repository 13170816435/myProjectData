<template>
  <div class="title-bar flex_row">
    <div class="tl col">
      <span class="title-name clr_303">
        <i class="iconfont icondingwei mr10"></i>
        <span v-for="(item, index) in menuList" :key="index">
          <span>{{ item }}</span>
          <i
            v-if="index < menuList.length - 1"
            class="iconfont iconzhankaishouqi"
          ></i>
        </span>
        <!-- 系统更新
        <i class="iconfont iconzhankaishouqi"></i>
        文档发布 -->
      </span>
    </div>
    <div>
      <slot name="right"></slot>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    menuList: Array,
  },
  data() {
    return {};
  },
};
</script>
