<template>
  <div class="treeCon temp-tree">
    <div class="leftTree">
      <div class="operateBtnDiv">
           <span @click="AddNode" class="templateBtn operateBtn">
              <i class="iconfont iconxinzeng"></i>新增一级分类
           </span>
      </div>
      <div class='clear mytree' style="height:415px;overflow:auto;"
           v-bind:class="{'firstNode':CommonTree&&CommonTree.length!=0}">
        <!-- <el-tree :data="CommonTree" :props="defaultProps"  default-expand-all-->
        <el-tree :data="CommonTree"
                 :props="defaultProps"
                 :expand-on-click-node="false"
                 :filter-node-method="filterNode"
                 @node-click="selectCommonNode"
                 draggable
                 @node-drop="sort"
                 :allow-drop="allowDrop"
                 :node-key="'id'"
                 :default-expanded-keys="openedNodeList"
                 @node-expand="onNodeExpand"
                 @node-collapse="onNodeCollapse"
                 class="category-tree"
                 ref="modeTree">
          <span class="custom-tree-node" @click="chooseNode($event)" slot-scope="{ node, data }"
                @mouseover="showEdit($event)" @mouseout="hideEdit($event)">
            <p class="tree-label">
              <span class="treeLabel" v-bind:title="node.label">{{ node.label }}</span>
              <span class="tree-count">({{ data.count_of_templates }})</span>
            </p>
            <span class="eidtNodeBtn pl10">
              <!-- v-show="data.children" -->
              <span class="edit-btn-item" title="新增子分类" @click.stop="() => AddSonNode(data,'新增')">
                <i class="iconfont icon-xinzeng"></i>
              </span>
              <span class="edit-btn-item" title="编辑分类" @click.stop="() => EditNode(data,'编辑')">
                <i class="iconfont icon-bianji2"></i>
              </span>
              <span class="edit-btn-item del-btn-item" title="删除分类" @click.stop="() => removeNode(node, data)">
                <i class="iconfont icon-shanchu1"></i>
              </span>
              <!--              <el-button class='operateBtn myBtn' type="text" size="mini" @click.stop="() => AddSonNode(data,'新增')">
                              新增
                            </el-button>
                            <el-button class='operateBtn myBtn' type="text" size="mini" @click.stop="() => EditNode(data,'编辑')">
                              编辑
                            </el-button>
                            <el-button class="clr_red" type="text" size="mini" @click.stop="() => removeNode(node, data)">
                              删除
                            </el-button>-->
            </span>
          </span>
        </el-tree>
      </div>
      <!-- <div class="bt tc f16 lh30 clr_minor cp"  v-on:click="NewAddRootNode">增加根节点</div> -->
    </div>
    <el-dialog v-bind:title="TempCategoryTit" :visible.sync="showAddNode" width="500px" height="260px"
               :close-on-click-modal="false" v-dialogDrag>
      <div class="AddDictionaryCon">
        <div class="dictionaryItem">
          <span class="dictionaryLabel fl"><i class="iconfont iconbitian mustIcon"></i>分类名称：</span>
          <el-input class="dictionaryInput width_300_input fl" type="text"
                    v-model="addTempCategoryParam.classify_name"></el-input>
        </div>
        <div class="dictionaryItem">
          <span class="dictionaryLabel fl">关联项目分类：</span>
          <el-select
              v-model="addTempCategoryParam.exam_item_category_ids"
              @change="changeExamItemCategory"
              placeholder="请选择"
              multiple
              collapse-tags
              class="alertFormInput width_300_select">
            <el-option
                v-for="(item, index) in ExamItemCategoryArr"
                :key="index"
                :label="item.item_category"
                :value="item.id"
            ></el-option>
          </el-select>
        </div>
        <div class="dictionaryItem">
          <span class="dictionaryLabel fl">关联检查项目：</span>
          <el-select
              v-model="addTempCategoryParam.exam_item_ids"
              placeholder="请选择"
              multiple
              collapse-tags
              class="alertFormInput width_300_select">
            <el-option
                v-for="(item, index) in ExamItemList"
                :key="index"
                :label="item.item_name"
                :value="item.id"
            ></el-option>
          </el-select>
        </div>
        <!--                <div class="dictionaryItem" v-if="isUpdateTempCategory">
                          <span class="dictionaryLabel fl tiplabel">提示：</span>
                          <span class="updateTip">关联项目分类，报告编辑时可自动展开相应模板分类，方便查找模板</span>
                        </div>-->
        <div class="dictionaryItem-tip">
          <span class="dictionaryLabel fl tiplabel">提示：</span>
          <span class="updateTip">关联项目分类，报告编辑时可自动展开相应模板分类，方便查找模板</span>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
                <el-button @click="showAddNode = false">取 消</el-button>
                <el-button v-if="isUpdateTempCategory" type="primary" @click="sureUpdateTempCategory">确 定</el-button>
                <el-button v-if="!isUpdateTempCategory" type="primary" @click="sureAddTempCategory">确 定</el-button>
            </span>
    </el-dialog>
  </div>
</template>
<script>
import eventBus from '@/utils/eventBus'
import {
  getWriteTempCategory,
  addWriteTempCategory,
  updateWriteTempCategory,
  deleteWriteTempCategory,
  getExamItem,
  getExamItemCategory,
  drageTree
} from '@/api/platform_departMent/systemSet'
import {findAllId} from '@/views/ServiceCenterManagement/serviceCenterSet/formFollowUp/utils'
import {findEnabledNode, findEnabledNode2} from '@/views/ServiceCenterManagement/serviceCenterSet/utils'

export default {
  props: {
    curServiceSectId: String,
    typeItem: {
      type: Object
    },
    templateList: {
      type: Array
    },
    templateType: {}
  },
  data() {
    const CommonTree = []
    return {
      dropIndex: '',
      defaultProps: { // 模版-Props
        children: 'children',
        label: 'classify_name'
      },
      isUpdateTempCategory: false,
      TempCategoryTit: '',
      ExamItemCategoryArr: [],
      ExamItemList: [], // 检查项目
      addTempCategoryParam: { // 新增模板分类
        id: 0,
        exam_item_category_ids: [],
        exam_item_ids: [],   // 新增的检查项目
        service_sect_id: '',
        classify_name: '',
        parent_id: 0,
        sequence: 0, // 使用频率
        system_instance_id: 0 // 系统实例ID
      },
      getWriteTempCategoryParam: {
        parentId: 0, // 父节点Id
        serviceSectId: '', // 检查类型
        templateType: 0 // 模版类型【0公共 1个人】
      },
      AddNodeshow: { // 增加-修改-模版分类弹款
        show: false
      },
      selectItem: {},
      EditNodeItem: {},
      DeleteModeDia: { // 删除模版分类弹框
        show: false
      },
      deleteItem: {},
      showAddNode: false,
      CommonTree: CommonTree,
      serachProjectClassParam: {
        ParentId: '',
        ServiceSectId: '',
        ItemCategory: ''
      },
      defaultShowNodes: [],
      openedNodeList: [],
      currentName: '',
      currentNode: null,
    }
  },
  watch: {
    curServiceSectId: function (val) { // 切换检查类型
      if (val) {
        this.openedNodeList = []
        this.currentName = ''
        this.currentNode = null
        var that = this
        that.getWriteTempCategoryParam.serviceSectId = val
        /*that.getMyExamItemCategoryList()*/
        that.getWriteTempCategoryList()
      } else {
        this.CommonTree = []
      }
    }
  },
  methods: {
    onNodeExpand({id}) {
      /*if (this.openedNodeList.includes(id)) {
        return
      }

      this.openedNodeList.push(id)*/
    },

    onNodeCollapse({id, children}) {
      /*const index = this.openedNodeList.findIndex(item => item === id)
      if (index !== -1) {
        this.openedNodeList.splice(index, 1)
        if (children && children.length > 0) {
          const ids = findAllId(children)
          for (const id of ids) {
            const i = this.openedNodeList.findIndex(iItem => iItem === id)
            if (i !== -1) {
              this.openedNodeList.splice(i, 1)
            }
          }
        }
      }*/
    },

    // 拖拽需要的 allowDrop和sort
    allowDrop(draggingNode, dropNode, type) {
      // 只有 同级才能拖动
      /*if (draggingNode.data.parent_id === dropNode.data.parent_id) {
        // this.CommonTree = this.getTreeData(this.CommonTree)
        return type !== 'inner'
      } else {
        return false
      }*/
      return true
    },
    getIndex(id, arr) {
      let index = 0
      for (const i in arr) {
        if (arr[i].id === id) {
          index = arr[i].index
          this.dropIndex = index
          // return index
        }
        if (arr[i].children) {
          this.getIndex(id, arr[i].children)
        }
      }
    },
    // 处理下拉树数据
    getTreeData(data) {
      let index = 1
      for (const i in data) {
        data[i].index = index
        if (data[i].children) {
          this.getTreeData(data[i].children)
          /*data[i].count_of_templates = data[i].count_of_templates + data[i].children.reduce((total, item) => {
            return total + item.count_of_templates
          }, 0)*/
        }
        index++
      }
      return data
    },
    async sort(draggingNode, dropNode, type, event) {
      /*this.CommonTree = this.getTreeData(this.CommonTree)
      let tableData = []
      tableData = JSON.parse(JSON.stringify(this.CommonTree))
      await this.getIndex(draggingNode.data.id, tableData)
      // console.log("index", this.dropIndex)
      var drageParam = {
        service_sect_id: draggingNode.data.service_sect_id,
        template_type: 0,
        id: draggingNode.data.id,
        new_sort: this.dropIndex,
        parent_id: dropNode
      }
      const res = await drageTree(drageParam)
      if (res.code === 0) {
        // 重新去 处理index
      } else {
        this.$message({message: `${res.msg}`, type: 'error'})
      }*/

      const {parent, data: currentItem} = dropNode
      const list = Array.isArray(parent.data) ? parent.data : parent.data.children
      let index = list.findIndex(item => {
        return item.id === currentItem.id
      })
      index++
      index = type === 'after' ? index + 1 : index - 1
      const params = {
        service_sect_id: currentItem.service_sect_id,
        template_type: 0,
        id: draggingNode.data.id,
        new_sort: index,
        parent_id: Array.isArray(parent.data) ? '' : parent.data.id,
      }

      const res = await drageTree(params)
      if (res.code === 0) {
        this.$message.success('排序成功')
        await this.getWriteTempCategoryList()
      } else {
        this.$message.error(res.msg)
      }
    },


    allowDrag(draggingNode, dropNode, type) {

    },
    chooseNode(e) {
      /*var arr = document.getElementsByClassName('el-tree-node__content')
      for (let i = 0; i < arr.length; i++) {
        arr[i].classList.remove('activeNode')
        // 特殊处理第一条模板的样式
        arr[i].style.background = '#fff'
        arr[i].style.color = '#333'
      }
      const nodeObj = e.currentTarget
      nodeObj.parentNode.classList.add('activeNode')*/
    },
    showEdit(e) {
      const nodeObj = e.currentTarget
      const nextOjb = nodeObj.getElementsByClassName('eidtNodeBtn')[0]
      nextOjb.style.visibility = 'visible'
    },
    hideEdit(e) {
      const nodeObj = e.currentTarget
      const nextOjb = nodeObj.getElementsByClassName('eidtNodeBtn')[0]
      nextOjb.style.visibility = 'hidden'
    },
    selectCommonNode(data, checked, indeterminate) { // 选择公共模板节点
      this.openedNodeList = [data.id]
      this.currentName = data.classify_name
      this.currentNode = checked
      if (data.count_of_templates && data.count_of_templates > 0) {
        this.$emit('begangGetWriteTemp', data.id)
      } else {
        this.$emit('begangGetWriteTemp', null)
      }
      eventBus.$emit('getTempName', data.classify_name)

      const res = this.getPathByKey(data.id, this.CommonTree)
      eventBus.$emit('getTempNameList', [...res])
    },

    getPathByKey(curKey, data) {
      let result = []
      let traverse = (curKey, path, data) => {
        if (data.length === 0) {
          return
        }
        for (let item of data) {
          path.push(item.id)
          if (item.id === curKey) {
            result = JSON.parse(JSON.stringify(path))
            return
          }
          const children = Array.isArray(item.children) ? item.children : []
          traverse(curKey, path, children)
          path.pop()
        }
      }
      traverse(curKey, [], data)
      return result
    },

    AddNode() { // 新增-模版类别
      this.showAddNode = true
      this.isUpdateTempCategory = false
      this.TempCategoryTit = '新增模板分类'
      this.addTempCategoryParam = { // 新增模板分类
        id: 0,
        exam_item_category_ids: [],
        exam_item_ids: [], // 新增的检查项目
        service_sect_id: this.curServiceSectId,
        classify_name: '',
        parent_id: 0,
        sequence: 0, // 使用频率
        system_instance_id: 0 // 系统实例ID
      }

      this.getMyExamItemCategoryList()
    },
    AddSonNode(data, text) { // 新增-模版类别
      this.showAddNode = true
      this.isUpdateTempCategory = false
      this.TempCategoryTit = '新增模板分类'
      this.addTempCategoryParam = { // 新增模板分类
        id: 0,
        exam_item_category_ids: [],
        exam_item_ids: [],
        service_sect_id: this.curServiceSectId,
        classify_name: '',
        parent_id: data ? data.id : 0,
        sequence: 0, // 使用频率
        system_instance_id: 0 // 系统实例ID
      }
    },
    async EditNode(data, text) { // 编辑-模版类别
      this.showAddNode = true
      this.isUpdateTempCategory = true
      this.TempCategoryTit = '编辑模板分类'
      this.selectItem = data


      this.addTempCategoryParam = { // 新增模板分类
        id: data.id,
        exam_item_category_ids: data.exam_item_category_id ? data.exam_item_category_id : [],
        exam_item_ids: data.exam_item_id ? data.exam_item_id : [],
        service_sect_id: data.service_sect_id,
        classify_name: data.classify_name,
        parent_id: data.parent_id,
        sequence: data.sequence,
        system_instance_id: data.system_instance_id
      }

      await this.getMyExamItemCategoryList()
      if (data.exam_item_category_id.length > 0) {
        await this.getExamItemList(data.exam_item_category_id)
      }
    },
    removeNode(node) { // 删除-模版类别'
      const {data, parent: {data: parentItem}} = node
      this.deleteItem = data
      this.$confirm(`确定删除模板分类"${data.classify_name}"吗？`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        customClass: 'warningAlert',
        type: 'warning'
      }).then(() => {
        this.beganDelTempCategory(data.id, node, data, parentItem)
      })

      /*const h = this.$createElement
      this.deleteItem = data
      console.log(data)
      this.$msgbox({
        title: '提示',
        showCancelButton: true,
        type: 'warning',
        customClass: 'del-container',
        message: h('div', {
        }, [
            h('p', {}, '删除后将无法恢复，请谨慎操作'),
            h('p', {
              class: 'sure-del'
            }, '确定要删除所选的3条模板记录吗？')
        ])
      }).then(() => {
        this.beganDelTempCategory(data.id)
      })*/
    },
    filterNode(value, data) { // 过滤节点
      if (data) {
        if (data.isTemplate === false) {
          return true
        }
      }
    },
    // 获取项目分类列表
    async getMyExamItemCategoryList() {
      this.serachProjectClassParam.ServiceSectId = this.curServiceSectId
      this.ExamItemCategoryArr = []
      const res = await getExamItemCategory(this.serachProjectClassParam)
      if (res.code === 0) {
        this.ExamItemCategoryArr = res.data
        // this.ExamItemCategoryArr.unshift({ id: null, item_category: '请选择' })
      } else {
        this.$message({message: `${res.msg}`, type: 'error'})
      }
    },
    // 改变项目分类
    changeExamItemCategory() {
      this.addTempCategoryParam.exam_item_ids = []
      // this.addPrintTempParam.ExamItemId = ''
      this.getExamItemList(this.addTempCategoryParam.exam_item_category_ids)
    },
    // 获取检查项目
    async getExamItemList(ids) {
      this.ExamItemList = []
      const res = await getExamItem({examItemCategoryId: ids})
      if (res.code === 0) {
        this.ExamItemList = res.data
      } else {
        this.$message({message: `${res.msg}`, type: 'error'})
      }
    },
    verifyAddTempCategory() {
      const self = this
      if (!self.addTempCategoryParam.classify_name) {
        self.$message({message: '请输入分类名称', type: 'error'})
        return false
      }
      return true
    },
    // 树节点展开
    handleNodeExpand(data) {
      // 保存当前展开的节点
      let flag = false
      this.defaultShowNodes.some(item => {
        if (item === data.id) { // 判断当前节点是否存在， 存在不做处理
          flag = true
          return true
        }
      })
      if (!flag) { // 不存在则存到数组里
        this.defaultShowNodes.push(data.id)
      }
    },
    // 树节点关闭
    handleNodeCollapse(data) {
      this.defaultShowNodes.some((item, i) => {
        if (item === data.id) {
          // 删除关闭节点
          this.defaultShowNodes.length = i
        }
      })
    },
    async sureUpdateTempCategory() {
      if (this.verifyAddTempCategory()) {
        const res = await updateWriteTempCategory(this.addTempCategoryParam)
        if (res.code === 0) {
          this.showAddNode = false
          this.$message({message: '修改模板分类成功', type: 'success'})
          // Object.assign(this.selectItem, this.addTempCategoryParam)
          // this.selectItem = {}
          this.getWriteTempCategoryList()
        } else {
          this.$message({message: `${res.msg}`, type: 'error'})
        }
      }
    },
    async beganDelTempCategory(id, node, data, parentItem) {
      const self = this
      const param = {
        id: id
      }
      const result = await deleteWriteTempCategory(param)
      if (result.code === 0) {
        self.$message({
          type: 'success',
          message: '删除成功!'
        })

        const selectId = this.openedNodeList[0]
        const currentId = data.id
        if (selectId === currentId) {
          // 删除的如果是选中的id，就要选择下一个id，或者上一个id，或者父id
          const currentItem = findEnabledNode(currentId, parentItem)
          if (currentItem.id) {
            this.openedNodeList = [currentItem.id]
            this.currentName = [currentItem.classify_name]
            this.currentNode = this.$refs.modeTree.getNode(currentItem)
          }
        } else if (this.currentNode) {
          let parent = this.currentNode.parent
          let isFind = false
          while (parent) {
            const pId = Array.isArray(parent.data) ? null : parent.data.id
            if (pId === currentId) {
              isFind = true
              break
            }
            parent = parent.parent
          }

          if (isFind) {
            const currentItem = findEnabledNode2(parent.data.id, parent)
            if (currentItem.id) {
              this.openedNodeList = [currentItem.id]
              this.currentName = [currentItem.classify_name]
              this.currentNode = this.$refs.modeTree.getNode(currentItem)
            }
          }
        }

        // self.$refs.modeTree.remove(self.deleteItem)
        await self.getWriteTempCategoryList()
      } else {
        self.$message({
          type: 'info',
          message: `${result.msg}`
        })
      }
    },
    // 确定新增分
    async sureAddTempCategory() {
      if (this.verifyAddTempCategory()) {
        const res = await addWriteTempCategory(this.addTempCategoryParam)
        if (res.code === 0) {
          this.showAddNode = false
          // 内部新增分类 不重新刷新列表
          //this.$refs.modeTree.append(this.addTempCategoryParam, this.addTempCategoryParam.parent_id)
          // 重新获取模板分类
          this.getWriteTempCategoryList()
        } else {
          this.$message({message: `${res.msg}`, type: 'error'})
        }
      }
    },
    // 获取模板分类列表
    async getWriteTempCategoryList() {
      const self = this
      const res = await getWriteTempCategory(self.getWriteTempCategoryParam)
      if (res.code === 0) {
        // self.CommonTree = res.data
        // res.data.forEach( (item,i) => {
        //   item.index = i +1
        //   if (item.children) {
        //     self.getTreeData(item.children)
        //   }
        //   self.CommonTree.push(item)
        // })
        if (self.CommonTree !== null) {
          // 获取第一个模板分类 下 对应的书写模板

          self.CommonTree = self.getTreeData(res.data)

          if (self.CommonTree.length > 0) {
            if (this.openedNodeList.length > 0) {
              const id = this.openedNodeList[0]
              self.$emit('begangGetWriteTemp', id)
              eventBus.$emit('getTempName', this.currentName)
              eventBus.$emit('getTempNameList', [id])

              self.$nextTick(() => {
                /*var firstNode = document.getElementsByClassName('el-tree-node__content')[0]
                // 特殊出来第一条模板的样式
                firstNode.style.background = '#0a70b0'
                firstNode.style.color = '#fff'*/
                this.$refs.modeTree.setCurrentKey(id)
              })
            } else {
              const item = self.CommonTree[0]
              if (item.count_of_templates && item.count_of_templates > 0) {
                self.$emit('begangGetWriteTemp', self.CommonTree[0].id)
              }

              eventBus.$emit('getTempName', self.CommonTree[0].classify_name)
              eventBus.$emit('getTempNameList', [self.CommonTree[0].id])
              self.$nextTick(() => {
                /*var firstNode = document.getElementsByClassName('el-tree-node__content')[0]
                // 特殊出来第一条模板的样式
                firstNode.style.background = '#0a70b0'
                firstNode.style.color = '#fff'*/
                this.openedNodeList = [self.CommonTree[0].id]
                this.currentName = self.CommonTree[0].classify_name
                this.$refs.modeTree.setCurrentKey(this.CommonTree[0].id)
                this.currentNode = this.$refs.modeTree.getNode(this.CommonTree[0])
              })
            }
          } else {
            self.$emit('begangGetWriteTemp', null)
          }
        } else {
          self.$emit('begangGetWriteTemp', null)
          self.$emit('noWriteTemp', [])
        }
      } else {
        self.$message({message: `${res.msg}`, type: 'error'})
      }
    },

    observe() {
      eventBus.$on('onMoveTemplatesSuccess', () => {
        this.getWriteTempCategoryList()
      })
    }
  },
  mounted() {
    this.observe()
    // this.getWriteTempCategoryList()
  }
}
</script>
<style lang="less" scoped>
.treeCon {
  height: calc(100% - 15px);
  padding-right: 15px;

  .leftTree {
    height: 100%;

    .mytree {
      height: calc(100% - 37px) !important;
    }
  }
}

/*.treeLabel {
  display: inline-block;
  max-width: 180px;
  min-width: 80px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}*/

/*.tree-label {
  width: 100%;
  overflow: hidden;
  display: flex;

  .treeLabel {
    max-width: 190px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}

.eidtNodeBtn {
  display: flex;
  visibility: hidden;
  align-items: center;
  align-self: center;
}*/

::v-deep .el-tree {
  color: #333;
}

::v-deep .el-tree-node__content {
  height: 40px;
}

.firstNode {
  //   ::v-deep .is-focusable:nth-of-type(1){
  //   background-color: #0a70b0;
  //   color: #fff;
  //       .operateBtn{
  //        color:#fff;
  //     }
  // }
}

::v-deep .activeNode {
  /*background-color: #0a70b0 !important;
  color: #fff !important;;*/

  .operateBtn {
    color: #fff !important;
  }
}

::v-deep .el-tree--highlight-current .el-tree-node.is-current > .el-tree-node__content {
  // background-color: #0a70b0;
  // color: #fff;
  //     .operateBtn{
  //      color:#fff;
  //   }
}

::v-deep .el-tree-node__expand-icon {
  font-size: 14px;
  // color: #606266;
}

.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
}

.operateBtnDiv {
  .templateBtn {
    //  width:68px;
    display: inline-block;
    width: 245px;
    height: 32px;
    line-height: 31px;
    border: 1px solid #dcdfe6;
    color: #0a70b0;
    font-size: 15px;
    text-align: center;
    cursor: pointer;
    border-radius: 3px;
    margin-bottom: 15px;
    margin-left: 48px;

    i {
      font-size: 16px;
      padding-right: 3px;
    }
  }

  .operateBtn:hover {
    border-color: rgba(10, 112, 176, 0.5);
    background: #e6f3ff;
  }

  .delTemplateBtn {
    color: #f56c6c;
  }

  .delTemplateBtn:hover {
    border-color: rgba(245, 108, 108, 0.5);
    background: #fef0f0;
  }
}

/**新增字典类型弹窗样式 */
.AddDictionaryCon {
  padding-top: 25px;
  // height:104px;
  .dictionaryItem {
    height: 36px;
    margin-bottom: 20px;

    .dictionaryLabel {
      width: 120px;
      height: 36px;
      text-align: right;
      line-height: 36px;
    }

    .dictionaryInput {
      height: 36px;
      line-height: 35px;

      ::v-deep .el-input__inner {
        height: 36px;
        line-height: 36px;
        border-radius: 3px;
      }
    }

    .tiplabel {
      line-height: 23px !important;
    }

    .updateTip {
      color: #E6A23C;
      font-size: 15px;
      // line-height: 36px;
    }
  }
}

.myBtn {
  color: #fff !important;
}

.custom-tree-node {
  height: 40px;
  line-height: 40px;
  // justify-content: normal!important;
}

/*::v-deep .el-tree-node__content:hover {
  background-color: #0a70b0 !important;
  color: #fff !important;
}*/

::v-deep .el-tree-node__content {
  box-sizing: initial !important;
}

::v-deep .el-tree-node__children {
  box-sizing: initial !important;
  overflow: initial !important;
}

.edit-btn-item {
  background-color: #FFFFFF;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  border-radius: 2px;

  &:not(:last-child) {
    margin-right: 10px;
  }

  i {
    font-size: 14px;
    color: #0a70b0;
  }
}

.del-btn-item {
  i {
    color: #da4a4a !important;
  }
}

.sure-del {
  color: #E6A23C;
}

.dictionaryItem-tip {
  color: #FF9900;
  display: flex;
  margin-top: -5px;
  margin-bottom: 20px;

  .tiplabel {
    width: 65px;
    text-align: right;
  }

  .updateTip {
    width: 355px;
  }
}

.category-tree {
  ::v-deep {
    .el-tree-node__content {
      display: flex;
    }

    .custom-tree-node {
      flex: 1;
      overflow: hidden;
      display: flex;
    }

    .eidtNodeBtn {
      display: flex;
      visibility: hidden;
    }

    .tree-label {
      flex: 1;
      overflow: hidden;
      display: flex;

      .treeLabel {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .tree-count {

      }
    }
  }
}

.temp-tree {
  ::v-deep {
    .is-current {
      & > .el-tree-node__content {
        background-color: #0a70b0;
        color: #FFFFFF;
      }
    }
  }
}
</style>
