<template>
    <div class="myEditor">
      <div class="tinymce-editor-wrapper">
        <editor
          v-model="content"
          :disabled="disabled"
          :init="options"
          initial-value=""
        />
      </div>
    </div>
</template>

<script>
import tinymce from 'tinymce/tinymce'
import Editor from '@tinymce/tinymce-vue'
import 'tinymce/themes/silver'

// 编辑器插件plugins
import 'tinymce/plugins/advlist'
import 'tinymce/plugins/autolink'
import 'tinymce/plugins/lists'
import 'tinymce/plugins/link'
import 'tinymce/plugins/image'
import 'tinymce/plugins/charmap'
import 'tinymce/plugins/print'
import 'tinymce/plugins/preview'
import 'tinymce/plugins/anchor'
 
import 'tinymce/plugins/searchreplace'
import 'tinymce/plugins/visualblocks'
import 'tinymce/plugins/fullscreen'
 
import 'tinymce/plugins/insertdatetime'
import 'tinymce/plugins/media'
import 'tinymce/plugins/table'
import 'tinymce/icons/default'

// https://www.tiny.cloud/docs/configure/editor-appearance/#toolbar
const toolbar =
  'undo redo | bold underline italic strikethrough  | alignleft aligncenter alignright | bullist numlist outdent indent'
 
// https://www.tiny.cloud/docs/configure/integration-and-setup/#plugins
const plugins = [
  'advlist autolink lists link image charmap print preview anchor',
  'searchreplace visualblocks fullscreen',
  'insertdatetime media table'
]

// https://www.tiny.cloud/docs/configure/editor-appearance/#fontsize_formats
const fonts =
  'Andale Mono=andale mono,times; Arial=arial,helvetica,sans-serif; 黑体=arial black,avant garde; Book Antiqua=book antiqua,palatino; Comic Sans MS=comic sans ms,sans-serif; Courier New=courier new,courier; Georgia=georgia,palatino; Helvetica=helvetica; Impact=impact,chicago; Symbol=symbol; 宋体=tahoma,arial,helvetica,sans-serif; Terminal=terminal,monaco; Times New Roman=times new roman,times; Trebuchet MS=trebuchet ms,geneva; Verdana=verdana,geneva; Webdings=webdings; Wingdings=wingdings,zapf dingbats'

export default {
    data () {
        return {
          content: this.value,
          options: {
            language_url: process.env.NODE_ENV === 'development' ? '/tinymce/langs/zh_CN.js' : '/telemedicine/tinymce/langs/zh_CN.js', // 语言包的路径
            language: 'zh_CN', // 语言
            skin_url:  process.env.NODE_ENV === 'development' ? '/tinymce/skins/ui/oxide' : '/telemedicine/tinymce/skins/ui/oxide', // 浅色
            plugins: plugins, // 插件
            toolbar: toolbar, // 工具栏
            font_formats: fonts, // 字体
            height: this.height, // 编辑器高度
            branding: false, // 是否禁用“Powered by TinyMCE”
            menubar: false, // 顶部菜单栏显示
            contextmenu: false, // 禁用富文本的右键菜单，使用浏览器自带的右键菜单
            images_upload_handler: (blobInfo, success, failure) => {
              this.handleImageAdded(blobInfo, success, failure)
            },
            auto_focus: this.autoFocus
          }
        }
    },
    props: {
      height: {
        default () {
          return 200
        }
      },
      value: {
        type: String,
        default () {
          return ''
        }
      },
      disabled: {
        type: Boolean,
        default () {
          return false
        }
      },
      autoFocus: {
        type: Boolean,
        default () {
          return false
        }
      }
    },
    watch: {
      value(val) {  //父子组建双向绑定
        this.content = val
      },
      content(val) {
        this.$emit('input', val)
      }
    },
    components: {
        Editor
    },
    mounted() {
      tinymce.init({})
    },
    created() {
    },
    methods: {
      handleImageAdded(blobInfo, success, failure) {
        let file = blobInfo.blob()
        const isLt8M = file.size / 1024 / 1024 < 20
        if (!isLt8M) {
          this.$message.error('图片大小不能超过 20MB!')
          return
        }
        let params = new FormData()
        params.append('file', file)
        // let headers = {
        //   headers: {
        //     'Content-Type': 'multipart/form-data',
        //     Authorization: getToken()
        //   }
        // }
      },
      info(str) {  //回显内容
        this.content = str
      }
    }
}
</script>
