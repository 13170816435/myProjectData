<template>
<!-- 表格： 可通过后台返回控制table显示某列 及自定义宽度 -->
  <div>
    <!-- <el-table
      :height="tableheight"
      :data="dataList"
      border
      stripe
      :header-cell-style="{background: '#F2F2F2',color: '#333'}"
      highlight-current-row
      header-row-class-name="strong">
      <el-table-column type="index" label="序号" width="60">
        <template slot-scope="scope">
          <span>{{(pageInfo.page_index - 1) * pageInfo.page_size + scope.$index + 1}}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-for="(item, index) in propData"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        >
          <template slot-scope="scope">
            <span class="icon-btn" :class="scope.row.class" @click="operateDepinfo(scope.row.type, scope.row)" :title="scope.row.title" ><i class="iconfont" :class="scope.row.icon"></i></span>
          </template>
      </el-table-column>
    </el-table> -->
    <slot></slot>
    <!-- <slot name="functions"></slot> -->
    <el-table-column
      v-for="(item, index) in propData"
      :key="index"
      :prop="item.prop"
      :label="item.label"
      :width="item.width"
      :formatter="item.formatter"
      :show-overflow-tooltip="true"
      >
    </el-table-column>
      <!-- v-if="item.isShow" -->
    <!-- <slot name="status"></slot> -->

  </div>
</template>
<script>
export default {
  name: 'CommonTable',
  props: {
    dataList: Array,
    propData: Array,
    pageInfo: Object,
    tableheight: Number
  }
}
</script>
<style lang="less">
</style>
