<template>
    <div class="imageCon">
         <div class="showCurrentImg">
            <img v-if="currentOneImgSrc" v-bind:src="currentOneImgSrc"  id="youCurrentImg">
         </div>
         <div class="operateBtn">
            <div class="prevImgCon" @click="PrevImg">
               <i class="iconfont">&#xe70a7;</i>
            </div>
            <div class="nextImgCon" @click="nextImgCon">
                <i class="iconfont">&#xe70be;</i>
            </div>
         </div>
         
    </div>
</template>
<script>
export default {
  props: {
    imgArr:{
      type:Array,
    },
    currentImgSrc:String,
    currentImgIndex:Number,
  },
  data () {
    return {
      currentOneImgSrc:this.currentImgSrc,
      currentOneImgIndex:this.currentImgIndex,
    }
  },
  // watch: {
  //   currentImgSrc: function(val, oldVal) {
  //     this.currentOneImgSrc = val
  //   },
  //   currentImgIndex: function(val, oldVal) {
  //     this.currentOneImgIndex = val
  //   },
  // },
  methods: {
    PrevImg(){
      if(this.currentOneImgIndex-1<0){
        this.$message.error("已经是第一张了")
      }else{
        if (this.imgArr[this.currentOneImgIndex - 1] === null) {
            this.currentOneImgSrc = null
        } else {
            this.currentOneImgSrc=this.imgArr[this.currentOneImgIndex-1].src || this.imgArr[this.currentOneImgIndex-1]; //有些后台人员给的图片时base64位  有些直接时图片路径
        }
        this.currentOneImgIndex--
      }
    },
    nextImgCon(){
      if(this.currentOneImgIndex+1>=this.imgArr.length){
        this.$message.error("已经是最后一张了")
      }else{
        if (this.imgArr[this.currentOneImgIndex+1] === null) {
          this.currentOneImgSrc = null
        } else {
          this.currentOneImgSrc=this.imgArr[this.currentOneImgIndex+1].src || this.imgArr[this.currentOneImgIndex+1]; //有些后台人员给的图片时base64位  有些直接时图片路径
        }
        this.currentOneImgIndex++
        return
      }
    },
  }
}
</script>
<style lang="less" scoped>
.showCurrentImg{
  // height:500px;
  display: flex;
  justify-content: center;
  align-items: center;
  padding:10px;
  img {
    // max-width: 100%;
    // max-height: 100%;
    width:auto;
    height:auto;
  }
}
.operateBtn{
  height:40px;
  display: flex;
  justify-content: center;
  align-items: center;  
}
.prevImgCon, .nextImgCon{
  background: #000;
  color: #fff;
  border-radius: 50%;
  width: 30px;
  height: 30px;
  text-align: center;
  line-height: 30px;
  cursor: pointer;
}
.nextImgCon{
  margin-left:20px;
}
</style>