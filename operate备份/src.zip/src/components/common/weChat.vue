<template>
  <div class="wechatCon">
    <div class="">
        <span class="fl wechatLabel">微信公众号：</span>
        <el-input :style="{width:inputWidth}" class="dictionaryInput fl" type="text" v-model="weChatObj.app_id" placeholder="请输入app Id"></el-input>
        <el-input :style="{width:inputWidth}" class="dictionaryInput fl ml10" type="text" v-model="weChatObj.app_secret" placeholder="请输入app Secret"></el-input>
    </div>
    <div class="wechatTip">(绑定微信公众号参数后,可对接该公众号使用相关功能)</div>
    
  </div> 
</template>
<script>
export default {
 props: {
   weChatObj:Object,
   inputWidth: String
 }
}
</script>
<style lang="less" scoped>
.wechatLabel{
  width:120px;
  color: #303133;
  font-size: 14px;
  line-height: 30px;
  padding-right: 8px;
  text-align: right;
}
.wechatTip{
  clear:both;
  margin-left:120px;
  color: #ff9900;
  font-size: 14px;
}
</style>
