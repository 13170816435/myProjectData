<template>
  <div>
    <quill-editor :ref="refsName" v-model="contentInfo" class="myQuillEditor" :options="editorOption" @change="onEditorChange($event)" />
  </div>
</template>

<script>
import { quillEditor } from 'vue-quill-editor'
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
const toolbarOptions = [
  ['bold', 'italic', 'underline'], // 加粗 斜体 下划线 删除线
  ['blockquote', 'code-block'], // 引用  代码块
  [{ color: [] }, { background: [] }], // 字体颜色、字体背景颜色
  [{ indent: '-1' }, { indent: '+1' }], // 缩进
  [{ align: [] }], // 对齐方式
  [{ header: 1 }, { header: 2 }], // 1、2 级标题
  [{ list: 'ordered' }, { list: 'bullet' }], // 有序、无序列表
  [{ script: 'sub' }, { script: 'super' }], // 上标/下标
  ['link', 'image'], // 链接、图片、视频
  ['clean'] // 清除文本格式
]
export default {
  components: {
    quillEditor
  },
  props: {
    refsName: String,
    contentInfo: String
  },
  computed: {
    contentText () {
      return this.content
    }
  },
  data () {
    return {
      editorOption: {
        placeholder: '请在这里输入',
        modules: {
          toolbar: toolbarOptions
        }
      }
    }
  },
  methods: {
    onEditorChange (event) {
      this.$emit('onEditorChange', event)
    }
  }
}
</script>

<style>
.ql-editor{
  min-height: 100px;
}
</style>
