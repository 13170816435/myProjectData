<template>
  <!-- 语音控制 -->
  <voice-assistant
    v-if="isEnabled"
    ref="VoiceAssistant"
    title="语音助手"
    :tenancyId="tenancyId"
    :left="'50vw'"
    :top="'1vh'"
    :commands="commands"
    @startASRTask="startASRTask"
    @stopASRTask="stopASRTask"
    @sendASRData="sendASRData"
    @receiveCommand="handleReceiveCommand"
    @receiveText="handleReceiveText"
  />
</template>
<script>
import commandObj from './command'
import eventBus from '@/utils/eventBus'
import { mapGetters } from 'vuex'
export default {
  props: {
    scene: { // 使用场景（使用界面）目前只有放射做区分 默认检查报告 可选参数为 jcbg,jczx  （检查报告、检查执行）
      type: String,
      default: 'jcbg'
    },
    isAllowedVoiceRecognize: { // 该参数为控制当前页面是否允许语音输入的情况，前置条件是 系统设置 -> 系统参数 勾选了语音识别
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      commands: [], // 初始化给语音助手的命令集合
      receivedCommand: {},
      nowInputCommand: ''
    }
  },
  computed: {
    ...mapGetters([
      'systermData',
      'userLoginInfo',
    ]),
    // 语音助手是否启用
    isEnabled () {
      const enbaleFlag = this.systermData?.CommonParameter?.speechRecognition
      return this.scene === 'jczx' ? enbaleFlag && enbaleFlag.length && enbaleFlag.includes(10) : enbaleFlag && enbaleFlag.length
    },
    // 是否启用语音控制
    isEnbaledVoiceControl () {
      const enbaleFlag = this.systermData?.CommonParameter?.speechRecognition
      return enbaleFlag && enbaleFlag.length && enbaleFlag.includes(10)
    },
    // 是否启用语音识别
    isEnbaledVoiceRecognize () {
      const enbaleFlag = this.systermData?.CommonParameter?.speechRecognition
      return enbaleFlag && enbaleFlag.length && enbaleFlag.includes(20)
    },
    tenancyId () {
      return this.userLoginInfo?.profile?.tenancy_id
    }
  },
  mounted () {
    if (this.isEnabled) {
      // 初始化语音助手
      this.initEventBus()
    }
  },
  beforeDestroy() {
    eventBus.$off('ReplyVoiceAssistant')
    eventBus.$off('handleGetASRStartAck')
    eventBus.$off('handleGetASRResult')
  },
  watch: {
    isAllowedVoiceRecognize: {
      handler (newVal, oldVal) {
        if (this.isEnabled) {
          this.initCommand()
        }
      },
      immediate: true
    }
  },
  methods: {
    // 初始化指令
    async initCommand () {
      const commandRawList = commandObj ? [...commandObj[this.$routeType]] : []
      commandRawList.forEach(val => {
        val.alias = val.alias || val.name
      })
      this.commands = [...commandRawList]
      // 获取接口数据
      const res = await this.$pacsApi.pacsApi.getSystemParameterCustom()
      if (res && res.code === 0) {
        const { custom_json_data } = res.data
        if (custom_json_data) {
          // 格式化数据
          const tempArr = JSON.parse(custom_json_data)
          if (tempArr && tempArr.length) {
            const fixedArr = []
            tempArr.forEach(val => {
              const tempItem = this.commands.find(item => item.name === val.Name)
              if (tempItem) {
                tempItem.alias = val.Value
                tempItem.active = val.IsChecked === 1
                // 拼音合并默认且去重
                if (val.Pinyin) {
                  const pinYinArr = val.Pinyin.indexOf('；') > -1 ? val.Pinyin.split('；') : [val.Pinyin]
                  tempItem.pinYin = [...new Set([...pinYinArr, ...tempItem.pinYin])]
                }
                fixedArr.push(tempItem)
              }
            })
            this.commands = [...fixedArr]
          }
        }
      }
      this.commands = this.commands.filter(val => val.active && val.scene.indexOf(this.scene) > -1)
      // 只开启语音控制
      if (this.isEnbaledVoiceControl && !this.isEnbaledVoiceRecognize) {
        this.commands = this.commands.filter(val => !val.isSpeechInputCommand)
      }
      // 只开启语音识别
      if (!this.isEnbaledVoiceControl && this.isEnbaledVoiceRecognize) {
        this.commands = this.commands.filter(val => val.isSpeechInputCommand)
      }
      // 判断当前页面有没有语音识别输入的权限 该权限根据报告的状态及页面是否有查看模式等而来
      if (!this.isAllowedVoiceRecognize) {
        this.commands = this.commands.filter(val => !val.isSpeechInputCommand)
      }
    },
    // 初始化eventBus
    initEventBus () {
      // 回复语音助手，涉及到语音通知
      eventBus.$on('ReplyVoiceAssistant', msg => {
        this.handleReplyVoiceAssistant(msg)
      })
      eventBus.$on('handleGetASRStartAck', this.handleGetASRStartAck)
      eventBus.$on('handleGetASRResult', this.handleGetASRResult)
    },
    // 收到开始语音识别任务ack时的回调
    handleGetASRStartAck(res) {
      if (this.$refs.VoiceAssistant) {
        this.$refs.VoiceAssistant.handleGetASRStartAck(res)
      }
    },
    // 收到语音识别结果时的回调
    handleGetASRResult(res) {
      if (this.$refs.VoiceAssistant) {
        this.$refs.VoiceAssistant.handleGetASRResult(res)
      }
    },
    // 开始 ASR 任务
    startASRTask(msg) {
      eventBus.$emit('startASRTask', msg)
    },
    // 结束 ASR 任务
    stopASRTask(msg) {
      eventBus.$emit('stopASRTask', msg)
    },
    // 发送 ASR 语音数据
    sendASRData(msg) {
      eventBus.$emit('sendASRData', msg)
    },
    // 回复助手命令执行情况command：ReceiveCommand返回的参数原封不动的传入;
    // result：{ code: 0, speechContent: `正在录像` }
    handleReplyVoiceAssistant(msg) {
      if (this.$refs.VoiceAssistant) {
        this.$refs.VoiceAssistant.handleGetReply(this.receivedCommand, {
          code: 0,
          speechContent: msg || (msg === false ? '' : '抱歉，暂不支持') // false 表示不进行任何语音反馈提示
        })
      }
    },
    // 语音助手组件收到命令的事件回调
    handleReceiveCommand(command) {
      console.log(command, 'command');
      this.receivedCommand = command // 用于回调语音助手
      const { name } = command
      const tempItem = this.commands.find(val => val.name == name)
      const fnName = tempItem ? tempItem.fnName : ''
      if (command?.isSpeechInputCommand) { // 语音识别指令 直接回复空值给语音助手
        this.handleReplyVoiceAssistant(false)
        if (['影像所见', '影像诊断', '建议', '心电所见', '心电诊断'].includes(command.name)) {
          this.nowInputCommand = command.name
        }
        if (['输入结束'].includes(command.name)) {
          this.nowInputCommand = ''
        }
      }
      // 抛出指令及找到的方法名
      this.$emit('exec', {
        commandName: name,
        fnName: fnName,
        nowInputCommand: this.nowInputCommand
      })
    },
    // 语音识别的时候  回调的文字  目前只处理type为1的情况
    handleReceiveText ({ type, text }) {
      this.$emit('recognize', {
        commandName: this.nowInputCommand,
        text: text,
        type: type
      })
    }
  }
}
</script>
