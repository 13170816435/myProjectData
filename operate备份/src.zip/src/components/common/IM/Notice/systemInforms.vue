<template>
  <div>
    <el-dialog :visible.sync="reasonState" width="500px" :append-to-body="true" title="拒绝原因">
      <el-input class="mt10 mb10" :autosize="{minRows: 5, maxRows: 7}" type="textarea" v-model="reason"></el-input>
      <div slot="footer" class="tc">
        <el-button size="small" @click="cancelReason">取 消</el-button>
        <el-button size="small" type="primary" @click="sendImMsg">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 危急报告弹窗 -->
    <CriticalDialog
      v-if="criticalDialogVisible"
      :crisisReportShow="criticalDialogVisible"
      :DetailData="{
        id: performed_procedure_id
      }"
      :isForce="criticalValueNotice === 20"
      @crisisReportBack="crisisReportBack"
    />
    <!-- 科内会诊详情 -->
    <DepartmentConsultDetail
      v-if="departmentConsultDetailVisible && ['RIS', 'ECG'].includes($routeType)"
      :visible="departmentConsultDetailVisible"
      :report="{
        id: performed_procedure_id
      }"
      @close="handleDeptConsultDetailClose"
    />
  </div>
</template>
<script>
import eventBus from '@/utils/eventBus'
import consultMixin from '@/utils/mixin/consult'
import CriticalDialog from '@/components/pacs/commonDialog/CrisisReport' // 危急报告
import DepartmentConsultDetail from '@/components/pacs/commonDialog/DepartmentConsultDetail' // 科内会诊详情
import { mapGetters } from 'vuex'
import { printIn } from '@/utils/public'
import { ViewUrlFun } from '@/utils/public.js'
export default {
  mixins: [consultMixin],
  components: {
    CriticalDialog,
    DepartmentConsultDetail
  },
  data () {
    return {
      msgText: '',
      mettingInfo: {},
      notifyList: {},
      notifyMsg: {},
      reasonState: false,
      reason: '',
      target: '',
      // 加急报告
      dialogVisible: false,
      // 使用messageId作为弹窗的key，用来获取弹窗的实例，以对对应弹窗进行操作
      notifications: {
        urgent: ''
      },
      // 使用messageId作为弹窗的key，用来获取弹窗的实例，以对对应弹窗进行操作
      notificationsReport: {
        urgent: ''
      },
      // 危急报告
      criticalDialogVisible: false,
      performed_procedure_id: '',
      departmentConsultDetailVisible: false,
      notificationsRepeatMatchObj: {
        urgent: ''
      },
      CheckFollowUpMatchObj: {
        urgent: ''
      },
      hasOccupy: false
    }
  },
  computed: {
    ...mapGetters(['ecgProcessConfig', 'systermData', 'afterRegInfo', 'userLoginInfo']),
    criticalValueNotice () {
      return this.systermData?.ReportParameter?.criticalValueNotice || 10
    },
    greenChannelWritingReminder () {
      return this.systermData?.CommonParameter?.greenChannelWritingReminder || false
    },
    imNoticeStaySecond () {
      return (this.systermData?.CommonParameter?.imNoticeStaySecond || 0) * 1000
    },
  },
  watch: {
    afterRegInfo: {
      immediate:true,
      deep: true,
      handler (newVal, oldVal) {
        if (newVal) {
          this.handleAfterRegInfo()
        }
      }
    }
  },
  created () {
    const _this = this
    // 系统通知 ReceiveSystemNotice 来自 src\components\common\IM\components\chat.vue 的 handleGetCMDMsg 方法
    eventBus.$on('iframeImGetCmdMsg', res => {
      if (_this.userLoginInfo?.profile?.sub !== res.fromUserId) {
        // 视频通知
        if (res.exts?.MailKind === '101') {
          this.mettingInfo = res.exts
          const h = this.$createElement
          this.notifyMsg[res.msgId] = res
          this.notifyList[res.msgId] = this.$notify.info({
            title: '系统消息',
            duration: 0,
            dangerouslyUseHTMLString: true,
            message: h('div', null, [
              res.content,
              h('div', null, [
                h('el-button', {
                  style: {
                    'margin-top': '10px'
                  },
                  domProps: {
                    name: res.msgId
                  },
                  attrs: {
                    size: 'mini',
                    type: 'danger'
                  },
                  on: {
                    click: this.openReason
                  }
                }, '拒绝'),
                h('el-button', {
                  style: {
                    'margin-top': '10px'
                  },
                  domProps: {
                    name: res.msgId
                  },
                  attrs: {
                    size: 'mini',
                    type: 'primary'
                  },
                  on: {
                    click: this.joinBtn
                  }
                }, '加入')
              ])
            ]),
            position: 'top-right',
            customClass: 'topRightFix',
            onClose () {
              _this.$emit('operateVoice', {
                type: 'videoVoice',
                state: false
              })
            }
          })
          // 收到视频信息后 去更新申请端的 会诊状态
          eventBus.$emit('hadBeganConsult', res.exts.BusinessId)
          // 播放声音
          // document.getElementById('commonVideoVoice').play()
          _this.$emit('operateVoice', {
            type: 'videoVoice',
            state: true
          })
        }
      }
      const noticeMap = new Map([
        ['DeptConsultationTypeOne', this.handleDeptConsultationType], // 科内会诊转机房
        ['DeptConsultationTypeTwo', this.handleDeptConsultationType], // 科内会诊呼叫专家
        ['ReportFallback', this.showReportBackNotify], // 报告回退
        ['PreWriteBack', this.showPreWriteBackNotify], // 预写回退
        ['CriticalValueTimeOut', this.handleCriticalValueTimeOut], // 危急值上报超时提醒（根据系统参数分霸屏和右下角）
        ['SuperiorConsultation', this.handleSuperiorConsultation], // 科内会诊（上级会诊提醒）
        ['DeptConsultation', this.handleDeptConsultation], // 科内会诊转机房
        ['CompleteSuperiorConsultation', this.handleSuperiorConsultationComplete], // 科内会诊（上级会诊完成）
        ['UrgentMessage', this.showNotify], // 加急报告提醒
        ['RepeatMatch', this.showRepeatMatchNotify], // 影像重复匹配
        ['AdditionalFilm', this.handleDoSthFn], // 追加摄片提醒
        ['RePhotoGraph', this.handleDoSthFn], // 重新摄片/检查提醒
        ['DiagnosisAssist', this.handleDoSthFn], // 申请诊断提醒/申请审核提醒
        ['SpecimenBack', this.handleDoSthFn], // 标本退回提醒
        ['ChangeReport', this.handleDoSthFn], // 报告更改提醒
        ['SupplyReport', this.handleDoSthFn], // 报告补充提醒
        ['DelayReport', this.handleDoSthFn], // 迟发报告提醒
        ['PisReportComplete', this.handleDoSthFn], // 病理结果提醒
        ['RemoteConsult', this.handleRemoteConsult], // 远程会诊提醒
        ['RemoteConsult_Refunded', this.handleCaseRollback], // 远程会诊——病例回退
        ['RISMatchFailed', this.handleRISMatchFailed], // 影像匹配失败
        ['WorkStateChange', this.handleReleaseTip], // 报告释放提醒
        ['ReportAssignedToUser', this.handleReportAssign], // 报告指派提醒
        ['AppendOrReShootingToOccupy', this.handleRadiographyTip], // 追加摄片/重新摄片推送给占用医生（如果是放射报告编辑界面且id为推动id则弹出追摄/重摄弹窗）
        ['AppendOrReShootingToWrite', this.handleRadiographyTip], // 追加摄片/重新摄片推送给书写医生（如果是放射报告编辑界面且id为推动id则弹出追摄/重摄弹窗）
        ['CriticalValueProcessed', this.handleCriticalValueProcessed], // 危急值已处理
        ['ThirdPartyCriticalValue', this.handleThirdPartyCriticalValue], // 第三方危急值推送通知（根据系统参数分霸屏和右下角）
        ['ThirdPartyCriticalValueCancel', this.handleThirdPartyCriticalValueCancel], // 危急值取消
        ['ReportReviseProcessRequset', this.handleReportReviseProcessRequset], // 修订申请的通知（申请、取消、审核、退回）
        ['ReportRevise', this.handleReportRevise], // 修订申请的通知（申请、取消、审核、退回）
      ])
      const normalNoticeMap = new Map([
        ['MobilePrint', this.handleDoOther], // 手机打印
        ['ReportImage', this.handleDoOther], // 获取报告图文数据
        ['RISReportImageReminder', this.handleDoOther], // 普通悬浮提示：当前采图不生效，后台已设置最大采图数量xxx
        ['AIResult', this.handleDoOther], // 放射报告书写界面AI检测结果完成
        ['BiopsyUpdate', this.handleDoOther], // 活检自动更新（无弹窗）
        ['CallNotice', this.handleDoOther], // 增加项目通知/客户信息修改通知/弃检恢复通知（国寿）
        ['ViewPicturePostback', this.handleDoOther], // 病例读片插入图片消息
        ['RemoteConsult_Capture', this.handleRemoteCapture], // 远程会诊 采集影像互动相关
        ['RemoteConsult_Recording', this.handleRemoteCapture], // 远程会诊 采集影像互动相关
        ['RemoteConsult_SelectToPrint', this.handleRemoteCapture], // 远程会诊 采集影像互动相关
        ['Emergency', this.handleEmergency], // 紧急提醒
        ['RequestOrderChange', this.handleRejectionInspection], // 增加项目通知/客户信息修改通知/弃检恢复通知（国寿）
        ['GreenChannelWritingReminder', this.handleGreenChannelWritingReminder], // 绿通书写提醒
        ['CheckFollowUp', this.handleCheckFollowUp], // 病例随访
        ['DiagnosisNotConformity', this.handleDiagnosisNotConformity], // 诊断不符提醒
      ])
      if (res?.exts?.NoticeKind) {
        const dispose = normalNoticeMap.get(res?.exts?.NoticeKind)
        if (dispose) {
          dispose(res)
        }
      }
      // 混合消息特殊处理下
      if (res?.exts?.NoticeKind === 'CriticalValueTimeOut') { // 危急值处理超时
        if (this.criticalValueNotice === 20) {
          this.performed_procedure_id = res.exts.PerformedProcedureId
          this.criticalDialogVisible = true
        }
      } else if (res?.exts?.NoticeKind === 'WorkStateChange' && res?.exts?.Action === '报告释放') { // 推送给放射—报告释放
        if (this.$route.path.indexOf('RIS/reportEditDetail') > -1 && JSON.parse(sessionStorage.getItem('reportInfo'))?.id === res?.exts?.PerformId) {
          eventBus.$emit('toReleaseReport', res.exts)
        }
      } else if (res?.exts?.NoticeKind === 'AppendOrReShootingToOccupy') { // 追加摄片、重新摄片推送给占用医生
        if (this.$route.path.indexOf('RIS/reportEditDetail') > -1 && JSON.parse(sessionStorage.getItem('reportInfo'))?.id === res?.exts?.PerformedProcedureId) {
          eventBus.$emit('toRadiographyReport', res.exts)
        }
      } else if (res?.exts?.NoticeKind === 'AppendOrReShootingToWrite') { // 追加摄片、重新摄片推送给书写医生
        if (this.$route.path.indexOf('RIS/reportEditDetail') > -1 && JSON.parse(sessionStorage.getItem('reportInfo'))?.id === res?.exts?.PerformedProcedureId) {
          eventBus.$emit('toRadiographyReport', res.exts)
        }
      } else if (['ThirdPartyCriticalValue'].includes(res?.exts?.NoticeKind)) { // 第三方危急值推送通知
        if (this.criticalValueNotice == 20) {
          this.performed_procedure_id = res.exts.PerformedProcedureId
          this.criticalDialogVisible = true
        }
      } else {
        if (res.exts?.code === 'ScreenDomination') { // 温湿度霸屏
          const  dealDate = JSON.parse(res.exts.data)
          const {sub_title,title,seize_content,template_buttons} = dealDate
          const val = {
            sub_title, 
            title, 
            content:seize_content,
            template_buttons
          }
          if (res.exts?.ProductCode === this.$routeType) {
            beganShowWatchDialog(val)
          }
        }
        // 温湿度消息特殊处理，没有NoticeKind
        if (this.$getStationData('msgReminderEnable') && !this.$getStationData('msgNotReminderList')?.includes('temperatureAndHumidity') && res.from === '11107' && res?.exts?.BusinessType === '130' && res.exts.code !== 'ScreenDomination' && res.exts.ProductCode === this.$routeType) {
          this.handleRoomWarning(res)
        }
      }
      if (res.exts?.MailKind !== '101' && !['CallNotice'].includes(res?.exts?.NoticeKind)) { // 非视频的声音通知
        _this.$emit('operateVoice', {
          type: 'msgVoice',
          state: true
        })
      }
      if (!this.$getStationData('msgReminderEnable') || (this.$getStationData('msgReminderEnable') && this.$getStationData('msgNotReminderList')?.includes(res?.exts?.NoticeKind))) {
        return
      }
      if (res?.exts?.NoticeKind) {
        const dispose = noticeMap.get(res?.exts?.NoticeKind)
        if (dispose) {
          dispose(res)
        }
      }
    })
  },
  mounted () {
    eventBus.$on('reportEditJumpBack', msg => {
      this.goReportEdit(msg, 'repeatMatch')
    })
    eventBus.$on('handleGetWsStateMsg', msg => {
      if (msg?.state === 1) {
        this.postCheckNoticeFollow()
      }
    })
    eventBus.$on('handleClickTemplateLinkBtn', async msg => {
      this.handleClickTemplateLinkBtnFn(msg)
    })
    if (window.iselectron) {
      window.openAction = this.handleClickTemplateLinkBtnFn
    }
  },
  beforeDestroy () {
    eventBus.$off('iframeImGetCmdMsg')
    eventBus.$off('reportEditJumpBack')
    eventBus.$off('handleGetWsStateMsg')
    eventBus.$off('handleClickTemplateLinkBtn')
  },
  methods: {
    async handleClickTemplateLinkBtnFn (msg) {
      console.log("msg",msg)
      if (msg?.exts?.NoticeKind && msg?.exts?.JumpAction !== '1000') {
        const exts = msg.exts
        if (this.$routeType === 'RIS' && ['ReportFallback', 'SuperiorConsultation'].includes(exts.NoticeKind)) {
          await this.getDetail(exts)
        }
        if (['DiagnosisNotConformity', 'ReportReviseProcessRequset'].includes(exts.NoticeKind) || this.$routeType === 'RIS') {
          await this.linkBtnFn(exts)
          eventBus.$emit('closeIm')
        }
      }
      if (msg?.exts?.JumpAction === '1000') {
        this.$store.commit('app/SET_consultTaskListData', JSON.stringify(msg.exts))
        if (window.location.href.indexOf('/consult/taskList') === -1) {
          this.$nextTick(() => {
            this.$router.push({
              name: `${this.$routeType}ConsultTaskList`
            })
          })
        }
      }
      if (msg?.exts?.JumpAction === '2001') {
        if (msg.action === 'join') {
          this.joinMetting(msg.exts.BusinessId, msg.exts.KindCode)
        } else if (msg.action === 'refuse') {
          this.reasonState = true
        } 
      }
      
    },
    handleRoomWarning (res) {
      const h = this.$createElement
      const data = JSON.parse(res.exts.data)
      let arr = []
      data.params.forEach(item => {
        if (['机房温度', '机房湿度'].includes(item.name)) {
          arr.push(h('div', { style: 'margin-top: 5px' }, [
            h('span', `${item.name}：`),
            h('span', { style: 'color: #EF5350' }, `${item.value}`)
          ]),)
        } else {
          arr.push(h('div', { style: 'margin-top: 5px' }, `${item.name}：${item.value}`),)
        }
      })
      const notify = this.$draggableNotify.warning({
        title: data.title,
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        customClass: 'report-notify',
        message: h('div', { style: 'color: #333;' }, [
          h('div', { style: 'font-size: 16px' }, data.sub_title),
          ...arr,
          h('div', { style: 'margin-top: 10px; text-align: right' }, [
            h('el-button', {
              attrs: {
                size: 'small',
                type: 'primary'
              },
              on: {
                click: () => {
                  notify.close()
                }
              }
            }, '知道了')
          ]),
        ]),
      })
      this.notifications.urgent = notify
    },
    async linkBtnFn (exts) {
      let obj = {
        'AdditionalFilm': { // 追加摄片（含质控发起）（9046）
          name: `ExamExecute`,
          query: {
            AccessionNumber: exts.AccessionNumber
          }
        },
        'RePhotoGraph': { // 重新摄片（含质控发起）（9046）
          name: `ExamExecute`,
          query: {
            AccessionNumber: exts.AccessionNumber
          }
        },
        // 报告回退（9046）
        'ReportFallback': {
          name: this.hasOccupy ? `RISIndex` : `RISEditDetail`,
          query: {
            type: 'ReportFallback',
            AccessionNumber: exts.AccessionNumber,
            chosedItem: JSON.stringify({ id: exts.Id }),
            from: 'Reg',
            urgentId: exts.Id
          }
        },
        'CriticalValueTimeOut': { // 危急值超时提醒（9456）
          name: `${this.$routeType}CriticalReport`,
          query: {
            PerformedProcedureId: exts.PerformedProcedureId,
            AccessionNumber: exts.AccessionNumber
          }
        },
        'CriticalValueProcessed': { // 危急值接收处理意见（23842）
          name: `${this.$routeType}CriticalReport`,
          query: {
            PerformedProcedureId: exts.PerformedProcedureId,
            AccessionNumber: exts.AccessionNumber
          }
        },
        'SuperiorConsultation': { // 科内会诊（上级会诊）（10889）
          name: this.hasOccupy ? `RISDepartmentConsult` : `RISEditDetail`,
          query: {
            type: 'SuperiorConsultation',
            AccessionNumber: exts.AccessionNumber,
            chosedItem: JSON.stringify({ id: exts.PerformedProcedureId }),
            from: 'Reg',
            urgentId: exts.PerformedProcedureId
          }
        },
        'DeptConsultation': { // 科内会诊（科内讨论）（10889）
          name: `${this.$routeType}DeptConsultDiscuss`,
          query: {
            performID: exts.PerformedProcedureId,
            consultID: exts.ConsultationId
          }
        },
        'CompleteSuperiorConsultation': { // 科内会诊完成提醒（10889）
          name: `RISIndex`,
          query: {
            type: 'CompleteSuperiorConsultation',
            AccessionNumber: exts.AccessionNumber,
            chosedItem: JSON.stringify({ id: exts.PerformedProcedureId }),
            from: 'Reg',
            urgentId: exts.PerformedProcedureId
          }
        },
        'DiagnosisAssist': { // 远程诊断（9046）
          name: `RISIndex`,
          query: {
            type: 'DiagnosisAssist',
            AccessionNumber: exts.AccessionNumber,
            chosedItem: JSON.stringify({ id: exts.PerformedProcedureId }),
            from: 'Reg',
            urgentId: exts.PerformedProcedureId
          }
        },
        'RemoteConsult': { // 远程会诊（9046）
          name: `RISIndex`,
          query: {
            type: 'RemoteConsult',
            AccessionNumber: exts.AccessionNumber,
            chosedItem: JSON.stringify({ id: exts.Id }),
            from: 'Reg',
            urgentId: exts.Id
          }
        },
        'SpecimenBack': { // 标本退回提醒
          name: `${this.$routeType}PathologyApplication`,
          query: {
            PerformedProcedureId: exts.PerformedProcedureId
          }
        },
        'ChangeReport': { // 报告更改提醒
          name: `${this.$routeType}PathologyApplication`,
          query: {
            PerformedProcedureId: exts.PerformedProcedureId
          }
        },
        'SupplyReport': { // 报告补充提醒
          name: `${this.$routeType}PathologyApplication`,
          query: {
            PerformedProcedureId: exts.PerformedProcedureId
          }
        },
        'DelayReport': { // 迟发报告提醒
          name: `${this.$routeType}PathologyApplication`,
          query: {
            PerformedProcedureId: exts.PerformedProcedureId
          }
        },
        'PisReportComplete': { // 病理结果完成提醒
          name: `${this.$routeType}PathologyApplication`,
          query: {
            PerformedProcedureId: exts.PerformedProcedureId
          }
        },
        'CheckFollowUp': { // 病例随访
          name: `${this.$routeType}followUp`,
          // query: {
          //   PerformedProcedureId: exts.PerformedProcedureId
          // }
        },
        'DiagnosisNotConformity': { // 诊断不符提醒
          name: `${this.$routeType}DiagnoseRate`,
          query: {
            AccessionNumber: exts.AccessionNumber,
            from: 'notify',
          }
        },
        'DeptConsultationTypeOne': {
          name: `${this.$routeType}Index`,
          params: {
            id: exts.PerformedProcedureId,
            accession_number: exts.AccessionNumber,
            way: 'IM'
          },
          query: {
            t: new Date().getTime() 
          }
        },
        'ReportAssignedToUser': {
          name: `RISEditDetail`,
          query: {
            chosedItem: JSON.stringify({
              id: exts.PerformedProcedureId
            }),
            from: 'Reg',
            urgentId: exts.PerformedProcedureId
          }
        },
      }
      if (['ReportReviseProcessRequset', 'ReportRevise'].includes(exts?.NoticeKind)) {
        if (this.$routeType === 'RIS') {
          obj.ReportReviseProcessRequset = {
            name: `RISEditDetail`,
            query: {
              chosedItem: JSON.stringify({
                id: exts.PerformedProcedureId
              }),
              from: 'Reg',
              urgentId: exts.PerformedProcedureId
            }
          }
        } else {
          obj.ReportReviseProcessRequset = {
            name: `${this.$routeType}Index`,
            params: {
              id: exts.PerformedProcedureId,
              way: 'IM'
            },
            query: {
              t: new Date().getTime() 
            },
          }
        }
      }
      if (obj[exts.NoticeKind]) {
        this.$router.push({
          name: obj[exts.NoticeKind].name,
          query: obj[exts.NoticeKind].query,
          params: obj[exts.NoticeKind].params
        })
      }
    },
    async getDetail (exts) {
      const res = await this.$pacsApi.pacsApi.getReportDetail({
        id: exts.NoticeKind === 'ReportFallback' ? exts.Id : exts.PerformedProcedureId,
        ReturnTypes: [30, 40, 50, 60]
      })
      if (res?.code === 0) {
        this.hasOccupy = res?.data?.report?.occupy_doc_id && res?.data?.report?.occupy_doc_id !== this.userLoginInfo.profile.sub
        if (this.hasOccupy) {
          this.$message.warning(exts.NoticeKind === 'ReportFallback' ? '当前报告已被占用，为您跳转至报告列表' : '当前报告已被占用，为您跳转至会诊列表')
        }
      } else {
        this.$message.error(res.msg)
      }
    },
    handleDoOther (res) {
      if (res?.exts?.NoticeKind === 'MobilePrint') { // 手机打印
        printIn({
          type: 100,
          printId: res.exts.PerformedProcedureId,
        })
      } else if (res?.exts?.NoticeKind === 'ReportImage') { // 放射图文报告消息
        eventBus.$emit('RisReportImage', res) // 推送给放射报告页面
      } else if (res?.exts?.NoticeKind === 'RISReportImageReminder') {
        eventBus.$emit('RisReportImageMaxLimit', res.exts?.Message || '')
      } else if (res?.exts?.NoticeKind === 'AIResult') { // 放射报告书写界面AI检测结果完成
        eventBus.$emit('RisReportAiResult', res) // 推送给放射报告页面
      } else if (res?.exts?.NoticeKind === 'BiopsyUpdate') { // 放射报告书写界面AI检测结果完成
        eventBus.$emit('BiopsyUpdate', res.exts.PerformedProcedureId)
      } else if (res?.exts?.NoticeKind === 'CallNotice') { // 推送给预约登记-检查进程-呼叫列表
        eventBus.$emit('toCheckProcessCallList', res.exts)
      } else if (res?.exts?.NoticeKind === 'ViewPicturePostback') { // 病例读片插入图片消息
        eventBus.$emit('ViewPicturePostback', res) // 推送给放射报告页面
      }
    },
    handleEmergency (res) {
      this.$confirm(`
        <div><i class="iconfont iconjinjitixing"></i></div>
        <div class="notice-content--end">
          <span>【${res.exts.RoomName}】</span>
          <span>于${res.exts.OccurrenceTime}发生紧急事件，请知悉!</span>
        </div>`, '提醒', {
        confirmButtonText: '确定',
        cancelButtonText: '我已知晓',
        // type: 'warning',
        dangerouslyUseHTMLString: true,
        closeOnClickModal: false,
        closeOnPressEscape: false,
        showClose: false,
        showConfirmButton: false,
        customClass: 'confirm-dialog--ew emergency-notice--dialog'
      })
      .then(() => {})
      .catch(() => {})
    },
    handleDeptConsultationType (res) {
      let noticeHTML = ''
      let reasonHTML = ''
      if (res.exts.NoticeKind === 'DeptConsultationTypeOne') {
        noticeHTML = `
          <div>
            <span class="clr_0a f14 strong">${res.exts.RequestUser}</span>
            <span class="clr_333 f14 strong">邀请您进行</span>
            <span class="clr_y f14 strong">科内会诊</span>
          </div>
        `
      } else {
        noticeHTML = `
          <div>
            <span class="clr_0a f14 strong">${res.exts.RequestUser}</span>
            <span class="clr_333 f14 strong">邀请您到</span>
            <span class="clr_0a f14 strong">${res.exts.RoomName}</span>
            <span class="clr_333 f14 strong">参加</span>
            <span class="clr_y f14 strong">科内会诊</span>
          </div>
        `
      }
      if (res.exts.Reason) {
        reasonHTML = `
          <div class="lh20 mt5">
            <span class="tr pr10">会诊原因:</span>
            <span>${res.exts.Reason}</span>
          </div>
        `
      }
      let clickHtml = ''
      if (this.$routeType === 'UIS' && res.exts.NoticeKind === 'DeptConsultationTypeOne') {
        clickHtml = `<span class="clr_main underline cp">点击查看详情</span>`
      }
      const notify = this.$draggableNotify.info({
        title: res.content,
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        message: `
              ${noticeHTML}
              <div class="lh20 mt5 clr_333">
                <div>
                  <span class="mr20 strong f12">${res.exts.PatientName}</span>
                  <span class="mr20 strong f12">${res.exts.PatientSex}</span>
                  <span class="strong f12">${res.exts.PatientAge}</span>
                </div>
              </div>
              <div class="lh20 mt5">
                <span class="tr pr10">检查项目:</span>
                <span>${res.exts.ExamItem}</span>
              </div>
              ${reasonHTML}
              ${clickHtml}
            `,
        onClick: () => {
          // 点击到报告页
          if (this.$routeType === 'UIS' && res.exts.NoticeKind === 'DeptConsultationTypeOne') {
            this.$router.push({
              name: `${this.$routeType}Index`,
              params: {
                id: res.exts.PerformedProcedureId,
                accession_number: '',
                way: 'IM'
              },
              query: {
                t: new Date().getTime() 
              }
            })
            this.$nextTick(() => {
              notify.close()
            })
          }
        }
      })
    },
    handleThirdPartyCriticalValueCancel (res) {
      const { exts } = res
      const notify = this.$draggableNotify.warning({
        title: '危急值处理提醒',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_333 f14" style="margin-top: -3px;">
            <div>【${this.userLoginInfo.profile.name}】医生您好，【${exts.DoctorName}】医生已取消【${exts.PatientName}】患者的危急值，详情请到危急报告列表查看！</div>
          </div>
        `,
        onClick: () => {
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    handleReportReviseProcessRequset (res) {
      const { exts } = res
      let title = ''
      let content = ''
      let linkText = ''
      if (exts.ReqState === '-1') { // 已撤销
        title = '报告修订撤销'
        content = `
          <div>撤销医生：${exts.ReqDocName}</div>
        `
        linkText = '修订审核'
      } else if (exts.ReqState === '10') { // 待审核
        title = '报告修订申请'
        content = `
          <div>申请医生：${exts.ReqDocName}</div>
          <div>申请原因：${exts.ReqReason}</div>
        `
        linkText = '修订审核'
      } else if (exts.ReqState === '20') { // 已通过
        title = '报告修订申请已通过'
        content = `
          <div>审核医生：${exts.ApprovalDocName}</div>
        `
        linkText = '修订报告'
      } else if (exts.ReqState === '21') { // 已退回
        title = '报告修订申请已退回'
        content = `
          <div>审核医生：${exts.ApprovalDocName}</div>
          <div>退回原因：${exts.ReqReason}</div>
        `
        linkText = '报告编辑'
      }
      const notify = this.$draggableNotify.warning({
        title: title,
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_333 f14" style="margin-top: -3px;">
            <div>【${exts.PatientName}-${exts.PatientSex}-${exts.DetailAge}-${exts.ExamItemCategory} ${exts.ExaminationItemName}】</div>
            ${content}
            <div class="clr_0a cp">${linkText}</div>
          </div>
        `,
        onClick: () => {
          if (this.$routeType === 'RIS') {
            this.$router.push({
              name: 'RISEditDetail',
              query: {
                chosedItem: JSON.stringify({
                  id: exts.PerformedProcedureId
                }),
                from: 'Reg',
                urgentId: exts.PerformedProcedureId,
                time: new Date().getTime(),
              }
            })
          }
          if (['UIS', 'EIS'].includes(this.$routeType)) {
            this.$router.push({
              name: `${this.$routeType}Index`,
              params: {
                id: exts.PerformedProcedureId,
                way: 'IM'
              },
              query: {
                t: new Date().getTime() 
              }
            })
          }
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    handleReportRevise (res) {
      const { exts } = res
      const notify = this.$draggableNotify.warning({
        title: '报告修订通知',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_333 f14" style="margin-top: -3px;">
            <div>医生您好，您的报告已被【${exts.ResultReviseName}医生】修订完成！</div>
            <div>${exts.PatientName}-${exts.PatientSex}-${exts.PatientAge}-${exts.ServiceSectId}-${exts.ExaminationItemName}</div>
            <div>修订原因：${exts.ReviseReason}</div>
            <div class="clr_0a cp">查看详情</div>
          </div>
        `,
        onClick: () => {
          if (this.$routeType === 'RIS') {
            this.$router.push({
              name: 'RISEditDetail',
              query: {
                chosedItem: JSON.stringify({
                  id: exts.PerformedProcedureId
                }),
                from: 'Reg',
                urgentId: exts.PerformedProcedureId,
                time: new Date().getTime(),
              }
            })
          }
          if (['UIS', 'EIS'].includes(this.$routeType)) {
            this.$router.push({
              name: `${this.$routeType}Index`,
              params: {
                id: exts.PerformedProcedureId,
                way: 'IM'
              },
              query: {
                t: new Date().getTime() 
              }
            })
          }
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    handleThirdPartyCriticalValue (res) {
      if (this.criticalValueNotice !== 10) {
        return
      }
      const { exts } = res
      const notify = this.$draggableNotify.warning({
        title: '危急值处理提醒',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_333 f14" style="margin-top: -3px;">
            <div>【${this.userLoginInfo.profile.name}】医生您好，【${exts.InitiateUserName}】医生上报了【${exts.PatientName}】患者的危急值，请及时处理！</div>
            <div class="clr_main cp">点击查看详情</div>
          </div>
        `,
        onClick: () => {
          this.performed_procedure_id = exts.PerformedProcedureId
          this.criticalDialogVisible = true
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    handleReportAssign (res) {
      const { exts } = res
      let str = ''
      if (exts.Count == 1) {
        str = '收到一条新的指派报告，请处理！'
      } else {
        str = `收到【${exts.Count}】条新的指派报告，请到报告列表查看`
      }
      const notify = this.$draggableNotify.warning({
        title: '报告指派提醒',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_333 f14" style="margin-top: -3px;">
            <div>${str}</div>
            <div>指派人：${exts.RequestUserName}</div>
            <div>指派原因：${exts.Reason}</div>
            ${exts.Count == 1 ? '<div class="clr_main cp">点击查看详情</div>' : ''}
          </div>
        `,
        onClick: () => {
          if (exts.Count == 1) {
            this.$router.push({
              name: 'RISEditDetail',
              query: {
                chosedItem: JSON.stringify({
                  id: exts.PerformedProcedureId
                }),
                from: 'Reg',
                urgentId: exts.PerformedProcedureId,
                time: new Date().getTime(),
              }
            })
          }
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    async postCheckNoticeFollow () {
      const followUpTodayTip = localStorage.getItem('followUpTodayTip') ? (localStorage.getItem('followUpTodayTip') - 0) : null
      const now = new Date().getTime()
      if (document.cookie.indexOf('followUp=1') > -1 || (followUpTodayTip && now <= followUpTodayTip)) {
        return
      }
      const res = await this.$pacsApi.pacsApi.postCheckNoticeFollow()
      if (res?.code === 0) {
        document.cookie = 'followUp=1;path=/'
      } else {
        this.$message.error(res.msg)
      }
    },
    handleAfterRegInfo () {
      if (this.$getStationData('regNotify')) {
        const _this = this
        const duration = this.$getStationData('regNotifyTime') || 0
        const h = this.$createElement
        const defaultArr = [
          { show: true, name: '患者姓名', code: 'patient_name' },
          { show: true, name: '检查项目', code: 'examination_item_name' },
          { show: true, name: '检查号', code: 'accession_number' },
          { show: true, name: '排队号', code: 'queue_no' },
          { show: true, name: '等待人次', code: 'wait_number' },
          { show: false, name: '患者编号', code: 'patient_id' },
        ]
        let shwoArr = []
        let arr = []
        if (this.$getStationData('regNotifySetData')?.length) {
          shwoArr = this.$getStationData('regNotifySetData')?.filter(o => o.show)
        } else {
          shwoArr = defaultArr?.filter(o => o.show)
        }
        shwoArr.forEach((item, index) => {
          let text = ''
          if (item.code === 'queue_no') {
            text = this.afterRegInfo?.queue_no_prefix ? (this.afterRegInfo?.queue_no_prefix + this.afterRegInfo?.queue_no) : this.afterRegInfo?.queue_no
          } else {
            text = this.afterRegInfo[item.code]
          }
          arr.push(
            h('div', {
              style: 'margin-bottom: 8px; display: flex;'
            }, [
              h('div', { style: 'width: 92px; text-align: right; flex-shrink: 0; '}, `${item.name}：`),
              h('div', { style: 'color: #EF8900; '}, text),
            ]),
          )
        })
        const notify = this.$draggableNotify({
          title: '登记成功',
          type: 'success',
          dangerouslyUseHTMLString: true,
          duration: Number(duration) * 1000,
          customClass: 'w-dialog o-z2020',
          message: h('div', { style: 'padding: 6px 0px 40px 5px;' }, [
            h('div', { style: 'color: #333; font-size: 18px; line-height: 1.2; ' }, arr),
            h('div', { style: 'text-align: right; position: absolute; right: 20px; bottom: 10px;' }, [
              h('el-button', {
                style: {
                  'margin-top': '10px'
                },
                attrs: {
                  size: 'small',
                  type: 'primary'
                },
                on: {
                  click: () => _this.handleAfterRegNotifyClose('click')
                }
              }, '知道了')
            ])
          ]),
          position: 'bottom-right',
          onClose () {
            _this.handleAfterRegNotifyClose()
          }
        })
        // 将messageId和通知实例放入字典中
        this.notifications.urgent = notify
      }
    },
    // 点击登记通知关闭
    handleAfterRegNotifyClose (way = '') {
      this.$store.dispatch('dialogCommon/setAfterRegInfo', null)
      if (way === 'click') {
        this.closeNotification()
      }
    },
    showNotify () {
      const UrgentObj = {
        patient_name: res.exts.PatientName,
        patient_sex: res.exts.PatientSex,
        detail_age: res.exts.DetailAge,
        PerformedProcedureId: res.exts.PerformedProcedureId,
        WorkState: res.exts.WorkState
      }
      const h = this.$createElement
      const notify = this.$draggableNotify({
        title: '',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        message: h('div', { style: 'padding: 16px 0px 6px 5px;' }, [
          h('h3', { style: 'position:relative' }, [
            h('i', {
              style: {
                color: '#EF8900',
                'font-size': '36px',
                position: 'absolute',
                left: '-10px',
                top: '5px'
              },
              attrs: {
                class: 'iconfont icon-position'
              },
              domProps: {
                innerHTML: '&#xe6d87;'
              }
            }, ''),
            h('span', { style: 'color:#EF8900;margin:0px 0 10px 35px;font-size:16px' }, '加急报告提醒')
          ]),
          h('p', { style: 'color:#666666;margin:0px 0 10px 35px;' }, '这里有一份加急报告，需要尽快处理'),
          h('div', { style: 'color:#000000;font-weight:600;margin-top:10px;margin-left:40px;' }, [
            h('span', {
              style: {
                'margin-right': '20px'
              }
            }, UrgentObj.patient_name),
            h('span', {
              style: {
                'margin-right': '20px'
              }
            }, UrgentObj.patient_sex),
            h('span', {
              style: {
              }
            }, UrgentObj.detail_age)
          ]),
          h('div', { style: 'margin-left:35px;text-align:center' }, [
            h('el-button', {
              style: {
                'margin-top': '10px'
              },
              attrs: {
                size: 'mini',
                type: '',
                id: 'closeBtn'
              },
              on: {
                click: this.closeNotification
              }
            }, '关闭'),
            h('el-button', {
              style: {
                'margin-top': '10px'
              },
              attrs: {
                size: 'small',
                type: 'primary',
                disabled: UrgentObj.WorkState < 2090
              },
              on: {
                click: () => this.goReportEdit(UrgentObj.PerformedProcedureId, 'Urgent')
              }
            }, '报告编辑')
          ])
        ]),
        position: 'bottom-right'
      })
      // 将messageId和通知实例放入字典中
      this.notifications.urgent = notify
    },
    closeNotification (id, operateCode, message) {
      this.notifications.urgent.close()
      delete this.notifications.urgent
      clearInterval(this.timer)
    },
    // 加入视频
    joinBtn ($event) {
      this.target = $event
      this.joinMetting(this.mettingInfo.BusinessId, this.mettingInfo.KindCode)
      this.closeNotify()
    },
    // 发送IM消息
    sendImMsg () {
      const _this = this
      if (_this.reason.length === 0) {
        _this.$message.error('请填写拒绝原因')
        return
      }
      this.closeNotify(true)
    },
    // 关闭弹窗
    closeNotify (sendMsg) {
      const ele = this.target.target
      let msgId = ''
      if (ele.tagName === 'SPAN') {
        msgId = ele.parentNode.name
      } else {
        msgId = ele.name
      }
      this.notifyList[msgId].close()
      if (sendMsg) {
        // 发送IM消息
        const command = {
          EventType: 1,
          to: this.notifyMsg[msgId].fromUserId, // 对方id
          MsgType: 1, // 消息类型
          Content: `医生拒绝了您的会诊邀请，拒绝原因：${this.reason}` // 消息内容,
        }
        eventBus.$emit('sendCmdMsg', command)
        this.cancelReason()
      }
    },
    // 打开拒绝原因
    openReason ($event) {
      this.target = $event
      this.reasonState = true
    },
    // 关闭拒绝原因
    cancelReason () {
      this.reason = ''
      this.reasonState = false
    },
    // 跳转报告详情
    goReportEdit (id, type) {
      if (id) {
        const data = {
          id: id
        }
        if (this.$routeType === 'RIS') {
          this.$router.push({
            path: process.env.NODE_ENV === 'development' ? '/RIS/reportEditDetail' : '/cloudpacs/RIS/reportEditDetail',
            name: 'RISEditDetail',
            query: {
              chosedItem: JSON.stringify(data),
              from: 'Reg',
              urgentId: id,
              time: new Date().getTime(),
            }
          })
        }
        if (this.$routeType === 'UIS') { // stt & lh 讨论结果  默认调到报告模式详情界面
          localStorage.setItem('UISReportMode', 'report')
          localStorage.setItem('UISReportModeId', id)
          this.$nextTick(() => {
            this.$router.push({
              name: `UISReportModeIndex`,
            })
          })
        }
      }
      if (type === 'Urgent') {
        this.closeNotification()
      } else if (type === 'reportBack') {
        this.closeReportBack()
      } else if (type === 'repeatMatch') {
        this.closeRepeatMatch()
      }
      this.dialogVisible = false
    },
    goReportEditFn (id) {
      if (window.location.href.indexOf('/reportEditDetail') > -1) {
        eventBus.$emit('reportEditJump', id)
      } else {
        this.goReportEdit(id, 'repeatMatch')
      }
    },
    // 报告回退消息
    showReportBackNotify (res) {
      const reportBackObj = {
        patient_name: res.exts.PatientName,
        patient_sex: res.exts.PatientSex,
        detail_age: res.exts.DetailAge,
        PerformedProcedureId: res.exts.Id,
        reportBackReason: res.exts.ReportBackReason,
        result_assistant_name: res.exts.ResultAssistantName
      }
      const h = this.$createElement
      const notify = this.$draggableNotify({
        title: '',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        customClass: 'report-notify',
        message: h('div', { style: 'padding: 16px 0px 6px 5px;' }, [
          h('h3', { style: 'position:relative;display:flex' }, [
            h('i', {
              style: {
                color: '#EF8900',
                'font-size': '36px',
                position: 'absolute',
                left: '-10px',
                top: '5px'
              },
              attrs: {
                class: 'iconfont icon-position'
              },
              domProps: {
                innerHTML: '&#xe79a7;'
              }
            }, ''),
            h('span', { style: 'color:#EF8900;margin:0px 0 10px 35px;font-size:16px' }, '【' + reportBackObj.result_assistant_name + '】您好，您有一条报告回退请处理')
          ]),
          h('p', { style: 'color:#666666;margin:5px 0 10px 35px;word-wrap:break-word;width:310px' }, reportBackObj.reportBackReason),
          h('div', { style: 'color:#000000;font-weight:600;margin-top:10px;margin-left:40px;' }, [
            h('span', {
              style: {
                'margin-right': '20px'
              }
            }, reportBackObj.patient_name),
            h('span', {
              style: {
                'margin-right': '20px'
              }
            }, reportBackObj.patient_sex),
            h('span', {
              style: {
              }
            }, reportBackObj.detail_age)
          ]),
          h('div', { style: 'margin-left:35px;text-align:center' }, [
            h('el-button', {
              style: {
                'margin-top': '10px'
              },
              attrs: {
                size: 'mini',
                type: '',
                id: 'closeBtnReport'
              },
              on: {
                click: this.closeReportBack
              }
            }, '关闭'),
            h('el-button', {
              style: {
                'margin-top': '10px'
              },
              attrs: {
                size: 'small',
                type: 'primary'
              },
              on: {
                click: () => this.goReportEdit(reportBackObj.PerformedProcedureId, 'reportBack')
              }
            }, '报告编辑')
          ])
        ]),
        position: 'bottom-right'
      })
      // 将messageId和通知实例放入字典中
      this.notificationsReport.urgent = notify
    },
    // 预写回退
    showPreWriteBackNotify (res) {
      const reportBackObj = {
        patient_name: res.exts.PatientName,
        patient_sex: res.exts.PatientSex,
        detail_age: res.exts.DetailAge,
        PerformedProcedureId: res.exts.Id,
        reportBackReason: res.exts.ReportBackReason,
        PreWritingDocName: res.exts.PreWritingDocName
      }
      const h = this.$createElement
      const notify = this.$draggableNotify({
        title: '',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        customClass: 'report-notify',
        message: h('div', { style: 'padding: 16px 0px 6px 5px;' }, [
          h('h3', { style: 'position:relative;display:flex' }, [
            h('i', {
              style: {
                color: '#EF8900',
                'font-size': '36px',
                position: 'absolute',
                left: '-10px',
                top: '5px'
              },
              attrs: {
                class: 'iconfont icon-position'
              },
              domProps: {
                innerHTML: '&#xe79a7;'
              }
            }, ''),
            h('span', { style: 'color:#EF8900;margin:0px 0 10px 35px;font-size:16px' }, '【' + reportBackObj.PreWritingDocName + '】您好，您有一条预写回退请处理')
          ]),
          h('p', { style: 'color:#666666;margin:5px 0 10px 35px;word-wrap:break-word;width:310px' }, reportBackObj.reportBackReason),
          h('div', { style: 'color:#000000;font-weight:600;margin-top:10px;margin-left:40px;' }, [
            h('span', {
              style: {
                'margin-right': '20px'
              }
            }, reportBackObj.patient_name),
            h('span', {
              style: {
                'margin-right': '20px'
              }
            }, reportBackObj.patient_sex),
            h('span', {
              style: {
              }
            }, reportBackObj.detail_age)
          ]),
          h('div', { style: 'margin-left:35px;text-align:center' }, [
            h('el-button', {
              style: {
                'margin-top': '10px'
              },
              attrs: {
                size: 'mini',
                type: '',
                id: 'closeBtnReport'
              },
              on: {
                click: () => {
                  notify.close()
                }
              }
            }, '关闭'),
            h('el-button', {
              style: {
                'margin-top': '10px'
              },
              attrs: {
                size: 'small',
                type: 'primary'
              },
              on: {
                click: () => {
                  if (reportBackObj.PerformedProcedureId) {
                    if (this.$routeType === 'RIS') {
                      this.$router.push({
                        path: process.env.NODE_ENV === 'development' ? '/RIS/reportEditDetail' : '/cloudpacs/RIS/reportEditDetail',
                        name: 'RISEditDetail',
                        query: {
                          chosedItem: JSON.stringify({ id: reportBackObj.PerformedProcedureId}),
                          from: 'Reg',
                          urgentId: reportBackObj.PerformedProcedureId,
                          time: new Date().getTime(),
                        }
                      })
                    }
                    if (this.$routeType === 'UIS') { // stt & lh 讨论结果  默认调到报告模式详情界面
                      localStorage.setItem('UISReportMode', 'report')
                      localStorage.setItem('UISReportModeId', reportBackObj.PerformedProcedureId)
                      this.$nextTick(() => {
                        this.$router.push({
                          name: `UISReportModeIndex`,
                        })
                      })
                    }
                    notify.close()
                  }
                }
              }
            }, '报告编辑')
          ])
        ]),
        position: 'bottom-right'
      })
    },
    // 危急值提醒消息
    async handleCriticalValueTimeOut (res) {
      if (this.criticalValueNotice !== 10) {
        return
      }
      const item = res.exts
      const notify = this.$draggableNotify.warning({
        title: '危急值上报超时提醒',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 mt5 clr_333">
            <div class="f12">
              <span class="strong">【${this.userLoginInfo.profile.name}】</span>
              <span>医生您好，</span><br>
              <span class="strong">【${item.PatientName}】</span>
              <span>患者的危急值上报还未处理，<span class="clr_red">已经超时！</span><span class="clr_main cp">点击查看详情</span></span>
            </div>
          </div>
        `,
        onClick: () => {
          this.performed_procedure_id = item.PerformedProcedureId
          this.criticalDialogVisible = true
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    // 弃检通知
    handleRejectionInspection (res) {
      if (res?.exts?.SystemId !== sessionStorage.getItem('lastname')) {
        return
      }
      const { exts, content } = res
      const notify = this.$draggableNotify.info({
        title: `${exts.RequestOrderChangeKind === 'Append' ? '增加项目通知' : exts.RequestOrderChangeKind === 'Modify' ? '客户信息修改通知' : exts.RequestOrderChangeKind === 'Cancel' ? content : exts.RequestOrderChangeKind === 'AbandonedAppend' ? '弃检恢复通知' : ''}`, // 增加项目通知、客户信息修改通知、弃检通知、弃检恢复通知
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 mt5 clr_333">
            <div>【${exts.PatientName}-${exts.MedRecNo}-${exts.ExaminationItemName}】${exts.RequestOrderChangeKind === 'Append' ? '已追加' : exts.RequestOrderChangeKind === 'Modify' ? '已修改' : exts.RequestOrderChangeKind === 'Cancel' ? '已取消' : exts.RequestOrderChangeKind === 'AbandonedAppend' ? '已恢复' : ''}！</div>
            <div class="mt10 cp bg_0a clr_fff bradius3 fr tc" style="width: 72px; padding: 8px 0px;">知道了</div>
          </div>
        `,
        onClick: () => {
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    // 上级会诊提醒
    async handleSuperiorConsultation (res) {
      const { content, exts } = res
      const item = { ...exts }
      const notify = this.$draggableNotify.warning({
        title: '科内会诊',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        customClass: 'no-title',
        message: `
                <div class="lh20 clr_333" style="margin-top: -3px;">
                  <div class="f14">
                    <span class="clr_y strong">${content}</span><br>
                    <span class="mr10">${item.PatientName}</span>
                    <span class="mr10">${item.PatientSex}</span>
                    <span class="mr20">${item.PatientAge}</span>
                    <span class="mr10">${item.ServiceSectId}</span>
                    <span class="mr10">${item.ExamItem}</span><br>
                    <span>会诊原因：${item.Reason}</span><br>
                    <span class="clr_main cp">点击进入会诊</span>
                  </div>
                </div>
              `,
        onClick: () => {
          // 跳转到书写签名
          // this.performed_procedure_id = item.PerformedProcedureId
          if (this.$routeType === 'RIS') {
            const reportEditParam = {
              QueryType: 1,
              diagnosisAction: 3,
              PageIndex: 1,
              ObservationStartTime: this.$getDefaultTime(1, -1)[1],
              ObservationEndTime: this.$getDefaultTime(1, -1)[1]
            }
            window.sessionStorage.setItem('reportEditParamNew', JSON.stringify(reportEditParam))
            this.$router.push({
              name: 'RISEditDetail',
              query: {
                chosedItem: JSON.stringify({
                  id: item.PerformedProcedureId
                }),
                from: 'Reg',
                urgentId: item.PerformedProcedureId,
                time: new Date().getTime(),
              }
            })
          }
          if (this.$routeType === 'ECG') {
            this.$router.push({
              name: 'ECGIndex',
              query: {
                performID: item.PerformedProcedureId
              }
            })
          }
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    // 上级会诊完成提醒
    async handleSuperiorConsultationComplete (res) {
      const { content, exts } = res
      const item = { ...exts }
      const notify = this.$draggableNotify.success({
        title: '科内会诊',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        customClass: 'no-title',
        message: `
                <div class="lh20 clr_333" style="margin-top: -3px;">
                  <div class="f14">
                    <span class="strong clr_1bb5">${content}</span><br>
                    <span class="mr10">${item.PatientName}</span>
                    <span class="mr10">${item.PatientSex}</span>
                    <span class="mr20">${item.PatientAge}</span>
                    <span class="mr10">${item.ServiceSectId}</span>
                    <span class="mr10">${item.ExamItem}</span><br>
                    <span class="of-ellip">影像诊断：${item.Diagnosis}</span><br>
                    <span class="clr_main cp">点击查看详情</span>
                  </div>
                </div>
              `,
        onClick: () => {
          this.performed_procedure_id = item.PerformedProcedureId
          this.departmentConsultDetailVisible = true
          // 点击查看详情
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    // 科内会诊详情关闭
    handleDeptConsultDetailClose () {
      this.departmentConsultDetailVisible = false
    },
    // 科内会诊提醒
    async handleDeptConsultation (res) {
      const { content, exts } = res
      const notify = this.$draggableNotify.warning({
        title: '科内会诊',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        customClass: 'no-title',
        message: `
                <div class="lh20 clr_333" style="margin-top: -3px;">
                  <div class="f12">
                    <span class="clr_y strong f14">${content}</span><br>
                    <span class="mr20">${exts.ScheduleTime}</span>
                    <span class="mr10">${exts.ConsultationLocation}</span><br>
                    <span class="clr_main cp">点击查看详情</span>
                  </div>
                </div>
              `,
        onClick: () => {
          // this.performed_procedure_id = exts.PerformedProcedureId
          // 跳转到讨论
          this.$router.push({
            name: `${this.$routeType}DeptConsultDiscuss`,
            query: {
              performID: exts.PerformedProcedureId,
              consultID: exts.ConsultationId
            }
          })
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    // 疾病风险提示及点击跳转
    async handleRiskReportView (res) {
      const { content, exts } = res
      const item = { ...exts }
      const notify = this.$draggableNotify.warning({
        title: '疾病风险',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        customClass: 'no-title',
        message: `
                <div class="lh20 clr_333" style="margin-top: -3px;">
                  <div class="f12">
                    <span class="clr_y strong f14">${content}</span><br>
                    <span class="mr20">查看时间：${item.CheckTime}</span><br>
                    <span class="mr10">患者信息：${item.PatientName}</span>
                    <span class="mr10">${item.PatientSex}</span>
                    <span class="mr20">${item.DetailAge}</span><br>
                    <span class="clr_main cp">点击查看详情</span>
                  </div>
                </div>
              `,
        onClick: () => {
          this.performed_procedure_id = exts.PerformedProcedureId
          const { ProductCode } = exts
          if (ProductCode === 'RIS' && this.$routeType === 'RIS') {
            const reportEditParam = {
              QueryType: 1,
              diagnosisAction: 3,
              PageIndex: 1,
              ObservationStartTime: this.$getDefaultTime(1, -1)[1],
              ObservationEndTime: this.$getDefaultTime(1, -1)[1]
            }
            window.sessionStorage.setItem('reportEditParamNew', JSON.stringify(reportEditParam))
            this.$router.push({
              name: 'RISEditDetail',
              query: {
                chosedItem: JSON.stringify({
                  id: item.PerformedProcedureId
                }),
                from: 'Reg',
                urgentId: item.PerformedProcedureId,
                isAutoOpenConsultation: true,
                time: new Date().getTime(),
              }
            })
          }
          if (ProductCode === 'ECG' && this.$routeType === 'ECG') {
            this.$router.push({
              name: 'ECGIndex',
              query: {
                performID: item.PerformedProcedureId,
                riskReportDialogShow: true
              }
            })
          }
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    // 危急报告回调
    crisisReportBack (val) {
      this.criticalDialogVisible = false
    },
    closeReportBack (id, operateCode, message) {
      this.notificationsReport.urgent.close()
      delete this.notificationsReport.urgent
      clearInterval(this.timer)
    },
    // 影像重复匹配
    showRepeatMatchNotify (res) {
      const repeatMatchObj = {
        patient_name: res.exts.PatientName,
        patient_sex: res.exts.PatientSex,
        detail_age: res.exts.DetailAge,
        performed_procedure_id: res.exts.PerformedProcedureId,
        doctor_name: res.exts.DoctorName,
        content: res.content
      }
      const h = this.$createElement
      const notify = this.$draggableNotify({
        title: '',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        customClass: 'report-notify',
        message: h('div', { style: 'padding: 16px 0px 6px 5px;' }, [
          h('h3', { style: 'position:relative;display:flex' }, [
            h('i', {
              style: {
                color: '#EF8900',
                'font-size': '36px',
                position: 'absolute',
                left: '-10px',
                top: '5px'
              },
              attrs: {
                class: 'iconfont icon-position'
              },
              domProps: {
                innerHTML: '&#xe6a8;'
              }
            }, ''),
            h('span', { style: 'color:#EF8900;margin:0px 0 10px 35px;font-size:16px' }, '新产生影像提醒')
          ]),
          h('p', { style: 'color:#666666;margin:5px 0 10px 35px;word-wrap:break-word;width:310px' }, repeatMatchObj.content),
          h('div', { style: 'color:#000000;font-weight:600;margin-top:10px;margin-left:40px;' }, [
            h('span', {
              style: {
                'margin-right': '20px'
              }
            }, repeatMatchObj.patient_name),
            h('span', {
              style: {
                'margin-right': '20px'
              }
            }, repeatMatchObj.patient_sex),
            h('span', {
              style: {
              }
            }, repeatMatchObj.detail_age)
          ]),
          h('div', { style: 'margin-left:35px;text-align:center' }, [
            h('el-button', {
              style: {
                'margin-top': '10px'
              },
              attrs: {
                size: 'mini',
                type: '',
                id: 'closeBtnReport'
              },
              on: {
                click: () => {
                  notify.close()
                }
              }
            }, '关闭'),
            h('el-button', {
              style: {
                'margin-top': '10px',
                'display': window.location.href.indexOf('/reportEditDetail') === -1 || window.location.href.indexOf(repeatMatchObj.performed_procedure_id) === -1
              },
              attrs: {
                size: 'small',
                type: 'primary'
              },
              on: {
                click: () => this.goReportEditFn(repeatMatchObj.performed_procedure_id, 'repeatMatch')
              }
            }, '报告编辑'),
            h('el-button', {
              style: {
                'margin-top': '10px',
                'display': window.location.href.indexOf('/reportEditDetail') > -1 && window.location.href.indexOf(repeatMatchObj.performed_procedure_id) > -1
              },
              attrs: {
                size: 'small',
                type: 'primary'
              },
              on: {
                click: () => this.ViewUrl(repeatMatchObj)
              }
            }, '影像浏览')
          ])
        ]),
        position: 'bottom-right'
      })
      // 将messageId和通知实例放入字典中
      this.notificationsRepeatMatchObj.urgent = notify
    },
    ViewUrl: _.debounce(function(row){
      ViewUrlFun({
        performedProcedureIds: [row.performed_procedure_id],
        NeedReportImage: true,
        ...row
      })
    }, 1000, {
      'leading': true,
      'trailing': false
    }),
    closeRepeatMatch () {
      this.notificationsRepeatMatchObj.urgent.close()
      delete this.notificationsRepeatMatchObj.urgent
    },
    handleDoSthFn (res) {
      const paramsObj = {
        'AdditionalFilm': { // 重新摄片
          title: '追加摄片提醒',
          type: 'AdditionalFilm',
          name: 'ExamExecute',
          query: {
            PerformedId: res.exts.PerformedProcedureId
          }
        },
        'RePhotoGraph': { // 追摄
          title: this.$routeType === 'RIS' ? '重新摄片提醒' : '重新检查提醒',
          type: 'RePhotoGraph',
          name: this.$routeType === 'RIS' ? 'ExamExecute' : `${this.$routeType}Index`,
          query: {
            PerformedId: res.exts.PerformedProcedureId
          }
        },
        'DiagnosisAssist': { // 申请诊断/审核
          title: res.exts.DiagnosisAssist == 10 ? '申请诊断提醒' : '申请审核提醒',
          type: 'DiagnosisAssist',
          name: `${this.$routeType}Index`,
          query: {
            PerformedProcedureId: res.exts.PerformedProcedureId,
            DiagnosisAssist: res.exts.DiagnosisAssist
          }
        },
        'SpecimenBack': { // 标本退回
          title: '标本退回提醒',
          type: 'SpecimenBack',
          name: `${this.$routeType}PathologyApplication`,
          query: {
            PerformedProcedureId: res.exts.PerformedProcedureId
          }
        },
        'ChangeReport': { // 报告更改
          title: '报告更改提醒',
          type: 'ChangeReport',
          name: `${this.$routeType}PathologyApplication`,
          query: {
            PerformedProcedureId: res.exts.PerformedProcedureId
          }
        },
        'SupplyReport': { // 补充
          title: '报告补充提醒',
          type: 'SupplyReport',
          name: `${this.$routeType}PathologyApplication`,
          query: {
            PerformedProcedureId: res.exts.PerformedProcedureId
          }
        },
        'DelayReport': { // 迟发报告
          title: '迟发报告提醒',
          type: 'DelayReport',
          name: `${this.$routeType}PathologyApplication`,
          query: {
            PerformedProcedureId: res.exts.PerformedProcedureId
          }
        },
        'PisReportComplete': { // 病理结果提醒
          title: '病理结果提醒',
          type: 'PisReportComplete',
          name: `${this.$routeType}PathologyApplication`,
          query: {
            PerformedProcedureId: res.exts.PerformedProcedureId
          }
        }
      }
      if (!(this.$routeType === 'ECG' && this.ecgProcessConfig.workModel === 1)) {
        this.handleDoSth(res, paramsObj[res?.exts?.NoticeKind])
      }
    },
    // 重新摄片/追加摄片
    handleDoSth (res, obj) {
      const { content, exts } = res
      let message = ''
      if (obj.type === 'DelayReport') { // 迟发报告
        message = `
          <div class="lh20 clr_333" style="margin-top: -3px;">
            <div class="f12">
              <span class="clr_666 f14">【${exts.RequesterName}】医生，【${exts.PatientName}】患者的病理报告因【${exts.Reason}】延期<span class="clr_y">${exts.DelayDays}</span> 天，将于<span class="clr_main">${exts.ReceiveTime}</span>发放报告</span>
              <span class="clr_main cp">点击查看详情</span>
            </div>
          </div>
        `
      } else if (obj.type === 'DiagnosisAssist') { // 申请诊断、审核
        message = `
          <div class="lh20 clr_333" style="margin-top: -3px;">
            <div class="f12">
              <span class="clr_666 f14">${content}</span>
              <div class="clr_000 f14 strong">
                <span class="mr10">${exts.PatientName}</span>
                <span class="mr10">${exts.PatientSex}</span>
                <span>${exts.PatientAge}</span>
              </div>
              <div class="clr_main cp">点击查看详情</div>
            </div>
          </div>
        `
      } else if (obj.type === 'AdditionalFilm') {
        message = `
          <div class="lh20 clr_666 f14" style="margin-top: -3px;">
            <div>您负责的患者【${exts.PatientName}】的记录由【${exts.OperateUser}】发起【追加摄片】操作</div>
            <div>【追加摄片】原因：${exts.Reason}</div>
            <div>当前记录已回退为【追加摄片】状态，请知悉！</div>
            <div class="clr_main cp">点击查看详情</div>
          </div>
        `
      } else if (obj.type === 'RePhotoGraph') {
        message = `
          <div class="lh20 clr_666 f14" style="margin-top: -3px;">
            <div>您负责的患者【${exts.PatientName}】的记录由【${exts.OperateUser}】发起【重新摄片】操作</div>
            <div>重新摄片】原因：${exts.Reason}</div>
            <div>当前记录已回退为【重新摄片】状态，请知悉！</div>
            <div class="clr_main cp">点击查看详情</div>
          </div>
        `
      } else {
        message = `
          <div class="lh20 clr_333" style="margin-top: -3px;">
            <div class="f12">
              <span class="clr_666 f14">${content}</span>
              <span class="clr_main cp">点击查看详情</span>
              <div>${exts.PathologyDiagnosis ? exts.PathologyDiagnosis : ''}</div>
            </div>
          </div>
        `
      }
      const notify = this.$draggableNotify.warning({
        title: obj.title,
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: message,
        onClick: () => {
          if (obj.type === 'DiagnosisAssist' && this.$routeType === 'ECG') {
            this.$router.push({
              name: obj.name,
              query: { time: new Date().getTime() },
              params: obj.query
            })
          } else {
            this.$router.push({
              name: obj.name,
              query: obj.query
            })
          }
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    handleCriticalValueProcessed (res) {
      const { exts } = res
      let dealName = []
      let dealInfo = []
      if (exts.DoctorName) {
        dealName.push(exts.DoctorName)
      }
      if (exts.NurseName) {
        dealName.push(exts.NurseName)
      }
      if (exts.DoctorProcessInfo) {
        dealInfo.push(exts.DoctorProcessInfo)
      }
      if (exts.NurseProcessInfo) {
        dealInfo.push(exts.NurseProcessInfo)
      }
      const notify = this.$draggableNotify.warning({
        title: '危急值处理提醒',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_333 f14" style="margin-top: -3px;">
            <div>【${exts.CriticalClass == 10 ? exts.RecheckUserName : exts.InitiateUserName}】您好，【${exts.PatientName}】患者的危急值临床处理意见已完成！</div>
            <div class="flex_row">
              <p class="noshrink">处理意见：</p>
              <p>【${dealInfo.join('|') || ''}】</p>
            </div>
            <div class="flex_row">
              <p class="noshrink tr" style="width: 70px;">处理人：</p>
              <p>【${dealName.join('|') || ''}】</p>
            </div>
          </div>
        `,
        onClick: () => {
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    handleGreenChannelWritingReminder (res) {
      const notify = this.$draggableNotify.warning({
        title: res.content,
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_333 f14" style="margin-top: -3px;">
            <div>检查号：<span class="clr_orange">${res.exts.AccessionNumber}</span></div>
            <div>患者编号：<span class="clr_orange">${res.exts.PatientId}</span></div>
            <div>患者姓名：<span class="clr_orange">${res.exts.PatientName}</span></div>
            <div>检查类型：<span class="clr_orange">${res.exts.ServiceSectId}</span></div>
            <div>项目分类：<span class="clr_orange">${res.exts.ExamItemCategory}</span></div>
            <div>检查项目：<span class="clr_orange">${res.exts.ExaminationItemName}</span></div>
          </div>
        `,
        onClick: () => {
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    handleCheckFollowUp (res) {
      const h = this.$createElement
      const notify = this.$draggableNotify.warning({
        title: '病例随访提醒',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        customClass: 'report-notify',
        message: h('div', {}, [
          h('div', { class: 'lh20 clr_333 f14' }, [
            h('span', {}, '您有'),
            h('span', { class: 'clr_orange' }, `【${res.exts.WaitCount}】`),
            h('span', {  }, `条待随访记录即将到期、`),
            h('span', { class: 'clr_red' }, `【${res.exts.ExpireCount}】`),
            h('span', {  }, `条随访记录已到期，是否立即查看？`)
          ]),
          h('div', { class: 'mt10 tr' }, [
            h('el-button', {
              attrs: {
                size: 'mini',
                type: '',
              },
              on: {
                click: () => this.handleTodayNoTip()
              }
            }, '今日不再提醒'),
            h('el-button', {
              attrs: {
                size: 'mini',
                type: 'primary'
              },
              on: {
                click: () => this.handleGoFollowUp()
              }
            }, '立即查看')
          ])
        ]),
        position: 'bottom-right'
      })
      this.CheckFollowUpMatchObj.urgent = notify
    },
    closeCheckFollowUp () {
      this.CheckFollowUpMatchObj.urgent.close()
      delete this.CheckFollowUpMatchObj.urgent
    },
    handleTodayNoTip () {
      localStorage.setItem('followUpTodayTip', new Date(`${this.dayjs().format('YYYY-MM-DD')} 23:59:59`).getTime())
      this.$nextTick(() => {
        this.closeCheckFollowUp()
      })
    },
    handleGoFollowUp () {
      this.$router.push({
        name: `${sessionStorage.getItem('currentSystemClass')}followUp`
      })
      this.$nextTick(() => {
        this.closeCheckFollowUp()
      })
    },
    // 远程会诊
    handleRemoteConsult (res) {
      const { content } = res
      const notify = this.$draggableNotify.warning({
        title: '远程会诊提醒',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_333" style="margin-top: -3px;">
            <div class="f12">
              <span class="clr_666 f14">${content}</span>
            </div>
          </div>
        `,
        onClick: () => {
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    // 报告释放提醒
    handleReleaseTip (res) {
      if (res?.exts?.Action === '报告释放' && (this.$route.path.indexOf('RIS/reportEditDetail') > -1 && JSON.parse(sessionStorage.getItem('reportInfo'))?.id === res?.exts?.PerformId)) {
        return
      }
      const { exts } = res
      const notify = this.$draggableNotify.warning({
        title: '报告释放提醒',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_333" style="margin-top: -3px;">
            <div class="f12">
              <span class="clr_666 f14">医生您当前【${exts.SignAction}】的【${exts.PatientName}】的检查记录由【${exts.OptionDocName}】发起【${exts.Action}】操作，请知悉！</span>
            </div>
          </div>
        `,
        onClick: () => {
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    // 追加、重摄提醒
    handleRadiographyTip (res) {
      if (this.$route.path.indexOf('RIS/reportEditDetail') > -1 && JSON.parse(sessionStorage.getItem('reportInfo'))?.id === res?.exts?.PerformedProcedureId) {
        return
      }
      const { exts } = res
      const typeStr = exts.Operate === 'Append' ? '追加摄片' : '重新摄片'
      const notify = this.$draggableNotify.warning({
        title: typeStr,
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_666 f14" style="margin-top: -3px;">
            <div>您负责的患者【${exts.PatientName}】的记录由【${exts.OperateUser}】发起【${typeStr}】操作</div>
            <div>【${typeStr}】原因：${exts.Reason}</div>
            <div>当前记录已回退为【${typeStr}】状态，请知悉！</div>
          </div>
        `,
        onClick: () => {
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    // 远程会诊-病例回退
    handleCaseRollback (res) {
      const { exts, content } = res
      const notify = this.$draggableNotify.warning({
        title: '远程会诊—病例回退',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_333" style="margin-top: -3px;">
            <div class="f12">
              <span class="clr_666 f14">【${exts.Applicant}】医生，您有一条会诊申请记录被回退；</span><br />
              <span>病例回退原因：${exts.Reason}</span>
            </div>
            <div class="mt10 cp bg_0a clr_fff bradius3 fr tc" style="width: 72px; padding: 8px 0px;">知道了</div>
          </div>
        `,
        onClick: () => {
          this.$nextTick(() => {
            notify.close()
          })
        }
      })
    },
    // 影像匹配失败
    handleRISMatchFailed (res) {
      const notify = this.$draggableNotify.warning({
        title: '影像匹配失败',
        position: 'bottom-right',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        offse: 5,
        message: `
          <div class="lh20 clr_333" style="margin-top: -3px;">
            <div class="f12">
              <span class="clr_666 f14">当前有匹配失败的影像，请及时${this.$routeType === 'RIS' ? '' : '前往放射系统'}处理！</span><br />
              ${this.$routeType === 'RIS' ? '<span class="clr_0a cp">点击立即前往</span>' : ''}
            </div>
          </div>
        `,
        onClick: () => {
          if (this.$routeType === 'RIS') {
            this.$router.push({
              name: 'PictureArchivingService'
            })
            sessionStorage.setItem('showMatchFailed', true)
            this.$nextTick(() => {
              notify.close()
            })
          }
        }
      })
    },
    // 远程会诊影像操作相关
    handleRemoteCapture (res) {
      const { exts } = res
      const detailInfo = exts || {}
      this.$store.dispatch('collectService/setRemoteConsultParams', null)
      this.$nextTick(() => {
        this.$store.dispatch('collectService/setRemoteConsultParams', detailInfo)
      })
    },
    // 诊断不符提醒
    async handleDiagnosisNotConformity (res) {
      const detailInfo = res?.exts || {}
      const h = this.$createElement
      let desc = ''
      const noFLag = detailInfo?.NoConformityFlag == 10 ? '漏诊' : (detailInfo?.NoConformityFlag == 20 ? '误诊' : '')
      const reason = detailInfo?.Reason || ''
      if (noFLag && reason.trim()) {
        desc = `【${noFLag}】${reason}`
      } else {
        if (noFLag && !reason.trim()) {
          desc = `${noFLag}`
        }
        if (!noFLag && reason.trim()) {
          desc = `${reason}`
        }
      }
      const notify = this.$draggableNotify.warning({
        title: '诊断不符提醒',
        dangerouslyUseHTMLString: true,
        duration: this.imNoticeStaySecond,
        customClass: 'dc-notify',
        message: h('div', {class: 'dc-notify-container'}, [
          h('div', { class: 'clr_333 f15 mb10' }, [
            h('span', {  }, `您有一条报告被判定`),
            h('span', { class: `${detailInfo.DiagnosisConformity == 20 ? 'clr_orange' : 'o-error'}` }, `${detailInfo.DiagnosisConformity == 20 ? '基本符合' : '诊断不符'}`),
            h('span', {  }, `，是否立即查看？`)
          ]),
          h('div', { class: 'clr_333 mb5' }, [
            h('span', { class: 'dc-label' }, '患者姓名：'),
            h('span', { class: 'clr_orange' }, `${detailInfo.PatientName}`)
          ]),
          h('div', { class: 'clr_333 mb5' }, [
            h('span', { class: 'dc-label' }, '检查项目：'),
            h('span', { class: 'clr_orange' }, `${detailInfo.ExaminItemName}`)
          ]),
          h('div', { class: 'clr_333 row mb5' }, [
            h('div', { class: 'clr_333 row' }, [
              h('p', { class: 'dc-label' }, '检查号：'),
              h('p', { class: 'clr_orange', style: 'width: 110px' }, `${detailInfo.AccessionNumber}`)]),
            h('div', { class: 'clr_333 ml10 row' },[
              h('p', { style: 'width: 60px' }, '病理号：'),
              h('p', { class: 'clr_orange ellipsis', style: 'width: 100px' }, `${detailInfo.PathologyNo}`)
            ]),
          ]),
          h('div', { class: 'row clr_333 mb5' }, [
            h('p', { class: 'dc-label' }, '备注：'),
            h('p', { class: 'clr_orange ellipsis', style: 'width: 260px' }, `${desc}`)
          ]),
          h('div', { class: 'mt10 tr' }, [
            h('el-button', {
              attrs: {
                size: 'mini',
                type: 'primary'
              },
              on: {
                click: () => {
                  this.$nextTick(() => {
                    notify.close()
                  })
                  this.$router.push({
                    name: `${this.$routeType}DiagnoseRate`,
                    query: {
                      AccessionNumber: detailInfo.AccessionNumber,
                      from: 'notify',
                    }
                  })
                }
              }
            }, '立即查看')
          ])
        ]),
        position: 'bottom-right'
      })
    },
  }
}
</script>
<style lang="less" scoped>
.dialog-content{
  text-align: center;
  font-size:16px;
}
.urgent-dialog /deep/ .el-dialog__footer{
  text-align: center!important;
  border-top:none;
}
</style>
<style lang="less">
.report-notify{
  width: 420px !important;
  .el-notification__group {
    width: 100%;
  }
}
.dc-notify {
  width: 435px !important;
  .dc-notify-container {
    width: 365px;
  }
  .dc-label {
    display: inline-block;
    width: 85px;
    text-align: right;
  }
}
.confirm-dialog--ew.emergency-notice--dialog {
  background: #fff1f0;
  border-radius: 8px!important;;
  &.el-message-box {
    width: 888px;
  }
  .el-message-box__header {
    display: none;
  }
  .el-message-box__content {
    position: relative;
    padding: 80px 50px 30px;
  }
  .el-message-box__btns {
    padding: 5px 15px 30px;
    text-align: center;
  }
  .notice-content--end {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    color: #FF0000;
    font-size: 30px;
    line-height: 1.5;
    border: 3px dotted #FF0000;
    border-radius: 8px;
    padding: 60px 43px 45px;
  }
  .iconfont {
    color: #EF6000;
    font-size: 50px;
    line-height: 1;
    background: #fff1f0;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    top: -25px;
    padding: 0 30px;
  }
}
</style>
