<template>
  <div>
    <!-- 系统通知 -->
    <system-informs @operateVoice="operateVoice"/>
    <div v-if="reDom" class="hidden">
      <!-- 普通消息声音提醒 -->
      <iframe  v-if="playMsgVoice" allow="autoplay" :src="msgIframeSrc"></iframe>
      <!-- 视频消息声音提醒 -->
      <iframe  v-if="playVideoVoice" allow="autoplay" :src="videoIframeSrc"></iframe>
    </div>
  </div>
</template>
<script>
import systemInforms from '@/components/common/IM/Notice/systemInforms'
import msgVoice from '@/style/voice/msg_voice.mp3'
import videoVoice from '@/style/voice/video_voice.mp3'
export default {
  components: {
    systemInforms
  },
  data () {
    return {
      msgIframeSrc: '',
      videoIframeSrc: '',
      playMsgVoice: false,
      playVideoVoice: false,
      reDom: true
    }
  },
  mounted () {
  },
  methods: {
    operateVoice ({ type, state }) {
      this.reDom = false
      if (type === 'msgVoice') {
        this.playMsgVoice = state
        this.msgIframeSrc = ''
        if (state) {
          this.msgIframeSrc = msgVoice
          this.$nextTick(() => {
            this.reDom = true
          })
        }
      } else if (type === 'videoVoice') {
        this.playVideoVoice = state
        this.videoIframeSrc = ''
        if (state) {
          this.videoIframeSrc = videoVoice
          this.$nextTick(() => {
            this.reDom = true
          })
        }
      }
    }
  }
}
</script>
