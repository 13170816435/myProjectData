<template>
  <div
    class="window-im-wrapper"
    v-show="IMWindowVisible"
    data-html2canvas-ignore
    style="z-index: 99999;"
  >
    <div class="window-im">
      <div class="window-header">
        <div class="window-header-title">医网云-即时协作</div>
        <div class="window-header-btn-group">
          <div class="btn-close">
            <i class="el-icon-close" @click="closeWindow"></i>
          </div>
        </div>
      </div>
      <div class="window-body">
        <iframe id="iframe-im" :src="imUrl" frameborder="0"></iframe>
      </div>
    </div>
  </div>
</template>
<script>
import eventBus from '@/utils/eventBus'
import { IMMessengerMain } from 'tomtaw-im-messenger'
let msger = null
export default {
  props: {
    IMWindowVisible: {
      type: Boolean
    }
  },
  data () {
    return {
      imUrl: ''
    }
  },
  created () {
    this.imUrl =
      process.env.NODE_ENV === 'development'
        ? '/im/'
        : configUrl.frontEndUrl + '/im/'
  },
  mounted () {
    this.initIMMessager()
    this.initEventBus()
  },
  beforeDestroy() {
    this.destroyEventBus()
  },
  methods: {
    closeWindow () {
      this.$emit('update:IMWindowVisible', false)
      msger.toggleIMVisible(false)
    },
    // 初始化eventBus
    initEventBus () {
      eventBus.$on('startASRTask', this.startASRTask)
      eventBus.$on('stopASRTask', this.stopASRTask)
      eventBus.$on('sendASRData', this.sendASRData)
      eventBus.$on('sendCmdMsg', this.sendCmdMsg)
      eventBus.$on('sendTxtMsg', this.sendTxtMsg)
      eventBus.$on('closeWindow', this.closeWindow)
    },
    // 销毁eventBus
    destroyEventBus() {
      eventBus.$off('startASRTask', this.startASRTask)
      eventBus.$off('stopASRTask', this.stopASRTask)
      eventBus.$off('sendASRData', this.sendASRData)
      eventBus.$off('sendCmdMsg', this.sendCmdMsg)
      eventBus.$off('sendTxtMsg', this.sendTxtMsg)
      eventBus.$on('closeWindow', this.closeWindow)
    },
    // IMMessager
    initIMMessager () {
      msger = new IMMessengerMain({
        getASRStartAck: this.handleGetASRStartAck,
        getASRResult: this.handleGetASRResult,
        getCmdMsg: this.handleGetCMDMsg,
        getUnreadMsgAmount: this.handleGetUnreadMsgAmount,
        getWsStateMsg: this.handleGetWsStateMsg,
        getLinkBtnFunc: this.handleClickTemplateLinkBtn,
      })
      msger.addIMMessengerTarget('iframe-im')
    },
    handleClickTemplateLinkBtn (msg) {
      eventBus.$emit('handleClickTemplateLinkBtn', msg)
    },
    // 主窗口收到来自iframe的CMD类型的消息时的事件回调
    handleGetCMDMsg(msg) {
      console.log('收到新版iframe chat 的CMD类型消息:', msg)
      eventBus.$emit('iframeImGetCmdMsg', msg)
    },
    // 向iframe发送cmd消息
    sendCmdMsg (msg) {
      console.log('发CMD类型消息:', msg)
      msger.sendCmdMsg(msg)
    },
    toggleIMVisible () {
      msger.toggleIMVisible(true)
    },
    sendTxtMsg (msg) {
      console.log('发Txt类型消息:', msg)
      msger.sendTxtMsg(msg)
    },
    // 未读消息数量
    handleGetUnreadMsgAmount (num) {
      // 如果不是在壳 助理程序下 
      if (!window.iselectron) {
        this.$store.dispatch('bussinessCommon/setUnreadMsgNum', num)
      }
    },
    // 状态获取
    handleGetWsStateMsg (msg) {
      eventBus.$emit('handleGetWsStateMsg', msg)
    },
    // 通过点击页面中用户头像、名字等信息打开与该用户的聊天界面
    openIMChatWindow (msg) {
      msger.openIMChatWindow(msg)
    },
    // 生成随机id
    randomId() {
      return (((1 + Math.random()) * 0x10000) | 0).toString(16)
    },
    // 收到ASR Start ack时的回调
    handleGetASRStartAck(msg) {
      eventBus.$emit('handleGetASRStartAck', msg)
    },
    // 收到ASR Result时的回调
    handleGetASRResult(msg) {
      eventBus.$emit('handleGetASRResult', msg)
    },
    // 开始 ASR 任务
    startASRTask (msg) {
      msger.startASRTask(msg)
    },
    // 结束 ASR 任务
    stopASRTask (msg) {
      console.log(123)
      msger.stopASRTask(msg)
    },
    // 发送 ASR 语音数据
    sendASRData (msg) {
      msger.sendASRData(msg)
    }
  }
}
</script>
<style lang="less">
.window-im-wrapper {
  z-index: 1000;
}
.window-im {
  position: relative;
  width: 1140px;
  margin: 0 auto 50px;
  border-radius: 2px;
  margin-top: 6vh;
  background: #fff;
  &-wrapper {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    overflow: auto;
  }
  .window-header {
    height: 35px;
    line-height: 35px;
    padding: 0 10px;
    background: #366eb4;
    position: relative;
    &-title {
      font-size: 18px;
      color: #fff;
    }
    &-btn-group {
      position: absolute;
      color: #fff;
      right: 10px;
      top: 10px;
      line-height: 1;
      display: flex;
    }
    .btn-close {
      cursor: pointer;
    }
  }
}
#iframe-im {
  width: 1140px;
  height: 730px;
}
</style>
