<template>
   <div class="chooseAudienceCon">
       <div class="choosedTenancyDiv" v-if="choosedTenancyArr.length != 0 && role =='plateform'">
          <div class="headDiv">
             <span class="headIcon fl"></span>
             <span class="headTit">已选受众客户</span>
          </div>
          <div class="choosedTenancyList">
              <span class="oneTenancy" v-for="(item,index) in choosedTenancyArr" :key="item.id">
                {{item.name}}
                <i class="iconfont" @click="removeTenancy(item)">&#xe65d;</i>
              </span>
          </div>
       </div>
       <div class="tenancyQuery mt10" v-if="role =='plateform'">
        <span class="search-bar-label fl">客户名称：</span>
        <el-select
            @change="changeTenancy"
            multiple
            collapse-tags
            filterable
            v-model="getInstitutionsParams.tenancy_ids"
            placeholder="全部"
            class="ele-select_32 width_260_select"
            style="width:260px"
        >
        <el-option value="">全部</el-option>
          <el-option
          v-for="(item,index) in tenancyList"
          :key="item.id"
          :label="item.name"
          :value="item.id"
          ></el-option>
        </el-select>
        <span class="chooseTip" v-if="choosedTenancyArr.length != 0">注：下拉筛选的客户会将“已选受众客户”过滤掉</span>
      </div>
      <div class="chooseAudienceContent">
         <div class="chooseTanency chooseItemContent fl">
           <div class="chooseHead">
               <span class="fl icon"></span>
               <span class="fl headText">选择受众机构</span>
               <el-checkbox class="fr"v-model="checkAllInstitute" @change="handleCheckAllInstitute">全选</el-checkbox>
           </div>
           <div class="chooseList">
               <div class="searchDiv">
                   <el-input class="fl width_312_input" v-on:keyup.enter.native=searchInstitute v-model="getInstitutionsParams.contains_name"  placeholder="请输入机构名称"></el-input>
                   <i class="iconfont searchIcon" @click="getInstitutionList">&#xe652;</i>
               </div>
               <div class="chooseListContent">
                   <el-checkbox-group v-model="institutionIds" @change="changeInstitutionList">
                    <div class="chooseItem" v-for="(item,index) in institutionList" :key="item.id">
                        <el-checkbox :label="item.id">
                            <span class="chooseName" v-bind:title="item.name">{{item.name}}</span>
                        </el-checkbox>
                    </div>
                   </el-checkbox-group>
               </div>
           </div>
         </div>
         <div class="chooseTanency chooseItemContent fl">
           <div class="chooseHead">
               <span class="fl icon"></span>
               <span class="fl headText">选择受众系统</span>
               <el-checkbox class="fr" v-model="checkAllSystem" @change="handleCheckAllSystem">全选</el-checkbox>
           </div>
           <div class="chooseList">
               <div class="searchDiv">
                   <el-input class="fl width_312_input" v-on:keyup.enter.native=searchSystem v-model="getSystemParams.contains_name"  placeholder="请输入系统名称"></el-input>
                   <i class="iconfont searchIcon">&#xe652;</i>
               </div>
               <div class="chooseListContent">
                   <el-checkbox-group v-model="systemIds">
                    <div class="chooseItem" v-for="(item,index) in systemList" :key="item.id">
                        <el-checkbox :label="item.id">
                            <span class="chooseName" v-bind:title="item.name">{{item.name}}</span>
                        </el-checkbox>
                    </div>
                   </el-checkbox-group>
               </div>
           </div>
         </div>
      </div>
      <div class="dialog_footer">
            <el-button size="small" plain @click="cancelChooseAudience">取消</el-button>
            <el-button type="primary" size="small" @click="sureChooseAudience">确定</el-button>
        </div>
   </div>
</template>
<script>
import Mgr from '@/utils/SecurityService'
import { getTenanciesLiteFn, getInstitutionsFn, getSystemFn } from '@/api/platform_operate/messageRelease'
// import { UnshiftToArray } from '@/components/commonJs'
export default {
  props: {
    choosedTenancyArr: Array,
    choosedSystemArr: Array,
    choosedInstitutionArr: Array,
    getInstituteTenacyIds: Array,
    recipients:Array
  },
  computed:{
		// 如果是静态，就不需要通过计算属性
		// 直接调用this.test即可
		newUpdate() {
			return this.isUpdate()
		},
	},
  data () {
    return {
      checkAllInstitute: false,
      checkAllSystem: false,
      tenancyList: [], // 客户列表
      institutionList: [], //机构列表
      systemList: [], // 系统列表
      institutionIds: [], // 选中了的机构id
      systemIds: [],
      allInstitutionArr: [],
      allsystemArr: [],
      checkedTenancyIdArr: [], // 选择了所有的客户id
      checkedAllInstituteId: [], // 选择了所有的机构id
      checkedAllSytemId: [], // 选择了所有的系统id
      getTenancyParams: {
        contains_name: ''
      },
      getInstitutionsParams: {
        contains_name: '',
        tenancy_ids: []   
      },
      getSystemParams: {
        contains_name: '',
        tenancy_ids: []   
      }
    }
  },
  inject: ['role','isUpdate'],
  methods: {
    // 查询机构
    searchInstitute () {
      const self = this
      self.institutionList = []
      self.allInstitutionArr.forEach((val) => {
        if (val.name.indexOf(self.getInstitutionsParams.contains_name) != -1) {
          self.institutionList.push(val)
        }
      })
    },
    // 查询系统
    searchSystem () {
      const self = this
      self.systemList = []
      self.allsystemArr.forEach((val) => {
        if (val.name.indexOf(self.getSystemParams.contains_name) != -1) {
          self.systemList.push(val)
        }
      })
    },
    cancelChooseAudience () {
      this.$emit('cancelChooseAudience')
    },
    // 移除客户
    removeTenancy (item) {
      this.$emit('removeTenancy', item.id)
      // 移除所选客户后 下拉列表里面就可以选择该客户了
      this.tenancyList.unshift(item)
    },
    // 确定选择这些受众
    sureChooseAudience () {
      const self = this
      let choosedSystemArr = []
      if (self.systemList.length != 0 && self.systemIds.length !== 0) {
        self.systemList.forEach((item) => {
           if (self.systemIds.indexOf(item.id) !== -1) {
              choosedSystemArr.push(item)
           }
        })
      }
      let choosedInstitutionArr  = []
      if (self.institutionList.length != 0 && self.institutionIds.length !== 0) {
        self.institutionList.forEach((item) => {
           if (self.institutionIds.indexOf(item.id) !== -1) {
              choosedInstitutionArr.push(item)
           }
        })
      }
      if (this.getInstitutionsParams.tenancy_ids.length === 0) {
        if (this.institutionIds.length == 0 &&  choosedSystemArr.length == 0) {
          this.$message({ message: '请选择受众', type: 'error' })
          return
        }
      }
      self.$emit('sureChooseAudience',choosedInstitutionArr,choosedSystemArr, this.getInstitutionsParams.tenancy_ids)
    },
    // 选择所有机构
    handleCheckAllInstitute (val) {
      this.institutionIds = val ? this.checkedAllInstituteId : []
    },
    // 选择所有系统
    handleCheckAllSystem () {
      this.systemIds = val ? this.checkedAllSytemId : []
    },
    // 改变客户时
    changeTenancy () {
      if (this.getInstitutionsParams.tenancy_ids.length != 0) {
        this.getSystemParams.tenancy_ids = []
        this.getInstitutionsParams.tenancy_ids.forEach((val) => {
          this.getSystemParams.tenancy_ids.push(val)
        })
        // 获取机构
        this.getInstitutionList()
        // 获取系统
        this.getSystmList()  
      } else {
        this.institutionList = []
        this.systemList = []
      }
    },
    // 获取租户列表
    async getCustomerLiteFn () {
      const self = this
      self.tenancyList = []
      const res = await getTenanciesLiteFn(self.getTenancyParams)
      if (res.code === 0) {
        if (res.data.length !== 0) {
          self.checkedTenancyIdArr = self.choosedTenancyArr.map(function(val) {
             return val.id
          })
          res.data.forEach((item) => {
            if (self.checkedTenancyIdArr.indexOf(item.id) == -1 ) {
              self.tenancyList.push(item)
            }
          })
        }
       
      //  if (self.newUpdate && self.recipients.length !== 0) {
      //    self.recipients.forEach((one) => {
      //     if (one.recipient_type === 1) { // 选择了客户
      //       self.getInstitutionsParams.tenancy_ids.push(one.recipient_id)
      //       self.getSystemParams.tenancy_ids.push(one.recipient_id)
      //     }
      //   })
      //  }

      } else {
        self.$message.error(res.msg)
      }
    },
    // 获取机构
    async getInstitutionList () {
      const self = this
      self.institutionList = []
      self.allInstitutionArr = []
      const res = await getInstitutionsFn(self.getInstitutionsParams)
      if (res.code === 0) {
        if (res.data.length != 0) {
          res.data.forEach((val) => {
            self.institutionList.push(val)
            self.allInstitutionArr.push(val)
          })
        }
        if (self.institutionList.length !== 0) {
          self.checkedAllInstituteId = self.institutionList.map(function(val) {
             return val.id
          })
        }
        if (self.institutionIds.length === self.institutionList.length && self.institutionList.length !== 0) {
          self.checkAllInstitute = true
        }
      } else {
        self.$message.error(res.msg)
      }
    },
    // 获取系统列表
    async getSystmList () {
      const self = this
      self.systemList = []
      self.allsystemArr = []
      const res = await getSystemFn(self.getSystemParams)
      if (res.code === 0) {
        if (res.data.length != 0) {
          res.data.forEach((val) => {
            self.systemList.push(val)
            self.allsystemArr.push(val)
          })
        }
        if (self.systemList.length !== 0) {
          self.checkedAllSytemId = self.systemList.map(function(val) {
            return val.id
          })
        }
        if (self.systemIds.length === self.systemList.length &&  self.systemList.length !== 0) {
          self.checkAllSystem = true
        }
      } else {
        self.$message.error(res.msg)
      }
    },
    // 改变机构
    changeInstitutionList () {

    },
    dealCommonTenancyId (tenancyIds) {
      const self = this
      // 所选的客户id 去重
      let newTenancyIds = []
      if (tenancyIds.length != 0) {
        tenancyIds.forEach((val) => {
          if(val && newTenancyIds.indexOf(val) == -1) {
            newTenancyIds.push(val)
          }
        })
      }
      if (newTenancyIds.length != 0) {
        newTenancyIds.forEach((val) => {
          self.getInstitutionsParams.tenancy_ids.push(val)
          self.getSystemParams.tenancy_ids.push(val)
        })
      }
    }
  },
  created () {
    if (this.role == 'plateform') {
      this.getCustomerLiteFn()
    }
  },
  mounted () {
    const self = this
    if (self.role == 'customer') { // 如果是客户管理下的 新增公告和通知
      var manager = new Mgr()
      manager.getRole().then(function (logindata) {
        self.getInstitutionsParams.tenancy_ids = []
        const tenancy_id = sessionStorage.getItem('curTenancyId') || logindata.profile.tenancy_id
        self.getInstitutionsParams.tenancy_ids.push(tenancy_id)
        self.changeTenancy()
      })
    } else {
      self.getInstitutionsParams.tenancy_ids = []
      self.getSystemParams.tenancy_ids = []
      self.institutionIds = []
      self.systemIds = []
      let tenancyIds = [] // 回显 选择客户下拉列表用的
      if (self.choosedSystemArr.length != 0) {
        self.choosedSystemArr.forEach((one) => {
          self.systemIds.push(one.id)
          if (one.tenancy_id && one.tenancy_id != "0") {
            tenancyIds.push(one.tenancy_id)
          }
        })
      }
      if (self.choosedInstitutionArr.length != 0) {
        self.choosedInstitutionArr.forEach((one) => {
          self.institutionIds.push(one.id)
          if (one.tenancy_id && one.tenancy_id != "0") {
            tenancyIds.push(one.tenancy_id)
          }
        })
      }
      if (self.getInstituteTenacyIds.length != 0) {
        self.getInstituteTenacyIds.forEach((one) => {
          tenancyIds.push(one.tenancy_id)
        })
      }
      
      self.dealCommonTenancyId(tenancyIds)
      // 如果有选择受众是客户 得去请求机构和系统
      if (self.getInstitutionsParams.tenancy_ids.length != 0) {
         self.changeTenancy()
      }

    }
    // 如果是新增得清空之前选择的受众id
    // if (!self.newUpdate) {
    //   self.getInstitutionsParams.tenancy_ids = []
    //   self.getSystemParams.tenancy_ids = []
    //   self.institutionIds = []
    //   self.systemIds = []
    // }
    // 编辑的时候回显已选的受众
    //console.log(self.newUpdate)
    // if (self.newUpdate && self.recipients.length !== 0) {
    //   self.getInstitutionsParams.tenancy_ids = []
    //   self.getSystemParams.tenancy_ids = []
    //   self.institutionIds = []
    //   self.systemIds = []
    //   let tenancyIds = [] // 回显 选择客户下拉列表用的
    //   self.recipients.forEach((one) => {
    //     if (one.recipient_type === 1) { // 选择了客户
    //       // self.getInstitutionsParams.tenancy_ids.push(one.recipient_id)
    //       // self.getSystemParams.tenancy_ids.push(one.recipient_id)
    //     }
    //     else if (one.recipient_type === 2) { // 选择了机构
    //       self.institutionIds.push(one.recipient_id)
    //       if (one.tenancy_id != "0") {
    //         tenancyIds.push(one.tenancy_id)
    //       }
          
    //     } else {
    //       self.systemIds.push(one.recipient_id)
    //       if (one.tenancy_id != "0") {
    //         tenancyIds.push(one.tenancy_id)
    //       }
    //     }
    //   })
    //   self.dealCommonTenancyId(tenancyIds)
    //   // 如果有选择受众是客户 得去请求机构和系统
    //   if (self.choosedTenancyArr.length != 0) {
    //      self.changeTenancy()
    //   }
    // }
  },
}
</script>
<style lang="less" scoped>
.chooseAudienceCon{
  .choosedTenancyDiv{
    padding-left:20px;
    .headDiv{
      height:40px;
      line-height: 40px;
      .headIcon{
        width: 3px;
        height: 14px;
        background: #0a70b0;
        border-radius: 2px;
        margin-top:13px;
        margin-right:8px;
      }
      .headTit{
        font-size:15px;
        color:#303133;
      }
    }
    .choosedTenancyList{
       width:670px;
       height:90px;
       border: 1px solid #dcdfe6;
       border-radius: 2px;
       padding: 10px;
       padding-top: 5px;
       overflow-y: auto;
    }
      .oneTenancy{
        display: inline-block;
        height: 24px;
        line-height: 22px;
        background: #f4f4f5;
        border: 1px solid #e9e9eb;
        padding: 0 5px;
        margin-right:5px;
        margin-bottom: 5px;
        i{
          color:#F56C6C;
          margin-left:5px;
          cursor: pointer;
        }
      }
  }
  .search-bar-label{
    font-size:14px;
    line-height: 32px;
    padding-left:20px;
  }
  .chooseTip{
    font-size:14px;
    color:#FF9900;
    padding-left:5px;
    line-height: 32px;
  }
  .chooseAudienceContent{
    border: 1px solid #dcdfe6;
    border-radius: 2px;
    margin: 20px;
    margin-top:10px;
    margin-bottom: 15px;
  }
  .chooseItemContent{
    width:334px;
    border-right: 1px solid #dcdfe6;
    height: 446px;
  }
  .chooseItemContent:last-of-type{
    border-right:none;
  }
  .chooseHead:last-of-type{
    border-right:none;  
  }
  ::v-deep .chooseHead{
    height:40px;
    line-height: 40px;
    background: #f5f7fa;
    border-bottom: 1px solid #dcdfe6;
    padding:0 12px;
    .icon{
       width: 3px;
       height: 16px;
       margin-top:12px;
       background: #0a70b0;
       border-radius: 2px;
       margin-right:8px;
    }
    .headText{
       font-weight: 700;
       color:#303133;
       font-size:15px;
    }
    .el-checkbox__inner{
       width:16px;
       height:16px;
       position: relative;
       top: -2px;
    }
    .el-checkbox__inner::after{
       left: 5px;
       top: 2px;  
    }
    .el-checkbox__label{
      font-size:15px;
      color:#303133;
      padding-left:5px;
    }
  }

  .chooseList{
    // padding-left:10px;
    // padding-top:10px;
    padding:10px 10px 0px 10px;
    height:calc(100% - 40px);
    .searchDiv{
      position: relative;
      height:32px;
      .width_312_input{
        width:312px;
      }
      .searchIcon {
        position: absolute;
        right:15px;
        top:8px;
        cursor: pointer;
      }
    }
    .chooseListContent{
      height:calc(100% - 32px);
      overflow: auto;  
    }
    ::v-deep .chooseItem{
      line-height: 40px;
      width:100%;
      float: left;
      .el-checkbox{
        width:100%;
        display: flex;
        height: 40px;
        align-items: center;
        color:#303133;
      }
      .el-checkbox__inner{
       width:16px;
       height:16px;
       position: relative;
       top: -1px;
      }
      .chooseName{
        font-size:15px;
        // color:#303133;
        margin-left:5px;
        cursor: pointer;
        display: inline-block;
        width: calc(100% - 22px);
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      .el-checkbox__inner::after{
        left: 5px;
        top: 2px; 
      }
      .el-checkbox__label{
        width:calc(100% - 16px);
        // color:#303133;
        font-size:15px;
      }
    }
  }
}
.chooseAudienceContent::after{
  content: '';
  /*建议加个height:0*/
  height: 0;
  display: block;
  clear: both;
  visibility: hidden;     
}
</style>