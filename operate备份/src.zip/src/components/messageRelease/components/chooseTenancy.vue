<template>
  <div class="chooseTenancyDiv">
     <div class="tenancyQuery">
        <span class="searchLabel">客户名称：</span><el-input class="width_250_input ml4"  v-model="getTenancyParam.keywords" placeholder="关键字"></el-input>
        <el-button class="searchBtn ml10" type="primary" size="small" @click="searchTenancy">查询</el-button>
        <el-button size="small" plain @click="resetSearchDataFn">重置</el-button>
     </div>
     <div class="tenancyTableDiv" v-bind:class="{'noTableData':tenancyList.length==0}">
         <el-table
          ref="tableList"
          border
          :data="tenancyList"
          :height="tableHeight"
          :header-cell-style="{background: '#f5f5f5',color: '#1E1D22'}"
          tooltip-effect="dark"
          style="width: 100%;max-height: 442px"
          :row-key="getRowKeys"
          @select="handleSelectionChange"
          @select-all="handleSelectionChange"
          >
          <el-table-column type="selection" width="55" fixed="left" :reserve-selection="true"></el-table-column>
          <el-table-column type="index" fixed="left" label="序号" width="50">
            <!-- <template slot-scope="scope">
              <span>{{(getTenancyParam.offset - 1) * getTenancyParam.limit + scope.$index + 1}}</span>
            </template> -->
          </el-table-column>
          <common-table :propData="tenancyPropData"></common-table>
        </el-table>
      </div>
      <!-- <div class="blockPage">
         <pagination-tool :total="totalTenancy" :page.sync="getTenancyParam.offset" :limit.sync="getTenancyParam.limit" @pagination="getTenancyListFn"/>
      </div> -->
     
    <div class="dialog_footer">
        <el-button size="small" plain @click="cancelChooseTenancy">取消</el-button>
        <el-button type="primary" size="small" @click="sureChooseTenancy">确定</el-button>
     </div>

  </div>
</template>
<script>
import { getTenanciesLiteFn } from '@/api/platform_operate/messageRelease'
import CommonTable from './CommonTable'
import PaginationTool from '@/components/common/PaginationTool'
export default {
  components: {
    CommonTable,
    PaginationTool 
  },
  props: {
    hasChoosedTenancyArr: Array
  },
  data () {
    return {
      tenancyList: [],
      allTenancyArr: [],
      choosedTenancyArr: [], // 选择了的客户
      tableHeight: '100%',
      totalTenancy: 0,
      getTenancyParam: {
        keywords: '',
        offset: 1,
        limit: 20  
      },
      tenancyPropData: [
        { prop: 'name', label: '客户姓名', width: 250 },
        { prop: 'type_desc', label: '客户类型' },
      ]
    }
  },
  methods: {
    resetSearchDataFn () {
      this.getTenancyParam = {
        offset: 1,
        limit: 20  
      }
      this.getTenancyListFn()  
    },
    // 查询客户
    searchTenancy () {
      const self = this
      self.tenancyList = []
      self.allTenancyArr.forEach((val) => {
        if (val.name.indexOf(self.getTenancyParam.keywords) != -1) {
          self.tenancyList.push(val)
        }
      })
    },
    // 确认选择了的客户
    sureChooseTenancy () {
      this.$emit('sureChooseTenancy',this.choosedTenancyArr)  
    },
    // 取消选择客户
    cancelChooseTenancy () {
      this.$emit('cancelChooseTenancy')
    },
    getRowKeys (row) {
      return row.id
    },
    handleSelectionChange (val) {
      this.choosedTenancyArr = val
    },
    // 获取客户列表
    async getTenancyListFn () {
      const self = this
      self.allTenancyArr = []
      const res = await getTenanciesLiteFn (self.getTenancyParam)
      if (res.code === 0) {
        self.tenancyList = res.data
        if (res.data.length > 0) {
          res.data.forEach((val) => {
            self.allTenancyArr.push(val)
          })
        }
        if (res.page) {
          self.totalTenancy = res.page.total_count
        }
        // 
        let ids  = []
        if (self.hasChoosedTenancyArr.length !== 0) {
          self.hasChoosedTenancyArr.forEach((val) => {
            ids.push(val.id)
          })
        }
        if (ids.length == 0) {
          self.$refs.tableList.clearSelection()
        } else {
          self.$nextTick(() => {
            self.tenancyList.forEach((item) => {
              if (ids.indexOf(item.id) !== -1) {
                self.$refs.tableList.toggleRowSelection(item, true) 
               } else {
                self.$refs.tableList.toggleRowSelection(item, false)
               }
            })
          })
        }
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      }
    },
  },
  mounted () {
    this.getTenancyListFn()
  }
}
</script>
<style lang="less" scoped>
.chooseTenancyDiv{
  .tenancyQuery{
    padding: 10px 20px;
    .searchLabel{
      color:#303133;
    }
  }
  .width_250_input{
    width:250px;
  }
  ::v-deep .tenancyTableDiv{
    height:411px;
    padding: 15px;
    padding-bottom: 10px;
    padding-top: 0px;
    .el-table__body-wrapper{
      height:calc(100% - 40px);
      overflow:auto;
    }
    .el-table__fixed-body-wrapper{
      height: calc(100% - 40px)!important;
    }
  }
  .dialog_footer{
    padding-right:15px;
  }
}
</style>