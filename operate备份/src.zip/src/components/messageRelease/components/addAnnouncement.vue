<template>
  <div class="addAnnouncementCon">
     <div class="addAnnouncementItem flex_row" v-if="role == 'plateform'">
          <span class="addAnnouncementItemLabel"><i class="iconfont iconbitian mustIcon"></i>受众客户：</span>
            <div class="useNameTextarea">
               <div class="chooseTip" v-if="choosedTenancyArr.length == 0">请点击右侧按钮进行选择</div>
               <div class="choosedTenancyList" v-else>
                  <span class="oneTenancy" v-for="(item,index) in choosedTenancyArr" :key="item.id">
                    {{item.name}}
                    <i class="iconfont" @click="removeTenancy(item.id)">&#xe65d;</i>
                  </span>
               </div>
            </div>
         <div @click="chooseTenancy" class="chooseMemeber ml10">选择客户</div>
     </div>
     <div class="addAnnouncementItem flex_row">
          <span class="addAnnouncementItemLabel">
            <span v-if="role == 'customer'">公告受众：</span>
          </span>
            <div class="useNameTextarea">
               <div class="chooseTip" v-if="choosedInstitutionArr.length == 0 && choosedSystemArr.length == 0">
                  <span v-if="role == 'customer'">请点击右侧按钮进行选择，若未选择，则默认发给整个客户</span>
                  <span v-else>请点击右侧按钮进行选择</span>
                </div>
               <div class="choosedInstitute" v-if="choosedInstitutionArr.length != 0">
                  <span class="oneTenancy" v-for="(item,index) in choosedInstitutionArr" :key="item.id">
                    {{item.name}}
                    <i class="iconfont" @click="removeInstitute(item.id)">&#xe65d;</i>
                  </span>
               </div>
               <div class="choosedSystem" v-if="choosedSystemArr.length != 0">
                  <span class="oneTenancy" v-for="(item,index) in choosedSystemArr" :key="item.id">
                    {{item.name}}
                    <i class="iconfont" @click="removeSystem(item.id)">&#xe65d;</i>
                  </span>
               </div>
            </div>
         <div @click="chooseAudience" class="chooseMemeber ml10">选择机构系统</div>
     </div>
     <div class="addAnnouncementItem flex_row">
         <span class="addAnnouncementItemLabel"><i class="iconfont iconbitian mustIcon"></i>公告时间：</span>
         <el-date-picker
            v-model="addAnnounceParam.start_time"
            type="datetime"
            class="datetime"
            value-format="yyyy-MM-dd HH:mm:ss"
            placeholder="开始时间">
         </el-date-picker>
         <el-radio-group class="ml10" v-model="timeTypeObj.end_time"  @change="noEndTimeFn">
              <el-radio :label=1>
                <el-date-picker
                   class="datetime"
                   :disabled="timeTypeObj.end_time===1?false:true"
                    v-model="addAnnounceParam.end_time"
                    type="datetime"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    placeholder="结束时间">
                </el-date-picker>
              </el-radio>
              <el-radio class="lh40" :label=2>无限期</el-radio>
         </el-radio-group>
     </div>
      <div class="addAnnouncementItem flex_row">
         <span class="addAnnouncementItemLabel"><i class="iconfont iconbitian mustIcon"></i>公告标题：</span>
         <el-input
            class="titleTextarea"
            type="textarea"
            placeholder="请输入公告标题"
            v-model="addAnnounceParam.title"
            maxlength="50"
            :resize="'none'"
            show-word-limit
            >
            </el-input>
     </div>
     <div class="addAnnouncementItem flex_row">
         <span class="addAnnouncementItemLabel"><i class="iconfont iconbitian mustIcon"></i>公告内容：</span>
         <quill-editor  v-model="addAnnounceParam.content" ref="text" @change="onEditorChange($event)" class="myQuillEditor" :options="editorOption"  style="min-height: 400px;max-height:530px;overflow-y:auto;"></quill-editor>
         <form action="" method="post" enctype="multipart/form-data" id="uploadFormMulti">
          <input style="display: none" :id="uniqueId" type="file" name="files" multiple accept="image/jpg,image/jpeg,image/png,image/gif" @change="uploadEditImg('uploadFormMulti')">
          </form>
         <span class="wordNumber">{{TiLength}}/1000</span>
     </div>
    <el-dialog title="选择受众机构或系统" :top="'5vh'" :visible.sync="showChooseAudienceAlert"  :width="'710px'" :close-on-click-modal="false" append-to-body v-dialogDrag>
        <chooseAudience ref="chooseAudience" :choosedTenancyArr="choosedTenancyArr" :getInstituteTenacyIds="getInstituteTenacyIds" @removeTenancy="removeTenancy" :key="chooseAudienceKey" :recipients="addAnnounceParam.recipients" :choosedSystemArr="choosedSystemArr" :choosedInstitutionArr="choosedInstitutionArr"  @sureChooseAudience="sureChooseAudience" @cancelChooseAudience="cancelChooseAudience"></chooseAudience>
    </el-dialog>
    <el-dialog title="选择客户" :top="'5vh'" :visible.sync="showChooseTenancyAlert"  :width="'500px'" :close-on-click-modal="false" append-to-body v-dialogDrag>
        <chooseTenancy ref="chooseTenancy" :key="chooseTenancyKey" :hasChoosedTenancyArr="choosedTenancyArr"  @sureChooseTenancy="sureChooseTenancy" @cancelChooseTenancy="cancelChooseTenancy"></chooseTenancy>
    </el-dialog>
  </div>
</template>
<script>
import { quillEditor } from 'vue-quill-editor'
import Quill from "quill";
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
import chooseAudience from './chooseAudience'
import chooseTenancy from './chooseTenancy'
import { uploadMediaFile } from "@/api/commonHttp";
import { connectUrlParam } from "@/components/commonJs";
const toolbarOptions = [
  ['bold', 'italic', 'underline'], // 加粗 斜体 下划线 删除线
  ['blockquote', 'code-block'], // 引用  代码块
  [{ color: [] }, { background: [] }], // 字体颜色、字体背景颜色
  [{ indent: '-1' }, { indent: '+1' }], // 缩进
  [{ align: [] }], // 对齐方式
  [{ header: 1 }, { header: 2 }], // 1、2 级标题
  //[{ list: 'ordered' }, { list: 'bullet' }], // 有序、无序列表
  //[{ script: 'sub' }, { script: 'super' }], // 上标/下标
  ['link', 'image'], // 链接、图片、视频
  //['clean'] // 清除文本格式
]
export default {
   props: {
     addAnnounceParam: Object,
     timeTypeObj: Object,
     isUpdate: Boolean
   },
   inject: ['role'],
   components: {
    quillEditor,
    chooseAudience,
    chooseTenancy
   },
   data () {
     return {
       editorOption: {
        placeholder: '请在这里输入',
        modules: {
          toolbar: toolbarOptions,
          clipboard: {
            // 粘贴过滤
            matchers: [[Node.ELEMENT_NODE, this.HandleCustomMatcher]],
          },
        },
      },
      chooseTenancyKey: 1,
      choosedTenancyArr: [],
      choosedInstitutionArr: [],
      choosedSystemArr: [],
      getInstituteTenacyIds: [],
      showChooseTenancyAlert: false,
      showChooseAudienceAlert: false,
      AudienceOperate: '选择受众',
      chooseAudienceKey: 0,
      TiLength: 0,
      addImgRange: "",
      uniqueId: "testUpload",
     }
   },
   methods: {
    HandleCustomMatcher(node, Delta) {
      // 文字，从别处复制而来，清除自带样式，转为纯文本
      if (node.src && node.src.indexOf("data:image/png") > -1) {
        Delta.ops = [];
        return Delta;
      }
      let ops = [];
      Delta.ops.forEach((op) => {
        if (op.insert && typeof op.insert === "string") {
          ops.push({
            insert: op.insert,
          });
        } else if (op.insert && typeof op.insert.image === "string") {
          ops.push({
            insert: op.insert,
          });
        }
      });
      Delta.ops = ops;
      return Delta;
    },
    noEndTimeFn (val) {
      this.$emit('noEndTimeFn', val, this.timeTypeObj)
    },
    onEditorChange (e) {
      e.quill.deleteText(1000, 4) // 从第500个开始删除，删除4个
      if (this.$refs.text.value === '') {
        this.TiLength = 0
      } else {
        this.TiLength = e.quill.getLength() - 1
      }
    },
    // 移除客户
    removeTenancy (id) {
      const self = this
      self.choosedTenancyArr.forEach((item, i) => {
        if (item.id == id) {
          self.choosedTenancyArr.splice(i,1)
        }
      })
      let ids  = []
      if (self.choosedTenancyArr.length !== 0) {
        self.choosedTenancyArr.forEach((val) => {
          ids.push(val.id)
        })
      }
      self.$emit('removeAudience', id)
      self.$nextTick(() => {
        self.$refs.chooseTenancy.tenancyList.forEach((item) => {
          if (ids.indexOf(item.id) !== -1) {
            self.$refs.chooseTenancy.$refs.tableList.toggleRowSelection(item, true) 
          } else {
            self.$refs.chooseTenancy.$refs.tableList.toggleRowSelection(item, false)
          }
        })
      })
    },
    // 移除机构或系统
    removeInstitute (id) {
      const self = this
      self.choosedInstitutionArr.forEach((item,i) => {
         if (item.id == id) {
          self.choosedInstitutionArr.splice(i,1)
        }
      })
      self.$emit('removeAudience', id)
      
    },
    // 移除系统 
    removeSystem (id) {
      const self = this
      self.choosedSystemArr.forEach((item, i) => {
         if (item.id == id) {
          self.choosedSystemArr.splice(i,1)
        }
      })
      self.$emit('removeAudience', id)
    },
    // 选择客户
     chooseTenancy () {
       this.showChooseTenancyAlert = true
       this.chooseTenancyKey++
     },
     // 确认选择客户
     sureChooseTenancy (arr) {
       this.showChooseTenancyAlert = false
       this.choosedTenancyArr = []
       if (arr && arr.length != 0) {
         arr.forEach((val) => {
           this.choosedTenancyArr.push(val)
         })
       }
       this.$emit('sureChooseAudience',this.choosedTenancyArr,this.choosedInstitutionArr,this.choosedSystemArr)
     },
     // 取消选择客户
     cancelChooseTenancy () {
       this.showChooseTenancyAlert = false
     },
     chooseAudience () {
       this.showChooseAudienceAlert = true
       //if (this.AudienceOperate == '选择受众') {
         this.chooseAudienceKey++
      // }
     },
     // 取消受众
     cancelChooseAudience () {
       this.showChooseAudienceAlert = false
     },
     // 确定选择这些受众
     sureChooseAudience (choosedInstitutionArr,choosedSystemArr,getInstituteTenacyIds) {
       this.showChooseAudienceAlert = false
       this.AudienceOperate  = "查看受众"
       this.choosedInstitutionArr = choosedInstitutionArr
       this.choosedSystemArr = choosedSystemArr
       this.getInstituteTenacyIds = getInstituteTenacyIds
       this.$emit('sureChooseAudience',this.choosedTenancyArr,choosedInstitutionArr,choosedSystemArr)
     },
     // 处理编辑时 回显 勾选中的客户
     checkedChooedTenancy () {
        const self = this
        let ids  = []
        if (self.choosedTenancyArr.length !== 0) {
          self.choosedTenancyArr.forEach((val) => {
            ids.push(val.id)
          })
        }
        self.$nextTick(() => {
          self.$refs.chooseTenancy.tenancyList.forEach((item) => {
            if (ids.indexOf(item.id) !== -1) {
              self.$refs.chooseTenancy.$refs.tableList.toggleRowSelection(item, true) 
            } else {
              self.$refs.chooseTenancy.$refs.tableList.toggleRowSelection(item, false)
            }
          })
        })
     },
    async uploadEditImg(id) {
      var vm = this;
      var obj = document.getElementById("uploadFormMulti");
      // 获取文件对象
      var fileObj = document.getElementById(vm.uniqueId);
      var file = fileObj.files[0]; 
      var fileName = file.name
      var fileSize = file.size
      var formData = new FormData(obj);
      formData.append('file_name',fileName)
      try {
        vm.uploadImgReq(formData,fileName,fileSize); // 自定义的图片上传函数
      } catch ({ message: msg }) {
        document.getElementById(vm.uniqueId).value = "";
        vm.$message.warning(msg);
      }
    },
    // 下载图片
    downloadImg(file_id) {
      const vm = this
      var src = configUrl.docUrl +"/api-document/download/document-id?document_id=" +file_id + "&is_crm_document=true"
      vm.addImgRange = vm.$refs.text.quill.getSelection();
      vm.$refs.text.quill.insertEmbed(
        vm.addImgRange != null ? vm.addImgRange.index : 0, 
        "image",
        src,
        Quill.sources.USER
      );
    },
    async uploadImgReq(myformData,file_name,file_size) {
       // 这里实现你自己的图片上传
      var vm = this;
       let param = {
        file_name: file_name,
        file_size: file_size,
        position: 0,
        file_type: 0,
      };
      let paramUrl = connectUrlParam(param);
      const res = await uploadMediaFile(myformData,paramUrl);
      if (res.code === 0) {
        const result = res;
        // 获取图片
        vm.downloadImg(result.document_id)
      }
    },
   },
   destroyed () {
    this.choosedTenancyArr = []
    this.choosedInstitutionArr = []
    this.choosedSystemArr = []
   },
   mounted () {
     const self = this
     if (self.isUpdate) {
       self.AudienceOperate  = "查看受众"
       // 处理编辑时 回显总共输入了多少个字数
       self.TiLength = self.$refs.text.quill.getLength() - 1
       self.choosedTenancyArr = []
       self.choosedInstitutionArr = []
       self.choosedSystemArr = []
       //console.log(self.addAnnounceParam)
       if (self.addAnnounceParam && self.addAnnounceParam.recipients.length != 0) {
        self.addAnnounceParam.recipients.forEach((val) => {
          let obj = {
            name: val.recipient_name,
            id: val.recipient_id,
            tenancy_id: val.tenancy_id,
            type: val.recipient_type
          }
         if (val.recipient_type === 1) {
           self.choosedTenancyArr.push(obj)
         }
         else if (val.recipient_type === 2) {
           self.choosedInstitutionArr.push(obj)
         }
         else{
           self.choosedSystemArr.push(obj)
         }
       })
       //self.checkedChooedTenancy()
      }
     }
    var imgHandler = async function (image) {
      self.addImgRange = self.$refs.text.quill.getSelection();
      if (image) {
        var fileInput = document.getElementById(self.uniqueId); //隐藏的file文本ID
        fileInput.click(); //加一个触发事件
      }
    };
    self.$nextTick(() => {
      self.$refs.text.quill.getModule("toolbar").addHandler("image", imgHandler);
    })
   }
}
</script>
<style lang="less" scoped>
.addAnnouncementCon{
  padding:0 20px;
  padding-top:20px;
  padding-left:0px;
  .addAnnouncementItem{
    margin-bottom:10px;
    position: relative;
    .addAnnouncementItemLabel{
      width:100px;
      line-height: 36px;
      text-align: right;
    }
    .titleTextarea{
      width:620px;
      height:60px;
      .el-textarea__inner{
        width:100%;
        height:100%;
      }
    }
    .oneTenancy{
      display: inline-block;
      height: 24px;
      line-height: 22px;
      background: #f4f4f5;
      border: 1px solid #e9e9eb;
      padding: 0 5px;
      margin-right:5px;
      margin-bottom: 5px;
      i{
        color:#F56C6C;
        margin-left:5px;
        cursor: pointer;
      }
    }
    ::v-deep .useNameTextarea {
      width: 500px;
      min-height:90px;
      border: 1px solid #DCDFE6;
      position: relative;
      padding:10px;
      padding-top:5px;
      .chooseTip{
        color:#C0C4CC;
        font-size:15px;
      }
      .choosedInstitute{
        display: inline-block;
      }
      .choosedSystem{
        display: inline-block;
      }
    }
    ::v-deep .datetime{
      height:36px;
      width:236px;
      .el-input__inner{
        width:236px;
        height:36px;
      }
      .el-input__icon {
        line-height: 36px;
      }
    }
    ::v-deep .el-radio{
      margin-right:0px;
    }
    ::v-deep .el-radio:last-of-type{
      margin-left:20px;
    }
    .width_500_input{
      width:500px;
      ::v-deep .el-input__inner{
        height: 36px!important;
        line-height: 34px!important;
      }
    }
    .announceTime{
      width:500px;
    }
    .chooseMemeber{
      width: 110px;
      height: 36px;
      text-align: center;
      cursor: pointer;
      color:#0A70B0;
      line-height: 34px;
      background: #ffffff;
      border: 1px solid #dcdfe6;
      border-radius: 2px;  
    }
    ::v-deep .myQuillEditor{
        width:620px;
      .ql-container{
        height:calc(100% - 38px);
      }
    }
  }
}
.wordNumber{
  position: absolute;
  right:15px;
  bottom:5px;
}
</style>
