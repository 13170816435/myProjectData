<template>
  <div class="inspectRecord-query">
          <div class="search-bar mb10">
            <div class="searchTop mb10">
              <div class="fl">
                  <span class="searchTit fl">关键字 :</span>
                  <el-input class="fl width_200_input" v-on:keyup.enter.native=search v-model="searchData.keyword"  placeholder="输入标题/内容"></el-input>
              </div>
              <div class="fl">
                <span class="searchTit fl ml20">发布人 :</span>
                <el-input class="fl width_100_input"  v-on:keyup.enter.native=search v-model="searchData.user_name"  placeholder=""></el-input>
              </div>
              <div class="fl">
                <span class="searchTit fl ml20">信息类型 :</span>
                <el-select
                  filterable
                  v-model="searchData.type"
                  placeholder="请选择"
                  class="width_120_input"
                  @change="search"
                >
                  <el-option
                    v-for="item in typeArr"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  ></el-option>
                </el-select>
              </div>
              <div class="fl ml20 mr10">
                <span class="searchTit fl">发布日期 :</span>
                <el-date-picker
                  @change="search"
                  class="chooseIntervalsPick searchTimePicker"
                  v-model="timer"
                  type="daterange"
                  align="right"
                  value-format="yyyy-MM-dd"
                  unlink-panels
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  :picker-options="pickerOptions"
                ></el-date-picker>
              </div>
              <div class="flex_row">
                <el-button type="primary" size="small" @click="search">查询</el-button>
                <el-button size="small" plain @click="resetSearch">重置</el-button>
              </div>
            </div>
        </div>
  </div>
</template>
<script>
// import eventBus from '@/utils/eventBus'
export default {
  props: {
    currentTabVal: String,
    action: {
      type: Number,
    },
  },
  components: {
  },
  data () {
    return {
      timer: [],
      typeArr: [
        {
          name: '全部',
          id: "",
        },
        {
          name: '平台公告',
          id: 1,
        },
        {
          name: '站内通知',
          id: 2,
        }
      ],
      pickerOptions: {
        shortcuts: [
          {
            text: '今天',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              // start.setTime(start.getTime() - 3600 * 1000 * 24 * 6);
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 6)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 29)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 89)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      width: '240px',
      searchData: {
        keyword: '',
        type: '',
        sender_type: '',
        user_name: '',
        start_add_time: '',
        end_add_time: '',
        offset: 1,
        limit: 20,
        sorts: [],
      }
    }
  },
  methods: {
    // 重置
    resetSearch () {
      // 初始化查询时间
      // this.timer = this.$getDefaultTime(0, -1)
      this.timer = []
      this.searchData = {
        keyword: '',
        type: '',
        user_name: '',
        start_add_time: '',
        end_add_time: '',
        offset: 1,
        limit: 20,
        sorts: [],
      }
      this.$emit('getList', this.searchData)
    },
    // 搜索
    search () {
      this.searchData.offset = 1
      this.searchData.limit = 20
      if (this.timer && this.timer.length !== 0) {
        this.searchData.start_add_time = this.timer[0]
        this.searchData.end_add_time = this.timer[1]
      } else {
        this.searchData.start_add_time = ''
        this.searchData.end_add_time = ''
      }
      this.$emit('getList', this.searchData)
    },
    beganSearchData () {

    },
  },
  watch: {

  },
  computed: {

  },
  created () {
  },
  mounted () {
    // 初始化查询时间
    // this.timer = this.$getDefaultTime(0, -1)
    // this.searchData.start_add_time = this.timer[0].substr(0, 10)
    // this.searchData.end_add_time = this.timer[1].substr(0, 10)
    this.search()
  }
}
</script>
<style lang="less" scoped>
.inspectRecord-query{
  .searchTop{
    min-height:32px;
  }
  .search-bar .addPadding{
    padding: 0 9px;
  }
  .search-bar .statusLabel{
    width:39px!important;
    min-width: 39px;
    text-align: left!important;
  }
  .searchTit{
    display: inline-block;
    margin-right: 10px;
    color: #303133;
    vertical-align: middle;
  }
  .operateBtnDiv{
    margin-left:5px;
  }
}
</style>
