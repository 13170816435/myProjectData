<template>
<!-- 表格： 可通过后台返回控制table显示某列 及自定义宽度 -->
  <div>
    <template v-for="(item, index) in propData">
      <el-table-column
        v-if="item.prop == 'patient_class'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <!-- 急诊标红处理 -->
        <template  slot-scope="scope">
          <span :class="{clr_red: scope.row.patient_class == '急诊'}">{{scope.row.patient_class}}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-else-if="item.prop == 'is_to_consult'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
          <span>{{scope.row.flags.is_to_consult ? '是' : '-'}}</span>
        </template>
      </el-table-column>
      <el-table-column
        v-else-if="item.prop == 'state_name'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
          <span class="stateName" v-bind:class="{'otherState': scope.row.state === 0 || scope.row.state === -1 || scope.row.state === 1 || scope.row.state === -98, 'failState': scope.row.state === -99 || scope.row.state < 0 && scope.row.state >= -70}">{{scope.row.state_name}}</span>
        </template>
      </el-table-column>
       <el-table-column
        v-else-if="item.prop == 'content'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
          <span class="" v-html="$replaceRN(scope.row.content)"></span>
        </template>
      </el-table-column>
      <el-table-column
        v-else
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
      </el-table-column>
    </template>
  </div>
</template>
<script>
import mixin from '@/utils/mixin/intelligentDiagnosis'

export default {
  name: 'CommonTable',
  props: {
    propData: Array
  },
  mixins: [mixin]
}
</script>
<style lang="less">
.stateName{
  color:#0bbd87;
  font-size:15px;
}
.otherState {
  color:#303133;
}
.failState{
  color: #f56c6c;
}
</style>
