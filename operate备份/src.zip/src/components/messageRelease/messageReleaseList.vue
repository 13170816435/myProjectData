<template>
  <div class="messageReleaseCon">
      <div class="title-bar flex_row">
        <div class="crumbsCon">
            <span class="title-name clr_303">
            <i class="iconfont icondingwei mr5"></i>{{ role == 'customer' ? '系统运维' : '运维管理'}}
            <i class="iconfont iconzhankaishouqi"></i> 信息发布
            </span>
            <!-- <div class="m-tab ml30">
              <div
                class="m-tab-item"
                :class="tabIndex === index ? 'm-tab-item-active' : ''"
                v-for="(item, index) in baseData.information_type"
                :key="index"
                v-if="index<2"
                @click="toggleTab(index, item.value)"
              >
              {{ item.name }}
              </div>
              <div class="tab-line" :style="{ left: number + 'px' }"></div>
            </div> -->
        </div>
        <!-- <el-tabs class="tabsCon fl" v-model="currentTabVal" @tab-click="userTabClickFn"> -->
          <!--加上v-if="index<2" 就是因为第3个tab(业务通知) 还未开发-->
          <!-- <el-tab-pane v-if="index<2" v-for="(item,index) in baseData.information_type" :key="item.value" :id="index" :label="item.name" :name="item.value.toString()"></el-tab-pane>
        </el-tabs> -->
        <div class="tr col">
            <span @click="addAnnouncement" class="function-btn bg_e6 clr_ff fr mt8">
            <i class="iconfont iconxinzeng mr5"></i>新增公告
            </span>
            <span @click="addNotice" class="function-btn bg_e6 clr_ff fr mt8 mr10">
            <i class="iconfont iconxinzeng mr5"></i>新增通知
            </span>
        </div>
    </div>
    <!-- <div class="searchTabCon">
        <div class="searchTab">
            <span v-for="(item,index) in baseData.information_type" :key="item.value">
              <span class="fl oneTab" :class="{'tabActive': index === 0}"  @click="chooseTab(item.value,$event)">{{item.name}}</span>
              <span v-if="index != baseData.information_type.length - 1" class="fl line"></span>
            </span>
            <span v-if="currentTabVal == 1" @click="addAnnouncement" class="function-btn bg_e6 clr_ff fr mt9 mr15">
            <i class="iconfont iconxinzeng mr5"></i>新增公告
            </span>
            <span v-if="currentTabVal == 2" @click="addNotice" class="function-btn bg_e6 clr_ff fr mt9 mr15">
            <i class="iconfont iconxinzeng mr5"></i>新增通知
            </span>
        </div>
    </div> -->
    <div class="container">
      <div class="searchQuery">
       <messageReleaseQuery :currentTabVal="currentTabVal" @getList="getList"></messageReleaseQuery>
    </div>
    <div
      class="allMessage clear"
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-background="rgba(255,255,255,0.6)"
      v-bind:class="{'noTableData':messageList.length==0}" >
        <el-table :data="messageList" border stripe
            height="100%"
            ref="tableAutoScroll"
            highlight-current-row
            header-row-class-name="strong">
              <el-table-column
                fixed="left"
                align="center"
                prop="index"
                label="序号"
                width="70">
                   <template slot-scope="scope">
                      <span>{{(searchData.offset - 1) * searchData.limit + scope.$index + 1}}</span>
                  </template>
              </el-table-column>
              <el-table-column width="100"
                align="left"
                fixed="left"
                label="操作">
                <template slot-scope="scope">
                  <span class="clr_0a pointer"  @click="editMessage(scope.row)">编辑</span>
                  <span class="clr_da pointer pl10"  @click="delMessage(scope.row)">删除</span>
                </template>
              </el-table-column>
              <el-table-column width="100"
                align="left"
                fixed="left"
                label="信息类型">
                <template slot-scope="scope">
                  <span class="">{{ scope.row.type == 1 ? "平台公告": "站内通知" }}</span>
                </template>
              </el-table-column>
              <common-table  :propData="propData" />
            </el-table>
        </div>
        <div class="pageContent">
          <div class="pageDiv">
            <pagination-tool :total="totalPage" :page.sync="searchData.offset" :limit.sync="searchData.limit" @pagination="getMessageList"/>
          </div>
        </div>
    </div>
    <!-- 新增公告 -->
    <el-dialog :title="announceTit" :top="'5vh'" :visible.sync="showAddAnnouncementAlert"  width="750px" :close-on-click-modal="false" v-dialogDrag>
        <addAnnouncement ref="addAnnouncement" :key="announceKey" :addAnnounceParam="addAnnounceParam" :isUpdate="isUpdate" :timeTypeObj="timeTypeObj" @noEndTimeFn="noEndTimeFn" @removeAudience="removeAudience" @sureChooseAudience="sureChooseAudience"></addAnnouncement>
        <div class="dialog_footer">
          <el-button size="small" plain @click="showAddAnnouncementAlert = false">取消</el-button>
          <el-button type="primary" size="small" v-if="!isUpdate" @click="beganAddAnnouncement">确定</el-button>
          <el-button type="primary" size="small" v-else @click="beganUpdateAnnouncement">确定</el-button>
        </div>
      </el-dialog>
      <!-- 新增通知 -->
      <el-dialog :title="noticeTit" :top="'5vh'" :visible.sync="showAddNoticeAlert"  width="750px" :close-on-click-modal="false" v-dialogDrag>
        <addNotice ref="addNotice" :key="noticeKey" :addNoticeParam="addNoticeParam" :isUpdate="isUpdate" @removeAudience="removeAudience" @sureChooseAudience="sureChooseAudience"></addNotice>
        <div class="dialog_footer">
            <el-button size="small" plain @click="showAddNoticeAlert = false">取消</el-button>
            <el-button type="primary" size="small" v-if="!isUpdate" @click="beganAddNotice">确定</el-button>
            <el-button type="primary" size="small" v-else @click="beganUpdateNotice">确定</el-button>
        </div>
      </el-dialog>
      <!-- 删除公告或通知 -->
      <el-dialog
        :title="currentAnnounceOrNoticeObj.type === 1 ? '删除公告': '删除通知'"
        :top="'31vh'"
        :visible.sync="showDelAnnounceOrNoticeAlert"
        width="400px"
        :close-on-click-modal="false"
        v-dialogDrag
      >
        <div class="deleteCon">
          <i class="iconfont icontishi clr_e6 mr5"></i>
          <span>确定要删除<span style="color:#0a70b0;padding:0 5px;">{{ currentAnnounceOrNoticeObj.title }}</span>{{currentAnnounceOrNoticeObj.type === '1' ? '公告' : '通知'}}?</span>
        </div>
        <div class="dialog_footer">
          <el-button size="small" plain @click="showDelAnnounceOrNoticeAlert=false">取消</el-button>
          <el-button type="primary" size="small" @click="beganDeleteInformation">确定</el-button>
        </div>
      </el-dialog>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import messageReleaseQuery from './components/messageReleaseQuery'
import CommonTable from './components/CommonTable'
import PaginationTool from '@/components/common/PaginationTool'
import addAnnouncement from './components/addAnnouncement'
import addNotice from './components/addNotice'
import { getInformationsList, deleteInformation, addInformation, putInformation, getInformationDetail } from '@/api/platform_operate/messageRelease'

export default {
  components: {
    messageReleaseQuery,
    CommonTable,
    PaginationTool,
    addAnnouncement,
    addNotice,
  },
  props: {
    role:String
  },
  provide() {
    return{
      isUpdate: ()=> this.isUpdate,
    }
  },
  computed: {
    ...mapGetters({ // 获取store查询枚举条件
      baseData: 'enumerations'
    }),
  },
  data () {
    return {
      tabIndex: 0,
      number: 0,
      tabType: 1,
      currentTabVal: '1',
      showAddAnnouncementAlert: false,
      showAddNoticeAlert: false,
      isUpdate: false,
      announceKey: 0,
      noticeKey: 0,
      totalPage: 0,
      searchData: {
        offset: 1,
        limit: 20,
      },
      curMessageId: 0,
      timeTypeObj: {
        end_time:2,
      },
      announceTit: '新增公告',
      noticeTit: '新增通知',
      messageList: [],
      messageDetailObj: {

      },
      addNoticeParam: {
        sender_type: "",
        type:2,
        title: '',
        content: '',
        recipients: []
      },
      addAnnounceParam: {
        sender_type: '',
        type:1,
        start_time: '',
        end_time: '',
        title: '',
        content: '' ,
        recipients: []
      },
      loading: false,
      propData: [
        { prop: 'title', label: '标题', width: 240 },
        { prop: 'content', label: '内容', width: 506 },
        { prop: 'user_name', label: '发布人', width: 90 },
        { prop: 'add_time', label: '发布时间', width: 180 },
        { prop: 'validity_period', label: '有效期', },
      ],
      showDelAnnounceOrNoticeAlert:false,
      currentAnnounceOrNoticeObj:{
        id: '',
        title: '',
      }
    }
  },
  methods: {
    toggleTab(index, value) {
      this.currentTabVal = value.toString();
      if (this.tabIndex < index) {
        this.number = index * 70 + index*10; //70既是一个tab的宽度 也是tab下滑动横线的宽度
      } else {
        this.number = this.number - (this.tabIndex - index) * 70 - (this.tabIndex - index)*10; // 10为tab之前的margin值 下面样式有设置
      }
      if (this.tabIndex != index) {
        this.searchData.type = parseInt(value)
        this.getMessageList()
      }
      this.tabIndex = index;
    },
    // 判断结束时间
    noEndTimeFn (val, timeTypeObj) {
      console.log(val)
      // this.addAnnounceParam.end_time = val
      this.timeTypeObj = timeTypeObj
      if (val === 2) {
        this.addAnnounceParam.end_time = ''
      }
    },
    //获取当前时间
    getNowTime() {
      var date = new Date();//年 getFullYear()：四位数字返回年份
      var year = date.getFullYear();  //getFullYear()代替getYear()
      var month = date.getMonth() + 1;//月 getMonth()：0 ~ 11
      var day = date.getDate();//日 getDate()：(1 ~ 31)
      var hour = date.getHours(); //时 getHours()：(0 ~ 23)
      var minute = date.getMinutes(); //分 getMinutes()： (0 ~ 59)
      var second = date.getSeconds();//秒 getSeconds()：(0 ~ 59)
      var time = year + '-' + this.addZero(month) + '-' + this.addZero(day) + ' ' + this.addZero(hour) + ':' + this.addZero(minute) + ':' + this.addZero(second);
      return time;
    },
    addZero(s) {
      return s < 10 ? ('0' + s) : s;
    },
    userTabClickFn (tab, event) {
      this.searchData.type = parseInt(this.currentTabVal)
      this.getMessageList()
    },
    chooseTab (num, e) {
      const curTabObj = e.currentTarget
      const tabObjArr = document.getElementsByClassName('oneTab')
      for (let i = 0; i < tabObjArr.length; i++) {
        tabObjArr[i].classList.remove('tabActive')
      }
      curTabObj.classList.add('tabActive')
      if (this.currentTabVal !== num) {
        this.currentTabVal = num
        this.searchData.type = this.currentTabVal
        this.getMessageList()
      }
    },
    // 移除受众
    removeAudience (id) {
      const self = this
      if (self.addAnnounceParam.recipients.length != 0 && self.currentTabVal == '1') {
        self.addAnnounceParam.recipients.forEach((item, i) => {
          if (item.recipient_id == id) {
            self.addAnnounceParam.recipients.splice(i,1)
          }
        })
      } else {
        if (self.addNoticeParam.recipients.length != 0) {
        self.addNoticeParam.recipients.forEach((item, i) => {
          if (item.recipient_id == id) {
            self.addNoticeParam.recipients.splice(i,1)
          }
        })
       }
      }
    },
    // 处理选择的受众
    sureChooseAudience (choosedTenancyArr,choosedInstitutionArr,choosedSystemArr) {
        if (this.currentTabVal == '1') { // 添加公告
          this.addAnnounceParam.recipients = []
        } else {
          this.addNoticeParam.recipients = []
        }
       // 将客户加入受众
       if (choosedTenancyArr.length != 0) {
          choosedTenancyArr.forEach((val)=> {
          let obj = {
            recipient_id: val.id,
            recipient_type: 1   // 受众类型是客户
          }
          if (this.currentTabVal == '1') { // 添加公告
            this.addAnnounceParam.recipients.push(obj)
          } else {
            this.addNoticeParam.recipients.push(obj)
          }

        })
       }
       // 将机构加入受众
       if (choosedInstitutionArr.length != 0) {
          choosedInstitutionArr.forEach((val)=> {
            let obj = {
              recipient_id: val.id,
              recipient_type: 2 // 受众类型是机构
            }
          if (this.currentTabVal == '1') { // 添加公告
            this.addAnnounceParam.recipients.push(obj)
          } else {
            this.addNoticeParam.recipients.push(obj)
          }
        })
      }
      // 将系统加入受众
      if (choosedSystemArr.length != 0) {
        choosedSystemArr.forEach((val)=> {
          let obj = {
            recipient_id: val.id,
            recipient_type: val.type // 受众类型是系统
          }
          if (this.currentTabVal == '1') { // 添加公告
            this.addAnnounceParam.recipients.push(obj)
          } else {
            this.addNoticeParam.recipients.push(obj)
          }
        })
      }
    },
    // 确定新增公告
    async sureAddAnnouncement () {
      const self = this
      const res = await addInformation(self.addAnnounceParam)
      if (res.code === 0) {
        self.$message({ message: '新增公告成功', type: 'success' })
        self.showAddAnnouncementAlert = false
        self.getMessageList()
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      }
    },
    // 确定编辑公告
    async sureUpdateAnnouncement () {
      const self = this
      let newParam = JSON.parse(JSON.stringify(Object.assign({id:self.curMessageId },self.addAnnounceParam)))
      newParam.recipients = []
      delete newParam['sender_type']
      delete newParam['type']
      if (self.addAnnounceParam.recipients.length != 0) {
        self.addAnnounceParam.recipients.forEach((item) => {
          let obj = {
            recipient_id:item.recipient_id,
            recipient_type: item.recipient_type
          }
          newParam.recipients.push(obj)
        })
      }

      const res = await putInformation(newParam)
      if (res.code === 0) {
        self.$message({ message: '编辑公告成功', type: 'success' })
        self.showAddAnnouncementAlert = false
        self.getMessageList()
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      }
    },
    verifyAddAnnounce () {
      if (this.role == "plateform" && this.addAnnounceParam.recipients.length == 0) {
        this.$message({ message: '请选择公告受众客户', type: 'error' })
        return
      }
      if (!this.addAnnounceParam.start_time) {
        this.$message({ message: '请选择公告开始时间', type: 'error' })
        return
      }
      if (!this.addAnnounceParam.end_time && this.timeTypeObj.end_time === 1) {
        this.$message({ message: '请选择公告结束时间', type: 'error' })
        return
      }
      if (!this.addAnnounceParam.title) {
        this.$message({ message: '请选择公告标题', type: 'error' })
        return
      }
      if (!this.addAnnounceParam.content) {
        this.$message({ message: '请选择公告内容', type: 'error' })
        return
      }
      return true
    },
    verifyAddNotice () {
      if (this.role == "plateform" && this.addNoticeParam.recipients.length == 0) {
        this.$message({ message: '请选择通知受众客户', type: 'error' })
        return
      }
      if (!this.addNoticeParam.title) {
        this.$message({ message: '请选择通知标题', type: 'error' })
        return
      }
      if (!this.addNoticeParam.content) {
        this.$message({ message: '请选择通知内容', type: 'error' })
        return
      }
      return true
    },
    // 开始编辑公告
    beganUpdateAnnouncement () {
      if (this.verifyAddAnnounce()) {
        this.sureUpdateAnnouncement()
      }
    },
    // 开始新增公告
    beganAddAnnouncement () {
      if (this.verifyAddAnnounce()) {
        this.sureAddAnnouncement()
      }
    },
    // 确定新增通知
    async sureAddNotice () {
      const self = this
      const res = await addInformation(self.addNoticeParam)
      if (res.code === 0) {
        self.$message({ message: '新增通知成功', type: 'success' })
        self.showAddNoticeAlert = false
        self.getMessageList()
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      }
    },
    // 确定编辑通知
    async sureUpdateNotice () {
      const self = this
      let newParam = JSON.parse(JSON.stringify(Object.assign({id:self.curMessageId },self.addNoticeParam)))
      newParam.recipients = []
      delete newParam['sender_type']
      delete newParam['type']
      if (self.addNoticeParam.recipients.length != 0) {
        self.addNoticeParam.recipients.forEach((item) => {
          let obj = {
            recipient_id:item.recipient_id,
            recipient_type: item.recipient_type
          }
          newParam.recipients.push(obj)
        })
      }
      // let newParam = Object.assign({id:self.curMessageId },self.addNoticeParam)
      const res = await putInformation(newParam)
      if (res.code === 0) {
        self.$message({ message: '编辑通知成功', type: 'success' })
        self.showAddNoticeAlert = false
        self.getMessageList()
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      }
    },
    // 开始编辑通知
    beganUpdateNotice () {
      if (this.verifyAddNotice()) {
        this.sureUpdateNotice()
      }
    },
    // 开始新增通知
    beganAddNotice () {
      console.log("发生了")
      if (this.verifyAddNotice()) {
        this.sureAddNotice()
      }
    },
    // 新增公告
    addAnnouncement () {
      this.showAddAnnouncementAlert = true
      this.isUpdate = false
      this.announceTit = '新增公告'
      this.addAnnounceParam = {
        sender_type: '',
        type:1,
        start_time: '',
        end_time: '',
        title: '',
        content: '' ,
        recipients: []
      }
      this.addAnnounceParam.start_time = this.getNowTime()
      if (this.role == "plateform") {
        this.addAnnounceParam.sender_type = 1
      }
      if (this.role == "customer") {
        this.addAnnounceParam.sender_type = 2
      }
      this.$nextTick(() => {
        this.$refs.addAnnouncement.AudienceOperate  = "选择受众"
        this.$refs.addAnnouncement.choosedTenancyArr = []
        this.$refs.addAnnouncement.choosedInstitutionArr = []
        this.$refs.addAnnouncement.choosedSystemArr = []
      })
    },
    // 新增通知
    addNotice () {
      this.showAddNoticeAlert = true
      this.isUpdate = false
      this.noticeTit = '新增通知'
      this.addNoticeParam = {
        sender_type: "",
        type:2,
        title: '',
        content: '',
        recipients: []
      }
      if (this.role == "plateform") {
        this.addNoticeParam.sender_type = 1
      }
      if (this.role == "customer") {
        this.addNoticeParam.sender_type = 2
      }
      this.$nextTick(() => {
        this.$refs.addNotice.AudienceOperate  = "选择受众"
        this.$refs.addNotice.choosedTenancyArr = []
        this.$refs.addNotice.choosedInstitutionArr = []
        this.$refs.addNotice.choosedSystemArr = []
      })
    },
    getList (obj) {
      this.searchData = obj
      if (this.role == "plateform") {
        this.searchData.sender_type = 1
      }
      if (this.role == "customer") {
        this.searchData.sender_type = 2
      }
      this.getMessageList()
    },
    // 获取公告列表和通知列表
    async getMessageList () {
      const self = this
      self.messageList = []
      //self.totalPage = 0
      const res = await getInformationsList (self.searchData)
      if (res.code === 0) {
        self.loading = false
        self.messageList = res.data
        if (res.page) {
          self.totalPage = res.page.total_count
        }
      } else {
        self.loading = false
        self.$message({ type: 'error', message: `${res.msg}` })
      }
    },
    // 获取公告详情
    async getMessageDetail (messageId,type) {
      const self = this
      const res = await getInformationDetail({id: messageId})
      if (res.code === 0) {
        self.messageDetailObj = res.data
        if (type == 1) { // 编辑公告
           self.addAnnounceParam = {
            sender_type: res.data.sender_type,
            type:1,
            start_time: res.data.start_time,
            end_time: res.data.end_time,
            title: res.data.title,
            content: res.data.content,
            recipients: res.data.recipients,
          }
          self.showAddAnnouncementAlert = true
          self.announceKey++
          if (res.data.end_time) {
            self.timeTypeObj.end_time = 1
          } else {
            res.data.end_time = ''
            self.timeTypeObj.end_time = 2
          }
        } else { // 编辑通知
          self.addNoticeParam = {
            sender_type: res.data.sender_type,
            type:2,
            title: res.data.title,
            content: res.data.content,
            recipients: res.data.recipients,
          }
          self.showAddNoticeAlert = true
          console.log(self.addNoticeParam)
          self.noticeKey++
        }
        if (this.role == "plateform") {
          this.addNoticeParam.sender_type = 1
          this.addAnnounceParam.sender_type = 1
        }
        if (this.role == "customer") {
          this.addNoticeParam.sender_type = 2
          this.addAnnounceParam.sender_type = 2
        }
      } else {
        self.$message({ type: 'error', message: `${res.msg}` })
      }
    },
    // 编辑公告或通知
    editMessage (row) {
      this.isUpdate = true
      this.curMessageId = row.id
      if (row.type == 1) {
        this.announceTit = '编辑公告'
      } else {
        this.noticeTit = '编辑通知'
      }
      this.getMessageDetail(row.id,row.type)
    },
    // 确定 删除通知或者公告
    async beganDeleteInformation () {
      const self = this
      const param = {
        id: this.currentAnnounceOrNoticeObj.id
      }
      const result = await deleteInformation(param)
      if (result.code === 0) {
        self.showDelAnnounceOrNoticeAlert = false
        self.$message({
          type: 'success',
          message: '删除成功!'
        })
        self.getMessageList()
      } else {
        self.$message({
          type: 'error',
          message: `${result.msg}`
        })
      }
    },
    // 删除公告或通知
    delMessage (obj) {
      const self = this
      self.showDelAnnounceOrNoticeAlert = true
      self.currentAnnounceOrNoticeObj = JSON.parse(JSON.stringify(obj))
    },
  },
  mounted() {
    this.addAnnounceParam.start_time = this.getNowTime()
    if (this.role == "plateform") {
      this.addNoticeParam.sender_type = 1
      this.addAnnounceParam.sender_type = 1
    }
    if (this.role == "customer") {
      this.addNoticeParam.sender_type = 2
      this.addAnnounceParam.sender_type = 2
    }
  }
}
</script>
<style lang="less" scoped>
.container{
  height: calc(100% - 46px);
  clear: both;
}
.messageReleaseCon{
  height:100%;
}
::v-deep .allMessage{
  height: calc(100% - 100px);
  .el-table__body-wrapper{
    height: calc(100% - 40px);
  }
}
.pageContent{
  .pageDiv{
    border: 1px solid #ebeef5;
    border-top:none;
  }
}
.crumbsCon {
  display: flex;
  .m-tab {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .m-tab-item {
    width: 70px;
    color: #303133;
    font-size: 15px;
    text-align: center;
    cursor: pointer;
    font-weight: 700;
    margin-right:10px;
  }
  .m-tab-item-active {
    color: #0a70b0;
    font-weight: 700;
  }
  .tab-line {
    height: 2px;
    width: 70px;
    background: #0a70b0;
    position: absolute;
    bottom: 0;
    left: 0;
    transition: all 0.3s ease;
  }
}
</style>
