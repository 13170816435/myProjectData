<template>
  <el-table
      :data="dataSource"
      :span-method="cellSpanMethod"
      @expand-change="onExpand"
      :default-expand-all="defaultExpandAll"
      row-key="__id"
      v-bind="$attrs"
      v-on="$listeners"
      ref="tb"
      :key="reRenderKey"
  >
    <slot></slot>
  </el-table>
</template>

<script>

import {calcSpan, statisticsDataListAdapter, toggleRowExpand} from './utils'

export default {
  name: "merge-table",

  props: {
    data: {
      type: Array,
      default: () => []
    },

    propList: {
      type: Array,
      default: () => []
    },

    expandAll: {
      type: Boolean,
      default: false
    },

    expandDeep: {
      type: Number,
      default: Number.MAX_VALUE
    }
  },

  data() {
    return {
      dataSource: [],
      reRenderKey: false,
      defaultExpandAll: this.expandAll
    }
  },

  watch: {
    data() {
      this.onDataChange()
    },

    expandAll(val) {
      if (val === this.defaultExpandAll) {
        return
      }
      this.defaultExpandAll = val
      this.reRender()
    },

    expandDeep() {
      this.reRender()
    }
  },

  methods: {
    reRender() {
      this.reRenderKey = !this.reRenderKey
      this.$nextTick(() => {
        this.onDataChange()
      })
    },

    onExpand(row, expanded) {
      row.__open = expanded
      this.calcSpan()
    },

    cellSpanMethod({row, column}) {
      const prop = column.property
      return {
        rowspan: row.__rowspan[prop],
        colspan: row.__colspan[prop]
      }
    },

    calcSpan() {
      calcSpan(this.dataSource, this.propList)
    },

    onDataChange() {
      this.dataSource = statisticsDataListAdapter(this.data, this.defaultExpandAll)
      this.calcSpan()

      /*this.$nextTick(() => {
        if(this.expandAll) {
          this.toggleRowExpansion(row => row.__deep > this.expandDeep)
        } else {
          this.toggleRowExpansion(row => row.__deep <= this.expandDeep)
        }
      })*/
    },

    toggleRowExpansion(fn) {
      const rowList = toggleRowExpand(this.dataSource, fn)
      for (let row of rowList) {
        this.$refs.tb.toggleRowExpansion(row.row, row.expand)
      }

      this.calcSpan()
    },

    doLayout() {
      this.$refs.tb.doLayout()
    }
  },

  mounted() {
    this.onDataChange()
  }
}

</script>

<style lang='less'>

</style>
