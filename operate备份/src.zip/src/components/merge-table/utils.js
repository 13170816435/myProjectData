import cloneDeep from 'clone-deep'

const isArray = list => Array.isArray(list)
const isUndef = val => val === undefined || val === null
const isStr = val => typeof val === 'string'
const isBlankStr = val => val.trim().length === 0

/**
 * 数据适配器
 * @param list
 * @param expandAll
 * @returns {*}
 */
export const statisticsDataListAdapter = (list, expandAll = false) => {
  const _list = cloneDeep(list)

  const map = (list, index = '', parent = null, deep = 1) => {
    for (let cIndex in list) {
      const row = list[cIndex]

      const __id = index.length > 0 ? `${index}_${cIndex}` : `${cIndex}`

      row.__id = __id
      row.__parent = parent
      row.__colspan = {}
      row.__rowspan = {}
      row.__open = expandAll
      row.__deep = deep

      if (isArray(row.children)) {
        row.children = map(row.children, __id, row, deep + 1)
      }

    }
    return list
  }

  return map(_list)
}


/**
 * 合并逻辑
 * 整体思想就是先处理children，通过children再向上推导父元素
 * @param list
 * @param propList
 */
export const calcSpan = (list, propList) => {
  const resetSpan = list => {
    for (let row of list) {
      if (row.children && row.children.length > 0) {
        resetSpan(row.children)
      }

      for (let prop of propList) {
        row.__colspan[prop] = 1
        row.__rowspan[prop] = 1
      }
    }
  }

  resetSpan(list)

  const map = list => {
    for (let row of list) {
      if (row.children && row.children.length > 0) {
        map(row.children)
      }

      propList.forEach((prop, propIndex) => {
        const value = row[prop]

        if ((isUndef(value) || (isStr(value) && isBlankStr(value)))) {
          if (row.__parent) {
            const key = `__${prop}`
            const value = row.__parent[prop]
            row.__parent[key] = value
            row[key] = value
          }
          const statisticsIndex = propList.findIndex(_prop => ['合计', '总计'].includes(row[_prop]))

          if (statisticsIndex > -1 && statisticsIndex < propIndex) {
            // 合并列
            const statisticsProp = propList[statisticsIndex]
            row.__colspan[statisticsProp] += 1
            row.__colspan[prop] = 0
          } else {
            // 合并列

            let parent = row.__parent
            let parentList = []     // parent 从小到大
            while (parent) {
              parentList.push(parent)
              parent = parent.__parent
            }

            row.__rowspan[prop] = 0

            const lastIndex = parentList.length - 1
            const targetIndex = lastIndex - propIndex
            const targetParent = parentList[targetIndex]

            const _parentList = parentList.slice(0, targetIndex + 1)

            const allParentOpened = _parentList.every(row => row.__open === true)

            if (allParentOpened) {
              targetParent.__rowspan[prop] += 1
            }
          }
        }
      })
    }
  }

  map(list)
}

/**
 * 展开关闭
 * @param list
 * @param fn
 * @returns {*[]}
 */
export const toggleRowExpand = (list, fn) => {
  const rowList = []
  const map = (list) => {
    for (let row of list) {
      if (row.children && row.children.length > 0) {
        map(row.children)
      }

      if (fn && fn(row) === true) {
        row.__open = !row.__open
        rowList.push({
          row, expand: row.__open
        })
      }
    }
  }

  map(list)
  return rowList
}
