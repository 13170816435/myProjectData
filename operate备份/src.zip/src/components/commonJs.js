import Vue from 'vue'
import axios from 'axios'
// 处理时间
export function InterceptTime (timer) {
  return timer.slice(0, 10)
}
export function connectUrlParam (data) {
  let url = ''
  for(var k in data) {
    let value = data[k] != undefined ? data[k] : '';
    url+=`&${k}=${encodeURIComponent(value)}`
  }
  return url ? url.substring(1): ''
}
// 数组去重
export function RemoveRepeatArray (arr) {
  return Array.from(new Set(arr))
}
// 下拉列表添加全部
export function UnshiftToArray (arr) {
  var item = {
    id: '',
    name: '全部'
  }
  if (arr && arr.length > 0) {
    arr.unshift(item)
  }
  return arr
}
// 删除数组指定元素
// export function RemoveArrayItem (arr, title, id) {
//   var self = this
//   arr.forEach((item, i) => {
//     self.$confirm('是否删除这条' + title + '信息？', '删除信息', {
//       distinguishCancelAndClose: true,
//       confirmButtonText: '删除',
//       cancelButtonText: '取消'
//     }).then(() => {
//       if (item.id === id) {
//         arr.splice(i, 1)
//       }
//       self.$message({
//         type: 'info',
//         message: '删除成功'
//       })
//     })
//   })
//   return arr
// }
// 处理城市json
export function CityLinkedJson (ajaxCityjson, _cityjson, params) {
  var arr = []
  ajaxCityjson.forEach(item => {
    var info = {
      label: '',
      value: ''
    }
    if (params.level < 3) {
      info.children = []
    }
    info.label = item.name
    info.value = item.code
    arr.push(info)
  })
  if (params.level === 1) {
    _cityjson = arr
  } else if (params.level === 2) {
    _cityjson.forEach(item => {
      if (item.value === params.parent_code) {
        item.children = arr
      }
    })
  } else if (params.level === 3) {
    _cityjson.forEach(itemlevel => {
      itemlevel.children.forEach(item => {
        if (item.value === params.parent_code) {
          item.children = arr
        }
      })
    })
  }
  return _cityjson
}
// 查询条件重置

// table里面滚动加载更多 指令
Vue.directive('loadTablemore', {
  bind (el, binding) {
    const selectWrap = el.querySelector('.el-table__body-wrapper')
    selectWrap.addEventListener('scroll', function () {
      const sign = 0
      const scrollDistance = this.scrollHeight - this.scrollTop - this.clientHeight
      if (scrollDistance <= sign) {
        binding.value()
      }
    })
  }
})
// 某个div 里面滚动加载更多
Vue.directive('loadmore', {
  bind (el, binding) {
    const selectWrap = el
    selectWrap.addEventListener('scroll', function () {
      const sign = 0
      const scrollDistance = this.scrollHeight - this.scrollTop - this.clientHeight
      if (scrollDistance <= sign) {
        binding.value()
      }
    })
  }
})
export function getBase64 (file) {
  return new Promise(function (resolve, reject) {
    let imgResult = ''
    if (file) {
      imgResult = 'data:image/png;base64,' + btoa(new Uint8Array(file).reduce((data, byte) => data + String.fromCharCode(byte), ''))
    }
    resolve(imgResult)
  })
}
// 打印表格
export function beganPrintPage (title, canvas) {
  var titleObj = document.getElementById("pageTit")
  titleObj.innerHTML = title
  var newstr = document.getElementById("printTest").innerHTML;//得到需要打印的元素HTML
  var oldstr = document.body.innerHTML
  //document.body.innerHTML = content;
 // window.print();
  document.body.innerHTML = oldstr;
  var win=window.open(); win.document.write("<br><img src='"+canvas.toDataURL()+"'/>"); win.print();
  // 主要处理 点击打印后 页面点击不了的问题
  window.location.reload();
}
// 导出excel
// url 导出接口地址  param 导出接口要传的参数 token 授权token  excelTit 为 excel文件的名字
export function beganImportExcel (url, param, token, excelTit) {
      const self = this
      axios.get(url, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded', // 请求的数据类型为form data格式
          'Authorization': token,
          // 'SystemId': SystemId
        },
        'responseType': 'blob',
        params: param
      }).then(function (response) {
        const result = response.data
        if (response.status === 200) {
          const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/vnd.ms-excel' }))
          const link = document.createElement('a')
          link.style.display = 'none'
          link.href = url
          link.setAttribute('download', excelTit + '.xls')
          document.body.appendChild(link)
          link.click()
        } else {
          self.$message.error(result.msg)
        }
      })
    }
export function getSS (key) {
  return sessionStorage.getItem(key) ? JSON.parse(sessionStorage.getItem(key)) : ''
}
export function setSS (key, value) {
  sessionStorage.setItem(key, JSON.stringify(value))
}
// 计算时间范围是 超过1个月 还是超过1年
export function timeOverFun (start,end) {
  const start_year = Number(start.slice(0, 4));
  const start_month = Number(start.slice(5, 7));
  const start_day = Number(start.slice(8));

  const end_year = Number(end.slice(0, 4));
  const end_month = Number(end.slice(5, 7));
  const end_day = Number(end.slice(8));
  let activeTimeTab = 1
  if (start_year === end_year) {
    //年份相同
    if (start_month === end_month) {
      //月份相同
      activeTimeTab = 1;
    } else {
      if (end_month - start_month > 1) {
        activeTimeTab = 2;
      } else {
        if (end_day >= start_day) {
          activeTimeTab = 2;
        } else {
          activeTimeTab = 1;
        }
      }
    }
  } else {
    //不同年
    if (end_year - start_year > 1) {
      //年份夸超过1年
      activeTimeTab = 3;
    } else {
      if (start_month === end_month) {
        //夸一年，月份相等 活期足额
        if (end_day >= start_day) {
          activeTimeTab = 3;
        } else {
          activeTimeTab = 2;
        }
      } else if (end_month - start_month >= 1) {
        //跨一年，结束月大于开始月
        activeTimeTab = 3;
      } else {
        activeTimeTab = 2;
      }
    }
  }
  return activeTimeTab
}
