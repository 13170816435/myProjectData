<template>
  <div class="container authorizaitonPage" v-bind:class="{'addAuthorizaitonPage': type === 'add', 'mt10': type === 'update'}">
    <div class="container-servicelist">
      <div class="lh40 blod"><span class="span_icon">1</span>{{serviceTypeinfo.pacs_service.name}}</div>
      <div class="el-collapse-item"  v-for="(item, index) in serviceTypeinfo.pacs_service.services" :key="index" v-cloak>
        <div class="collapse-title flex_row lh45">
          <div class="flex_1 ml30" v-cloak><span class="iconjiantou" :class="item.is_open?'down':''"><i class="iconfont iconzhankaishouqi"></i></span>{{item.name}}</div>
          <div class="flex_1 tr mr10">
            <el-switch
              v-model="item.is_open"
              active-color="#409EFF"
              inactive-color="#C0C4CC">
            </el-switch>
          </div>
        </div>
        <div class="el-collapse-item-info pb15 mt5 ml20" v-show="item.is_open">
           <div class="system_type" v-if="item.modules.length != 0">
                <span v-for="checkservece in item.modules" :key="checkservece.code">
                   <el-tooltip class="item toolTipText" effect="dark" :content="checkservece.instruction" placement="top-start">
                    <el-checkbox  v-model="checkservece.is_open" :label="checkservece.is_open">
                        {{checkservece.name}}
                    </el-checkbox>
                   </el-tooltip>
                </span>
            </div>

          <el-row class="tc clr666">
            <el-col :span="8">
              <span class="mr5">机构数量 :</span>
              <el-input v-model="item.count.institution_count" type="number" class="w_120" min=0 onKeypress="return (/[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </el-col>
            <el-col :span="8">
              <span class="mr5">用户数量 :</span>
              <el-input v-model="item.count.user_count" type="number" class="w_120" min=0 onKeypress="return (/[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </el-col>
            <el-col :span="8">
              <span class="mr5">设备数量 :</span>
              <el-input v-model="item.count.equipment_count" type="number" class="w_120" min=0 onKeypress="return (/[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </el-col>
          </el-row>
        </div>
      </div>
      <div class="el-collapse-item servi" v-for="(item, serviceindex) in ServiceList" :key="item.name" v-cloak>
        <div class="collapse-title flex_row pl lh45">
          <div class="flex_1" ><span class="span_icon">{{serviceindex + 2}}</span>{{item.name}}</div>
          <div class="flex_1 tr mr10" v-if="item.code != 'Quality' && item.code != 'Calling' && item.code != 'ImageSharing'">
            <el-switch
              v-model="item.is_open"
              active-color="#409EFF"
              inactive-color="#C0C4CC">
            </el-switch>
          </div>
        </div>
       
      <div class="el-collapse-item" v-if="item.code === 'Quality' || item.code == 'ImageSharing'"  v-for="(one, index) in item.items" :key="index" v-cloak>
        <div class="collapse-title flex_row lh45">
          <div class="flex_1 ml30" v-cloak><span class="iconjiantou" :class="one.is_open?'down':''"><i class="iconfont iconzhankaishouqi"></i></span>{{one.name}}</div>
          <div class="flex_1 tr mr10">
            <el-switch
              v-model="one.is_open"
              active-color="#409EFF"
              inactive-color="#C0C4CC">
            </el-switch>
          </div>
        </div>
        <div class="el-collapse-item-info pb15 mt5 ml20" v-show="one.is_open">
          <el-row class=" tc clr666">
            <!-- <el-checkbox-group v-model="one.checkedlist" class="serviceCheckBox tl pl20 pr20"> -->
              <el-checkbox v-for="checkservece in one.modules" :key="checkservece.code" v-model="checkservece.is_open" :label="checkservece.code" v-bind:title="checkservece.instruction">{{checkservece.name}}</el-checkbox>
            <!-- </el-checkbox-group> -->
          </el-row>
        </div>
      </div>

    <!--医技质控跟 叫号系统 字段名称不一样 一个是items 另一个是 children-->
      <div class="el-collapse-item" v-if="item.code === 'Calling'"  v-for="(one, index) in item.children" :key="index" v-cloak>
        <div class="collapse-title flex_row lh45">
          <div class="flex_1 ml30" v-cloak><span class="iconjiantou" :class="one.is_open?'down':''"><i class="iconfont iconzhankaishouqi"></i></span>{{one.name}}</div>
          <div class="flex_1 tr mr10">
            <el-switch
              v-model="one.is_open"
              active-color="#409EFF"
              inactive-color="#C0C4CC">
            </el-switch>
          </div>
        </div>
        <div class="el-collapse-item-info pb15 mt5 ml20" v-show="one.is_open">
          <el-row class=" tc clr666">
            <el-col :span="8" v-if="one.count.hasOwnProperty('call_screen_count')">
              <span class="mr5">叫号屏数量 :</span>
              <el-input v-model="one.count.call_screen_count" type="number" class="w_120" min=0 onKeypress="return (/[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </el-col>
          </el-row>
        </div>
      </div>
        
        <div class="el-collapse-item-info pb15 mt5 ml20" v-show="item.is_open && item.code != 'Quality' && item.code != 'Calling' && item.code != 'ImageSharing'">
          <el-row v-if="item.items" class=" tc clr666" style="padding-left: 53px;">
            <el-checkbox-group v-model="item.checkedlist" class="serviceCheckBox tl pl20 pr20">
              <el-checkbox v-for="checkservece in item.items" :key="checkservece.code" :label="checkservece.code" v-bind:title="checkservece.instruction">{{checkservece.name}}</el-checkbox>
            </el-checkbox-group>
          </el-row>

          <el-row v-if="item.count" class="tc clr333 mt10 mb5 ml20 el-row">
            <el-col :span="8" v-if="item.count.hasOwnProperty('institution_count')">
              <span class="mr5">机构数量 :</span>
              <el-input v-model="item.count.institution_count" type="number" class="w_120" min=0 onKeypress="return (/[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </el-col>
            <el-col :span="8" v-if="item.count.hasOwnProperty('equipment_count')">
              <span class="mr5">设备数量 :</span>
              <el-input v-model="item.count.equipment_count" type="number" class="w_120" min=0 onKeypress="return (/[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </el-col>
            
            <el-col :span="8" v-if="item.count.hasOwnProperty('user_count')">
              <span class="mr5">用户数量 :</span>
              <el-input v-model="item.count.user_count" type="number" class="w_120" min=0 onKeypress="return (/[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </el-col>
            <el-col :span="8" v-if="item.count.hasOwnProperty('office_count')">
              <span class="mr5">科室数量 :</span>
              <el-input v-model="item.count.office_count" type="number" class="w_120" min=0 onKeypress="return (/[\d]/.test(String.fromCharCode(event.keyCode)))"></el-input>
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    serviceTypeinfo: null
  },
  data () {
    return {
      activeName: '1',
      checklist: [],
      isShow: false,
      type: 'update'
    }
  },
  computed: {
    PacsServiceList () {
      console.log(this.serviceTypeinfo.pacs_service)
      return this.serviceTypeinfo.pacs_service
    },
    ServiceList () {
      return this.serviceTypeinfo.services
    }
  },
  methods: {
    closeFn () {
      this.$emit('closeFn')
    }
  },
  mounted () {
    if (this.$route.query.type) {
      this.type = this.$route.query.type
    }
  }
}
</script>
<style>
  .collapse-title {
    flex: 1 0 80%;
    order: 1;
    color: #303133;
    font-weight: bold;
  }
  .el-collapse-item__header {
    flex: 1 0 auto;
    order: -1;
  }
</style>
<style lang="less" scoped>
.container{
  border: 1px dashed #ccc;
  // height: calc(100vh - 275px);
  height:100%;
  overflow: auto;
}
.addAuthorizaitonPage{
  height: calc(100vh - 295px);
}
.operate-btn {
  width: 84px;
  height: 36px;
  line-height: 36px;
  border-radius: 3px;
  padding: 0px;
  border: none;
  border:1px solid #DCDFE6;
}
.w_120{
  width: 120px;
}
.span_icon{
  display: inline-block;
  width: 24px;
  height: 24px;
  line-height: 22px;
  background: #E6A23C;
  margin-right: 10px;
  font-weight: normal;
  text-align: center;
  border-radius: 50%;
  color: #fff;
}
.el-collapse-item{
  border-bottom: 1px solid #EBEEF5;
}
.iconjiantou{
  transition: transform .3s,-webkit-transform .3s;
  font-weight: 200;
  display: inline-block;
  margin-right: 5px;
}
.down{
  transform: rotate(90deg);
  -webkit-transform:rotate(90deg);
  -moz-transform:rotate(90deg);
}
.container-servicelist{
  min-height: 500px;
}
.authorizaitonPage{
  padding:10px 30px!important;
}
.mt10{
  margin-top:10px;
}
::v-deep .serviceCheckBox{
  .el-checkbox{
    color: #303133;
    font-size:15px;
    min-width: 135px;
    line-height: 30px;
  }
}
::v-deep .system_type{
  padding-left:28px;
  .toolTipText{
    font-size:15px;
    color:#303133;
    line-height: 24px;
    cursor: pointer;
  }
}
</style>
