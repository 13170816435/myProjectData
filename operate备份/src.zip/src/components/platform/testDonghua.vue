<template>
  <div class="dealRecord-wrap">
    <div class="title-contant" v-for="(item,index) in items " >

      <div class="title" @click="showHide(index)">

        <h3>2018年0{{index+6}}月</h3>

      </div>

      <div class="contant">

        <ul>

          <li v-for="i in item.allNumber">
            {{index+6}}
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    serviceTypeinfo: null
  },
  data () {
    return {
      items:[
        {v:'qqq',allNumber:1},

        {v:'aaa',allNumber:2},

        {v:'qqq',allNumber:3},

      ],
    }
  },
  methods: {
    closeFn () {
      this.$emit('closeFn')
    },
    showHide(index){  //点击展开收起

      let contant = document.getElementsByClassName('contant')[index];  //这里我们通过参数index来让浏览器判断你点击的是哪一个列表  

      let height = contant.getBoundingClientRect().height;  //获取页面元素的当前高度

      document.getElementsByTagName('i')[index].style.transform = !!height?'rotateX(0deg)':'rotateX(180deg)';

      if (!!height) {

      contant.style.height = height + 'px';

      //let f = document.body.offsetHeight; //强制相应dom重绘，使最新的样式得到应用

      contant.style.height = '0px';

      } else {

      contant.style.height = 'auto';

      height = contant.getBoundingClientRect().height;

      contant.style.height = '0';

      // let f = document.body.offsetHeight;

      contant.style.height = height + 'px';

      }
    }
  },
  mounted () {
   for(var i=0;i<3;i++){  //这里取值自后台返回的长度,设置页面渲染完成后是否展开，此处不展开

      document.getElementsByClassName('contant')[i].style.height = '0px';

    }
  }
}
</script>
<style>
  /* .collapse-title {
    flex: 1 0 80%;
    order: 1;
    color: #303133;
    font-weight: bold;
  } */
  .el-collapse-item__header {
    flex: 1 0 auto;
    order: -1;
  }
  .pacsSwitchStyle .el-switch__label {
    position: absolute;
    display: none;
    color: #fff;
  }
  .pacsSwitchStyle .el-switch__label--left {
    z-index: 9;
    left: 25px;
  }
  .pacsSwitchStyle .el-switch__label--right {
    z-index: 9;
    left: -2px;
  }
  .pacsSwitchStyle .el-switch__label.is-active {
    display: block;
  }
  .el-switch .el-switch__label {
    width: 24px !important;
  }
  .pacsSwitchStyle.el-switch .el-switch__core {
    width: 48px !important;
    border-radius:12px;
    height:24px;
  }
  .pacsSwitchStyle.el-switch .el-switch__core::after {
    width:18px;
    height:18px;
    top:2px;
  }
  .pacsSwitchStyle.el-switch__label * {
    font-size: 14px !important;
  }
</style>
<style lang="less" scoped>
.dealRecord-wrap{margin-bottom: 100px;

  .title-contant{overflow: hidden;  /* 这个是重点 */

    .title{height: 84px;padding: 0 24px;border-bottom: 1px solid #eaeaea;/*px*/

      h3{height: 84px;font-size: 28px;color: #333;display: flex;align-items: center;float: left;;margin-left: 10px;}

    }

    .contant{background: #fff;transition: height 1s;  /* 这个也是重点 */

      ul li{padding: 0 24px;height: 142px;display: flex;align-items: center;}

      ul li:not(:last-child){border-bottom: 1px solid #f6f6f6;/*px*/}
    }
  }
}
</style>