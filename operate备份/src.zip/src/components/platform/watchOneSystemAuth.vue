<template>
  <div class="oneSystemAuth">
    <div class="authTab">
       <span class="authTabTitle" v-if="(curSystemCode>=2210&&curSystemCode<=2250)">授权记录</span> <!--叫号系统  它不需要关联机构-->
       <el-radio-group v-else v-model="tabVal" @change="changeTab()">
          <el-radio-button :label="item.value" v-for="(item, index) in tabTypeArr" :key="index">{{item.name}}</el-radio-button>
        </el-radio-group>
    </div>
    <div class="authTabCon mt10" v-loadmore="loadMore" v-if="tabVal==1" v-bind:class="{'noTableData':activities.length==0}">
       <el-timeline>
        <el-timeline-item
          v-for="(activity, index) in activities"
          :key="index"
          :icon="activity.icon"
          :type="activity.orderType"
          :color="activity.color"
          :size="activity.size"
        >
        <div class="updateStatusDiv mb5">
            <span v-bind:class="{'authSuc': activity.state == 1, 'waitAuth': activity.state == 0}" class="updateStatus fl mr5">{{activity.state_remark}}</span>
            <!-- <span class="updateTime fl">{{activity.migrate_time}}</span> -->
        </div>
        <div class="updateBasicInfor clear">
            <div class="updateBasicInforBox">
                <!-- <div class="detailStateDiv updateStateDiv">
                    <span class="stateDescTip">更新说明：</span>
                    <span class="moreLineEllipsis moreLineAfter medIconfont detailState" @click="showAllState($event,activity)" v-html="$replaceRN(activity.remark)"></span>
                </div>
                <div class="dashline"></div>
                <span class="updateLogLabel">更新日志</span> -->
                <div class="updateLogItem">
                    <span class="updateLogItemLabel">审核时间：</span>
                    <span class="updateLogItemVal">{{activity.audit_date}}</span>
                </div>
                <div class="updateLogItem">
                    <span class="updateLogItemLabel">服务期限：</span>
                    <span class="updateLogItemVal">{{activity.validity_time}}</span>
                </div>
                <div class="updateLogItem">
                    <span class="updateLogItemLabel">申<span class="oneText">请</span>人：</span>
                    <span class="updateLogItemVal">{{activity.applicant}}</span>
                </div>
                <div class="updateLogItem">
                    <span class="updateLogItemLabel">申请时间：</span>
                    <span class="updateLogItemVal">{{activity.apply_time}}</span>
                </div>
            </div>
        </div>
        </el-timeline-item>
      </el-timeline>
    </div>
    <div class="serviceAppliCation mt10" v-if="tabVal==2">
       <div class="applicationHead">
        
         <span class="applicationSystemName" v-if="curSystemCode == 100">服务中心</span>
         <span class="applicationSystemName" v-else-if="curSystemCode == 400">教学中心</span>
         <span class="applicationSystemName" v-else>系统名称</span>
         <el-select class="systemSelect" filterable v-model="searchDataSystemData.system_id" @change="changeSystem" placeholder="请选择">
            <el-option
                v-for="item in systemArr"
                :key="item.id"
                :label="item.name"
                :value="item.id"
            ></el-option>
         </el-select>
       </div>
       <div class="table-list mt10" v-bind:class="{'noTableData':tableData.length==0}">
        <el-table
           width="100%"
           v-loading="loadingSystem"
           element-loading-text="拼命加载中"
           element-loading-background="rgba(255,255,255,0.6)"
           size="medium "
           :data="tableData"
           border
           stripe
           :height="tableheight"
           highlight-current-row
           header-row-class-name="strong"
          >
          <el-table-column type="index" label="序号" width="60" fixed="left"></el-table-column>
          <el-table-column prop="name" label="机构名称" width="210" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column type="admin_name" label="机构管理员" width="210" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div
                class="belongToDescription"
              >{{scope.row.admin_name}} ({{scope.row.admin_phone}})</div>
            </template>
          </el-table-column>
          <el-table-column prop="remark" v-if="(curSystemCode>=910&&curSystemCode<=980)" label="科室" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="remark" v-else label="开通服务" :show-overflow-tooltip="true"></el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>
<script>
import { getVersionDetail, getServiceLogList, getSystemOrServiceCenterList, getInstituteListBySystem } from '@/api/platform_operate/costomer'
export default {
  props: {
    service_id: String,
    tenancy_id: String,
    curSystemCode: Number,
  },
  data () {
    return {
      tabVal: 1,
      tabTypeArr: [
        {
          value:1,
          name: '授权记录'
        },
        {
          value:2,
          name: '服务应用'
        }
      ],
      loading:true,
      aq: true,
      systemArr: [],
      searchData: {
        service_id: '',
        offset: 1,
        limit:10,
      },
      searchDataSystemData: {
        system_id: '',
        tenancy_id: '',
      },
      getSystemOrServiceCenterParam: {
        service_id: '',
        tenancy_id: '',
      },
      activities: [],
      loadingSystem: false,
      tableheight: '100%',
      tableData: [],
    }
  },
  methods: {
    changeTab() {

    },
    loadMore () {
      if (this.aq === false) {
        return
      }
      if (this.searchData.offset === 1) {
        this.searchData.offset++
      }
      this.getSystemAuthLogList()
    },
    // 获取日志跟踪
    async getSystemAuthLogList () {
      const self = this
      //self.activities = []
      const res = await getServiceLogList(self.searchData)
      if (res.code === 0) {
        self.loading = false
        if (res.data && res.data.length !== 0) {
            self.searchData.offset++
            res.data.forEach((val, index) => {
              if (val.type === 0) {
                val.size = 'large'
                val.orderType = 'primary'
                val.icon = 'el-icon-more'
              }
              // 默认为授权成功的颜色
              val.color = '#1BB54A'
              // 给其它加上颜色
              if (val.type === 0) {
                val.color = '#FF9900'
              } else if (val.type === 2 ) { // 解约授权
                val.color = '#DA4A4A'
              } else if (val.type === 3) { // 授权到期
                val.color = '#DA4A4A'
              } else if (val.type === 4) { // 授权拒绝
                val.color = '#DA4A4A'
              }
              self.activities.push(val)
            })
          } else {
            self.activities = []
          }
        if (res.data.length < self.searchData.limit) {
          self.aq = false
        }
      } else {
        //self.loading = false
        self.$message.error(res.msg)
      }      
    },
    // 根据客户id和服务id 获取系统列表或服务中心
    async getSystemOrServiceCenterByTenancy() {
      const res = await getSystemOrServiceCenterList(this.getSystemOrServiceCenterParam)
      if (res.code == 0) {
        this.systemArr = res.data
        if (this.systemArr.length != 0) {
          this.searchDataSystemData.system_id = this.systemArr[0].id
          this.beganGetInstituteListBysystem()
        }
      } else {
        this.$message.error(res.msg)
      }
    },
    // 改变系统
    changeSystem () {
      this.beganGetInstituteListBysystem()
    },
    // 获取系统下的 机构列表
    async beganGetInstituteListBysystem() {
      
      const param = {
        tenancy_id: this.searchDataSystemData.tenancy_id
      }
      // 远程医疗和教学中心 传的字段名字service_center_id
      if (this.curSystemCode == 100 || this.curSystemCode == 400) {
        param.service_center_id = this.searchDataSystemData.system_id
      } else if (this.curSystemCode == 600) { // 质控
        param.quality_center_id = this.searchDataSystemData.system_id
      } else {
        param.system_id = this.searchDataSystemData.system_id
      }
      
      const res = await getInstituteListBySystem(param)
      if (res.code == 0) {
        this.tableData = res.data
      } else {
        this.$message.error(res.msg)
      }
    }
  },
  mounted () {
    this.searchData.service_id = this.service_id
    this.getSystemOrServiceCenterParam.service_id = this.service_id
    this.getSystemOrServiceCenterParam.tenancy_id = this.tenancy_id
    this.searchDataSystemData.tenancy_id = this.tenancy_id
    this.getSystemAuthLogList()
    this.getSystemOrServiceCenterByTenancy()
  }
}
</script>
<style lang="less" scoped>
.oneSystemAuth{
  padding: 8px 20px;
}
.authTab{
    .authTabTitle{
      color: #303133;
      font-weight: 700;
    }
    ::v-deep .el-radio-group{
    height:28px;
    line-height: 26px;
    .el-radio-button__inner{
      height:28px;
      line-height: 26px;
      padding:0 15px!important;
    }
    .el-radio-button__orig-radio:checked+.el-radio-button__inner{
       background-color: #0a70b0!important;
       border-color: #0a70b0!important;
    }
  }  
}
.updateStatusDiv{
 .updateStatus{
  //  width:70px;
   height:18px;
   padding:0 8px;
   color:#fff;
   font-size:14px;
   text-align: center;
   background:#F56C6C;
   line-height: 18px;
   border-radius: 9px;
 }
 .updateFail{
   background:#f56c6c;
 }
 .authSuc{
   background:#67C23A;
 }
 .waitAuth{
   background:#FF9900;
 }
 .updateTime{
   display: block;
   font-size:15px;
   color: #303133;
   line-height: 20px;
   font-weight: 700;
 }
}
.updateStatusDiv::after{
  content: '';
  height: 0;
  display: block;
  clear: both;
  visibility: hidden;
}
.authTabCon{
  padding:10px;
  border:1px solid #DCDFE6;
  height: 450px;
  overflow-y: auto;
}
.updateBasicInfor{
  border: 1px solid #ebeef5;
  box-shadow: 0px 2px 2px 0px rgba(25,25,25,0.02);
  .updateBasicInforBox{
    padding: 10px 10px 0px 10px;
    display: flex;
    flex-wrap: wrap;
  }
  .updateLogItem{
    line-height: 24px;
    margin-bottom: 5px;
    position: relative;
    width:50%;
    .updateLogItemLabel{
      font-size:14px;
      color:#303133;
    //   display: inline-block;
     .oneText{
       padding: 0 7px;
     }
    }
    .updateLogItemVal{
      color:#1A1A1A;
      font-size:14px;
    }
  }
}
::v-deep .el-timeline-item__node--normal{
  background:#0a70b0!important;
}
// 服务应用样式
.serviceAppliCation{
//   border: 1px solid #DCDFE6;
  height: 450px;
  .table-list{
    height:410px;
    ::v-deep .el-table {
      .el-table__body-wrapper{
        height:calc(100% - 40px);
        overflow-y: auto;
       }
    }
  }
}
.applicationHead{
  display: flex;
  height:32px;
  align-items: center;
  .applicationSystemName{
    border-radius: 3px 0 0px 3px;
    background:#F5F7FA;
    font-size:14px;
    color:#606266;
    padding: 0 15px;
    border:1px solid #DCDFE6;
    border-right: none;
    height: 32px;
    line-height: 30px;
  }
  ::v-deep .systemSelect{
    color:#303133;
    width:calc(100% - 90px);
    .el-input__inner{
      border-radius: 0px 2px 2px 0px;
    }
  }
}
</style>