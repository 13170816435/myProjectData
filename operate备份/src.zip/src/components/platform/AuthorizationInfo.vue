<template>
  <div
    class="container authorizaitonPage"
    v-bind:class="{ addAuthorizaitonPage: type === 'add' }"
  >
    <div class="container-servicelist">
      <div
        class="oneService"
        v-for="(oneService, nth) in allServiceTypeArr"
        :key="nth"
      >
        <div class="moduleCon">
          <span class="span_icon">{{ nth + 1 }}</span
          >{{ oneService.name }}
        </div>

        <div
          class="el-collapse-item"
          :class="{'activeCollapseItem':item.is_open}"
          v-for="(item, index) in oneService.products"
          :key="index"
          v-cloak
        >
          <div class="collapse-title flex_row">
            <div class="flex_1" v-cloak>
              <el-switch
                v-model="item.is_open"
                class="pacsSwitchStyle"
                :class="{'noOpenSwitchStyle': !item.is_open}"
                active-color="#409EFF"
                inactive-color="#c0c4cc"
                active-text="开"
                inactive-text="关"
                :active-value="true"
                :inactive-value="false"
                @change="changeProduct($event, item.service_val)"
              >
              </el-switch>
              <span
                class="iconjiantou"
                :class="item.is_open ? 'down' : ''"
              ></span>
              <span class="oneServiceName">{{ item.name }}</span>
            </div>
          </div>
          <div class="el-collapse-item-info">
            <div
              class="clr666 flex_row inputNumberCon"
              :class="{ noOpenService: item.services.length == 0 }"
              v-if="item.param_list && item.param_list.length != 0"
            >
              <div
                class="oneInputNumber mr29"
                v-for="(oneParam, paramIndex) in item.param_list"
                :key="paramIndex"
              >
                <span class="inputNumberLabel">{{ oneParam.name }}：</span>
                <el-input
                  v-model="oneParam.value"
                  type="number"
                  class="w_184"
                  min="0"
                  onKeypress="return (/[\d]/.test(String.fromCharCode(event.keyCode)))"
                ></el-input>
              </div>
            </div>

            <div
              class="system_type flex_row"
              v-if="item.services && item.services.length != 0"
            >
              <span
                v-for="(checkservece,nth) in item.services"
                :key="checkservece.service_val"
              >
                <!--有描述-->
                <el-tooltip
                  class="item toolTipText"
                  effect="dark"
                  v-if="checkservece.describe"
                  :content="checkservece.describe"
                  placement="top-start"
                >
                  <el-checkbox
                    v-model="checkservece.is_open"
                    :label="checkservece.is_open"
                    class="openModule"
                  >
                    {{ checkservece.name }}
                  </el-checkbox>
                </el-tooltip>
                <!--无描述--> 
                <span v-else>
                  <el-checkbox
                    v-model="checkservece.is_open"
                    :label="checkservece.is_open"
                    class="openModule"
                  >
                    {{ checkservece.name }}
                  </el-checkbox>
                </span> 
                
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    //serviceTypeinfo: null,
    allServiceTypeArr: Array,
  },
  data() {
    return {
      activeName: "1",
      checklist: [],
      isShow: false,
      type: "update",
      allProductArr: [],
    };
  },
  computed: {},
  methods: {
    closeFn() {
      this.$emit("closeFn");
    },
    changeProduct(state, serviceCode) {
      const self = this;
      let index = 0;
      self.$nextTick(() => {
        for (var i = 0; i < self.allProductArr.length; i++) {
          if (self.allProductArr[i].service_val == serviceCode) {
            index = i;
          }
        }
        let contant = document.getElementsByClassName("el-collapse-item-info")[
          index
        ];
        let height = contant.getBoundingClientRect().height; //获取页面元素的当前高度
        if (!state) { // 关闭时
          contant.style.height = height + "px";
          let f = document.body.offsetHeight; //强制相应dom重绘，使最新的样式得到应用
          contant.style.height = "0px";
        } else {
          contant.style.height = "auto";
          height = contant.getBoundingClientRect().height;
          contant.style.height = "0";
          let f = document.body.offsetHeight;
          contant.style.height = height + "px";
        }
      });
    },
  },
  mounted() {
    const self = this;
    if (self.$route.query.type) {
      self.type = self.$route.query.type;
    }
    self.$nextTick(() => {
      self.allProductArr = [];
      for (var i = 0; i < self.allServiceTypeArr.length; i++) {
        //这里取值自后台返回的长度,设置页面渲染完成后是否展开，此处不展开
        for (var j = 0; j < self.allServiceTypeArr[i].products.length; j++) {
          self.allProductArr.push(self.allServiceTypeArr[i].products[j]);
        }
      }

      for (var m = 0; m < self.allProductArr.length; m++) {
        if (!self.allProductArr[m].is_open) {
          document.getElementsByClassName("el-collapse-item-info")[
            m
          ].style.height = "0px";
        }
      }
    });
  },
};
</script>
<style>
.el-collapse-item__header {
  flex: 1 0 auto;
  order: -1;
}
.pacsSwitchStyle .el-switch__label {
  position: absolute;
  display: none;
  color: #fff;
}
.pacsSwitchStyle .el-switch__label--left {
  z-index: 9;
  left: 25px;
}
.pacsSwitchStyle .el-switch__label--right {
  z-index: 9;
  left: -2px;
}
.pacsSwitchStyle .el-switch__label.is-active {
  display: block;
}
.el-switch .el-switch__label {
  width: 24px !important;
}
.pacsSwitchStyle.el-switch .el-switch__core {
  width: 48px !important;
  border-radius: 12px;
  height: 24px;
  border-color: #c0c4cc !important;
  background: #c0c4cc !important;
}
.pacsSwitchStyle.el-switch .el-switch__core::after {
  width: 18px;
  height: 18px;
  top: 2px;
  margin-left: -20px;
}
.noOpenSwitchStyle.el-switch .el-switch__core::after {
  margin-left: 1px;
}
.pacsSwitchStyle.is-checked .el-switch__core {
  border-color: #409eff !important;
  background: #409eff !important;
}
.pacsSwitchStyle.el-switch__label * {
  font-size: 14px !important;
}
</style>
<style lang="less" scoped>
.container {
  height: 100%;
  overflow: auto;
}
.addAuthorizaitonPage {
  height: calc(100vh - 295px);
}
.operate-btn {
  width: 84px;
  height: 36px;
  line-height: 36px;
  border-radius: 3px;
  padding: 0px;
  border: none;
  border: 1px solid #dcdfe6;
}
.w_120 {
  width: 120px;
}
.moduleCon {
  line-height: 40px;
  color: #000;
  font-size: 16px;
}
.span_icon {
  display: inline-block;
  width: 20px;
  height: 20px;
  line-height: 20px;
  background: #e6a23c;
  font-family: Arial;
  margin-right: 10px;
  font-weight: 500;
  text-align: center;
  border-radius: 3px;
  color: #fff;
  font-size: 15px;
}
.el-collapse-item {
  padding-left: 28px;
  border: 1px solid #e4e7ed;
  border-radius: 3px;
  margin-bottom: 10px;
  overflow: hidden;
}
.activeCollapseItem{
  border-color: rgb(10,112,176,0.3);
  background:#fbfdff;
}
.el-collapse-item:hover{
  border-color: rgba(64, 158, 255, .5);
  background:#fbfdff;
}
.el-collapse-item-info {
  margin-left: 52px;
  transition: height 0.5s; // 动画效果
}
.inputNumberCon {
  // height:40px;
  padding-bottom: 10px;
  .oneInputNumber {
    display: flex;
    .inputNumberLabel {
      min-width: 75px;
      line-height: 32px;
      text-align: right;
    }
    .w_184 {
      width: 184px;
    }
  }
  .oneInputNumber:last-of-type {
    margin-right: 0px;
  }
  .mr29 {
    margin-right: 29px;
  }
}
.noOpenService {
  padding-bottom: 15px;
}
.collapse-title {
  padding: 10px 0px;
}
.iconjiantou {
  transition: transform 0.3s, -webkit-transform 0.3s;
  font-weight: 200;
  display: inline-block;
  margin-right: 5px;
}
.oneServiceName {
  position: relative;
  top: 2px;
}
.down {
  transform: rotate(90deg);
  -webkit-transform: rotate(90deg);
  -moz-transform: rotate(90deg);
}
.container-servicelist {
  min-height: 500px;
}
.authorizaitonPage {
}
.mt10 {
  margin-top: 10px;
}
::v-deep .serviceCheckBox {
  .el-checkbox {
    color: #303133;
    font-size: 15px;
    min-width: 135px;
    line-height: 30px;
  }
}
::v-deep .system_type {
  padding-bottom: 10px;
  flex-wrap: wrap;
  .toolTipText {
    font-size: 15px;
    color: #303133;
    line-height: 24px;
    cursor: pointer;
  }
}
.openModule {
  padding: 5px 15px;
  border-radius: 3px;
  border: 1px solid #dcdfe6;
  margin-right: 10px;
  color: #0a70b0;
  cursor: pointer;
  font-size: 14px;
  margin-bottom: 5px;
  ::v-deep .el-checkbox__label {
    padding-left: 0px;
  }
}
.openModule.el-checkbox.is-checked {
  border-color: #409eff;
  background: url("../../assets/images/common/checkboxBg.png") right bottom
    no-repeat;
}
.openModule {
  ::v-deep .el-checkbox__inner {
    display: none;
  }
}
.openModule:hover {
  color: #409eff;
  border-color: #409eff;
}
</style>