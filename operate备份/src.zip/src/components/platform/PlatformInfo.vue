<template>
  <div class="userinfo">
    <div class="contaner">
      <!-- 平台信息 -->
      <div class="container-item-border mt20">
        <div class="container-item-title">客户信息</div>
        <el-row class="tr clr_0a">
          <span class="pointer" @click="toUpdate('user', userinfo.tenancy_info.id)">编辑</span>
        </el-row>
        <el-row class="mt5 pl10 pr10">
          <el-col :span="12">
            <span class="clr_88">客户类型 ：</span>
            <span class="clr_333">{{userinfo.tenancy_info.type_desc}}</span>
          </el-col>
          <el-col :span="12">
            <span class="clr_88">客户名称 ：</span>
            <span class="clr_333">{{userinfo.tenancy_info.name}}</span>
          </el-col>
        </el-row>
        <el-row class="mt20 pl10 pr10">
          <el-col :span="12">
            <span class="clr_88">所在区域 ：</span>
            <span class="clr_333">{{userinfo.tenancy_info.address}}</span>
          </el-col>
          <el-col :span="12">
            <span class="clr_88">入驻时间 ：</span>
            <span class="clr_333">{{userinfo.tenancy_info.settling_time}}</span>
          </el-col>
        </el-row>
        <el-row class="mt20 pl10 pr10">
          <el-col :span="12">
            <span class="clr_88">管理人员 ：</span>
            <span class="clr_333">{{userinfo.tenancy_info.admin_name}}</span>
          </el-col>
          <el-col :span="12">
            <span class="clr_88">电话号码 : </span>
            <span class="clr_333" >{{userinfo.tenancy_info.admin_phone}}</span>
          </el-col>
        </el-row>
        <!-- <el-row class="mt20 pl10 pr10">
           <el-col :span="12">
            <span class="clr_88">是否委托 ：</span>
            <span class="clr_333">{{userinfo.tenancy_info.is_mandator?'是': '否'}}</span>
          </el-col>
          <el-col :span="12" v-if="userinfo.tenancy_info.operation_names">
            <span class="clr_88">委托管理员 ：</span>
            <span class="clr_333">{{userinfo.tenancy_info.operation_names}}</span>
          </el-col>
        </el-row> -->
      </div>
       <div class="container-item-border">
        <div class="container-item-title">服务授权</div>
        <el-row class="tr clr_0a">
          <!-- <span class="pointer" @click="toUpdate('shouquan', userinfo.tenancy_info.id, userinfo.tenancy_info.service_state)">{{userinfo.tenancy_info.service_state == 1 ? '编辑' : '新增'}}</span> -->
          <span class="pointer" @click="toUpdate('shouquan', userinfo.tenancy_info.id, userinfo.tenancy_info.service_state)">编辑</span>
        </el-row>
        <el-row class="mt20 pl10 pr10" v-if="!userinfo.service_authorize.reviewed && !userinfo.service_authorize.pending_review && !userinfo.service_authorize.rejected">
            <div class="lh40 tc">暂无服务</div>
          </el-row>
          <!-- 授权成功 -->
          <el-row class="mt20 pl10 pr10" v-if="userinfo.service_authorize.reviewed" v-bind:class="{'borderDashed': userinfo.service_authorize.reviewed&&userinfo.service_authorize.pending_review}">
            <el-col :span="3" class="tc br">
              <img class="authorize-img" :src="successImg" />
              <div class="mt10 clr_00">授权成功</div>
            </el-col>
            <el-col :span="20" class="pl10">
              <el-row class="lh25">
                <el-col :span="3" class="clr_88">已 开 通 ：</el-col>
                <el-col :span="20" class="clr_333" v-cloak>{{userinfo.service_authorize.reviewed.service_name?userinfo.service_authorize.reviewed.service_name:'暂无'}}</el-col>
              </el-row>
              <el-row class="mt10">
                <span class="clr_88">开通时间 ：</span>
                <span class="clr_333" v-cloak>{{userinfo.service_authorize.reviewed.audit_time}}</span>
              </el-row>
            </el-col>
          </el-row>
          <!-- 等待授权 -->
          <el-row class="mt20 pl10 pr10" v-if="userinfo.service_authorize.pending_review">
            <el-col :span="3" class="tc br">
              <img class="authorize-img" :src="waitImg" />
              <div class="mt10 clr_oarange">等待授权</div>
            </el-col>
            <el-col :span="20" class="pl10">
              <el-row class="lh25">
                <el-col :span="3" class="clr_88">已 申 请 ：</el-col>
                <el-col :span="20" class="clr_333" v-cloak>{{userinfo.service_authorize.pending_review.service_name?userinfo.service_authorize.pending_review.service_name:'暂无'}}</el-col>
              </el-row>
              <el-row class="mt10">
                <span class="clr_88">申请时间 ：</span>
                <span class="clr_333" v-cloak>{{userinfo.service_authorize.pending_review.apply_time}}</span>
              </el-row>
            </el-col>
          </el-row>
          <!-- 授权失败 -->
          <el-row class="mt20 pl10 pr10" v-if="userinfo.service_authorize.rejected">
            <el-col :span="3" class="tc br">
              <img class="authorize-img" :src="failImg" />
              <div class="mt10 clr_red">授权失败</div>
            </el-col>
            <el-col :span="20" class="pl10">
              <el-row class="lh25">
                <el-col :span="3" class="clr_88">失败原因 ：</el-col>
                <el-col :span="20" class="clr_333" v-cloak>{{userinfo.service_authorize.rejected.service_name?userinfo.service_authorize.rejected.service_name:'暂无'}}</el-col>
              </el-row>
              <el-row class="lh25">
                <el-col :span="3" class="clr_88">失败服务 ：</el-col>
                <el-col :span="20" class="clr_333" v-cloak>{{userinfo.service_authorize.rejected.reason}}</el-col>
              </el-row>
              <el-row class="mt10">
                <span class="clr_88">审核时间 ：</span>
                <span class="clr_333" v-cloak>{{userinfo.service_authorize.rejected.apply_time}}</span>
              </el-row>
            </el-col>
          </el-row>
      </div>


     <div class="container-item-border">
        <div class="container-item-title">平台信息</div>
        <el-row class="tr clr_0a">
          <span class="pointer" @click="toUpdate('platform', userinfo.tenancy_info.id)">编辑</span>
        </el-row>
        <el-row class="mt5 pl10 pr10 flex_row">
          <span class="clr_88 m_with100">平台名称 ：</span>
          <span class="clr_333">{{userinfo.platform_info.name}}</span>
        </el-row>
        <el-row class="mt20 pl10 pr10 flex_row">
          <div class="clr_88 v_top m_with100">平台Logo ：</div>
          <img v-if="userinfo.platform_info.logoUrl" :src="userinfo.platform_info.logoUrl" class="logoImg" />
        </el-row>
         <el-row class="mt20 pl10 pr10 flex_row">
          <div class="clr_88 v_top m_with100">网页图标 ：</div>
          <img v-if="userinfo.platform_info.favicon" :src="userinfo.platform_info.favicon" class="" />
        </el-row>
        <el-row class="mt20 pl10 pr10 flex_row">
          <div class="clr_88 v_top m_with100">网站横幅 ：</div>
          <div class="">
            <img v-for="(item, index) in bannerList" :key="index" v-if="item" :src="item" class="appbannerImg ml5" />
          </div>
        </el-row>
        <el-row class="mt20 pl10 pr10 lh25 flex_row" style="overflow:hidden">
          <div class="clr_88 m_with100">网站简介 ：</div>
          <div class="clr_333 flex_1">
            <div class="over_ell_3">
              <div v-html="userinfo.platform_info.introduction"></div>
            </div>
          </div>
        </el-row>
        <el-row class="mt20 pl10 pr10 lh25 flex_row">
          <div class="clr_88 m_with100">网站尾页 ：</div>
          <div class="clr_333 flex_1 over_ell_3">
            <div v-html="userinfo.platform_info.footer"></div>
          </div>
        </el-row>
        <el-row class="mt20 pl10 pr10 lh25 flex_row">
          <div class="clr_88 m_with100">友情链接 ：{{userinfo.platform_info.links}}</div>
        </el-row>
        <el-row class="mt20 pl10 pr10 lh25 flex_row">
          <div class="clr_88 m_with100">网页二维码 ：</div>
          <img v-for="(item, index) in codeList" :key="index" v-if="item" :src="item" class="appbannerImg ml5" />
        </el-row>
        <el-row class="mt20 pl10 pr10 flex_row">
          <div class="clr_88 v_top m_with100">移动端Logo ：</div>
          <img v-if="userinfo.platform_info.applogoUrl" :src="userinfo.platform_info.applogoUrl" class="logoImg" />
        </el-row>
        <el-row class="mt20 pl10 pr10 flex_row">
          <div class="clr_88 v_top m_with100">移动端Banner图 ：</div>
          <img v-for="(item, index) in appbannerList" :key="index" v-if="item" :src="item" class="appbannerImg" />
        </el-row>
        <el-row class="mt15 pl10 pr10 lh25 flex_row">
            <div class="clr_88 m_with100">登录页页尾内容 ：</div>
            <div v-if="userinfo.platform_info.login_footer">
              <div class="clr_333 flex_1" v-html="userinfo.platform_info.login_footer.length > 200 ? userinfo.platform_info.login_footer.substring(0, 200) + '...' : userinfo.platform_info.login_footer"></div>
            </div>
          </el-row>
        <el-row class="mt20 pl10 pr10 lh25 flex_row">
          <div class="clr_88 m_with100">外网域名 ：{{userinfo.platform_info.domain}}</div>
        </el-row>
        <el-row class="mt20 pl10 pr10 lh25 flex_row">
          <div class="clr_88 m_with100">内网域名 ：{{userinfo.platform_info.sub_domain}}</div>
        </el-row>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    userinfo: Object,
    bannerList: Array,
    linkList: Array,
    codeList: Array,
    appbannerList: Array,
    loginBgList: Array,
  },
  data () {
    return {
      successImg: require('@/assets/images/user/authorize_success.png'),
      failImg: require('@/assets/images/user/authorize_fail.png'),
      waitImg: require('@/assets/images/user/waitint_authorize.png')
    }
  },
  methods: {
    closeFn () {
      this.$emit('closeFn')
    },
    toUpdate (type, id, state) {
      var info = {
        type: type,
        id: id,
        state: state
      }
      this.$emit('toUpdate', info)
    }
  }
}
</script>
<style lang="less" scoped>
.userinfo {
  width: 1020px;
  padding: 0px 15px;
  .container-item-border{
    width: 100%;
    padding: 5px 20px 20px 25px;
    box-sizing: border-box;
    border: 1px dashed #DCDFE6;
    position: relative;
    margin-bottom: 20px;
    .w_300{
      width: 300px;
    }
    .container-item-title{
      position: absolute;
      left: 25px;
      top: -10px;
      background: #fff;
      min-width: 76px;
      text-align: center;
      color: #303133;
      font-weight: bold;
    }
    .customer-type{
      display: inline-block;
      padding: 0px 25px;
      height:36px;
      line-height: 36px;
      border:2px solid rgba(220, 223, 230, 1);
      border-radius:20px;
      color: #0A70B0;
      cursor: pointer;
      margin: 0px 10px;
    }
    .operate-btn{
      width: 88px;
      height:40px;
      line-height: 40px;
      padding: 0px;
      background:#fff;
      border:1px solid rgba(10, 112, 176, 1);
      border-radius:4px;
      color: #0a70b0;
      margin-right: 20px;
    }
    .customer-type:hover{
      border-color: rgba(10,112,175,0.75);
    }
    .active-customer{
      border-color: #0a70b0;
    }
  }
  // .container-item-border:last-of-type{
  //   border-bottom:none!important;
  // }
  .clr_88 {
    color: #888888;
  }
  .m_with100{
    min-width: 100px;
  }
}
.borderDashed{
  padding-bottom:10px;
  border-bottom: 1px dashed #dcdfe6;
}
</style>
