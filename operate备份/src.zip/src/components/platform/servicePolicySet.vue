<template>
  <div class="servicePolicy" :class="{'operateServicePolicy': role == 'operate'}">
    <div class="policyHead" v-if="role != 'operate'">
       <span class="icon"></span>
       <span class="policyHeadTit">客户层通知</span>
    </div>
    <div class="" v-if="role == 'operate'">
       <div class="policyItem mb15">
        <span class="policyItemLabel"><i class="iconfont iconbitian mustIcon"></i>服务节点：</span>
        <div class="policyItemVal">
        <span class="policyItemValLabel">服务到期前</span>
        <el-input type="text" class="policyItemInput" v-model="servicePolicyParam.first_notice_node" placeholder="请输入"></el-input>
        <span class="policyItemValLabel">天/</span>
        <el-input type="text" class="policyItemInput" v-model="servicePolicyParam.second_notice_node" placeholder="请输入"></el-input>
        <span class="policyItemValLabel">天/</span>
        <el-input type="text" class="policyItemInput" v-model="servicePolicyParam.third_notice_node" placeholder="请输入"></el-input>
        <span class="policyItemValLabel">天</span>
      </div>
    </div>
    <div class="policyItem mb15">
      <span class="policyItemLabel"><i class="iconfont iconbitian mustIcon"></i>通知对象：</span>
      <div class="policyItemVal selectItem">
        <el-select class="systemSelect" multiple collapse-tags filterable v-model="servicePolicyParam.notice_user_ids" @change="changeNoticeTarget" placeholder="请选择">
            <el-option
                v-for="item in operateUserList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
            ></el-option>
         </el-select>
      </div>
    </div>
    <div class="policyItem mb15">
       <span class="policyItemLabel specialPolicyLabel"><i class="iconfont iconbitian mustIcon"></i>通知方式：</span>
       <div class="policyItemVal">
         <el-checkbox-group v-model="servicePolicyParam.notice_type">
          <div class="checkItem" v-for="(item,index) in noticeTypesArr" :key="index">
            <el-checkbox :label="item.code" >
            {{item.name}}
            <span class="noticeTip">{{item.desc}}</span>
            </el-checkbox>
          </div>
        </el-checkbox-group>
      </div>
    </div>
    <div class="policyItem">
      <span class="policyItemLabel specialPolicyLabel">策略状态：</span>
      <div class="policyItemVal">
        <el-switch v-model="servicePolicyParam.notice_state"></el-switch>
      </div>
    </div>
    </div>
    
    <div class="" v-if="role != 'operate'">
       <div class="policyItem mb15">
        <span class="policyItemLabel"><i class="iconfont iconbitian mustIcon"></i>服务节点：</span>
        <div class="policyItemVal">
        <span class="policyItemValLabel">服务到期前</span>
        <el-input type="text" class="policyItemInput" v-model="servicePolicyParam.tenancy_first_notice_node" placeholder="请输入"></el-input>
        <span class="policyItemValLabel">天/</span>
        <el-input type="text" class="policyItemInput" v-model="servicePolicyParam.tenancy_second_notice_node" placeholder="请输入"></el-input>
        <span class="policyItemValLabel">天/</span>
        <el-input type="text" class="policyItemInput" v-model="servicePolicyParam.tenancy_third_notice_node" placeholder="请输入"></el-input>
        <span class="policyItemValLabel">天</span>
      </div>
    </div>
    <div class="policyItem mb15">
      <span class="policyItemLabel"><i class="iconfont iconbitian mustIcon"></i>通知对象：</span>
      <div class="policyItemVal selectItem">
        <el-select class="systemSelect" multiple collapse-tags filterable v-model="servicePolicyParam.tenancy_notice_user_ids" @change="changeNoticeTarget" placeholder="请选择">
            <el-option
                v-for="item in userList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
            ></el-option>
         </el-select>
      </div>
    </div>
    <div class="policyItem mb15">
       <span class="policyItemLabel specialPolicyLabel"><i class="iconfont iconbitian mustIcon"></i>通知方式：</span>
       <div class="policyItemVal">
         <el-checkbox-group v-model="servicePolicyParam.tenancy_notice_type">
          <div class="checkItem" v-for="(item,index) in noticeTypesArr" :key="index">
            <el-checkbox :label="item.code" >
            {{item.name}}
            <span class="noticeTip">{{item.desc}}</span>
            </el-checkbox>
          </div>
        </el-checkbox-group>
      </div>
    </div>
    <div class="policyItem">
      <span class="policyItemLabel specialPolicyLabel">策略状态：</span>
      <div class="policyItemVal">
        <el-switch v-model="servicePolicyParam.tenancy_notice_state"></el-switch>
      </div>
    </div>
    </div>

    <div class="" v-if="role != 'operate'">
      <div class="policyHead">
       <span class="icon"></span>
       <span class="policyHeadTit">系统层通知</span>
    </div>
    <div class="policyItem mb15">
      <span class="policyItemLabel"><i class="iconfont iconbitian mustIcon"></i>服务节点：</span>
      <div class="policyItemVal">
        <span class="policyItemValLabel">服务到期前</span>
        <el-input type="text" class="policyItemInput" v-model="servicePolicyParam.system_first_notice_node" placeholder="请输入"></el-input>
        <span class="policyItemValLabel">天/</span>
        <el-input type="text" class="policyItemInput" v-model="servicePolicyParam.system_second_notice_node" placeholder="请输入"></el-input>
        <span class="policyItemValLabel">天/</span>
        <el-input type="text" class="policyItemInput" v-model="servicePolicyParam.system_third_notice_node" placeholder="请输入"></el-input>
        <span class="policyItemValLabel">天</span>
      </div>
    </div>
    <div class="policyItem mb15">
      <span class="policyItemLabel"><i class="iconfont iconbitian mustIcon"></i>通知对象：</span>
      <div class="policyItemVal selectItem systemNoticeUser">
        
        <el-input
          value="系统管理员"
          :disabled="true">
        </el-input>
      </div>
    </div>
    <div class="policyItem mb15">
       <span class="policyItemLabel specialPolicyLabel"><i class="iconfont iconbitian mustIcon"></i>通知方式：</span>
       <div class="policyItemVal">
         <el-checkbox-group v-model="servicePolicyParam.system_notice_type">
          <div class="checkItem" v-for="(item,index) in noticeTypesArr" :key="index">
            <el-checkbox :label="item.code" >
            {{item.name}}
            <span class="noticeTip">{{item.desc}}</span>
            </el-checkbox>
          </div>
        </el-checkbox-group>
      </div>
    </div>
    <div class="policyItem">
      <span class="policyItemLabel specialPolicyLabel">策略状态：</span>
      <div class="policyItemVal">
        <el-switch v-model="servicePolicyParam.system_notice_state"></el-switch>
      </div>
    </div>
    </div>

  </div> 
</template>
<script>
export default {
  props: {
    role:String,
    servicePolicyParam: Object,
    operateUserList:Array,
    userList: Array,
  },
  data () {
    return {
      systemArr: [
        {
          name: '授权记录',
          id: 1
        },
        {
          name: '服务应用',
          id: 2
        },
      ],
      noticeTypesArr: [
        {
          name: '弹窗提示',
          code: 1,
          desc: '（触发条件后，登入系统后右下角弹窗提醒）'
        },
        {
          name: '手机短信',
          code: 2,
          desc: '（触发条件后，当天09:00发送短信通知）'
        },
        {
          name: '电子邮件',
          code: 3,
          desc: '（触发条件后，当天09:00发送邮件通知）'
        },
      ],
    }
  },
  methods: {
    // 选择通知对象
    changeNoticeTarget () {

    },
  },

}
</script>
<style lang="less" scoped>
.servicePolicy{
   padding: 0px 20px 10px 20px;
  .policyHead{
    display: flex;
    align-items: center;
    border-bottom: 1px solid #DCDFE6;
    height:36px;
    margin-bottom: 10px;
    .icon{
      width: 3px;
      height: 16px;
      background:#0a70b0;
      margin-right:10px;
    }
    .policyHeadTit{
      font-size:15px;
      color:#303133;
      font-weight: 700;
    }
  }
  .policyItem{
    display: flex;
    .policyItemLabel{
       color:#303133;
       font-size:14px;
       line-height: 32px;
       width: 85px;
       text-align: right;
       i{
         color: #da4a4a;
         font-size: 10px;
         line-height: 32px;
       }
    }
    .specialPolicyLabel{
      position: relative;
      top:-5px;
    }
    .policyItemVal{
      .policyItemValLabel{
        color:#303133;
        font-size:14px;
        line-height: 32px;
      }
      .policyItemInput{
        width:60px;
        margin:0 5px;
      }
      .systemSelect{
        width:100%;
      }
      .noticeTip{
        color:#FF9900;
        font-size:14px;
      }
      .checkItem{
        line-height: 24px;
        ::v-deep .is-checked{
          .el-checkbox__inner{
            background:#0a70b0;
            border-color:#0a70b0;
          } 
          .el-checkbox__label{
            color:#0a70b0;
          }
        }
      }
      ::v-deep .el-switch.is-checked .el-switch__core{
        border-color: #0a70b0;
        background-color: #0a70b0;
      }
    }
    .selectItem{
      width:calc(100% - 85px);  
    }
  }
}
.operateServicePolicy{
  padding:20px;
}
.systemNoticeUser{
  font-size:14px;
  color:#303133;
  line-height:32px;
}
</style>