<template>
  <div class="">
    <el-form :model="customerInfo" :rules="rules" ref="customerInfo" label-width="130px" class="container">
      <div class="container-item-border">
        <div class="container-item-title">客户类型</div>
        <div class="tc">
          <!-- <span class="customer-type" :class="customerparmas.active_customerType == item.value?'active-customer': ''" v-show="item.value" v-for="(item, index) in (customerType)" :key="index" @click="CustomerTypeFn(item)">{{item.name}}</span> -->
          <span class="customer-type"  
          :class="{'active-customer': customerparmas.active_customerType == item.value, 'notUpdate': isUpdate}"
          v-show="item.value" v-for="(item, index) in (tenancyTypeArr)" 
          :key="index" @click="CustomerTypeFn(item)">{{item.name}}</span>
        </div>
      </div>
      <div class="container-item-border">
        <div class="container-item-title"><span class="border_l"></span>客户信息</div>
        <div class="w_450">
          <el-form-item label="客户名称:" prop="name">
            <el-input v-model="customerInfo.name" class="w_300"></el-input>
          </el-form-item>
          <el-form-item label="机构入驻日期:" prop="settling_time" class="mt15">
            <el-date-picker v-model="customerInfo.settling_time" type="date" placeholder="选择日期" value-format="yyyy-MM-dd"  class="w_300"> </el-date-picker>
          </el-form-item>
          <el-form-item label="所  在  地:" prop="city" class="mt15">
            <el-cascader
              ref="cascaderAddr"
              :style="{width: '300px'}"
              v-model="customerparmas.cityValue"
              :options="customerparmas.cityJson"
              :key="1"
              @change="getCityCodeFn"
              @active-item-change="childrenCity">
            </el-cascader>
          </el-form-item>
        </div>
      </div>
      <div class="container-item-border">
      <div class="container-item-title"><span class="border_l"></span>客户管理员</div>
      <div class="w_450">
        <el-form-item label="管理员电话:" prop="admin_phone" class="mt15">
          <el-input type="tel" v-model="customerInfo.admin_phone" @input="changePhone" class="w_300"  @blur="getNameFn('admin', customerInfo.admin_phone)"></el-input>
        </el-form-item>
        <el-form-item label="管理员姓名:" prop="admin_name" class="mt15">
          <el-input type="tel" v-model="customerInfo.admin_name" :disabled="customerparmas.adminnameDisabled?true:false" class="w_300"></el-input>
        </el-form-item>
      </div>
      </div>
      <!-- <div class="container-item-border">
        <div class="container-item-title"><span class="border_l"></span>管理委托</div>
        <div class="w_450">
          <el-form-item label="是否委托:">
            <el-switch v-model="customerInfo.is_mandator" @change="changeSwitch($event)">是</el-switch>
          </el-form-item>
          <el-form-item v-if="customerInfo.is_mandator" label="委托管理人 :" prop="operation_names">
            <el-input type="tel" v-model="customerInfo.operation_names" class="w_300" disabled></el-input>
            <el-button class="check-btn" @click="showUserList">选择用户</el-button>
          </el-form-item>
        </div>
      </div> -->
    </el-form>
    <div class="mt15">
      <el-button type="primary" size="medium" @click="onSubmit('customerInfo', 'commit')">提交</el-button>
      <el-button size="medium" plain @click="onSubmit('customerInfo', 'cancel')">取消</el-button>
    </div>
    <!--委托管理人-->
    <el-dialog :append-to-body="true" :title="userInfo.userInfotile" :visible.sync="userInfo.isUserInfo" @close="colseDialog" :close-on-click-modal="false"  width="900px" v-dialogDrag>
      <addedit-userinfo ref="Ctable" :userInfo="userInfo" :userlist="toCheckedUserList" :search="insuserSearchData" :pageInfo="adduserlist_pageInfo" :checkeduser="CheckedUserList" @getinsuserSerchName="getinsuserSerchName"
                        @serchListFn="serchUserListFn" @submitForm="submitForm" @changeCheck="changeCheck" @userselectChange="userselectChange" @delCheckuser="delCheckuser" @pageSizeChangeFn="pageSizeChangeFn"></addedit-userinfo>
      <div slot="footer" class="dialog-footer">
        <el-button @click="ChoiceUserFn('cancel')">取 消</el-button>
        <el-button type="primary" @click="ChoiceUserFn('commit')">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import Vue from 'vue'
// import JSEncrypt from 'jsencrypt'
import JSEncrypt from '@/utils/jsencrypt.min'
import AddeditUserinfo from '@/components/jurisdiction/AddedituserInfo'
import { mapGetters } from 'vuex'
import { getUsersOperations } from '@/api/user'
import { putCostomer, getCityJson, getLoginName, getCostomerInfo, getAllTenancyType } from '@/api/platform_operate/costomer'
import { getConfigurations } from '@/api/commonHttp'
export default {
  props: {
    userId: String
  },
  components: {
    AddeditUserinfo
  },
  data () {
    return {
      tenancyTypeArr: [],
      customerparmas: {
        isadd: true,
        active_customerType: null, // 客户类型
        is_mandator: false,
        isagree: false,
        adminnameDisabled: '', // 管理员姓名
        mandatornameDisabled: '', // 委托管理员姓名
        cityValue: [],
        cityJson: [],
        city_parmas: {
          parent_code: '1',
          level: 1
        }
      },
      isUpdate: true,
      isFirstChange: true,
      // 委托管理人--------------------
      toCheckedUserList: [], // 选择用户列表
      CheckedUserList: [],
      // 新增、编辑用户
      insuserSearchData: {
        username: ''
      },
      userInfo: {
        isUserInfo: false,
        userInfotile: '新增委托管理员',
        userList: []
      },
      adduserlist_pageInfo: {
        eof: 1,
        page_index: 1,
        page_size: 10,
        total_count: 0,
        total_pages: 1
      },
      addUserInfo: {},
      // ------------------
      customerInfo: {
        type: '',
        name: '',
        settling_time: '',
        admin_name: '',
        admin_phone: '',
        mandator_name: '',
        mandator_phone: '',
        province_code: '',
        province: '',
        city_code: '',
        city: '',
        district_code: '',
        district: ''
      },
      rules: {
        name: [
          { required: true, message: '请输入客户名称', trigger: 'blur' },
          { min: 2, max: 20, message: '长度在2-20个字符之间', trigger: 'blur' }
        ],
        settling_time: [
          { required: true, message: '请选择日期', trigger: 'change' }
        ],
        admin_phone: [
          { required: true, message: '请输入管理员电话', trigger: 'blur' }
        ],
        city: [
          { required: true, message: '请选择所在地', trigger: 'change' }
        ],
        admin_name: [
          { required: true, message: '请输入管理员姓名', trigger: 'change' }
        ],
        mandator_phone: [
          { required: true, message: '请输入委托管理员电话', trigger: 'blur' }
        ],
        mandator_name: [
          { required: true, message: '请输入委托管理员姓名', trigger: 'change' }
        ]
      }
    }
  },
  computed: {
    ...mapGetters({ customerType: 'tenancyType' })
  },
  mounted () {
    this.getTenancyType()
    // 加密
    this.getConfigurationsFn()
    this.getCostomerInfoFn(this.userId)
    this.geUserlistFn()
    // this.getCityJsonFn(this.userId)
  },
  methods: {
    async getConfigurationsFn () {
      const res = await getConfigurations('TransmissionSecurity.RSA.PublicKey')
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) { // 注册方法
          const pubKey = res.data// ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt()
          encryptStr.setPublicKey(pubKey) // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()) // 进行加密
          return data
        }
      }
    },
    // 获取租户类型
    async getTenancyType () {
      const res = await getAllTenancyType()
      if (res.code === 0) {
        this.tenancyTypeArr = res.data
      } else {
        this.$message.error(res.msg)
      }
    },
    changePhone () {
      // 是否是第一次改变
      if (this.isFirstChange) {
        this.customerInfo.admin_phone = ''
        this.customerInfo.admin_name = ''
      }
      this.isFirstChange = false
    },
    // 用户信息
    async getCostomerInfoFn (id) {
      const res = await getCostomerInfo(id)
      if (res.code === 0) {
        this.customerInfo = res.data
        this.customerparmas.active_customerType = res.data.type
        this.customerparmas.adminnameDisabled = this.customerInfo.admin_name
        if (this.customerInfo.province_code) {
          await this.echoCityinfo(this.customerInfo.province_code, this.customerInfo.city_code, this.customerInfo.district_code)
          this.customerparmas.cityValue = [this.customerInfo.province_code, this.customerInfo.city_code, this.customerInfo.district_code]
        }
      }
    },
    // 获取城市json
    async getCityJsonFn (params) {
      const res = await getCityJson(params)
      var arr = []
      res.data.forEach(item => {
        var info = {
          label: '',
          value: ''
        }
        if (params.level < 3) {
          info.children = []
        }
        info.label = item.name
        info.value = item.code
        arr.push(info)
      })
      if (params.level === 1) {
        this.customerparmas.cityJson = arr
      } else if (params.level === 2) {
        this.customerparmas.cityJson.forEach(item => {
          if (item.value === params.parent_code) {
            item.children = arr
          }
        })
      } else if (params.level === 3) {
        this.customerparmas.cityJson.forEach(itemlevel => {
          itemlevel.children.forEach(item => {
            if (item.value === params.parent_code) {
              item.children = arr
            }
          })
        })
      }
    },
    async childrenCity (val) {
      val.forEach((item, i) => {
        this.customerparmas.city_parmas.parent_code = item
        this.customerparmas.city_parmas.level = i + 2
      })
      await this.getCityJsonFn(this.customerparmas.city_parmas)
    },
    getCityCodeFn (val) {
      var arr = this.getCascaderObj(val, this.customerparmas.cityJson)
      arr.forEach((item, i) => {
        if (i === 0) {
          this.customerInfo.province_code = item.value
          this.customerInfo.province = item.label
        } else if (i === 1) {
          this.customerInfo.city_code = item.value
          this.customerInfo.city = item.label
        } if (i === 2) {
          this.customerInfo.district_code = item.value
          this.customerInfo.district = item.label
        }
      })
    },
    getCascaderObj (val, opt) {
      return val.map(function (value, index, array) {
        for (var itm of opt) {
          if (itm.value === value) { opt = itm.children; return itm }
        }
        return null
      })
    },
    // 回显城市联动
    async echoCityinfo (province, city, district) {
      var _provinceparmas = {
        parent_code: province,
        level: 1
      }
      var _cityparmas = {
        parent_code: city,
        level: 2
      }
      var _districtparmas = {
        parent_code: district,
        level: 3
      }
      var _provincejson = []
      var _cityjson = []
      var _districtjson = []
      // 一级
      const _provinceres = await getCityJson(_provinceparmas)
      _provinceres.data.forEach(item => {
        var info = {
          label: '',
          value: ''
        }
        info.children = []
        info.label = item.name
        info.value = item.code
        _provincejson.push(info)
      })
      this.customerparmas.cityJson = _provincejson
      // 二级
      const _cityres = await getCityJson(_cityparmas)
      _cityres.data.forEach(item => {
        var info = {
          label: '',
          value: ''
        }
        info.children = []
        info.label = item.name
        info.value = item.code
        _cityjson.push(info)
      })
      this.customerparmas.cityJson.forEach(item => {
        if (item.value === _provinceparmas.parent_code) {
          item.children = _cityjson
        }
      })
      // 三级
      const _districtres = await getCityJson(_districtparmas)
      _districtres.data.forEach(item => {
        var info = {
          label: '',
          value: ''
        }
        info.label = item.name
        info.value = item.code
        _districtjson.push(info)
      })
      this.customerparmas.cityJson.forEach(itemlevel => {
        itemlevel.children.forEach(item => {
          if (item.value === _cityparmas.parent_code) {
            item.children = _districtjson
          }
        })
      })
    },
    // 设置用户类型
    CustomerTypeFn (info) {
      if (this.isUpdate) { // 编辑时 不让它修改客户类型
        return false
      }
      this.customerparmas.active_customerType = info.value
      this.customerInfo.type = info.value
    },
    // 手机号码匹配姓名
    async getNameFn (type, phone) {
      var phoneReg = /^1[3456789]\d{9}$/
      if (!phoneReg.test(phone)) {
        return
      }
      var url = `/users/lite/${phone}`
      var res = await getLoginName(url)
      if (res.code === 0) {
        if (type === 'admin') {
          this.customerInfo.admin_name = res.data ? res.data.name : ''
          this.customerparmas.adminnameDisabled = res.data ? res.data.name : ''
        } else {
          this.customerInfo.mandator_name = res.data ? res.data.name : ''
          this.customerparmas.mandatornameDisabled = res.data ? res.data.name : ''
        }
      } else {
        if (type === 'admin') {
          this.customerInfo.admin_name = ''
          this.customerparmas.adminnameDisabled = ''
        } else {
          this.customerInfo.mandator_name = ''
          this.customerparmas.mandatornameDisabled = ''
        }
      }
    },
    // 是否委托
    changeSwitch (val) {
      if (!val) {
        this.customerInfo.mandator_phone = ''
        this.customerInfo.mandator_name = ''
        this.customerInfo.operation_ids = []
        this.customerInfo.operation_names = ''
      }
    },
    // 添加委托人--------------------------------------------------------------------------------
    colseDialog () {
      this.addUserInfo = this.$options.data().addUserInfo
    },
    showUserList () {
      this.userInfo.isUserInfo = true
    },
    // 获取用户列表
    async geUserlistFn (username) {
      const name = username ? '&name=' + username : ''
      const _url = 'offset=' + this.adduserlist_pageInfo.page_index + '&limit=' + this.adduserlist_pageInfo.page_size + name
      const res = await getUsersOperations(_url)
      if (res.code === 0) {
        this.toCheckedUserList = res.data
        this.adduserlist_pageInfo = res.page
      }
    },
    getinsuserSerchName (val) {
      this.insuserSearchData.username = val
    },
    async showAddUserinfoFn () {
      this.userInfo.isUserInfo = true
      await this.getUnAuthorityUserlistFn()
      // if (this.userListInfo.userList.length > 0) {
      //   this.CheckedUserList = this.userListInfo.userList
      //   this.toCheckedUserList.forEach(element => {
      //     this.CheckedUserList.forEach((item, i) => {
      //       if (item.id === element.id) {
      //         this.$nextTick(() => {
      //           this.$refs.Ctable.$refs.CheckuserTable.toggleRowSelection(this.$refs.Ctable.$refs.CheckuserTable.data[i], true)
      //         })
      //       }
      //     })
      //   })
      // }
    },
    // 搜索用户列表
    serchUserListFn () {
      console.log(this.insuserSearchData.username)
      this.geUserlistFn(this.insuserSearchData.username)
    },
    // 用户列表勾选
    userselectChange (val) {
      this.CheckedUserList = val
    },
    delCheckuser (id) {
      this.CheckedUserList.forEach((item, i) => {
        if (item.id === id) {
          this.$refs.Ctable.$refs.CheckuserTable.toggleRowSelection(this.$refs.Ctable.$refs.CheckuserTable.data[i], false)
          this.CheckedUserList.splice(item.id, 1)
        }
      })
    },
    ChoiceUserFn (type) {
      var self = this
      if (type === 'cancel') {
        self.userInfo.isUserInfo = false
        return
      }
      if (self.CheckedUserList.length === 0) {
        self.$message({ message: '请至少选择一位组成员', type: 'error' })
        return false
      }
      console.log(self.CheckedUserList)
      var arr = []
      const namelsit = []
      self.CheckedUserList.forEach(item => {
        arr.push(item.id)
        namelsit.push(item.name)
      })
      self.customerInfo.operation_ids = arr
      self.userInfo.isUserInfo = false
      self.customerInfo.operation_names = namelsit.join(',')
    },
    pageSizeChangeFn (info, type) {
      this.adduserlist_pageInfo.page_index = info.page
      this.adduserlist_pageInfo.offset = info.page
      this.getUnAuthorityUserlistFn() // 天际用户组用户列表
    },
    // 选择权限复选框事件(1级)
    changeCheck (e, val) {
      if (!e) { // 父级checkbox未勾选，子级置为false
        this.userGroupInfo.AthorityGroupsArr.forEach(tabitem => {
          tabitem.authorities.forEach(Aitem => {
            if (Aitem.id === val) {
              if (!Aitem.checked) {
                Aitem.policies.forEach(Pitem => {
                  Pitem.checked = false
                })
              }
            }
          })
        })
      } else {
        this.userGroupInfo.AthorityGroupsArr.forEach(tabitem => {
          tabitem.authorities.forEach(Aitem => {
            if (Aitem.id === val) {
              Aitem.policies.forEach(Pitem => {
                Pitem.checked = true
              })
            }
          })
        })
      }
    },
    submitForm (form, type) {
      if (form.type === 'submit') {
        form.refs[form.formName].validate((valid) => {
          if (valid) {
            this.addUserGroupInfoFn()
          } else {
            return false
          }
        })
      } else {
        form.refs[form.formName].resetFields()
        this.isGroupInfo = false
        this.userGroupInfo = this.$options.data().userGroupInfo
      }
    },
    // ------------------------------------------------
    onSubmit (fileName, type) {
      const self = this
      if (type === 'commit') {
        self.$refs[fileName].validate((valid) => {
          if (valid) {
            if (!self.customerInfo.type) {
              self.$message({
                message: '请选择用户类型!',
                type: 'warning'
              })
              return
            }
            var phoneReg = /^1[3456789]\d{9}$/
            // if (!phoneReg.test(this.customerInfo.admin_phone)) {
            //   this.$message({
            //     message: '管理员电话输入有误，请重新输入!',
            //     type: 'warning'
            //   })
            //   return false
            // }
            // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
            if (!self.isUpdate || (self.isUpdate && !self.isFirstChange)) {
              if (!phoneReg.test(self.customerInfo.admin_phone)) {
                self.$message({
                  message: '管理员电话输入有误，请重新输入!',
                  type: 'warning'
                })
                return false
              }
            }

 

            let responseData = {}
            let msg = ''
            var adminPhone = self.customerInfo.admin_phone
            self.customerInfo.admin_phone = self.$getRsaCode(self.customerInfo.admin_phone)
            const param =  {
              id: self.customerInfo.id,
              type:self.customerInfo.type,
              name: self.customerInfo.name,
              settling_time: self.customerInfo.settling_time,
              admin_name: self.customerInfo.admin_name,
              admin_phone: self.customerInfo.admin_phone,
              mandator_name: self.customerInfo.mandator_name,
              mandator_phone: self.customerInfo.mandator_phone,
              province_code: self.customerInfo.province_code,
              province: self.customerInfo.province,
              city_code: self.customerInfo.city_code,
              city: self.customerInfo.city,
              district_code: self.customerInfo.district_code,
              district: self.customerInfo.district,
            }
            responseData = putCostomer(self.customerInfo.id, param)
            msg = '修改客户信息成功！'
            responseData.then(response => {
              if (response.code === 0) {
                 self.$emit('closeFn', 'userinfo')
                  self.$message({
                    message: msg,
                    type: 'success'
                  })
              } else {
                self.customerInfo.admin_phone = adminPhone
                self.message.error(response.msg)
              }
            })
          }
        })
      } else {
        // this.customerInfo = this.$options.data().customerInfo
        this.$emit('closeFn')
      }
    }
  }
}
</script>

<style lang="less" scoped>
.container{
  border: 1px solid #DCDFE6;
  padding: 0px;
  height: calc(100vh - 112px);
  overflow: auto;
}
.container-item-border{
  width: 100%;
  padding: 10px 10px 20px 10px;
  box-sizing: border-box;
  border-bottom : 1px dashed #DCDFE6;
  position: relative;
  .container-item-title{
    text-align: left;
    color: #303133;
    .border_l{
      display: inline-block;
      width: 3px;
      height: 14px;
      border-radius: 1px;
      margin-right: 5px;
      vertical-align: middle;
      background: #0a70b0;
    }
  }
  .customer-type{
    display: inline-block;
    padding: 0 16px;
    height: 36px;
    line-height: 34px;
    border: 1px solid #dcdfe6;
    border-radius: 20px;
    color: #0a70b0;
    cursor: pointer;
    margin: 10px 10px 0;
  }
  .active-customer{
    border-color: #0a70b0;
    background: #0a70b0!important;
    color: #fff;
  }
  .notUpdate{
    cursor: not-allowed;
  }
  .operate-btn{
    width: 88px;
    height:40px;
    line-height: 40px;
    padding: 0px;
    background:#fff;
    border:1px solid rgba(10, 112, 176, 1);
    border-radius:4px;
    color: #0a70b0;
    margin-right: 20px;
  }
  .customer-type:hover{
    border-color: rgba(10,112,175,0.75);
  }
  .w_450{
    width: 450px;
    margin: auto;
  }
  .w_300{
    width: 300px;
  }
}
.container-item-border:last-child{
  border: none;
}

</style>
