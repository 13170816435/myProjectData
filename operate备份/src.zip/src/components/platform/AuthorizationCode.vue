<template>
  <div class="dialoginfo">
    <div class="service_typeinfo">
      <div class="lh40 clr_333 f15 bold">已选产品：</div>
      <div class="service_scroll">
        <div class="service_type" v-for="(item, index) in AuthorizedUrl.products" :key="index">
          <div class="service_type_title">
            <img class="productImg" :src="
                item.service_val == 960
                  ? HYX
                  : item.service_val == 930
                  ? XD
                  : item.service_val == 920
                  ? CS
                  : item.service_val == 910
                  ? FS
                  : item.service_val == 940
                  ? NJ
                  : item.service_val == 950
                  ? PS
                  : item.service_val == 961
                  ? FLK
                  : item.service_val == 2000
                  ? ES
                  : item.service_val == 2110
                  ? CUND
                  : item.service_val == 970
                  ? YK
                  : item.service_val == 980
                  ? SZJGH
                  :item.service_val == 981
                  ? FLPACS
                  : item.service_val == 2400
                  ? AIM
                  : (item.service_val == 2210 || item.service_val == 2220 || item.service_val == 2230 || item.service_val == 2240 || item.service_val == 2250 || item.service_val == 2260)
                  ? YY
                  : item.service_val == 2300
                  ? YYDSJ
                  : item.service_val == 100
                  ? YCYL
                  : item.service_val == 310
                  ? YYYGD
                  : item.service_val == 350
                  ? YYZX
                  : item.service_val == 340
                  ? YYZSY
                  : item.service_val == 1100
                  ? KSGL
                  : item.service_val == 400
                  ? YCJX
                  : (item.service_val == 610 || item.service_val == 611)
                  ? ZKFS
                  : (item.service_val == 620 || item.service_val == 621)
                  ? ZKCS
                  : (item.service_val == 630 || item.service_val == 631)
                  ? ZKNJ
                  : (item.service_val == 640 || item.service_val == 641)
                  ? ZKXD
                  : (item.service_val == 650 || item.service_val == 651)
                  ? ZKPL 
                  : (item.service_val == 2500) ? HZFU: YY
              " alt="">
            <span>{{item.name}}</span>
          </div>
          <div class="productParamCon">
            <div class="flex_row">
              <div class="oneProductParam" v-for="(oneParam,index) in item.param_list">
                  <span class="productValue">{{oneParam.value}}</span>
                  <div class="productParamLabel">{{oneParam.name}}</div>
              </div>
             </div>
             <div class="productService" v-if="item.services">
              {{item.services}}
             </div>
          </div>


          <!-- <div v-if="item.items.length > 0" class="service_type_info"><span v-for="(itemtitle, index) in item.items" :key='index'><span v-if="index !=0">、</span>{{itemtitle}}</span></div> -->
        </div>
      </div>
    </div>
    <div class="service_code">
      <div class="qrcode fl" ref="qrCodeUrl"></div>
      <div class="fl authDesc">
        <div class="stepState">服务授权流程：</div>
        <div class="stepCon">第1步：打开【医网影像云】公众号，登录并进入管理界面；</div>
        <div class="stepCon">第2步：进入服务授权申请页面，扫描左侧二维码；</div>
        <div class="stepCon">第3步：确认并提交授权申请，审核结果将以消息的方式发送至微信公众号，请注意查收；</div>
        <div class="stepCon">第4步：审核通过后，将授权码复制到下方输入框，完成服务授权。
          <span class="checkRefuseTip">若审核拒绝，点击【重新申请】，可再次发起授权申请</span>
        </div>
        <div class="stepCon pointer mt5 mb5 f15">注：若扫码失败，可点此<span class="copyText" @click="copycode"> 复制申请码</span>，并粘贴到申请码输入框</div>
      </div>
      
      <div class="inputcode clear">
        <div class="mb5 f15 clr_333 bold">请录入收到的授权码</div>
        <el-input type="textarea" :value="servicecode" :autosize="autosize" @input="inputCode"></el-input>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    AuthorizedUrl: Object,
    servicecode: String,
    qrCodeUrl: String
  },
  data () {
    return {
      CS: require("../../assets/images/CS_Image.png"), // 超声
      FS: require("../../assets/images/FS_Image.png"), // 放射
      NJ: require("../../assets/images/NJ_Image.png"), // 内镜
      XD: require("../../assets/images/XD_Image.png"), // 心电
      PS: require("../../assets/images/PS_Image.png"), // 病理
      HYX: require("../../assets/images/HYX_Image.png"), // 核医学
      ES: require("../../assets/images/Appoint_Image.png"), // 集中预约
      CUND: require("../../assets/images/YXCD_Image.png"), // 影像存档
      YY: require("../../assets/images/YY_Image.png"), // 语音叫号
      YK: require("../../assets/images/YK_Image.png"), // 眼科
      SZJGH: require("../../assets/images/SZHBG_Image.png"), // 数字结构化报告
      AIM: require("../../assets/images/AIM.png"), // 智能诊断
      YCYL: require("../../assets/images/FWZX_Image.png"), // 远程医疗
      YYDSJ: require("../../assets/images/YYDSJ_Image.png"), // 影像大数据
      YYYGD: require("../../assets/images/YXYGD_Image.png"), // 影像云归档
      YYZX: require("../../assets/images/YYZX_Image.png"), // 影像中心
      YYZSY: require("../../assets/images/YXZSY_Image.png"), // 影像主索引
      FLK: require("../../assets/images/fangLiao_Image.png"), // 放疗科
      FLPACS: require("../../assets/images/fangLiao_Image.png"), // 放疗PACS
      KSGL: require("../../assets/images/intelligenceOfficeIcon.png"), // 科室管理
      YCJX: require("../../assets/images/teaching.png"), // 远程教学
      ZKFS: require("../../assets/images/ZK_FS_Image.png"), // 质控放射
      ZKCS: require("../../assets/images/ZK_CS_Image.png"), // 质控超声
      ZKNJ: require("../../assets/images/ZK_NJ_Image.png"), // 质控内镜
      ZKXD: require("../../assets/images/ZK_XD_Image.png"), // 质控心电
      ZKPL: require("../../assets/images/ZK_PS_Image.png"), // 质控病理
      HZFU: require("../../assets/images/patientServices.png"), // 患者服务
      autosize: {
        minRows: 5,
        maxRows: 10
      }
    }
  },
  methods: {
    inputCode (val) {
      this.$emit('inputCode', val)
    },
    copycode () {
      this.$emit('copycode')
    }
  }
}
</script>

<style lang="less" scoped>
.dialoginfo{
  padding: 0px 10px;
  display: flex;
  height:625px;
  .service_typeinfo{
    width: 320px;
    padding-left: 10px;
    overflow-y: auto;
    // margin-right: 30px;
    // position: relative;
    // overflow: hidden;
  }
  .service_scroll{
    // height: 90%;
    padding-right: 15px;
  }
  .service_type{
    width: 100%;
    border: 1px solid #e4e7ed;
    padding: 8px 10px;
    margin-bottom: 15px;
    border-radius: 4px;
    box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.05);
    
    .service_type_title{
      display: flex;
      font-size:16px;
      color:#303133;
      margin-bottom: 8px;
      align-items: center;
      .productImg{
        width:24px;
        border-radius: 4px;
        margin-right:10px;
      }
     
    }
    .service_type_info{
      padding: 10px 15px;
      border-top: 1px solid #DBDFE5;
    }
  }
  .productParamCon{
    .oneProductParam{
      flex:1;
      text-align: center;
      border-right: 1px dashed #e4e7ed;
      .productValue {
        font-size:15px;
        font-family: Arial;
        font-weight: 700;
        color:#303133;
      }
      .productParamLabel{
        font-size:13px;
        color:#909399;
      }
    }
    .oneProductParam:last-of-type{
      border-right:none;
    }
    .productService{
      padding:6px 10px;
      margin-top:8px;
      background:#f5f7fa;
      border-radius: 4px;
      font-size:14px;
      color:#303133;
      line-height: 22px;
    }
  }
  .service_code{
    flex: 1;
    height: 100%;
    border-left: 1px solid #DBDFE5;
  }
  .qrcode{
    // margin: auto;
    // margin-top: 30px;
    margin-left:15px;
    margin-top:15px;
    text-align: center;
    width: 300px;
    height: 300px;
    border: 1px solid #DCDFE6;
    background: #fff;
    padding: 10px 0px 0px 10px;
    img {
        width: 300px;
        height: 300px;
        background-color: #fff; //设置白色背景色
        padding: 6px; // 利用padding的特性，挤出白边
        box-sizing: border-box;
    }
  }
  .authDesc{
    width:calc(100% - 340px);
    margin-top:15px;
    margin-left:15px;
    .stepState{
      font-size:17px;
      color:#303133;
      font-weight: 700;
      margin-bottom: 10px;
    }
    .stepCon{
      margin-bottom:10px;
      font-size:15px;
      color:#303133;
      text-align: justify;
    }
    .checkRefuseTip{
      color: #303133;
      font-size:15px;
    }
  }
  .inputcode{
    width:calc(100% - 15px);
    margin-left: 15px;
    ::v-deep .el-textarea__inner{
      height: 250px!important;
    }
  }
}
.imgStorage{
  width:50%;
}
.officeManage{
  width:50%;
}
.ewcssManage{
  width:50%;
}
.aim{
  width:50%;
}
.copyText{
  text-decoration: underline;
  color:#0a70b0;
}
.copyText:hover{
  font-weight: 700;
}
</style>
