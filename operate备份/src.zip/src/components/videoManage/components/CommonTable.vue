<template>
<!-- 表格： 可通过后台返回控制table显示某列 及自定义宽度 -->
  <div>
    <template v-for="(item, index) in propData">
      <el-table-column
        v-if="item.prop == 'archive_state'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
          <template  slot-scope="scope">
            <!---archive_state: 0 为 未开始   -1  存档失败   -2  已删除   2 存档中  3 已存档 --->
            <span class="stateDesc stateNo" v-if="scope.row.archive_state == 0">{{scope.row.archive_state_describe}}</span>
            <span class="stateDesc stateFail" v-if="scope.row.archive_state == -1">{{scope.row.archive_state_describe}}</span>
            <span class="stateDesc stateFail" v-if="scope.row.archive_state == -2">{{scope.row.archive_state_describe}}</span>
            <span class="stateDesc stateArchiveing" v-if="scope.row.archive_state == 2">{{scope.row.archive_state_describe}}</span>
            <span class="stateDesc" v-if="scope.row.archive_state == 3">{{scope.row.archive_state_describe}}</span>
          </template>
      </el-table-column>

      <el-table-column
        v-else-if="item.prop == 'content'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
           <span v-html="$replaceRN(scope.row.content)"></span>
          </template>
      </el-table-column>
      
      <el-table-column
        v-else-if="item.prop == 'type'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
          <span>{{scope.row.type  | getSystemName(allType)}}</span>
        </template>
      </el-table-column>

      <!--所属系统-->
      <el-table-column
        v-else-if="item.prop == 'source_system'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
          <span class="">{{scope.row.source_system | getSystemName(businessSystem)}}</span>
        </template>
      </el-table-column>

      <!--所属业务-->
       <el-table-column
        v-else-if="item.prop == 'kind'"
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
        <template  slot-scope="scope">
          <span class="">{{scope.row.kind | getBussessName(scope.row.source_system,businessSystem)}}</span>
        </template>
      </el-table-column>

      <el-table-column
        v-else
        :key="index"
        :prop="item.prop"
        :label="item.label"
        :width="item.width"
        :sortable="item.sortable"
        :render-header="item.renderHeader"
        :formatter="item.formatter"
        :show-overflow-tooltip="true"
        align="left">
      </el-table-column>
    </template>
  </div>
</template>
<script>
import mixin from '@/utils/mixin/intelligentDiagnosis'
import { downLoadOfficialFile } from '@/api/platform_operate/systemset'
export default {
  name: 'CommonTable',
  props: {
    propData: Array,
    businessSystem: Array,
  },
  mixins: [mixin],
  methods: {
    async downLoadFile (id, fileName) {
      const param = { id: id }
      const result = await downLoadOfficialFile(param)
      if (result) {
        let index = fileName.lastIndexOf('.')
        // 获取文件类型
        let type = fileName.substring(index)
        let blob = new Blob([result], {
            //下载的文件类型；
            type: `application/${type}`
        })
        if (window.navigator.msSaveOrOpenBlob) {
            navigator.msSaveBlob(blob, fileName)
            navigator.msSaveBlob(blob)
        } else {
            var link = document.createElement('a')
            link.href = window.URL.createObjectURL(blob)
            link.download = fileName
            link.click()
            window.URL.revokeObjectURL(link.href) //释放内存
        }
      }else {
        self.$message({
          type: 'info',
          message: `${result.msg}`
        })
      }
    }
  },
  filters:{
    // 根据code 获取系统名称
    getSystemName (code,businessTypeArr) {
      let systemName = ''
      businessTypeArr.forEach((item) => {
        if (item.code === code) {
          systemName = item.name
        }
      })
      return systemName
    },
    // 根据code 和kind 去获取某个系统下的 业务
    getBussessName (code, curSystemCode, businessTypeArr) {
      let businessArr = []
      let businessName = ''
      businessTypeArr.forEach((item) => {
        if (item.code === curSystemCode) {
          businessArr = item.business
        }
      })
      businessArr.forEach((one) => {
        if (code == one.code) {
          businessName = one.name
        }
      })
      return businessName
    }
  }
}
</script>
<style lang="less">
.downLoadTemp {
    color: #0a70b0;
    text-decoration: underline;
    cursor: pointer;
}
.stateDesc{
  font-size:14px;
  color:#606266;
}
.stateNo{
  color:#FF9900;
}
.stateFail{
  color:#DA4A4A;
}
.stateArchiveing{
  color:#1C8BE4;
}
</style>
