<template>
  <div class="userinfo">
    <div class="userinfo-title">
      <div class="archiveStateCon">
        <span class="archiveState" :class="{'archiveFail':videoDataInfor.state == -1 }">{{videoDataInfor.state_describe}}</span>
        <span class="userinfo-titleinfo">{{videoDataInfor.subject}}</span>
      </div>
      
      <span
        @click="closeFn"
        class="close-btn iconfont iconchuangjianshibai"
      ></span>
    </div>
    <el-form
      ref="formInfo"
      label-width="90px"
      class="demo-ruleForm"
    >
      <div class="contaner">
        <div class="contaner-info">
          <el-row class="basicInfor">
            <el-col :span="12" class="videoFormItem">
                <el-form-item label="会议名称：">
              <div :title="videoDataInfor.subject">{{videoDataInfor.subject}}</div>
            </el-form-item>
            </el-col>
            
            <el-col :span="12" class="videoFormItem">
              <el-form-item class="" label="所属客户：">
              <div :title="videoDataInfor.tenancy_name">{{videoDataInfor.tenancy_name}}</div>
            </el-form-item>
            </el-col>
            
            <el-col :span="12" class="videoFormItem">
              <el-form-item class="" label="所属系统：">
                <div>{{videoDataInfor.source_system | getSystemName(businessSystem)}}</div>
              </el-form-item>
            </el-col>

            <el-col :span="12" class="videoFormItem">
              <el-form-item class="" label="业务类型：">
                 <div>{{videoDataInfor.kind | getBussessName(videoDataInfor.source_system,businessSystem)}}</div>
              </el-form-item>
            </el-col>
            
            
          </el-row>
        </div>

        <div class="contaner-info-title">
            <div class="detailTitleBox"><span class="border-left"></span><span class="detailTitle">视频文件</span></div>
            <div class="btnCon flex">
              <span
                class="userListoperate-btn delBtn mr15"
                @click="delAllOriginVideo()"
                >全部删除</span
                >
             <span
                class="userListoperate-btn allArchiveBtn"
                @click="allArchive()"
                >全部存档</span
                >
            </div>
            
            <!-- <div class="btnCon flex">
             <span
                class="userListoperate-btn clr_red border mr15"
                v-if="videoDataInfor.state == 3"
                @click="delAllOriginVideo()"
                >全部删除</span
                >
             <span
                v-if="videoDataInfor.state == 0"
                class="userListoperate-btn clr_0a border"
                @click="allArchive()"
                >全部存档</span
                >
            </div> -->
        </div>
        <div
            class="allOriginalVideo clear"
            v-bind:class="{'noTableData':videoDataInfor.records.length==0}"
            >
             <el-table :data="videoDataInfor.records"
              height="100%"
              ref="tableAutoScroll"
              highlight-current-row
              border
              stripe
              header-row-class-name="strong">
              <el-table-column
                fixed="left"
                align="center"
                type="index"
                label="序号"
                width="55">
               </el-table-column>
               <el-table-column label="操作" width="100" fixed="left">
                    <template slot-scope="scope">
                      <span class="clr_da pointer pl10" @click="readyDelOneVideo(scope.row.id)">删除</span>
                   </template>
                </el-table-column>
              <common-table :propData="originalVideoPropData"/>
            </el-table>
        </div>


        <div class="contaner-info-title">
            <div class="detailTitleBox"><span class="border-left"></span><span class="detailTitle">操作日志</span></div>
        </div>
        <div
            class="allOriginalVideo clear"
            v-bind:class="{'noTableData':videoDataInfor.logs.length==0}"
            >
             <el-table :data="videoDataInfor.logs"
              height="100%"
              ref="tableAutoScroll"
              highlight-current-row
              border
              stripe
              header-row-class-name="strong">
              <el-table-column
                fixed="left"
                align="center"
                type="index"
                label="序号"
                width="55">
               </el-table-column>
              <common-table :propData="unloadingVideoPropData"/>
            </el-table>
        </div>

      </div>
    </el-form>
  </div>
</template>
<script>
import CommonTable from './CommonTable'
import { getVedioList, beganDeleteVideo, getVideoDetail } from '@/api/platform_costomer/systemOperation'
export default {
  components: {
    CommonTable
  },
  props: {
    pacsinfo: Object,
    pageInfo: Object,
    businessSystem: Array,
  },
  data() {
    return {
      pageLayout: "total, prev, pager, next, jumper",
      videoDataInfor: {
        logs: [],
        records: []
      },
      originalVideoPropData: [
        { prop: 'archive_state_describe', label: '存档状态', width: 90 },
        { prop: 'file_name', label: '文件名称', width: 280 },
        { prop: 'file_size', label: '文件大小' },
      ],
      unloadingVideoPropData: [
        { prop: 'type_describe', label: '类型', width: 90 },
        { prop: 'content', label: '操作内容', width: 280 },
        { prop: 'operator_name', label: '操作人', width: 90 },
        { prop: 'operator_time', label: '操作时间' },
      ],
    };
  },
  methods: {
    // 获取视频文件详情
    async beganGetVideoDetail (row) {
      const self = this
      const res = await getVideoDetail({business_id: row.business_id})
      if (res.code === 0) {
        self.videoDataInfor = res.data
      } else {
        self.$message.error(res.msg)
      }
    },
    readyDelOneVideo (row) {
      let name = row.subject
      this.$confirm(
        '<i class="iconfont icontishi clr_e6 mr5"></i>是否确定要删除' +'"' + name +'"'+'文件',
        "提示",
        {
          distinguishCancelAndClose: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
        }
      ).then(() => {
        this.deleteOneVideo(row.id);
      });
    },
    // 删除某个会议里面 某个文件
    async deleteOneVideo(id) {
      const self = this
      const _parmas = {
        id: id,
      };
      const res = await beganDeleteVideo(_parmas);
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: "删除成功！",
        });
        if (self.videoDataInfor.records.length != 0) {
          self.videoDataInfor.records.forEach((item,i) => {
            if (item.id == id) {
              self.videoDataInfor.records.splice(i,1)
            }
          })
        }
      } else {
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    // 删除所有原始视频文件
    delAllOriginVideo () {
      this.$emit('readyDelOneVideo',this.videoDataInfor)
    },
    // 全部存档
    allArchive () {
      this.$emit('allArchive',this.videoDataInfor)
    },
    closeFn() {
      this.$emit("closeFn");
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    ChoiceOrganFn(type) {
      this.$emit("ChoiceOrganFn", type);
    },
  },
  filters:{
    // 根据code 获取系统名称
    getSystemName (code,businessTypeArr) {
      let systemName = ''
      businessTypeArr.forEach((item) => {
        if (item.code === code) {
          systemName = item.name
        }
      })
      return systemName
    },
    // 根据code 和kind 去获取某个系统下的 业务
    getBussessName (code, curSystemCode, businessTypeArr) {
      let businessArr = []
      let businessName = ''
      businessTypeArr.forEach((item) => {
        if (item.code === curSystemCode) {
          businessArr = item.business
        }
      })
      businessArr.forEach((one) => {
        if (code == one.code) {
          businessName = one.name
        }
      })
      return businessName
    }
  }
};
</script>
<style lang="less" scoped>
.userinfo {
  width: 800px;
  padding-left:30px;
  padding-right:20px;
  .userinfo-title {
    position: relative;
    width: 100%;
    height: 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .archiveState{
      padding: 5px 10px;
      background:#E6A23C;
      color:#fff;
      font-size:14px;
      margin-right:10px;
      border-radius: 3px;
    }
    .archiveFail{
      background:#F56C6C;
    }
    .userinfo-titleinfo {
      font-size: 18px;
      color: #303133;
      font-weight: 700;
    }
    .close-btn {
      color: #9facc3;
      font-size: 24px !important;
      cursor: pointer;
    }
  }
  .contaner {
    height: calc(100vh - 60px);
    .contaner-info {
      .basicInfor{
        width:100%;
        height: 80px;
        padding: 8px 0;
        border-radius: 3px; 
        ::v-deep .videoFormItem{
          .el-form-item__label{
            font-size:15px;
            color:#888888;
            line-height: 32px;
            padding-right: 0!important;
          }
          .el-form-item__content{
            line-height: 32px;
            font-size: 15px;
            overflow:hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
        }
      }
      .instituteInfor {
        border-top: 1px dashed #dcdfe6;
      }
      ::v-deep .el-form-item {
        margin-bottom: 0px!important;
      }
    }
  }
 .contaner-info-title {
    width:100%;
    height: 48px;
    color: #1f2f3d;
    display: flex;
    align-items: center;
    justify-content: space-between;
    .border-left {
        width: 3px;
        height: 14px;
        background: rgba(9, 113, 176, 1);
        margin-right: 7px;
    }
    .detailTitleBox{
      display: flex;
      align-items: center;
      .detailTitle{
        color:#303133;
        font-size:15px;
        font-weight: 700;
      }
    }
    
    .userListoperate-btn{
      // line-height: 28px;
      padding: 4px 10px;
      border-radius: 3px;
      font-size: 15px;
      cursor: pointer;
    }
    .delBtn{
      background:#F56C6C;
      color:#fff;
    }
    .allArchiveBtn{
      background:#0a70b0;
      color:#fff;
    }
  }
  ::v-deep .allOriginalVideo{
    height: calc(50% - 93px);
    // border: 1px solid #EBEEF5;
    .el-table{
      height:100%;
      .el-table__body-wrappe{
        height:calc(100% - 40px);
        overflow: auto;
      }
    }
  }
  .bg_e6 {
    background: #e6a23c;
  }
  .bg_f5 {
    background: #f56c6c;
  }
  .bg_0c {
    background: #0c83cd;
  }
  .bg_00 {
    background: #00ad78;
  }
  .w_300 {
    width: 300px;
  }
}
</style>
