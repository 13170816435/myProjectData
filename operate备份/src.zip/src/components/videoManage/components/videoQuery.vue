<template>
  <div class="inspectRecord-query">
          <div class="search-bar mb10">
            <div class="searchTop mb10">
              <div class="fl mr10">
                <span class="search-bar-label fl">所属系统 :</span>
                <el-select
                    @change="changeSystem"
                    filterable
                    v-model="searchData.source_system"
                    placeholder="全部"
                    class="ele-select_32 width_200_select"
                    style="width:200px"
                >
                <el-option value="">全部</el-option>
                    <el-option
                    v-for="(item,index) in businessSystem"
                    :key="index"
                    :label="item.name"
                    :value="item.code"
                    ></el-option>
                </el-select>
              </div>
             
              <div class="fl mr10">
                <span class="search-bar-label fl">业务类型 :</span>
                <el-select
                    @change="search"
                    v-if="searchData.source_system=== 'operate' || searchData.source_system=== 'telemed' "
                    v-model="searchData.kind"
                    placeholder="全部"
                    class="ele-select_32 width_200_select"
                    style="width:200px"
                >
                <el-option value="">全部</el-option>
                    <el-option
                    v-for="(item,index) in businessModule"
                    :key="index"
                    :label="item.name"
                    :value="item.code"
                    ></el-option>
                </el-select>
                <el-select
                    @change="search"
                    v-else
                    v-model="searchData.kind"
                    placeholder="全部"
                    class="ele-select_32 width_200_select"
                    style="width:200px"
                >
                <el-option value="">全部</el-option>
                    <el-option
                    v-for="(item,index) in businessModule"
                    :key="index"
                    :label="item.name"
                    :value="item.code"
                    ></el-option>
                </el-select>
              </div>
              <div class="fl mr15" v-if="role =='operate'">
                <span class="search-bar-label accountLabel fl">会议名称 :</span>
                <el-input class="fl width_200_input" v-on:keyup.enter.native=search v-model="searchData.subject"  placeholder="请输入会议名称"></el-input>
              </div>
            </div>
            <div class="serachBar-bottom mb10">
              <div class="fl mr10">
                <span class="search-bar-label fl">存档状态 :</span>
                <el-select
                    @change="search"
                    filterable
                    v-model="searchData.state"
                    placeholder="全部"
                    class="ele-select_32 width_200_select"
                    style="width:200px"
                >
                <el-option value="">全部</el-option>
                    <el-option
                    v-for="(item,index) in archiveStateArr"
                    :key="index"
                    :label="item.name"
                    :value="item.value"
                    ></el-option>
                </el-select>
              </div>
              <div class="fl mr15" v-if="role =='operate'">
                <span class="search-bar-label fl">所属客户 :</span>
                <el-select
                    @change="search"
                    filterable
                    v-model="searchData.tenancy_id"
                    placeholder="全部"
                    class="ele-select_32 width_200_select"
                    style="width:200px"
                >
                <el-option value="">全部</el-option>
                    <el-option
                    v-for="(item,index) in customerList"
                    :key="index"
                    :label="item.name"
                    :value="item.id"
                    ></el-option>
                </el-select>
              </div>
              <div class="fl mr15" v-if="role =='customer'">
                <span class="search-bar-label accountLabel fl">会议名称 :</span>
                <el-input class="fl width_200_input" v-on:keyup.enter.native=search v-model="searchData.subject"  placeholder="请输入会议名称"></el-input>
              </div>
              <div class="fl operateBtnDiv">
                <el-button type="primary" size="small" @click="search">查询</el-button>
                <el-button size="small" plain @click="resetSearch">重置</el-button>
              </div>
            </div>
        </div>
  </div>
</template>
<script>
import { getBusinessParam } from '@/api/platform_operate/operateUser'
import { getInstitutionListLite } from '@/api/commonHttp'
import { getTenanciesLiteFn } from '@/api/platform_operate/costomer'
export default {
  props: {
    businessSystem: Array,
    optionsMouduleArr: Array,
    allModule: Array,
    archiveStateArr: Array,
  },
  inject: ['role'],
  data () {
    return {
      businessModule: [],
      customerList: [],
      searchData: {
        source_system: '',
        kind: '',
        state: '',
        subject: '',
        tenancy_id: '',
        offset: 1,
        limit: 20,
        sorts: []
      },
    }
  },
  methods: {
    // 重置
    resetSearch () {
      this.searchData = {
        source_system: '',
        kind: '',
        state: '',
        subject: '',
        tenancy_id: '',
        offset: 1,
        limit: 20,
        sorts: []
      }
      this.$emit('getList', this.searchData)
    },
    handleChange (value) {
      console.log(value)
    },
    // 搜索
    search () {
      this.searchData.offset = 1
      this.searchData.limit = 20
      this.$emit('getList', this.searchData)
    },
    // 获取系统对应 的所属业务
    changeSystem (val) {
      const self = this
      self.searchData.kind = ''
      if (self.businessSystem.length != 0) {
        self.businessSystem.forEach((item) => {
          if (item.code == val) {
            self.businessModule = item.business
          }
        })
      }
      this.search()
    },
    // 客户列表
    async getMyCustomer() {
      const res = await getTenanciesLiteFn();
      if (res.code === 0) {
        this.customerList = res.data;
      } else {
        this.customerList = [];
        this.$message({ type: "error", message: res.msg });
      }
    },
  },
  created () {
    // 获取所属客户
    this.getMyCustomer('') 
  },
  mounted () {
    this.search()
  }
}
</script>
<style lang="less" scoped>
.ml24{
  margin-left:24px;
}
.addPd{
  padding: 0 7px;
}
.search-bar {
  line-height: initial!important;
}
.inspectRecord-query{
  // padding: 15px 15px;
  padding-bottom:0px;
  padding-top:0px;
  .searchTop, .serachBar-bottom{
    min-height:32px;
  }
  .search-bar .addPadding{
    padding: 0 9px;
  }
  .search-bar .statusLabel{
    width:39px!important;
    min-width: 39px;
    text-align: left!important;
  }
  .search-bar-label {
    line-height: 32px;
  }
}
</style>
