<template>
  <div class="videoTotalBox">
    <div class="archivesCon mr10">
      <div class="totalContent">
        <div class="totalContentTit">存档文件
          <el-popover
            placement="top-start"
            popper-class="organTipPopover"
            title=""
            width="400"
            trigger="hover"
            content="存档文件是通过系统自动人为手工转存到存储设备上的视频文件。可以长期保存和管理"
            >
            <el-button class="tipButton" slot="reference"><i class="iconfont tipIcon">&#xe720;</i></el-button>
          </el-popover>
        </div>
        <div class="totalContentVal">
           <span class="totalNum">324.75</span>
           <span class="totalUnit">GB</span>
        </div>
      </div>
      <div class="totalItem ml40 mr40">
        <div class="totalItemTit">无原始</div>
        <div class="totalItemVal">
           <span class="totalItemNum">324.75</span>
           <span class="totalItemUnit">GB</span>
        </div>
      </div>
      <div class="totalItem">
        <div class="totalItemTit">有原始</div>
        <div class="totalItemVal">
           <span class="totalItemNum">324.75</span>
           <span class="totalItemUnit">GB</span>
        </div>
      </div>
    </div>
    <div class="originalFileCon">
      <div class="totalContent">
        <div class="totalContentTit">原始文件其它
          <el-popover
            placement="top-start"
            popper-class="organTipPopover2"
            title=""
            width="600"
            trigger="hover"
            content="原始文件是指由视频会议功能产生的,存放在视频会议服务器磁盘上的视频文件。
            当服务器磁盘占用过高时,会影响视频会议服务的正常使用。在系统自动或人为手工做好文件存档后,
            建议手工及时清理原始文件。其它指应用文件、未知文件的占用空间。"
            >
            <el-button class="tipButton" slot="reference"><i class="iconfont tipIcon">&#xe720;</i></el-button>
          </el-popover>
        </div>
        <div class="totalContentVal">
           <span class="totalNum">324.75</span>
           <span class="totalUnit">GB</span>
        </div>
      </div>
      <div class="totalItem ml40 mr40">
        <div class="totalItemTit">无原始</div>
        <div class="totalItemVal">
           <span class="totalItemNum">324.75</span>
           <span class="totalItemUnit">GB</span>
        </div>
      </div>
      <div class="totalItem">
        <div class="totalItemTit">有原始</div>
        <div class="totalItemVal">
           <span class="totalItemNum">324.75</span>
           <span class="totalItemUnit">GB</span>
        </div>
      </div>
    </div>
    <div class="originalFileCon cdTotal">
      <div class="totalContent">
        <div class="totalContentTit">磁盘总容量</div>
        <div class="totalContentVal">
           <span class="totalNum">324.75</span>
           <span class="totalUnit">GB</span>
        </div>
      </div>
      <div class="totalItem ml40 mr40">
        <div class="totalItemTit">磁盘使用率</div>
        <div class="totalItemVal">
           <span class="totalItemNum">324.75</span>
           <span class="totalItemUnit">GB</span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    
  },
  data () {
    return {

    }
  } 
}
</script>
<style lang="less" scoped>
.videoTotalBox{
  display: flex;
  margin-bottom: 10px;
  .totalContent{
    display: flex;
    flex-flow: column;
    justify-content: space-between;
    ::v-deep .totalContentTit{
      line-height: 20px;
      font-size:15px;
      color:#303133;
      .tipButton{
        padding:0px;
        border:none;
        color:#C0C4CC;
        background:#e3f2fd;
      }
    }
    .totalContentVal{
      .totalNum{
        font-size:30px;
        font-weight: 700;
        color:#303133;
        font-family: Arial;
      }
      .totalUnit{
        font-size:15px;
        color:#303133;
      }
    }
  }
  .totalItem{
    margin-top:15px;
    .totalItemTit{
      font-size:14px;
      color:#909399;
      line-height: 20px;
      margin-bottom: 5px;
    }
    .totalItemVal{
      .totalItemNum{
        font-size:15px;
        font-weight: 700;
        color:#303133;
        font-family: Arial;
      }
      .totalItemUnit{
        font-size:15px;
        color:#303133;
      }
    }
  }
  .archivesCon{
    padding: 15px 20px;
    display: flex;
    height: 92px;
    border-radius: 3px;
    background: #e3f2fd;
  }
  .originalFileCon{
    padding: 15px 20px;
    display: flex;
    height: 92px;
    background: #FFF3E0;
    border-top-left-radius: 3px;
    border-bottom-left-radius: 3px;
  }
  .cdTotal{
    border-left:1px solid #DCDFE6;
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
  }
}
</style>