<template>
   <div class="videoManageCon">
      <div class="title-bar flex_row">
          <div class="crumbsCon">
            <span class="title-name clr_303">
              <i class="iconfont icondingwei mr5"></i>{{role == 'customer' ? '系统运维' : '数据存储'}}
              <i class="iconfont iconzhankaishouqi"></i> 会议录屏
            </span>
            <div class="m-tab ml30">
              <div
                class="m-tab-item"
                :class="tabIndex === index ? 'm-tab-item-active' : ''"
                v-for="(item, index) in tabList"
                :key="index"
                @click="toggleTab(index, item.value)"
              >
                {{ item.label }}
              </div>
              <div class="tab-line" :style="{ left: number + 'px' }"></div>
            </div>
            </div>

            <!-- <div class="tr col" v-if="tabType == 1">
              <span key=""class="userListoperate-btn"@click="moreDelVideo()">批量删除原始文件</span>
            </div> -->
        </div>
        <div class="inspectCon" v-if="tabType == 1">
          <!-- <div class="videoTotal">
            <videoTotal></videoTotal>
          </div> -->
          <div class="searchDiv">
            <videoQuery @getList="getList" :businessSystem="businessSystem" :archiveStateArr="baseInfo.meeting_record_archive_state"></videoQuery>
          </div>
          <div
            class="allInspect videoTableDiv clear"
            v-loading="loading"
            element-loading-text="拼命加载中"
            element-loading-background="rgba(255,255,255,0.6)"
            v-bind:class="{'noTableData':tableData.length==0}"
            >
            <el-table :data="tableData" border stripe
              :height="tableheight"
              ref="videoTable"
              highlight-current-row
              :row-key="rowKey"
              header-row-class-name="strong">
             <!-- <el-table :data="tableData" border stripe
              height="100%"
              ref="videoTable"
              highlight-current-row
              :row-key="rowKey"
              @selection-change="handleSelectionChange"
              header-row-class-name="strong">
              <el-table-column type="selection" v-bind:reserve-selection="true" :selectable='selectEnable' width="48"></el-table-column> -->
              <el-table-column
                fixed="left"
                align="center"
                type="index"
                label="序号"
                width="55">
                  <template slot-scope="scope">
                      <span>{{(searchData.offset - 1) * searchData.limit + scope.$index + 1}}</span>
                  </template>
               </el-table-column>
               <el-table-column label="操作" width="120" fixed="left">
                    <template slot-scope="scope">
                      <span class="clr_0a pointer" @click="watchVideoDetail(scope.row)">查看</span>
                      <!-- <span class="clr_0a pointer pl10" @click="beganArchiving(scope.row)">开始存档</span> -->
                      <span class="clr_0a pointer pl10" v-if="scope.row.state == -1 || scope.row.state == -2" @click="reArchiving(scope.row)">重新存档</span>
                      <span class="clr_da pointer pl10" v-if="scope.row.state == 3" @click="readyDelOneVideo(scope.row)">删除存档</span>
                      <!-- <el-popover placement="right" width="118" class="" trigger="click">
                        <div class="moreOperateDiv">
                          <div
                            class="oneOperateBtn"
                            @click="readyDelOneVideo(scope.row)"
                          >
                            删除原始文档
                          </div>
                          <div
                            class="oneOperateBtn"
                            @click="readyDelOneVideo(scope.row)"
                          >
                            删除存档文档
                          </div>
                        </div>
                        <span class="clr_da pointer pl10" slot="reference">删除<i class="iconfont iconxialazhankai"></i></span>
                      </el-popover> -->
                   </template>
                </el-table-column>




              <el-table-column prop="subject" label="会议名称" width="280" :show-overflow-tooltip="true"></el-table-column>
              <el-table-column prop="attach_count" label="文件数量" width="90" :show-overflow-tooltip="true"></el-table-column>
              <el-table-column prop="file_size" label="文件大小" width="105" sortable :show-overflow-tooltip="true"></el-table-column>
              <el-table-column prop="state" label="存档状态" width="90" :show-overflow-tooltip="true">
                <template  slot-scope="scope">
                   <!---state: 0 为 未开始   -1  存档失败   -2  已删除   2 存档中  3 已存档 --->
                  <span class="stateDesc stateNo" v-if="scope.row.state == 0">{{scope.row.state_describe}}</span>
                  <span class="stateDesc stateFail" v-if="scope.row.state == -1">{{scope.row.state_describe}}</span>
                  <span class="stateDesc stateFail" v-if="scope.row.state == -2">{{scope.row.state_describe}}</span>
                  <span class="stateDesc stateArchiveing" v-if="scope.row.state == 2">{{scope.row.state_describe}}</span>
                  <span class="stateDesc" v-if="scope.row.state == 3">{{scope.row.state_describe}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="start_time" label="开始下载时间" width="170" :show-overflow-tooltip="true"></el-table-column>
              <el-table-column prop="tenancy_name" label="所属客户" width="180" :show-overflow-tooltip="true"></el-table-column>
              <el-table-column prop="source_system" label="所属系统" width="140" :show-overflow-tooltip="true">
                <template  slot-scope="scope">
                  <span class="">{{scope.row.source_system | getSystemName(businessSystem)}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="kind" label="所属业务" width="140" :show-overflow-tooltip="true">
                <template  slot-scope="scope">
                  <span class="">{{scope.row.kind | getBussessName(scope.row.source_system,businessSystem)}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="archive_time" label="存档时间" :show-overflow-tooltip="true"></el-table-column>
              <!-- <common-table :propData="propData" :businessSystem="businessSystem"/> -->
            </el-table>
        </div>
        <div class="blockPage">
            <pagination-tool :total="totalVideoCount" :page.sync="searchData.offset" :limit.sync="searchData.limit" @pagination="beganGetVideoList"/>
          </div>
        </div>

        <div class="inspectCon" v-if="tabType == 2">
          <div class="logSearchDiv">
            <div class="flex mr10">
                <span class="search-bar-label">操作类型 :</span>
                <el-select
                    @change="beganGetOperateLogList"
                    filterable
                    v-model="searchLogData.type"
                    placeholder="全部"
                    class="ele-select_32 width_200_select"
                    style="width:200px"
                >
                <el-option value="">全部</el-option>
                    <el-option
                    v-for="(item,index) in baseInfo.meeting_record_log_type"
                    :key="index"
                    :label="item.name"
                    :value="item.value"
                    ></el-option>
                </el-select>
              </div>
              <div class="mr15">
                <span class="search-bar-label accountLabel fl">会议名称 :</span>
                <el-input class="fl width_200_input" v-on:keyup.enter.native=beganGetOperateLogList v-model="searchLogData.subject"  placeholder="请输入会议名称"></el-input>
              </div>
              <div class="operateBtnDiv">
                <el-button type="primary" size="small" @click="searchOperateLogList">查询</el-button>
                <el-button size="small" plain @click="resetSearchLogData">重置</el-button>
              </div>
          </div>
          <div
            class="allInspect clear operateLogTableDiv"
            v-loading="loading"
            element-loading-text="拼命加载中"
            element-loading-background="rgba(255,255,255,0.6)"
            v-bind:class="{'noTableData':tableLogData.length==0}"
            >
             <el-table :data="tableLogData" border stripe
              :height="tableheight"
              ref="vedioLogTable"
              highlight-current-row
              :default-sort="{prop: 'operator_time', order: 'descending'}"
              header-row-class-name="strong">
              <el-table-column
                fixed="left"
                align="center"
                type="index"
                label="序号"
                width="55">
                  <template slot-scope="scope">
                      <span>{{(searchLogData.offset - 1) * searchLogData.limit + scope.$index + 1}}</span>
                  </template>
               </el-table-column>
              <common-table :propData="logPropData" :businessSystem="businessSystem"/>
            </el-table>
        </div>
        <div class="blockPage">
            <pagination-tool :total="totalVideoLogCount" :page.sync="searchLogData.offset" :limit.sync="searchLogData.limit" @pagination="beganGetOperateLogList"/>
          </div>
        </div>

     <el-drawer
      size="880"
      :modal="false"
      :visible.sync="showVideoDetail"
      :show-close="false"
      :withHeader="false"
      :wrapperClosable="false"
      :direction="direction"
      :before-close="handleClose"
    >
      <videoDetail ref="videoDetail" :businessSystem="businessSystem" @readyDelOneVideo="readyDelOneVideo" @allArchive="reArchiving" @closeFn="closeFn"></videoDetail>
    </el-drawer>

   </div>
</template>
<script>
import { mapGetters } from 'vuex'
import videoTotal from './components/videoTotal'
import videoQuery from './components/videoQuery'
import CommonTable from './components/CommonTable'
import videoDetail from './components/videoDetail'
import PaginationTool from '@/components/common/PaginationTool' // 分页
import { getBusinessType } from "@/api/commonHttp";
import { getVideoList, beganDeleteVideo, getVideoLogList, reArchivingVideo } from '@/api/platform_costomer/systemOperation'

export default {
  components: {
    videoTotal,
    videoQuery,
    CommonTable,
    PaginationTool,
    videoDetail,
  },
  props: {
    role:String
  },
  computed: {
    ...mapGetters({ // 获取store查询枚举条件
      baseInfo: 'enumerations'
    })
  },
  data () {
    return {
      tabIndex: 0,
      number: 0,
      tabType: 1,
      tableheight: '100%',
      tabList: [
        {
          label: "视频文件管理",
          value: 1,
        },
        {
          label: "操作日志",
          value: 2,
        },
      ],
      searchData: {
        clientKind: '',
        applicationKind: '',
        mySystem: '',
        institution_id : '',
        tenancy_id: '',
        login_name: '',
        offset: 1,
        limit: 20
      },
      searchLogData: {
        type: '',
        subject: '',
        offset: 1,
        limit: 20,
        sorts: ['operator_time|desc']
      },
      direction: "rtl",
      showVideoDetail: false,
      choosedTableData: [],
      businessSystem: [],
      optionsMouduleArr: [],
      tableData: [],
      totalVideoCount: 0,
      tableLogData: [],
      totalVideoLogCount: 0,
      loading: false,
      // 表头字段
      propData: [
        { prop: 'subject', label: '会议名称', width: 280 },
        { prop: 'attach_count', label: '文件数量', width: 90 },
        { prop: 'file_size', label: '文件大小', width: 105, sortable: true,},
        { prop: 'state', label: '存档状态', width: 90 },
        { prop: 'archive_time', label: '存档时间', width: 170 },
        { prop: 'tenancy_name', label: '所属客户', width: 180 },
        { prop: 'source_system', label: '所属系统', width: 140 },
        { prop: 'kind', label: '所属业务' },
      ],
      logPropData: [
        { prop: 'source_system', label: '所属系统', width: 140 },
        { prop: 'kind', label: '所属业务', width: 120 },
        { prop: 'subject', label: '会议名称', width: 280 },
        { prop: 'type_describe', label: '类型', width: 90 },
        { prop: 'content', label: '操作内容', width: 608 },
        { prop: 'operator_name', label: '操作人', width: 90 },
        { prop: 'operator_time', label: '操作时间',sortable: true,},
      ],
    }
  },
  methods: {
    toggleTab(index, value) {
      this.tabType = value;
      if (this.tabIndex < index) {
        this.number = index * 95; //95既是一个tab的宽度 也是tab下滑动横线的宽度
      } else {
        this.number = this.number - (this.tabIndex - index) * 95; // 10为tab之前的margin值 下面样式有设置
      }
      if (this.tabIndex != index) {
        if (this.tabType == 1) {
          // 视频会议文件列表
          this.beganGetVideoList();
        } else if (this.tabType == 2) {
          // 操作日志
          this.beganGetOperateLogList()
        }
      }
      this.tabIndex = index;
    },
    resetSearchLogData() {
      this.searchLogData = {
        type: '',
        subject: '',
        offset: 1,
        limit: 20,
        sorts: ['operator_time|desc']
      }
      this.beganGetOperateLogList()
    },
    searchOperateLogList () {
      this.searchLogData.offset = 1
      this.searchLogData.limit = 20
      this.beganGetOperateLogList()
    },
    selectEnable(row, rowIndex) {
      if (row.is_allow_upgrade) {
        return true
      }
    },
    handleClose(done) {
      done();
    },
    closeFn () {
      this.showVideoDetail = false
    },
    rowKey (row) {
      return row.id
    },
    getList (obj) {
      this.searchData  = obj
      this.beganGetVideoList()
    },
    // 删除文件
    async deleteTheseVideo(id) {
      const _parmas = {
        id: id,
      };
      const res = await beganDeleteVideo(_parmas);
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: "删除成功！",
        });
        this.beganGetVideoList();
      } else {
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    moreDelVideo () {
      const self = this
      if (self.choosedTableData.length == 0) {
        self.$message({ message: '请至少选择一个会议视频', type: 'error' })
        return false
      }
      self.$confirm(
          '<i class="iconfont icontishi clr_e6 mr5"></i>是否确定要删除这些文件',
          "提示",
          {
            distinguishCancelAndClose: true,
            dangerouslyUseHTMLString: true,
            confirmButtonText: "确定",
            cancelButtonText: "取消",
          }
        ).then(() => {
          self.deleteTheseVideo();
        });
    },
    // 批量选择方法
    handleSelectionChange (arr) {
      const self = this
      self.choosedTableData = arr
    },
    watchVideoDetail (row) {
      const self = this
      self.showVideoDetail = true
      self.$nextTick(() => {
        self.$refs.videoDetail.beganGetVideoDetail(row)
      })
    },
    // 重新存档
    async reArchiving (row) {
      const _parmas = {
        business_id: row.business_id,
      };
      const res = await reArchivingVideo(_parmas);
      if (res.code === 0) {
        this.$message({ type: "success",message: "重新存档成功！",});
        this.beganGetVideoList();
      } else {
        this.$message({ type: "error",message: res.msg,});
      }
    },
    readyDelOneVideo (row) {
      let name = row.subject
      this.$confirm(
        '<i class="iconfont icontishi clr_e6 mr5"></i>是否确定要删除' +'"' + name +'"'+ '文件',
        "提示",
        {
          distinguishCancelAndClose: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
        }
      ).then(() => {
        this.deleteOneVideo(row);
      });
    },
    // 删除文件
    async deleteOneVideo(row) {
      const _parmas = {
        business_id: row.business_id,
      };
      const res = await beganDeleteVideo(_parmas);
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: "删除成功！",
        });
        this.beganGetVideoList();
      } else {
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    // 获取会议视频列表
    async beganGetVideoList () {
      const self = this
      self.loading = true
      const res = await getVideoList(self.searchData)
      if (res.code === 0) {
        self.loading = false
        self.tableData = res.data
        self.totalVideoCount = res.page.total_count

        self.$nextTick(() => {
          self.$refs.videoTable.doLayout();
        });
      } else {
        self.loading = false
        self.$message.error(res.msg)
      }
    },
    // 获取操作日志列表
    async beganGetOperateLogList () {
      const self = this
      self.loading = true
      const res = await getVideoLogList(self.searchLogData)
      if (res.code === 0) {
        self.loading = false
        self.tableLogData = res.data
        self.totalVideoLogCount = res.page.total_count
        self.$nextTick(() => {
          self.$refs.vedioLogTable.doLayout();
          // self.$refs.vedioLogTable.value.sort('operator_time', 'descending')
        });
      } else {
        self.loading = false
        self.$message.error(res.msg)
      }
    },
    // 获取业务系统
    async getMygetBusinessType () {
      const res = await getBusinessType()
      if (res.code === 0) {
        this.businessSystem =  res.data
      } else {
        this.$message({ type: 'error', message: res.msg })
      }
    },
  },
  mounted () {
    const self = this
    // var manager = new Mgr()
    // manager.getRole().then(function (logindata) {
    //   self.addLogParam.tenancy_id = logindata.profile.tenancy_id
    //   self.tokenInfor = logindata
    //   self.token = logindata.token_type + ' ' + logindata.access_token
    //   self.getCurAllModule()
    // })
    // 获取业务系统
    self.getMygetBusinessType()
  },
  filters:{
    // 根据code 获取系统名称
    getSystemName (code,businessTypeArr) {
      let systemName = ''
      businessTypeArr.forEach((item) => {
        if (item.code === code) {
          systemName = item.name
        }
      })
      return systemName
    },
    // 根据code 和kind 去获取某个系统下的 业务
    getBussessName (code, curSystemCode, businessTypeArr) {
      let businessArr = []
      let businessName = ''
      businessTypeArr.forEach((item) => {
        if (item.code === curSystemCode) {
          businessArr = item.business
        }
      })
      businessArr.forEach((one) => {
        if (code == one.code) {
          businessName = one.name
        }
      })
      return businessName
    }
  }
}
</script>
<style lang="less" scoped>
.videoManageCon{
  height:100%;
    .userListoperate-btn {
      display: inline-block;
      text-align: center;
      padding: 0px 10px;
      height: 32px;
      line-height: 32px;
      border-radius: 3px;
      cursor: pointer;
      background:#F56C6C;
      color:#fff;
    }
  .inspectCon{
    padding: 10px 12px;
    height: calc(100% - 46px);
    .videoTableDiv{
      height:calc(100% - 142px);
      position: relative;
      ::v-deep .el-table{
        height:100%!important;
        .el-table__body-wrapper{
          height:calc(100% - 51px)!important;
          overflow: auto;
        }
        // .el-table__fixed-body-wrapper{
        //   height:calc(100% - 51px)!important;
        // }
      }
    }
    .operateLogTableDiv{
      height:calc(100% - 99px);
      ::v-deep .el-table{
          height:100%!important;
          .el-table__body-wrapper{
            height:calc(100% - 40px)!important;
            overflow: auto;
          }
        }
    }
    .blockPage {
      border: 1px solid #eee;
      border-top: none;
    }
  .logSearchDiv{
    display: flex;
    align-items: center;
    margin-bottom:10px;
    .search-bar-label{
      font-size:15px;
      color:#303133;
      line-height: 32px;
      min-width: 70px;
      text-align: right;
      margin-right: 10px;
    }
  }
 }
}
.crumbsCon {
  display: flex;
  .m-tab {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .m-tab-item {
    width: 95px;
    color: #303133;
    font-size: 15px;
    text-align: center;
    cursor: pointer;
    font-weight: 700;
  }
  .m-tab-item-active {
    color: #0a70b0;
    font-weight: 700;
  }
  .tab-line {
    height: 2px;
    width: 95px;
    background: #0a70b0;
    position: absolute;
    bottom: 0;
    left: 0;
    transition: all 0.3s ease;
  }
}
.stateDesc{
  font-size:14px;
  color:#606266;
}
.stateNo{
  color:#FF9900;
}
.stateFail{
  color:#DA4A4A;
}
.stateArchiveing{
  color:#1C8BE4;
}
</style>
