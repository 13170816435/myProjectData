<template>
  <el-dialog :visible.sync="relationMode.show" title="批量关联" width="700px" :close-on-click-modal="false" append-to-body
    center>
    <div style="display: flex;padding: 10px;">
      <div class="relation-box">
        <span class="title-box">{{relationMode.right_title}}</span>
        <div class="temp-tab-content pis-tree">
          <el-tree ref="r_tree" :data="l_treeData" :props="r_Props" node-key='id' :default-expand-all='false'
            :expand-on-click-node='true' draggable @node-click="NodeClick" :highlight-current="true">
            <span slot-scope="scope" class="custom-tree-node">
              <i class="iconfont clr_999" v-if="!scope.data.children && scope.data.parent_id">&#xe640;</i>
              <span style="padding-left: 4px;margin-right: auto;">{{scope.node.label}}</span>
            </span>
          </el-tree>
        </div>
      </div>
      <div style="padding: 0 10px;display: inline-flex; align-items: center;">
        <div
          style="background:rgba(10,112,176,0.1);width: 30px;height: 30px; border-radius: 50%;text-align: center;line-height: 30px;">
          <i class="iconfont" style="color: #0A70B0;">&#xe700;</i>
        </div>
      </div>
      <div class="relation-box">
        <span class="title-box">{{relationMode.left_title}}</span>
        <div class="temp-tab-content">
          <el-tree ref="l_tree" show-checkbox :data="r_treeData" :props="l_Props" node-key='id'
            :default-expand-all='false' :expand-on-click-node='true' draggable>
            <span slot-scope="scope" class="custom-tree-node">
              <i class="iconfont clr_999" v-if="!scope.data.children && scope.data.parent_id">&#xe640;</i>
              <span style="padding-left: 4px;margin-right: auto;">{{scope.node.label}}</span>
            </span>
          </el-tree>
        </div>

      </div>
    </div>
    <div class="dialog_footer">
      <el-button size="small" @click="cancle()">取消</el-button>
      <el-button type="primary" size="small" @click="confirm()">提交</el-button>
    </div>
  </el-dialog>
</template>
<script>

  export default {
    data() {
      return {
        chooseNode: {},
      }
    },
    props: {
      relationMode: { type: Object },
      l_treeData: { type: Array },
      l_Props: { type: Object },
      r_treeData: { type: Array },
      r_Props: { type: Object },
      checkedList: { type: Array }
    },
    methods: {
      cancle() { // 取消
        this.relationMode.show = false
      },
      //保存
      confirm() {
        // console.log(this.$refs.l_tree.getHalfCheckedKeys())
        this.$emit('BatchRelationClick', this.chooseNode, this.$refs.l_tree.getCheckedKeys())
      },
      //点击检查项目查看相关关联
      NodeClick(data) {
        if (!data.children) {
          console.log(data);
          // if (this.examId) {
          //   this.$confirm('是否保存上一条记录?', '提示', {
          //     confirmButtonText: '确定',
          //     cancelButtonText: '取消',
          //     type: 'warning'
          //   }).then(() => {
          //     console.log(this.$refs.l_tree.getCheckedKeys());
          //     this.$emit('BatchRelationClick',this.examId,this.$refs.l_tree.getCheckedKeys())//保存
          //   }).catch(() => {

          //   });
          // }else{
          this.chooseNode = data;//选中节点
          this.$emit('getRelationTemp', data)
          // }
        }
      },
    },
    watch: {
      checkedList: {//选中数据
        handler(val, old) {
          // console.log(old,val)
          this.$refs.l_tree.setCheckedKeys(val);

        },
        deep: true
      },
    },

  }
</script>
<style scoped>
  .title-box {
    background-color: #F2F2F2;
    display: inline-block;
    width: 100%;
    padding: 10px;
    box-sizing: border-box;
    font-size: 14px;
    color: #333333;
    font-family: PingFangSC, PingFangSC-Regular;
    font-weight: 400;
  }

  .relation-box {
    flex: 1;
    border: 1px solid #EBEEF5;
    height: 448px;
  }

  .temp-tab-content {
    height: 408px;
    overflow: auto;
  }

  .pis-tree /deep/.el-tree--highlight-current .el-tree-node.is-current>.el-tree-node__content {
    background-color: #0a70b0;
    color: white;
  }
</style>