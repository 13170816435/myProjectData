<template>
  <el-dialog :visible.sync="DeleteModeDia.show"
  :title="DeleteModeDia.deltitle"
  width="350px"
  :close-on-click-modal="false"
  :show-close="false"
  append-to-body
  center>
    <div class="row flex_column flex_center">
      <p class="f16" style="display: flex;align-items: center;margin: 20px 0;">
        <i class="iconfont clr_warn mr10" style="font-size:34px">&#xe606;</i>
        <span>确定删除该{{DeleteModeDia.type}}？</span>
      </p>
    </div>
    <div class="dialog_footer">
      <el-button size="small" @click="cancle()">取消</el-button>
      <el-button type="primary" size="small" @click="confirm()">确定</el-button>
    </div>
  </el-dialog>
</template>
<script>
// import { DeleteWritingTemplate, DeleteSingleOrMoreTemplate, DeleteThesaurusCategory, DeleteSingleOrMoreThesaurus } from '@/api/pacs_template'
export default {
  data () {
    return {
      
    }
  },
  props: {
    DeleteModeDia: { type: Object }
  },
  methods: {
    cancle () { // 取消
      this.DeleteModeDia.show = false
    },
    async confirm () { // 确定删除
      this.$emit('delClick')
    },
    
  },
  watch: {
  },
  
}
</script>
