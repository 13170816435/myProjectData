<template>
<!--
  导入模板
-->
  <el-dialog :visible.sync="ImportTempMode.show"
  title="导入模板"
  width="1000px"
  :close-on-click-modal="false"
  :show-close="true"
  append-to-body
  center>
    <div>
      <div class="upload-temp" style="margin: 14px 0;"> 
        

        <el-upload
        class="upload-demo"
        ref="upload"
        action="https://jsonplaceholder.typicode.com/posts/"
        :on-preview="handlePreview"
        :on-remove="handleRemove"
        :file-list="fileList"
        :auto-upload="false">
        <div style="width: 950px;display: flex;padding: 6px 0px 0 30px; " >
          <div>
            <span @click.stop="" style="color: #333333;">上传文件：</span>
            <el-button size="small" @click="">选择文件</el-button>
            <el-button size="small"  @click.stop="downloadTemp">下载模板</el-button>
            <span @click.stop="" class="clr_y ml10">选择需要需要导入的EXCEL文件</span>
          </div>
          
          <el-button type="warning" size="small" @click.stop="ImportList" style="margin-left: auto;">导入</el-button>
        </div>
        </el-upload>

        <div style="border-top: 1px dashed #DDDDDD;" class="mt20">

          <div style="padding: 26px 0 16px 0;text-align: center;">共6条数据，导入成功 
            <span class="f18" style="color: #1BB54A;padding: 0 10px">{{message.success}}</span> 条，失败 
            <span class="f18" style="color: #FF6F6F;padding: 0 10px">{{message.err}}</span> 条
          </div>

          <el-table
            ref="tableRef"
            :data="tableData"
            :header-cell-style="{background: '#F2F2F2',color: '#333'}"
            highlight-current-row
            stripe 
            border
            @header-dragend="dragendTableChange"
            :height="tableHeight"
            v-loading='loading'>
            <!-- <el-table-column
            type="selection"
            width="55">
            </el-table-column> -->
            <el-table-column
            label="序"
            type="index">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" label="结果" prop='result' width="60">
            <template slot-scope="scope">
             <span v-if="scope.row.result==0" style="color: #FF6F6F;">失败</span>
             <span v-else style="color: #1BB54A;">成功</span>
            </template>
          </el-table-column>
            <el-table-column v-for="(col, index) in columnList" :key="index" :show-overflow-tooltip="true" :label="col.label" :prop='col.prop' :width="col.width">
            </el-table-column>
            <!-- <common-table :propData="propData" ></common-table> -->
          </el-table>
        </div>
        
       
      </div>
    </div>
  </el-dialog>
</template>

<script>
// import { WritingTemplateCategory, AddSingleTemplate, ModifySingleTemplate } from '@/api/pacs_template'

export default {
  name: 'ImportTemp',
  props: {
    ImportTempMode: { type: Object }
  },
  components: {
  },
  data () {
    return {
      tableData:[
        {result:0,errresult:'编码不能为空',parentCode:'',name:'项目3',code:'',tempName:'模板名称',see:'',results:''},
        {result:1,errresult:'',parentCode:'8465',name:'项目3',code:'',tempName:'模板名称',see:'',results:''}
      ],
      columnList: [
       {label:'失败原因',width:'150',prop:'errresult'},
       {label:'上级分类编码',width:'150',prop:'parentCode'},
       {label:'分类名称',width:'100',prop:'name'},
       {label:'分类编码',width:'100',prop:'code'},
       {label:'模板名称',width:'100',prop:'tempName'},
       {label:'镜下所见',width:'',prop:'see'},
       {label:'病理诊断',width:'100',prop:'results'}
      ],
      message:{
        success:4,
        err:2
      },
      tableHeight:'400',
      fileList:[],
      loading:false
    }
  },
  watch: {
    
  },
  mounted () {
   
  },
  methods: {
    //下载模板
    downloadTemp(){

    },
    //批量导入
    ImportList(){
      this.$refs.upload.submit();
    },
    handlePreview(){

    },
    handleRemove(){

    },
    dragendTableChange(){
      
    }
  }  
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less" scoped>
.addModel ::v-deep .el-form-item {
  margin-bottom: 15px;
}
.editBox {
  width: 100%;
  height: 150px;
  margin-bottom: 10px;
}
.editBoxT {
  width: 100%;
  height: 100px;
}
</style>
<style>
  .upload-temp .el-progress-bar__inner{
    background-color:#1BB54A!important;
  }
  .upload-temp .el-progress__text{
    color:#1BB54A!important;
  }
  .upload-temp ul.el-upload-list{
    display: flex;
    flex-wrap: wrap;
  }
  .upload-temp ul.el-upload-list li{
    width: 280px;
    background-color: #F5F5F5;
    border-radius: 4px;
    margin-right: 55px;
  }
  .upload-temp ul.el-upload-list li .el-icon-document a{
    color: #333333!important;
  }
  .upload-temp .el-icon-document{
    color: #333333!important;
    margin-left: 6px;
  }
  .upload-temp .el-upload-list__item{
    margin-top: 10px;
  }
  .upload-temp ul li:nth-child(3n+3) {
    margin-right: 0px;
  }
</style>
