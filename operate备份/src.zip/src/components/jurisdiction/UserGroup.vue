<template>
  <div class="userGroupContent">
    <div class="search-bar flex_row">
      <div class="mr20" v-if="systemList">
        <span class="search-bar-label">所属系统：</span>
        <el-select class="ml5" v-model="searchData.system_id" placeholder="请选择" style="width:240px" @change="groupSystemchagen">
          <el-option
            v-for="item in systemList"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          ></el-option>
        </el-select>
      </div>
      <div class="flex_row">
        <el-select v-model="searchData.group_type" class="width_150_input" placeholder="所属科室">
          <el-option label="用户组名称" value="1"></el-option>
          <!-- <el-option label="用户组编号" value="2"></el-option> -->
        </el-select>
        <el-input class="ml5 width_240_input" v-model="searchData.keyvalue" placeholder="请输入" ></el-input>
      </div>
      <div class="ml30">
        <el-button type="primary" size="small" @click="SearchGroupFn('search')">查询</el-button>
        <el-button size="small" plain @click="SearchGroupFn('reset')">重置</el-button>
      </div>
      <div class="flex_1 tr">
          <span class="operate-btn clr_ff bg_e6" @click="showUserinfoFn('add')"><i class="iconfont iconxinzeng mr5"></i>新增用户组</span>
      </div>
    </div>
    <div class="mt10 groupTableDiv" v-bind:class="{'noTableData':group_Tablelist.length==0}">
      <el-table border stripe 
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-background="rgba(255,255,255,0.6)"
      :height="tableheight" :data="group_Tablelist">
<!--        <el-table-column prop="index" label="序号" width="60"></el-table-column>-->
        <el-table-column type="index" label="序号" width="60">
          <template slot-scope="scope">
            <span>{{(pageInfo.page_index - 1) * pageInfo.page_size + scope.$index + 1}}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="100">
        <template slot-scope="scope">
          <span class="clr_0a pointer" @click="showUserinfoFn('edit', scope.row)">编辑</span>
          <span class="clr_da pointer pl10" @click="showUserinfoFn('del', scope.row)">删除</span>
        </template>
      </el-table-column>
        <!-- <el-table-column prop="tenancy_system_name" label="所属系统" width="300"></el-table-column> -->
        <!-- <el-table-column prop="code" label="用户组编号"></el-table-column> -->
        <el-table-column prop="name" label="用户组名称" width="220"></el-table-column>
        <el-table-column prop="user_count" label="用户组人数" width="100"></el-table-column>
        <el-table-column prop="description" label="用户组描述"></el-table-column>
      </el-table>
    </div>
    <div class="ba">
      <pagination-tool :total="pageInfo.total_count" :page.sync="pageInfo.page_index" :limit.sync="pageInfo.page_size" @pagination="pageSizeChangeFn" />
    </div>
  </div>
</template>

<script>
import PaginationTool from '@/components/common/PaginationTool'
export default {
  props: {
    systemList: Array,
    searchData: Object,
    group_Tablelist: Array,
    pageInfo: Object
  },
  components: {
    PaginationTool
  },
  data () {
    return {
      pageLayout: 'total, prev, pager, next, jumper',
      tableheight: '100%',
      loading: true,
    }
  },
  methods: {
    showUserinfoFn (type, row) {
      var info = {
        type: type,
        row: row
      }
      this.$emit('showUserinfoFn', info)
    },
    SearchGroupFn (type) {
      this.$emit('SearchGroupFn', type)
    },
    groupSystemchagen (val) {
      this.$emit('SystemChange', val, 'group')
    },
    pageSizeChangeFn (info) {
      this.$emit('pageSizeChangeFn', info, 'usergroup')
    }
  }
}
</script>

<style lang="less" scoped>
.userGroupContent{
  height:100%;
  .groupTableDiv{
    height:calc(100% - 101px);
    .el-table{
      ::v-deep .el-table__body-wrapper{
        height:calc(100% - 40px)!important;
        overflow: auto;
      }
    }
  }
}
.operate-btn{
  display: inline-block;
  width: 104px;
  text-align: center;
  padding: 0px;
  height:32px;
  line-height: 32px;
  border-radius:3px;
  border: none;
  margin-left: 10px;
  cursor: pointer;
}
.tab_title{
  height: 45px;
  line-height: 45px;
  border-bottom: 1px solid #DCDFE6;
}
.tab_span{
  display: inline-block;
  width: 86px;
  height: 45px;
  padding: 0px 5px;
  cursor: pointer;
  text-align: center;
}
.border_b{
  border-bottom: 2px solid #0A70B0;
}
.border{
  border: 1px solid #DCDFE6;
}
.icon-btn {
  display: inline-block;
  width: 24px;
  height: 24px;
  color: #fff;
  line-height: 24px;
  text-align: center;
  padding: 0px;
  cursor: pointer;
  border-radius: 3px;
  margin-right: 8px;
}
</style>
