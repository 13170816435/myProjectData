<template>
  <div class="list flex_row flex_wrap">
    <div class="list-item" v-for="(item, index) in List" :key="index">
      <div class="flex_row">
        <img class="pacs_img" src="../../assets/images/CS_Image.png" />
        <div class="ml25 flex_1">
          <div class="f20 clr_303 title">{{item.name}}</div>
          <div class="clr_666 mt20">授权产品：{{item.product_name}}</div>
        </div>
        <div class="item_btn ml20" @click="toGroupFn(item.id)">权限管理</div>
      </div>
      <div class="flex_row mt25">
        <div class="flex_1"><span class="clr_999"><i class="iconfont iconjigoumingcheng"></i>机构数量：</span> <span class="clr_303">{{item.institution_count}}</span></div>
        <div class="flex_1"><span class="clr_999"><i class="iconfont iconyonghuzu"></i>用户组: </span> <span class="clr_303">{{item.usergroup}}</span></div>
      </div>
      <div class="flex_row mt20">
        <div class="tl flex_1"><span class="clr_999"><i class="iconfont iconguanliyuan"></i>管理人员: </span> <span class="clr_303">{{item.admin_name}}</span></div>
        <div class="flex_1"><span class="clr_999"><i class="iconfont icondianhua"></i>联系电话: </span> <span class="clr_303">{{item.admin_phone}}</span></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['List'],
  methods: {
    toGroupFn (id) {
      this.$emit('toGroupFn', id)
    }
  }
}
</script>

<style lang="less" scoped>
.list-item{
  min-width: 500px;
  max-width: 560px;
  height: 190px;
  padding: 25px;
  box-sizing: border-box;
  border:1px solid rgba(220, 223, 230, 1);
  margin-right: 20px;
  margin-bottom: 20px;
  cursor: pointer;
  .pacs_img{
    width: 64px;
    height: 64px;
    vertical-align: middle;
  }
  .item_btn{
    width:88px;
    height:30px;
    line-height: 30px;
    text-align: center;
    background:rgba(255,255,255,1);
    border:1px solid rgba(10, 112, 176, 0.5);
    border-radius:3px;
    color: #0A70B0;
  }
  .iconfont{
    margin-right: 8px;
  }
}
.list-item:hover{
  border-color: #0A70B0;
}
.list-item:hover .title{
  color: #0A70B0;
}
</style>
