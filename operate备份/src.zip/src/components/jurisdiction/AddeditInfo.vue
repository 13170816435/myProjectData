<template>
  <div class="dialoginfo">
    <el-form :model="userGroupInfo.groupInfo" :rules="userGroupInfo.rules" ref="userGroupInfo.groupInfo" label-width="110px" class="demo-ruleForm pb5">
      <el-row class="mt10 mb10">
        <el-col :span="12" v-if="systemList">
          <el-form-item label="所属系统:" prop="system_code" class="w_340">
            <el-select size="small" class="ml5" v-model="userGroupInfo.groupInfo.system_id" placeholder="请选择" @change="systemChange" style="width:235px">
              <el-option
                v-for="item in systemList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="9">
          <div class="row">
            <div class="mr5"><i class="iconfont iconbitian clr_da"></i>用户组名称 :</div>
            <el-input v-model="userGroupInfo.groupInfo.name" class="width_240_input" size="small" maxlength="16" show-word-limit></el-input>
          </div>
        </el-col>
        <el-col :span="11">
          <div class="row">
            <div class="mr5">用户组描述 :</div>
            <el-input v-model="userGroupInfo.groupInfo.description" style="width: 360px;" size="small"></el-input>
          </div>
        </el-col>
        <el-col :span="4" class="tr">
          <div>
            <el-button size="small" type="primary" @click="submitForm('submit',userGroupInfo.groupInfo)">提交</el-button>
            <el-button size="small" plain @click="submitForm('', userGroupInfo.groupInfo)">取消</el-button>
          </div>
        </el-col>
      </el-row>
      <div class="CheckBoxlist">
        <el-table
          ref="multipleTable"
          class="table"
          :data="tableData"
          height="calc(100vh - 370px)"
          border
        >
          <el-table-column
            width="55"
            :render-header="renderHeader"
          >
            <template slot-scope="scope">
              <el-checkbox v-model="scope.row.checked" @change="checkboxChange(scope.row)"></el-checkbox>
            </template>
          </el-table-column>
          <el-table-column
            label="权限分类"
            prop="display_group_name"
            width="100"
          ></el-table-column>
          <el-table-column
            label="菜单&操作权限"
            prop="menu"
          >
            <template slot-scope="scope">
              <div class="flex_row flex_wrap">
                <div class="row" style="width: 20%; line-height: 26px;" v-for="(item, index) in scope.row.menu" :key="index">
                  <el-checkbox v-if="item.policies.length === 0 && item.children.length === 0" class="check1 strong" :disabled="item.disabled"  v-model="item.checked" @change="checked => chooseAuthoy(item.checked, item.name, item.id, scope.row.display_group_name)" :label="item.id" :title="item.description">
                    {{item.name}}
                  </el-checkbox>
                  <el-popover v-if="item.policies.length === 0 && item.children.length" popper-class="remove-popover" @hide="onPopoverHide" placement="bottom" width="230" trigger="click">
                    <el-row class="pt5 pl5 pr5">
                      <el-col class="mb5" :span="24" v-for="val in item.children" :key="val.id">
                        <el-checkbox :disabled="val.disabled" :title="val.description" @change.native.stop="changeChildCheckFn($event, val.name, val.id, scope.row.display_group_name)" v-model="val.checked" :label="val.id">{{ val.name }}</el-checkbox>
                      </el-col>
                    </el-row>
                    <span class="blod" slot="reference">
                      <el-checkbox v-model="item.checked" :disabled="item.disabled" :title="item.description" @change="changeChildCheck($event, item.name)" :label="item.id">{{ item.name }}</el-checkbox>
                      <i class="iconfont pointer">&#xe6432;</i>
                    </span>
                  </el-popover>
                  <el-popover v-if="item.policies.length && item.children.length === 0" placement="bottom" width="290" trigger="click">
                    <el-row class="pt5 pl5 pr5" v-if="item.name !== '隐私保密等级'">
                      <el-col class="mb5" :span="8" v-for="policiesitem in item.policies" :key="policiesitem.code">
                        <el-checkbox :disabled="item.disabled" :title="policiesitem.description" @change="childcheckFn($event, item.id, item.name, scope.row.display_group_name)" v-model="policiesitem.checked" :label="policiesitem.code">{{ policiesitem.name }}</el-checkbox>
                      </el-col>
                    </el-row>
                    <div v-else>
                      <div
                        v-for="policiesitem in item.policies"
                        :key="policiesitem.code"
                        class="tc pl10 pr10 pt5 pb5 bb cp"
                        :class="{ 'policiesitem-active': policiesitem.checked }"
                        @click="handlePoliciesitem($event, item.id, item.name, scope.row.display_group_name, policiesitem)"
                      >{{ policiesitem.name }}</div>
                    </div>
                    <span class="blod" slot="reference">
                      <el-checkbox v-model="item.checked" :disabled="item.disabled" :title="item.description" @change="changeCheck($event, item.name, scope.row.display_group_name)" :label="item.id">{{ item.name }}</el-checkbox>
                      <i class="iconfont pointer" v-show="!(item.name === '修改电子单信息' && !enableModifyPlacerFiled)">&#xe6432;</i>
                    </span>
                  </el-popover>
                </div>
              </div>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-form>
  </div>
</template>

<script>
import $ from 'jquery'
import { mapGetters } from 'vuex'
export default {
  props: {
    systemList: Array,
    userGroupInfo: Object,
    tableData: Array,
    roleName: String
  },
  data () {
    return {
      isIndeterminate: true,
      checkAll: false,
      checkedList: [],
      selectionArr: [],
      selectAll: false,
      indeterminate: false
    }
  },
  computed: {
    ...mapGetters(['systermData']),
    enableModifyPlacerFiled () {
      return this.systermData?.RegistParameter?.enableModifyPlacerFiled
    }
  },
  methods: {
    handlePoliciesitem (e, val, name, display_group_name, policiesitem) {
      this.tableData.forEach((item, index) => {
        if (item.display_group_name === display_group_name && item.menu.length) {
          item.menu.forEach(Aitem => {
            if (Aitem.policies.length) {
              Aitem.policies.forEach(Pitem => {
                Pitem.checked = false
              })
              const curr = Aitem.policies.find(o => o.name === policiesitem.name)
              curr.checked = !curr.checked
            }
          })
          this.$set(this.tableData, index, item)
        }
      })
      this.childcheckFn(e, val, name, display_group_name)
    },
    renderHeader(h, data) {
      return h("span", [
        h("el-checkbox", {
          on: {
            change: this.selectAllFn
          },
          props: {
            value: this.selectAll,
            indeterminate: this.indeterminate
          }
        })
      ]);
    },
    onPopoverHide () {
      // $('.remove-popover').remove();
    },
    selectAllFn () {
      this.selectAll = !this.selectAll
      this.$emit('tableSelectAll', this.selectAll)
    },
    checkboxChange (row) {
      this.$emit('selectChange', row)
    },
    submitForm (type, formName) {
      const info = {
        type: type,
        formName: formName,
        refs: this.$refs
      }
      this.$emit('submitForm', info)
    },
    chooseAuthoy (checked, name, id, display_group_name) {
      this.$emit('chooseAuthoy', checked, name, id, display_group_name)
    },
    changeCheck (e, val, display_group_name) {
      this.$emit('changeCheck', e, val, display_group_name)
    },
    changeChildCheck (e, val) {
      this.$emit('changeChildCheck', e, val)
    },
    changeChildCheckFn (e, name, id, display_group_name) {
      this.$emit('changeChildCheckFn', e, name, id, display_group_name)
    },
    childcheckFn (e, val, name, display_group_name) {
      this.$emit('childcheckFn', e, val, name, display_group_name)
    },
    systemChange (val) {
      this.$emit('systemChange', val)
    },
  },
}
</script>

<style lang="less" scoped>
.dialoginfo{
  padding: 0 15px;
  padding-bottom: 10px;
}
.policiesitem-active {
  background-color: #0A70B0;
  color: #ffffff;
}
.w_340{
  width: 340px;
}
// 权限信息
.checkbox_group{
  min-width: 18%;
  margin-bottom: 10px;
}
.checkeditem{
  min-width: 20%;
  margin-top: 10px;
  margin-bottom: 10px;
}
.consol-btn{
  display: inline-block;
  min-width: 64px;
  height: 32px;
  line-height: 32px;
  text-align: center;
  padding: 0px 5px;
  cursor: pointer;
  background: #FFF;
  border: 1px solid #DCDFE6;
}
.saveBtn{
  color:#fff;
  padding: 0px 5px!important;
  min-width: 64px;
  height: 32px;
  line-height: 32px;
  background-color: #0A70B0;
}
::v-deep .CheckBoxlist .el-tabs__item.is-active {
  color: #fff !important;
}
::v-deep .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: #ffffff !important;
}

</style>