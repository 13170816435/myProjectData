<template>
  <div class="userListContent">
    <div class="left_select">
      <el-select v-if="systemList" class="ml5 mb15" filterable v-model="searchData.system_id" placeholder="所属系统" style="width:175px" @change="userlistSystemchange">
        <el-option
          v-for="item in systemList"
          :key="item.id"
          :label="item.name"
          :value="item.id"
        ></el-option>
      </el-select>
      <div class="groupContainer">
        <div class="productSearch">
          <el-input
            size="small"
            class="productSearchInput"
            v-model="groupSearchData.keyvalue"
            @keyup.enter.native="SearchGroupFn('search')"
            placeholder="按名称查询"
          >
            <i slot="suffix" class="el-icon-search" @click.stop="SearchGroupFn('search')"></i>
          </el-input>

          <el-tooltip placement="top">
            <div slot="content">新增用户组</div>
              <span class="addProductBtn"  @click="showUserinfoFn('add')">
                <i class="iconfont iconxinzeng"></i>
            </span>
          </el-tooltip>
        </div>
       <div class="allGroupCon">
        <div class="gorupList_item" 
          :class="{'actived': userListInfo.activeIndex==index}"
          v-for="(item, index) in groupList" :key="item.id" 
          @click="changeUserGourpAvtive(index, item.id)">
          <tooltip-over
            :content="item.name"
            placement="top-start"
            class="wid190"
            refName="tooltipOver"
          ></tooltip-over>

          <div class="operateBtnCon">
              <span :title="'编辑'" class="clr_0a"  @click.stop="showUserinfoFn('edit', item)"><i class="iconfont iconbianji1"></i></span>
              <span :title="'删除'" class="pl10 clr_da" @click.stop="showUserinfoFn('del', item)"><i class="iconfont iconshanchu"></i></span>
          </div>
          </div>
      </div>
      </div>
    </div>
    <div class="left_main flex_1">
      <div class="search-bar flex_row">
        <div class="flex_row">
          <el-select class="width_120_input" v-model="searchData.type" filterable>
            <el-option label="姓名" value="1"></el-option>
            <el-option label="工号" value="2"></el-option>
            <el-option label="手机号" value="3"></el-option>
          </el-select>
          <el-input class="ml5 width_240_input" v-model="searchData.keyvalue" placeholder="请输入"></el-input>
        </div>
        <div class="ml30">
          <el-button type="primary" size="small" @click="SearchuserlistFn('search')">查询</el-button>
          <el-button size="small" plain @click="SearchuserlistFn('reset')">重置</el-button>
        </div>
        <div class="flex_1 tr">
          <span class="operate-btn clr_ff bg_e6" @click="showAddUserinfoFn('add')"><i class="iconfont iconxinzeng mr5"></i>添加成员</span>
          <span class="operate-btn clr_ff bg_f5" @click="delUserFn('pi_del')"><i class="iconfont icondongjie mr5"></i>批量删除</span>
        </div>
      </div>
      <div class="mt10 userTableDiv" v-bind:class="{'noTableData':userListInfo.userList.length==0}">
        <el-table
          ref="CheckuserListTable"
          style="width: 100%"
          v-loading="loading"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          size="medium "
          height="100%"
          border stripe
          :data="userListInfo.userList"
          highlight-current-row
          header-row-class-name="strong"
          @selection-change="tableSelectChangeFn">
          <el-table-column type="selection" width="50"></el-table-column>
<!--          <el-table-column prop="index" label="序号" width="50"></el-table-column>-->
          <el-table-column type="index" label="序号" width="60">
            <template slot-scope="scope">
              <span>{{(pageInfo.page_index - 1) * pageInfo.page_size + scope.$index + 1}}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="60">
            <template slot-scope="scope">
              <!-- <span class="icon-btn bg_f5" @click="delUserFn('del', scope.row)" type="text" size="small" title="删除">
                <i class="iconfont icondongjie"></i>
              </span> -->
              <span class="clr_da pointer" @click="delUserFn('del', scope.row)">删除</span>
            </template>
          </el-table-column>
          <el-table-column prop="name" label="姓名" width="100" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="sex" label="性别" width="80" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="phone" label="手机号码" width="120" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="work_no" label="工号" width="100" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="title" label="职称" width="120" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="group_name" label="所属用户组" width="120" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="office_name" label="所属科室" :show-overflow-tooltip="true"></el-table-column>
          <el-table-column prop="institution_name" label="所属医院" :show-overflow-tooltip="true"></el-table-column>

          <!-- <el-table-column prop="use_time" label="使用时间" :show-overflow-tooltip="true" width="200"></el-table-column> -->
          <!-- <el-table-column prop="address" label="通讯地址" :show-overflow-tooltip="true" width="200"></el-table-column> -->
          <!-- <el-table-column prop="create_time" label="创建时间" :show-overflow-tooltip="true" width="200"></el-table-column> -->
        </el-table>
      </div>
      <div class="ba">
        <pagination-tool :total="pageInfo.total_count" :page.sync="pageInfo.page_index" :limit.sync="pageInfo.page_size" @pagination="pageSizeChangeFn" />
      </div>
    </div>
  </div>
</template>

<script>
import tooltipOver from '@/components/common/tooltipOver'
import PaginationTool from '@/components/common/PaginationTool'
export default {
  props: {
    systemList: Array,
    groupList: Array,
    userListInfo: Object,
    groupSearchData: Object,
    searchData: Object,
    userList: Array,
    munesystemcode: String,
    pageInfo: Object
  },
  components: {
    PaginationTool,
    tooltipOver
  },
  data () {
    return {
      pageLayout: 'total, prev, pager, next, jumper',
      loading: true,
      showDeleteGroupOrUserAlert: false,
    }
  },
  methods: {
    // 用户组相关的方法
    SearchGroupFn (type) {
      this.$emit('SearchGroupFn', type)
    },
    // 添加、编辑、删除用户组
    showUserinfoFn (type, row) {
      var info = {
        type: type,
        row: row
      }
      this.$emit('showUserinfoFn', info)
    },
    delUserFn (type, row) {
      var info = {
        type: type,
        row: row
      }
      this.$emit('delUserFn', info)
    },
    tableSelectChangeFn (val) {
      this.$emit('tableSelectChangeFn', val)
    },
    changeUserGourpAvtive (index, id) {
      this.$emit('changeUserGourpAvtive', index, id)
    },
    userlistSystemchange (val) {
      this.$emit('SystemChange', val, 'list')
    },
    showAddUserinfoFn (type) {
      this.$emit('showAddUserinfoFn', type)
    },
    pageSizeChangeFn (info) {
      this.$emit('pageSizeChangeFn', info, 'userlist')
    },
    SearchuserlistFn (type) {
      this.$emit('SearchuserlistFn', type)
    }
  }
}
</script>

<style lang="less" scoped>
.userListContent{
  display: flex;
  height: 100%;
  .userTableDiv{
    height:calc(100% - 101px);
    .el-table{
      ::v-deep .el-table__body-wrapper{
        height:calc(100% - 40px)!important;
        overflow: auto;
      }
    }
  }
}
.left_select{
  width: 250px;
  height: 100%;
  padding-right: 10px;
}
.left_main{
  min-width: calc(1280px - 420px );
  border-left: 1px solid #DCDFE6;
  padding: 0px 10px;
  height:100%;
  padding-right:0px;
}
.groupContainer {
  height: 100%;
}
.allGroupCon{
  height: calc(100% - 41px);
  overflow-y: auto;
}
::v-deep .gorupList_item{
  width: 100%;
  height: 42px;
  display: flex;
  align-items: center;
  padding-left: 8px;
  border-left: 4px solid #fff;
  font-weight: 900;
  color: #303133;
  cursor: pointer;
  .el-button{
    border:none;
    background:initial;
    padding:0px;
    width: 100%;
    color: #303133;
    text-align: left;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
}
::v-deep .actived{
  background: #E6F3FF;
  border-left-color: #0A70B0;
  color: #085A8D;
  .el-button{
    color: #085A8D;
  }
}
.operate-btn{
  display: inline-block;
  width: 104px;
  text-align: center;
  padding: 0px;
  height:32px;
  line-height: 32px;
  border-radius:3px;
  border: none;
  margin-left: 10px;
  cursor: pointer;
}
.border_l{
  display: inline-block;
  width: 3px;
  height: 16px;
  background: #0A70B0;
  margin-right: 8px;
  vertical-align: middle;
  margin-top: -4px;
}
.icon-btn {
  display: inline-block;
  width: 24px;
  height: 24px;
  color: #fff;
  line-height: 24px;
  text-align: center;
  padding: 0px;
  cursor: pointer;
  border-radius: 3px;
  margin-right: 8px;
}
.checkalltab{
  height: 350px;
  border:1px solid rgba(220, 223, 230, 1)
}
.checkalltab_title{
  height:40px;
  line-height: 40px;
  padding: 0px 10px;
  background:rgba(249,249,249,1);
  border-bottom:1px solid rgba(220, 223, 230, 1);
}
.checkalltab_list{
  height: 300px;
  overflow-y: scroll;
}
.productSearch {
  display: flex;
  border-bottom: 1px solid #dcdfe6;
  padding-bottom:8px;
  .productSearchInput {
    margin-right: 8px;
    flex: 1;
  }
  ::v-deep .el-input__suffix{
    display: flex;
    align-items: center;
    cursor: pointer;
    color: #0a70b0;
  }
  .addProductBtn {
    width: 32px;
    height: 32px;
    background: #ffffff;
    border: 1px solid #dcdfe6;
    border-radius: 3px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    i {
      font-size: 16px;
      color: #0a70b0;
    }
  }
}
.wid190{
  width:80%!important;
}
.operateBtnCon{
  width:20%;
  text-align: right;
}
</style>
