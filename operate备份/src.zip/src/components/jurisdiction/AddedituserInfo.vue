<template>
  <div class="dialoginfo">
    <div class="flex_row">
      <div class="flex_1 pl10">
        <div class="peopleTabDiv" v-if="roleName&& roleName == 'customerManage'">
          <el-radio-group v-model="tabTypeVal" @change="changePeopleType">
            <el-radio-button :label="item.value" v-for="(item, index) in typeArr" :key="index">{{item.name}}</el-radio-button>
           </el-radio-group>
        </div>
        <div class="search-bar flex_row mt10">
          <div v-if="InstitutionList&&InstitutionList.length !== 0">
            <span>所属机构：</span>
            <el-select class="width_200_input" v-model="search.InstitutionId" placeholder="请选择" @change="Institutionchagen">
              <el-option
                v-for="item in InstitutionList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </div>
          <div class="ml10">
            <span>用户名：</span>
            <el-input type="text" v-model="search.username" class="width_200_input" placeholder=""></el-input>
          </div>
          <div class="ml10">
            <el-button type="primary" size="small" @click="serchListFn">确定</el-button>
          </div>
        </div>
        <div class="tableDiv" v-bind:class="{ 'noTableData': userlist.length == 0 }">
          <el-table
            ref="CheckuserTable"
            class="mt10"
            border
            :data="userlist"
            style="width: 100%"
            height="100%"
            v-bind:row-key="getRowKeys"
            @select="handleSelectionChange"
            @select-all="handleSelectionChange">
            <el-table-column type="selection" v-bind:reserve-selection="true" width="55"></el-table-column>
            <el-table-column prop="name" label="姓名" width="150"></el-table-column>
            <!-- <el-table-column v-if="institution_name" prop="institution_name" label="所属机构"></el-table-column>
            <el-table-column v-if="title" prop="title" label="职称" width="100"></el-table-column> -->
            <el-table-column prop="phone" label="联系电话" ></el-table-column>
          </el-table>
        </div>
        <div class="blockPage">
          <pagination-tool :layout="pageLayout" :total="pageInfo.total_count" :page.sync="pageInfo.page_index" :limit.sync="pageInfo.page_size" @pagination="pageSizeChangeFn" />
        </div>
      </div>
      <div class="checksuer">
        <div class="clr_333 lh40">已选人员：</div>
        <div class="allCheckedUser">
          <div class="checksueritem" v-for="item in checkeduser" :key="item.id">
            <span>{{item.name}}</span>
            <span class="delMeal fr" v-on:click="del(item.id)">
              <i class="iconfont">&#xe63a;</i>
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import PaginationTool from '@/components/common/PaginationTool'
export default {
  props: {
    userinfo: Object,
    InstitutionList: Array,
    search: Object,
    userlist: Array,
    checkeduser: Array,
    pageInfo: Object,
    roleName: {
      type: String,
      default: 'customerManage',
    }
  },
  components: {
    PaginationTool
  },
  data () {
    return {
      tabTypeVal: 1,
      isIndeterminate: true,
      checkAll: false,
      pageLayout: 'total, prev, pager, next, jumper',
      typeArr:[
        {
          name: '普通用户',
          value: 1,
        },
        {
          name: '运维用户',
          value: 2,
        },
      ],
    }
  },
  mounted () {
    // const self = this
    // self.$nextTick(() => {
    //   self.$refs.CheckuserTable.toggleRowSelection(self.userlist[2], true)
    // })
  },
  methods: {
    checkedTableTr () {
      const self = this
      let ids  = []
      if (self.checkeduser.length !== 0) {
        self.checkeduser.forEach((val) => {
          ids.push(val.id)
        })
      }
      self.$nextTick(() => {
      self.userlist.forEach((item) => {
        if (ids.indexOf(item.id) !== -1) {
          self.$refs.CheckuserTable.toggleRowSelection(item, true) 
        } else {
          self.$refs.CheckuserTable.toggleRowSelection(item, false)
        }
       })
      })
    },
    // 切换普通用户或运维用户
    changePeopleType (val) {
      this.$emit('changePeopleType',val)
    },
    getRowKeys (row) {
      return row.id
    },
    handleSelectionChange (val) {
      this.$emit('userselectChange', val)
    },
    del (id) {
      this.$emit('delCheckuser', id)
    },
    pageSizeChangeFn (info) {
      this.$emit('pageSizeChangeFn', info, 'adduser')
    },
    Institutionchagen (val) {
      this.$emit('Institutionchagen', val)
    },
    serchListFn () {
      this.$emit('serchListFn', 'searchUser', this.tabTypeVal)
    }
  }
}
</script>

<style lang="less" scoped>
.checkalltab{
  height: 350px;
  border:1px solid rgba(220, 223, 230, 1)
}
.checkalltab_title{
  height:40px;
  line-height: 40px;
  padding: 0px 10px;
  background:rgba(249,249,249,1);
  border-bottom:1px solid rgba(220, 223, 230, 1);
}
.checkalltab_list{
  height: 300px;
  overflow-y: scroll;
}
.w_340{
  width: 340px;
}
// 权限信息
.checkbox_group{
  min-width: 18%;
  margin-bottom: 10px;
}
.checksuer{
  width: 210px;
  padding: 10px;
  height:500px;
  .allCheckedUser{
    height: 460px;
    overflow-y:auto;
  }
}
.checksueritem{
  width: 100%;
  line-height: 30px;
  padding: 0px 10px;
  background: #E6F3FF;
  border-radius: 4px;
  margin-bottom: 10px;
  cursor: pointer;
}
.checksueritem:hover .delMeal{
  display: block;
}
.delMeal{
  display: none;
}
.h500{
  height: 500px;
}
.operatebtn{
  padding: 0px 15px;
  height:32px;
  line-height: 32px;
  background:rgba(10,112,176,1);
  border:1px solid rgba(10, 112, 176, 1);
  border-radius:4px;
  color: #fff;
  margin-left: 38%;
}
::v-deep .peopleTabDiv{
  margin-top:10px;
  .el-radio-group{
  height:32px;
  line-height: 30px;
  .el-radio-button__inner{
    height:32px;
    line-height: 30px;
    padding:0 10px!important;
    text-align: center;
  }
  .el-radio-button__orig-radio:checked+.el-radio-button__inner{
      background-color: #0a70b0!important;
      border-color: #0a70b0!important;
  }
 }
}
::v-deep .tableDiv{
  height:400px;
  .el-table__body-wrapper{
    height:calc(100% - 40px);
    overflow-y: auto;
  }
}
</style>
