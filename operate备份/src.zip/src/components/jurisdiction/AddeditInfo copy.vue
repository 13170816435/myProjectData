<template>
  <div class="dialoginfo">
    <el-form :model="userGroupInfo.groupInfo" :rules="userGroupInfo.rules" ref="userGroupInfo.groupInfo" label-width="110px" class="demo-ruleForm pb5">
      <el-row class="mt10 pl20">
        <div class="bold lh30 clr_303 pl10"><span class="border_l"></span>基本信息</div>
        <el-col :span="12" v-if="systemList">
          <el-form-item label="所属系统:" prop="system_code" class="w_340">
            <el-select class="ml5" v-model="userGroupInfo.groupInfo.system_id" placeholder="请选择" @change="systemChange" style="width:235px">
              <el-option
                v-for="item in systemList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <div class="flex_row w_340 lh40">
            <div class="mr5"><i class="iconfont iconbitian clr_da"></i>用户组名称 :</div>
            <el-input v-model="userGroupInfo.groupInfo.name" class="width_240_input"></el-input>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="flex_row w_340 lh40">
            <div class="mr5">用户组描述 :</div>
            <el-input v-model="userGroupInfo.groupInfo.description" class="width_240_input"></el-input>
          </div>
        </el-col>
      </el-row>
      <div class="CheckBoxlist">
        <div class="bold lh30 clr_303 pl20"><span class="border_l"></span>权限信息</div>
        <div class="checkalltab pl20" v-if="checkedInfo && roleName === 'customerManage'">
          <el-checkbox-group v-model="checkedInfo" @change="checkedInfoFn">
            <el-checkbox class="checkeditem" :disabled="item.disabled" v-for="item in userGroupInfo.AthorityGroupsArr" :key="item.id" :label="item.id" v-bind:title="item.description">{{item.name}}</el-checkbox>
          </el-checkbox-group>
        </div>
        <el-tabs v-model="userGroupInfo.authorityTabactive" type="card" v-else>
          <el-tab-pane v-for="(itemTab, tabIndex) in  userGroupInfo.AthorityGroupsArr" :key="tabIndex" :label="itemTab.name" :name="itemTab.code">
            <div class="checkalltab">
              <div class="flex_row flex_wrap pl20 mt10">
                <div class="checkbox_group" v-for="item in itemTab.authorities" :key="item.id">
                  <template>
                    <el-checkbox v-if="item.policies.length === 0" class="check1" style="font-weight: 600;margin-bottom: 15px" :disabled="item.disabled"  v-model="item.checked" @change="checked=>chooseAuthoy(item.checked,item.id)" :label="item.id" v-bind:title="item.description">
                      {{item.name}}
                    </el-checkbox>
                    <el-popover v-else class="mt15" placement="bottom" width="100" trigger="click" >
                      <el-checkbox class="mt10" :disabled="item.disabled" @change="childcheckFn($event, item.id)" v-model="policiesitem.checked" v-for="policiesitem in item.policies" :key="policiesitem.code" :label="policiesitem.code" v-bind:title="policiesitem.description">{{policiesitem.name}}</el-checkbox><br/>
                      <span class="blod" slot="reference">
                        <el-checkbox v-model="item.checked" :disabled="item.disabled" @change="changeCheck($event, item.id)" :label="item.id" v-bind:title="item.description">{{item.name}}</el-checkbox>
                        <i class="iconfont iconxialazhankai pointer"></i>
                      </span>
                    </el-popover>
                  </template>
                </div>
              </div>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
      <el-form-item class="mt20 pr20 tr">
        <el-button size="small" plain @click="submitForm('', 'userGroupInfo.groupInfo')">取消</el-button>
        <el-button size="small" type="primary" @click="submitForm('submit','userGroupInfo.groupInfo')">保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  props: {
    systemList: Array,
    userGroupInfo: Object,
    checkedInfo: Array,
    roleName: String
  },
  data () {
    return {
      isIndeterminate: true,
      checkAll: false,
      checkedList: []
    }
  },
  methods: {
    submitForm (type, formName) {
      var info = {
        type: type,
        formName: formName,
        refs: this.$refs
      }
      this.$emit('submitForm', info)
    },
    chooseAuthoy (checked, index) {
      this.$emit('chooseAuthoy', checked, index)
    },
    changeCheck (e, val) {
      this.$emit('changeCheck', e, val)
    },
    childcheckFn (e, val) {
      this.$emit('childcheckFn', e, val)
    },
    systemChange (val) {
      this.$emit('systemChange', val)
    },
    checkedInfoFn (val) {
      this.$emit('checkedInfoFn', val)
    }
  },
  mounted () {
    console.log('this.checkedInfo',this.checkedInfo)
  }
}
</script>

<style lang="less" scoped>
.checkalltab{
  height: 350px;
  border:1px solid rgba(220, 223, 230, 1);
  border-top: none;
  overflow: auto;
}
.checkalltab_title{
  height:40px;
  line-height: 40px;
  padding: 0px 10px;
  background:rgba(249,249,249,1);
  border-bottom:1px solid rgba(220, 223, 230, 1);
}
.checkalltab_list{
  height: 300px;
  overflow-y: scroll;
}
.w_340{
  width: 340px;
}
// 权限信息
.checkbox_group{
  min-width: 18%;
  margin-bottom: 10px;
}
.checkeditem{
  min-width: 16.5%;
  margin-top: 10px;
  margin-bottom: 10px;
}
.consol-btn{
  display: inline-block; 
  min-width: 64px;
  height: 32px;
  line-height: 32px;
  text-align: center;
  padding: 0px 5px;
  cursor: pointer;
  background: #FFF;
  border: 1px solid #DCDFE6;
}
.saveBtn{
  color:#fff;
  padding: 0px 5px!important;
  min-width: 64px;
  height: 32px;
  line-height: 32px;
  background-color: #0A70B0;
}
</style>
