<template>
  <div class="versionManageCon">
    <div class="title-bar flex_row crumbsBox">
      <div class="tl crumbsCon">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>系统运维
          <i class="iconfont iconzhankaishouqi"></i>
        </span>

        <div class="m-tab">
          <div
            class="m-tab-item"
            :class="tabIndex === index ? 'm-tab-item-active' : ''"
            v-for="(item, index) in tabList"
            :key="index"
            @click="toggleTab(index, item.value)"
          >
            {{ item.label }}
          </div>
          <div class="tab-line" :style="{ left: number + 'px' }"></div>
        </div>
      </div>
    </div>
    <div class="versionManageBox">
      <!--数据库概要-->
      <div v-if="tabType == 1" class="dataBaseGeneral">
        <!--检测前-->
        <div class="beforeInspect" v-if="inspectStatus == 'beforeInspect'">
          <div class="lastestVersionCon">
            <img
              class="inspectLeftImg"
              src="../../../assets/images/dataBase/blueInspectLeft.png"
              alt=""
            />
            <img
              class="inspectRightImg"
              src="../../../assets/images/dataBase/blueInspectRight.png"
              alt=""
            />
            <div class="inspectChart">
              <img src="../../../assets/images/dataBase/inspect.png" alt="" />
            </div>
            <div class="inspectRightCon">
              <div class="lastestVersionContent" v-if="hasNewVersion">
                监测到最新版本:<span class="versionVal">{{
                  latestVersionObj &&
                  latestVersionObj.name
                }}</span>
              </div>
              <div class="lastestVersionContent" v-if="!hasNewVersion">
                无版本信息
              </div>
              <div class="inspectTip">请及时进行数据库检测</div>
              <div class="inspectBtnCon">
                <span class="uploadVersionBtn" @click="uploadOneVersion"
                  >上传版本</span
                >
                <div
                  class="hoverable set_4_button2"
                  @click="beganInspect"
                  v-if="hasNewVersion"
                >
                  <div class="anim"></div>
                  <div class="applyUseBtnText">开始检测</div>
                </div>
              </div>
            </div>
          </div>
          <div
            class="allDataBase"
            v-loading="loading"
            element-loading-text="拼命加载中"
            element-loading-background="rgba(255,255,255,0.6)"
            v-bind:class="{ 'noTableData': dataBaseVersionList.length == 0 }"
          >
            <div
              class="oneDataBase"
              v-for="(item, index) in dataBaseVersionList"
              :key="index"
            >
              <div class="oneDataBaseBox">
                <div class="tenancyNameCon">
                  <span class="oneDataBaseNumber">{{
                    index + 1 > 9 ? index + 1 : "0" + (index + 1)
                  }}</span>
                  <span class="oneTenancyName"
                    >【{{ item.tenancy_name }}】</span
                  >
                  <span class="oneDataBaseName">{{ item.database }}</span>
                  <div class="oneDataBaseVersion" v-if="item.version">
                    <img
                      src="../../../assets/images/dataBase/versionLeft.png"
                      alt=""
                    />
                    <div class="versionCenterCon">
                      {{ item.version }}
                    </div>
                    <img
                      src="../../../assets/images/dataBase/versionRight.png"
                      alt=""
                    />
                  </div>
                </div>
                <div class="productNameCon">
                  <span class="dataBaseLabel">授权产品：</span
                  ><span :title="item.product_names">{{
                    item.product_names
                  }}</span>
                </div>
                <div class="updateDesc">
                  <div class="">
                    <span class="dataBaseLabel">最后更新：</span>
                    <span  v-if="item.result">{{ item.result.operator_name }}（{{ item.result.operate_time }}）</span>
                  </div>
                  <div class="rightUpdateDesc">
                    <span class="dataBaseLabel">更新描述：</span>
                    <span v-if="item.result">
                      <span>执行成功{{item.result.succeeded_count}}条,执行失败{{item.result.failed_count}}条</span>
                    </span>
                  </div>
                </div>
              </div>
              <div class="inspectStatusCon">
                <img
                  src="../../../assets/images/dataBase/inspecting.png"
                  v-if="item.state == 10"
                  alt=""
                />
                <img
                  src="../../../assets/images/dataBase/updateing.png"
                  v-if="item.state == 20"
                  alt=""
                />
                <img
                  src="../../../assets/images/dataBase/waitInspect.png"
                  v-if="item.state == 0"
                  alt=""
                />
                <div
                  class="statusDesc waitInspectStatus"
                  v-if="item.state == 0"
                >
                  待检测
                </div>
                <div class="statusDesc inspectStatus" v-if="item.state == 10">
                  检测中
                </div>
                <div class="statusDesc inspectFinish" v-if="item.state == 11">
                  检测完成
                </div>
                <div class="statusDesc inspectFail" v-if="item.state == 12">
                  检测失败
                </div>
                <div class="statusDesc updateStatus" v-if="item.state == 20">
                  更新中
                </div>
                <div class="statusDesc inspectFinish" v-if="item.state == 21">
                  更新完成
                </div>
                <div class="statusDesc inspectFail" v-if="item.state == 22">
                  更新失败
                </div>
              </div>
            </div>
          </div>
        </div>

        <!--检测中-->
        <div
          class="beforeInspect inspecting"
          v-if="inspectStatus == 'inspecting'"
        >
          <div class="lastestVersionCon">
            <img
              class="inspectLeftImg"
              src="../../../assets/images/dataBase/greenInspectLeft.png"
              alt=""
            />
            <img
              class="inspectRightImg"
              src="../../../assets/images/dataBase/greenInspectRight.png"
              alt=""
            />
            <div class="inspectChart progressChart">
              <chart-item
                :option="progressOption"
                :action="'consult'"
                v-show="progressOption"
              ></chart-item>
            </div>
            <div class="inspectRightCon">
              <div class="lastestVersionContent">
                数据库版本与上传版本<span class="versionVal">{{
                  latestVersionObj &&
                  latestVersionObj.name
                }}</span
                >对比检测中
              </div>
              <div class="inspectTip inspectingTip">
                正在检测：【{{ curInspectDataBase.tenancy_name }}】{{
                  curInspectDataBase.database
                }}
              </div>
              <div class="inspectBtnCon progressCon">
                <el-progress
                  class="clear"
                  :text-inside="true"
                  :stroke-width="15"
                  :percentage="progressVal"
                  :color="processColorFn(progressVal)"
                ></el-progress>
              </div>
            </div>
          </div>
          <div
            class="allDataBase"
            v-loading="loading"
            element-loading-text="拼命加载中"
            element-loading-background="rgba(255,255,255,0.6)"
            v-bind:class="{ 'noTableData': dataBaseVersionList.length == 0 }"
          >
            <div
              class="oneDataBase"
              v-for="(item, index) in dataBaseVersionList"
              :key="index"
            >
              <div class="oneDataBaseBox">
                <div class="tenancyNameCon">
                  <span class="oneDataBaseNumber">{{
                    index + 1 > 10 ? index + 1 : "0" + (index + 1)
                  }}</span>
                  <span class="oneTenancyName"
                    >【{{ item.tenancy_name }}】</span
                  >
                  <span class="oneDataBaseName">{{ item.database }}</span>
                  <div class="oneDataBaseVersion" v-if="item.version">
                    <img
                      src="../../../assets/images/dataBase/versionLeft.png"
                      alt=""
                    />
                    <div class="versionCenterCon">
                      {{ item.version }}
                    </div>
                    <img
                      src="../../../assets/images/dataBase/versionRight.png"
                      alt=""
                    />
                  </div>
                </div>
                <div class="productNameCon">
                  <span class="dataBaseLabel">授权产品：</span
                  ><span :title="item.product_names">{{
                    item.product_names
                  }}</span>
                </div>
              </div>
              <div class="inspectStatusCon">
                <img
                  src="../../../assets/images/dataBase/inspecting.png"
                  v-if="item.state == 10"
                  alt=""
                />
                <img
                  src="../../../assets/images/dataBase/updateing.png"
                  v-if="item.state == 20"
                  alt=""
                />
                <img
                  src="../../../assets/images/dataBase/waitInspect.png"
                  v-if="item.state == 0"
                  alt=""
                />
                <div
                  class="statusDesc waitInspectStatus"
                  v-if="item.state == 0"
                >
                  待检测
                </div>
                <div class="statusDesc inspectStatus" v-if="item.state == 10">
                  检测中
                </div>
                <div class="statusDesc inspectFinish" v-if="item.state == 11">
                  检测完成
                </div>
                <div class="statusDesc inspectFail" v-if="item.state == 12">
                  检测失败
                </div>
                <div class="statusDesc updateStatus" v-if="item.state == 20">
                  更新中
                </div>
                <div class="statusDesc inspectFinish" v-if="item.state == 21">
                  更新完成
                </div>
                <div class="statusDesc inspectFail" v-if="item.state == 22">
                  更新失败
                </div>
              </div>
              <!---当版本跟最新版本一样时   展示检测后的内容--->
              <div class="updateTipCon mt5" v-if="item.content && (item.content.version_id == latestVersionObj.id )">
                <div
                  class="updateTipTitle"
                  @click.stop="showAllContent($event,index)"
                >
                  <span
                    ><i class="iconfont mr10">&#xe646;</i>存在
                    {{
                      item.content.alter_count + item.content.drop_count
                    }}
                    项数据结构需要更新升级（注意：其中包含DROP语句{{
                      item.content.drop_count
                    }}项，ALTER语句{{ item.content.alter_count }}项）
                  </span>
                  <i class="showAllIcon iconfont">&#xe675;</i>
                </div>
                <div class="updateContent">
                  <div
                    class="allUpdateContent"
                    ref="allUpdateContent"
                    v-html="$replaceRN(item.content.content)"
                  ></div>
                  <div
                    class="copyBtn"
                    @click.stop="copyContent(item.content.content)"
                  >
                    复制语句
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!--检测完成-->
        <!---0:待检测, 10:检测中，11:检测完成，12:检测失败，20:更新中，21:更新完成，22:更新失败-->
        <div
          class="beforeInspect inspectFinish"
          v-if="inspectStatus == 'inspectFinish'"
        >
          <div class="lastestVersionCon">
            <img
              class="inspectLeftImg"
              src="../../../assets/images/dataBase/blueInspectLeft.png"
              alt=""
            />
            <img
              class="inspectRightImg"
              src="../../../assets/images/dataBase/blueInspectRight.png"
              alt=""
            />
            <div class="inspectRightCon">
              <div class="lastestVersionContent" v-if="hasNewVersion">
                数据库版本与上传版本<span class="versionVal">{{
                  latestVersionObj &&
                  latestVersionObj.name
                }}</span
                >对比检测完成,概要如下:
              </div>
            </div>
          </div>

          <div class="allDataBase"
            v-loading="loading"
            element-loading-text="拼命加载中"
            element-loading-background="rgba(255,255,255,0.6)"
            v-bind:class="{ 'noTableData': dataBaseVersionList.length == 0 }">
            <div class="operateDataBaseCon">
              <el-checkbox v-model="isCheckedAll" @change="changeCheckedAll"
                >全选/全不选</el-checkbox
              >
              <div class="operateDataBaseBtnCon">
                <span
                  class="operateDataBaseBtn blueOperateBtn mr10"
                  @click="uploadOneVersion"
                  >上传版本</span
                >
                <span
                  class="operateDataBaseBtn blueOperateBtn mr10"
                  @click="reInspectMoreTenancy"
                  >重新检测</span
                >
                <span
                  class="operateDataBaseBtn greenOperateBtn mr10"
                  @click="updateMoreTenancy"
                  >批量更新</span
                >
                <span
                  class="operateDataBaseBtn updateCagetyBtn"
                  @click="watchUpdateCagety"
                  >更新策略</span
                >
              </div>
            </div>
            <div
              class="allDataBaseCon"
              v-bind:class="{ noTableData: dataBaseVersionList.length == 0 }"
            >
              <div
                class="oneDataBase"
                v-for="(item, index) in dataBaseVersionList"
                :key="index"
              >
                <div class="oneDataBaseBox">
                  <div class="tenancyNameCon checkedCon">
                    <el-checkbox v-model="item.is_checked" :disabled="item.g_than_latest_version"></el-checkbox>
                    <span class="oneTenancyName"
                      >【{{ item.tenancy_name }}】</span
                    >
                    <span class="oneDataBaseName">{{ item.database }}</span>
                    <div class="oneDataBaseVersion" v-if="item.version">
                      <img
                        src="../../../assets/images/dataBase/versionLeft.png"
                        alt=""
                      />
                      <div class="versionCenterCon">
                        {{ item.version }}
                      </div>
                      <img
                        src="../../../assets/images/dataBase/versionRight.png"
                        alt=""
                      />
                    </div>
                  </div>
                  <div class="productNameCon">
                    <span class="dataBaseLabel">授权产品：</span
                    ><span :title="item.product_names">{{
                      item.product_names
                    }}</span>
                  </div>
                  <div class="updateDesc">
                    <div class="">
                      <span class="dataBaseLabel">最后更新：</span>
                      <span  v-if="item.result">{{ item.result.operator_name }}（{{ item.result.operate_time }}）</span>
                    </div>
                    <div class="rightUpdateDesc">
                      <span class="dataBaseLabel">更新描述：</span>
                      <span v-if="item.result">
                        <span>执行成功{{item.result.succeeded_count}}条,执行失败{{item.result.failed_count}}条</span>
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  class="inspectStatusCon"
                  :class="{
                    hasUpdateBtn: item.state == 11 || item.state == 22,
                  }"
                >
                  <img
                    src="../../../assets/images/dataBase/inspecting.png"
                    v-if="item.state == 10"
                    alt=""
                  />
                  <img
                    src="../../../assets/images/dataBase/updateing.png"
                    v-if="item.state == 20"
                    alt=""
                  />
                  <img
                    src="../../../assets/images/dataBase/waitInspect.png"
                    v-if="item.state == 0"
                    alt=""
                  />
                  <div
                    class="statusDesc waitInspectStatus"
                    v-if="item.state == 0"
                  >
                    待检测
                  </div>
                  <div class="statusDesc inspectStatus" v-if="item.state == 10">
                    检测中
                  </div>
                  <div
                    class="statusDesc inspectFinish reInspectBtn"
                    v-if="item.state == 11 || item.state == 12"
                    @click="reInspectOneTenacny(item.tenancy_id)"
                  >
                    <!--检测完成 检测失败-->
                    重新检测
                  </div>
                  <!-- <div class="statusDesc inspectFail"  v-if="item.state == 12">检测失败</div> -->
                  <div class="statusDesc updateStatus" v-if="item.state == 20">
                    更新中
                  </div>
                  <div class="statusDesc inspectFinish" v-if="item.state == 21">
                    更新完成
                  </div>
                  <div
                    class="statusDesc inspectFinish updateBtn ml10"
                    v-if="item.state == 11 || item.state == 22"
                    :disabled="item.g_than_latest_version"
                    :class="{'disabledUpdateBtn':item.g_than_latest_version}"
                    @click="updateOneTenacny(item)"
                  >
                    更新
                  </div>
                  <!-- <div class="statusDesc inspectFail"  v-if="item.state == 22">更新失败</div> -->
                </div>
                <div class="updateTipCon mt5" v-if="item.content">
                  <div
                    class="updateTipTitle"
                    @click.stop="showAllContent($event,index)"
                  >
                    <span
                      ><i class="iconfont mr10">&#xe646;</i>存在
                      {{
                        item.content.alter_count + item.content.drop_count
                      }}
                      项数据结构需要更新升级（注意：其中包含DROP语句{{
                        item.content.drop_count
                      }}项，ALTER语句{{ item.content.alter_count }}项）
                    </span>
                    <i class="showAllIcon iconfont">&#xe675;</i>
                  </div>
                  <div class="updateContent">
                    <div
                      class="allUpdateContent"
                      ref="allUpdateContent"
                      v-html="$replaceRN(item.content.content)"
                    ></div>
                    <div
                      class="copyBtn"
                      @click.stop="copyContent(item.content.content)"
                    >
                      复制语句
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--更新记录-->
      <div v-if="tabType == 2" class="updateDataBaseMemory">
        <updateDataBaseMemoryQuery
          @getList="getList"
        ></updateDataBaseMemoryQuery>
        <div class="allUpdatememoryCon">
          <div
            class="allUpdatememory clear"
            v-loading="updateMemoryloading"
            element-loading-text="拼命加载中"
            element-loading-background="rgba(255,255,255,0.6)"
            v-bind:class="{ noTableData: updateMemoryTableData.length == 0 }"
          >
            <el-table
              :data="updateMemoryTableData"
              border
              stripe
              height="100%"
              ref="memoryTableAutoScroll"
              highlight-current-row
              @sort-change="sortMemoryChange"
            >
              <el-table-column
                fixed="left"
                align="center"
                type="index"
                label="序号"
                width="55"
              >
                <template slot-scope="scope">
                  <span>{{
                    (searchMemoryParam.offset - 1) * searchMemoryParam.limit +
                    scope.$index +
                    1
                  }}</span>
                </template>
              </el-table-column>
              <el-table-column label="操作" width="80" fixed="left">
                <template slot-scope="scope">
                  <span class="clr_0a pointer" @click="watchMemory(scope.row)">查看</span>
                </template>
              </el-table-column>
              <el-table-column prop="state" label="状态" width="120">
                <template slot-scope="scope">
                  <span class="clircle running mr5" 
                  :class="{'runningError':(scope.row.state == 12 || scope.row.state == 22),'waitRunning':(scope.row.state == 0 || scope.row.state == 10 || scope.row.state == 20)}"></span>
                  <span class="updateing" v-if="scope.row.state == 0">待检测</span>
                  <span class="updateing" v-else-if="scope.row.state == 10">检测中</span>
                  <span class="udateFinished" v-else-if="scope.row.state == 11">检测完成</span>
                   <span class="updateFailed" v-else-if="scope.row.state == 12">检测失败</span>
                  <span class="updateing" v-else-if="scope.row.state == 20">更新中</span>
                  <span class="udateFinished" v-else-if="scope.row.state == 21">更新完成</span>
                  <span class="updateFailed" v-else-if="scope.row.state == 22">更新失败</span>
                </template>
              </el-table-column>
              <el-table-column prop="total" label="执行总数" width="100">
              </el-table-column>
              <el-table-column prop="wait" label="执行成功" width="100">
                <template slot-scope="scope">
                  <span class="clr_0a">{{
                    scope.row.total - scope.row.failed_count
                  }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="failed_count" label="执行失败" width="100">
                <template slot-scope="scope">
                  <span class="clr_0a">{{ scope.row.failed_count }}</span>
                </template>
              </el-table-column>
              <el-table-column
                prop="tenancy_name"
                label="客户"
                width="200"
              ></el-table-column>
              <el-table-column
                prop="version"
                label="更新版本"
                width="180"
              ></el-table-column>
              <el-table-column
                prop="failed_content"
                label="失败描述"
                width="200"
              ></el-table-column>
              <el-table-column
                prop="operator_name"
                label="更新人"
                width="100"
              ></el-table-column>
              <el-table-column
                prop="finish_time"
                label="更新时间"
              ></el-table-column>
            </el-table>
          </div>
          <div class="blockPage">
            <pagination-tool
              :total="totalUpdatePage"
              :page.sync="searchMemoryParam.offset"
              :limit.sync="searchMemoryParam.limit"
              @pagination="beganGetUpdateMemoryList"
            />
          </div>
        </div>
      </div>
      <!--版本库-->
      <div v-if="tabType == 3" class="dataBaseVersionCon">
        <dataBaseVersionQuery @getList="getVersionList">
          <span
            class="operate-btn clr_0a importInstituteBtn"
            @click="uploadVersion"
            ><i class="iconfont icondaoru mr5"></i>上传版本</span
          >
        </dataBaseVersionQuery>

        <div class="allVersionCon">
          <div
            class="allVersion clear"
            v-loading="versionloading"
            element-loading-text="拼命加载中"
            element-loading-background="rgba(255,255,255,0.6)"
            v-bind:class="{ noTableData: versionTableData.length == 0 }"
          >
            <el-table
              :data="versionTableData"
              border
              stripe
              height="100%"
              ref="tableAutoScroll"
              highlight-current-row
              @sort-change="sortVersionChange"
            >
              <el-table-column
                fixed="left"
                align="center"
                type="index"
                label="序号"
                width="55"
              >
                <template slot-scope="scope">
                  <span>{{
                    (searchVersionParam.offset - 1) * searchVersionParam.limit +
                    scope.$index +
                    1
                  }}</span>
                </template>
              </el-table-column>
              <el-table-column label="操作" width="80" fixed="left">
                <template slot-scope="scope">
                  <span
                    class="clr_da pointer pl10"
                    @click="deleteThisVersion(scope.row)"
                    >删除</span
                  >
                </template>
              </el-table-column>
              <el-table-column
                prop="file_name"
                label="更新包"
                width="220"
              ></el-table-column>
              <el-table-column
                prop="creator_name"
                label="上传人"
                width="160"
              ></el-table-column>
              <el-table-column
                prop="create_time"
                label="上传时间"
                sortable
              ></el-table-column>
            </el-table>
          </div>
          <div class="blockPage">
            <pagination-tool
              :total="totalVersionPage"
              :page.sync="searchVersionParam.offset"
              :limit.sync="searchVersionParam.limit"
              @pagination="beganGetUpdateMemoryList"
            />
          </div>
        </div>
      </div>
    </div>
    <!-- 详情 -->
    <el-drawer
      size="880"
      :modal="false"
      :visible.sync="drawer"
      :show-close="false"
      :withHeader="false"
      :direction="direction"
      :before-close="handleClose"
    >
      <dataBaseUpdateDetail
        :curTenancyDataBaseObj="curTenancyDataBaseObj"
        :key="key"
        @closeFn="closeFn"
      ></dataBaseUpdateDetail>
    </el-drawer>

    <!-- 数据库更新 -->
    <el-dialog
      title="更新提醒"
      :visible.sync="showUpdateStep"
      @close="closeDialogFn"
      width="840px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <dataBaseUpdateStep
        ref="updateStep"
        :choosedTenancyArr="choosedTenancyArr"
        :latestVersionObj="latestVersionObj"
        @setUpdateResult="setUpdateResult"
        @cancelUpdateDataBase="cancelUpdateDataBase"
      ></dataBaseUpdateStep>
    </el-dialog>

    <!-- 上传版本 -->
    <el-dialog
      title="版本上传"
      :visible.sync="isdialogInfo"
      @close="closeDialogFn"
      width="500px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <uploadVersion
        :isdialogInfo="isdialogInfo"
        :soft_info="soft_info"
        @submitForm="submitFileForm"
        @dealUploadSucBigFile="uploadBigFileSuc"
      ></uploadVersion>
    </el-dialog>

    <!-- 数据库更新策略 -->
    <el-dialog
      title="更新策略"
      :visible.sync="showUpdateCagetory"
      @close="closeDialogFn"
      width="840px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <dataBaseUpdateTip
        ref="updateCagetory"
        @cancelSaveCagety="cancelSaveCagety"
      ></dataBaseUpdateTip>
    </el-dialog>
  </div>
</template>
<script>
import * as echarts from "echarts";
import "echarts-liquidfill/src/liquidFill.js";
import updateDataBaseMemoryQuery from "./dataBaseComponents/updateDataBaseMemoryQuery";
import dataBaseUpdateDetail from "./dataBaseComponents/dataBaseUpdateDetail";
import dataBaseVersionQuery from "./dataBaseComponents/dataBaseVersionQuery";
import uploadVersion from "./dataBaseComponents/uploadVersion";
import dataBaseUpdateStep from "./dataBaseComponents/dataBaseUpdateStep";
import dataBaseUpdateTip from "./dataBaseComponents/dataBaseUpdateTip";
import PaginationTool from "@/components/common/PaginationTool"; // 分页
import ChartItem from "@/views/CustomerManagement/dataCockpit/components/ChartItem"; // enchart
import {
  getTenancySummary,
  getTenancyVersionLatest,
  dataBaseCheck,
  dataBaseUpdate,
  getDataBaseUpdateSettings,
  saveDataBaseUpdateSettings,
  getUpdateMemoryList,
  getVersionList,
  beganDeleteThisVersion,
  uploadVersionFile,
} from "@/api/platform_operate/dataBase";
export default {
  components: {
    updateDataBaseMemoryQuery,
    PaginationTool,
    dataBaseUpdateDetail,
    dataBaseVersionQuery,
    uploadVersion,
    dataBaseUpdateStep,
    dataBaseUpdateTip,
    ChartItem,
  },
  data() {
    return {
      tabIndex: 0,
      number: 0,
      tabType: 1,
      loading: false,
      curTenancyDataBaseObj: {},
      inspectStatus: "beforeInspect",
      //inspectStatus: "inspecting",
      progressVal: 0,
      ballProgressVal: 0,
      customerList: [], // 客户列表
      dataBaseVersionList: [],
      curInspectDataBase: {},
      hasNewVersion: true,
      latestVersionObj: {},
      isCheckedAll: false,
      choosedTenancyIdArr: [],
      choosedTenancyArr: [],
      tabList: [
        {
          label: "数据库概要",
          value: 1,
        },
        {
          label: "更新记录",
          value: 2,
        },
        {
          label: "版本库",
          value: 3,
        },
      ],
      showUpdateStep: false,
      showUpdateCagetory: false,
      updateMemoryloading: true,
      searchMemoryParam: {
        offset: 1,
        limit: 20,
      },
      totalUpdatePage: 0,
      updateMemoryTableData: [], // 更新记录列表
      drawer: false,
      direction: "rtl",
      key: 0,
      versionloading: true,
      versionTableData: [],
      totalVersionPage: 0,
      searchVersionParam: {
        offset: 1,
        limit: 20,
      },
      isdialogInfo: false,
      soft_info: {
        download_url: "", // 下载地址
        package_type: 1, // 文件包
        file_size: 0, // 文件大小
        file_name: "",
        description: "",
        file_hash: "",
      },
    };
  },
  computed: {
    progressOption() {
      let progressVal = this.ballProgressVal;
      let option = null;
      option = {
        //backgroundColor: '#050038',
        title: {
          text: "",
          textStyle: {
            fontWeight: "normal",
            fontSize: 14,
            color: "rgb(97, 142, 205)",
          },
        },
        series: [
          {
            type: "liquidFill",
            radius: "90%",
            center: ["50%", "50%"],
            color: "red",
            data: [
              {
                value: progressVal,
                itemStyle: { normal: { color: "rgba(0, 211, 93, 100)" } },
              },
              {
                value: progressVal,
                itemStyle: { normal: { color: "#00D35D" } },
              },
              {
                value: progressVal,
                itemStyle: { normal: { color: "#00D35D" } },
              },
            ], // data个数代表波浪数
            backgroundStyle: {
              borderWidth: 1,
              color: "rgb(255,0,255,0.1)",
            },
            label: {
              normal: {
                formatter: (progressVal * 100).toFixed(2) + "%",
                textStyle: {
                  fontSize: 20,
                },
              },
            },
            outline: {
              show: false,
            },
          },
          {
            type: "pie",
            center: ["50%", "50%"],
            radius: ["94%", "96%"],
            hoverAnimation: false,
            data: [
              {
                name: "",
                value: 100,
                labelLine: {
                  show: false,
                },
                itemStyle: {
                  color: "#00D35D",
                },
                emphasis: {
                  labelLine: {
                    show: false,
                  },
                  itemStyle: {
                    color: "#00D35D",
                  },
                },
              },
              {
                //画中间的图标
                name: "",
                value: 1,
                labelLine: {
                  show: false,
                },
                itemStyle: {
                  color: "#ffffff",
                  normal: {
                    color: "#00D35D",
                    borderColor: "#00D35D",
                    borderWidth: 4,
                    borderRadius: "100%",
                  },
                },
                label: {
                  borderRadius: "100%",
                },
                emphasis: {
                  labelLine: {
                    show: false,
                  },
                  itemStyle: {
                    color: "#00D35D",
                  },
                },
              },
              {
                // 解决圆点过大后续部分显示明显的问题
                name: "",
                value: 2,
                labelLine: {
                  show: false,
                },
                itemStyle: {
                  color: "#00D35D",
                },
                emphasis: {
                  labelLine: {
                    show: false,
                  },
                  itemStyle: {
                    color: "#00D35D",
                  },
                },
              },
              {
                //画剩余的刻度圆环
                name: "",
                value: 100 - (progressVal * 100).toFixed(2),
                itemStyle: {
                  color: "#fff",
                },
                label: {
                  show: false,
                },
                labelLine: {
                  show: false,
                },
                emphasis: {
                  labelLine: {
                    show: false,
                  },
                  itemStyle: {
                    color: "#050038",
                  },
                },
              },
            ],
          },
        ],
      };
      return option;
    },
  },
  methods: {
    toggleTab(index, value) {
      const self = this
      self.tabType = value;
      if (self.tabIndex < index) {
        self.number = index * 90; //60既是一个tab的宽度 也是tab下滑动横线的宽度
      } else {
        self.number = self.number - (self.tabIndex - index) * 90;
      }
      if (self.tabIndex != index) {
        if (self.tabType == 1) {
          // 数据库概览
          self.dataBaseVersionList = [];
          self.beganGetTenancyVersionLatest();
          self.beganGetTenancySummary();
        } else if (self.tabType == 2) {
          // 更新记录
          //self.beganGetUpdateMemoryList()
          self.$nextTick(() => {
            self.$refs.memoryTableAutoScroll.doLayout();
          });
        }
      }
      this.tabIndex = index;
    },
    // 上传版本
    uploadOneVersion() {
      this.isdialogInfo = true;
    },
    // 开始检测
    async beganInspect() {
      // 先获取所有的租户
      const self = this;
      self.inspectStatus = "inspecting";
      await this.beganGetTenancySummary();
      for (let i = 0; i < self.dataBaseVersionList.length; i++) {
        self.curInspectDataBase = self.dataBaseVersionList[i];
        self.$set(self.dataBaseVersionList[i], "state", 10);
        let res = await dataBaseCheck({
          tenancy_ids: [self.dataBaseVersionList[i].tenancy_id],
          version_id: self.latestVersionObj.id,
        });
        if (res.code === 0) {
          self.ballProgressVal = ((i + 1) / self.dataBaseVersionList.length).toFixed(2);
          self.progressVal = parseFloat((self.ballProgressVal * 100).toFixed(2)); // 处理2位小数乘以100时 出现多位小数问题(精度丢失)
          const result = res.data;
          self.$set(self.dataBaseVersionList[i], "state", result[0].state);
          self.$set(self.dataBaseVersionList[i], "content", result[0].content);
          // 将展开内容隐藏起来
          if (document.getElementsByClassName("updateContent")[i]) {
            document.getElementsByClassName("updateContent")[i].style.height = "auto";
          }
          // 全部检测完成
          if (i + 1 == self.dataBaseVersionList.length) {
            self.inspectStatus = "inspectFinish";
            // 获取最新的版本
            self.beganGetTenancyVersionLatest();
            //self.beganGetTenancySummary();
          }
        } else {
          self.$message({ type: "error", message: res.msg });
          self.ballProgressVal = ((i + 1) / self.dataBaseVersionList.length).toFixed(2);
          self.progressVal = parseFloat((self.ballProgressVal * 100).toFixed(2));
          self.$set(self.dataBaseVersionList[i], "state", 12);
          // 全部检测完成
          if (i + 1 == self.dataBaseVersionList.length) {
            self.inspectStatus = "inspectFinish";
            // 获取最新的版本
            self.beganGetTenancyVersionLatest();
            //self.beganGetTenancySummary();
          }
          
        }
      }
    },
    // 设置进度条背景颜色
    processColorFn(val) {
      // if (val < 50) {
      //   return '#1ab44a'
      // } else if (val > 50 && val < 80) {
      //   return '#e6a23c'
      // } else {
      //   return '#f56c6c'
      // }
      return "#00D35D";
    },
    // 取消更新数据库
    cancelUpdateDataBase() {
      this.showUpdateStep = false;
    },
    // 上传版本
    uploadVersion() {
      this.isdialogInfo = true;
    },
    // 关闭弹框
    closeDialogFn() {
      this.soft_info = this.$options.data().soft_info;
    },
    // 上传版本压缩包
    submitFileForm(info) {
      if (info.type === "cansol") {
        this.soft_info = this.$options.data().soft_info;
        this.isdialogInfo = false;
        //info.refs[info.formName].resetFields()
      } else {
        // info.refs[info.formName].validate((valid) => {
        //   if (valid) {
        //     this.addProductFn(info)
        //   }
        // })
        this.beganUploadVersion();
      }
    },
    // 复制
    copyContent(content) {
      this.$copyText(content);
      this.$message({ message: "复制成功", type: "success" });
    },
    // 获取数据库概要
    async beganGetTenancySummary() {
      const self = this;
      self.loading = true
      self.dataBaseVersionList = [];
      const res = await getTenancySummary();
      if (res.code === 0) {
        self.loading = false
        if (res.data.length > 0) {
          res.data.forEach((item,i) => {
            item.is_checked = false;
            // 将字符串里面的 "\n" 全部替换成 br
            if (item.content && item.content.content) {
              item.content.content = item.content.content.replace(/\n/g,"<br/>");
            }
            // 就用 "大半" 这个客户用来测试
            // if (i<20) {
            //   self.dataBaseVersionList.push(item);
            // }
            self.dataBaseVersionList.push(item)
          });
          if (
            self.inspectStatus == "inspecting" ||
            self.inspectStatus == "inspectFinish"
          ) {
            self.initContentHeight()
          }
        }
      } else {
        self.$message.error(res.msg);
      }
    },
    // 初始化 展开内容区域的高度
    initContentHeight () {
      const self = this
      if (self.dataBaseVersionList.length != 0) {
        self.$nextTick(() => {
          for (var m = 0; m < self.dataBaseVersionList.length; m++) {
            if (document.getElementsByClassName("updateContent")[m]) {
              document.getElementsByClassName("updateContent")[m].style.height = "auto";
            }
          }
        });
      }
    },
    // 获取当前最新版本的升级情况
    async beganGetTenancyVersionLatest() {
      const res = await getTenancyVersionLatest();
      if (res.code === 0) {
        if (res.data) {
          this.latestVersionObj = res.data.latest_version
          if (!this.latestVersionObj) {
            this.hasNewVersion = false;
          }
          if (this.latestVersionObj && this.latestVersionObj.is_checked) { // 为true时 代表已经检测过
            this.inspectStatus = "inspectFinish"
          } else { // 未检测过
            this.inspectStatus = "beforeInspect"
          }
        }
      } else {
        this.$message.error(res.msg);
      }
    },
    showAllContent(e,index) {
      const self = this;
      self.$nextTick(() => {
        // var contentArr = document.getElementsByClassName("updateContent");
        // var contant = contentArr[index];
        var contant = e.currentTarget.nextElementSibling;
        let height = contant.getBoundingClientRect().height; //获取页面元素的当前高度
        if (height) {
          // 关闭时
          contant.style.height = height + "px";
          let f = document.body.offsetHeight; //强制相应dom重绘，使最新的样式得到应用
          contant.style.height = "0px";
        } else {
          contant.style.height = "auto";
          height = contant.getBoundingClientRect().height;
          contant.style.height = "0";
          let f = document.body.offsetHeight;
          contant.style.height = height + "px";
        }
      });
    },
    // 全选/ 全不选
    changeCheckedAll(val) {
      for (let i = 0; i < this.dataBaseVersionList.length; i++) {
        if (!this.dataBaseVersionList[i].g_than_latest_version) {
          this.$set(this.dataBaseVersionList[i], "is_checked", val); 
        }
      }
    },
    // 验证是否选择了1个客户
    verifyChoosedOneItem() {
      const self = this;
      self.choosedTenancyIdArr = [];
      self.choosedTenancyArr = [];
      self.dataBaseVersionList.forEach((item) => {
        if (item.is_checked) {
          self.choosedTenancyIdArr.push(item.tenancy_id);
          self.choosedTenancyArr.push(item);
        }
      });
      if (self.choosedTenancyIdArr.length == 0) {
        return false;
      } else {
        return true;
      }
    },
    // 批量更新--更新策略
    async updateMoreTenancy() {
      const self = this;
      if (!self.verifyChoosedOneItem()) {
        self.$message.error("请至少选择一个客户");
        return false;
      }
      self.showUpdateStep = true;
      self.$nextTick(() => {
        self.$refs.updateStep.getCurDataBaseUpdateSettings();
        self.$refs.updateStep.active = 0;
        // self.$refs.updateStep.sureTime = 5
        // self.$refs.updateStep.initContent();
        self.$refs.updateStep.caluteRestSureTime();
      });
    },
    // 重新设置 更新结果
    async setUpdateResult(tenancy_id,state, result) {
      const self = this;
      for (let i = 0; i < self.dataBaseVersionList.length; i++) {
        if (tenancy_id == self.dataBaseVersionList[i].tenancy_id) {
          self.$set(self.dataBaseVersionList[i], "state", state);
          self.$set(self.dataBaseVersionList[i], "version", result.version);
          self.$set(self.dataBaseVersionList[i], "result", result);
        }
      }
      //self.initContentHeight()
    },
    // 更新单个客户
    async updateOneTenacny(obj) {
      const self = this;
      self.choosedTenancyArr = [];
      self.choosedTenancyArr.push(obj);
      self.showUpdateStep = true;
      self.$nextTick(() => {
        self.$refs.updateStep.getCurDataBaseUpdateSettings();
        self.$refs.updateStep.active = 0;
        // self.$refs.updateStep.sureTime = 5
        // self.$refs.updateStep.initContent();
        self.$refs.updateStep.caluteRestSureTime();
      });
    },
    // 批量重新检测
    async reInspectMoreTenancy() {
      const self = this;
      if (!self.verifyChoosedOneItem()) {
        self.$message.error("请至少选择一个客户");
        return false;
      }
      for (let i = 0; i < self.dataBaseVersionList.length; i++) {
        if (
          self.choosedTenancyIdArr.indexOf(
            self.dataBaseVersionList[i].tenancy_id
          ) != -1
        ) {
          self.$set(self.dataBaseVersionList[i], "state", 10);
          let res = await dataBaseCheck({
            tenancy_ids: [self.dataBaseVersionList[i].tenancy_id],
            version_id: self.latestVersionObj.id,
          });
          if (res.code === 0) {
            const result = res.data;
            self.$set(self.dataBaseVersionList[i], "state", result[0].state);
            self.$set(
              self.dataBaseVersionList[i],
              "content",
              result[0].content
            );
          } else {
            self.$set(self.dataBaseVersionList[i], "state", 12);
            self.$message({ type: "error", message: res.msg });
          }
        }
      }
      self.initContentHeight()
    },
    // 重新检测单个客户
    async reInspectOneTenacny(tenancy_id) {
      const self = this;
      for (let i = 0; i < self.dataBaseVersionList.length; i++) {
        if (tenancy_id == self.dataBaseVersionList[i].tenancy_id) {
          self.$set(self.dataBaseVersionList[i], "state", 10);
          let res = await dataBaseCheck({
            tenancy_ids: [self.dataBaseVersionList[i].tenancy_id],
            version_id: self.latestVersionObj.id,
          });
          if (res.code === 0) {
            const result = res.data;
            self.$set(self.dataBaseVersionList[i], "state", result[0].state);
            self.$set(
              self.dataBaseVersionList[i],
              "content",
              result[0].content
            );
          } else {
            self.$set(self.dataBaseVersionList[i], "state", 12);
            self.$message({ type: "error", message: res.msg });
          }
        }
      }
      self.initContentHeight()
    },
    // 查看更新策略
    watchUpdateCagety() {
      const self = this;
      self.showUpdateCagetory = true;
      self.$nextTick(() => {
        self.$refs.updateStep.getCurDataBaseUpdateSettings();
      });
    },
    cancelSaveCagety() {
      this.showUpdateCagetory = false;
    },
    // 上传版本
    async beganUploadVersion() {
      const res = await uploadVersionFile({
        file_id: this.soft_info.file_hash,
      });
      if (res.code === 0) {
        this.isdialogInfo = false;
        if (this.tabType == 1) {
          // 获取最新的版本
          this.beganGetTenancyVersionLatest();
          this.beganGetTenancySummary();
        } else {
          this.beganGetVersionList();
        }
      } else {
        this.$message.error(res.msg);
      }
    },
    async uploadBigFileSuc(arr, file_name, file_size) {
      console.log(arr);
      this.soft_info.file_hash = arr[arr.length - 1].id;
      this.soft_info.file_size = file_size;
      this.soft_info.file_name = file_name;
    },
    getList(obj) {
      this.searchMemoryParam = obj;
      this.beganGetUpdateMemoryList();
    },
    sortMemoryChange(sort) {
      if (sort.order === "descending") {
        this.searchVersionParam.sorts = [sort.prop + "|" + "desc"];
      } else {
        this.searchVersionParam.sorts = [sort.prop + "|" + "asc"];
      }
      this.searchVersionParam.page_index = 1;
      this.beganGetUpdateMemoryList();
    },
    // 获取更新记录列表
    async beganGetUpdateMemoryList() {
      const self = this;
      self.updateMemoryTableData = [];
      const res = await getUpdateMemoryList(self.searchMemoryParam);
      if (res.code === 0) {
        if (res.data.length != 0) {
          res.data.forEach((val) => {
            self.updateMemoryTableData.push(val);
          });
        }
        self.totalUpdatePage = res.page.total_count;
        self.updateMemoryloading = false;
      } else {
        self.updateMemoryloading = false;
        self.$message.error(res.msg);
      }
    },
    handleClose(done) {
      done();
    },
    closeFn() {
      this.drawer = false;
      var allSystemObj = document.getElementsByClassName("oneSystem");
      for (let i = 0; i < allSystemObj.length; i++) {
        allSystemObj[i].classList.remove("activeOneSystem");
      }
    },
    // 查看记录
    watchMemory(row) {
      this.curTenancyDataBaseObj = row
      if (this.curTenancyDataBaseObj.content) {
        this.curTenancyDataBaseObj.content =  this.curTenancyDataBaseObj.content.replace(/\n/g,"<br/>")
      }
      if (this.curTenancyDataBaseObj.failed_content) {
        this.curTenancyDataBaseObj.failed_content =  this.curTenancyDataBaseObj.failed_content.replace(/\n/g,"<br/>")
      }
      if (this.curTenancyDataBaseObj.succeeded_content) {
        this.curTenancyDataBaseObj.succeeded_content =  this.curTenancyDataBaseObj.succeeded_content.replace(/\n/g,"<br/>")
      }
      // console.log(this.curTenancyDataBaseObj)
      this.drawer = true;
      this.key = this.key + 1;
    },
    // 表格排序点击事件
    sortVersionChange(sort) {
      if (sort.order === "descending") {
        this.searchVersionParam.sorts = [sort.prop + "|" + "desc"];
      } else {
        this.searchVersionParam.sorts = [sort.prop + "|" + "asc"];
      }
      this.searchVersionParam.page_index = 1;
      this.beganGetVersionList();
    },
    // 获取版本列表
    async beganGetVersionList() {
      const self = this;
      self.versionTableData = [];
      const res = await getVersionList(self.searchVersionParam);
      if (res.code === 0) {
        if (res.data.length != 0) {
          res.data.forEach((val) => {
            self.versionTableData.push(val);
          });
        }
        self.totalVersionPage = res.page.total_count;
        self.versionloading = false;
      } else {
        self.versionloading = false;
        self.$message.error(res.msg);
      }
    },
    getVersionList(obj) {
      this.searchVersionParam = obj;
      this.beganGetVersionList();
    },
    // 删除版本
    async beganDeleteThisVersion(id) {
      const _parmas = {
        id: id,
      };
      const res = await beganDeleteThisVersion(_parmas);
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: "删除成功！",
        });
        this.beganGetVersionList();
      } else {
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    // 删除当前版本
    deleteThisVersion(row) {
      this.$confirm(
        '<i class="iconfont icontishi clr_e6 mr5"></i>确定要删除该版本？',
        "删除用户",
        {
          distinguishCancelAndClose: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
        }
      ).then(() => {
        this.beganDeleteThisVersion(row.id);
      });
    },
  },
  created () {
    // 获取最新的版本
    this.beganGetTenancyVersionLatest();
  },
  mounted() {
    this.beganGetTenancySummary();
  },
};
</script>
<style lang="less" scoped>
.m-tab {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.m-tab-item {
  width: 90px;
  color: #0a70b0;
  font-size: 15px;
  text-align: center;
  cursor: pointer;
}
.m-tab-item-active {
  color: #0a70b0;
  font-weight: 700;
}
.tab-line {
  height: 2px;
  width: 90px;
  background: #0a70b0;
  position: absolute;
  bottom: 0;
  left: 0;
  transition: all 0.3s ease;
}
.crumbsCon {
  display: flex;
}
.crumbsBox {
  justify-content: space-between;
}
.versionManageCon {
  height: 100%;
}
.versionManageBox {
  height: calc(100% - 46px);
}
.dataBaseGeneral,
.updateDataBaseMemory,
.dataBaseVersionCon {
  height: 100%;
}
.dataBaseVersionCon,
.updateDataBaseMemory {
  padding: 10px;
}
.allUpdatememoryCon {
  height: calc(100% - 42px);
  .allUpdatememory {
    height: calc(100% - 56px);
    ::v-deep .el-table__fixed-body-wrapper{
      height: calc(100% - 40px);
    }
  }
}
.beforeInspect {
  background: #f5f7fa;
  height: 100%;
  // padding: 10px;
  // padding-top:0px;
}

.lastestVersionCon {
  display: flex;
  justify-content: center;
  background: linear-gradient(0deg, #fbfcff, #f0f6ff);
  box-shadow: 0 1px 2px 0 #00000005;
  padding-top: 20px;
  position: relative;
  border-bottom: 2px solid #fff;
  .inspectLeftImg {
    position: absolute;
    top: 0px;
    left: 0px;
  }
  .inspectRightImg {
    position: absolute;
    top: 0px;
    right: 0px;
  }
  .progressChart {
    width: 130px;
    height: 130px;
  }
}
.inspecting .lastestVersionCon {
  min-height: 168px;
}
.inspectFinish .inspectRightImg,
.inspectFinish .inspectLeftImg {
  height: 70px;
}
.inspectFinish .lastestVersionCon {
  min-height: 70px;
  align-items: center;
  padding-top: 0px;
}
.inspectFinish .lastestVersionContent {
  margin-bottom: 0px !important;
}
.inspectRightCon {
  margin-left: 40px;
  z-index:100;
  .lastestVersionContent {
    font-size: 30px;
    letter-spacing: 3px;
    color: #1f2329;
    line-height: 40px;
    margin-bottom: 10px;
    .versionVal {
      color: #206beb;
      padding-left: 10px;
    }
  }
  .inspectTip {
    color: #606266;
    font-size: 16px;
    line-height: 32px;
    margin-bottom: 20px;
  }
  .inspectingTip {
    color: #303133;
  }
  .inspectBtnCon {
    display: flex;
    .uploadVersionBtn {
      width: 130px;
      height: 42px;
      line-height: 42px;
      border-radius: 21px 21px 21px 21px;
      background: linear-gradient(0deg, #0a70b0, #0d88d5);
      box-shadow: 0 4px 12px 0 #0a70b04d;
      color: #fff;
      cursor: pointer;
      text-align: center;
      font-size: 16px;
      margin-right: 30px;
    }
  }
  // 进度条
  ::v-deep .progressCon {
    .el-progress {
      width: 100%;
    }
    .el-progress-bar__innerText { //进度条 进度值的样式设置
      position: relative;
      top: -17px;
      z-index: 1000;
      color: #fff!important;
    }
   .el-progress-bar__inner:before{
     content:"";
     width:100%;
     height:100%;
     display:block;
     background-image:repeating-linear-gradient(-45deg,hsla(0,0%,100%,.15) 25%,transparent 0,transparent 50%,hsla(0,0%,100%,.15) 0,hsla(0,0%,100%,.15) 75%,transparent 0,transparent);
     background-size:40px 40px;
     animation:mymove 2s linear infinite;
   }
   @keyframes mymove{
      0%   {background-position: 0;}
      25%  {background-position: 50px;}
      50%  {background-position: 100px;}
      75%  {background-position: 150px;}
      100% {background-position: 200px;}
    }
  }
}
.allDataBase {
  width: 1240px;
  height: calc(100% - 190px);
  margin: 0 auto;
  margin-top: 10px;
  background: #ffffff;
  box-shadow: 0 6px 8px 0 #00000008;
  overflow-y: auto;
  .oneDataBase {
    padding: 20px;
    border-bottom: 1px dashed #dcdfe6;
    display: flex;
    justify-content: space-between;
    .tenancyNameCon {
      display: flex;
      .oneDataBaseNumber {
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 14px;
        color: #303133;
        font-weight: 700;
        width: 30px;
        height: 30px;
        border-radius: 3px 3px 3px 3px;
        background: url("../../../assets/images/dataBase/numberBg.png");
      }
      .oneTenancyName {
        font-size: 15px;
        color: #303133;
        font-weight: 700;
        letter-spacing: 3px;
        line-height: 24px;
      }
      .oneDataBaseName {
        font-size: 15px;
        color: #303133;
        font-weight: 700;
        letter-spacing: 3px;
        line-height: 24px;
        margin-left: 10px;
      }
      .oneDataBaseVersion {
        font-size: 14px;
        font-weight: 700;
        margin-left: 15px;
        color: #e6a23c;
        height: 24px;
        display: flex;
        align-items: center;
        // background:#E6A23C;
        .versionCenterCon {
          line-height: 24px;
          background: url("../../../assets/images/dataBase/versionCenter.png")
            center repeat;
        }
      }
    }
    .checkedCon {
      align-items: center;
    }
    .productNameCon {
      font-size: 14px;
      color: #303133;
      line-height: 32px;
      max-width: 600px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      padding-left: 36px;
      .dataBaseLabel {
        color: #909399;
      }
    }
    .updateDesc {
      display: flex;
      font-size: 14px;
      line-height: 24px;
      color: #303133;
      padding-left: 36px;
      .dataBaseLabel {
        color: #909399;
      }
      .rightUpdateDesc {
        margin-left: 220px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 430px;
      }
    }
    .updateTipCon {
      width: 100%;
      background: #f5f5f7;
      overflow: hidden;
      margin-left: 36px;
      .updateTipTitle {
        // height: 30px;
        line-height:30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: #ff6600;
        font-size: 14px;
        padding: 0 10px;
        cursor: pointer;
        border-bottom: 1px solid #fff;
        .showAllIcon {
          cursor: pointer;
        }
      }
      .updateContent {
        transition: height 0.5s; // 动画效果
        position: relative;
        max-height: 300px;
        overflow-y: auto;
        .allUpdateContent {
          padding: 10px 100px 10px 10px;
          font-size: 14px;
          color: #606266;
          line-height: 20px;
        }
        .copyBtn {
          position: absolute;
          top: 10px;
          right: 10px;
          cursor: pointer;
          border-radius: 0 0 0 15px;
          background: #e4e7ed;
          padding: 5px 10px;
          color: #0a70b0;
          font-size: 14px;
        }
      }
    }
    .inspectStatusCon {
      display: flex;
      flex-flow: column;
      justify-content: center;
      align-items: center;
      // margin-right: 15px;
      .statusDesc {
        font-size: 14px;
        line-height: 24px;
      }
      .inspectStatus {
        color: #23c451;
      }
      .updateStatus {
        color: #1c8be4;
      }
      .waitInspectStatus {
        color: #ffb537;
      }
      .inspectFinish {
        color: #0a70b0;
      }
      .reInspectBtn {
        padding: 0 10px;
        border-radius: 3px;
        border: 1px solid #dcdfe6;
        cursor: pointer;
      }
      .updateBtn {
        padding: 0 10px;
        border-radius: 3px;
        border: 1px solid #00c959;
        background: #00c959;
        cursor: pointer;
        color: #fff;
      }
      .disabledUpdateBtn{
        background-color: #f5f7fa;
        border-color: #e4e7ed;
      }
      .inspectFail {
        color: #da4a4a;
      }
    }
    .hasUpdateBtn {
      flex-flow: initial;
    }
  }
  .operateDataBaseCon {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 20px;
    border-bottom: 1px solid #e4e7ed;
    .operateDataBaseBtnCon {
      display: flex;
      .operateDataBaseBtn {
        padding: 5px 10px;
        font-size: 14px;
        border-radius: 4px;
        cursor: pointer;
      }
      .blueOperateBtn {
        background: #0a70b0;
        color: #fff;
      }
      .greenOperateBtn {
        background: #00c959;
        color: #fff;
      }
      .updateCagetyBtn {
        border: 1px solid #dcdfe6;
        color: #0a70b0;
      }
    }
  }
}
.inspecting {
  .allDataBase {
    height: calc(100% - 184px);
    .oneDataBase {
      padding-bottom: 10px;
    }
  }
}
.inspectFinish {
  .allDataBase {
    height: calc(100% - 86px);
    overflow: hidden;
    .allDataBaseCon {
      height: calc(100% - 62px);
      overflow-y: auto;
    }
    .oneDataBase {
      flex-wrap: wrap;
    }
    .productNameCon,
    .updateDesc{
      padding-left: 20px;
    }
    .updateTipCon{
      margin-left:20px;
    }
  }
}
.inspecting {
  .oneDataBase {
    flex-wrap: wrap;
  }
}
.allVersionCon {
  height: calc(100% - 42px);
  .allVersion {
    height: calc(100% - 56px);
  }
}
.blockPage {
  border: 1px solid #ebeef5;
  border-top: none;
}
.operate-btn {
  display: inline-block;
  width: 104px;
  text-align: center;
  padding: 0;
  height: 32px;
  line-height: 30px;
  border-radius: 3px;
  border: none;
  margin-left: 10px;
  cursor: pointer;
  border: 1px solid #dcdfe6;
}
.importInstituteBtn {
  height: 30px;
}
@media screen and (max-width: 1540px) {
 ::v-deep .updateTimeCon{
   clear:both;
   margin-top:10px;
   margin-bottom: 10px;
 }
 ::v-deep .versionCon{
   margin-top:10px;
   .width_180_input{
     width:240px!important;
   }
 }
 ::v-deep .width_200_select{
   width:240px!important;
 }
 ::v-deep .operateMemoryBtnDiv{
  margin-top:10px;
 }
 .allUpdatememoryCon {
  height: calc(100% - 84px);
  margin-top:10px;
  .allUpdatememory {
    height: calc(100% - 56px);
  }
 }
}
.updateing{
  font-size:14px;
  color:#1E93FF;
}
.udateFinished {
  font-size:14px;
  color:#1BB54A;
}
.updateFailed {
  font-size:14px;
  color:#da4a4a;
}
.clircle {
  position: relative;
  top: -2px;
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background:#67C23A;
  &.running::after {
    position: absolute;
    top: -1px;
    left: -1px;
    width: 100%;
    height: 100%;
    border-width: 1px;
    border-style: solid;
    border-radius: 50%;
    content: '';
    border-color: #67C23A;
    animation: animateIcon 1.2s ease-in-out infinite;
  }
}
.runningError{
  background:#DA4A4A;
}
&.running::after {
  border-color: #DA4A4A;
}
.waitRunning{
  background:#1E93FF;
}
&.waitRunning::after {
  border-color: #1E93FF;
}
@keyframes animateIcon {
  0% {
    transform: scale(0.8);
    opacity: 0.5;
  }
  to {
    transform: scale(2);
    opacity: 0;
  }
}

/*按钮 申请使用样式 start*/
.set_4_button2 {
  position: relative;
  font-weight: 300;
  width: 140px;
  height: 40px;
  line-height: 40px;
  font-size: inherit;
  overflow: hidden;
  position: relative;
  z-index: 0;
  cursor: pointer;
  color: #fff;
  background: rgba(252, 153, 37, 1);
  border-radius: 20px;
  text-align: center;
}
.set_4_button2.raised {
  -moz-transition: all 0.1s;
  -o-transition: all 0.1s;
  -webkit-transition: all 0.1s;
  transition: all 0.1s;
}
.anim {
  -moz-transform: translateY(-50%) translateX(-50%);
  -ms-transform: translateY(-50%) translateX(-50%);
  -webkit-transform: translateY(-50%) translateX(-50%);
  transform: translateY(-50%) translateX(-50%);
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: -1;
}
.anim:before {
  position: relative;
  content: "";
  display: block;
  margin-top: 100%;
}
.anim:after {
  content: "";
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  border-radius: 50%;
}
.hoverable .anim {
  -moz-animation: anim-out 0.75s;
  -webkit-animation: anim-out 0.75s;
  animation: anim-out 0.75s;
}
.hoverable .anim:after {
  -moz-animation: anim-out-pseudo 0.75s;
  -webkit-animation: anim-out-pseudo 0.75s;
  animation: anim-out-pseudo 0.75s;
}
.hoverable .anim,
.hoverable .anim:after {
  animation-iteration-count: infinite;
  animation-duration: 1.3s;
}
@-webkit-keyframes anim-in {
  0% {
    width: 0%;
  }
  100% {
    width: 100%;
  }
}
@-moz-keyframes anim-in {
  0% {
    width: 0%;
  }
  100% {
    width: 100%;
  }
}
@-ms-keyframes anim-in {
  0% {
    width: 0%;
  }
  100% {
    width: 100%;
  }
}
@keyframes anim-in {
  0% {
    width: 0%;
  }
  100% {
    width: 100%;
  }
}
@-webkit-keyframes anim-in-pseudo {
  0% {
    background: rgba(255, 255, 255, 0.25);
  }
  100% {
    background: transparent;
  }
}
@-moz-keyframes anim-in-pseudo {
  0% {
    background: rgba(255, 255, 255, 0.25);
  }
  100% {
    background: transparent;
  }
}
@-ms-keyframes anim-in-pseudo {
  0% {
    background: rgba(255, 255, 255, 0.25);
  }
  100% {
    background: transparent;
  }
}
@keyframes anim-in-pseudo {
  0% {
    background: rgba(255, 255, 255, 0.25);
  }
  100% {
    background: transparent;
  }
}
@-webkit-keyframes anim-out {
  0% {
    width: 0%;
  }
  100% {
    width: 100%;
  }
}
@-moz-keyframes anim-out {
  0% {
    width: 0%;
  }
  100% {
    width: 100%;
  }
}
@-ms-keyframes anim-out {
  0% {
    width: 0%;
  }
  100% {
    width: 100%;
  }
}
@keyframes anim-out {
  0% {
    width: 0%;
  }
  100% {
    width: 100%;
  }
}
@-webkit-keyframes anim-out-pseudo {
  0% {
    background: rgba(255, 255, 255, 0.25);
  }
  100% {
    background: transparent;
  }
}
@-moz-keyframes anim-out-pseudo {
  0% {
    background: rgba(255, 255, 255, 0.25);
  }
  100% {
    background: transparent;
  }
}
@-ms-keyframes anim-out-pseudo {
  0% {
    background: rgba(255, 255, 255, 0.25);
  }
  100% {
    background: transparent;
  }
}
@keyframes anim-out-pseudo {
  0% {
    background: rgba(255, 255, 255, 0.25);
  }
  100% {
    background: transparent;
  }
}
/*按钮 end*/
</style>