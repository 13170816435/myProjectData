<template>
    <div class="aboutSystemCon">
        <div class="about-modal-content" v-if="companyType == 1">
            <div class="logo">
                <img src="./images/mtywLogo.png" alt="明天医网"> <!--文件有点大 打包不进去导致页面显示不出来-->
            </div>
            <div class="about-content">
                <div class="about-info">
                    <p class="title">
                        <span class="label">产品名称：</span>
                        {{ appInfo.product_name }}
                    </p>
                    <p v-if="appInfo.product_module">
                        <span class="label">产品模块：</span>
                        {{ appInfo.product_module }}
                    </p>
                    <p>
                        <span class="label">型号规格：</span>
                        {{ appInfo.model_specification }}
                    </p>
                    <p>
                        <span class="label">发布版本：</span>
                        {{ appInfo.release_version }}
                    </p>
                    <p>
                        <span class="label">完整版本：</span>
                        {{ appInfo.version }}
                        <span class="pl10 Microservices" @click="watchMicroservices">微服务</span>
                    </p>
                    <p>
                        <span class="label">发布日期：</span>
                        {{ appInfo.release_date }}
                    </p>
                    <!-- <p v-if="appInfo.batch_number">
                        <span class="label">生产批次：</span>
                        {{ appInfo.batch_number }}
                    </p> -->

                    <p v-if="appInfo.registration_number">
                        <span class="label">注册证号：</span>
                        {{ appInfo.registration_number }}
                    </p>
                    <p class="useTimeState">
                        <span class="label">使用期限：</span>
                        <span class="useTimeStateCon" v-html="appInfo.service_life"></span>
                    </p>
                </div>
                <p class="split-line"></p>
                <div class="about-copyright">
                    <div class="about-us">
                        <p>
                            <span class="label companyInforLabel">公司名称：</span>
                            {{ appInfo.company_name }}
                        </p>
                        <p>
                            <span class="label companyInforLabel">生产许可证：</span>
                            {{ appInfo.production_license_number }}
                        </p>
                        <p>
                            <span class="label companyInforLabel">生产地址/住所：</span>
                            {{ appInfo.production_address }}
                        </p>
                        <p>
                            <span class="label companyInforLabel">公司网址：</span>
                            {{ appInfo.company_url }}
                        </p>
                        <p>
                            <span class="label companyInforLabel">服务热线：</span>
                            {{ appInfo.company_tel }}
                        </p>
                        <p>
                            Copyright(C){{ release_year }}
                        </p>
                    </div>
                    <div class="qr">
                        <div class="qr-container" v-if="qrUrl.length > 0">
                            <img :src="qrUrl" alt="qrCode">
                        </div>
                        <div>
                            <p>{{ appInfo.udi_di }}</p>
                            <p>{{ appInfo.udi_pi }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="about-modal-content" v-if="companyType == 2">
            <div class="logo" v-if="logoSrc">
                <img :src="logoSrc" alt=""> <!--文件有点大 打包不进去导致页面显示不出来-->
            </div>
            <div class="about-content">
                <div class="about-info">
                    <!-- 产品信息--->
                    <p v-html="replaceRN(thirdAboutSystem.product_introduction)">
                    </p>
                </div>
                <p class="split-line"></p>
                <div class="about-copyright">
                    <div class="about-us">
                        <p v-html="replaceRN(thirdAboutSystem.company_info)">
                        </p>
                        <p>
                            Copyright(C){{ release_year }}
                        </p>
                    </div>
                </div>
            </div>
        </div>


        <!---查看微服务--->
        <!-- <el-dialog
      :title="'微服务'"
      class="microservicesAlert"
      top="10vh"
      v-if="dialogMounted"
      :visible.sync="showMicroservicesAlert"
      width="1000px"
      :close-on-click-modal="false"
      v-dialogDrag
      append-to-body
      custom-class="global-dialog"
      :before-close="handleClose"
      ref="myDialog"
    >
      
    </el-dialog> -->
        <microservicesDetail ref="dialog"></microservicesDetail>
    </div>
</template>
<script>
import Mgr from '@/utils/SecurityService'
import axios from 'axios'
import microservicesDetail from "./components/microservicesDetail.vue";
export default {
    components: {
        microservicesDetail,
    },
    data() {
        return {
            shouldAppendToBody: false,
            loginInfor: {},
            appKey: '',
            requestOnShow: false,
            show: false,
            qrUrl: '',
            fetched: false,
            release_year: new Date().getFullYear(),
            appInfo: {
                product_name: '',
                product_module: '',
                release_version: '',
                version: '',
                registration_number: '',
                company_name: '',
                company_url: '',
                company_tel: '',
                service_life: '',
                udi_di: '',
                udi_pi: ''
            },
            companyType: 1, //companyType 1 代表的本公司   2代表的是第三方
            // 第三方的关于系统信息
            logoSrc: '',
            thirdAboutSystem: {
                logo: '',
                product_introduction: '',// 产品信息
                company_info: '', // 公司信息
            },
            showMicroservicesAlert: false,
            shouldAppendToParent: false,
            dialogClass: '',
            globalContainer: null,
            dialogMounted: false,
        }
    },
    watch: {
        show() {
            this.handleLayout()
        }
    },
    methods: {
        watchMicroservices() {
            this.$refs.dialog?.open(this.appInfo)
        },
        // 替换\r\n
        replaceRN(str) {
            str = str || ''
            return str.replace(/\r\n/g, '<br>')
        },
        changeVisible() {
            this.show = !this.show
        },
        GetQueryString(name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
            var r = window.location.search.substr(1).match(reg); //获取url中"?"符后的字符串并正则匹配
            var context = "";
            if (r != null)
                context = decodeURIComponent(r[2]);
            reg = null;
            r = null;
            return context == null || context == "" || context == "undefined" ? "" : context;
        },
        async initData() {
            const self = this
            if (self.requestOnShow) {
                if (self.companyType == 1) {// 本公司
                    self.request()
                } else {// 第三方
                    self.requestThirdAboutSystemInfor()
                }

            } else {
                self.requestOnce()
            }
        },
        // 获取 是否是 第三方配置的 还是本公司默认的
        async requestThirdSet() {
            const self = this
            try {
                const result = await axios({
                    method: 'GET',
                    //url: 'https://api-dev.mtywcloud.com/api-operate/udis/detail',  // 测试用的
                    url: configUrl.apiUrl + '/api-operate/operates/about-system/type',
                    headers: {
                        Authorization: self.loginInfor.token_type + ' ' + self.loginInfor.access_token
                    },
                    params: {
                        key: self.appKey
                    }
                })
                let res = result.data
                if (res.code === 0) {
                    self.companyType = res.data
                }
            } catch (e) {
            }

        },
        removeDialog() {
            const container = this.$el.parentElement
            if (container) {
                setTimeout(() => {
                    container.removeChild(this.$el)
                }, 300)
            }
        },

        handleEsc(event) {
            if (this.show && event.code === 'Escape') {
                this.show = false
            }
        },

        listenEscKeyboard() {
            window.addEventListener('keydown', this.handleEsc)
        },

        removeEscKeyboard() {
            window.removeEventListener('keydown', this.handleEsc)
        },

        handleLayout() {
            if (!this.show) {
                return
            }
            this.$nextTick(() => {
                const { height } = this.$refs.main.getBoundingClientRect()
                const clientHeight = document.body.clientHeight
                if (height > clientHeight - 40) {
                    this.$refs.wrapper.style.alignItems = 'flex-start'
                } else {
                    this.$refs.wrapper.style.alignItems = ''
                }
            })
        },
        requestOnce() {
            if (this.fetched) {
                return
            }
            this.fetched = true
            if (this.companyType == 1) {// 本公司
                this.request()
            } else {// 第三方
                this.requestThirdAboutSystemInfor()
            }
        },
        getBase64(file) {
            return new Promise(function (resolve, reject) {
                let imgResult = ''
                if (file) {
                    imgResult = 'data:image/png;base64,' + btoa(new Uint8Array(file).reduce((data, byte) => data + String.fromCharCode(byte), ''))
                }
                resolve(imgResult)
            })
        },
        // 获取第三方logo
        async getLogoSrc(logoParams) {
            const self = this
            try {
                const result = await axios({
                    method: 'GET',
                    //url: 'https://api-dev.mtywcloud.com/api-operate/udis/detail',  // 测试用的
                    url: configUrl.apiUrl + '/api-archive/download/crm-document-id',
                    headers: {
                        Authorization: self.loginInfor.token_type + ' ' + self.loginInfor.access_token
                    },
                    params: logoParams,
                    responseType: 'arraybuffer',
                })
                if (result) {
                    self.getBase64(imgFile).then((result) => {
                        self.logoSrc = result;
                    });
                } else {
                    self.logoSrc = "";
                }
            } catch (e) {
            }
        },
        // 获取 自定义关于系统配置 （第三方的）
        async requestThirdAboutSystemInfor() {
            const self = this
            try {
                const result = await axios({
                    method: 'GET',
                    //url: 'https://api-dev.mtywcloud.com/api-operate/udis/detail',  // 测试用的
                    url: configUrl.apiUrl + '/api-operate/udis/about-system',
                    headers: {
                        Authorization: self.loginInfor.token_type + ' ' + self.loginInfor.access_token
                    },
                    params: {
                        key: self.appKey
                    }
                })
                let res = result.data
                if (res.code === 0) {
                    self.thirdAboutSystem = res.data
                    // 获取logo
                    if (self.thirdAboutSystem.logo) {
                        self.getLogoSrc({ document_id: res.data.logo })
                    }
                }
            } catch (e) {
            }

        },
        // 请求二维码
        async requestCode(str) {
            const self = this
            const res = await axios({
                method: 'GET',
                //url: 'https://api-dev.mtywcloud.com/api-operate/udis/data-matrix/base64',  // 测试用的
                url: configUrl.apiUrl + '/api-operate/udis/data-matrix/base64',
                headers: {
                    Authorization: self.loginInfor.token_type + ' ' + self.loginInfor.access_token
                },
                //responseType: 'arraybuffer',
                params: {
                    content: str
                }
            })
            const result = res.data
            if (result.code == 0) {
                self.qrUrl = 'data:image/png;base64,' + result.data
            }
        },
        async request() {
            const self = this
            try {
                // const res = await self.axios({
                //   //url: self.url || '/api-operate/udis/detail',
                //   url: 'https://api-dev.mtywcloud.com/api-operate/udis/detail',
                //   params: self.url ? {} : {
                //     key: self.appKey
                //   }
                // })
                const result = await axios({
                    method: 'GET',
                    //url: 'https://api-dev.mtywcloud.com/api-operate/udis/detail',  // 测试用的
                    url: configUrl.apiUrl + '/api-operate/udis/detail',
                    headers: {
                        Authorization: self.loginInfor.token_type + ' ' + self.loginInfor.access_token
                    },
                    params: {
                        key: self.appKey
                    }
                })
                let res = result.data
                if (res.code === 0) {
                    self.appInfo = res.data
                    let release_date = res.data.release_date
                    // if (release_date) {
                    //   self.release_year = release_date.substring(0,4)
                    // }
                    let str = `${res.data.udi_di}${res.data.udi_pi}`
                    self.requestCode(str)
                }
            } catch (e) {
                //console.log("请求异常")
            }

        },
    },
    mounted() {
        window.addEventListener('message', (e) => {
            if (e.data.type === 'SET_GLOBAL_CONTAINER') {
                this.$refs.dialog?.setContainer(e.data.containerId)
                this.loginInfor = e.data.loginInfor
                this.appKey = e.data.appKey
                this.requestOnShow = e.data.requestOnShow
                this.initData()
            }

        })
        this.handleLayout()
        this.listenEscKeyboard()
        window.addEventListener('resize', this.handleLayout)
    },

    beforeDestroy() {
        this.removeDialog()
        this.removeEscKeyboard()
        window.removeEventListener('resize', this.handleLayout)
    }
}
</script>
<style lang="less" scoped>
.aboutSystemCon{
  width: 100%;
  height: 100%;
  border-radius: 4px;
  overflow: hidden;
//   background: url(./images/bg.png), #fff no-repeat;
//   background-size: 765px auto;
    ::v-deep .about-modal-content {
        height: 100%;
        overflow: hidden;
    }
}
.about-app-dialog {
    .about-modal {
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, .24);
        z-index: 9999;
    }



    .about-dialog-wrapper {
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
        box-sizing: border-box;
        padding: 20px;
    }

    .about-modal-main {
        width: 712px;
        border-radius: 4px;
        overflow: hidden;
        background: url("images/bg.png"), #FFFFFF;
        background-size: 765px auto;
        // background-size: 700px auto;
    }
}

.about-modal-content {
    display: flex;
    box-sizing: border-box;
    padding: 16px;

    .about-content {
        flex: 1;
        overflow: hidden;
    }

    .logo {
        width: 97px;
        //height:60px;
        margin-right: 23px;

        //background:url('@/package/about-application/images/mtywLogo.png'), #FFFFFF center no-repeat;
        img {
            width: 100%;
        }
    }

    .about-info,
    .about-us {
        p {
            color: #333333;
            font-size: 12px;
            line-height: 17px;
        }
    }

    .about-us {
        p:not(:last-child) {
            margin-bottom: 3px;
        }
    }

    .about-info {
        min-height: 285px;

        p:not(:last-child) {
            margin-bottom: 6px;
        }

        p.title {
            font-weight: bold;
            color: #333333;
            font-size: 18px;
            margin-bottom: 12px;
        }
    }

    .split-line {
        height: 1px;
        background-color: #0A70B0;
    }

    .about-copyright {
        margin-top: 15px;
        display: flex;
        justify-content: space-between;
    }

    .qr {
        display: flex;
        align-items: flex-end;
        font-size: 12px;
    }

    .qr-container {
        height: 75px;
        width: 75px;
        // border: 1px dashed rgb(180, 180, 180);
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        margin-right: 6px;
        padding: 2px;

        img {
            width: 100%;
            height: auto;
            max-width: 100%;
            max-height: 100%;
        }
    }

    .companyInforLabel {
        //   display: inline-block;
        //   width:92px;
        //   text-align-last: justify;
    }
}

.useTimeState {
    position: relative;
    line-height: 26px !important;

    .label {
        position: absolute;
        left: 0px;
        top: 0px;
    }

    .useTimeStateCon {
        padding-left: 60px;
    }
}

.about-translate-enter-active,
.about-translate-leave-active,
.about-fade-enter-active,
.about-fade-leave-active {
    transition: all .2s ease-in-out;
}

.about-translate-enter,
.about-translate-leave-to {
    transform: translateY(-20px);
}

.about-fade-enter,
.about-fade-leave-to {
    opacity: 0;
}

.Microservices {
    font-size: 15px;
    color: #0a70b0;
    cursor: pointer;
}
</style>