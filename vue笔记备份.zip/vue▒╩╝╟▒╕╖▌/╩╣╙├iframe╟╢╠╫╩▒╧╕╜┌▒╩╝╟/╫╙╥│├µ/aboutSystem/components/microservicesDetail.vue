<template>

  <div v-show="visible">
    <el-dialog :visible.sync="visible" title="微服务" width="1000px" :before-close="handleBeforeClose"
      :close-on-click-modal="false" :append-to-body="false">
      <div class="microservicesDetailCon">
        <!-- <div class="searchHead mb10">
        <el-select
            @change="searchMicroserviceList"
            filterable
            v-model="searchMicroData.exclude_blacklist"
            class="ele-select_32 width_120_select ml5"
            placeholder="全部"
            style="width:120px;">
            <el-option :value="false" label="全部"></el-option>
            <el-option :value="true" label="不含黑名单"></el-option>
        </el-select>
        <el-date-picker
            @change="changeTimer"
            class="chooseIntervalsPick searchTimePicker"
            v-model="timer"
            type="daterange"
            align="right"
            value-format="yyyy-MM-dd"
            unlink-panels
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            :picker-options="pickerOptions"
          ></el-date-picker>
           

        <el-input class="width_220_input ml10" v-on:keyup.enter.native=searchMicroserviceList v-model="searchMicroData.phone"  placeholder="按研发项目、微服务、版本号查找"></el-input>
        <el-button type="primary" size="small" @click="searchMicroserviceList">查询</el-button>
        <el-button size="small" plain @click="resetSearch">重置</el-button>
     </div> -->

        <div class="sendCountTableDiv clear" v-loading="loading" element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          v-bind:class="{ noTableData: microServiceList.length == 0 }" style="height: 356px;">
          <el-table :data="microServiceList" border stripe height="100%" ref="tableAutoScroll" highlight-current-row
            header-row-class-name="strong" :row-key="myRowkey" :cell-class-name="cellClassNameSet">
            <el-table-column fixed="left" align="center" type="index" label="序号" width="55">
              <template slot-scope="scope">
                <span>{{
                  (searchMicroData.offset - 1) * searchMicroData.limit + scope.$index + 1
                  }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="micro_service_group_name" label="研发项目" width="168"></el-table-column>
            <el-table-column prop="micro_service_name" label="微服务" width="168"></el-table-column>
            <el-table-column prop="micro_service_version" label="版本号" width="168"></el-table-column>
            <el-table-column prop="micro_service_heartbeat_status" label="状态" width="100">
              <template slot-scope="scope">
                <span class="running" v-if="scope.row.micro_service_heartbeat_status == 1">运行中</span>
                <span class="offline" v-if="scope.row.micro_service_heartbeat_status == 2">离线</span>
              </template>
            </el-table-column>
            <el-table-column prop="micro_service_request_time_first" label="启用时间"></el-table-column>
          </el-table>
        </div>
        <!-- <div class="ba">
          <pagination-tool  :total="total_count" :page.sync="searchMicroData.offset" :limit.sync="searchMicroData.limit" @pagination="beganGetMicroserviceList" />
        </div> -->
      </div>
    </el-dialog>
  </div>
</template>
<script>
import moment from 'moment';
import PaginationTool from '@/components/common/PaginationTool'
import cryptoMix from '@/utils/mixin/crypto'
import {
  getSmsDaliySendCountData,
  watchDependencyMicroList
} from "@/api/platform_operate/systemset";
export default {
  components: {
    PaginationTool,
  },
  mixins: [cryptoMix],
  data() {
    return {
      visible: false,
      container: null,
      searchMicroData: {
        micro_service_name: "",
        micro_service_version: "",
        micro_service_version_sub: "",
        start_create_datetime: "",
        end_create_datetime: "",
        micro_ervice_heartbeat_status: "",
        key_world: "",
        //offset:1,
        //limit:20,
      },
      timer: [],
      startDate: '',
      pickerOptions: {
        shortcuts: [
          {
            text: '今天',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              // start.setTime(start.getTime() - 3600 * 1000 * 24 * 6);
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 6)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 29)
              picker.$emit('pick', [start, end])
            }
          },
          //   {
          //     text: '最近三个月',
          //     onClick (picker) {
          //       const end = new Date()
          //       const start = new Date()
          //       start.setTime(start.getTime() - 3600 * 1000 * 24 * 89)
          //       picker.$emit('pick', [start, end])
          //     }
          //   }
        ],
        onPick: ({ minDate }) => {
          this.startDate = minDate.getTime()
        },
      },
      // 表头字段
      propData: [
        { prop: "to_phone", label: "账号", width: 120 },
        { prop: "state_desc", label: "状态", width: 120 },
        { prop: "count", label: "累计发送量" },
      ],
      microServiceList: [],
      total_count: 0,
      loading: false,
    }
  },
  methods: {
    open(appInfo) {
      this.visible = true
      this.$nextTick(this.moveDialog)
      this.initData(appInfo)
    },
    setContainer(id) {
      this.container = window.parent.document.getElementById(id)
    },
    handleBeforeClose(done) {
      this.visible = false
      //done()
      //this.cleanupDialog()
    },
    moveDialog() {
      const dialogWrapper = this.$el.querySelector('.el-dialog__wrapper')
      if (dialogWrapper && this.container) {
        this.container.appendChild(dialogWrapper)
      }
    },
    cleanupDialog() {
      if (this.container) {
        this.container.innerHTML = ''
      }
    },
    resetTime() {
      // 设置账号短信发送量的默认时间
      const firstDay = moment().startOf('month').format('YYYY-MM-DD');
      const nowTime = moment().format('YYYY-MM-DD')
      this.timer = []
      this.timer.push(firstDay)
      this.timer.push(nowTime)
      this.searchMicroData.start_create_datetime = firstDay
      this.searchMicroData.end_create_datetime = nowTime
    },
    initTime(startTime, endTime) {
      this.timer = []
      this.timer.push(startTime)
      this.timer.push(endTime)
      this.searchMicroData.start_create_datetime = startTime
      this.searchMicroData.end_create_datetime = endTime
      this.beganGetMicroserviceList()
    },
    // 重置
    resetSearch() {
      this.resetTime()
      this.searchMicroData.exclude_blacklist = true
      this.searchMicroData.phone = ''
      this.searchMicroData.offset = 1
      this.searchMicroData.limit = 20
    },
    changeTimer(val) {
      this.searchMicroData.start_create_datetime = val[0]
      this.searchMicroData.end_create_datetime = val[1]
      this.searchMicroserviceList()
    },
    // 搜索微服务
    searchMicroserviceList() {
      this.searchMicroData.offset = 1
      this.searchMicroData.limit = 20
      this.beganGetMicroserviceList()
    },
    myRowkey(row) {
      return row.id;
    },
    cellClassNameSet({ row, column }) {
      //console.log("column",column)
      if (column && column.property && column.property != 'send_count' && column.property != 'state' && column.property != 'state_desc' && column.property != 'to_phone') {
        return 'sendCountVal'
      }
      return ''
    },
    cellClickNow(row, col, cell) {
      if (cell && cell.field == 'send_count' || cell.field == 'state_desc' || cell.field == 'to_phone') {
        return
      }
      //console.log("row",row)
      console.log("cell", cell)
      this.gotoDetail(row, cell.time_range, cell.time_range)
    },
    initData(appInfo) {
      this.searchMicroData.micro_service_name = appInfo.model_specification
      this.searchMicroData.micro_service_version = appInfo.release_version
      this.searchMicroData.micro_service_version_sub = appInfo.version
      this.beganGetMicroserviceList()
    },
    // 获取某产品 所依赖的全部微服务
    async beganGetMicroserviceList() {
      const self = this
      self.loading = true
      const res = await watchDependencyMicroList(self.searchMicroData);
      if (res.code === 0) {
        self.loading = false
        self.microServiceList = res.data || []
        if (res.page) {
          self.total_count = res.page.total_count
        }
      } else {
        self.loading = false
        self.$message.error(res.msg);
      }
    },
  },
  mounted() {
    window.addEventListener('message', (e) => {
      if (e.data.type === 'SET_CONTAINER_ID') {
        this.container = parent.document.getElementById(e.data.containerId)
      }
    })
  }
}
</script>
<style lang="less">
::v-deep .smsSendCountDetailCon {
  padding: 15px 20px;

  .searchHead {
    display: flex;
    align-items: center;

    ::v-deep .el-date-editor .el-input__icon.el-range__close-icon {
      display: none !important;
    }
  }

  .sendCountTableDiv {
    height: 400px;

    ::v-deep .el-table__body-wrapper {
      height: calc(100% - 40px) !important;
      overflow: auto;
    }

    ::v-deep .sendCountVal {
      font-size: 14px;
      color: #0a70b0;
      font-weight: 700;
      cursor: pointer;
    }
  }
}

.delCon {
  padding: 20px;

  .account {
    padding: 0 5px;
    color: #0a70b0;
    font-size: 14px;
  }
}
.running {
  color: #1cb54a;
}
.offline{
  color:#909399;
}
</style>