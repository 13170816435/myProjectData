<template>
  <div class="about-app-dialog" ref="container">

    <transition name="about-fade">
      <div class="about-modal" v-if="show"></div>
    </transition>

    <transition name="about-translate">

      <div class="about-dialog-wrapper" v-if="show" ref="wrapper">
        <div class="about-modal-main" ref="main">
          <div class="about-header">
            关于 {{ appInfo.product_name }}
            <span class="close" @click="changeVisible">
            <img src="./images/close.png" alt="close">
          </span>
          </div>
          <!-- 内容区域--->
           <iframe id="frm-editor" width="100%" height="100%" :src="pageSrc" scrolling="no" frameborder="0"
            style="border: 0" ref="iframe" @load="handleIframeLoad">
          </iframe>
          <div id="global-dialog-root"></div>
        </div>
      </div>
    </transition>


    
  </div>
</template>

<script>
import axios from 'axios'
// import { config } from 'vue/types/umd'
// import QRCode from 'qrcode'

export default {
  name: "about-application",

  watch: {
    show() {
      this.handleLayout()
    }
  },
  props: ['loginInfor', 'appKey', 'requestOnShow', 'url'],
  data() {
    return {
      show: false,
      qrUrl: '',
      fetched: false,
      pageSrc: process.env.NODE_ENV === 'development' ? 'http://localhost:8080/aboutSystem/index' : `${configUrl.frontEndUrl}/operate/aboutSystem/index`,
      release_year: new Date().getFullYear(),
      appInfo: {
        product_name: '',
        product_module: '',
        release_version: '',
        version: '',
        registration_number: '',
        company_name: '',
        company_url: '',
        company_tel: '',
        service_life: '',
        udi_di: '',
        udi_pi: ''
      },
      companyType: 1, //companyType 1 代表的本公司   2代表的是第三方
      // 第三方的关于系统信息
      logoSrc: '',
      thirdAboutSystem: {
        logo: '',
        product_introduction: '',// 产品信息
        company_info: '', // 公司信息
      },
    }
  },

  methods: {
    // iframe 加载时 
    handleIframeLoad() {
      const iframe = this.$refs.iframe
      const checkReady = () => {
        if (iframe.contentWindow?.document.readyState === 'complete') {
          iframe.contentWindow.postMessage({// 传递给嵌套的子页面
            type: 'SET_GLOBAL_CONTAINER',
            containerId: 'global-dialog-root',
            loginInfor: this.loginInfor,// 登录信息
            appKey: this.appKey,
            requestOnShow: this.requestOnShow,
          }, '*')
        } else {
          setTimeout(checkReady, 100)
        }
      }
      checkReady()
    },
    
    // 替换\r\n
    replaceRN (str) {
      str = str || ''
      return str.replace(/\r\n/g, '<br>')
    },
    changeVisible() {
      this.show = !this.show
    },
    async showDialog() {
      this.show = true
    },
    // 获取 是否是 第三方配置的 还是本公司默认的
    async requestThirdSet() {
      const self = this
      try { 
        const result = await axios({
          method:'GET',
          //url: 'https://api-dev.mtywcloud.com/api-operate/udis/detail',  // 测试用的
          url: configUrl.apiUrl + '/api-operate/operates/about-system/type',
          headers: {
            Authorization: self.loginInfor.token_type + ' ' + self.loginInfor.access_token
          },
          params: {
            key: self.appKey
          }
        })
        let res = result.data
        if (res.code === 0) {
          self.companyType = res.data
        }
      } catch (e) {
      }
      
    },

    removeDialog() {
      const container = this.$el.parentElement
      if (container) {
        setTimeout(() => {
          container.removeChild(this.$el)
        }, 300)
      }
    },

    handleEsc(event) {
      if (this.show && event.code === 'Escape') {
        this.show = false
      }
    },

    listenEscKeyboard() {
      window.addEventListener('keydown', this.handleEsc)
    },

    removeEscKeyboard() {
      window.removeEventListener('keydown', this.handleEsc)
    },

    handleLayout() {
      if (!this.show) {
        return
      }
      this.$nextTick(() => {
        const {height} = this.$refs.main.getBoundingClientRect()
        const clientHeight = document.body.clientHeight
        if (height > clientHeight - 40) {
          this.$refs.wrapper.style.alignItems = 'flex-start'
        } else {
          this.$refs.wrapper.style.alignItems = ''
        }
      })
    },
    requestOnce() {
      if (this.fetched) {
        return
      }
      this.fetched = true
      if (this.companyType == 1) {// 本公司
        this.request()
      } else {// 第三方
        this.requestThirdAboutSystemInfor()
      }
    },
    getBase64 (file) {
      return new Promise(function (resolve, reject) {
        let imgResult = ''
        if (file) {
          imgResult = 'data:image/png;base64,' + btoa(new Uint8Array(file).reduce((data, byte) => data + String.fromCharCode(byte), ''))
        }
        resolve(imgResult)
      })
    },
    // 获取第三方logo
    async getLogoSrc(logoParams) {
      const self = this
      try { 
        const result = await axios({
          method:'GET',
          //url: 'https://api-dev.mtywcloud.com/api-operate/udis/detail',  // 测试用的
          url: configUrl.apiUrl + '/api-archive/download/crm-document-id',
          headers: {
            Authorization: self.loginInfor.token_type + ' ' + self.loginInfor.access_token
          },
          params: logoParams,
          responseType: 'arraybuffer',
        })
        if (result) {
          self.getBase64(imgFile).then((result) => {
            self.logoSrc = result;
          });
        } else {
          self.logoSrc = "";
        }
       } catch (e) {
       }
    },
    // 获取 自定义关于系统配置 （第三方的）
    async requestThirdAboutSystemInfor() {
      const self = this
      try { 
        const result = await axios({
          method:'GET',
          //url: 'https://api-dev.mtywcloud.com/api-operate/udis/detail',  // 测试用的
          url: configUrl.apiUrl + '/api-operate/udis/about-system',
          headers: {
            Authorization: self.loginInfor.token_type + ' ' + self.loginInfor.access_token
          },
          params: {
            key: self.appKey
          }
        })
        let res = result.data
        if (res.code === 0) {
          self.thirdAboutSystem = res.data
          // 获取logo
          if (self.thirdAboutSystem.logo) {
            self.getLogoSrc({document_id:res.data.logo})
          }
        }
      } catch (e) {
      }
      
    },
    // 请求二维码
    async requestCode (str) {
      const self = this
      const res = await axios({
        method:'GET',
        //url: 'https://api-dev.mtywcloud.com/api-operate/udis/data-matrix/base64',  // 测试用的
        url: configUrl.apiUrl + '/api-operate/udis/data-matrix/base64',
        headers: {
          Authorization: self.loginInfor.token_type + ' ' + self.loginInfor.access_token
        },
        //responseType: 'arraybuffer',
        params: {
          content: str
        }
      })
      const result = res.data
      if (result.code == 0) {
        self.qrUrl = 'data:image/png;base64,' + result.data
      }
    },
    async request() {
      const self = this
      try { 
        // const res = await self.axios({
        //   //url: self.url || '/api-operate/udis/detail',
        //   url: 'https://api-dev.mtywcloud.com/api-operate/udis/detail',
        //   params: self.url ? {} : {
        //     key: self.appKey
        //   }
        // })
        const result = await axios({
          method:'GET',
          //url: 'https://api-dev.mtywcloud.com/api-operate/udis/detail',  // 测试用的
          url: configUrl.apiUrl + '/api-operate/udis/detail',
          headers: {
            Authorization: self.loginInfor.token_type + ' ' + self.loginInfor.access_token
          },
          params: {
            key: self.appKey
          }
        })
        let res = result.data
        if (res.code === 0) {
          self.appInfo = res.data
          let release_date = res.data.release_date
          // if (release_date) {
          //   self.release_year = release_date.substring(0,4)
          // }
          let str = `${res.data.udi_di}${res.data.udi_pi}`
          self.requestCode(str)
        }
      } catch (e) {
        //console.log("请求异常")
      }
      
    }
  },

  mounted() {
    this.handleLayout()
    this.listenEscKeyboard()
    window.addEventListener('resize', this.handleLayout)
  },

  beforeDestroy() {
    this.removeDialog()
    this.removeEscKeyboard()
    window.removeEventListener('resize', this.handleLayout)
  }
}

</script>
<style>
#global-dialog-root {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 9999;
}
</style>
<style lang='less' src="./index.less">
</style>