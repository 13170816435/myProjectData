import Vue from 'vue'
import App from './App.vue'
// import router from './router'
import store from './store'
import Element from 'element-ui'
import vcolorpicker from 'vcolorpicker' // 色号
import VueClipboard from 'vue-clipboard2'
/*import 'element-ui/lib/theme-chalk/index.css'*/
import formdata from './components/newFormdata'
import 'umy-ui/lib/theme-chalk/index.css';// 引入样式
import { UxGrid,UxTableColumn } from 'umy-ui';
// import '@/style/iconfont/iconfont.css'
import '@/style/common/theme.scss'
import '@/style/index.less'
import '@/components/commonJs.js'
import '@/filter/index.js'
import '@/utils/directives.js'
import validation from '@/utils/validation' // 公共方法
import qs from 'qs'
import pacsApi from '@/api/yunshangfuyouApi/pacs.js' // 云PACS全局j接口
// import JSEncrypt from 'jsencrypt'
import {setAxiosConfig} from '@/utils/request'
import loadConfigScript from '@/utils/loadConfigScript'
import {setRouterConfig} from './router'
import Mgr from '@/utils/SecurityService'
// import myTomtawPackage from "my-tomtaw-package"
// import tomtawForward from 'tomtaw-forward'
// 判断是否登录才能浏览的页面 函数
function noNeedLogin () {
  if (typeof _dataCockpitName !== 'undefined' && (_dataCockpitName == 'fogangxian' || _dataCockpitName == 'dongyang') && window.location.href.indexOf('/platformDataCockpit/index') != -1) {
    return true
  } else if (typeof _dataCockpitName !== 'undefined' && _dataCockpitName == 'jinhua' && window.location.href.indexOf('/customerDataCockpit/index') != -1) {
    return true
  } else {
    return false
  }
}

// VUE项目初始化
function initVueProject () {
  setAxiosConfig()
  const router = setRouterConfig()
  Vue.config.productionTip = false
  Vue.prototype.$qs = qs
  Vue.prototype.$noNeedLogin = noNeedLogin()
  Vue.use(Element)
  Vue.use(UxGrid);
  Vue.use(UxTableColumn);
  Vue.use(vcolorpicker)
  Vue.use(validation)
  Vue.use(VueClipboard)
  // Vue.use(tomtawForward)
  // Vue.use(myTomtawPackage)
  // 设置浏览器标题
  // Vue.directive('title', {
  //   inserted: function (el, binding) {
  //     document.title = '客户管理'
  //   }
  // })
  
  // 设置浏览器标题
  Vue.directive('cockpitTitle', {
    inserted: function (el, binding) {
      document.title = el.dataset.title
    }
  })


   // 监听localStorage 如果其中一个浏览器tab退出登录了 那么其它tab页也都要退出登录
  window.addEventListener("storage", function(e){
    //console.log("eeeee",e)
    if (localStorage.getItem('loginStatus') == 'loginOut') {
      if (typeof _dataCockpitName !== 'undefined') {
        if (!noNeedLogin()) {
          var manager = new Mgr()
          manager.signOut()
        }
      }
    }
  })

  // iframe
  window.onunload = function () {
    //console.log('---------------------------------------------')
    const key = `oidc.user:${configUrl.crmUrl}:${configUrl.client_id}`
    if (window.frames.length !== parent.frames.length) {
      console.log('在iframe中, 需要删除session, key: ' + key)
      window.sessionStorage.removeItem(key)
    }
  }
  new Vue({
    router,
    store,
    render: h => h(App)
  }).$mount('#app')
}

loadConfigScript().then(() => {
  if (process.env.NODE_ENV === 'production') {
    const versionNumber = 'dev_1.0.23.1'
    console.log(`%c项目打包时间：${BUILD_DATE} - ${BRANCH} - ${versionNumber}`, 'color: #0a70b0;font-weight: bold;')
    // console.log(`%c项目打包时间：${BUILD_DATE} - ${BRANCH} - ${VERSION}`, 'color: #0a70b0;font-weight: bold;')
  }
  // 这里先请求一次getRole是为了 苗哥那边的tomtaw-authority里面防止多次请求李阳的 /users/identity --获取用户信息接口
  // 苗哥tomtaw-authority 请求/users/identity 做了限制处理

  if (noNeedLogin()) { // 不需要登录也能浏览的
    initVueProject()
  } else { // 需要登录
    var manager = new Mgr()
    manager.getRole().then(function (item) {
     // 将登录信息存储到 vuex里面去
     store.commit('app/save_loginTokenInfo', item)
     initVueProject()
   })
  }
})
