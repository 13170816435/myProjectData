const {proxy} = require('jquery')
const path = require('path')
const webpack = require('webpack')
const GitRevisionPlugin = require("git-revision-webpack-plugin")
const GitRevision = new GitRevisionPlugin()
const buildDate = JSON.stringify(new Date().toLocaleString())
const resolve = (dir) => {
  return path.join(__dirname, dir)
}
const name = 'vue Admin Template' // page title

const getCurrentDate = () => {
  const today = new Date()
  const year = today.getFullYear()
  const month = ('0' + (today.getMonth() + 1)).slice(-2)
  const date = ('0' + today.getDate()).slice(-2)
  return `${year}-${month}-${date}`
}
const getBanner = () => {
  return `/*! 平台运营 - 1.0.17.2 - ` +
    `${getCurrentDate()} ` +
    '| (c) 2021 tomtaw.com.cn | https://www.tomtaw.com.cn */'
}
const argv = require('yargs').argv

let publicPath = process.env.NODE_ENV === 'development' ? '/' : '/operate/'
// 二级目录部署时 virtualDir 为目录名字
// npm run build -- --virtualDir='mtyw'
if (argv.virtualDir) {
  publicPath = '/' + argv.virtualDir + publicPath
}
console.log('public path is', publicPath)
const timeStamp = new Date().getTime();
module.exports = {
   publicPath: publicPath,
  //publicPath: '/mtyw/operate/',
  outputDir: 'dist',
  assetsDir: 'assets',
  indexPath: 'index.html',
  filenameHashing: true,
  pages: {
    index: {
      entry: 'src/main.js',
      template: 'public/index.html',
      filename: 'index.html'
    }
  },
  transpileDependencies: ['/@yabby-business/'],
  pwa: {
    iconPaths: {
      favicon32: 'favicon.ico',
      favicon16: 'favicon.ico',
      appleTouchIcon: 'favicon.ico',
      maskIcon: 'favicon.ico',
      msTileImage: 'favicon.ico'
    }
  },
  lintOnSave: process.env.NODE_ENV === 'development',
  productionSourceMap: false, // 除去.map文件
  devServer: {
    host: '0.0.0.0',
    port: '8080',
    // port: '9001', // 连测试环境
    hot: true,
    open: true,
    proxy: {
      // '/statistics': {
      //   target: 'http://192.168.1.152:8099',
      //   changeOrigin: true,
      //   pathRewrite: {
      //     '^/statistics': '/statistics'
      //   }
      // }
      '/api': {
        target: 'http://192.168.1.87:80',
        changeOrigin: true,
        pathRewrite: {
          '^/api': '/api'
        }
      }
    }
  },
  css: {
    loaderOptions: {
      scss: {
        prependData: `@import "~@/style/util.scss";`
      }
    }
  },
  configureWebpack: config => {
    if (process.env.NODE_ENV === 'production') {
      return {
        plugins: [
          new webpack.BannerPlugin({
            banner: getBanner(),
            entryOnly: true,
            raw: true
          }),
          new webpack.DefinePlugin({
            APP_VERSION: `"${require("./package.json").version}"`,
            BUILD_DATE: buildDate,
            BRANCH: JSON.stringify(GitRevision.branch()),
            COMMITHASH: JSON.stringify(GitRevision.commithash()),
            VERSION: JSON.stringify(GitRevision.version())
          })
        ],
        name: name,
        resolve: {
          alias: {
            '@': resolve('src')
          }
        },
        devtool: 'cheap-module-source-map',
        //devtool: 'source-map',
        performance: {
          hints: 'warning',
          // 入口起点的最大体积
          maxEntrypointSize: 50000000,
          // 生成文件的最大体积
          maxAssetSize: 30000000,
          // 只给出 js 文件的性能提示
          assetFilter: function (assetFilename) {
            return assetFilename.endsWith('.js')
          }
        },
        // output: {
        //   filename: 'assets/js/[name].'+timeStamp+'.js',
        //   chunkFilename: 'assets/js/[name].'+timeStamp+'.js'
        // },
      }
    } else {
      return {
        //devtool: 'source-map',
        devtool: 'cheap-module-source-map',
      }
    }
  },
  lintOnSave: false,
  chainWebpack: config => {
    config.externals({'./cptable': 'var cptable'})
  }
}
