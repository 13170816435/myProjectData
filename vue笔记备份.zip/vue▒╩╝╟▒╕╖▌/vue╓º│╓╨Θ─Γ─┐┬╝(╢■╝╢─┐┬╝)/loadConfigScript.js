const product = '/operate/'
window.Config = {}
if (window.location.pathname.indexOf(product) !== 0) {
  // 说明是虚拟目录
  window.Config.subdir = window.location.pathname.substring(0, window.location.pathname.indexOf(product));
} else {
  window.Config.subdir = '';
}


function loadConfigScript () {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = `${window.Config.subdir}/config/config.js`;
    script.onload = () => {
      //console.log('加载/config/config.js 成功');
      resolve();
    };

    //console.log('开始 /config/config.js');
    document.getElementsByTagName('head')[0].appendChild(script);
  })
}

export default loadConfigScript