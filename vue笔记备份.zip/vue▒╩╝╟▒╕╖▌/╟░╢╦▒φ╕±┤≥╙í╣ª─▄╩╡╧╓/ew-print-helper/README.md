## 打印表格的一个库

```javascript
import {PrintHelper} from 'ew-print-helper'

new PrintHelper().table(table).prepend({
  title: '你好呀',
  exportDate: '2022-12-18',
  username: '我呀'
}).print()

```
