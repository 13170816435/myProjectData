export default function (window, document, $) {
  const cssText = `
.printX-table {
  width: 100%;
  border-collapse: collapse;
}

.printX-table thead th {
  background-color: rgb(242, 242, 242);
}

.printX-table thead th, .printX-table thead td {
  border-top: 1px solid #EBEEF5;
  font-weight: bold;
}

.printX-table th, .printX-table td {
  border-right: 1px solid #EBEEF5;
  border-bottom: 1px solid #EBEEF5;
  padding: 8px 0;
  color: #1E1D22!important;
  font-size: 14px;
}

.printX-table tr td:nth-of-type(1), .printX-table tr th:nth-of-type(1) {
  border-left: 1px solid #EBEEF5;
}

.printX-table-header .printX-table-header-title {
    box-sizing: border-box;
    line-height: 38px;
    text-align: center;
    font-size: 18px;
    font-weight: bold;
}

.printX-table-header .printX-table-header-date {
    line-height: 40px;
    padding: 0 10px;
    font-size: 14px;
}
  `

  const insertCss = () => {
    const styleTag = $('#printTable')
    if (styleTag.length > 0) {
      return
    }
    const textNode = document.createTextNode(cssText)
    const style = $('<style/>').attr('id', 'printTable').attr('type', 'text/css').append(textNode)
    style.appendTo(document.head)
  }


  function cloneTable(sourceTable) {
    const printableTable = $(`<table class="print-table-preview"><thead></thead><tbody></tbody></table>`)
    printableTable.attr('class', sourceTable.attr('class'))
    const $header = printableTable.find("thead")
    const $body = printableTable.find('tbody')
    sourceTable.find('thead').find('tr').each(function () {
      const $row = $(this)
      const newRow = $('<tr>')
      $row.find('th,td').each(function () {
        const $originCell = $(this)
        if ($originCell.css('display') === 'none') {
          return
        }
        const rowspan = $originCell.attr('rowSpan')
        const colspan = $originCell.attr('colSpan')
        const $cell = $('<th>' + $originCell.text() + '</th>')
        /*.width($originCell.width())*/
        if (rowspan) {
          $cell.attr('rowSpan', rowspan)
        }

        if (colspan) {
          $cell.attr('colSpan', colspan)
        }

        $cell.attr('style', $originCell.attr('style'))
        newRow.append($cell)
      })
      $header.append(newRow)
    })

    sourceTable.find('tbody').find('tr').each(function () {
      const $row = $(this)
      const newRow = $('<tr />')
      $row.find('td').each(function () {
        const $originCell = $(this)
        const rowspan = $originCell.attr('rowSpan')
        const colspan = $originCell.attr('colSpan')

        const $cell = $('<td align="center">' + $originCell.text() + '</td>')

        if (rowspan) {
          $cell.attr('rowSpan', rowspan)
        }
        if (colspan) {
          $cell.attr('colSpan', colspan)
        }
        $cell.attr('style', $originCell.attr('style'))
        newRow.append($cell)
      })
      $body.append(newRow)
    })
    return printableTable
  }

  const prependHeader = params => {
    const {
      title,
      date,
      username,
      dateLabel = '统计时间',
      userLabel = '制表人'
    } = params
    const header = document.createElement('div')
    header.classList.add('printX-table-header')
    header.innerHTML += `
         <h3 class="printX-table-header-title printX-table-header-empty">${title}</h3>
         <div class="printX-table-header-date printX-table-date-empty">
         ${dateLabel}：${date}&nbsp;&nbsp;&nbsp;&nbsp;${userLabel}：${username}
         </div>
       `
    return header
  }

  $.fn.printX = function (title, header, ...config) {

    insertCss()
    this.each(function () {
      /*const table = cloneTable($(this))*/

      let headerElm = null
      if (header !== null) {
        headerElm = prependHeader(header)
      }

      $(this).printThis({
        importStyle: false,
        importCSS: false,
        importCSSText: cssText,
        header: headerElm ? $(headerElm) : null,
        ...config
      })
    })
    return this
  }
}
