<template>
  <div class="h_full bg_ebeef5">
    <!-- <breadcrumb :breadCrumbs="['远程培训', '教学统计', '学习情况']"></breadcrumb> -->
    <div ref="tabHeight" class="title-bar flex_row ">
      <div class="tl col">
        <span class="title-name clr_303 fl">
          <i class="iconfont icondingwei mr10"></i>运行情况
          <i class="iconfont iconzhankaishouqi"></i>学习情况
        </span>
      </div>
    </div>
    <div class="bgf studyContainer bradius4 flex_row flex_column">
      <ul class="clear boxs tab">
        <li v-for="(item, index) in tabList" :key="index" @click="setTabIndex(index)" class="fl pl10 pr10 mr10 boxs pb10 cursor" :class="{ active: tabIndex === index }">
          {{ item.text }}
        </li>
      </ul>
      <div class="mb10 med-query mt10">
        <el-form :inline="true" class="demo-form-inline clear" label-width="85px" label-position="right">
          <el-form-item class="fl mr10" v-show="tabIndex === 0">
            <div slot="label">
              <span v-show="tabIndex == 0">学习时间：</span>
            </div>
            <div class="fl w240x searchTimeDiv">
              <SearchTime @getTimes="getTime" :clearTime="false" :initTime="initTime"/>
            </div>
          </el-form-item>
          <el-form-item class="fl">
            <div slot="label">
              <span>所属机构：</span>
            </div>
            <div class="fl w200x">
              <el-select class="w200x" size="small" v-model="search.institution_id" @change="institutionChange" filterable clearable>
                <el-option v-for="(item, index) in institutions" :key="index" :label="item.name" :value="item.id"></el-option>
              </el-select>
            </div>
          </el-form-item>
          <el-form-item v-show="tabIndex === 1"  class="fl">
            <div slot="label">
              <span>所属科室：</span>
            </div>
            <div class="fl w150x">
              <el-select class="w150x" size="small" v-model="search.office_id" @change="getList" filterable clearable>
                <el-option label="全部" value=""></el-option>
                <el-option v-for="(item, index) in officeList" :key="index" :label="item.name" :value="item.id"></el-option>
              </el-select>
            </div>
          </el-form-item>
          <el-form-item v-show="tabIndex === 0" label="姓名：" class="fl mr10" label-width="60px">
            <div class="fl w150x">
              <el-select :disabled="userLite.length == 0" v-model="search.user_id" class="w150x" size="small" multiple filterable
              clearable collapse-tags @change="clickEvent">
                <el-option v-for="(item, index) in userLite" :key="index" :label="item.name" :value="item.id"></el-option>
              </el-select>
            </div>
          </el-form-item>
          <el-form-item v-show="tabIndex === 1" label="关键字：" class="fl mr10" label-width="110px">
            <el-input size="small" class="w200x" v-model="search.keywords" placeholder="请输入姓名/手机号查询" @keydown.enter.native="clickEvent"></el-input>
          </el-form-item>
          <el-form-item class="fl mr10">
            <el-button type="primary" size="small" @click="clickEvent">查询</el-button>
            <el-button size="small" @click="reset">重置</el-button>
            <el-button v-show="tabIndex === 0" size="small" @click="exportExcel(1)">导出</el-button> <!--导出学习考试统计-->
            <el-button v-show="tabIndex === 1" size="small" @click="exportExcel(2)">导出</el-button> <!--导出学习时长统计-->
          </el-form-item>
          <el-form-item class="fr">
            <el-button type="primary" size="small" class="mr10" v-show="tabIndex === 1" @click="sendMessage()">发送短信</el-button>
          </el-form-item>
        </el-form>
        <el-form :inline="true" class="demo-form-inline clear" label-width="85px" label-position="right">
          <el-form-item label="教学中心：" class="fl mr10">
            <el-select v-model="search.source_id" filterable  @change="changeServiceCenter" class="w230x" size="small">
              <el-option v-for="(item, index) in teachCenterArr" :key="index" :value="item.id" :label="item.name"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="课程分类：" class="fl mr10">
            <el-select v-model="search.teach_category_ids" filterable clearable collapse-tags multiple @change="clickEvent" class="w200x" size="small">
              <el-option v-for="(item, index) in teachCategorys" :key="index" :value="item.id" :label="item.dic_define_value"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="课程类型：" class="fl mr10">
            <el-checkbox-group v-model="search.teach_kind" @change="clickEvent">
              <el-checkbox :label="1">直播</el-checkbox>
              <el-checkbox :label="2">点播</el-checkbox>  
              <el-checkbox :label="3">互动</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
          <el-form-item v-show="tabIndex === 1"  class="fl mr10">
            <div slot="label">
              <span>已学时长：</span>
            </div>
            <div class="fl w150x">
              <el-input-number size="small" class="w67x" v-model="search.start_already_duration" @keyup.enter.native="clickEvent" :min="0" :max="100" :controls="false"></el-input-number>
              -
              <el-input-number size="small" class="w67x" v-model="search.end_already_duration" @keyup.enter.native="clickEvent" :min="0" :max="100" :controls="false"></el-input-number>
            </div>
            (百分比)
          </el-form-item>
        </el-form>
      </div>
      <!-- 学习考试统计 -->
      <div v-show="tabIndex === 0" class="studyTestTable">
        <el-table stripe border class="w_full" :data="studyTableData" ref="studyTable" :height="tableHeight" v-loading="loading" @sort-change="changeSort">
          <el-table-column fixed="left" type="index" :index="indexMethod" width="80px" label="序号">
          </el-table-column>
          <el-table-column prop="user_name" label="姓名"></el-table-column>
          <el-table-column prop="institution_name" label="所属机构"></el-table-column>
          <el-table-column prop="title_kind" label="岗位"></el-table-column>
          <el-table-column prop="total_teach_qty" label="应学课程数">
            <template slot-scope="scope">
              <el-button class="strong" type="text" @click="studyDetail(scope.row)">{{ scope.row.total_teach_qty }}</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="total_teach_credit" label="应学学分" width="100"></el-table-column>
          <el-table-column prop="study_teach_qty" label="已学课程数"></el-table-column>
          <el-table-column prop="study_teach_credit" label="已学学分" width="100"></el-table-column>
          <el-table-column prop="total_study_duration" label="学习时长" sortable="custom"></el-table-column>
          <el-table-column prop="total_paper_qty" label="应考试数量">
            <template slot-scope="scope">
              <el-button class="strong" type="text" @click="studyDetail(scope.row, 1)">{{ scope.row.total_paper_qty }}</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="already_paper_qty" label="已考试数量"></el-table-column>
          <el-table-column prop="paper_average_score" label="考试平均得分"></el-table-column>
        </el-table>
        <el-dialog v-dialogDrag class="detailAlert" :title="`${studentName}-学习明细`" :append-to-body="true" :visible.sync="studyDialog" :destroy-on-close="true" width="1280px">
          <div class="traniningDetailAlert">
          <el-table class="w_full" ref="studyDetail" :data="studyDetailTableData" height="60vh" v-loading="loading1">
            <el-table-column fixed="left" type="index" width="80px" label="序号">
              <template slot-scope="scope">
                {{ (pageIndex - 1) * pageSize + (scope.$index + 1) }}
              </template>
            </el-table-column>
            <commonTable :propData="studyDetailPropData"></commonTable>
          </el-table>
          <pagination-tool :total="total1" :page.sync="pageIndex" :limit.sync="pageSize" :pageSizes="[20, 50, 100, 300, 500]" @pagination="pagination1(null)"/>
          </div>
          <div slot="footer">
            <el-button size="medium" type="primary" @click="exportExcel(0)">导出</el-button>
          </div>
        </el-dialog>
        <el-dialog v-dialogDrag class="detailAlert" :title="`${studentName}-考试明细`" :append-to-body="true" :visible.sync="studyDialog1" :destroy-on-close="true" width="1280px">
          <div class="traniningDetailAlert">
          <el-table ref="paperTable" class="w_full" :data="studyPaperTableData" height="60vh" v-loading="loading1">
            <el-table-column fixed="left" type="index" width="80px" label="序号">
              <template slot-scope="scope">
                {{ (pageIndex - 1) * pageSize + (scope.$index + 1) }}
              </template>
            </el-table-column>
            <el-table-column prop="paper_name" label="考试名称"></el-table-column>
            <el-table-column prop="begin_time" label="考试时间" width="160"></el-table-column>
            <el-table-column prop="total_minute" label="考试时长（分钟）" width="150"></el-table-column>
            <el-table-column prop="state_name" label="状态" width="80"></el-table-column>
            <el-table-column prop="" label="考试对象/人">
              <template slot-scope="scope">
                {{ handleTestTarget(scope.row) }}（{{ scope.row.test_count }}）
              </template>
            </el-table-column>
            <el-table-column prop="total_score" label="总分" width="60"></el-table-column>
            <el-table-column prop="score" label="分数" width="60"></el-table-column>
            <el-table-column prop="ranking" label="名次" width="60"></el-table-column>
          </el-table>
          <pagination-tool :total="total1" :page.sync="pageIndex" :limit.sync="pageSize" :pageSizes="[20, 50, 100, 300, 500]" @pagination="pagination1(null)"/>
          </div>
          <div slot="footer">
            <el-button size="medium" type="primary" @click="exportExcel(0)">导出</el-button>
          </div>
        </el-dialog>
      </div>
      <!--学习时长 统计-->
      <div v-show="tabIndex === 1" class="studyDurationTable">
        <el-table stripe border class="w_full dd3" :height="tableHeight" :data="durationStaticsTableData" v-loading="loading"
        @select="setSelectedTableData" @select-all="setSelectedTableData">
          <el-table-column type="selection" width="55"></el-table-column>
          <el-table-column type="index" width="55" :index="indexMethod" label="序号"></el-table-column>
          <el-table-column label="操作" width="90">
            <template slot-scope="scope">
              <el-button type="text" @click="sendMessage(scope.row)">发送短信</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="institution_name" label="机构" align="center"></el-table-column>
          <el-table-column prop="office_name" label="科室" align="center"></el-table-column>
          <el-table-column prop="user_name" label="姓名" align="center"></el-table-column>
          <el-table-column prop="user_phone" label="手机号" align="center"></el-table-column>
          <el-table-column label="已学情况" align="center">
            <el-table-column prop="already_duration" label="已学时长" align="center"></el-table-column>
            <el-table-column prop="already_credit" label="已学学分" align="center"></el-table-column>
            <el-table-column prop="already_teach_qty" label="已学课程数" align="center"></el-table-column>
          </el-table-column>
          <el-table-column label="必学情况" align="center">
            <el-table-column prop="must_duration" label="必学时长" align="center"></el-table-column>
            <el-table-column prop="must_credit" label="必学学分" align="center"></el-table-column>
            <el-table-column prop="must_teach_qty" label="必学课程数" align="center"></el-table-column>
          </el-table-column>
          <el-table-column label="学习百分比" align="center">
            <el-table-column prop="study_duration_ratio" label="时长" align="center"></el-table-column>
            <el-table-column prop="study_credit_ratio" label="学分" align="center"></el-table-column>
            <el-table-column prop="study_teach_ratio" label="课程数" align="center"></el-table-column>
          </el-table-column>
        </el-table>
      </div>
      <pagination-tool class="ba" :total="total" :page.sync="search.page_index" :limit.sync="search.page_size" @pagination="pagination"/>
      <el-dialog v-dialogDrag :visible.sync="dialogVisible" title="发送短信" width="460px" @close="resetSmsInfo" append-to-body center>
        <div class="smsAlert">
        <div>
          <span><i class="eduIconfont iconfont iconbitian clr_red mr5"></i>学习截止时间：</span>
          <el-date-picker size="small" v-model="studyDeadline" type="datetime" placeholder="选择学习截止时间" value-format="yyyy-MM-dd HH:mm"
          :picker-options="pickerOptions" class="w290xi"></el-date-picker>
        </div>
        <div class="mt10" v-show="isTimedSend">
          <span><i class="eduIconfont iconfont iconbitian clr_red mr5"></i>定时发送时间：</span>
          <el-date-picker size="small" v-model="timedSendTime" type="datetime" placeholder="选择发送短信时间" value-format="yyyy-MM-dd HH:mm"
          :picker-options="pickerOptions" class="w290xi"></el-date-picker>
        </div>
        <el-radio-group class="mt10 ml120 mb10" v-model="isTimedSend">
          <el-radio :label="false">立即发送</el-radio>
          <el-radio :label="true">定时发送</el-radio>
        </el-radio-group>
        <div class="pl50">
          <span style="vertical-align: top;">短信模板：</span>
          <div class="dib w290x dd2">{{ smsTemplate }}</div>
        </div>
        </div>
        <div slot="footer" class="fr">
          <el-button size="small" @click="dialogVisible = false">取 消</el-button>
          <el-button size="small" type="primary" @click="postTeachPublicSmsSendNotStandard">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import Breadcrumb from '@/components/common/Breadcrumb' // 面包屑
import PaginationTool from '@/components/common/PaginationTool'
import SearchTime from '@/components/common/SearchTime' // 搜索时间
// import commonTable from '@/views/operate/education/components/commonTable.vue'
import commonTable from '@/components/common/CommonTable.vue'
import { export_json_to_excel } from '@/utils/ExportExcel'
import { getStatisticsStudy, getStatisticsStudyDetail, getUserLite, getStatisticsDuration, getStatisticsLecturerData,
  getStatisticsPaperDetail } from '@/api/teach'
import { getTeachPublicSmsTemplate, postTeachPublicSmsSendNotStandard } from '@/api/teachPub' 
import { getInstitutions } from '@/api/operate'
import { getOfficesLite } from '@/api/commonHttp'
import { getDictInforList } from '@/api/dataDictionary'
import { getAllServiceCenter } from '@/api/platform_costomer/telemedicine'
export default {
  name: 'studySituation',
  components: { Breadcrumb, PaginationTool, SearchTime, commonTable },
  data () {
    return {
      teachCenterId: '',
      tabIndex: 0,
      tabList: [
        { text: '学习考试', code: 1 },
        { text: '学习时长', code: 2 }
      ],
      tableHeight: '100%',
      initTime: ['', ''],
      teachCenterArr: [],
      search: {
        user_id: [],
        institution_id: '',
        office_id: '',
        start_date: '',
        end_date: '',
        teach_name: '',
        keywords: '',
        start_already_duration: undefined,
        end_already_duration: undefined,
        page_index: 1,
        page_size: 20,
        source_id: '',
        teach_category_ids: [],
        teach_kind: []
      },
      userLite: [],
      durationStaticsTableData: [],
      loading: false,
      loading1: false,
      pageIndex: 1,
      pageSize: 20,
      total: 0,
      total1: 0,
      institutions: [],
      teachCategorys: [],

      // 学习考试
      studyPropData: [
        { prop: 'user_name', label: '姓名' },
        { prop: 'institution_name', label: '所属机构' },
        { prop: 'title_kind', label: '岗位' },
        { prop: 'total_teach_qty', label: '应学课程数' },
        { prop: 'total_teach_credit', label: '应学学分', width: 100 },
        { prop: 'study_teach_qty', label: '已学课程数' },
        { prop: 'study_teach_credit', label: '已学学分', width: 100 },
        { prop: 'total_study_duration', label: '学习时长', sortable: "custom" },
        { prop: 'total_paper_qty', label: '应考试数量' },
        { prop: 'already_paper_qty', label: '已考试数量'},
        { prop: 'paper_average_score', label: '考试平均得分'},
      ],
      studyTableData: [],
      studyDetailPropData: [
        { prop: 'teach_name', label: '课程名称' },
        { prop: 'teach_credit', label: '课程学分', width: 100 },
        { prop: 'read_date', label: '学习时间' },
        { prop: 'has_time_length', label: '已学时长' },
        { prop: 'before_submit_date', label: '课前习题提交时间' },
        { prop: 'after_submit_date', label: '课后习题提交时间' },
        { prop: 'answer_rate', label: '答题正确率(课前/课后)' }
      ],
      studyPaperPropData: [
        { prop: 'paper_name', label: '考试名称' },
        { prop: 'begin_time', label: '考试时间', width: 100 },
        { prop: 'total_minute', label: '考试时长（分钟）' },
        { prop: 'state_name', label: '状态' },
        { prop: 'paper_targets', label: '考试对象/人' },
        { prop: 'total_score', label: '总分' }
      ],
      studyDetailTableData: [],
      studyPaperTableData: [],
      officeList: [],
      studentName: '',
      studyDialog: false,
      studyDialog1: false,
      selectedTableData4: [],
      selectedData4: [],
      durationStaticsTableData: [],
      durationStaticsPropData: [ // 学习时长
        { prop: 'institution_name', label: '所属机构' },
        { prop: 'office_name', label: '科室' },
        { prop: 'user_name', label: '姓名' },
        { prop: 'user_phone', label: '手机号' },
        { prop: 'already_duration', label: '已学时长', width: 100 },
        { prop: 'already_credit', label: '已学学分', width: 100 },
        { prop: 'already_teach_qty', label: '已学课程数' },
        { prop: 'must_duration', label: '必学时长', width: 100 },
        { prop: 'must_credit', label: '必学学分', width: 100 },
        { prop: 'must_teach_qty', label: '必学课程数'},
        { prop: 'study_duration_ratio', label: '时长百分比',width: 100  },
        { prop: 'study_credit_ratio', label: '学分百分比',width: 100 },
        { prop: 'study_teach_ratio', label: '课程数百分比',width: 100},
      ],
      dialogVisible: false,
      studyDeadline: '',
      timedSendTime: '',
      isTimedSend: false,
      smsTemplate: '',
      pickerOptions: {
        disabledDate: (time) => {
          return time.getTime() < (new Date().getTime() -24*60*60*1000)
        }
      },
      studySorts: []
    }
  },
  methods: {
    changeServiceCenter (val) {
      this.search.teach_category_ids = []
      if (val) {
        this.getDictInforList()
      } else {
        this.search.source_id = 0
        this.teachCategorys = []
      }
      this.getList()
    },
    // 获取所有的服务中心(不分页)
    async getMyAllServiceCenter () {
      const param = {
        category: 2,
      }
      this.serviceCenterAr = []
      const res = await getAllServiceCenter(param)
      if (res.code === 0) {
        this.teachCenterArr = res.data
        this.teachCenterArr.unshift({name: '全部',id: ''})
      }
    },
     // 处理考试对象
     handleTestTarget (row) {
      var target = ''
      if (row.paper_targets && row.paper_targets.length > 0) {
        row.paper_targets.forEach(item => {
          if (target) {
            target += '，'
          }
          if (item.teach_name) {
            target += item.teach_name
          }
          if (item.class_name) {
            target += item.class_name
            if (item.group_name) {
              target += ' - ' + item.group_name
            }
          }
          if (item.institution_name) {
            target += item.institution_name
            if (item.office_name) {
              target += ' - ' + item.office_name
            }
          }
          if (item.train_plan_name) {
            target += item.train_plan_name
            if (item.train_plan_subject_name) {
              target += `[${item.train_plan_office_name}：${item.train_plan_subject_name}]`
            }
          }
        })
      }
      return target
    },
    // 学习统计明细
    async studyDetail (row, index) {
      this.pageIndex = 1
      this.pageSize = 20
      this.detailItem = row
      this.studentName = row.user_name
      if (index) {
        this[`studyDialog${index}`] = true
      } else {
        this.studyDialog = true
      }
      this.pagination1()
    },
    // 获取课程分类
    async getDictInforList () {
      var param = {
        DicTypeCode: 'TeachCategory',
        // DepartmentId: sessionStorage.getItem('teachCenterId')
        DepartmentId: this.search.source_id,
        Systemid: this.search.source_id,
      }
      var res = await getDictInforList(param)
      if (res.code !== 0) {
        this.$message.error(res.msg)
        return
      }
      this.teachCategorys = res.data
    },
    // 获取所有讲师信息
    async getStatisticsLecturer () {
      var res = await getStatisticsLecturerData({
        lecturer: '',
        source_id: this.teachCenterId,
        page_index: 1,
        page_size: 1000
      })
      if (res.code !== 0) {
        this.$message.error(res.msg)
        return
      }
      this.lecterers = res.data
    },
    changeSort ({ column, prop, order }) {
      let sorts = []
      switch (order) {
        case 'ascending':
          sorts = ['has_view_seconds|asc']
          break
        case 'descending':
          sorts = ['has_view_seconds|desc']
          break
        default:
          sorts = null
      }
      if (sorts) {
        this.studySorts = sorts
      }
      this.getStatisticsStudy()
    },
    setSelectedTableData (data) {
      this[`selectedTableData4`] = data
    },
    resetSmsInfo () {
      this.studyDeadline = ''
      this.timedSendTime = ''
      this.isTimedSend = false
      this.selectedData4 = []
    },
    // 获取短信模板
    async getTeachPublicSmsTemplate () {
      const res = await getTeachPublicSmsTemplate({ template_kind: 1 })
      if (res.code !== 0) {
        this.$message.error(res.msg)
        return
      }
      this.smsTemplate = res.data || ''
    },
    sendMessage (data) {
      this.getTeachPublicSmsTemplate()
      let list = []
      if (data) {
        list = [data]
      } else {
        list = this.selectedTableData4
      }
      this.selectedData4 = list.map(ele => {
        return {
          user_id: ele.user_id,
          name: ele.user_name,
          phone: ele.user_phone
        }
      })
      if (this.selectedData4.length === 0) {
        this.$message.error('请选择需要发送短信的学员')
        return
      }
      this.dialogVisible = true
    },
    async postTeachPublicSmsSendNotStandard () {
      if (!this.studyDeadline) {
        this.$message.error('请选择学习截止时间')
        return
      }
      if (new Date(this.studyDeadline) < new Date()) {
        this.$message.error('学习截止时间不能早于当前时间')
        return
      }
      if (!this.isTimedSend) {
        this.timedSendTime = ''
      }
      if (this.isTimedSend) {
        if (!this.timedSendTime) {
          this.$message.error('请选择定时发送时间')
          return
        } else if (new Date(this.timedSendTime) < new Date()) {
          this.$message.error('定时发送时间不能早于当前时间')
          return
        }
      }
      const data = {
        study_deadline: this.studyDeadline,
        is_timed_send: this.isTimedSend,
        timed_send_time: this.timedSendTime,
        to_user_infos: this.selectedData4
      }
      const res = await postTeachPublicSmsSendNotStandard(data)
      if (res.code !== 0) {
        this.$message.error(res.msg)
        return
      }
      this.$message.success(res.msg)
      this.dialogVisible = false
    },
    async getStatisticsDuration () {
      const params = {
        page_index: this.search.page_index,
        page_size: this.search.page_size,
        teach_center_id: this.search.source_id,
        teach_kind: this.search.teach_kind,
        teach_category_ids: this.search.teach_category_ids
      }
      if (this.search.start_already_duration !== undefined) {
        if (this.search.start_already_duration < 0 || this.search.start_already_duration > 100) {
          this.$message.error('请输入0-100的整数')
          return
        }
        params.start_already_duration = this.search.start_already_duration
      }
      if (this.search.end_already_duration !== undefined) {
        if (this.search.end_already_duration < 0 || this.search.end_already_duration > 100) {
          this.$message.error('请输入0-100的整数')
          return
        }
        params.end_already_duration = this.search.end_already_duration
      }
      if (this.search.start_already_duration > this.search.end_already_duration) {
        this.$message.error('结束时长不能小于开始时长')
        return
      }
      if (this.search.keywords) {
        params.keywords = this.search.keywords
      }
      if (this.search.institution_id) {
        params.institution_id = this.search.institution_id
      }
      if (this.search.office_id) {
        params.office_id = this.search.office_id
      }
      const res = await getStatisticsDuration(params)
      if (res.code !== 0) {
        this.$message.error(res.msg)
        return
      }
      this.durationStaticsTableData = res.data || []
      this.total = res.page.total_count
      this.loading = false
    },
    async getOfficesLite () {
      const url = `/offices/lite?institution_id=${this.search.institution_id}`
      const res = await getOfficesLite(url)
      if (res.code !== 0) {
        this.$message.error(res.msg)
        return
      }
      this.officeList = res.data || []
    },
    // 获取用户列表
    async getUserLite () {
      const res = await getUserLite({
        institution_id: this.search.institution_id
      })
      if (res.code !== 0) {
        this.$message.error(res.msg)
        return
      }
      this.userLite = res.data
    },
    // 获取所属机构信息
    async getInstitutionList () {
      const data = {
        service_center_id: this.teachCenterId
      }
      const res = await getInstitutions(data)
      if (res.code !== 0) {
        this.$message.error(res.msg)
        return
      }
      this.institutions = res.data
    },
    institutionChange (val) {
      this.search.office_id = ''
      if (!val) {
        this.officeList = []
        this.userLite = []
        return
      }
      this.userLite = []
      this.search.user_id = []
      if (this.tabIndex === 0) {
        this.getUserLite()
        this.search.page_index = 1
        this.getList()
      } else {
        this.getOfficesLite()
        this.getList()
      }
    },
    // 序号
    indexMethod (index) {
      return (this.search.page_index - 1) * this.search.page_size + (index + 1)
    },
    getTime (val) {
      if (!val) {
        this.initTime = []
      } else {
        this.search.start_date = val[0]
        this.search.end_date = val[1]
      }
      this.search.page_index = 1
      this.getList()
    },
    pagination (item) {
      this.search.page_index = item.page
      this.search.page_size = item.limit
      this.getList()
    },
    setTabIndex (num) {
      this.tabIndex = num
      this.reset()
    },
    clickEvent () {
      this.search.page_index = 1
      this.getList()
    },
    // 重置
    reset () {
      this.search = {
        user_id: [],
        institution_id: '',
        office_id: '',
        start_date: '',
        end_date: '',
        teach_name: '',
        keywords: '',
        start_already_duration: undefined,
        end_already_duration: undefined,
        page_index: 1,
        page_size: 20,
        source_id: '',
        teach_category_ids: [],
        teach_kind: []
      }
      this.userLite = []
      this.initTime = ['', '']
      this.officeList = []
    },
    getList () {
      this.loading = true
      //this.search.source_id = this.teachCenterId
      if (this.tabIndex == 0) {
        this.getStatisticsStudy()
      } else {
        this.getStatisticsDuration()
      }
    },
    // 获取学习统计
    async getStatisticsStudy () {
      const params = JSON.parse(JSON.stringify(this.search))
      if (this.studySorts.length) {
        params.sorts = this.studySorts
      } else {
        params.sorts = ['institution_id|desc']
      }
      const res = await getStatisticsStudy(params)
      if (res.code !== 0) {
        this.$message.error(res.msg)
        return
      }
      this.studyTableData = res.data
      this.total = res.page.total_count
      this.$nextTick(() => {
        this.$refs.studyTable.doLayout()
      })
      this.loading = false
    },
    async pagination1 (params) {
      const data = {
        page_index: this.pageIndex,
        page_size: this.pageSize,
        source_id: this.teachCenterId,
        ...params
      }
      let res = null
      this.loading1 = true
      if (this.tabIndex === 0) {
        data.user_id = this.detailItem.user_id
        if (this.studyDialog1) {
          res = await getStatisticsPaperDetail(data)
          this.loading1 = false
          if (res.code !== 0) {
            this.$message.error(res.msg)
            return
          }
          if (!params) {
            this.studyPaperTableData = res.data
            this.$nextTick(() => {
              this.$refs['paperTable'].doLayout()
            })
          } else {
            return res.data
          }
        } else if (this.studyDialog) {
          let data1 = JSON.parse(JSON.stringify(this.search))
          data1.user_id = this.detailItem.user_id
          data1.page_index = this.pageIndex
          data1.page_size = this.pageSize
          if (params) {
            data1 = {
              ...data1,
              ...params
            }
          }
          res = await getStatisticsStudyDetail(data1)
          this.loading1 = false
          if (res.code !== 0) {
            this.$message.error(res.msg)
            return
          }
          if (!params) {
            this.studyDetailTableData = res.data
            this.$nextTick(() => {
              this.$refs['studyDetail'].doLayout()
            })
          } else {
            return res.data
          }
        }
      }
      if (!params) {
        this.total1 = res.page.total_count
      }
    },
    // 导出
    async exportExcel (type) {
      let filename = ''
      let tableData = []
      let arr = []
      if (type == 0) {
        tableData = await this.pagination1({ page_index: 1, page_size: 10000 })
        if (this.studyDialog1) {
          arr = this.studyPaperPropData
          filename = this.detailItem.user_name + '-考试明细'
          tableData.forEach(ele => {
            ele.paper_targets = `${this.handleTestTarget(ele)}（${ele.test_count}）`
          })
        } else {
          // 学习详情
          arr = this.studyDetailPropData
          filename = this.detailItem.user_name + '-学习明细'
        }
      } else if (type == 1) {
        // 学习考试
        arr = this.studyPropData
        tableData = this.studyTableData
        if (this.search.start_date && this.search.start_date != '') {
          filename = `${this.search.start_date}~${this.search.end_date}-考试统计`
        } else {
          filename = '考试统计'
        }
      } else if (type == 2) {
        // 学习时长
        arr = this.durationStaticsPropData
        tableData = this.durationStaticsTableData
        filename = '时长统计'
      }

      const header = [] // 表头 值对应汉字
      let data = []
      const filterVal = []
      arr.forEach(item => {
        header.push(item.label)
        filterVal.push(item.prop)        
      })
      data = this.formatJson(filterVal, tableData)
      export_json_to_excel({
        header,
        data,
        filename,
        autoWidth: true,
        bookType: 'xlsx'
      })
      if (type == 1) {
        this.studyDialog = false
      } else if (type == 2) {
        this.courseDialog = false
      } else if (type == 3) {
        this.staDialog = false
      }
    },
    formatJson (filterVal, jsonData) {
      return jsonData.map(v =>
        filterVal.map(j => {
          return v[j]
        })
      )
    }
  },
  mounted () {
    // this.teachCenterId = sessionStorage.getItem('teachCenterId')
    // sessionStorage.setItem('teachCenterId', 0)
    // this.teachCenterId = 0
    this.initTime = ['', ''] // this.$getDefaultTime(30, 1)
    this.search.start_date = this.initTime[0]
    this.search.end_date = this.initTime[1]
    this.getInstitutionList()
    this.getStatisticsLecturer()
    this.getMyAllServiceCenter()
    //this.getDictInforList()
  }
}
</script>

<style lang="less" scoped>
@import "~@/style/variable.less";
.studyContainer{
  padding:10px 15px;
  height: calc(100% - 46px);
}
::v-deep .studyTestTable{
  height: calc(100% - 184px);
  .el-table__body-wrapper{
    height: calc(100% - 51px)!important;
    overflow: auto;
  }  
}
::v-deep .studyDurationTable{
  height: calc(100% - 184px);
  .el-table__body-wrapper{
    height: calc(100% - 80px)!important;
    overflow: auto;
  }  
}
.med-query ::v-deep .el-form-item {
  margin-bottom: 5px;
}
.tab li {
  position: relative;
  &.active:after {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 2px;
    background: @variable-clr-main;
    content: '';
  }
}
.detailAlert {
  ::v-deep .el-table__body-wrapper {
    max-height: 80vh;
    overflow-y: auto !important;
  }
  ::v-deep .el-table__fixed::before {
    display: none !important;
  }
}
.dd2 {
  background: #F5F5F5;
  padding: 10px;
  border: 1px solid #DCDFE6;
  border-radius: 2px;
}
.dd3 ::v-deep .el-table__body-wrapper {
  height: calc(100% - 97px) !important;
}
.w240x{
  width:240px;
}
::v-deep .searchTimeDiv{
  .el-date-editor{
    width:240px;
  }
  .el-range__close-icon{
    line-height:25px;
  }
}
::v-deep .traniningDetailAlert{
  padding: 15px!important;
  padding-bottom:0px!important;
}
.smsAlert{
  padding: 10px 25px 25px!important;
}
.w290x{
  width:290px;
}
.pl50{
  padding-left:50px;
}
</style>