<template>
  <div class="serviceIndexCon">
    <Breadcrumb :breadCrumbs="['服务首页',]"/>
    <div class="serviceIndexContent">
        <div class="tabBox">
           <div class="allTab">
             <span class="oneTab">服务</span>
             <span class="oneTab">异常</span>
             <span class="oneTab">正常</span>
           </div>
           <div @click="watchAllIntro($event)" class="watchMore">
             <span class="operateCon">展开全部</span>
             <i class="iconfont showOrHideIcon">&#xe642;</i>
           </div>
        </div>
        <div class="tabContent introduceCon">
            <!--注意这里要加个 子元素div 来专门设置内容的最多高度和滚动条 
             如果不加个子元素 直接在父元素tabContent上设置 max-height:100px; over-flow:auto  即便内容小于100px 点击展开时 也会看到滚动条-->
            <div class="tabContentBox">
                爱上发动机拉萨大家发拉萨的飞机拉是否拉萨大幅拉升发撒了发
                士大夫点击链接撒地方拉萨酱豆腐拉萨的飞机拉萨地方就爱丽丝的附件
                暗室逢灯就爱上了对方就萨拉地方啊拉萨地方撒地方撒地方顶顶顶大地方
                阿达房间阿里山地方撒的法律阿斯蒂芬萨芬的撒旦发射点发打发十分
                安德森发生了的房间拉萨打飞机啊是地方拉萨的弗利萨的弗利萨的发拉萨的
                奥利弗就爱上对方就疗法的数量阿斯兰的发生了地方萨拉地方拉是否士大夫
                爱上发动机拉萨大家发拉萨的飞机拉是否拉萨大幅拉升发撒了发
                士大夫点击链接撒地方拉萨酱豆腐拉萨的飞机拉萨地方就爱丽丝的附件
                暗室逢灯就爱上了对方就萨拉地方啊拉萨地方撒地方撒地方顶顶顶大地方
                阿达房间阿里山地方撒的法律阿斯蒂芬萨芬的撒旦发射点发打发十分
                安德森发生了的房间拉萨打飞机啊是地方拉萨的弗利萨的弗利萨的发拉萨的
                奥利弗就爱上对方就疗法的数量阿斯兰的发生了地方萨拉地方拉是否士大夫
            </div>
            
        </div>

        <div class="pieChart">
            <chart-item
                :option="pieProgressOption"
                v-show="pieProgressOption"
            ></chart-item>
        </div>
    </div>
  </div>
</template>
<script>
import * as echarts from "echarts";
import chartItem from "@/components/enchart/chartItem";
import Breadcrumb from '@/components/common/Breadcrumb'
export default {
   components: { Breadcrumb, chartItem },
   data () {
    return {
      
    }
   },
   computed: {
     pieProgressOption () {
        let option = null
        var data = [
        { name: '高级风险', value: 76 },
        { name: '中级风险', value: 12 },
        { name: '低级风险', value: 10 },
        ];
        var dataHigh = data[0].value;
        var dataMiddle = data[1].value;
        var dataLow = data[2].value;
        var total = 0;
        for (var i = 0; i < data.length; i++) {
          total += data[i].value;
        }

        var perHigh = ((dataHigh / total) * 100).toFixed(0) + '%';
        var perMiddle = ((dataMiddle / total) * 100).toFixed(0) + '%';
        var perLow = ((dataLow / total) * 100).toFixed(0) + '%';

        option = {
        backgroundColor: '#fff',
        title: [
        {
        text: '风险等级',
        top: 30,
        left: 30,
        textStyle: {
            color: '#35598d',
            fontSize: 18,
            fontWeight: 'normal',
        },
        },
        {
        text: '高级风险' + '{num|' + dataHigh + '}条',
        bottom: '28%',
        left: '14%',
        textAlign: 'center',
        textStyle: {
            color: '#666',
            fontSize: 20,
            fontWeight: 'normal',
            textAlign: 'center',
            rich: {
            num: {
            color: '#4d71df',
            fontSize: 20,
            },
            },
        },
        },
        {
        text: '中级风险' + '{num|' + dataMiddle + '}条',
        bottom: '28%',
        left: '49%',
        textAlign: 'center',
        textStyle: {
            color: '#666',
            fontSize: 20,
            fontWeight: 'normal',
            rich: {
            num: {
            color: '#32c78d',
            fontSize: 20,
            },
            },
        },
        },
        {
        text: '低级风险' + '{num|' + dataLow + '}条',
        bottom: '28%',
        left: '84%',
        textAlign: 'center',
        textStyle: {
            color: '#666',
            fontSize: 20,
            fontWeight: 'normal',
            textAlign: 'center',
            rich: {
            num: {
            color: '#4cb9cd',
            fontSize: 20,
            },
            },
        },
        },
        ],
        graphic: [
        {
        type: 'text',
        top: '49%',
        left: '12%',
        style: {
            text: perHigh,
            font: '30px "microsoft yahei"',
            textAlign: 'center',
            fill: '#4d71df',
        },
        },
        {
        type: 'text',
        top: '49%',
        left: '47%',
        style: {
            text: perMiddle,
            font: '30px "microsoft yahei"',
            textAlign: 'center',
            fill: '#35c68d',
        },
        },
        {
        type: 'text',
        top: '49%',
        left: '82%',
        style: {
            text: perLow,
            font: '30px "microsoft yahei"',
            textAlign: 'center',
            fill: '#4cb9cd',
        },
        },
        ],
        tooltip: {
        show: false,
        },
        series: [
        {
        name: '高级风险',
        type: 'pie',
        center: ['15%', '50%'],
        radius: ['20%', '26%'],
        startAngle: 180, //起始角度
        label: {
            show: false,
        },
        labelLine: {
            show: false,
        },
        hoverAnimation: false,
        emphasis: false,
        data: [
            {
            value: dataHigh,
            name: '',
            itemStyle: {
            normal: {
            color: '#4e73de',
            },
            },
            },
            {
            name: '',
            itemStyle: {
            emphasis: {
            color: '#e6e9f0',
            },
            normal: {
            color: '#e6e9f0',
            },
            },
            value: total - dataHigh, // 总数减去当前项数(灰色占比)
            },
        ],
        },
        {
        name: '中级风险',
        type: 'pie',
        center: ['50%', '50%'],
        radius: ['20%', '26%'],
        startAngle: 180, //起始角度
        label: {
            show: false,
        },
        labelLine: {
            show: false,
        },
        hoverAnimation: false,
        data: [
            {
            value: dataMiddle,
            name: '',
            itemStyle: {
            normal: {
            color: '#35c68d',
            },
            },
            },
            {
            name: '',
            itemStyle: {
            emphasis: {
            color: '#e6e9f0',
            },
            normal: {
            color: '#e6e9f0',
            },
            },
            value: total - dataMiddle, // 总数减去当前项数(灰色占比)
            },
        ],
        },
        {
        name: '低级风险',
        type: 'pie',
        center: ['85%', '50%'],
        radius: ['20%', '26%'],
        startAngle: 180, //起始角度
        label: {
            show: false,
        },
        labelLine: {
            show: false,
        },
        hoverAnimation: false,
        data: [
            {
            value: dataLow,
            name: '',
            itemStyle: {
            normal: {
            color: 'red',
            },
            },
            },
            {
            name: '',
            itemStyle: {
            emphasis: {
            color: '#e6e9f0',
            },
            normal: {
            color: '#e6e9f0',
            },
            },
            value: total - dataLow, // 总数减去当前项数(灰色占比)
            },
        ],
        },
        ],
        };
       return option;
     },
   },
   methods: {
    watchAllIntro(e) {
      const obj = e.currentTarget;
      const operateObj = obj.getElementsByClassName("operateCon")[0];
      const showIntroConObj = obj.parentNode.nextSibling;
    //   if (showIntroConObj.classList.contains("activeIntro")) {
    //     showIntroConObj.classList.remove("activeIntro");
    //   } else {
    //     showIntroConObj.classList.add("activeIntro");
    //   }
      if (obj.classList.contains("activeWatch")) {
        obj.classList.remove("activeWatch");
        operateObj.innerHTML = "展开全部";
      } else {
        obj.classList.add("activeWatch");
        operateObj.innerHTML = "收起全部";
      }


      var contant = obj.parentNode.nextSibling;
        let height = contant.getBoundingClientRect().height; //获取页面元素的当前高度
        if (height) {
          // 关闭时
          
          contant.style.height = height + "px";
          let f = document.body.offsetHeight; //强制相应dom重绘，使最新的样式得到应用
          contant.style.height = "0px";
        //   contant.style.display = 'none'
        } else {
        //   contant.style.display = 'block'  
          contant.style.height = "auto";
          height = contant.getBoundingClientRect().height;
          contant.style.height = "0";
          let f = document.body.offsetHeight;
          contant.style.height = height + "px";
          
        }

    },
   }
}
</script>
<style scoped lang="scss">
.serviceIndexCon{
  height: 100%;
  .serviceIndexContent{
    padding:10px;
    height:calc(100% - 48px);
    .tabBox{
       display: flex;
       justify-content: space-between;
      .showOrHideIcon {
        display: inline-block;
        transition: all 0.3s;
        -moz-transition: all 0.3s;
        -webkit-transition: all 0.3s;
        -o-transition: all 0.3s;
        margin-right: 7px;
      }

      .activeWatch {
        .showOrHideIcon {
          margin-right: 7px;
          -webkit-transform: rotate(180deg);
          -moz-transform: rotate(180deg);
          -o-transform: rotate(180deg);
          -ms-transform: rotate(180deg);
          transform: rotate(180deg);
        }
      }
    }
    .activeIntro {
      display: none;
    }
    .tabContent {
      transition: all 0.5s; // 动画效果
      position: relative;
      height:0;
      overflow: hidden;
     .tabContentBox{
      max-height: 100px;
      overflow-y: auto;
     }
    }
  }
}
.pieChart{
  width:100%;
  height:500px;
}
</style>
