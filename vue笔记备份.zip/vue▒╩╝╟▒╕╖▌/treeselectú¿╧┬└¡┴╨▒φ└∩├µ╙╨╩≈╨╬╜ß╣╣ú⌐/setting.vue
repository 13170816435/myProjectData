<template>
  <div class="params">
    <Breadcrumb :breadCrumbs="['系统管理', '参数设置']" />
    <div class="container">
      <div class="search-bar">
        <!-- <div class="fl">
          <span class="search-bar-label fl">参数模块：</span>
          <el-select
            v-model="searchData.paramModules"
            class="ele-select_32 width_200_select"
            placeholder="请选择"
            style="width:180px"
          >
            <el-option value="">全部</el-option>
            <el-option
              v-for="(item,index) in paramModuleArr"
              :key="index"
              :label="item.name"
              :value="item.value"
            ></el-option>
          </el-select>
        </div> -->
        <!-- <div class="fl">
          <span class="search-bar-label fl">参数名称：</span>
          <el-input class="width_200_input fl" v-on:keyup.enter.native=getParamList() v-model="searchData.name" placeholder="请输入名称关键字"></el-input>
        </div>
        <div class="fl ml10">
          <el-button class="search-bar-btn bg_0a clr_ff" @click=getParamList>查询</el-button>
          <el-button class="res-bar-btn" @click="resetSearchData">重置</el-button>
        </div> -->
        <div class="tr col">
         <el-button
          class="saveSettingBtn"
          size="small"
          type="primary"
          @click="saveSet()"
        >
          <i class="iconfont icon-zhengchang mr5"></i>保存
        </el-button>
        </div>
      </div>
      <div class="table-list pageTable mt10" v-bind:class="{'noTableDataActive':noFilingClerk,'organTableData':true,'noTableData':tableData.length==0}">
        <el-table
          :data="tableData"
          v-loading="loading"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          border
          height="100%"
        >
          <el-table-column type="index" label="序号" width="60">
            <!-- <template slot-scope="scope">
              <span>{{(searchData.PageIndex - 1) * searchData.PageSize + scope.$index + 1}}</span>
            </template> -->
          </el-table-column>
          <!-- <el-table-column prop="module" label="参数模块" width="150"></el-table-column> -->
          <el-table-column prop="config_name" label="参数名称" width="160"></el-table-column>
          <el-table-column prop="config_value" label="参数值" width="500">
           <template slot-scope="scope">
<!--             <value-slot v-slot:scope.row.Render :dataInfo="scope.row"> </value-slot>-->
             <div v-if="scope.row.config_key == 'AutoPublishConfig'">
               <div class="onePeople" v-for="(value, key, index) in (scope.row.config_value)" :key="key">
                 <div class="oneClassPeople" v-if="key == 'GeneratorUser'">
                    <span class="">生产人员:</span>
                    <treeselect v-model="value.UserId" :option-label-customizer="customLabel" :options="deptList" :disable-branch-nodes="true" 
                      :clear-on-select="true"  placeholder="请选择" append-to-body>
                      <template v-slot:option-label="{ node, shouldShowCount }">
                          <div class="imgCon">
                            <img v-if="node.raw.avatar" :src="node.raw.avatar" alt="avatar" style="height: 20px; width: 20px; margin-right: 5px;">
                            {{ node.label }}
                            <span v-if="node.raw.type == 1">({{ node.raw.member_count }})</span>
                          </div>
                        </template>
                    </treeselect>
                 </div>

                 <div class="oneClassPeople" v-if="key == 'InspectionUser'">
                    <span class="">检验人员:</span>
                    <!--:disableBranchNodes="node => node.type === 1"-->
                    <treeselect v-model="value.UserId" :option-label-customizer="customLabel" :options="deptList" :disable-branch-nodes="true"
                      :clear-on-select="true" placeholder="请选择" append-to-body>
                      <template v-slot:option-label="{ node, shouldShowCount }">
                          <div class="imgCon">
                            <img v-if="node.raw.avatar" :src="node.raw.avatar" alt="avatar" style="height: 20px; width: 20px; margin-right: 5px;">
                            {{ node.label }}
                            <span v-if="node.raw.type == 1">({{ node.raw.member_count }})</span>
                          </div>
                        </template>
                    </treeselect>
                 </div>

                 <div class="oneClassPeople" v-if="key == 'ReleaseUser'">
                    <span class="">放行人员:</span>
                    <!--:normalizer="my_normalizer"   :disable-branch-nodes="true" 代表只能选择人(子节点) 不能选择部门(父节点)-->
                    <treeselect v-model="value.UserId" :option-label-customizer="customLabel" :options="deptList" :disable-branch-nodes="true"
                      :clear-on-select="true"  placeholder="请选择"  append-to-body>
                      <template v-slot:option-label="{ node, shouldShowCount }">
                          <div class="imgCon">
                            <img v-if="node.raw.avatar" :src="node.raw.avatar" alt="avatar" style="height: 20px; width: 20px; margin-right: 5px;">
                            {{ node.label }}
                            <span v-if="node.raw.type == 1">({{ node.raw.member_count }})</span>
                          </div>
                        </template>
                    </treeselect>
                 </div>
                 
               </div>
             </div>
             <!-- 文本输入框-->
             <div v-if="scope.row.render === 'Text'">
               <el-input v-model="scope.row.value" class='width_240_input' placeholder=""></el-input>
             </div>
             <!-- 数字输入框-->
             <div v-if="scope.row.render === 'Number'">
               <el-input type="number" v-model="scope.row.value" class='width_240_input' placeholder=""></el-input>
             </div>
             <!-- 日期-->
             <div v-if="false">
               <el-date-picker
                 v-model="scope.row.value"
                 type="date"
                 placeholder="选择日期">
               </el-date-picker>
             </div>
             <!-- 日期时间-->
             <div v-if="false">
               <el-date-picker
                 v-model="scope.row.value"
                 type="datetime"
                 placeholder="选择日期时间">
               </el-date-picker>
             </div>
             <!-- switch开关-->
             <div v-if="scope.row.render === 'Switch'">
               <el-switch v-model="scope.row.value"></el-switch>
             </div>

             <!-- radio关和文本框（用户初始化密码）-->
             <div v-if="scope.row.render === 'textAndRadio'" class="textAndRadioDiv">
               <!-- <el-switch v-model="scope.row.options[0].value" active-color="#ed6481"></el-switch> -->
               <el-radio-group v-model="scope.row.options[0].value" class="passwordRadioGruop">
                <el-radio v-for="(item, index) in scope.row.options[0].options" :key="index" :label="item.value">{{item.name}}</el-radio>
              </el-radio-group>
               <el-input v-if="scope.row.options[0].value == '2'" v-model="scope.row.options[1].value" class='passwordInput width_160_input ml15' placeholder=""></el-input>
             </div>
             <!-- 多选框-->

             <!-- 单选按钮-->
             <div v-if="scope.row.render === 'RadioBox'">
               <div>
                 <el-radio-group v-model="scope.row.value">
                   <el-radio v-for="(item, index) in scope.row.options" :key="index" :label="item.value">{{item.name}}</el-radio>
                 </el-radio-group>
               </div>
             </div>
           </template>
          </el-table-column>
          <el-table-column prop="description" label="参数说明">
            <template slot-scope="scope">
              <div class="paramDesc">
                <span v-html="$replaceRN(scope.row.description)"></span>
              </div>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="pageDiv" v-if="false">
        <pagination-tool :total="totalPage" :page.sync="searchData.PageIndex" :limit.sync="searchData.PageSize" @pagination="getParamList"/>
      </div>
    </div>
  </div>
</template>

<script>
import Breadcrumb from "@/components/common/Breadcrumb";
import PaginationTool from '@/components/common/PaginationTool' // 分页
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import { addSetting, editSetting, deleteSetting, getSystemSetList, getOrganizationalData, updateSystemOneSet } from '@/api/devops'
export default {
  components: {
    Breadcrumb,
    PaginationTool,
    Treeselect
  },
  data () {
    return {
      sid: '',
      value: '',
      loading: true,
      value1: '',
      checked: false,
      checked2: false,
      noFilingClerk: true, // 导入后台有没有列表数据
      currentPage: 1,
      CooperationsDetail: [],
      newCooperationsDetail: [],
      secondLoginMethod: {},
      two_factor_authentication_global_enabledObj: {},
      paramList: [],
      totalPage: 1,
      searchData: {
        name: ''
      },
      paramModuleArr: [], // 参数模块
      getTableData: [],
      allow_members: [],
      allPeopleObj: {},
      deptList: [],
      tableData: [],
    }
  },
  methods: {
    // 动态设置哪些节点不能点击
    my_normalizer(node) {
      return {
        id: node.id,
        label: node.label,
        children: node.children,
        //isDisabled: node.type == 2,
      };
    },
    resetSearchData () {
      this.searchData = {
        name: ''
      }
      this.getParamList()
    },
    // 处理选择的下载人员信息 和 通知人员信息
    forEachChildren (userId,children,dealType) {
      const self = this
      if (children && children.length != 0) {
        children.forEach((item) => {
          if (item.id == userId ) {
            if (item.type == 2) {
              self.allPeopleObj[dealType].UserId = item.id
              self.allPeopleObj[dealType].UserName = item.label
            }
          } else {
            self.forEachChildren(userId,item.children,dealType)
          }
        })
      }
    },
    dealPeopleInfor (allPeopleObj) {
      const self = this
      self.allPeopleObj = JSON.parse(JSON.stringify(allPeopleObj))
      // allPeopleObj 为 生产人员 检验人员 放行人员的信息对象
      for (let key in allPeopleObj) {
        self.forEachChildren(allPeopleObj[key].UserId,self.deptList,key)
      }
    },
    // 保存设置
    async saveSet () {
      const self = this
      const parmas = []
      self.tableData.forEach(item => {
        if (item.config_key == "AutoPublishConfig") {
          self.dealPeopleInfor(item.config_value)
        }
      })
      self.tableData.forEach(item => {
        let obj = {
          id: item.id,
          config_name: item.config_name,
          config_key: item.config_key,
          config_value: JSON.stringify(self.allPeopleObj)
        }
        parmas.push(obj)
      })
      const res = await updateSystemOneSet(parmas)
      if (res.code === 0) {
        self.$message({ message: '保存参数配置成功', type: 'success' })
        self.saveDisabled = false
        self.getParamList()
      } else {
        self.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    customLabel({ node: { label, avatar } }) {
      return {
        label,
        avatar: avatar || 'default_avatar.jpg' // default avatar if not provided
      };
    },
    HandleCustomMatcher(node, Delta) {
      // 文字，从别处复制而来，清除自带样式，转为纯文本
      if (node.src && node.src.indexOf("data:image/png") > -1) {
        Delta.ops = [];
        return Delta;
      }
      let ops = [];
      Delta.ops.forEach((op) => {
        if (op.insert && typeof op.insert === "string") {
          ops.push({
            insert: op.insert,
          });
        } else if (op.insert && typeof op.insert.image === "string") {
          ops.push({
            insert: op.insert,
          });
        }
      });
      Delta.ops = ops;
      return Delta;
    },
    // 获取组织架构数据
    async beganGetOrganizationalData () {
      const res = await getOrganizationalData({ tenancy_type: 6})
      if (res.code == 0) {
        this.deptList = res.data
      } else {
        this.$message.error(res.msg);
      }
    },
    // 获取 参数 列表
    async getParamList () {
      const self = this
      const param = {
        name: self.searchData.name
      }
      self.tableData = []
      self.secondLoginMethod = {}
      const res = await getSystemSetList(param)
      
      if (res.code === 0) {
        self.loading = false
        self.paramList = JSON.parse(JSON.stringify(res.data))
        if (res.data.length != 0) {
          self.paramList.forEach(item => {
            item.config_value = JSON.parse(item.config_value)
            // 发布时 人员设置  特殊处理
            if (item.config_key == 'AutoPublishConfig') {
              for (let key in item.config_value) {
                if (item.config_value[key].UserId == '0') {
                  self.$set(item.config_value[key],'UserId',null)
                }
              }
              self.beganGetOrganizationalData()
              self.tableData.push(item)
            } else { // 其它参数
              self.tableData.push(item)
            }
          })
        }
      } else {
        self.loading = false
        self.$message({ message: `${res.msg}`, type: 'error' })
      }
    }
  },
  mounted () {
    // 获取参数列表
    this.getParamList()
  }
}
</script>
<style lang="less" scoped>
.back:hover{
  color: rgba(10, 112, 176, 1)
}
.params{
  height:100%;
}
.container {
  background: #fff;
  padding: 10px 15px;
  height:calc(100% - 46px);
  .border{
    border:1px solid rgba(220, 223, 230, 1);
  }
  .saveSettingBtn{
    background:#E6A23C;
    border-color:#E6A23C;
  }
  .pageTable {
    height:calc(100% - 42px);
    ::v-deep .el-table__body-wrapper{
      height:calc(100% - 40px);
      overflow-y: auto;
      overflow-x:hidden;
    }
  }
  .search-bar {
    line-height: 32px;
    height: 32px;
    .search-bar-btn {
      padding: 0px 13px;
      height: 32px;
      line-height: 32px;
      border-radius: 3px;
      border: none;
      cursor: pointer;
    }
    .res-bar-btn{
      padding: 0px 13px;
      height: 32px;
      line-height: 32px;
      border-radius: 3px;
      border: 1px solid #ddd;
      cursor: pointer;
      color: #606266;
    }
  .regist-btn{
    width: 60px;
    height:32px;
    line-height: 32px;
    padding: 0px;
    background:rgba(10,112,176,1);
    border:1px solid rgba(10, 112, 176, 1);
    border-radius:4px;
    color: #fff;
    margin-right: 100px;
  }
  .clr_ff9{
    color:#FF9A50;
  }
  .uploadimg{
    width: 320px;
    height: 140px;
  }
}
}
.paramDesc {
  font-size: 15px;
  color: #E6A23C;
  line-height: 20px;
}
.width_160_input{
  width:160px;
}
.textAndRadioDiv{
  position: relative;
  height: 54px;
  .passwordInput{
    position: absolute;
    bottom:0px;
    left:100px;
  }
}
::v-deep .passwordRadioGruop{
  .el-radio{
    display: block;
  }
  .el-radio:last-child{
    margin-top:15px;
  }
}
.oneClassPeople{
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 10px;
  position: relative;
  ::v-deep .vue-treeselect{
    flex:1;
    margin-left:10px;
  }
}
</style>