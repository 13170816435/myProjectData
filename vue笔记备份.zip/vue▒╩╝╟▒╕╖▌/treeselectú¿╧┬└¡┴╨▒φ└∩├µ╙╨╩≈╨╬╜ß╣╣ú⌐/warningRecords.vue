<template>
  <div class="warnRecordCon">
    <div class="warnRecordSearch">
      <div class="warnRecordSearchForm">
        <el-date-picker
          @change="search"
          class="chooseIntervalsPick searchTimePicker"
          v-model="timer"
          type="daterange"
          align="right"
          value-format="yyyy-MM-dd"
          unlink-panels
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :picker-options="pickerOptions"
        ></el-date-picker>
        
        <div class="warnPeopleSearch">
          <!--:normalizer="my_normalizer"   :disable-branch-nodes="true" 代表只能选择人(子节点) 不能选择部门(父节点)-->
          <treeselect v-model="searchWarnParam.warn_user_id" @input="search" :option-label-customizer="customLabel" :options="deptList" :disable-branch-nodes="true"
            :clear-on-select="true" placeholder="预警人" >
             <template v-slot:option-label="{ node, shouldShowCount }">
                <div class="imgCon">
                  <img v-if="node.raw.avatar" :src="node.raw.avatar" alt="avatar" style="height: 20px; width: 20px; margin-right: 5px;">
                  {{ node.label }}
                  <span v-if="node.raw.type == 1">({{ node.raw.member_count }})</span>
                </div>
              </template>
          </treeselect>
        </div>
        

        <el-select
          class="w200 ml10"
          size="small"
          placeholder="所属产品"
          v-model="searchWarnParam.product_id"
          @change="changeProduct"
          filterable
          clearable
        >
          <el-option
            v-for="(item, index) in productList"
            :key="index"
            :label="item.name"
            :value="item.id"
          ></el-option>
        </el-select>

        <el-select
          class="w200 ml10"
          size="small"
          placeholder="发布记录"
          @change="search"
          v-model="searchWarnParam.zentao_project_version_id"
          filterable
          clearable
        >
          <el-option
            v-for="(item, index) in publishRecordList"
            :key="index"
            :label="item.zentao_project_name"
            :value="item.zentao_project_id"
          ></el-option>
        </el-select>
        <!-- <el-button size="small" type="primary" @click="beaganGetWarnList"
          >查询</el-button
        >
        <el-button size="small" type="plain" @click="reset">重置</el-button> -->
      </div>
      <div class="operateBtnCon">
        <el-button
          class="warningBtn"
          size="small"
          type="warning"
          @click="addImageWarn()"
        >
          <i class="iconfont mr5">&#xe99e;</i>预警
        </el-button>
      </div>
    </div>
    <div class="downloadTableCon">
      <div class="downloadTable" :class="{ noTableData: warnList.length == 0 }">
        <el-table
          :data="warnList"
          class="downloadTable"
          height="100%"
          border
          stripe
        >
          <el-table-column type="index" width="50" label="序">
            <template slot-scope="scope">
                <span>{{
                  (searchWarnParam.page_index - 1) *
                    searchWarnParam.page_size +
                  scope.$index +
                  1
                }}</span>
              </template>
          </el-table-column>
          <el-table-column prop="servicePort" label="操作" width="100">
            <template slot-scope="scope">
              <div class="serviceOperate">
                <span class="updateServe" @click="editWarn(scope.row)">编辑</span>
                <span class="updateServe pl10" @click="gotoWarnDetail(scope.row)">查看</span>
              </div>
            </template>
          </el-table-column>
          <el-table-column
            prop="created_by"
            label="预警人"
            width="90"
            show-overflow-tooltip
          >
          </el-table-column>
          <el-table-column
            prop="created_time"
            label="预警时间"
            width="180"
            show-overflow-tooltip
          >
          </el-table-column>
          <el-table-column
            prop="product_name"
            label="所属产品"
            width="200"
            show-overflow-tooltip
          >
          </el-table-column>
          <el-table-column
            prop="zentao_project_name"
            label="预警产品"
            width="180"
            show-overflow-tooltip
          ></el-table-column>
          <el-table-column
            prop="risk_issue"
            label="问题及风险"
            width="180"
            show-overflow-tooltip
          ></el-table-column>
          <el-table-column
            prop="handling_method"
            label="处理方法及注意事项"
            show-overflow-tooltip
          ></el-table-column>
        </el-table>
      </div>
       <div class="ba noBorderTop">
          <pagination-tool
            :total="totalWarn"
            :page.sync="searchWarnParam.page_index"
            :limit.sync="searchWarnParam.page_size"
            @pagination="beaganGetWarnList"
          />
       </div>
    </div>
    <!-- 镜像预警 -->
    <el-drawer
      :size="800"
      :modal="false"
      :visible.sync="showImageWarnAlert"
      :show-close="false"
      :withHeader="false"
      :direction="direction"
      :before-close="handleClose"
    >
      <addImageWarn
        ref="addImageWarn"
        :key="addImageWarnKey"
        :isUpdate="isUpdate"
        :productList="productList"
        @refreshList="refreshList"
        @closeFn="closeImageWarnFn"
      ></addImageWarn>
    </el-drawer>
    <!-- 镜像预警详情 -->
    <el-drawer
      :size="800"
      :modal="false"
      :visible.sync="showImageWarnDetailAlert"
      :show-close="false"
      :withHeader="false"
      :direction="direction"
      :before-close="handleClose"
    >
      <imageWarnDetail
        ref="imageWarnDetail"
        @editWarn="editWarn"
        @closeFn="closeImageWarnDetailFn"
      ></imageWarnDetail>
    </el-drawer>
  </div>
</template>
<script>
import addImageWarn from "./components/addImageWarn"
import imageWarnDetail from "./components/imageWarnDetail"
import PaginationTool from "@/components/common/PaginationTool"
import moment from "moment";
import Treeselect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import {
  getAllProduct,
  getAllProductMicroserviceList,
} from "@/api/productManage";
import { getWarnList, getPublishRecordListFn, getWarnDetail,addWarn,editdWarn } from "@/api/formalLibrary";
import { getOrganizationalData } from "@/api/devops";
export default {
  components: {
    addImageWarn,
    imageWarnDetail,
    PaginationTool,
    Treeselect,
  },
  data() {
    return {
      timer: [],
      warnDetailObj: {},
      addImageWarnKey: 0,
      pickerOptions: {
        shortcuts: [
          {
            text: "今天",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              // start.setTime(start.getTime() - 3600 * 1000 * 24 * 6);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近一周",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 6);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近一个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 29);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近三个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 89);
              picker.$emit("pick", [start, end]);
            },
          },
        ],
      },
      productList: [],
      publishRecordList : [],
      deptList: [],
      searchWarnParam: {
        start_time: "",
        end_time: "",
        warn_user_id: null,
        product_id: "",
        zentao_project_version_id: "",
        page_index: 1,
        page_size: 20,
      },
      warnList: [
        // {
        //   id: 123,
        //   states:1,
        //   name: '警告记录1'
        // }
      ],
      totalWarn: 0,
      showImageWarnAlert: false,
      direction: "rtl",
      showImageWarnDetailAlert: false,
      showWarnDealAlert: false,
      isUpdate:false,
    };
  },
  // watch: {
  //   'searchWarnParam.warn_user_id'(val) {
  //     this.beaganGetWarnList()
  //   },
  // },
  methods: {
    customLabel({ node: { label, avatar } }) {
      return {
        label,
        avatar: avatar || 'default_avatar.jpg' // default avatar if not provided
      };
    },
    handleClose(done) {
      done();
    },
    closeImageWarnFn () {
      this.showImageWarnAlert = false
    },
    closeImageWarnDetailFn () {
      this.showImageWarnDetailAlert = false
    },
    refreshList () {
      this.beaganGetWarnList()
    },
    // 添加预警
    addImageWarn () {
      const self = this
      self.isUpdate = false
      self.showImageWarnAlert = true
      self.addImageWarnKey++
      self.$nextTick(() => {
        self.$refs.addImageWarn.initData(null,'addWarn');
      });
    },
    // 获取所有的产品
    async beganGetAllProduct() {
      const res = await getAllProduct();
      if (res.code == 0) {
        this.productList = res.data;
      } else {
        this.$message.error(res.msg);
      }
    },
    // 获取某个产品下的发布记录
    async changeProduct (product_id) {
      this.search()
      const res = await getPublishRecordListFn({
        product_id: product_id,
      });
      if (res.code == 0) {
        this.publishRecordList = res.data;
      } else {
        this.$message.error(res.msg);
      }
    },
    // 获取组织架构数据
    async beganGetOrganizationalData () {
      const res = await getOrganizationalData({ tenancy_type: 6})
      if (res.code == 0) {
        this.deptList = res.data
      } else {
        this.$message.error(res.msg);
      }
    },
    // 重置
    reset() {
      this.searchWarnParam = {
        start_time: "",
        end_time: "",
        product_id: "",
        microservice_id: "",
        version: "",
        key_words: "",
        page_index: 1,
        page_size: 20,
      };
    },
    // 搜索
    search() {
      this.searchWarnParam.page_index = 1;
      this.searchWarnParam.page_size = 20;
      if (this.timer && this.timer.length !== 0) {
        this.searchWarnParam.start_time = this.timer[0];
        this.searchWarnParam.end_time = this.timer[1];
      } else {
        this.searchWarnParam.start_time = "";
        this.searchWarnParam.end_time = "";
      }
      this.beaganGetWarnList();
    },
   // 查看警告详情
    gotoWarnDetail(item) {
      const self = this
      // var path = process.env.NODE_ENV === "development" ? "/" : "/PRMS/";
      // self.$router.push({ path: `${path}formalLibrary/warningRecordsDetail`,query: {id: item.id} });
      self.showImageWarnAlert = false
      self.showImageWarnDetailAlert = true
      self.$nextTick(() => {
        self.$refs.imageWarnDetail.initData(item.warning_id);
      });
    },
    // 获取预警详情
    async beganGetWarnDetail(warnId) {
      const res = await getWarnDetail({
        id: warnId,
      });
      if (res.code == 0) {
        this.warnDetailObj = res.data;
      } else {
        this.$message.error(res.msg);
      }
    },
    // 编辑警告详情
    async editWarn (item) {
      const self = this
      self.showImageWarnDetailAlert = false
      self.showImageWarnAlert = true
      self.isUpdate = true
      await self.beganGetWarnDetail(item.warning_id)
      self.$nextTick(() => {
        self.$refs.addImageWarn.initData(self.warnDetailObj);
      });
    },
    // 获取警告记录列表
    async beaganGetWarnList() {
      const res = await getWarnList(this.searchWarnParam);
      if (res.code == 0) {
        this.warnList = res.data;
        if (res.page) {
          this.totalWarn = res.page.total_count;
        }
      } else {
        this.$message.error(res.msg);
      }
    },
    // 初始化查询条件里面的时间
    initSearchTime() {
      this.timer = [];
      // 获取当前时间
      const now = moment();
      // 生产日期默认为当天
      this.searchWarnParam.end_time = now.format("YYYY-MM-DD");
      // 初始化2个月前的时间
      const sevenDaysAgo = now.subtract(2, "months");
      this.searchWarnParam.start_time = sevenDaysAgo.format("YYYY-MM-DD");
      this.timer[0] = this.searchWarnParam.start_time;
      this.timer[1] = this.searchWarnParam.end_time;
    },
  },
  mounted() {
    this.initSearchTime()
    this.beganGetAllProduct()
    this.beganGetOrganizationalData();
    this.beaganGetWarnList();
  },
};
</script>
<style lang="less" scoped>
.warnRecordCon {
  height: 100%;
  padding: 0 10px;
  .warnRecordSearch {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 10px 0px;
    .warnRecordSearchForm {
      display: flex;
      .formLabel {
        font-size: 14px;
        color: #303133;
      }
      .warnPeopleSearch{
        width:200px;
        margin-left:10px;
        ::v-deep .vue-treeselect__control{
          height: 32px;
        }
        ::v-deep .vue-treeselect__placeholder, .vue-treeselect__single-value {
          line-height: 30px;
        }
      }
      .w220 {
        width: 220px;
      }
    }
  }
  ::v-deep .downloadTableCon {
    height: calc(100% - 110px);
    .downloadTable {
      height: calc(100% - 48px);
    }
    .el-table__body-wrapper {
      height: calc(100% - 40px);
      overflow-y: auto;
    }
  }
}
.warningBtn{
  background:#FF6F6F;
  border-color:#FF6F6F;
}
.updateServe {
  color: #0a70b0;
  cursor: pointer;
}
</style>