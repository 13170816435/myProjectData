<template>
  <div class="addProductCon">
     <div class="productItem">
        <span class="productItemLabel"><i class="dev-iconfont clr_red">&#xe6c5;</i>文件夹名称：</span>
        <el-input class="w340" size="small" v-model="addFolderParams.name"></el-input>
     </div>
     <div class="productItem">
        <span class="productItemLabel">所属目录：</span>
        <treeSelect
        v-model="value"
        :data="list"
        style="width: 340px"
      ></treeSelect>
     </div>
  </div>
</template>
<script>
import treeSelect from './treeSelect'
export default {
  props:{
    addFolderParams: Object,
  },
  components: {
    treeSelect
  },
  data () {
    return {
      list: [{
                label: '系统',
                id: 1,
                children: [
                    { label: '用户', id: 2 },
                    { label: '用户组', id: 3 },
                    { label: '角色', id: 4 },
                    { label: '菜单', id: 5 },
                    { label: '组织架构', id: 6 }
                ]
            },
            {
                label: '商品',
                id: 7,
                children: [
                    { label: '列表', id: 8 },
                    { label: '添加', id: 9 },
                    { label: '修改', id: 10 },
                    { label: '删除', id: 11 },
                    { label: '商品分类', id: 12 },
                    { label: '分类修改', id: 13 }
                ]
            }],
        value: '',
        // value: 1,
    }
  } 
}
</script>
<style lang="less" scoped>
.addProductCon{
//   padding:20px 0px;
  .productItem{
    margin-bottom:12px;
    display: flex;
    align-items: center;
    .productItemLabel{
      width:110px;
      text-align: right;
      font-size: 14px;
      color: #303133;
      line-height: 20px;
    }
    .w340{
       width:340px;
    }
  }
}
::v-deep .selectTree {
  height: 32px;
  .el-input__inner {
    height: 32px;
    line-height: 32px;
  }
  .el-input__icon{
    line-height: 32px;
  }
}
</style>