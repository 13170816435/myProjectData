<template>
    <div class="imageContainer">
      <!--提供给业务系统-->
      <el-dialog
      title="病例导出申请"
      class="caseExportApplyAlert"
      :visible.sync="showApplyCaseExportAlert"
      width="880px"
      :modal="false"
      :close-on-click-modal="false"
      append-to-body
      modal-class="caseExportApplyAlert"
      v-dialogDrag
    >
     <div class="applyCaseExport" ref="applyCaseExport">
       <div class="caseImport">
         <span class="statuLabel">总量：<span class="caseNum">{{exportParam.items.length}}</span></span>
         <el-input
          size="small"
          class="productSearchInput"
          v-model="searchCaseParam.keywords"
          v-on:keyup.enter.native="searchCaseList()"
          placeholder="全局检索"
          style="width:260px;"
         >
          <i slot="suffix" class="el-icon-search" @click.stop="searchCaseList()"></i>
        </el-input>
       </div>
       <!----->
       <div
          class="allCase clear"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          v-bind:class="{ noTableData: exportParam.items.length == 0 }"
        >
          <el-table
            :data="exportParam.items"
            border
            stripe
            height="100%"
            ref="caseTable"
            highlight-current-row
            header-row-class-name="strong"
            :row-key="rowKey"
          >
            <el-table-column
              fixed="left"
              align="center"
              type="index"
              label="序号"
              width="55"
            >
            </el-table-column>
            <el-table-column label="操作" width="60" fixed="left">
              <template slot-scope="scope">
                <span class="clr_da pointer" @click="removeCase(scope.row,scope.$index)">移除</span>
              </template>
            </el-table-column>
            <el-table-column label="查看" width="90" fixed="left">
              <template slot-scope="scope">
                <el-popover popper-class="strategyTipPopover" placement="right" width="350" trigger="hover">
                  <div class="pt5 pl10 pr10 pb5 lh24">
                    <div>影像所见</div>
                    <div>（1）范围内的数据，保留追溯记录。</div>
                    <div>影像诊断</div>
                    <div>2、【数据访问追溯有效期】，选择时间范围后，只保留所配置时间范围内的【数据访问】记录</div>
                    <div>注意事项</div>
                    <div>【数据访问追溯有效期】，选择时间范围后，只保留所配置时间范围内的【数据访问】记录</div>
                  </div>
                  
                  <span slot="reference" class="clr_0a pointer">报告</span>
                </el-popover>

                <span class="clr_0a pointer pl10" @click="watchImg(scope.row,scope.$index)">影像</span>
              </template>
            </el-table-column>
            
          <el-table-column
            label="检查号"
            prop="accession_number"
            width="100"
            show-overflow-tooltip>
          </el-table-column>

          <el-table-column
            label="病例号"
            prop="med_rec_no"
            width="100"
            show-overflow-tooltip
          >
          </el-table-column>

          <el-table-column
            label="患者姓名"
            prop="patient_name"
            width="90"
            show-overflow-tooltip
          >
          </el-table-column>

          <el-table-column label="检查科室" prop="observations_depart_name" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="检查项目" prop="exam_item" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="项目分类" prop="exam_item_category" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="患者类型" prop="patient_type" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="检查时间" prop="exam_time" width="100" show-overflow-tooltip>
            <template slot-scope="scope">
               <span>{{ scope.row.observation_start_time }}~{{ scope.row.observation_end_time }}</span>
            </template>
          </el-table-column>
          <el-table-column label="申请科室" prop="request_dept_name" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="检查机构" prop="observations_org_name" width="100" show-overflow-tooltip></el-table-column>
          <el-table-column label="审批" prop="name"  show-overflow-tooltip></el-table-column>
         </el-table>
        </div>

       <div class="checkTitBox">
         <span class="titleIcon"></span>
         <span class="titleText">审批人</span>
       </div>

       <div class="checkPeopleCon">
         <div class="allPeople">
           <div class="onePeople" :class="{'thirdPeople':index == 3}" v-for="(item,index) in checkPeopleArr" :key="index" v-if="index<3">
             <img src="@/assets/images/dataStorage/checkUser.png" alt="">
             <span class="checkUserName">赵禹州{{ index }}</span>
           </div>
           <!-- 第一行显示3个   从第4个开始换行显示--->
           <br/>
           <div class="onePeople"  v-for="(item,index) in checkPeopleArr" :key="index" v-if="index>2">
             <img src="@/assets/images/dataStorage/checkUser.png" alt="">
             <span class="checkUserName">赵禹州{{ index }}</span>
           </div>

         </div>
         <span class="showOrHide" @click="watchAllCheckPeople($event)" v-if="checkPeopleArr.length>3">
           <span class="operateCon">展开其他</span>
           <i class="iconfont showOrHideIcon iconshuangjiantou-you"></i>
          </span>
         
       </div>

       <div class="checkTitBox">
         <span class="titleIcon"></span>
         <span class="titleText">导出原因<i class="iconfont iconbitian mustIcon"></i></span>
       </div>
       <div class="reasonBox">
         <el-select
            filterable
            clearable
            v-model="exportParam.reason_code"
            placeholder=""
            class="ele-select_32"
            style="width:300px"
          >
            <el-option
              v-for="(item,index) in reasonArr"
              :key="index"
              :label="item.name"
              :value="item.value"
              ></el-option>
          </el-select>

          <el-input class=""
            style="width:320px;margin-left:10px;"
            v-model="exportParam.reason"
            placeholder="请输入其他原因">
          </el-input>
          <el-button size="small" class="ml20" type="primary" @click="subCaseExport">提交申请</el-button>
          <el-button size="small" class="ml20" plain @click="showApplyCaseExportAlert = false">关闭窗口</el-button>
       </div>
     </div>

    </el-dialog>
    </div>
  </template>
  <script>
  import Vue from 'vue'
  import '../utils/directives.js'
  import { Dialog, Message,Button, Select,Option,Input,Table,TableColumn,Loading, Popover } from 'element-ui'
  import { getCaseExportReasonList, subExportApply } from "../api/user";
  Vue.prototype.$loading = Loading.service
  export default {
    name: "caseExport",
    props: {
      oneInformationObj: {
        type: Object,
      },
    },
    components: {
      elDialog: Dialog,
      elButton: Button,
      elSelect:Select,
      elOption: Option,
      elInput:Input,
      elTable: Table,
      elTableColumn: TableColumn,
      elPopover: Popover,
      Message,
      Loading,
    },
    data() {
      return {
        // 病例导出申请弹窗
        showApplyCaseExportAlert: false,
        searchCaseParam: {
          keywords: '',
        },
        checkPeopleArr: [1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,17],
        reasonArr: [],
        exportParam: {
          reason_code: '',
          reason: '',
          items: [],
        },
      };
    },
    methods: {
      showDialog(data) {
        const self = this
        console.log("调用时传过来的数据",data)
        self.exportParam.items = []
        if (data.caseExportDataArr.length != 0) {
          data.caseExportDataArr.forEach((item) => {
            let newObj = {
              id: item.id,
              business_id: '', //业务id
              business_system_id: '', //业务系统id
              business_system_type: '', //业务系统类型
              accession_number: item.accession_number,// 检查号
              study_instance_uid: '',//检查实例UID
              med_rec_no: item.med_rec_no,// 病例号
              patient_id: item.patient_id,// 患者编号
              patient_name: item.patient_name,//患者姓名
              observations_org_id: item.observations_org_id, // 检查机构id
              observations_org_name: item.observations_org_name,// 检查机构名称
              observations_depart_id: '',// 检查科室id
              observations_depart_name: item.observations_depart_name, // 检查科室名称
              exam_item: item.examination_item_name,// 检查项目
              exam_item_category:item.exam_item_category,// 项目分类
              patient_type: item.patient_type,// 患者类型
              exam_time: '',// 检查时间 observation_start_time、observation_end_time
              request_org_id: item.request_org_id,// 申请机构id
              request_org_name: item.request_org_name,//申请机构名称
              request_dept_id: '',// 申请科室id
              request_dept_name: '',// 申请科室名称
            }
            self.exportParam.items.push(newObj)
          })
        }
        self.showApplyCaseExportAlert = true;
        // self.$nextTick(() => {
        //   self.$refs.showForwardMember.oneInformationObj = JSON.parse(JSON.stringify(self.oneInformationObj))
        //   self.$refs.showForwardMember.initRequest()
        // })
      },
      handleClose () {
        this.showApplyCaseExportAlert = false;
      },
      closeDialog () {
        const self = this
        self.showApplyCaseExportAlert = false;
      },
      // 病例导出申请弹窗方法
      rowKey (row) {
        return row.id
      },
      // 移除病例
      removeCase (row,index) {
        const self = this
        this.$confirm(
            '确定移除 <span style="color: #0099ff">' +
            row.inspect_id +
            "</span> 检查吗?",
            "移除",
            {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            dangerouslyUseHTMLString: true,
            type: "warning",
            }
        )
        .then(() => {
            self.exportParam.items.forEach((item) => {
            if (item.id == row.id) {
              self.exportParam.items.splice(i,1)
            }
           })
        })
        .catch(() => {});
      },
      // 查看更多的审批人
      watchAllCheckPeople(e) {
        const obj = e.currentTarget;
        const operateObj = obj.getElementsByClassName("operateCon")[0];
        if (obj.classList.contains("activeWatch")) {
          obj.classList.remove("activeWatch");
          operateObj.innerHTML = "展开其他";
        } else {
          obj.classList.add("activeWatch");
          operateObj.innerHTML = "收起其他";
        }
        var contant = obj.previousSibling;
        let height = contant.getBoundingClientRect().height; //获取页面元素的当前高度
        if (height > 40) {
          // 关闭时
          contant.style.height = height + "px";
          let f = document.body.offsetHeight; //强制相应dom重绘，使最新的样式得到应用
          contant.style.height = "40px";
        } else {
          contant.style.height = "auto";
          height = contant.getBoundingClientRect().height;
          contant.style.height = "40px";
          let f = document.body.offsetHeight;
          contant.style.height = height + "px";
         }
        },
        // 提交导出申请
        async subCaseExport () {
          const loading = this.$loading({
            target: this.$refs.applyCaseExport,
            lock: true,
            text: "正在提交导出申请",
            spinner: 'el-icon-loading',
            background: 'rgba(255, 255, 255, 0.6)'
         })

          const res = await subExportApply(this.exportParam)
          if (res.code == 0) {
            loading.close();
            this.$message.success("导出申请成功");
          } else {
            this.$message.error(res.msg);
            loading.close();
          }
        },
        async initData () {
          await this.beganGetReasonList()
        },
        // 获取病例导出 列表
        async beganGetReasonList () {
          const res = await getCaseExportReasonList("TransmissionSecurity.RSA.PublicKey")
          if (res.code == 0) {
            console.log('调用了获取理由列表')
            this.reasonArr = res.data
          } else {
            this.$message.error(res.msg);
          }
        }
    },
    created () {
      this.initData()
    },
  };
  </script>
  <style lang="less">
  // 查看公告样式重置
  .caseExportApplyAlert {
    .el-dialog {
      border-radius: 3px;
      box-shadow: 0px 2px 20px 0 rgba(0, 0, 0, 0.1);
    }
    .el-dialog__header {
      width: 100%;
      background: #0a70b0;
      .el-dialog__close {
        // color: #909399 !important;
      }
    }
  }
    // 实现dialog可拖拽且底层可点击
    .caseExportApplyAlert {
    pointer-events: none;
    .el-dialog {
        pointer-events: auto;
    }
    .el-dialog__header{
        pointer-events: auto;
    }
    }
  </style>
  <style lang="less" scoped>
  // 病例导出申请弹窗样式
.applyCaseExport{
  padding: 0 20px 20px 20px;
  position: relative;
  .caseImport{
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 50px;
    .statuLabel {
      font-size:15px;
      color:#303133;
    }
    .caseNum{
      font-size: 15px;
      font-weight: 600;
      font-family: Arial;
    }
  }
  .allCase{
    height: 360px;
    ::v-deep .el-table__body-wrapper{
     height: calc(100% - 40px);
     overflow-x: auto;
    }
  }
  .checkTitBox{
    height: 36px;
    display: flex;
    align-items: center;
    .titleIcon{
      width: 4px;
      height: 16px;
      background: #0A70B0;
      border-radius: 2px;
      margin-right: 5px;
    }
    .titleText{
      font-weight: 700;
      font-size: 15px;
      color: #303133;
    }
  }
  .checkPeopleCon{
    padding: 0 10px;
    border-radius: 3px;
    background:rgba(245, 247, 250, 0.8);
    display: flex;
    position: relative;
    .allPeople{
      transition: all 0.5s; // 动画效果
      position: relative;
      height: 40px;
      // width: 288px;
      overflow: hidden;
    }
    .onePeople{
      display: inline-block;
      img {
        width:24px;
        margin-top:8px;
      }
      .checkUserName{
        margin-left:10px;
        font-size: 14px;
        color: #303133;
        font-weight: 700;
        white-space: nowrap;
        position: relative;
        top: -2px;
        display: inline-block;
        width: 62px;
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
      }
    }
    .thirdPeople{
      display: block;
    }
    .showOrHide{
      position: absolute;
      left: 300px;
      top: 7px;
      font-size: 14px;
      color: #0A70B0;
      cursor: pointer;
      text-decoration: underline;
    }

    .showOrHideIcon {
    display: inline-block;
    transition: all 0.3s;
    -moz-transition: all 0.3s;
    -webkit-transition: all 0.3s;
    -o-transition: all 0.3s;
    position: relative;
    top:2px;
  }

  .activeWatch {
    .showOrHideIcon {
      -webkit-transform: rotate(180deg);
      -moz-transform: rotate(180deg);
      -o-transform: rotate(180deg);
      -ms-transform: rotate(180deg);
      transform: rotate(180deg);
    }
  }
  .reasonBox{
    display: flex;
    align-items: center;
    .ml20{
      margin-left: 20px;
    }
  }
  }
}
  </style>