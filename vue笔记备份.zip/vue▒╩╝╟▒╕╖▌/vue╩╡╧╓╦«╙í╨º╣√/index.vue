<template>
  <div class="sideBar">
    <div class="titleSpan">
      <el-dropdown v-show="!opened" style="width: 135px;text-align: center;">
        <span class="el-dropdown-link over_ell" style="color:#fff;"> {{ meuName | titleFilter }}<i
            class="el-icon-arrow-down el-icon--right"></i></span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item v-for="(item,index) in MenuData" :key="index"
                            :class="{'activeMenu': currentName === item.meta.title}"
                            @click.native="meuNameChange(item.name, index, item.meta.title, item)">{{ item.meta.title }}
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <i class="fr" v-bind:class="{'el-icon-s-fold': !opened,'el-icon-s-unfold': opened}" @click="toggleOpen()"></i>
    </div>
    <el-scrollbar>
      <el-menu
          :default-active="activeMenu"
          class="el-menu-vertical-demo"
          background-color="transparent"
          text-color="#FFF"
          mode="vertical"
          :collapse-transition="false"
          :unique-opened="true"
          :collapse="opened"
          @select="handleSelect"
      >
        <sidebar-item
            :FileName="FileName"
            v-for="item in routes"
            :key="item.path"
            :item="item"
            :basePath="item.path"
        ></sidebar-item>
      </el-menu>
    </el-scrollbar>
  </div>
</template>
<script>
import SidebarItem from './SideBarItem'
import {mapGetters} from 'vuex'
import {ownMenu, fetchSystemIds, getConstants, PacsSystemId} from '@/api/commonHttp' // 请求
import Mgr from '@/utils/SecurityService'
import { waterMark } from '@/utils/waterMark'
//import { duration } from 'html2canvas/dist/types/css/property-descriptors/duration'
export default {
  components: {
    SidebarItem
  },
  computed: {
    ...mapGetters(['opened', 'usertype', 'currentPagePath']),
    activeMenu: {
      get() {
        var _path = this.$route.path
        if (_path.split('/')[2] === 'paservice' && this.currentPagePath !== '' && this.currentPagePath !== undefined) {
          _path = '/operate' + this.currentPagePath
          history.replaceState(null, document.title, _path)
        }
        if (_path === '/MedicalInstitution/AddOrgain') {
          _path = '/MedicalInstitution/InstitutionList'
        }
        if (_path === '/operate/PlatformOperation/OperateUserlist') {
          _path = '/operate/PlatformOperation'
        }
        if (_path === '/operate/systemOperate/productManagement/releaseRecord' || _path === '/operate/systemOperate/productManagement/releaseOperate') {
          _path = '/operate/systemOperate/productManagement'
        }
        return _path
      }
    }
  },
  watch: {
    currentPagePath(newVal) {

    }
  },
  data() {
    const currentName = sessionStorage.getItem('CheckMemuname')
    return {
      currentName: currentName ? currentName : '',
      routes: [],
      MenuData: [],
      FileName: '',
      meuName: '',
      systemArray: []
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.getUserinfoFn()
      this.getConstantsFn()
    })
  },
  methods: {
    handleSelect(val) {
      // if (val === 'operate') {
      //   window.location.href = ''
      // }
    },
    // 获取用户信息
    async getUserinfoFn() {
      
      let user
      if (localStorage.getItem('loginInfo')) {
        user = JSON.parse(localStorage.getItem('loginInfo'))
      } else {
        const manager = new Mgr()
        user = await manager.getRole()
      }
      var prmgroups = user.profile.prm_groups
      if (prmgroups.match(/Doctor/i)) {
        this.SystemInit()
      }
      else {
        await this.getMenu()
        // 给网页加上水印
        waterMark()
      }
    },
    async SystemInit(val) {
      return new Promise(async (resolve, reject) => {
        try {
          await this.fetchSystemIds()
          await this.getMenu()
          // 给网页加上水印
          waterMark()
          return
        } catch (err) {
          reject(err)
          return err
        }
      })
    },
    async fetchSystemIds() {
      var res = await fetchSystemIds()
      this.systemArray = res.data
      sessionStorage.setItem('systemArray', JSON.stringify(res.data))
    },
    // 子节点里面的path 是否有 "-"
    isHasSymbol (arr) {
      let newPath = ''
      for (let i = 0; i<arr.length; i++) {
        if (arr[i].path != '-') {
          newPath = arr[i].path
          break
      }
      }
      return newPath
    },
    // 菜单栏切换
    meuNameChange(name, menuindex, activetitle, menuObj) {
      // 缓存整个菜单项，以后不再新增字段缓存
      sessionStorage.setItem('currentMenuObj', JSON.stringify(menuObj))
      sessionStorage.setItem('global.system', JSON.stringify(menuObj))
      if (activetitle === sessionStorage.getItem('CheckMemuname')) { // 想同的菜单
        return
      }
      this.$store.commit('app/setUserType', name)
      var Arr = this.MenuData
      var index = 0
      Arr.forEach((item, i) => {
        if (item.name === name && menuindex === i && item.system_id == menuObj.system_id ){
          if (item.name === 'TeleeducationManagement' || item.name === 'Teleeducation') {
            sessionStorage.setItem('teachCenterId', item.service_center_id)
            sessionStorage.setItem('ChosedFileName', item.name)
          }
          this.routes = []
          this.meuName = item.meta.title
          this.routes = item.children
          this.FileName = item.path
          window.sessionStorage.setItem('FileName', this.FileName)
          window.sessionStorage.setItem('ChosedSystemName', name) // select选中菜单
          window.sessionStorage.setItem('CheckMemuname', item.meta.title) // select选中菜单name
          this.$store.commit('app/set_CheckMemuname', item.meta.title)
          // var sid = item.name === 'DepartmentSystem' ? item.system_id : ''
          // if (sid) {
          //   window.sessionStorage.setItem('lastname', sid)
          // }
          
          window.sessionStorage.setItem('lastname', item.system_id)
          if (item.name === 'serviceCenterManage') {
            window.sessionStorage.setItem('serviceCenterName', item.meta.title)
            window.sessionStorage.setItem('serviceCenterId', item.service_center_id)
          }
          // 切换远程医疗 申请医生或服务医生
          if ((name == item.name) && name === 'Telemedicine') {
            var newPath = item.children[0].path + this.isHasSymbol(item.children[0].children)
            window.location.href = configUrl.frontEndUrl + newPath
          }
          if (item.system_code) {
            window.sessionStorage.setItem('currentSystemClass', item.system_code)
          }

          if (item.path === 'quality') {
            window.sessionStorage.setItem("quality_center_id", item.quality_center_id)
            window.sessionStorage.setItem("FileName", item.path) // select选中菜单
            window.sessionStorage.setItem("ChosedSystemName", item.path) // select选中菜单
            window.location.href = configUrl.frontEndUrl + item.children[0].path + item.children[0].children[0].path + '?time=' + new Date().getTime()
            return
          }
          if (process.env.NODE_ENV === 'development') {
            if (item.children[0].path === 'operate') {
              window.open = configUrl.frontEndUrl + item.children[0].name
            } else if (item.name.toLowerCase() === 'quality' || item.name.toLowerCase() == 'dms') {
              //window.location.href = configUrl.frontEndUrl +'/quality'+ item.children[0].path
              window.location.href = configUrl.frontEndUrl + `/${item.path}` + item.children[0].path
            } else {
              window.location.href = configUrl.frontEndUrl + item.children[0].path
            }
          } else {
            if (item.name === 'serviceCenterManage') {
              var path = process.env.NODE_ENV === 'development' ? '/' : '/operate/'
              this.$router.push({path: `${path}centerSet/serviceCenterInfor`, query: {id: item.service_center_id}})
            } else if (item.name.toLowerCase() === 'quality' || item.name.toLowerCase() == 'dms') {
              // window.location.href = configUrl.frontEndUrl +'/quality'+ item.children[0].path
              window.location.href = configUrl.frontEndUrl + `/${item.path}` + item.children[0].path
            } else {
              const findDeepPath = menuItem => {
                let path = menuItem.path
                if(Array.isArray(menuItem.children)) {
                  for (let item of menuItem.children) {
                    if(item.path !== '-') {
                      path += findDeepPath(item)
                      break
                    }
                  }
                }
                return path
              }

              if (Array.isArray(item.children) && item.children.length > 0) {
                window.location.href = configUrl.frontEndUrl + findDeepPath(item.children[0])
              }
            }
          }
        }
        index = index + 1
      })
    },
    async getMenu() {
      var res = await ownMenu()
      if (!res || res.code !== 0) {
        return
      }
      var self = this
      var routePath = window.location.href.split('//')[1]  // localhost:8080/PlatformOperation/OperateUserlist
      // const isdepPath = routePath.split('/')[2]
      var isdepPath = process.env.NODE_ENV === 'development' ? routePath.split('/')[1] : routePath.split('/')[2]
      var menuNodes = res.data
      if (menuNodes.length == 0) {
        return false
      }
      menuNodes.forEach((rootNode, i) => {
        rootNode.children.forEach((node, j) => {
          if (node.is_new_form === true) { // 如果二级菜单需要打开新页面，则移除所有子节点
            node.children.length = 0
            node.children = null
          }
        })
      })
      var arr = []
      menuNodes.forEach((item, i) => {
        if (item.is_show) {
          arr.push(item)
        }
      })
      menuNodes = arr
      menuNodes.forEach((item, i) => {
        item.children.forEach(itempath => {
          if (process.env.NODE_ENV === 'development') {
            itempath.path = itempath.path.replace('/operate', '') // 路由命名不能有/operate
          }
        })
      })
      self.MenuData = menuNodes
      self.routes = menuNodes[0].children
      var FirstEnterSystem = window.sessionStorage.getItem('FirstEnterSystem')
      var _name = window.sessionStorage.getItem('ChosedSystemName') // 菜单name
      var _menuname = window.sessionStorage.getItem('CheckMemuname') // d当前菜单
      if (FirstEnterSystem === 'true') {
        self.MenuData.forEach((item, i) => {
          if (_name && (item.name == 'ProvinceManagement' || item.name == 'CityManagement' || item.name == 'DistrictManagement')) {// 三级管理员
            if (item.system_id === sessionStorage.getItem('lastname')) {
              self.meuName = item.meta.title
              self.routes = item.children
              sessionStorage.setItem('currentMenuObj', JSON.stringify(item))
            }
          } else {
            if (!_menuname && _name === 'CustomerManagement' && window.sessionStorage.getItem('lastname') == 0) {// 客户管理员
              isdepPath = 'CustomerManagement'
            }
            if (item.name === _name || item.name === isdepPath || (!_name && i === 0) || (!_menuname && _name === item.name) || item.name === 'institutionsManage') {
              self.FileName = item.path
              window.sessionStorage.setItem('FileName', self.FileName)
              self.meuName = item.meta.title
              self.routes = item.children
              sessionStorage.setItem('currentMenuObj', JSON.stringify(item))
            }
          }
        })
        if (!_menuname) {
          window.sessionStorage.setItem('CheckMemuname', self.meuName)
        }
        self.$store.commit('app/set_CheckMemuname', self.meuName)
        if (isdepPath === 'home') {
          self.setDefaultMenu()
        }
      } else {
        self.MenuData.forEach((item, i) => {
          if (item.name === _name || (!_name && i === 0)) {
            self.FileName = item.path
            window.sessionStorage.setItem('FileName', self.FileName)
            self.meuName = item.meta.title
            self.routes = item.children
            sessionStorage.setItem('currentMenuObj', JSON.stringify(item))
            window.sessionStorage.setItem('currentSystemClass', item.system_code)
            // 不是科室管理 默认显示第一个
            if (isdepPath !== 'DepartmentSystem') {
              self.meuName = self.MenuData[0].meta.title
            }
          }
        })
        self.setDefaultMenu()
        window.sessionStorage.setItem('FirstEnterSystem', true)
        if (!_menuname) {
          window.sessionStorage.setItem('CheckMemuname', self.meuName)
        }
        self.$store.commit('app/set_CheckMemuname', self.meuName)
      }
      if (sessionStorage.getItem('currentMenuObj')) {
        var currentMenuObj = JSON.parse(sessionStorage.getItem('currentMenuObj'))
        sessionStorage.setItem('institutionsManageId', currentMenuObj.institution_id)
        sessionStorage.setItem('lastname', currentMenuObj.system_id)
      }
    },
    setDefaultMenu() { // 加载默认地址
      console.log('MenuData',this.MenuData)
      var firstRoutePath = this.MenuData[0].children[0].path
      if (this.MenuData[0].name === 'serviceCenterManage') {
        sessionStorage.setItem('serviceCenterName', this.MenuData[0].meta.title)
        sessionStorage.setItem('serviceCenterId',this.MenuData[0].service_center_id)
        window.location.href = configUrl.frontEndUrl + this.MenuData[0].children[0].path + this.MenuData[0].children[0].children[0].path + '?id=' + this.MenuData[0].service_center_id
      } else {
        window.location.href = configUrl.frontEndUrl + firstRoutePath
      }
    },
    // 设置菜单栏面包屑
    toggleOpen() {
      this.$store.commit('app/SET_OPENED', !this.opened)
    },
    // 获取后台枚举值--设置前端基础数据
    async getConstantsFn() {
      const res = await getConstants()
      var item = {name: '全部', value: ''}
      res.tenancy_type.unshift(item)
      res.tenancy_state.unshift(item)
      res.telemed_service_type.unshift(item)
      res.user_account_ca_state.unshift(item)
      res.user_account_state.unshift(item)
      res.common_setting_type.shift()
      this.$store.commit('app/set_officeType', res.office_type) // 科室类型
      this.$store.commit('app/set_tenancyType', res.tenancy_type) // 客户类型
      this.$store.commit('app/set_tenancyState', res.tenancy_state) // 客户状态
      this.$store.commit('app/set_userAccountState', res.user_account_state) // 用户状态
      this.$store.commit('app/set_serviceList', res.telemed_service_type) // 服务列表
      this.$store.commit('app/set_caStatelist', res.user_account_ca_state) // ca证书列表
      this.$store.commit('app/set_commonSettingtype', res.common_setting_type) // 外部能力-tab列表
      this.$store.commit('app/set_meetingCompany', res.meeting_company) // 外部能力-视频会议
      this.$store.commit('app/set_smsProducer', res.sms_producer) // 外部能力-短信服务
      this.$store.commit('app/set_caProducer', res.ca_producer) // 外部能力-电子签名
      this.$store.commit('app/set_caaccounttype', res.ca_account_type) // 外部能力-cs -类型
      this.$store.commit('app/set_caType', res.ca_type) // 外部能力类型
      this.$store.commit('app/set_servicePushText', res.service_report_type) // 推送内容
      this.$store.commit('app/set_servicePushType', res.service_report_cycle) // 推送类型
      this.$store.commit('app/set_servicePushMethods', res.service_report_receiver_push_method) // 接受方式
      this.$store.commit('app/set_enumerations', res) // 所有基础数据-------------------
    }
  },
  filters: {
    titleFilter: function (value) {
      if (!value) return ''
      if (value && value.length > 7) {
        value = value.substring(0, 7) + '...'
      }
      return value
    }

  }
}
</script>
<style lang="less" scoped>
@import "~@/style/variable.less";
.titleSpan {
  height: 46px;
  line-height: 46px;
  color: #fff;
  border-bottom: 1px solid hsla(0, 0%, 100%, .3);
}

.menu-bar {
  text-align: center;
  color: #fff;
  height: 47px;
  line-height: 47px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.3);

  .iconshouqizhankai1, .iconshouqizhankai {
    float: right;
    padding-right: 20px;
    cursor: pointer;
  }
}

.el-dropdown-menu__item.activeMenu {
  color: #fff;
  background: @variable-clr-main;
}

.sideItem {
  ::v-deep .el-submenu__icon-arrow {
    font-weight: bold !important;
  }
}

.el-scrollbar {
  height: calc(100% - 47px) !important;

  ::v-deep .el-menu--collapse {
    ::v-deep .el-submenu__title {
      span {
        display: none;
      }
    }

    ::v-deep .el-submenu__icon-arrow {
      display: none;
    }
  }
}
</style>
