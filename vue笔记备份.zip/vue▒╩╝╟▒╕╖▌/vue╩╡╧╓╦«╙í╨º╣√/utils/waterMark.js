import { getSettingsMmeta } from '@/api/platform_costomer/institution'
import Mgr from '@/utils/SecurityService'

const getRadian = angle => Math.PI * angle / 180

const appConfigData = {
    fontSize: 14,
    density: {
        1: -200,
        2: -100,
        3: -500
    }
}
const webConfigData = {
    fontSize: 16,
    density: {
        1: 300,
        2: 100,
        3: -500
    }
}

const drawText = (txt, fontSize, color = '#ccc', dGap) => {
    const angle = -30 // 旋转角度
    const gap = dGap
    const gapY = 0

    const AC = txt.length * fontSize
    const AB = AC * Math.cos(-30 * Math.PI / 180)
    const BC = AC * Math.sin(-30 * Math.PI / 180)
    const clientWidth = document.documentElement.clientWidth
    const clientHeight = 2 * (Math.abs(BC) + gapY)

    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d')
    canvas.setAttribute('width', `${clientWidth}`)
    canvas.setAttribute('height', `${clientHeight}`)

    ctx.fillStyle = color
    ctx.font = `${fontSize}px serif`
    // for (let i = 0; i < 4; i++) {
    //     for (let j = 0; j < 20; j++) {
    //         ctx.save()
    //         // 横向的偏移量为  (长度 + gap) * j
    //         let translateX = Math.abs(j * (Math.abs(AB) + gap))
    //         let translateY = Math.abs((i + 1) * Math.abs(BC) - 80)
    //         if ((i + 1) % 2 === 0) {
    //             translateX += (gap + Math.abs(AB)) / 2 - 5
    //         }
    //         translateX -= 200
    //         if (i !== 0) {
    //             translateY += gapY
    //         }
    //         ctx.translate(translateX, translateY)
    //         ctx.rotate(getRadian(angle))
    //         ctx.fillText(txt, 0, 0)
    //         ctx.restore()
    //     }
    // }
    for (let i = 0; i < 2; i++) {
        for (let j = 0; j < 20; j++) {
            ctx.save()
            // 横向的偏移量为  (长度 + gap) * j
            let translateX = Math.abs(j * (Math.abs(AB) + gap))
            let translateY = Math.abs((i + 1) * Math.abs(BC)) + 10
            if ((i + 1) % 2 === 0) {
                translateX += (gap + Math.abs(AB)) / 2 - 5
            }
            // translateX -= 200
            if (i !== 0) {
                translateY += gapY
            }
            ctx.translate(translateX, translateY)
            ctx.rotate(getRadian(angle))
            ctx.fillText(txt, 0, 0)
            ctx.restore()
        }
    }
    return canvas.toDataURL()
}

export const waterMark = async function () {
    if (window.location.href.indexOf('appEducation') > -1) {
        return
    }

    const mgr = new Mgr()
    const userInfo = await mgr.getRole()
    if (!userInfo || !userInfo.profile) {
        return
    }
    const params = {
        id: userInfo.profile.tenancy_id,
    }
    const res = await getSettingsMmeta(params)
    const setData = res.data
    let isOpenWaterMask = false
    let myWaterMaskArr = []
    let otherWaterMaskArr = []
    let waterMaskColor = ''
    if (setData.length != 0) {
        setData.forEach((item) => {
            if (item.key == 'watermark_state') {
                isOpenWaterMask = item.value
            }
            if (item.key == 'watermark_info') {
                if (item.value) {
                  myWaterMaskArr = item.value
                }
                
            }
            if (item.key == 'watermark_custom_info') { // 自定义的水印内容
                if (item.value) {
                  otherWaterMaskArr = JSON.parse(item.value)
                }
                
            }
            if (item.key == 'watermark_color') {
                waterMaskColor = item.value
            }
        });
    }
    // 没有开启，直接返回
    if (!isOpenWaterMask) {
        return
    }
    let txt = ''
    if (myWaterMaskArr.indexOf('PlatformName') != -1) { // 有没有勾选平台名称
        txt += sessionStorage.getItem('platFormName')
    }
    if (myWaterMaskArr.indexOf('Name') != -1) {// 有没有勾选登录姓名
        txt += ` ${userInfo.profile.name}`
    }
    if (myWaterMaskArr.indexOf('Institution') != -1) {
        txt += ` ${userInfo.profile.inst_name}`
    }
    if (otherWaterMaskArr.length != 0) {
        otherWaterMaskArr.forEach((one) => {
            if (one.isChecked) {
              txt += ` ${one.text}`
            } 
        })
    }
    if (myWaterMaskArr.indexOf('Date') != -1) {
        const now = new Date()
        const year = now.getFullYear() // 年
        const month = now.getMonth() + 1 >= 10 ? now.getMonth() + 1 : `0${now.getMonth() + 1}` // 月
        const date = now.getDate() >= 10 ? now.getDate() : `0${now.getDate()}` // 日
        txt += ` ${year}-${month}-${date}`
    }


    let fontSize = 16
    //let gap = webConfigData.density[data.WatermarkDensity]
    let gap = webConfigData.density[2]
    console.log(waterMaskColor)
    const url = drawText(txt, fontSize, waterMaskColor, gap)
    const styles = {
        position: 'fixed',
        left: '0',
        top: '0',
        width: '100vw',
        height: '100vh',
        zIndex: '10086',
        backgroundImage: `url(${url})`,
        pointerEvents: 'none'
    }

    const div = document.createElement('div')
    document.body.appendChild(div)

    for (let [key, value] of Object.entries(styles)) {
        div.style[key] = value
    }
}
