<template>
  <div class="CAdialog">
    <div class="caContainer">
    <div class="stepDiv">
      <el-steps :active="active">
        <el-step title="卫健信息"></el-step>
        <el-step title="关联机构"></el-step>
        <el-step title="完成添加"></el-step>
      </el-steps>
    </div>
    <div class="firstStep" v-if="active === 0">
      <div class="weiJianInfor">
         <div class="formItemDiv">
            <label class="formLabel"><i class="iconfont iconbitian mustIcon"></i>卫健名称：</label>
            <el-input class="fl  width_300_input height_36" v-model="addWeiJianInfor.name" maxlength="30" show-word-limit placeholder="请输入卫健名称"></el-input>
          </div>
          <div class="formItemDiv">
            <label class="formLabel">卫健简称：</label>
            <el-input class="fl  width_300_input height_36" v-model="addWeiJianInfor.abbreviation" maxlength="30" show-word-limit placeholder="请输入卫健简称"></el-input>
          </div>
          <div class="formItemDiv">
            <label class="formLabel">卫健代码：</label>
            <el-input class="fl  width_300_input height_36" v-model="addWeiJianInfor.code" placeholder="请输入卫健代码"></el-input>
          </div>
          <div class="formItemDiv">
            <label class="formLabel"><i class="iconfont iconbitian mustIcon"></i>卫健区域：</label>
            <el-cascader
              ref="cascaderAddr"
              :style="{width: '300px'}"
              v-model="weiJianCityValue"
              :key="cityKey"
              :options="city.cityJson"
              @change="getCityCodeFn"
              @active-item-change="childrenCity">
            </el-cascader>
          </div>
          <div class="formItemDiv">
            <label class="formLabel"><i class="iconfont iconbitian mustIcon"></i>联系人：</label>
            <el-input class="fl  width_300_input height_36" v-model="addWeiJianInfor.admin_name"  placeholder="请输入联系人姓名"></el-input>
          </div>
          <div class="formItemDiv">
            <label class="formLabel"><i class="iconfont iconbitian mustIcon"></i>联系电话：</label>
            <el-input class="fl  width_300_input height_36" v-model="addWeiJianInfor.admin_phone" placeholder="请输入联系人电话"></el-input>
          </div>
          <div class="formItemDiv">
            <label class="formLabel">备注信息：</label>
            <el-input class="fl width_300_input introduceInput" v-model="addWeiJianInfor.remark" type="textarea" placeholder="请输入备注信息" resize="none" maxlength="200" show-word-limit></el-input>
          </div>
      </div>
    </div>
    <div class="twoStep" v-if="active === 1">
      <div class="tableDiv">
        <div class="tableLeft">
          <div class="queryDiv">
            <span class="institute-label">机构名称 :</span>
            <el-input class="width_160_input ml4"  v-model="searchData.name" placeholder="关键字"></el-input>
            <span class="institute-label ml10">所属区域 :</span>
            <el-cascader
              ref="cascaderAddr"
              :style="{width: '220px'}"
              v-model="instituteCityValue"
              :options="city.cityJson"
              @change="getAnotherCityCodeFn"
              @active-item-change="childrenCity">
            </el-cascader>
            <el-button class="searchBtn" type="primary" size="small" @click="getInstituteListFn()">查询</el-button>
            <el-button size="small" plain @click="resetSearchDataFn">重置</el-button>
          </div>
          <div class="tableBox" :class="{'noTableData':instituteList.length===0}">
            <el-table
              ref="tableList"
              border
              :data="instituteList"
              :height="tableHeight"
              :header-cell-style="{background: '#f5f5f5',color: '#1E1D22'}"
              tooltip-effect="dark"
              :row-key="getInstituteRowKeys"
              @select="selectCurRow"
              @select-all="selectAll"
              >
              <el-table-column type="selection" width="50" :reserve-selection="true"></el-table-column>
              <el-table-column prop="index" fixed="left" label="序号" width="50">
                <template slot-scope="scope">
                  <span>{{
                    (searchData.offset - 1) * searchData.limit + scope.$index + 1
                  }}</span>
                </template>
              </el-table-column>
              <common-table :propData="institutePropData"></common-table>
            </el-table>
          </div>
         
        <div>
          <pagination-tool  :total="totalInstitute" :page.sync="searchData.offset" :limit.sync="searchData.limit" @pagination="getInstituteListFn()" />
        </div>
        </div>
        <div class="tableRight ml10">
            <div class="clr_333 choosedInstituteTotal mb10">已选择机构（{{CheckedInstituteList.length}}）</div>
            <div class="allChooedInstitute">
              <div class="checksueritem" v-for="item in CheckedInstituteList" :key="item.id">
                <span class="instituteName" :title="item.name">{{item.name}}</span>
                <span class="delMeal" v-on:click="delCheckuser(item.id)">
                  <i class="iconfont">&#xe63a;</i>
                </span>
              </div>
            </div>
        </div>
      </div>
    </div>
    <!--第三步-->
    <div class="twoStep" v-if="active === 2">
      <div class="caBindStuDiv mb5">
         <span class="firstIcon"></span>
         <i class="iconfont ml10 sucIcon">&#xe634;</i>
         <span class="ml6 caBindLabel">绑定成功：</span>
         <span class="sucNum">{{importCaSucNum}}</span>
         <span class="ml6">条</span>
         <i class="iconfont failIcon ml25">&#xe632;</i>
         <span class="ml6 caBindLabel">绑定失败：</span>
         <span class="failNum">{{importCaFailNum}}</span>
         <span class="ml6">条</span>
      </div>
      <el-table
        ref="bindOvertableList"
        border
        :data="importCAlist"
        :height="500"
        :header-cell-style="{background: '#f5f5f5',color: '#1E1D22'}"
        tooltip-effect="dark"
        style="width: 100%;max-height: 450px;margin-bottom:20px;"
        :row-key="getRowKeys"
        
        >
        <!-- <el-table-column type="selection" width="55" :reserve-selection="true"></el-table-column> -->
        <el-table-column prop="index" fixed="left" label="序号" width="50"></el-table-column>
        <el-table-column prop="result" fixed="left" label="绑定状态" width="230">
          <template slot-scope="scope">
            <span class="caSucStatus" v-bind:class="{'caFailStatus':scope.row.success===false}">{{scope.row.result}}</span>
          </template>
        </el-table-column>
        <common-table :propData="caFinishbindPropData"></common-table>
      </el-table>
    </div>
  </div>
   <div slot="footer" class="dialog_footer">
      <el-button v-if="active === 0" plain size="small" @click="finishWeiJianAdd()">取 消</el-button>
      <el-button v-if="active === 1" plain size="small" @click="prevStep()">上一步</el-button>
      <el-button v-if="active === 0" size="small" type="primary" @click="nextStep()">下一步</el-button>
      <el-button v-if="active === 1 || active === 2" type="primary" size="small" @click="beganAddWeiJian()">完成</el-button>
    </div>
  </div>
</template>

<script>
import CommonTable from '@/components/common/CommonTable'
import PaginationTool from '@/components/common/PaginationTool'
import { getUserList ,importCa } from '@/api/user'
import { getCenterUser }  from '@/api/seviceCenterManage/centerSet'
import { getOfficesLite } from '@/api/commonHttp'
import { UnshiftToArray } from '@/components/commonJs'
import { getCityJson } from "@/api/commonHttp";
import { getCommonSettingTenancy, getTenancyInstitutionList, addFirmOrWeiJian, updateFirmOrWeiJian, getFirmOrWeiJianDetail,  getAllFactoryInstitution } from '@/api/platform_costomer/institution'
export default {
  props: {
    // institutelist:Array,
    isUpdate: Boolean
  },
  components: {
    CommonTable,
    PaginationTool
  },
  inject:['city'],
  data () {
    return {
      active: 0,
      cityKey: 0,
      tableHeight: '100%',
      weiJianCityValue: [],
      addWeiJianInfor: {
        id: 0,
        name: '',
        abbreviation: '',
        code: '',
        province_code: '',
        province: '',
        city_code: '',
        city: '',
        district_code: '',
        district: '',
        admin_name: '',
        admin_phone: '',
        remark: '',
        institution_ids: [],
        type: 1,
      },
      totalInstitute: 0,
      CheckedInstituteList: [],
      CheckedInstituteIdArr: [],
      importCAlist: [],
      instituteList: [],
      importCaSucNum: 0,
      importCaFailNum: 0,
      instituteCityValue: [],
      weiJianOrFirmDetailObj: {},
      searchData: {
        name: '',
        province_code: '',
        city_code: '',
        district_code: '',
        offset:1,
        limit: 10,
      },
      institutePropData: [
        { prop: 'name', label: '机构名称', width: 150 },
        { prop: 'level', label: '行政级别', width: 100 },
        { prop: 'type', label: '机构类别', width: 100 },
        { prop: 'address', label: '所属区域' },
      ],
      caFinishbindPropData: [
        { prop: 'name', label: '用户姓名', width: 90 },
        { prop: 'phone', label: '手机号码', width: 130 },
        { prop: 'work_no', label: '工号', width: 95 },
        { prop: 'institution_name', label: '所属机构', width: 220 },
        { prop: 'institution_code', label: '组织机构代码'},
      ]
    }
  },
  watch: {
    'city.cityJson': function() {
      this.cityKey++
    }
  },
  methods: {
    getCityCodeFn (val) {
      var self = this
      var arr = self.getCascaderObj(val, self.city.cityJson)
      arr.forEach((item, i) => {
        if (i === 0) {
          self.addWeiJianInfor.province_code = item.value
          self.addWeiJianInfor.province = item.label
        } else if (i === 1) {
          self.addWeiJianInfor.city_code = item.value
          self.addWeiJianInfor.city = item.label
        } else if (i === 2) {
          self.addWeiJianInfor.district_code = item.value
          self.addWeiJianInfor.district = item.label
        }
      })
    },
    // 回显城市联动
    async echoCityinfo(province, city, district) {
      var _provinceparmas = {
        parent_code: province,
        level: 1,
      };
      var _cityparmas = {
        parent_code: city,
        level: 2,
      };
      var _districtparmas = {
        parent_code: district,
        level: 3,
      };
      var _provincejson = [];
      var _cityjson = [];
      var _districtjson = [];
      // 一级
      const _provinceres = await getCityJson(_provinceparmas);
      _provinceres.data.forEach((item) => {
        var info = {
          label: "",
          value: "",
        };
        info.children = [];
        info.label = item.name;
        info.value = item.code;
        _provincejson.push(info);
      });
      this.city.cityJson = _provincejson;
      // 二级
      const _cityres = await getCityJson(_cityparmas);
      _cityres.data.forEach((item) => {
        var info = {
          label: "",
          value: "",
        };
        info.children = [];
        info.label = item.name;
        info.value = item.code;
        _cityjson.push(info);
      });
      this.city.cityJson.forEach((item) => {
        if (item.value === _provinceparmas.parent_code) {
          item.children = _cityjson;
        }
      });
      // 三级
      const _districtres = await getCityJson(_districtparmas);
      _districtres.data.forEach((item) => {
        var info = {
          label: "",
          value: "",
        };
        info.label = item.name;
        info.value = item.code;
        _districtjson.push(info);
      });
      this.city.cityJson.forEach((itemlevel) => {
        itemlevel.children.forEach((item) => {
          if (item.value === _cityparmas.parent_code) {
            item.children = _districtjson;
          }
        });
      });
    },
    getAnotherCityCodeFn (val) {
      var self = this
      var arr = self.getCascaderObj(val, self.city.cityJson)
      arr.forEach((item, i) => {
        if (i === 0) {
          self.searchData.province_code = item.value
        } else if (i === 1) {
          self.searchData.city_code = item.value
        } else if (i === 2) {
          self.searchData.district_code = item.value
        }
      })
    },
    getCascaderObj (val, opt) {
      return val.map(function (value, index, array) {
        for (var itm of opt) {
          if (itm.value === value) { opt = itm.children; return itm }
        }
        return null
      })
    },
    childrenCity (val) {
      this.$emit('childrenCityFn', val)
    },
    // 获取详情
    async getCurFirmOrWeiJianDetail (id) {
      const res = await getFirmOrWeiJianDetail({id: id})
      if (res.code === 0) {
        this.weiJianOrFirmDetailObj = res.data
        this.addWeiJianInfor = {
          id: res.data.id,
          name: res.data.name,
          abbreviation: res.data.abbreviation,
          code: res.data.code,
          admin_name: res.data.admin_name,
          admin_phone: res.data.admin_phone,
          province_code: res.data.province_code,
          province: res.data.province,
          city_code: res.data.city_code,
          city: res.data.city,
          district_code: res.data.district_code,
          district: res.data.district,
          remark: res.data.remark,
          institution_ids: [],
          type:2,
        }
        if (res.data.province_code) {
          await this.echoCityinfo(
            res.data.province_code,
            res.data.city_code,
            res.data.district_code
          );
          this.weiJianCityValue = [
            res.data.province_code,
            res.data.city_code,
            res.data.district_code,
          ];
        }        
      } else {
        this.$message({ type: 'error', message: res.msg })
      }
    },
    // 获取厂商或卫建绑定的所有机构
    async getFactoryBindInstitution (id) {
      const res = await getAllFactoryInstitution({factory_id: id})
      if (res.code === 0) {
        this.CheckedInstituteList = []
        this.CheckedInstituteList = res.data
      } else {
        this.$message({ type: 'error', message: res.msg })
      }
    },
    // 重置
    resetSearchDataFn () {
     this.instituteCityValue = []
     this.searchData = {
        name: '',
        province_code: '',
        city_code: '',
        district_code: '',
        offset:1,
        limit: 10,
      }
      this.getInstituteListFn()
    },
    verifyAddWeiJian () {
      if (!this.addWeiJianInfor.name) {
        this.$message({ message: '请输入卫健名称', type: 'error' })
        return false
      }
      if (this.addWeiJianInfor.province_code === '' || this.addWeiJianInfor.city_code === '' || this.addWeiJianInfor.district_code === '') {
        this.$message.error('请选择卫健区域')
        return false
      }
      if (!this.addWeiJianInfor.admin_name) {
        this.$message({ message: '请输入联系人姓名', type: 'error' })
        return false
      }
      if (!this.addWeiJianInfor.admin_phone) {
        this.$message({ message: '请输入联系人电话', type: 'error' })
        return false
      }
      var phoneReg = /^1[3456789]\d{9}$/;
      if (!phoneReg.test(this.addWeiJianInfor.admin_phone)) {
        this.$message({ message: "请输入正确的手机号码", type: "error" });
        return false;
      }
      return true
    },
    // 上一步
    prevStep () {
      this.active = this.active - 1
    },
    // 下一步
    async nextStep () {
      if (!this.verifyAddWeiJian()) {
        return false
      }
      this.active = this.active + 1
      if (this.active === 1) {
        this.getInstituteListFn()
      }
    },
    // 获取userlist type=bind 查询绑定ca用户数据
    async getInstituteListFn() {
      var self = this
      
      const res = await getTenancyInstitutionList(self.searchData)
      if (res.code === 0) {
        self.loading = false
        self.totalInstitute = res.page.total_count
        res.data.forEach((item, i) => {
          item.index = i + 1
        })
        self.instituteList = res.data
        // 编辑回显时 勾选之前已选中的机构
        self.CheckedInstituteIdArr = []
        if (self.CheckedInstituteList.length != 0) {
          self.CheckedInstituteList.forEach((item) => {
            self.CheckedInstituteIdArr.push(item.id)
          })
        }
        self.$nextTick(()=> {
          if (self.instituteList.length != 0) {
            self.instituteList.forEach((item) => {
              if (self.CheckedInstituteIdArr.indexOf(item.id) != -1) {
                self.$refs.tableList.toggleRowSelection(item,true)
              } else {
                self.$refs.tableList.toggleRowSelection(item,false)
              }
            })
          }
        })
        
      } else {
        self.loading = false
        self.$message({ message: `${res.msg}`, type: 'error' })
      }
    },
    // 去重数组对象里面id值相等的
    clearCommonId (arr) {
      var result = [];
      var obj = {};
      for(var i =0; i<arr.length; i++){
          if(!obj[arr[i].id]){
            result.push(arr[i]);
            obj[arr[i].id] = true;
          }
      }
      return result
    },
    // 全选
    selectAll (val) {
      const self = this
      self.CheckedInstituteList = val
      // console.log(val)
      // if (val.length != 0) {// 选中
      //   val.forEach((one) => {
      //     self.CheckedInstituteList.push(one)
      //   })
      //   // 去重
      //   self.CheckedInstituteList = self.clearCommonId(self.CheckedInstituteList)
      // } else { // 不选中
      //   self.instituteList.forEach((item) => {
      //     self.CheckedInstituteList.forEach((nth,i)=> {
      //       if (nth.id == item.id) {
      //         self.CheckedInstituteList.splice(i,1)
      //       }
      //     })
      //   })
      // }
    },
    // 选中某一行
    selectCurRow (selection, row) {
      const self = this
      // 判断是否 选中
      let selected = selection.length && selection.indexOf(row) !== -1
      // 去掉选中时
      if (!selected) {
        self.CheckedInstituteList.forEach((val,i) => {
           if (val.id === row.id) {
             self.CheckedInstituteList.splice(i,1)
           }
        })
      } else {
        self.CheckedInstituteList.push(row)
        self.CheckedInstituteList = self.clearCommonId(self.CheckedInstituteList)
      }
    },
    delCheckuser(id) {
      const self = this;
      self.instituteList.forEach((one) => {
        if (one.id === id) {
          self.$refs.tableList.toggleRowSelection(one, false);
        }
      });
      self.CheckedInstituteList.forEach((item, i) => {
        if (item.id === id) {
          self.CheckedInstituteList.splice(i, 1);
        }
      });
    },
    // 开始添加卫建
    async beganAddWeiJian () {
      const _parmas = {
        id: this.addWeiJianInfor.id,
        name: this.addWeiJianInfor.name,
        abbreviation: this.addWeiJianInfor.abbreviation,
        code: this.addWeiJianInfor.code,
        province_code: this.addWeiJianInfor.province_code,
        province: this.addWeiJianInfor.province,
        city_code: this.addWeiJianInfor.city_code,
        city: this.addWeiJianInfor.city,
        district_code: this.addWeiJianInfor.district_code,
        district: this.addWeiJianInfor.district,
        admin_name: this.addWeiJianInfor.admin_name,
        admin_phone: this.addWeiJianInfor.admin_phone,
        remark: this.addWeiJianInfor.remark,
        type: 1,
        institution_ids: []
      };
      if (this.CheckedInstituteList.length != 0) {
        this.CheckedInstituteList.forEach((item) => {
          _parmas.institution_ids.push(item.id)
        })
      }
      let res
      let message = ''
      if (!this.isUpdate) {
        delete _parmas.id // 新增时 不传id字段
        res = await addFirmOrWeiJian(_parmas);
        message = '创建卫健成功'
      } else {
        delete _parmas.type // 编辑时 不传type字段
        res = await updateFirmOrWeiJian(_parmas);
        message = '编辑卫健成功'
      }
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: message,
        });
        this.finishWeiJianAdd()
      } else {
        this.$message({ type: "error", message: res.msg, });
      }
    },
    finishWeiJianAdd () {
      this.active = 0
      this.$emit('finishWeiJianAdd')
    },
    getRowKeys (val) {
      return val.id
    },
    getInstituteRowKeys (val) {
      return val.id
    },
  },
  mounted () {
  }
}
</script>
<style lang="less" scoped>
.caContainer{
  padding:0 20px;
}
::v-deep .stepDiv{
  display: flex;
  justify-content: center;
  margin-bottom:30px;
 .el-step{
   width:204px;
   flex-basis: initial!important;
   .el-step__line{
     left: 32px;
     right: 8px;
     background:#ededed;
   }
   .el-step__icon{
      background:#e1e8ed;
      color:#606266;
      font-size:15px;
      font-family: Arial;
      border:none;
    }
    .el-step__head.is-process{
      .el-step__icon{
        background:#0a70b0;
        color:#fff;
      }
    }
    .el-step__head.is-finish{
      .el-step__icon{
        background:#0a70b0;
        color:#fff;
      }
      .el-step__line{
        background:#0a70b0;
      }
    }
    .el-step__title.is-finish{
      color:#0a70b0!important;
    }
    .el-step__main{
      .el-step__title{
        font-size:14px;
        color:#606266;
        line-height: 18px;
        position: relative;
        left: -15px;
        margin-top: 8px;
      }
      .is-process{
        color:#0a70b0;
        font-weight: initial;
      }
    }
 }
 .el-step:last-of-type{
   width:auto!important;
 }
}
.formItemDiv{
  margin-bottom:15px;
  display: flex;
  justify-content: center;
  .formLabel{
    width:130px;
    text-align:right;
    font-size: 15px!important;
    color: #303133;
    line-height: 36px;
    i {
        padding-right: 5px;
        font-size: 15px;
    }
  }
  ::v-deep .el-textarea__inner{
    height:100px;
  }
}
.queryDiv{
  margin-bottom:10px;
  .institute-label{
    display: inline-block;
    width:75px;
  }
  .width_95_input{
    width:95px;
  }
  .width_160_input{
    width:160px;
  }
  .shortInput{
    width:120px!important;
  }
  .ml4{
    margin-left:4px;
  }
  .searchBtn{
    margin-left:18px;
  }
  .shortSearchBtn{
    margin-left:8px;
  }
  .bg_e6{
    border:none!important;
    margin-left:8px;
  }
  .bg_e6:hover{
    background:#E6A23C!important;
  }
}
.tableDiv{
  display: flex;
}
.tableRight{
  width: 210px;
  .choosedInstituteTotal{
    line-height: 32px;
  }
  .allChooedInstitute{
    max-height: 468px;
    overflow:auto;
  }
}
.tableLeft{
  width:calc(100% - 220px);
}
.checksueritem{
  width: 100%;
  display: flex;
  height: 30px;
  justify-content: space-between;
  align-items: center;
  padding: 0px 10px;
  background: #E6F3FF;
  border-radius: 4px;
  margin-bottom: 10px;
  cursor: pointer;
}
.checksueritem:hover .delMeal{
  display: block;
}
.delMeal{
  display: none;
}
.instituteName{
  display: inline-block;
  width:170px;
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
}
::v-deep .tableBox{
  height:442px;
  .el-table{
    height:100%;
  }
  .el-table__body-wrapper{
    height:calc(100% - 40px);
    overflow: auto;
  } 
}
// 第三步的样式
.caBindStuDiv{
  background:#faecd8;
  height:30px;
  display: flex;
  align-items: center;
  border-radius: 3px;
  .firstIcon{
    width:3px;
    height:30px;
    border-radius: 1px;
    background:#e6a23c;
  }
  .sucIcon{
    font-size:16px;
    color:#19b955;
  }
  .failIcon{
    font-size:16px;
    color:#f56c6c;
  }
  .caBindLabel{
    font-size:14px;
    color:#303133;
  }
  .sucNum{
    font-size:16px;
    color:#19b955;
    font-weight: bold;
  }
  .failNum{
    font-size:16px;
    color:#f56c6c;
    font-weight: bold;
  }
  .ml6{
    margin-left:6px;
  }
}
.moreBindCaBtn{
  display: inline-block;
  width: 80px;
  height: 32px;
  text-align: center;
  border-radius: 3px;
  line-height: 32px;
  cursor: pointer;
  color:#fff;
  font-size:14px;
}
.caSucStatus{
  color:#19B955;
}
.caFailStatus{
  color:#F56C6C;
}
</style>
<style>
.CAdialog{
  padding-top: 15px!important;
  padding-bottom:0px!important;
  /* overflow: auto; */
}
</style>
