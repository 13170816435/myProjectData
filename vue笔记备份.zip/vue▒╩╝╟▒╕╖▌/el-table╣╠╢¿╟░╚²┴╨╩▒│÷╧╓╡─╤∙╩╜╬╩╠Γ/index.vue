<template>
  <div class="userlist">
    <div class="title-bar flex_row">
      <div class="crumbsCon">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>医疗机构<i
            class="iconfont iconzhankaishouqi"
          ></i>
        </span>
        <div class="m-tab">
          <div
            class="m-tab-item"
            :class="tabIndex === index ? 'm-tab-item-active' : ''"
            v-for="(item, index) in tabList"
            :key="index"
            @click="toggleTab(index, item.value)"
          >
            {{ item.label }}
          </div>
          <div class="tab-line" :style="{ left: number + 'px' }"></div>
        </div>
      </div>
      <div class="tr col operateCon">
        <!-- <span
              class="operate-btn clr_0a importInstituteBtn"
              @click="operationFn('', 'weijian')"
              ><i class="iconfont iconxinzeng mr5"></i
              >卫健管理</span
            >
          <span
              class="operate-btn clr_0a importInstituteBtn"
              @click="operationFn('', 'firm')"
              ><i class="iconfont iconxinzeng mr5"></i
              >厂商管理</span
            > -->
        <span
          v-if="isPayModel && tabType == 1"
          class="operate-btn clr_0a addInstituteBtn mr5"
          @click="readyAddInstitute()"
        >
          <el-popover
            placement="bottom-start"
            popper-class="addOrganPopover"
            title=""
            width="300"
            trigger="hover"
            content="可快速添加平台中其他客户下的机构到本客户中；"
          >
            <el-button class="tipButton" slot="reference"
              >添加机构<i class="iconfont tipIcon pl5">&#xe720;</i></el-button
            >
          </el-popover>
        </span>
        <span
          v-if="tabType == 1 && !intelligentDiagnosis"
          class="operate-btn clr_0a importInstituteBtn"
          @click="operationFn('', 'import')"
          ><i class="iconfont icondaoru mr5"></i>导入机构</span
        >
        <span
          class="function-btn bg_e6 clr_ff ml10"
          @click="beganAddCampus"
        >
          <i class="iconfont iconxinzeng mr5"></i>院区
        </span>
        <span
          v-if="tabType == 1"
          class="function-btn bg_e6 clr_ff ml10"
          @click="operationFn('', 'add')"
        >
          <i class="iconfont iconxinzeng mr5"></i>机构
        </span>

        <span
          v-if="tabType == 2 && isWeiJianTenancy"
          class="function-btn bg_e6 clr_ff ml10"
          @click="beganAddWeiJian"
        >
          <i class="iconfont iconxinzeng mr5"></i>新增卫健
        </span>

        <span
          v-if="tabType == 3"
          class="function-btn bg_e6 clr_ff ml10"
          @click="beganAddFirm"
        >
          <i class="iconfont iconxinzeng mr5"></i>新增厂商
        </span>
        <!-- </div> -->
      </div>
    </div>
    <div v-if="tabType == 1" class="container">
      <div class="search-bar flex_row">
        <div class="searchDiv">
          <span class="fl mb10 search-bar-label">机构名称 :</span>
          <el-input
            class="fl width_240_input"
            v-model="searchData.name"
            placeholder="请输入机构名称"
          ></el-input>
          <span class="fl search-bar-label ml15">医院等级 :</span>
          <el-select
            v-model="searchData.level_code"
            filterable
            placeholder="请选择"
            class="w_200 fl"
          >
            <el-option
              v-for="item in HospitalLevel"
              :key="item.dic_code"
              :label="item.dic_name"
              :value="item.dic_code"
            ></el-option>
          </el-select>

          <div class="instituteDiv fl">
            <span class="search-bar-label ml15">所属区域 :</span>
            <el-cascader
              :style="{ width: timerWidth }"
              v-model="cityValue"
              :options="city.cityJson"
              placeholder="请选择省/市/区"
              :key="1"
              clearable
              @change="getCityCodeFn"
              @expand-change="childrenCity"
            >
            </el-cascader>
          </div>

          <div class="clear fl joinTime">
            <span class="instituteType search-bar-label fl">入驻时间 :</span>
            <el-date-picker
              @change="search"
              class="chooseIntervalsPick searchTimePicker"
              v-model="timer"
              type="daterange"
              align="right"
              value-format="yyyy-MM-dd"
              unlink-panels
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :picker-options="pickerOptions"
            ></el-date-picker>
          </div>

          <span class="instituteType search-bar-label fl ml15">机构类别 :</span>
          <el-select
            v-model="searchData.nature_code"
            filterable
            placeholder="请选择"
            class="w_200 fl"
          >
            <el-option
              v-for="item in HospitalKind"
              :key="item.dic_code"
              :label="item.dic_name"
              :value="item.dic_code"
            ></el-option>
          </el-select>
          <span class="search-bar-label ml15 fl">管理人员 :</span>
          <el-input
            class="width_200_input mr15 fl"
            v-model="searchData.admin_info"
            placeholder="请输入姓名/手机号"
          ></el-input>
          <el-button
            type="primary"
            class="fl"
            size="small"
            @click="searchInstitutionListFn"
            >查询</el-button
          >
          <el-button class="fl" size="small" plain @click="resetFn"
            >重置</el-button
          >
        </div>
      </div>
      <div
        class="table-list"
        v-bind:class="{ noTableData: institutionList.length == 0 }"
      >
        <el-table
          ref="dataTable"
          v-loading="loading"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          :data="institutionList"
          border
          :height="tableheight"
          stripe
          highlight-current-row
          header-row-class-name="strong"
          row-key="id"
          :expand-row-keys="expandedRowKeys"
          :row-class-name="setClassName"
          :show-expand-icon="false"
        >
          
          <el-table-column label="序号" width="60" fixed="left" type="">
            <template slot-scope="scope">
              <span>{{
                (searchData.offset - 1) * searchData.limit + scope.$index + 1
              }}</span>
            </template>
          </el-table-column>
          
          <el-table-column label="操作" width="230" fixed="left" type="">
            <template slot-scope="scope">
                <span
                    v-if="intelligentDiagnosis"
                    class="clr_0a pointer mr10"
                    @click="intelligentDiagnosisDetailEvent(scope.row)"
                    >详情</span
                  >
                  <span
                    class="clr_0a pointer"
                    @click="operationFn(scope.row, 'update')"
                    >编辑</span
                  >
                  <span
                    v-if="!intelligentDiagnosis"
                    class="clr_oarange pointer pl10"
                    @click="operationFn(scope.row, 'office')"
                    >科室管理</span
                  >
                  <span
                    class="clr_0a pointer pl10"
                    @click="beganAddCampus(scope.row)"
                    >新增院区</span
                  >
                  
                  <el-popover placement="right" width="118" class="" trigger="hover" v-if="!intelligentDiagnosis">
                    <div class="moreOperateDiv">
                      <span
                      v-if="!intelligentDiagnosis"
                      class="clr_0a oneOperateBtn"
                      @click="operationFn(scope.row, 'generalManage')"
                      >个性设置</span
                    >
                    <span
                      v-if="!intelligentDiagnosis"
                      class="clr_da oneOperateBtn"
                      @click="operationFn(scope.row, 'del')"
                      >删除</span
                    >
                    <span
                      v-if="intelligentDiagnosis"
                      class="clr_da oneOperateBtn"
                      @click="operationFn(scope.row, 'remove')"
                      >移除</span
                    >
                    </div>
                  <span class="clr_0a pointer pl10" slot="reference">更多</span>
                </el-popover>
            </template>
          </el-table-column>
          <el-table-column type="expand" fixed="left" width="1">
            <template slot-scope="props">
                <el-table
                  :data="props.row.hospitals" 
                  inline
                  class="orderTable  demo-table-expand"
                  style="width: 100%"
                  
                  >
                  <el-table-column width='230'>
                    <template slot-scope="scope">
                      <span class="clr_0a pointer" @click="updateCampus(scope.row)">编辑</span>
                      <span class="clr_da pointer oneOperateBtn pl10" @click="operationFn(scope.row, 'del')">删除</span>
                    </template>
                  </el-table-column>
                <el-table-column v-for="(item,index) in propData"
                  v-bind:key="index"
                  :prop="item.prop"
                  :label="item.label"
                  :width="item.width"
                  type=""
                  >
                  <template slot-scope="scope">
                    <span v-if="item.prop === 'name'" class="campusName">
                      <span class="campusTitle">院区</span>
                      {{scope.row.name}}
                    </span> 
                  </template>                            
               </el-table-column>
              </el-table>
            </template>
          </el-table-column>
          <el-table-column label="机构名称" width="300" fixed="left">
            <template slot-scope="scope">
              <el-button v-if="scope.row.hospitals.length != 0" type="text" @click="toggleRowExpansion($event,scope.row)">
                <i class="iconfont iconshuangjiantou-xia showOrHideIcon"></i>
              </el-button>
              <span>{{scope.row.name}}</span>
            </template>
          </el-table-column>
          <common-table :propData="newPropData"></common-table>
        </el-table>
        <div class="ba">
          <pagination-tool
            :total="total_count"
            :page.sync="searchData.offset"
            :limit.sync="searchData.limit"
            @pagination="pageSizeChangeFn"
          />
        </div>
      </div>
    </div>
    <div v-if="tabType == 2" class="container">
      <addWeiJian
        :key="addInstituteKey"
        ref="weiJianList"
        :city="city"
        @resetCity="resetCity"
        @childrenCity="childrenCity"
        :reportParam="reportParam"
      ></addWeiJian>
    </div>
    <div v-if="tabType == 3" class="container">
      <addFirm
        :key="addInstituteKey"
        ref="firmList"
        :city="city"
        @resetCity="resetCity"
        @childrenCity="childrenCity"
        :reportParam="reportParam"
      ></addFirm>
    </div>
    <el-dialog
      title="导入机构"
      :visible.sync="isImportInstitution"
      width="900px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <a id="downlink"></a>
      <import-institution
        :importList="importList"
        :name="importFileName"
        @chooseUploadFile="chooseUploadFile"
        @importListFn="importListFn"
        :isImportFinished="isImportFinished"
        :importTip="importTip"
      ></import-institution>
    </el-dialog>
    <el-dialog
      title="个性设置"
      :visible.sync="showGeneralManageAlert"
      width="680px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <generalManage
        :commonSettingList="commonSettingList"
        :reportParam="reportParam"
      ></generalManage>
      <div class="dialog_footer">
        <el-button size="small" plain @click="showGeneralManageAlert = false"
          >取消</el-button
        >
        <el-button type="primary" size="small" @click="sureSaveSetting"
          >保存</el-button
        >
      </div>
    </el-dialog>
    <el-dialog
      title="添加机构"
      :visible.sync="showAddInstituteAlert"
      width="1000px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <addInstitute
        :key="addInstituteKey"
        :city="city"
        @resetCity="resetCity"
        @childrenCity="childrenCity"
        @cancelAddInstitute="cancelAddInstitute"
        @sureAddInstitute="sureAddInstitute"
        :reportParam="reportParam"
      ></addInstitute>
    </el-dialog>
    <!-- 
    <el-dialog
      title="卫健管理"
      :visible.sync="showAddWeiJianAlert"
      width="1000px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <addWeiJian
        :key="addInstituteKey"
        :city="city"
        @resetCity="resetCity"
        @childrenCity="childrenCity"
        @cancelAddWeiJian="cancelAddWeiJian"
        :reportParam="reportParam"
      ></addWeiJian>
    </el-dialog> -->

    <!-- <el-dialog
      title="厂商管理"
      :visible.sync="showAddFirmAlert"
      width="1000px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <addFirm
        :key="addInstituteKey"
        :city="city"
        @resetCity="resetCity"
        @childrenCity="childrenCity"
        @cancelAddFirm="cancelAddFirm"
        :reportParam="reportParam"
      ></addFirm>
    </el-dialog> -->
  </div>
</template>

<script>
import Mgr from '@/utils/SecurityService'
import eventBus from '@/utils/eventBus'
import { getSS, setSS } from "@/components/commonJs";
import exportExcel from "@/components/exportExcel";
import ImportInstitution from "./components/ImportInstitution";
import generalManage from "./components/generalManage";
import addInstitute from "./components/addInstitute";
import addWeiJian from "./components/addWeiJian";
import addFirm from "./components/addFirm";
import CommonTable from "./components/CommonTable";
import PaginationTool from "@/components/common/PaginationTool";
import {
  getOperateSettingsMmeta,
  addNoBindInstitution,
  getInstitutionList,
  getTenancyInstitutionList,
  delInstitutionInfoByid,
  institutionUnbindSystem,
  importInstitution,
  getCommonSettingTenancy,
  postCommonSettingTenancy,
  saveServiceReportSetting,
  getReportConfigSettings,
  getAimInstitutionOpenList, getAimInstitutionDetailOpen
} from "@/api/platform_costomer/institution";
import { getDistinfoByType, getCityJson, getCurTenancyType } from "@/api/commonHttp";
import { CityLinkedJson } from "@/components/commonJs";
export default {
  components: {
    ImportInstitution,
    CommonTable,
    PaginationTool,
    generalManage,
    addInstitute,
    addWeiJian,
    addFirm,
  },
  provide() {
    return {
      city: this.city,
    };
  },
  data() {
    return {
      tenancyId: '',
      tabIndex: 0,
      number: 0,
      tabType: 1,
      tabList: [
        {
          label: "机构管理",
          value: 1,
        },
        {
          label: "厂商管理",
          value: 3,
        },
      ],
      tableheight: "100%",
      timerWidth: "200px",
      cityValue: [],
      timer: [],
      //cityJson: [],
      value: "",
      curInstitutionId: "",
      isPayModel: false,
      loading: true,
      addInstituteKey: 0,
      total_count: 0,
      showAddInstituteAlert: false,
      isImportInstitution: false,
      showGeneralManageAlert: false,
      pickerOptions: {
        shortcuts: [
          {
            text: "今天",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              // start.setTime(start.getTime() - 3600 * 1000 * 24 * 6);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近一周",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 6);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近一个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 29);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近三个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 89);
              picker.$emit("pick", [start, end]);
            },
          },
        ],
      },
      searchData: {
        name: "",
        level_code: "",
        nature_code: "",
        admin_info: "",
        begin_create_time: "",
        end_create_time: "",
        offset: 1,
        limit: 20,
        province_code: "",
        city_code: "",
        district_code: "",
      },
      reportParam: {
        id: "",
        paramSet: [],
      },
      city: {
        cityValue: [],
        cityJson: [],
        city_parmas: {
          parent_code: "1",
          level: 1,
        },
      },
      isImportFinished: true,
      importTip: "导入中...",
      importFileName: "",
      currentFileName: "",
      commonSettingList: [],
      importList: [],
      HospitalLevel: [], // 医院等级
      HospitalKind: [], // 机构性质
      pageLayout: "total, prev, pager, next, jumper",
      newPropData: [
        // { prop: "name", label: "机构名称", width: 300 },
        { prop: "office_count", label: "科室数量", width: 80 },
        { prop: "level", label: "医院等级", width: 120 },
        { prop: "nature", label: "机构类别", width: 120 },
        { prop: "type", label: "机构类型", width: 120 },
        { prop: "business_nature", label: "经营性质", width: 90 },
        { prop: "regional_nature", label: "行政级别", width: 100 },
        { prop: "admin_name", label: "管理员", width: 120 },
        { prop: "admin_phone", label: "管理员电话", width: 140 },
        { prop: "create_time", label: "入驻时间", width: 180 },
        { prop: "ordinal", label: "排序号", width: 80  },
        { prop: "health_commission_names", label: "所属卫健", width: 180  },
        { prop: "vendor_names", label: "所属厂商"},
      ],
      propData: [
        { prop: "name", label: "机构名称", width: 300 },
        { prop: "office_count", label: "科室数量", width: 80 },
        { prop: "level", label: "医院等级", width: 120 },
        { prop: "nature", label: "机构类别", width: 120 },
        { prop: "type", label: "机构类型", width: 120 },
        { prop: "business_nature", label: "经营性质", width: 90 },
        { prop: "regional_nature", label: "行政级别", width: 100 },
        { prop: "admin_name", label: "管理员", width: 120 },
        { prop: "admin_phone", label: "管理员电话", width: 140 },
        { prop: "create_time", label: "入驻时间", width: 180 },
        { prop: "ordinal", label: "排序号", width: 80  },
        { prop: "health_commission_names", label: "所属卫健", width: 180  },
        { prop: "vendor_names", label: "所属厂商"},
      ],
      institutionList: [],
      // 批量导入
      total: 10000,
      excel: "",
      gridData: [
        {
          index: 1,
          state: "0",
          state_str: "正常",
          name: "浙江大学附属邵逸夫医院",
          code: "12345678",
          num: "123456",
          admin_name: "小黑",
        },
      ],
      importinfo: {
        total: "10",
        success: "5",
        faild: "3",
      },
      importFormData: new CompatibleFormData(),
      intelligentDiagnosis: false,
      isWeiJianTenancy: false,
      expandedRowKeys: [],
    };
  },
  watch: {
    // $route (to) {
    //   if (to.name === 'InstitutionList') { // 详情返回事刷新表格（新增编辑）
    //     this.getInstitutionListFn()
    //     this.$refs.dataTable.doLayout()
    //   }
    // }
  },
  // beforeMount () {
  //   this.$nextTick(() => { // 表格高度
  //     this.tableheight = document.documentElement.clientHeight - 220
  //   })
  // },
  created() {
    if (getSS("instituteListQueryObj")) {
      this.searchData = getSS("instituteListQueryObj");
    }
    this.beganGetTenancyType()
  },
  mounted() {
    if (this.$route.meta.intelligentDiagnosis) {
      this.intelligentDiagnosis = true
      this.tabList = [
        {
          label: "机构管理",
          value: 1,
        }
      ]
    }
    this.getCityJsonFn(this.city.city_parmas);
    this.getInstitutionListFn();
    this.getDistinfoFn();
    this.getPayMode();
  },
  methods: {
    toggleRowExpansion (e,row) {
      this.$refs.dataTable.toggleRowExpansion(row);

      const obj = e.currentTarget;


      if (obj.classList.contains("activeWatch")) {
        obj.classList.remove("activeWatch");
      } else {
        obj.classList.add("activeWatch");
      }

    },
    getSpanMethod(row, column, rowIndex, columnIndex) {
      // 第一、第二列不合并
      if (columnIndex >= 1 && columnIndex <= 2) {
        return 1;
      }
      // 第三和第四列合并（假设这两列的数据在你的数据源中是连续的）
      if (rowIndex === 0 && columnIndex === 3) { // 第一行的第四列
        return { row: 2, column: 1 };
      }
      return 1;
    },
    setClassName (data) {
      if (data.row.hospitals && data.row.hospitals.length == 0) {
        return 'noExpandRow'
      }
      return ''
    },
    beganAddCampus () {
      // this.showAddCampusAlert = true
      // this.$router.push("addOrgain");
      this.$router.push({path: "addOrgain",query: { type: 'addCampusTab'}} );
    },
    // 确定新增院区
    sureAddCampus () {

    },
    // 获取当前客户类型
    async beganGetTenancyType () {
      const manager = new Mgr();
      const user = await manager.getRole();
      const tenancy_id = sessionStorage.getItem('curTenancyId') || user.profile.tenancy_id
      if (user) {
        const res = await getCurTenancyType({tenancy_id: tenancy_id});
        if (res.code === 0) {
          if (res.data.type == 4) {// 如果客户类型是卫健委
            this.isWeiJianTenancy = true
            this.tabList = [
              {
                label: "机构管理",
                value: 1,
              },
              {
                label: "卫健管理",
                value: 2,
              },
              {
                label: "厂商管理",
                value: 3,
              },
            ]
          }
        } else {
          this.$message({ type: "error", message: res.msg });
        }
      }
      
    },
    // 智能诊断详情按钮事件
    intelligentDiagnosisDetailEvent (item) {
      eventBus.$emit('senMessenger', {
        msgStr: 'intelligentDiagnosisDetail',
        payload: item
      })
    },
    toggleTab(index, value) {
      this.tabType = value;
      if (this.tabIndex < index) {
        this.number = index * 70 + index*10; //70既是一个tab的宽度 也是tab下滑动横线的宽度
      } else {
        this.number = this.number - (this.tabIndex - index) * 70 - (this.tabIndex - index)*10; // 10为tab之前的margin值 下面样式有设置
      }
      if (this.tabIndex != index) {
        if (this.tabType == 1) {
          // 机构列表
          this.getInstitutionListFn();
        } else if (this.tabType == 2) {
          // 卫健列表
        } else if (this.tabType == 3) {
          // 厂商列表
        }
      }
      this.tabIndex = index;
    },
    beganAddWeiJian() {
      const self = this;
      self.$nextTick(() => {
        self.$refs.weiJianList.beganAddWeiJian();
      });
    },
    beganAddFirm() {
      const self = this;
      self.$nextTick(() => {
        self.$refs.firmList.beganAddFirm();
      });
    },
    // 获取支付模式
    async getPayMode() {
      const self = this;
      const param = {
        name: "",
      };
      const res = await getOperateSettingsMmeta(param);
      if (res.code === 0) {
        res.data.forEach((item) => {
          if (item.key === "platform_model" && item.value === "1") {
            self.isPayModel = true;
          }
        });
      } else {
        self.$message({ type: "error", message: res.msg });
      }
    },
    // 添加机构弹窗  重置时 地址控制数据重置
    resetCity() {
      this.city.cityValue = [];
    },
    // 获取联动改变的值
    getCityCodeFn(val) {
      val.forEach((item, i) => {
        if (i === 0) {
          this.searchData.province_code = item;
        } else if (i === 1) {
          this.searchData.city_code = item;
          this.searchData.district_code = "";
        }
        if (i === 2) {
          this.searchData.district_code = item;
        }
      });
    },
    // 取消添加
    cancelAddInstitute() {
      this.showAddInstituteAlert = false;
    },
    readyAddInstitute() {
      this.showAddInstituteAlert = true;
      this.addInstituteKey++;
    },
    // 确认添加机构
    async sureAddInstitute(params) {
      const res = await addNoBindInstitution(params);
      if (res.code === 0) {
        this.showAddInstituteAlert = false;
        this.$message({ type: "success", message: "添加机构成功" });
        this.searchData.offset = 1;
        this.getInstitutionListFn();
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 获取城市json
    async getCityJsonFn(params) {
      var self = this;
      const res = await getCityJson(params);
      if (res.code === 0) {
        self.city.cityJson = CityLinkedJson(
          res.data,
          self.city.cityJson,
          params
        );
      }
    },
    async childrenCity(val) {
      var self = this;
      val.forEach((item, i) => {
        self.city.city_parmas.parent_code = item;
        self.city.city_parmas.level = i + 2;
      });
      await self.getCityJsonFn(self.city.city_parmas);
    },
    // 获取字典列表
    async getDistinfoFn() {
      var _parmas = "HospitalLevel,HospitalKind";
      var _url = `/dict/${_parmas}`;
      const res = await getDistinfoByType(_url);
      if (res.code !== 0 || res.data.length === 0) {
        return;
      }
      var iL = [];
      var iK = [];
      res.data.forEach((item) => {
        if (item.lookup_key === "HospitalLevel") {
          iL.push(item);
        }
        if (item.lookup_key === "HospitalKind") {
          iK.push(item);
        }
      });
      this.HospitalLevel = iL;
      this.HospitalKind = iK;
    },
    // 机构列表
    async getInstitutionListFn() {
      const self = this
      if (self.intelligentDiagnosis) {
        self.searchData.system_id = sessionStorage.getItem('system_id')
      }

      setSS("instituteListQueryObj", self.searchData);
      self.expandedRowKeys = []
      const res = await getTenancyInstitutionList(self.searchData);
      if (res.code === 0) {
        self.loading = false;
        res.data.forEach((item, i) => {
          item.index = i + 1;
        });
        self.institutionList = res.data;
        // 设置 列表里面的字段hospitals 数组长度不为0的默认展开
        if (self.institutionList.length != 0) {
          self.institutionList.forEach((item) => {
            if (item.hospitals.length != 0) {
              self.expandedRowKeys.push(item.id)
            }
          })
        }
        if (res.page) {
          self.total_count = res.page.total_count;
        }
      } else {
        self.loading = false;
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // 筛选条件搜索
    searchInstitutionListFn() {
      this.searchData.offset = 1;
      if (this.cityValue.length === 0) {
        this.searchData.province_code = "";
        this.searchData.city_code = "";
        this.searchData.district_code = "";
      }
      this.getInstitutionListFn();
    },
    // 重置
    resetFn() {
      this.cityValue = this.$options.data().cityValue;
      this.searchData = this.$options.data().searchData;
      this.timer = [];
      this.getInstitutionListFn();
    },
    search() {
      this.searchData.offset = 1;
      if (this.timer && this.timer.length !== 0) {
        this.searchData.begin_create_time = this.timer[0];
        this.searchData.end_create_time = this.timer[1];
      } else {
        this.searchData.begin_create_time = "";
        this.searchData.end_create_time = "";
      }
      this.getInstitutionListFn();
    },
    // 编辑院区
    updateCampus (row) {
      this.$router.push({ path: "addOrgain", query: { id: row.id,type: 'addCampusTab' } });
    },
    // 表格操作按钮
    operationFn (row, type) {
      let basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
      if (type === "add") {
        if (this.intelligentDiagnosis) {
          this.$router.push(`${basepath}/MedicalInstitutionLayoutBlank/addOrgain`);
        } else {
          this.$router.push("addOrgain");
        }
        // this.$router.push("addOrgain");
      } else if (type === "update") {
        if (this.intelligentDiagnosis) {
          this.$router.push({ path: `${basepath}/MedicalInstitutionLayoutBlank/addOrgain`, query: { id: row.id } });
        } else {
          this.$router.push({ path: "addOrgain", query: { id: row.id } });
        }
        // this.$router.push({ path: "addOrgain", query: { id: row.id } });
      } else if (type === "机构") {
        // 参数配置
        this.$router.push("paramstersetting");
      } else if (type === "office") {
        this.$router.push({ path: "departmentList", query: { id: row.id } });
      } else if (type === "import") {
        this.isImportInstitution = true;
        this.name = "";
        this.importList = [];
        this.importFileName = "";
      } else if (type === "generalManage") {
        this.showGeneralManageAlert = true;
        this.curInstitutionId = row.id;
        // 获取配置
        this.getcommonSettinginfoFn();
        // 获取院内报告配置
        this.getMyReportConfigSettings();
      } else if (type === "del") {
        this.$confirm("是否删除" + row.name + "？", "删除", {
          distinguishCancelAndClose: true,
          confirmButtonText: "删除",
          cancelButtonText: "取消",
        }).then(() => {
          const response = delInstitutionInfoByid(row.id);
          response.then((res) => {
            if (res.code === 0) {
              // this.institutionList.forEach((item, i) => {
              //   console.log(item);
              //   if (item.id === row.id) {
              //     this.institutionList.splice(i, 1);
              //   }
              // });
              this.getInstitutionListFn()
              this.$message({
                message: "删除成功",
                type: "success",
              });
            } else {
              this.$message({ type: "error", message: res.msg });
            }
          });
        });
      } else if (type == 'remove') {
        // 移除
        this.aimRemoveEvent(row)
        
      }
    },
    async aimRemoveEvent (row) {
      let useState = await this.aimInstitutionUseService(row)
      if (useState) {
        return
      }
      this.$confirm("是否移除" + row.name + "？", "移除", {
        distinguishCancelAndClose: true,
        confirmButtonText: "移除",
        cancelButtonText: "取消",
      }).then(() => {
        const response = institutionUnbindSystem({
          tenancy_id: this.tenancyId,
          system_id: sessionStorage.getItem('system_id'),
          institution_id: row.id
        });
        response.then((res) => {
          if (res.code === 0) {
            this.institutionList.forEach((item, i) => {
              if (item.id === row.id) {
                this.institutionList.splice(i, 1);
              }
            });
            this.$message.success('移除成功')
          } else {
            this.$message.error(res.msg);
          }
        });
      });
    },
    // 智能诊断系统 判断机构下是否有服务使用
    async aimInstitutionUseService (row) {
      let res = await getAimInstitutionOpenList({
        institution_id: row.id,
        system_id: sessionStorage.getItem('system_id'),
        tenancy_id: this.tenancyId
      })
      if (res.code != 0) {
        return true
      }
      if (res.data.length) {
        if (res.data[0].service_count > 0) {
          this.aimInstitutionOpenService(row)
          return true
        } else {
          return false
        }
      }
      return false
    },
    // 智能诊断系统 获取机构下使用的服务信息
    async aimInstitutionOpenService (row) {
      let res = await getAimInstitutionDetailOpen({
        institution_id: row.id,
        system_id: sessionStorage.getItem('system_id'),
        tenancy_id: this.tenancyId
      })
      if (res.code != 0) {
        return true
      }
      let arr = res.data.filter(item => {
        return item.open_state
      })
      if (!arr.length) {
        return
      }
      let nameArr = arr.map(item => {
        return item.service_name
      })
      this.$message.error(`${row.name}正在使用【${nameArr.join('】【')}】不支持移除`)
    },
    // 判断id 对应的 厂商、视频会议、ca签名是否被删除了
    isHasSettingId(id, arr) {
      let isHasThisId = false;
      arr.forEach((val) => {
        if (val.id === id) {
          isHasThisId = true;
        }
      });
      if (!isHasThisId) {
        return 0;
      } else {
        return id;
      }
    },
    async getcommonSettinginfoFn() {
      const self = this;
      const res = await getCommonSettingTenancy({
        institution_id: self.curInstitutionId,
      });
      self.commonSettingList = [];
      if (res.code === 0) {
        res.data.forEach((item, i) => {
          item.index = i + 1;
          if (item.config_type === 10) {
            //针对短信设置特殊处理
            item.state = item.state != 1 ? false : true;
          } else {
            item.state = item.state === 0 ? false : true;
          }
        });
        res.data.forEach((val) => {
          val.setting_id = self.isHasSettingId(
            val.setting_id,
            val.common_settings
          );
          self.commonSettingList.push(val);
        });
      } else {
        self.commonsettingList = [];
        self.$message({ type: "error", message: res.msg });
      }
    },
    // 保存综合管理配置
    async sureSaveSetting() {
      console.log(this.commonSettingList)
      const arr = this.commonSettingList.map(({config_type,setting_id,state}) => ({config_type,setting_id,state}));
      arr.forEach((item) => {
        console.log(item.state);
        item.default_selection = item.state === true ? 1 : 0;
        item.state = item.state === true ? 1 : 0;
        
      });
      const _params = {
        common_settings: arr,
        institution_id: this.curInstitutionId,
      };
      const res = await postCommonSettingTenancy(_params);
      if (res.code === 0) {
        this.saveReportSetting();
        // if (this.reportParam.hospital_report) {
        //   this.saveReportSetting()
        // } else {
        //   this.$message({ type: 'success',message: '保存成功' })
        //   this.showGeneralManageAlert = false
        // }
      } else {
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    async saveReportSetting() {
      const self = this;
      this.reportParam.id = this.curInstitutionId;
      let param = {
        id: this.reportParam.id,
        hospital_report: "",
        menu_display: [],
      };
      self.reportParam.paramSet.forEach((val) => {
        if (val.key === "hospital_report") {
          param.hospital_report = val.value;
        } else if (val.key === "menu_display") {
          param.menu_display = val.value;
        }
      });
      const res = await saveServiceReportSetting(param);
      if (res.code === 0) {
        this.$message({
          type: "success",
          message: "保存成功",
        });
        this.showGeneralManageAlert = false;
      } else {
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    async getMyReportConfigSettings() {
      const res = await getReportConfigSettings(this.curInstitutionId);
      if (res.code === 0) {
        if (res.data.length != 0) {
          res.data.forEach((item) => {
            // 对options里面 的字段名称进行修改下  把options里面的Name 转成name  Value转成value
            if (item.options != undefined) {
              item.options.forEach((oneOptions) => {
                if (oneOptions.hasOwnProperty('Name')) {
                  oneOptions.name = oneOptions.Name
                  delete oneOptions.Name;
                }
                if (oneOptions.hasOwnProperty('Value')) {
                  oneOptions.value = oneOptions.Value
                  delete oneOptions.Value;
                }
              });
            }
          });
        }
        this.reportParam.paramSet = res.data;
      } else {
        this.$message({
          type: "error",
          message: res.msg,
        });
      }
    },
    // 分页
    pageSizeChangeFn(info) {
      this.getInstitutionListFn();
    },
    // 机构导入-----------------------------------
    // 上传文件
    chooseUploadFile(file, fileList) {
      if (this.verifyIsFrx(file)) {
        this.importFileName = file.name;
        this.importFormData.delete("file");
        this.importFormData.append("file", file.raw);
      }
    },
    verifyIsFrx(file) {
      const fileName = file.raw.name;
      this.currentFileName = file.raw.name;
      const type = fileName.substring(fileName.lastIndexOf(".")).toLowerCase();
      var isFrx = null;
      isFrx = type === ".xlsk" || type === ".xls" || type === ".xlsx";
      if (!isFrx) {
        this.$message.error("上传文件只能是excel格式!");
        return false;
      }
      return isFrx;
    },
    async importListFn(type) {
      if (type === "down") {
        exportExcel.downloadFile(
          this.exportModel,
          document.getElementById("downlink")
        );
      } else {
        // 导入用户
        if (!this.importFileName) {
          this.$message.error("请选择文件！");
          return;
        }
        this.importFormData.delete("detect");
        let tips = "";
        if (type === "check") {
          this.importFormData.append("detect", 1);
          tips = "检测完成！";
          this.importTip = "检测中...";
        } else {
          tips = "导入完成！";
          this.importTip = "导入中...";
        }
        this.isImportFinished = false;
        const res = await importInstitution(this.importFormData.compatible());
        if (res.code === 0) {
          this.isImportFinished = true;
          this.$message.success(tips);
          res.data.forEach((item, i) => {
            item.index = i + 1;
            if (item.result.split("：")[0] === "导入失败：") {
              item.state = 0;
            } else {
              item.state = 1;
            }
          });
          this.importList = res.data;
        } else {
          this.isImportFinished = true;
          this.$message.error(res.msg);
        }
      }
    },
  },
};
</script>

<style lang="less" scoped>
.crumbsCon {
  display: flex;
  .m-tab {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .m-tab-item {
    width: 70px;
    color: #303133;
    font-size: 15px;
    text-align: center;
    cursor: pointer;
    font-weight: 700;
    margin-right:10px;
  }
  .m-tab-item-active {
    color: #0a70b0;
    font-weight: 700;
  }
  .tab-line {
    height: 2px;
    width: 70px;
    background: #0a70b0;
    position: absolute;
    bottom: 0;
    left: 0;
    transition: all 0.3s ease;
  }
}
.userlist {
  height: 100%;
  .container {
    height: calc(100% - 46px);
    .table-list {
      height: calc(100% - 85px);
      ::v-deep .el-table {
        height: calc(100% - 57px) !important;
        .el-table__body-wrapper {
          height: calc(100% - 40px) !important;
          overflow: auto !important;
        }
        .el-table__expanded-cell{
          padding:0px!important;
          border-bottom:none!important;
        }
        .orderTable{
          .el-table__body-wrapper{
            overflow: hidden !important;
          }
        }
        .el-table__expand-icon{
          display: none;
        }
      }
    }
    .border {
      border: 1px solid rgb(2, 2, 3);
    }
    .icon-btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      color: #fff;
      line-height: 24px;
      text-align: center;
      padding: 0px;
      cursor: pointer;
      border-radius: 3px;
      margin-right: 8px;
    }
  }
  .clr_e63 {
    color: #e6a23c;
  }
  .search-bar {
    flex-flow: wrap;
    position: relative;
    .searchDiv {
      width: 100%;
      margin-bottom: 10px;
    }
    .operateCon {
      position: absolute;
      right: 0px;
      top: 0px;
    }
  }
}
.search-bar {
  .w_200 {
    width: 200px !important;
    display: inline-block !important;
    overflow: initial;
  }
}
::v-deep .addInstituteBtn {
  border: 1px solid rgba(220, 223, 230, 1) !important;
  .el-button {
    width: 100%;
    height: 100%;
    border: none;
    padding: 0px;
  }
}
.importBtn {
  border: 1px solid rgba(220, 223, 230, 1) !important;
}
.operate-btn {
  display: inline-block;
  width: 104px;
  text-align: center;
  padding: 0;
  height: 32px;
  line-height: 30px;
  border-radius: 3px;
  border: none;
  margin-left: 10px;
  cursor: pointer;
  border: 1px solid #dcdfe6;
}
.importInstituteBtn {
  height: 30px;
}
.moreOperateDiv{
  display: flex;
  flex-flow: column;
  .oneOperateBtn {
   cursor: pointer;
   height: 36px;
   line-height: 36px;
  }
 .oneOperateBtn:hover {
   background: #f5f7fa;
   color: #0a70b0;
  }
}
::v-deep .orderTable {
  padding-left:60px;
  .el-table__header-wrapper {
    display: none;
  }
  .el-table__body-wrapper{
    overflow: hidden!important;
  }
}
// 列表里面hospitals字段数组为空数组时 不需要展开
::v-deep .noExpandRow{
  .el-table__expand-column .cell{
    display: none;
  }
}
.iconshuangjiantou-xia{
  color:#0a70b0;
}
.campusName{
  display: flex;
  align-items: center;
  .campusTitle{
    border-radius: 4px;
    font-size:12px;
    width:32px;
    height: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    border:1px solid #1ea9ff;
    color:#1ea9ff;
    margin-right:5px;
  }
}
.showOrHideIcon {
  display: inline-block;
  transition: all 0.3s;
  -moz-transition: all 0.3s; /* Firefox 4 */
  -webkit-transition: all 0.3s; /* Safari 和 Chrome */
  -o-transition: all 0.3s;
  margin-right: 5px;
}

.activeWatch {
  .showOrHideIcon {
    margin-right: 5px;
    -webkit-transform: rotate(270deg);
    -moz-transform: rotate(270deg);
    -o-transform: rotate(270deg);
    -ms-transform: rotate(270deg);
    transform: rotate(270deg);
  }
}
// @media screen and (max-width: 1800px) {
//   .joinTime{
//     clear: both;
//     margin-right:15px;
//     margin-left:0px;
//     .search-bar-label{
//       margin-left:0px;
//     }
//   }
// }

// @media screen and (max-width: 1450px) {
//   .instituteDiv{
//     clear: both;
//     margin-right:15px;
//     .search-bar-label{
//       margin-left:0px;
//     }
//   }
// }
// @media screen and (min-width: 1800px) {
//   .instituteType{
//    clear: both;
//   }
// }
</style>
