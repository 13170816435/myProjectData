<template>
  <div class="header" id="header">
    <div class="bn fl  head_name">
      <img :src="headerimg"/> <!--@error="headerimgError"-->
      <span class="fl f20 fw_500" v-cloak>{{ platformName }}</span>
    </div>
    <div class="fr">
      <div class="imclient work-station pl10 pr10 fullScreen-btn"
      @click="lockPage">
        <i class="med_mima medIconfont f15"></i>
        锁屏
      </div>
      <!-- web im -->
      <div class="imclient work-station pl10 pr10 fullScreen-btn" @click='handleFullScreen'>
        <i class="iconfont mr5" v-if="!isFullscreen">&#xe6ca;</i>
        <i class="iconfont mr5" v-else>&#xe6c9;</i>
        {{ isFullscreen ? '退出全屏' : '全屏' }}
      </div>
      <span class="imclient pl10 pr10 work-station" @click='dialogFormVisible=true'><i
          class="iconfont iconxitongshezhi mr5"></i>设置</span>
      <webImClient class="imclient ml10"/>
      <el-popover placement="bottom" width="600" trigger="manual"
      v-model="windowsNotificationTips1" v-if="!windowsNotification">
        <div class="pl10 pt10 pb10 pr10">
          <div>您未打开“windows”消息通知，为了能及时提醒到您，请按以下步骤打开：</div>
          <div>1、浏览器右上角打开“<i class="medIconfont med_gengduo1"></i>”--->“设置”--->隐私与安全--->网站设置--->通知--->网站可以询问能否向您发送通知</div>
          <div>2、首次收到消息后在询问弹窗内点击“允许”即可</div>
        </div>
        <i class="el-icon-warning cursor f18 clr_red ml10" slot="reference" @click.stop="windowsNotificationTips1 = !windowsNotificationTips1"></i>
      </el-popover>
      <el-popover
          placement="bottom"
          width="90"
          top="0" trigger="click"
      >
        <ul class="head_pop_ul">
          <li><a :href="personalCenterUrl" target="_blank"><i
              class="el-icon-user-solid f16 lh40 mr10 clr_666"></i>个人中心</a></li>
          <!-- <li @click="showSetPassword"><a href="#"><i class="iconfont f16 lh40 mr10 clr_666">&#xe682;</i>修改密码</a></li> -->
          <li><a href="#" @click="downLoad"><i class="medIconfont med_daoru f16 lh40 mr10 clr_666"></i>下载插件</a></li>
          <li v-if="showSystemAbout"><a href="#" @click="aboutSystem"><i class="medIconfont med_guanyuxitong f16 lh40 mr10 clr_666"></i>关于系统</a>
          </li>
          <li><a href="#" @click="LoginOut"><i class="iconfont f16 lh40 mr10 clr_666">&#xe6ba;</i>退出登录</a></li>
        </ul>
        <div class="fr head_login_info cursor" slot="reference">
          <span class='fr ml10 fw_500'>{{ loginInfo.profile.name }}</span>
          <img :src="userImg" @error="userimgError" class='fr  ml10'/>
        </div>
      </el-popover>
    </div>
    <WorkstationSet :dialogFormVisible='dialogFormVisible' @closeBack='closeBack'></WorkstationSet>
    <!-- 修改密码 -->
    <change-password v-if="showChangePassword.show" :showChangePassword="showChangePassword"/>
  </div>
</template>
<script>
import Mgr from '@/utils/SecurityService'
import { getTenanciesLogo, getThisPlatformName, getUserAvatar } from '@/api/Public'
import { getTenanCiesSettingsMeta } from '@/api/commonHttp'
import { getBase64 } from '@/utils/mixin/filter'
import ChangePassword from '@/components/pacs/commonDialog/ChangePassword'
import WorkstationSet from '@/components/pacs/commonDialog/WorkstationSet'
import eventBus from '@/utils/eventBus'
import aboutSystem from 'tomtaw-system-about'
import { loadImage } from '@/utils'
import { initLockSceen } from 'tomtaw-lockpage'
import { getScreensaverTime } from '@/api/commonHttp'
import { mapState, mapGetters } from 'vuex'

export default {
  computed: {
    ...mapGetters(['platformName']),
    ...mapState('app', {
      windowsNotification: state => state.windowsNotification,
    }),
    ...mapGetters(['windowsNotificationTips'])
  },
  watch: {
    windowsNotificationTips: {
      immediate: true,
      handler (val) {
        if (val) {
          this.windowsNotificationTips1 = true
        } else {
          this.windowsNotificationTips1 = false
        }
      }
    },
    windowsNotificationTips1: {
      handler (val) {
        this.$store.commit('app/SET_WINDOWSNOTIFICATIONTIPS', val)
      }
    }
  },
  data () {
    return {
      personalCenterUrl: '',
      isShowReconnnect: false,
      loginInfo: {
        profile: {
          inst_name: '',
          name: ''
        }
      },
      defaultUserImg: require('../../../assets/images/common/doctor_boy.png'),
      headerimg: require('../../../assets/images/common/logo.png'),
      userImg: require('../../../assets/images/common/doctor_boy.png'),
      dialogFormVisible: false,
      isFullscreen: false,
      showChangePassword: { show: false },
      showSystemAbout: false,
      windowsNotificationTips1: false
    }
  },
  created () {
    // 获取锁屏时间
    this.getCurScreensaverTime()
  },
  mounted () {
    this.personalCenterUrl = window.Config.subdir + '/operate/myPersonCenter/index?from=telemedicine'
    var _this = this
    _this.$nextTick(async () => {
      const manager = new Mgr()
      _this.loginInfo = await manager.getRole()
      _this.getUserIcon()
      localStorage.setItem('userName', _this.loginInfo.profile.name)
      /*localStorage.setItem('loginInfo', JSON.stringify(_this.loginInfo))*/
      _this.getPlatformName()
    })
    // 监听全屏事件
    document.addEventListener('fullscreenchange', () => {
      this.isFullscreen = document.fullscreen
    })
    // 禁用f11
    document.onkeydown = function (event) {
      if (event.keyCode == 122) {
        return false
      }
    }
    window.onhelp = function () {
      return false
    }
    this.getTenanCiesSettingsMeta()
  },
  methods: {
    // 锁屏
    lockPage () {
      openLockPage()
    },
    // 获取锁屏时间
    async getCurScreensaverTime () {
      const res = await getScreensaverTime()
      if (res.code === 0) {
        let lockScreenTime = parseInt(res.data.time) || 0 // 注意单位是秒
        if (!res.data.state) { // 个人中心那不开启自动锁屏时 时间默认传0
          lockScreenTime = 0
        }
        // 初始化initLockSceen函数第二个参数 传你们项目产品的名称
        initLockSceen(lockScreenTime,'/telemedicine/')
        if (localStorage.getItem('isLockPage') == 'true') {
          openLockPage()
        }
      } else {
        this.$message({ type: 'error',message: res.msg})
      }
    },
    getTenancyId () {
      return new Promise((resolve, reject) => {
        let tenancyId = sessionStorage.getItem('tenancyId')
        if (tenancyId) {
          resolve(tenancyId)
        } else {
          const timer = setInterval(() => {
            tenancyId = sessionStorage.getItem('tenancyId')
            if (tenancyId) {
              clearInterval(timer)
              resolve(tenancyId)
            }
          }, 5)
        }
      })
    },
    async getTenanCiesSettingsMeta () {
      const tenancyId = await this.getTenancyId()
      const res = await getTenanCiesSettingsMeta({ id: tenancyId, name: '' })
      if (res.code !== 0) {
        this.$message.error(res.msg)
        return
      }
      res.data.forEach(item => {
      // 对options里面 的字段名称进行修改下  把options里面的Name 转成name  Value转成value
        if (item.options != undefined) {
          item.options.forEach((oneOptions) => {
            oneOptions.name = oneOptions.Name
            delete oneOptions.Name
            oneOptions.value = oneOptions.Value
            delete oneOptions.Value
          })
        }
        if (item['value'] == undefined) {
          item.value = null
        }
      })
      const result = res.data
      result.forEach((one) => {
        if (one.key == 'common_components') {
          if (one.value.indexOf('About') != -1){
            this.showSystemAbout = true
          }
        }
      })
    },
    // 关于系统
    aboutSystem () {
      let manager = new Mgr()
      manager.getRole().then((userInfo) => {
        aboutSystem('telemed', userInfo)
      })
    },
    headerimgError () {
      /* event.srcElement.src = this.defaultHeaderImg */
    },
    userimgError () {
      event.srcElement.src = this.defaultUserImg
    },
    handleFullScreen () {
      const element = document.documentElement
      if (this.isFullscreen) {
        if (document.exitFullscreen) {
          document.exitFullscreen()
        } else if (document.webkitCancelFullScreen) {
          document.webkitCancelFullScreen()
        } else if (document.mozCancelFullScreen) {
          document.mozCancelFullScreen()
        } else if (document.msExitFullscreen) {
          document.msExitFullscreen()
        }
      } else {
        if (element.requestFullscreen) {
          element.requestFullscreen()
        } else if (element.webkitRequestFullScreen) {
          element.webkitRequestFullScreen()
        } else if (element.mozRequestFullScreen) {
          element.mozRequestFullScreen()
        } else if (element.msRequestFullscreen) {
          // IE11
          element.msRequestFullscreen()
        }
      }
      this.isFullscreen = !this.isFullscreen
      eventBus.$emit('changeScreen', this.isFullscreen)
    },
    async getUserIcon () {
      const self = this
      const userIconId = self.loginInfo.profile.sub
      if (userIconId && userIconId !== '0') {
        const imgFile = await getUserAvatar(userIconId)
        getBase64(imgFile).then(result => {
          self.userImg = result
        })
      }
    },
    LoginOut () {
      const key = `oidc.user:${configUrl.crmUrl}:${clientid}`
      const oidcSession = sessionStorage.getItem(key)
      sessionStorage.clear()
      sessionStorage.setItem(key, oidcSession)
      localStorage.removeItem('loginInfo')
      if (localStorage.getItem('editRisApplyInfoNotice')) {
        localStorage.removeItem('editRisApplyInfoNotice')
      }
      var manager = new Mgr()
      manager.signOut()
    },
    async getPlatformName () {
      const self = this
      const res = await getThisPlatformName()
      if (res.code === 0) {

        if (res.data.site_name && res.data.site_name !== '') {
          this.setBrowserTit(res.data.site_name)
        }

        if (res.data.logo && res.data.logo !== '0') {
          const imgFile = await getTenanciesLogo({
            id: res.data.logo,
            tenancy_id: self.loginInfo.profile.tenancy_id
          }, 'blob')
          const url = URL.createObjectURL(imgFile)
          if (url) {
            const isLoad = await loadImage(url)
            if (isLoad) {
              this.headerimg = url
            }
          }
        } else {

        }
      } else {

      }
    },
    setBrowserTit (name) {
      document.title = name
    },
    closeBack () {
      this.dialogFormVisible = false
    },
    showSetPassword () {
      this.showChangePassword.show = true
    },
    downLoad () {
      window.open(configUrl.frontEndUrl + '/cloudpacs/downLoad')
    }
  },
  components: {
    WorkstationSet,
    ChangePassword
  }
}
</script>
<style lang="less" scoped>
.fw_500 {
  font-weight: 500;
}

.header {
  width: 100%;
  height: 50px;
  color: #303133;
  border-bottom: 1px solid #ebeef5
}

.head_pop_ul {
  padding: 6px 0;
}

.head_pop_ul li {
  height: 40px;
  line-height: 40px;
}

.head_pop_ul li:hover {
  cursor: pointer;
  background: #ecf5ff;
}

.head_pop_ul li a {
  height: 40px;
  width: 110px;
  display: block;
  line-height: 40px;
  padding-left: 20px;
}

.head_pop_ul li:hover a, .head_pop_ul li:hover i {
  color: #0a70b0
}

.head_name {
  font-size: 18px;
  line-height: 50px;
  padding-left: 24px;
  overflow: hidden;
}

.head_name img {
  margin-top: 5px;
  margin-right: 12px;
  float: left;
  height: 40px;
}

.head_name span {
  line-height: 50px;
  float: left;
}

.head_login_info img {
  width: 36px;
  height: 36px;
  border-radius: 18px;
  margin-top: 6px;
  margin-right: 5px;
}

.head_login_info span {
  line-height: 50px;
  margin-right: 30px;
}

.header ::v-deep .el-popover {
  padding: 0px !important;
  min-width: 110px !important;
}

.imclient {
  display: inline-block;
  height: 100%;
  line-height: 50px;
}

.work-station {
  cursor: pointer;
}

.work-station i {
  color: #0a70b0
}

.imclient:hover {
  background: #f2f2f4;
}

.head_login_info:hover {
  background: #f2f2f4;
}

// .head_pop_ul li a:hover{background: #f2f2f4;}
.fullScreen-btn {
  cursor: pointer;

  i {
    font-size: 12px;
  }
}
</style>
