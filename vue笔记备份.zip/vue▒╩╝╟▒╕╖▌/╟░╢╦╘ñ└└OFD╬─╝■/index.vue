// 链接地址： https://www.jianshu.com/p/8e1fbaebf175
/* 组件使用说明  1、首先安装依赖npm i ofd.js --save
2、import {parseOfdDocument, renderOfd} from "ofd.js";
3、准备一个div容器 */
<template>
  <div id="divId" style="text-align: center"></div>
</template>

<script>
import { parseOfdDocument, renderOfd } from "ofd.js";

export default {
  data() {
    return {

    };
  },
  mounted() {
    parseOfdDocument({
      // ofd写入文件地址
      ofd: "/SystemMana/control/streamCdt?contentId=56ls8Fgf1vI3UaDaxVd",
      success(res) {
        //输出ofd每页的div
        let screenWidth = 800;
        const divs = renderOfd(screenWidth, res[0]);
        let contentDiv = document.getElementById('divId');
        contentDiv.innerHTML = '';
        for (const div of divs) {
          contentDiv.appendChild(div);
        }
      },
      fail(error) {
        console.log(error)
      }
    });
  },
  methods: {

  }
};
</script>
<style lang="less" scoped>
.login-wrap {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: url("../../assets/image/loginBac.jpg");
  .login {
    width: 368px;
    position: relative;
    left: -33%;
    .header {
      margin-top: 9vh;
      margin-bottom: 6vh;
      text-align: center;
      .description {
        font-size: 30px;
        font-weight: 600;
        margin-top: 1vh;
      }
    }
  }
  .login-form {
    background-color: #fff;
    padding: 0 20px 20px;
    box-shadow: 0 0 20px #ddd;
    .form {
      padding-top: 1vh;
    }
    .login-btn {
      display: inline-block;
      width: 100%;
      margin-top: 2vh;
    }
  }
}
</style>