<template>
   <div class="container">
      <el-form
        :model="organInfo"
        :rules="rules"
        ref="organInfo"
        label-width="155px"
        class="demo-ruleForm"
      >
        <el-row class="mt5">
          <el-col :span="9" class="fl w_500">
            <el-form-item label="机构名称 :" prop="name">
              <el-input
                v-if="isAdd"
                placeholder="医疗机构全称"
                v-model="organInfo.name"
                class="w_300"
                @blur="onCheckExistsWhileNhc('name')"
              ></el-input>
              <el-input
                :disabled="stopUpdateInstitute"
                v-else
                placeholder="医疗机构全称"
                v-model="organInfo.name"
                class="w_300"
              ></el-input>
              <el-popover
                v-if="isAdd"
                placement="bottom-start"
                popper-class="organTipPopover"
                title=""
                width="300"
                trigger="hover"
                content="您可通过输入精准的医院机构名称或组织机构代码，自动搜索后添加已存在的非本客户下的机构，机构信息无法修改，可选择隶属关系。"
              >
                <el-button class="tipButton" slot="reference"
                  ><i class="iconfont tipIcon">&#xe720;</i></el-button
                >
              </el-popover>
            </el-form-item>
          </el-col>
          <el-col :span="9" class="fl w_500">
            <el-form-item label="组织机构代码 :" prop="code">
              <el-input
                v-if="isAdd"
                placeholder="组织机构代码"
                v-model="organInfo.code"
                class="w_300"
                @blur="onCheckExistsWhileNhc('code')"
              ></el-input>
              <el-input
                :disabled="stopUpdateInstitute"
                v-else
                placeholder="组织机构代码"
                v-model="organInfo.code"
                class="w_300"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="9" class="fl w_500">
            <el-form-item label="机构简称 :" prop="abbreviation">
              <el-input
                :disabled="stopUpdateInstitute"
                placeholder="请输入8个字以内的机构简称"
                v-model="organInfo.abbreviation"
                class="w_300"
              ></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="9" class="fl w_500">
            <el-form-item label="平台机构代码 :" prop="downward_code">
              <el-input
                :disabled="stopUpdateInstitute"
                placeholder="请输入平台机构代码"
                v-model="organInfo.downward_code"
                class="w_300"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="9" class="fl w_500">
            <el-form-item
              label="机构管理员 :"
              prop="admin_phone"
              style="width: 440px"
            >
              <el-row>
                <el-col :span="12">
                  <el-form-item prop="admin_phone">
                    <el-popover placement="top" width="160" v-model="visible">
                      <p class="popoverLabel">
                        该管理员属于<span class="instituteName">{{
                          adminInstituteInfo.institution_name
                        }}</span
                        >机构
                      </p>
                      <p class="popoverLabel">是否添加该机构</p>
                      <div style="text-align: right; margin: 0">
                        <el-button
                          size="mini"
                          type="text"
                          @click="cancelGetInstituteDetail"
                          >取消</el-button
                        >
                        <el-button
                          type="primary"
                          size="mini"
                          @click="sureGetInstituteDetail"
                          >添加</el-button
                        >
                      </div>
                    </el-popover>
                    <!--是卫健委时  不允许编辑-->
                    <!-- <el-input
                      class="w_150"
                      :disabled="(getInstituteDetailSuc) || stopUpdateInstitute"
                      v-model="organInfo.admin_phone"
                      @blur="inputName"
                      @input="changePhone"
                      placeholder="管理员电话"
                    ></el-input> -->
                    <el-input
                      class="w_150"
                      :disabled="stopUpdateInstitute"
                      v-model="organInfo.admin_phone"
                      @blur="inputName"
                      @input="changePhone"
                      placeholder="管理员电话"
                    ></el-input>
                  </el-form-item>
                </el-col>

                <el-col :span="12">
                  <el-form-item prop="admin_name">
                    <el-input
                      class="ml5 w_150"
                      v-model="organInfo.admin_name"
                      placeholder="管理员姓名"
                      :disabled="
                        stopUpdateInstitute || isphoneNameListitem
                          ? true
                          : false
                      "
                    ></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form-item>
          </el-col>
          <el-col :span="9" class="fl w_500">
            <el-form-item label="HIS机构代码 :" prop="upward_code">
              <el-input
                :disabled="stopUpdateInstitute"
                placeholder="请输入HIS机构代码"
                v-model="organInfo.upward_code"
                class="w_300"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="9" class="fl w_500">
            <el-form-item label="机构类型 :" prop="type_code">
              <el-select
                filterable
                :disabled="stopUpdateInstitute"
                v-model="organInfo.type_code"
                placeholder="请选择"
                class="w_300"
              >
                <el-option
                  v-for="item in InstitutionType"
                  :key="item.dic_code"
                  :label="item.dic_name"
                  :value="item.dic_code"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="9" class="fl w_500">
            <el-form-item label="机构类别 :" prop="nature_code">
              <el-select
                filterable
                :disabled="stopUpdateInstitute"
                v-model="organInfo.nature_code"
                placeholder="请选择"
                class="w_300"
              >
                <el-option
                  v-for="item in HospitalKind"
                  :key="item.dic_code"
                  :label="item.dic_name"
                  :value="item.dic_code"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="9" class="fl w_500">
            <el-form-item label="医院等级 :" prop="level_code">
              <el-select
                filterable
                :disabled="stopUpdateInstitute"
                v-model="organInfo.level_code"
                placeholder="请选择"
                class="w_300"
              >
                <el-option
                  v-for="item in HospitalLevel"
                  :key="item.dic_code"
                  :label="item.dic_name"
                  :value="item.dic_code"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="9" class="fl w_500">
            <el-form-item label="经营性质 :" prop="business_nature_code">
              <el-select
                filterable
                :disabled="stopUpdateInstitute"
                v-model="organInfo.business_nature_code"
                placeholder="请选择"
                class="w_300"
              >
                <el-option
                  v-for="item in InstitutionBusinessNature"
                  :key="item.dic_code"
                  :label="item.dic_name"
                  :value="item.dic_code"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="9" class="fl w_500">
            <el-form-item class="addressInput" label="通讯地址 :">
              <el-cascader
                :disabled="stopUpdateInstitute"
                ref="cascaderAddr"
                filterable
                placeholder="请选择省/市/区"
                :style="{ width: '300px' }"
                v-model="city.cityValue"
                :options="city.cityJson"
                :key="1"
                @change="getCityCodeFn"
                @active-item-change="childrenCity"
              >
              </el-cascader>
              <div>
                <el-input
                  :disabled="stopUpdateInstitute"
                  class="w_300 el-input mt8"
                  v-model="organInfo.address"
                  placeholder="详细信息"
                ></el-input>
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="9" class="fl w_500">
            <el-form-item label="隶属关系 :">
              <el-radio-group v-model="organInfo.subordination">
                <el-radio
                  v-for="(item, index) in baseInfo.institution_subordination"
                  :key="index"
                  :label="item.value"
                  >{{ item.name }}</el-radio
                >
              </el-radio-group>
            </el-form-item>
            <el-form-item class="ordinalInput" label="排序号 :">
              <!-- <el-input-number class="inputNumber"  v-model="organInfo.ordinal" controls-position="right" placeholder="请输入大于0的整数"  :min="1" :step="1" :precision="0"></el-input-number> -->
              <el-input
                class="w_300"
                v-model="organInfo.ordinal"
                placeholder="请输入大于0的整数"
                @blur="checkNumber()"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="9" class="fl w_500">
            <el-form-item label="经纬度 :" prop="longitude">
              <el-input
                :disabled="stopUpdateInstitute"
                placeholder="输入经度"
                v-model="organInfo.longitude"
                class="w_145"
              ></el-input>
              <el-input
                :disabled="stopUpdateInstitute"
                placeholder="输入纬度"
                v-model="organInfo.latitude"
                class="w_145 ml10"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="9" class="fl w_500">
            <el-form-item class="regional_nature" label="行政级别 :">
              <el-radio-group
                v-model="organInfo.regional_nature_code"
                :disabled="stopUpdateInstitute"
              >
                <el-radio
                  v-for="(item, index) in RegionalNatureArr"
                  :key="index"
                  :label="item.dic_code"
                  >{{ item.dic_name }}</el-radio
                >
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="isImg">
          <el-col :span="6" class="fl w_500">
            <el-form-item class="" label="机构logo :">
              <uploadImg
                :disabled="stopUpdateInstitute"
                @chooseUploadImg="chooseUploadImg"
                @uploadSuc="uploadSuc"
                :ImgSrc="this.organInfo.logo_image"
                :UploadSrc="UploadSrc"
                :imgClass="'logo'"
                :isAutoUpload="true"
              ></uploadImg>
              <div
                v-if="!this.organInfo.logo_image"
                class="f13 lh25 clr_oarange"
              >
                支持jpg、jpeg、bmp、gif、png格式；大小不超过2M
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6" class="fl w_500">
            <el-form-item class="" label="宣传图片 :">
              <uploadImg
                :disabled="stopUpdateInstitute"
                @chooseUploadImg="chooseUploadImg"
                @uploadSuc="uploadSuc"
                :ImgSrc="this.organInfo.propaganda_image"
                :UploadSrc="UploadSrc"
                :imgClass="'banner'"
                :isAutoUpload="true"
              ></uploadImg>
              <div
                v-if="!this.organInfo.propaganda_image"
                class="f13 lh25 clr_oarange"
              >
                支持jpg、jpeg、bmp、gif、png格式；大小不超过2M
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6" class="fl w_500">
            <el-form-item class="" label="医疗机构执业许可证:">
              <uploadImg
                :disabled="stopUpdateInstitute"
                @chooseUploadImg="chooseUploadImg"
                @uploadSuc="uploadSuc"
                :ImgSrc="this.organInfo.license_image"
                :UploadSrc="UploadSrc"
                :imgClass="'license'"
                :isAutoUpload="true"
              ></uploadImg>
              <div
                v-if="!this.organInfo.license_image"
                class="f13 lh25 clr_oarange"
              >
                支持jpg、jpeg、bmp、gif、png格式；大小不超过2M
              </div>
            </el-form-item>
          </el-col>
        </el-row>

        <div
          class="chooseMoreUpload"
          @click="uploadMore"
          v-if="!needUploadMore && isAdd"
        >
          上传更多<i class="iconfont">&#xe7b1;</i>
        </div>
        <div
          class="chooseMoreUpload"
          @click="uploadMore"
          v-if="!needUploadMore && !isAdd"
        >
          查看更多<i class="iconfont">&#xe7b1;</i>
        </div>
        <el-row v-if="isImg && needUploadMore">
          <el-col :span="6" class="fl w_500">
            <el-form-item class="" label="机构资质 :">
              <uploadImg
                :disabled="stopUpdateInstitute"
                @chooseUploadImg="chooseUploadImg"
                @uploadSuc="uploadSuc"
                :ImgSrc="this.organInfo.qualification_image"
                :UploadSrc="UploadSrc"
                :imgClass="'native'"
                :isAutoUpload="true"
              ></uploadImg>
              <div
                v-if="!this.organInfo.qualification_image"
                class="f13 lh25 clr_oarange"
              >
                支持jpg、jpeg、bmp、gif、png格式；大小不超过2M
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6" class="fl w_500">
            <el-form-item class="" label="等级证书 :">
              <uploadImg
                :disabled="stopUpdateInstitute"
                @chooseUploadImg="chooseUploadImg"
                @uploadSuc="uploadSuc"
                :ImgSrc="this.organInfo.level_certificate_image"
                :UploadSrc="UploadSrc"
                :imgClass="'levelCa'"
                :isAutoUpload="true"
              ></uploadImg>
              <div
                v-if="!this.organInfo.level_certificate_image"
                class="f13 lh25 clr_oarange"
              >
                支持jpg、jpeg、bmp、gif、png格式；大小不超过2M
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6" class="fl w_500">
            <el-form-item class="" label="放射诊疗许可证:">
              <uploadImg
                :disabled="stopUpdateInstitute"
                @chooseUploadImg="chooseUploadImg"
                @uploadSuc="uploadSuc"
                :ImgSrc="this.organInfo.radiology_license_image"
                :UploadSrc="UploadSrc"
                :imgClass="'ris'"
                :isAutoUpload="true"
              ></uploadImg>
              <div
                v-if="!this.organInfo.radiology_license_image"
                class="f13 lh25 clr_oarange"
              >
                支持jpg、jpeg、bmp、gif、png格式；大小不超过2M
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <div
          class="chooseMoreUpload"
          @click="needUploadMore = false"
          v-if="needUploadMore"
        >
          收起<i class="iconfont">&#xe7b1;</i>
        </div>
        <el-row>
          <el-col :span="18">
            <el-form-item
              class="medicalSubject"
              label="诊疗科目 :"
              prop="footer"
              style="min-width: 956px"
            >
              <el-input
                :disabled="stopUpdateInstitute"
                type="textarea"
                v-model="organInfo.medical_department"
                style="min-height: 60px"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item
              class=""
              label="机构简介 :"
              prop="intriduce"
              style="min-width: 956px"
            >
              <!-- <quill-editor
                @focus="focusOnIntroduction($event)"
                :ref="organInfo.introduction"
                v-model="organInfo.introduction"
                :content="organInfo.introduction"
                class="myQuillEditor"
                :options="editorOption"
              /> -->
              <quill-editor
                @focus="focusOnIntroduction($event)"
                ref="introduction"
                v-model="organInfo.introduction"
                :content="organInfo.introduction"
                class="myQuillEditor"
                :options="editorOption"
              />
              <form action="" method="post" enctype="multipart/form-data" id="uploadFormMulti">
                 <input style="display: none" :id="uniqueId" type="file" name="files" multiple accept="image/jpg,image/jpeg,image/png,image/gif" @change="uploadEditImg('uploadFormMulti')">
              </form>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item>
          <el-button
            type="primary"
            size="medium"
            class="mt5"
            @click="onSubmit('organInfo')"
            >保存</el-button
          >
        </el-form-item>
      </el-form>
    </div>
</template>
<script>
import Vue from "vue";
import JSEncrypt from "jsencrypt";
import Mgr from "@/utils/SecurityService";
import { quillEditor } from "vue-quill-editor";
import Quill from "quill";
import "quill/dist/quill.core.css";
import "quill/dist/quill.snow.css";
import "quill/dist/quill.bubble.css";
import UploadImg from "@/components/common/uploadImg";
import {
  addInstitution,
  putInstitution,
  getInstitutionInfoDetail,
  getAnyInstitutionInfoDetail,
} from "@/api/platform_costomer/institution";
import {
  getDistinfoByType,
  getCityJson,
  getLoginName,
  getInstituteLogo,
  getPropaganda,
  getLicense,
  getQualification,
  getLevelCertificate,
  getRadiologyLicense,
  getConfigurations,
  uploadMediaFile,
} from "@/api/commonHttp";
import {
  CityLinkedJson,
  getBase64,
  connectUrlParam,
} from "@/components/commonJs";
import { getCostomerInfoDetail } from "@/api/platform_operate/costomer";
import { mapGetters } from "vuex";
// form表单电话验证
var checkPhone = (rule, value, callback) => {
  if (!value) {
    return callback(new Error("请输入管理员电话"));
  } else {
    const reg = /^1[3456789]\d{9}$/;
    if (reg.test(value)) {
      callback();
    } else {
      return callback(new Error("请输入正确的手机号"));
    }
  }
};

const DEFAULT_INFO = {
  // 机构详情
  name: "",
  abbreviation: "",
  admin_name: "",
  admin_phone: "",
  upward_code: "",
  downward_code: "",
  code: "",
  ordinal: "",
  regional_nature_code: "",
  type_code: "",
  nature_code: "",
  level_code: "",
  business_nature_code: "",
  longitude: "",
  latitude: "",
  province_code: "",
  province: "",
  city_code: "",
  city: "",
  district_code: "",
  district: "",
  address: "",
  introduction: "",
  medical_department: "",
  logo_image: "",
  propaganda_image: "",
  license_image: "",
  qualification_image: "",
  level_certificate_image: "",
  radiology_license_image: "",
  subordination: 1,
};

export default {
  components: {
    quillEditor,
    UploadImg,
  },
  data() {
    return {
      tenancyId: "",
      needUploadMore: false,
      stopUpdateInstitute: false,
      visible: false,
      getInstituteDetailSuc: false,
      isCollectImg: false,
      UploadSrc: "#",
      isNHC: false, // 是否是卫健委
      isAdd: true,
      isImg: false,
      titletext: "新增机构",
      value: "",
      InstitutionType: [], // 机构类型
      HospitalKind: [], // 机构性质
      HospitalLevel: [], // 医院等级
      RegionalNatureArr: [], // 区域性质
      InstitutionBusinessNature: [], // 经营性质
      city: {
        cityValue: [],
        cityJson: [],
        city_parmas: {
          parent_code: "1",
          level: 1,
        },
      },
      editorOption: {
        // 富文本参数
        placeholder: "请在这里输入",
        modules: {
          toolbar: [
            [
              "bold",
              "color",
              "background",
              "underline",
              "strike",
              "image",
              "blockquote",
              "code-block",
              "align",
            ],
          ],
        },
      },
      adminInstituteInfo: {},
      organFormData: new CompatibleFormData(),
      isphoneNameListitem: true,
      organInfo: { ...DEFAULT_INFO },
      rules: {
        name: [
          { required: true, message: "请输入机构名称", trigger: "change" },
        ],
        code: [
          { required: true, message: "请选择组织机构代码", trigger: "change" },
        ],
        admin_name: [
          { required: true, message: "请输入管理员姓名", trigger: "change" },
        ],
        admin_phone: [
          //{ required: true, validator: checkPhone, trigger: "change" },
          { required: true, message: "请输入管理员电话", trigger: "change" },
        ],
        abbreviation: [
          { required: true, message: "请输入机构简称", trigger: "change" },
          { max: 8, message: "机构简称长度不能超过8个字", trigger: "change" },
        ],
        type_code: [
          { required: true, message: "请选择机构类型", trigger: "change" },
        ],
        level_code: [
          { required: true, message: "请选择医院等级", trigger: "change" },
        ],
      },
      isFirstChange: true,
      ischeckphone: false,
      isCommit: false,
      changedOptions: {
        name: false,
        code: false,
      },
      state: {
        populated: false, // 卫健委客户下，标记是否获取了已有客户进行数据填充，用于下次获取不到用户时清空视图模型
      },
      addImgRange: "",
      uniqueId: "testUpload",
    };
  },
  watch: {
    $route(to, from) {
      if (to.name === "AddOrgain") {
        this.initInfo();
      }
    },
    "organInfo.name": {
      handler: function () {
        this.changedOptions.name = true;
      },
      deep: true,
    },
    "organInfo.code": {
      handler: function () {
        this.changedOptions.code = true;
      },
      deep: true,
    },
  },
  computed: {
    ...mapGetters({
      // 获取store查询枚举条件
      baseInfo: "enumerations",
    }),
    // 智能诊断系统
    intelligentDiagnosis () {
      if (this.$route.meta.intelligentDiagnosis) {
        return true
      }
      return false
    }
  },
  mounted() {
    const vm = this
    vm.getTenancyId();
    vm.initInfo();
    vm.getConfigurationsFn();
    var imgHandler = async function (image) {
      vm.addImgRange = vm.$refs.introduction.quill.getSelection();
      if (image) {
        var fileInput = document.getElementById(vm.uniqueId); //隐藏的file文本ID
        fileInput.click(); //加一个触发事件
      }
    };
    vm.$nextTick(() => {
      vm.$refs.introduction.quill.getModule("toolbar").addHandler("image", imgHandler);
    })
  },
  methods: {
    async getConfigurationsFn() {
      const res = await getConfigurations("TransmissionSecurity.RSA.PublicKey");
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) {
          // 注册方法
          const pubKey = res.data; // ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt();
          encryptStr.setPublicKey(pubKey); // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()); // 进行加密
          return data;
        };
      }
    },
    changePhone() {
      if (!this.isAdd) {
        // 是否是第一次改变
        if (this.isFirstChange) {
          this.organInfo.admin_phone = "";
          this.organInfo.admin_name = "";
        }
        this.isFirstChange = false;
      }
    },
    getTenancyId() {
      const self = this;
      var manager = new Mgr();
      manager.getRole().then(function (logindata) {
        self.tenancyId = sessionStorage.getItem('curTenancyId') || logindata.profile.tenancy_id;
      });
    },
    //获取焦点事件
    focusOnIntroduction(quill) {
      quill.enable(!this.stopUpdateInstitute); //设置富文本编辑器不可编辑
    },
    checkNumber() {
      // this.organInfo.ordinal = this.organInfo.ordinal.replace(/[^1-9]/g, '');
      var regNumber = /^\+?[1-9][0-9]*$/;
      if (regNumber.test(this.organInfo.ordinal) == false) {
        this.$message({ message: "排序号必须是大于0的整数", type: "error" });
        return;
      }
      return true;
    },
    sureGetInstituteDetail() {
      this.visible = false;
      // 获取机构详情之前 先清空通讯地址
      this.city.cityValue = [];
      this.getInstitutionInfoByidFn({
        id: this.adminInstituteInfo.institution_id,
      });
    },
    cancelGetInstituteDetail() {
      this.visible = false;
      this.organInfo.admin_phone = "";
      this.organInfo.admin_name = "";
    },
    async onCheckExistsWhileNhc(type) {
      // 非卫健委
      // if (this.isNHC !== true) return false;
      // 检索项未变更
      if (this.changedOptions[type] !== true) return false;
      const value = this.organInfo[type]?.replace(/[\s]/g, "");
      if (!value || !value.length) return false;
      const query = {};
      query[type] = value;

      const exists = await this.getInstitutionInfoByidFn(
        query,
        "instituteCode"
      );

      // 防止重复查询
      this.changedOptions.name = false;
      this.changedOptions.code = false;

      if (this.state.populated && exists !== true) {
        const without = { ...DEFAULT_INFO };
        delete without[type];
        Object.assign(this.organInfo, without);
      }

      this.state.populated = exists;
    },
    uploadMore() {
      this.needUploadMore = true;
    },
    initInfo() {
      this.getDistinfoFn();
      this.isImg = true;
      if (this.$route.query.id) {
        this.titletext = "编辑机构";
        this.isAdd = false;
        this.isFirstChange = true;
        this.getInstitutionInfoByidFn({ id: this.$route.query.id });
      } else {
        this.$refs["organInfo"].resetFields();
        this.city = this.$options.data().city;
        this.organFormData = this.$options.data().organFormData;
        this.organInfo = this.$options.data().organInfo;
        this.titletext = "新增机构";
        this.isAdd = true;
        this.getPlatInfor();
      }
      this.getCityJsonFn(this.city.city_parmas);
    },
    // 获取平台信息
    async getPlatInfor() {
      const res = await getCostomerInfoDetail();
      if (res.code === 0) {
        // 判断是否是卫健委
        if (res.data.type === 4) {
          this.isNHC = true;
        } else {
          this.isNHC = false;
        }
      } else {
        this.$message.error(res.msg);
      }
    },
    // 获取字典列表
    async getDistinfoFn() {
      var _parmas =
        "InstitutionType,InstitutionBusinessNature,HospitalLevel,HospitalKind,RegionalNature";
      var _url = `/dict/${_parmas}`;
      const res = await getDistinfoByType(_url);
      if (res.code !== 0 || res.data.length === 0) {
        return;
      }
      var iT = [];
      var iB = [];
      var iL = [];
      var iK = [];
      var RN = [];
      res.data.forEach((item) => {
        if (item.lookup_key === "InstitutionType") {
          iT.push(item);
        }
        if (item.lookup_key === "InstitutionBusinessNature") {
          iB.push(item);
        }
        if (item.lookup_key === "HospitalLevel") {
          iL.push(item);
        }
        if (item.lookup_key === "HospitalKind") {
          iK.push(item);
        }
        if (item.lookup_key === "RegionalNature") {
          RN.push(item);
        }
      });
      this.InstitutionType = iT;
      this.InstitutionBusinessNature = iB;
      this.HospitalLevel = iL;
      this.HospitalKind = iK;
      this.RegionalNatureArr = RN;
    },
    // input监听输入管理员电话
    async inputName(val) {
      const reg = /^1[3456789]\d{9}$/;
      // 对手机号码进行验证是否规范 (新增的时候、编辑的时候修改过手机号)
      if (this.isAdd || (!this.isAdd && !this.isFirstChange)) {
        if (
          this.organInfo.admin_phone &&
          !reg.test(this.organInfo.admin_phone)
        ) {
          this.$message({ message: "请输入正确的手机号", type: "error" });
          return false;
        }
      }
      var _phone = this.organInfo.admin_phone;
      var url = `/users/lite/${_phone}`;
      var res = await getLoginName(url);
      if (res.code === 0) {
        this.organInfo.admin_name = res.data ? res.data.name : "";
        this.isphoneNameListitem = res.data ? true : false;
        // 如果是 新增 并且客户类型是卫健委  得去获取机构详情
        // if (this.isAdd && this.isNHC) {
        if (this.isAdd) {
          if (res.data.institution_name) {
            this.visible = true;
            this.adminInstituteInfo = {
              institution_id: res.data.institution_id,
              institution_name: res.data.institution_name,
            };
          }
        }
      } else {
        this.organInfo.admin_name = "";
        this.isphoneNameListitem = false;
      }
    },
    // 上传图片成功
    async uploadSuc(params, className) {
      if (this.isCollectImg) {
        let res;
        let param = {
          file_name: params.file.name,
          //file_sha: '123',
          file_size: params.file.size,
          position: 0,
          file_type: 0,
        };
        let paramUrl = connectUrlParam(param);
        const formData = new FormData();
        if (className === "logo") {
          formData.append("file", params.file);
          res = await uploadMediaFile(formData, paramUrl);
        } else if (className === "banner") {
          formData.append("file", params.file);
          res = await uploadMediaFile(formData, paramUrl);
        } else if (className === "license") {
          formData.append("file", params.file);
          res = await uploadMediaFile(formData, paramUrl);
        } else if (className === "native") {
          formData.append("file", params.file);
          res = await uploadMediaFile(formData, paramUrl);
        } else if (className === "levelCa") {
          formData.append("file", params.file);
          res = await uploadMediaFile(formData, paramUrl);
        } else {
          formData.append("file", params.file);
          res = await uploadMediaFile(formData, paramUrl);
        }
        if (res.code == 0) {
          if (className === "logo") {
            // logo
            this.$set(
              this.organInfo,
              "logo_image",
              URL.createObjectURL(params.file)
            );
            this.organFormData.delete("logo_image");
            this.organFormData.append("logo_image", res.document_id);
          }
          if (className === "banner") {
            // 宣传图
            this.$set(
              this.organInfo,
              "propaganda_image",
              URL.createObjectURL(params.file)
            );
            this.organFormData.delete("propaganda_image");
            this.organFormData.append("propaganda_image", res.document_id);
          }
          if (className === "license") {
            // 营业执照
            this.$set(
              this.organInfo,
              "license_image",
              URL.createObjectURL(params.file)
            );
            this.organFormData.delete("license_image");
            this.organFormData.append("license_image", res.document_id);
          }
          if (className === "native") {
            // 机构资质
            this.$set(
              this.organInfo,
              "qualification_image",
              URL.createObjectURL(params.file)
            );
            this.organFormData.delete("qualification_image");
            this.organFormData.append("qualification_image", res.document_id);
          }
          if (className === "levelCa") {
            // 等级证书
            this.$set(
              this.organInfo,
              "level_certificate_image",
              URL.createObjectURL(params.file)
            );
            this.organFormData.delete("level_certificate_image");
            this.organFormData.append(
              "level_certificate_image",
              res.document_id
            );
          }
          if (className === "ris") {
            // 放射诊疗
            this.$set(
              this.organInfo,
              "radiology_license_image",
              URL.createObjectURL(params.file)
            );
            this.organFormData.delete("radiology_license_image");
            this.organFormData.append(
              "radiology_license_image",
              res.document_id
            );
          }
        } else {
          this.$message({ type: "error", message: res.msg });
        }
      }
    },
    // 选择图片
    chooseUploadImg(file, className, bool) {
      this.isCollectImg = bool;
    },
    // 获取城市json
    async getCityJsonFn(params) {
      const res = await getCityJson(params);
      if (res.code === 0) {
        this.city.cityJson = CityLinkedJson(
          res.data,
          this.city.cityJson,
          params
        );
      }
    },
    async childrenCity(val) {
      val.forEach((item, i) => {
        this.city.city_parmas.parent_code = item;
        this.city.city_parmas.level = i + 2;
      });
      await this.getCityJsonFn(this.city.city_parmas);
    },
    getCityCodeFn(val) {
      var arr = this.getCascaderObj(val, this.city.cityJson);
      arr.forEach((item, i) => {
        if (i === 0) {
          this.organInfo.province_code = item.value;
          this.organInfo.province = item.label;
        } else if (i === 1) {
          this.organInfo.city_code = item.value;
          this.organInfo.city = item.label;
        }
        if (i === 2) {
          this.organInfo.district_code = item.value;
          this.organInfo.district = item.label;
        }
      });
    },
    getCascaderObj(val, opt) {
      return val.map(function (value, index, array) {
        for (var itm of opt) {
          if (itm.value === value) {
            opt = itm.children;
            return itm;
          }
        }
        return null;
      });
    },
    // 获取机构详情
    async getInstitutionInfoByidFn(param, instituteCode) {
      this.stopUpdateInstitute = false;
      let res;
      if (instituteCode) {
        //通过输入机构代码查询 可以查询出其它客户下的机构详情(跨客户)
        res = await getAnyInstitutionInfoDetail(param);
      } else {
        res = await getInstitutionInfoDetail(param); // 本客户下的机构详情
      }
      if (res.code === 0) {
        this.getInstituteDetailSuc = true;
        this.organInfo = res.data;
        if (
          !res.data.hasOwnProperty("admin_name") &&
          !res.data.hasOwnProperty("admin_phone")
        ) {
          this.$set(this.organInfo, "admin_name", "");
          this.$set(this.organInfo, "admin_phone", "");
        }
        // 判断是否是其他客户  其他客户不让修改本机构信息(除了排序号)
        if (this.tenancyId === res.data.tenancy_id) {
          this.stopUpdateInstitute = false;
        }
        // else if (this.isNHC) {
        //   this.stopUpdateInstitute = true;
        // }
        else {
          this.stopUpdateInstitute = true;
        }
        if (res.data.province_code) {
          await this.echoCityinfo(
            res.data.province_code,
            res.data.city_code,
            res.data.district_code
          );
          this.city.cityValue = [
            res.data.province_code,
            res.data.city_code,
            res.data.district_code,
          ];
        }
        if (res.data.logo_image !== "") {
          await getInstituteLogo(res.data.id)
            .then((imgFile) => {
              if (imgFile) {
                getBase64(imgFile).then((result) => {
                  this.organInfo.logo_image = result;
                  //console.log("result", result);
                });
              } else {
                this.organInfo.logo_image = "";
              }
            })
            .catch((error) => {
              console.log(error);
            });
        } else {
          this.organInfo.propaganda_image = "";
        }
        if (res.data.propaganda_image !== "") {
          await getPropaganda(res.data.id)
            .then((imgFile) => {
              if (imgFile) {
                getBase64(imgFile).then((result) => {
                  this.organInfo.propaganda_image = result;
                });
              } else {
                this.organInfo.propaganda_image = "";
              }
            })
            .catch((error) => {
              console.log(error);
            });
        } else {
          this.organInfo.propaganda_image = "";
        }
        if (res.data.license_image !== "") {
          await getLicense(res.data.id)
            .then((imgFile) => {
              if (imgFile) {
                getBase64(imgFile).then((result) => {
                  this.organInfo.license_image = result;
                });
              } else {
                this.organInfo.license_image = "";
              }
            })
            .catch((error) => {
              console.log(error);
            });
        } else {
          this.organInfo.license_image = "";
        }
        // 机构资质
        if (res.data.qualification_image !== "") {
          await getQualification(res.data.id)
            .then((imgFile) => {
              if (imgFile) {
                getBase64(imgFile).then((result) => {
                  this.organInfo.qualification_image = result;
                });
              } else {
                this.organInfo.qualification_image = "";
              }
            })
            .catch((error) => {
              console.log(error);
            });
        } else {
          this.organInfo.qualification_image = "";
        }
        // 机构等级
        if (res.data.level_certificate_image !== "") {
          await getLevelCertificate(res.data.id)
            .then((imgFile) => {
              if (imgFile) {
                getBase64(imgFile).then((result) => {
                  this.organInfo.level_certificate_image = result;
                });
              } else {
                this.organInfo.level_certificate_image = "";
              }
            })
            .catch((error) => {
              console.log(error);
            });
        } else {
          this.organInfo.level_certificate_image = "";
        }
        // 机构等级
        if (res.data.radiology_license_image !== "") {
          await getRadiologyLicense(res.data.id)
            .then((imgFile) => {
              if (imgFile) {
                getBase64(imgFile).then((result) => {
                  this.organInfo.radiology_license_image = result;
                });
              } else {
                this.organInfo.radiology_license_image = "";
              }
            })
            .catch((error) => {
              console.log(error);
            });
        } else {
          this.organInfo.radiology_license_image = "";
        }
        return res.data != null;
        // this.organInfo.propaganda_image = res.data.propaganda_image === '0' ? '' : getImgSrcById(res.data.propaganda_image)
        // this.organInfo.license_image = res.data.license_image === '0' ? '' : getImgSrcById(res.data.license_image)
      } else {
        // 如果有上一次机构的详情就把申请数据质控（这次没查到该机构的详情 但是上次查到了 把上次的数据清空）
        // if (this.organInfo.id) {
        //   this.organInfo = this.$options.data().organInfo
        // }
        this.getInstituteDetailSuc = false;
        this.city.cityValue = [];
        this.$message({ message: res.msg,type: "error",});
        return false;
      }
    },
    // 回显城市联动
    async echoCityinfo(province, city, district) {
      var _provinceparmas = {
        parent_code: province,
        level: 1,
      };
      var _cityparmas = {
        parent_code: city,
        level: 2,
      };
      var _districtparmas = {
        parent_code: district,
        level: 3,
      };
      var _provincejson = [];
      var _cityjson = [];
      var _districtjson = [];
      // 一级
      const _provinceres = await getCityJson(_provinceparmas);
      _provinceres.data.forEach((item) => {
        var info = {
          label: "",
          value: "",
        };
        info.children = [];
        info.label = item.name;
        info.value = item.code;
        _provincejson.push(info);
      });
      this.city.cityJson = _provincejson;
      // 二级
      const _cityres = await getCityJson(_cityparmas);
      _cityres.data.forEach((item) => {
        var info = {
          label: "",
          value: "",
        };
        info.children = [];
        info.label = item.name;
        info.value = item.code;
        _cityjson.push(info);
      });
      this.city.cityJson.forEach((item) => {
        if (item.value === _provinceparmas.parent_code) {
          item.children = _cityjson;
        }
      });
      // 三级
      const _districtres = await getCityJson(_districtparmas);
      _districtres.data.forEach((item) => {
        var info = {
          label: "",
          value: "",
        };
        info.label = item.name;
        info.value = item.code;
        _districtjson.push(info);
      });
      this.city.cityJson.forEach((itemlevel) => {
        itemlevel.children.forEach((item) => {
          if (item.value === _cityparmas.parent_code) {
            item.children = _districtjson;
          }
        });
      });
    },
    // 返回
    goBack() {
      this.$router.go(-1);
    },
    // 删除formdata值
    deleteFormDataKey() {
      this.organFormData.delete("id");
      this.organFormData.delete("name");
      this.organFormData.delete("abbreviation");
      this.organFormData.delete("admin_name");
      this.organFormData.delete("admin_phone");
      this.organFormData.delete("upward_code");
      this.organFormData.delete("downward_code");
      this.organFormData.delete("code");
      this.organFormData.delete("ordinal");
      this.organFormData.delete("regional_nature_code");
      this.organFormData.delete("type_code");
      this.organFormData.delete("level_code");
      this.organFormData.delete("nature_code");
      this.organFormData.delete("business_nature_code");
      this.organFormData.delete("longitude");
      this.organFormData.delete("latitude");
      this.organFormData.delete("province_code");
      this.organFormData.delete("province");
      this.organFormData.delete("city_code");
      this.organFormData.delete("city");
      this.organFormData.delete("district_code");
      this.organFormData.delete("district");
      this.organFormData.delete("address");
      this.organFormData.delete("introduction");
      this.organFormData.delete("medical_department");
      this.organFormData.delete("subordination");
      this.organFormData.delete("parent_id");
      this.organFormData.delete("category");
    },
    // 设置formdata值
    setFormData(formData) {
      if (!this.isAdd) {
        this.organFormData.append("id", this.$route.query.id);
      }
      // 新增&&卫健委&&又成功获取到了详情
      // if (this.isAdd && this.isNHC && this.getInstituteDetailSuc) {
      if (this.isAdd && this.getInstituteDetailSuc) {
        this.organFormData.append("id", this.organInfo.id);
      }
      this.organFormData.append("name", formData.name);
      this.organFormData.append("abbreviation", formData.abbreviation);
      this.organFormData.append("admin_name", formData.admin_name);
      // 对手机号码进行加密
      this.organFormData.append(
        "admin_phone",
        this.$getRsaCode(formData.admin_phone)
      );
      // this.organFormData.append("admin_phone", formData.admin_phone);
      this.organFormData.append(
        "upward_code",
        formData.upward_code ? formData.upward_code : ""
      );
      this.organFormData.append(
        "downward_code",
        formData.downward_code ? formData.downward_code : ""
      );
      this.organFormData.append("code", formData.code);
      if (formData.ordinal) {
        this.organFormData.append("ordinal", formData.ordinal);
      }
      if (formData.regional_nature_code) {
        this.organFormData.append(
          "regional_nature_code",
          formData.regional_nature_code
        );
      }
      this.organFormData.append(
        "type_code",
        formData.type_code ? formData.type_code : ""
      );
      this.organFormData.append(
        "level_code",
        formData.level_code ? formData.level_code : ""
      );
      this.organFormData.append(
        "nature_code",
        formData.nature_code ? formData.nature_code : ""
      );
      this.organFormData.append(
        "business_nature_code",
        formData.business_nature_code ? formData.business_nature_code : ""
      );
      if (formData.longitude) {
        this.organFormData.append("longitude", formData.longitude);
      }
      if (formData.latitude) {
        this.organFormData.append("latitude", formData.latitude);
      }
      this.organFormData.append(
        "province_code",
        formData.province_code ? formData.province_code : ""
      );
      this.organFormData.append(
        "province",
        formData.province ? formData.province : ""
      );
      this.organFormData.append(
        "city_code",
        formData.city_code ? formData.city_code : ""
      );
      this.organFormData.append("city", formData.city ? formData.city : "");
      this.organFormData.append(
        "district_code",
        formData.district_code ? formData.district_code : ""
      );
      this.organFormData.append(
        "district",
        formData.district ? formData.district : ""
      );
      this.organFormData.append(
        "address",
        formData.address ? formData.address : ""
      );
      this.organFormData.append(
        "introduction",
        formData.introduction ? formData.introduction : ""
      );
      this.organFormData.append(
        "medical_department",
        formData.medical_department ? formData.medical_department : ""
      );
      this.organFormData.append(
        "subordination",
        formData.subordination ? formData.subordination : ""
      );

      if (this.intelligentDiagnosis) {
        this.organFormData.append(
          "system_id", sessionStorage.getItem('system_id')
        );
      }
      this.organFormData.append("category", 1);
    },
    onSubmit(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.deleteFormDataKey();
          this.setFormData(this.organInfo);
          let loadingText;
          if (this.$route.query.id) {
            loadingText = "正在编辑，请稍等...";
          } else {
            loadingText = "正在新增，请稍等...";
          }
          const loading = this.$loading({
            lock: true,
            text: loadingText,
            spinner: "el-icon-loading",
            background: "rgba(255, 255, 255, 0.6)",
          });
          // 新增的时候并且不是卫健委、新增的时候是卫健委但没获取到机构详情 时调用新增接口 其它情况调用编辑接口
          // if ((this.isAdd && !this.isNHC) ||(this.isAdd && this.isNHC && !this.getInstituteDetailSuc)) {
          if (this.isAdd && !this.getInstituteDetailSuc) {
            const response = addInstitution(this.organFormData.compatible());
            response.then((res) => {
              loading.close();
              if (res.code === 0) {
                this.$message({
                  message: "新增机构成功！",
                  type: "success",
                });
                var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
                this.$router.push({path:basepath+'/MedicalInstitution/institutionList'});
                this.isImg = false;
              } else {
                this.$message({
                  message: res.msg,
                  type: "error",
                });
                loading.close();
              }
            });
          } else {
            const response = putInstitution(
              this.$route.query.id || this.organInfo.id,
              this.organFormData.compatible()
            );
            response.then((res) => {
              loading.close();
              if (res.code === 0) {
                this.$message({
                  message: "修改机构信息成功！",
                  type: "success",
                });
                var basepath = process.env.NODE_ENV === 'development' ? '' : '/operate'
                this.$router.push({path:basepath+'/MedicalInstitution/institutionList'});
              } else {
                this.$message({
                  message: res.msg,
                  type: "error",
                });
                loading.close();
              }
              this.isCommit = false;
            });
          }
        } else {
          // this.$refs[formName].resetFields()
        }
      });
    },
    async uploadEditImg(id) {
      var vm = this;
      var obj = document.getElementById("uploadFormMulti");
      // 获取文件对象
      var fileObj = document.getElementById(vm.uniqueId);
      var file = fileObj.files[0]; 
      var fileName = file.name
      var fileSize = file.size
      var formData = new FormData(obj);
      formData.append('file_name',fileName)
      try {
        vm.uploadImgReq(formData,fileName,fileSize); // 自定义的图片上传函数
      } catch ({ message: msg }) {
        document.getElementById(vm.uniqueId).value = "";
        vm.$message.warning(msg);
      }
    },
    // 下载图片
    downloadImg(file_id) {
      const vm = this
      var src = configUrl.docUrl +"/api-document/download/document-id?document_id=" +file_id + "&is_crm_document=true"
      vm.addImgRange = vm.$refs.introduction.quill.getSelection();
      vm.$refs.introduction.quill.insertEmbed(
        vm.addImgRange != null ? vm.addImgRange.index : 0, 
        "image",
        src,
        Quill.sources.USER
      );
    },

    async uploadImgReq(myformData,file_name,file_size) {
       // 这里实现你自己的图片上传
      var vm = this;
       let param = {
        file_name: file_name,
        file_size: file_size,
        position: 0,
        file_type: 0,
      };
      let paramUrl = connectUrlParam(param);
      const res = await uploadMediaFile(myformData,paramUrl);
      if (res.code === 0) {
        const result = res;
        // 获取图片
        vm.downloadImg(result.document_id)
      }
    },
  },
};
</script>

<style>
.el-upload-list {
  width: 250px;
}
.el-input.is-disabled .el-input__inner {
  color: #303133;
}
.el-upload-list--picture .el-upload-list__item-thumbnail {
  width: 100%;
}
.el-upload-list--picture
  .el-upload-list__item.is-success
  .el-upload-list__item-name {
  display: none;
}
.el-upload-dragger {
  width: 310px;
  height: 140px;
  border: 1px solid #c0ccda;
}
.el-upload-dragger .el-icon-upload {
  margin: 20px 0 16px;
}
</style>
<style lang="less" scoped>

.addorgan {
  .iconfont {
    margin: 0px;
  }
  .back:hover {
    color: rgba(10, 112, 176, 1);
  }
  .container {
    padding: 10px 0px;
    // margin: auto;
    background: #fff;
    .clr_ff9 {
      color: #ff9a50;
    }
    .uploadimg {
      width: 320px;
      height: 140px;
    }
  }
}
.inputNumber {
  width: 200px !important;
}
.w_145 {
  width: 145px;
}
::v-deep .inputNumber {
  .el-input__inner {
    height: 32px !important;
    line-height: 32px !important;
  }
  .el-input-number__increase {
    line-height: 16px !important;
    top: 4px !important;
  }
  .el-input-number__decrease {
    line-height: 16px !important;
    bottom: 4px !important;
  }
}
.myQuillEditor {
  ::v-deep .ql-container {
    height: 130px;
  }
}
::v-deep .el-form-item__error {
  padding-top: 0px !important;
}
.tipButton {
  padding: 0 !important;
  margin-left: 10px;
  border: none;
  .tipIcon {
    font-size: 16px;
  }
}
.medicalSubject,
.regional_nature {
  margin-bottom: 10px;
}
.ordinalInput {
  margin-bottom: 5px;
}
::v-deep .addressInput {
  margin-bottom: 10px;
  .el-form-item__content {
    line-height: 21px;
  }
}
.chooseMoreUpload {
  width: 155px;
  text-align: right;
  color: #0a70b0;
  cursor: pointer;
  margin-bottom: 10px;
}
.demo-ruleForm {
  ::v-deep .el-radio {
    margin-right: 5px !important;
  }
}
</style>
