<template>
  <div class="pacs_main" :class="{inIframe: systemType}">
    <head-nav :firstTitle="firstTitle" :subTitle="subTitle"></head-nav>
    <div v-if="systemType" class="tab bb">
      <div
        :class="{ select: tabIndex == 1 }"
        @click="tabIndex = 1"
        class="tabItem"
      >
        影像存档
      </div>
      <div
        :class="{ select: tabIndex == 2 }"
        @click="tabIndex = 2"
        class="tabItem"
      >
        存储域
      </div>
    </div>
    
    <div v-show="tabIndex == 1" class="contentContainer" :class="{ noCardStyle: !cardStyle }">
      <div class="content">
        <div class="main_top">
          <div class="inspectLeft">
            <div class="pt15 column-start">
              <div class="imgBox">
                <el-image :src="logoSrc" class="imgCon">
                  <div
                    slot="error"
                    class="image-slot w100 h100 position_relative bg_f5"
                  >
                    <i
                      class="el-icon-picture-outline f30 position_absolute toCenter clr_ccc"
                    ></i>
                  </div>
                </el-image>
              </div>
              <p class="organizationName">{{ organizationName }}</p>
            </div>
            <div class="pl21 pr21 tl flex_row space_between">
              <div class>
                <p class="inspectLabel">已接入医疗机构</p>
                <span class="inspectVal">{{ institutionCount }}</span>
              </div>
              <i class="dib w1 h51 bg_ddd"></i>
              <div class>
                <p class="inspectLabel">已接入影像设备</p>
                <span class="inspectVal">{{ modalityCount }}</span>
              </div>
            </div>
          </div>
          <div class="inspectRight">
            <div class="inspectTypeCon">
              <div class="todayImageInspect todayTotalInspect">
                <p class="todayImageLabel">今日新增影像检查</p>
                <span class="todayImageVal">{{
                    todayStatistics.total_count
                  }}</span>
              </div>

            
              <div class="scrollTab">
                <span class="leftArrow" @click="scrollTab('left')"><i class="iconfont">&#xe8e5;</i></span>
                <ul class="slider" ref="slider">
                  <li
                    class="todayImageInspect"
                    v-for="(item, index) in list"
                    :key="index"
                  >
                    <p class="todayImageLabel inspectTypeName">{{ index}}</p>
                    <span class="todayImageVal inspectTypeCount">{{ item }}</span>
                  </li>

                  <!-- <li
                    class=""todayImageInspect
                    v-for="(item, index) in todayStatistics.study_counts"
                    :key="index"
                  >
                    <p>{{ item.modalities_in_study }}</p>
                    <span>{{ item.count }}</span>
                  </li> -->
                  <li
                    v-if="
                      todayStatistics.study_counts &&
                      todayStatistics.study_counts.length === 0
                    "
                    class="row"
                  >
                    <div>今日暂无新增影像检查</div>
                  </li>
                </ul>
                <span class="rightArrow" @click="scrollTab('right')"><i class="iconfont ">&#xe8e6;</i></span>
              </div>
            </div>

            <div class="h40 mt10 todayCheck">
              <div class="todayCheckItem mr10">
                <i class="iconfont clr_303 f22i ml20 mr10 vam">&#xe68a;</i>
                <span class="todayCheckLabel">今日影像检查已登记数：</span>
                <span class="numberVal">{{ todayRISCount }}</span>
              </div>
              <div class="todayCheckItem mr10">
                <i class="iconfont clr_303 f22i ml20 mr10 vam">&#xe68b;</i>
                <span class="todayCheckLabel">今日PACS已归档检查数：</span>
                <span class="numberVal">{{ todayStatistics.pacs_count }}</span>
              </div>
              <div class="todayCheckItem todayNoMatchCheck">
                <a @click.prevent="toMatching" class="ml20 cursor">
                  <i class="iconfont clr_ff6f6f f22i mr10 vam">&#xe687;</i>
                  <span class="todayCheckLabel todayNoMatchCheckLabel">今日尚未匹配到影像检查数：</span>
                  <span class="numberVal errorNumberVal">{{ todayStatistics.un_match_count }}</span>
                </a>
              </div>
            </div>
            <div class="moduleTitBox"><span class="icon"></span><span class="moduleTit">策略情况</span></div>
            <div class="strategy f14">
              <div class="strategy_box mr20">
                <div class="strategyCon">
                  <div class="strategyMinBox strategyTitDiv">
                    <!-- <img
                      src="../../assets/images/pacs/routeStrategy.png"
                      class="w20 h20 mr10 vam"
                    /> -->
                    <i class="iconfont">&#xe67c;</i>
                    <span>路由策略</span>
                  </div>
                  <div>
                    <a
                      v-if="!strategyInfo.is_routing_setting"
                      @click.prevent="toStrategyConfig"
                      class="strategyMinBox cursor"
                    >
                      <i class="iconfont clr_c1 f14i mr10 vam">&#xe680;</i>
                      <span class="clr_1C8BE4 bbt_0a70b0">未设置</span>
                    </a>
                    <a
                      v-if="strategyInfo.is_routing_setting"
                      @click.prevent="toStrategyConfig"
                      class="strategyMinBox cursor"
                    >
                      <i class="iconfont clr_1C8BE4 f14i mr10 vam">&#xe681;</i>
                      <span class="clr_1C8BE4 bbt_0a70b0">已设置</span>
                    </a>
                  </div>
                  <div v-if="!strategyInfo.is_routing_running" class="strategyMinBox">
                    <i
                      class="iconfont clr_909 f14i mr10 vam"
                    >&#xe67d;</i>
                    <span class="isRunningLabel">未执行</span>
                  </div>
                  <div v-if="strategyInfo.is_routing_running" class="strategyMinBox">
                    <i
                      class="iconfont clr_49b523 f14i mr10 vam "
                    >&#xe67e;</i>
                    <span class="isRunningLabel">执行中</span>
                    <el-popover placement="top-start" trigger="hover">
                      <div class="pl5 pr5 pt5 pb5">当前正在执行路由任务。</div>
                      <i
                        class="ml10 el-icon-question clr_c0c vam f14i cursor"
                        slot="reference"
                      ></i>
                    </el-popover>
                  </div>
                 </div>
              </div>
              <div class="strategy_box mr20">
                <div class="strategyCon">
                  <div class="strategyMinBox strategyTitDiv">
                    <!-- <img
                      src="../../assets/images/pacs/deleteStrategy.png"
                      class="w20 h20 mr10 vam"
                    /> -->
                    <i class="iconfont">&#xe68ca;</i>
                    <span>删除策略</span>
                  </div>
                  <div>
                    <a
                      v-if="!strategyInfo.is_offline_setting"
                      @click.prevent="toSetSaveStrategy"
                      class="strategyMinBox cursor"
                    >
                      <i class="iconfont clr_c1 f14i mr10 vam">&#xe680;</i>
                      <span class="clr_1C8BE4 bbt_0a70b0">未设置</span>
                    </a>
                    <a
                      v-if="strategyInfo.is_offline_setting"
                      @click.prevent="toSetSaveStrategy"
                      class="strategyMinBox cursor"
                    >
                      <i class="iconfont clr_1C8BE4 f14i mr10 vam">&#xe681;</i>
                      <span class="clr_1C8BE4 bbt_0a70b0">已设置</span>
                    </a>
                  </div>
                  <div v-if="!strategyInfo.is_offline_running" class="strategyMinBox">
                    <i
                      class="iconfont clr_909 f14i mr10 vam"
                    >&#xe67d;</i>
                    <span class="isRunningLabel">未执行</span>
                    <el-popover placement="top-start" trigger="hover">
                      <div class="pl5 pr5 pt5 pb5">
                        服务异常或当前时间不处于策略执行时间内。
                      </div>
                      <i
                        class="ml10 el-icon-question clr_c0c vam f14i cursor"
                        slot="reference"
                      ></i>
                    </el-popover>
                  </div>
                  <div v-if="strategyInfo.is_offline_running" class="strategyMinBox">
                    <i
                      class="iconfont clr_49b523 f14i mr10 vam"
                    >&#xe67e;</i>
                    <span class="isRunningLabel">执行中</span>
                    <el-popover placement="top-start" trigger="hover">
                      <div class="pl5 pr5 pt5 pb5">
                        服务正常且当前时间处于策略执行时间内。
                      </div>
                      <i
                        class="ml10 el-icon-question clr_c0c vam f14i cursor"
                        slot="reference"
                      ></i>
                    </el-popover>
                  </div>
                </div>
              </div>

              <div class="strategy_box">
                <div class="strategyCon">
                  <div class="strategyMinBox strategyTitDiv">
                    <!-- <img
                      src="../../assets/images/pacs/nearLineStrategy.png"
                      class="w20 h20 mr10 vam"
                    /> -->
                    <i class="iconfont">&#xe683;</i>
                    <span>近线策略</span>
                  </div>
                  <div>
                    <a
                      v-if="!strategyInfo.is_nearline_setting"
                      @click.prevent="toSetSaveStrategy"
                      class="strategyMinBox cursor"
                    >
                      <i class="iconfont clr_c1 f14i mr10 vam">&#xe680;</i>
                      <span class="clr_1C8BE4 bbt_0a70b0">未设置</span>
                    </a>
                    <a
                      v-if="strategyInfo.is_nearline_setting"
                      @click.prevent="toSetSaveStrategy"
                      class="strategyMinBox cursor"
                    >
                      <i class="iconfont clr_1C8BE4 f14i mr10 vam">&#xe681;</i>
                      <span class="clr_1C8BE4 bbt_0a70b0">已设置</span>
                    </a>
                  </div>
                  <div v-if="!strategyInfo.is_nearline_running" class="strategyMinBox">
                    <i
                      class="iconfont clr_909 f14i mr10 vam"
                    >&#xe67d;</i>
                    <span class="isRunningLabel">未执行</span>
                    <el-popover placement="top-start" trigger="hover">
                      <div class="pl5 pr5 pt5 pb5">
                        服务异常或当前时间不处于策略执行时间内。
                      </div>
                      <i
                        class="ml10 el-icon-question clr_c0c vam f14i cursor"
                        slot="reference"
                      ></i>
                    </el-popover>
                  </div>
                  <div v-if="strategyInfo.is_nearline_running" class="strategyMinBox">
                    <i
                      class="iconfont clr_49b523 f14i mr10 vam"
                    >&#xe67e;</i>
                    <span class="isRunningLabel">执行中</span>
                    <el-popover placement="top-start" trigger="hover">
                      <div class="pl5 pr5 pt5 pb5">
                        服务正常且当前时间处于策略执行时间内。
                      </div>
                      <i
                        class="ml10 el-icon-question clr_c0c vam f14i cursor"
                        slot="reference"
                      ></i>
                    </el-popover>
                  </div>
                </div>
              </div>

              <div class="strategy_box mt10">
                <div class="strategyCon">
                  <div class="strategyMinBox strategyTitDiv">
                    <!-- <img
                      src="../../assets/images/pacs/backupStrategy.png"
                      class="w20 h14 mr10 vam"
                    /> -->
                    <i class="iconfont">&#xe67b;</i>
                    <span>压缩策略</span>
                  </div>
                  <div>
                    <a
                      v-if="!strategyInfo.is_compress_setting"
                      @click.prevent="toSetSaveStrategy"
                      class="strategyMinBox cursor"
                    >
                      <i class="iconfont clr_c1 f14i mr10 vam">&#xe680;</i>
                      <span class="clr_1C8BE4 bbt_0a70b0">未设置</span>
                    </a>
                    <a
                      v-if="strategyInfo.is_compress_setting"
                      @click.prevent="toSetSaveStrategy"
                      class="strategyMinBox cursor"
                    >
                      <i class="iconfont clr_1C8BE4 f14i mr10 vam">&#xe681;</i>
                      <span class="clr_1C8BE4 bbt_0a70b0">已设置</span>
                    </a>
                  </div>
                  <div v-if="!strategyInfo.is_compress_running" class="strategyMinBox">
                    <i
                      class="iconfont clr_909 f14i mr10 vam "
                    >&#xe67d;</i>
                    <span class="isRunningLabel">未执行</span>
                    <el-popover placement="top-start" trigger="hover">
                      <div class="pl5 pr5 pt5 pb5">
                        服务异常或当前时间不处于策略执行时间内。
                      </div>
                      <i
                        class="ml10 el-icon-question clr_c0c vam f14i cursor"
                        slot="reference"
                      ></i>
                    </el-popover>
                  </div>
                  <div v-if="strategyInfo.is_compress_running" class="strategyMinBox">
                    <i
                      class="iconfont clr_49b523 f14i mr10 vam"
                    >&#xe67e;</i>
                    <span class="isRunningLabel">执行中</span>
                    <el-popover placement="top-start" trigger="hover">
                      <div class="pl5 pr5 pt5 pb5">
                        服务正常且当前时间处于策略执行时间内。
                      </div>
                      <i
                        class="ml10 el-icon-question clr_c0c vam f14i cursor"
                        slot="reference"
                      ></i>
                    </el-popover>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- 服务监控 -->
        <serviceStatus ref="serviceStatus" @sendFetchInfor="sendFetchInfor"></serviceStatus>
        <div class="storageAndDeviceCon">
          <div class="clear_fixed systemStorageBox">
            <div class="bgf systemStorageCon">
              <div v-if="saveDeviceList.length > 0">
                <system-memory
                  boxWidth="w205"
                  boxHeight="h205"
                  :boxText1="allUsedText"
                  :boxText2="allTotalText"
                  boxText1Font="22px Microsoft YaHei"
                  boxText2Font="22px Microsoft YaHei"
                  :boxValue="
                    (allUsed &&
                      allTotal &&
                      parseFloat(allUsed) / parseFloat(allTotal)) ||
                    0
                  "
                ></system-memory>
                <div class="systemStorageTit">系统存储使用</div>
              </div>


               <div class="usage_situation_top">
                <div
                  class="usage_situation_top_item"
                  v-for="(item, index) in tips"
                  :key="index"
                >
                  <div>
                    <span class="usage_situation_top_item_icon"
                      ><i class="iconfont" :class="item.icon"></i
                    ></span>
                    <span>{{ item.name }}：</span>
                    <span v-if="index > 1" class="clr_1cb">
                      <span v-if="!item.subTitle && item.subTitle != 0">
                        暂无数据
                      </span>
                      <span v-else>{{ item.subTitle }}{{ item.title }}</span>
                    </span>

                    <span
                      v-else
                      :class="{
                        clr_1cb: item.value >= 30,
                        clr_ef8: item.value < 30 && item.value >= 10,
                        clr_ff6: item.value < 10,
                      }"
                    >
                      <span v-if="!item.subTitle && item.subTitle != '0%'">
                        暂不支持计算容量
                      </span>
                      <span v-else>
                        {{ item.title }} {{ item.subTitle }}</span
                      ></span
                    >
                  </div>
                  <span v-if="index < 2">
                    <el-button
                      v-popover="`secondPop${index}`"
                      type="text"
                      class="f16 ml10"
                    >
                      <i
                        class="iconfont"
                        :class="{
                          clr_1cb: item.value >= 30,
                          clr_ef8: item.value < 30 && item.value >= 10,
                          clr_ff6: item.value < 10,
                        }"
                        >&#xe720;</i
                      >
                    </el-button>
                    <el-popover
                      :ref="`secondPop${index}`"
                      placement="right"
                      width="300"
                      trigger="hover"
                    >
                      <div class="mr10 ml10 mt10 mb10">
                        <span
                          >只计算所有{{
                            index == 0 ? '在' : '近'
                          }}线文件存储的容量使用情况，无法获取对象存储的容量
                          计算方式：{{
                            index == 0 ? '在' : '近'
                          }}线文件存储剩余容量/{{
                            index == 0 ? '在' : '近'
                          }}线文件存储总容量</span
                        >
                      </div>
                    </el-popover>
                  </span>
                </div>
              </div>
            </div>

            <div class="usage_situation">
              <!-- <div class="usage_situation">  暂时隐藏不能影像其他功能-->

              <!-- <div class="usage_situation_bottom mt5 bgf"> -->

                <div class="usage_situation_bottom_item">
                  <div class="moduleTitBox ml10"><span class="icon"></span><span class="moduleTit">在线设备</span></div>
                  <div class="chartCon">
                    <div v-for="item in onlineDeviceList" :key="item.id">
                      <cloud-memory
                        v-if="item.device_type != 1"
                        boxWidth="w230"
                        boxHeight="h230"
                        :colorStart="item.colorStart"
                        :colorStop="item.colorStop"
                        :totalSpace="item.total_space"
                        :currentSpace="item.current_space"
                        :cloudName="item.device_name"
                      ></cloud-memory>
                      
                      <p v-if="item.device_type != 1" class="someDeviceName">{{ item.device_name }}</p>

                      <div
                        v-else
                        :key="item.id"
                        class="w160 h160 fl bradius8 tc"
                      >
                        <div class="device_item">
                          <img
                            src="../../assets/images/pacs/cloud.png"
                            class="w160 h160"
                            style="margin: 10px auto 0px"
                          />
                          <p class="curDeviceName">{{ item.device_name }}</p>
                        </div>
                      </div>


                    </div>
                    <div class="no-data" v-if="onlineDeviceList.length === 0">
                      <img src="../../assets/images/common/NoData.png" alt="" />
                    </div>
                  </div>
                </div>

                <div class="usage_situation_bottom_item h100">
                  <div class="moduleTitBox ml10"><span class="icon"></span><span class="moduleTit">近线设备</span></div>
                  <div class="chartCon">
                    <div v-for="item in nearDeviceList" :key="item.id">
                      <cloud-memory
                        v-if="item.device_type != 1"
                        boxWidth="w230"
                        boxHeight="h230"
                        :colorStart="item.colorStart"
                        :colorStop="item.colorStop"
                        :totalSpace="item.total_space"
                        :currentSpace="item.current_space"
                        :cloudName="item.device_name"
                      ></cloud-memory>
                      <p v-if="item.device_type != 1" class="someDeviceName">{{ item.device_name }}</p>
                      <div
                        v-else
                        :key="item.id"
                        class="w160 h160 fl bradius8 tc"
                      >
                        <div class="device_item">
                          <img
                            src="../../assets/images/pacs/cloud.png"
                            class="w160 h160"
                            style="margin: 10px auto 0px"
                          />
                          <p class="curDeviceName">{{ item.device_name }}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="no-data" v-if="nearDeviceList.length === 0">
                    <img src="../../assets/images/common/NoData.png" alt="" />
                  </div>
                </div>
            </div>
          </div>
        </div>
        <transition name="slide-fade">
          <el-alert
            v-if="checkTimeErrorAlertShow"
            type="warning"
            description="系统内存在检查时间错误数据！"
            close-text="查看详情"
            show-icon
            @close="checkTimeErrorAlertClose"
            style="
              width: 440px;
              height: 50px;
              position: fixed;
              z-index: 10000;
              right: 0;
              top: 170px;
            "
          ></el-alert>
        </transition>
        <transition name="slide-fade">
          <div
            v-if="checkTimeErrorAlertShow"
            class="dataCheckTip w580 h50 lh50 alert_bshadow bgf bradius4"
            style="position: fixed; right: 0; top: 240px"
          >
            <span class="f14 ml40 mr10">数据校对进度</span>
            <el-progress
              :percentage="dataCheckPercentage"
              :format="dataCheckFormat"
              class="w225 dib"
            ></el-progress>
            <div class="dib f12 clr_999">
              <span>{{ dataCheckCurrent }}</span
              >/
              <span>{{ dataCheckAll }}</span>
            </div>
            <el-link type="danger" :underline="false" class="f12 ml40"
              >已发现错误数 1</el-link
            >
          </div>
        </transition>
        <!-- 数据备份 -->
        <!-- <dataBackup :fetchInforObj="fetchInforObj"></dataBackup> -->
      </div>
    </div>
    <div v-if="systemType" v-show="tabIndex == 2" class="iframeContent">
      <iframe class="pageIframe" :src="iframeSrc"></iframe>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import JSEncrypt from 'jsencrypt'
import HeadNav from '@/components/common/HeadNav' // 头部导航
import SystemMemory from '@/components/pacs/systemMemory' // 水球
import CloudMemory from '@/components/pacs/cloudMemory' // 环形
import moment from 'moment'
import { mapMutations, mapGetters, mapActions } from 'vuex'
import { getUserToken } from '@/api/app'
import { getConfigurations } from '@/api/Public.js'
import Mgr from '@/utils/SecurityService'
import requestForNode from '@/utils/requestForNode'
import serviceStatus from './components/serviceStatus'
import dataBackup from './components/dataBackup'
export default {
  name: 'home',
  data() {
    return {
      tabIndex: 1,
      systemType: null,
      firstTitle: '影像存档',
      subTitle: '存档首页',
      tips: [
        {
          name: '在线容量',
          icon: 'icon-zaixianrongliang',
          title: '剩余容量',
          subTitle: '',
          value: 0,
        },
        {
          name: '近线容量',
          icon: 'icon-jinxianrongliang',
          title: '剩余容量',
          subTitle: '',
          value: 0,
        },
        {
          name: '归档性能',
          icon: 'icon-guidangxingneng',
          title: '幅/s',
          subTitle: '',
          value: 0,
        },
        {
          name: '存档性能',
          icon: 'icon-cundangxingneng',
          title: 'MB/s',
          subTitle: '',
          value: 0,
        },
      ],
      userInfo: {},
      tabActiveName: '0',
      // nodeList: [],
      organizationName: '',

      list: ['Item 1', 'Item 2', 'Item 3', 'Item 4', 'Item 5', 'Item 6', 'Item 7', 'Item 8','Item 9'], // 示例数据
      scrollPosition: 0,
      itemWidth: 140, // 单个li的宽度

      institutionCount: 0,
      modalityCount: 0,
      todayStatistics: {},
      todayRISCount: '',
      strategyInfo: {},
      checkTimeErrorAlertShow: false, // 系统内存在检查时间错误数据
      imgSendPercentage: 0,
      dataCheckCurrent: 0,
      dataCheckAll: 4000,
      apiUrl: '',
      logoSrc: '',
      baseUrl: '',
      saveDeviceList: [],
      nearDeviceList: [],
      onlineDeviceList: [],
      colorArr: [
        { colorStart: '#8D98F0', colorStop: '#6F88E0' },
        { colorStart: '#88D489', colorStop: '#7FD4B2' },
        { colorStart: '#FFD071', colorStop: '#F68C6C' },
        { colorStart: '#F0E48D', colorStop: '#A8E06F' },
        { colorStart: '#D276FF', colorStop: '#BD7FD4' },
        { colorStart: '#EFDA00', colorStop: '#F6E56C' },
      ],
      allText: null,
      allUsed: null,
      allTotal: null,
      allUsedText:null,
      allTotalText: null,
      fetchInforObj: {
        last_run_time: '',
        health_check_time_span_seconds: 0
      }
    }
  },
  computed: {
    ...mapGetters(['cardStyle', 'loginInfo', 'nodeList', 'currentNode']),
    dataCheckPercentage() {
      return Math.floor((this.dataCheckCurrent / this.dataCheckAll) * 100)
    },
    iframeSrc() {
      return `${configUrl.frontEndUrl}/operate/dataStorage/contentManageLayoutBlank?system_id=${this.$store.getters.systemid}&system_type=${this.systemType}`
    }
  },
  watch: {
    currentNode: {
      handler(val) {
        if (val) {
          console.log('首页这里没有执行哦', val, this.$route.path)
          if (this.$route.path == this.baseUrl + '/paserviceHome/index') {
            this.tabActiveName = this.currentNode.node_name
            this.refreshFn()
          }
        }
      },
    },
  },
  provide() {
    return {
      device: this,
    }
  },
  methods: {
    ...mapMutations({
      changeNodeType: 'nodeMessage/SET_NODETYPE',
      setCurrentNode: 'nodeMessage/SET_CURRENTNODE',
    }),
    ...mapActions({
      getNodeList: 'nodeMessage/getNodeList',
      // await store.dispatch('nodeMessage/getNodeList')
    }),
    refreshFn() {
      const self = this
      self.allUsed = null
      self.allTotal = null
      self.allText = null
      self.saveDeviceList = []
      self.onlineDeviceList = []
      self.nearDeviceList = []
      self.imgStatistics()
      self.getImgDeviceAndInstitutionNum()
      self.getStrategyInfo()
      self.getLogo()
      self.getCompleteDetails()
      self.getRISCount()
      self.getArchiveNodeList()
      self.getSaveDeviceList()
      self.getDeviceInfo()
      // 这里不加的话 切换最右上角的 节点时 就不会去调用getService方法
      self.$nextTick(() => {
        self.$refs.serviceStatus.getService()
      })
    },
    async getConfigurationsFn() {
      const res = await getConfigurations('TransmissionSecurity.RSA.PublicKey')
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) {
          // 注册方法
          const pubKey = res.data // ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt()
          encryptStr.setPublicKey(pubKey) // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()) // 进行加密
          return data
        }
      }
    },
    // 今日影像检查类型太多时 点击向左或向右滑动
    scrollTab(direction) {
      const step = this.itemWidth; // 每次滑动的距离
      if (direction === 'left') {
        this.scrollPosition = Math.max(this.scrollPosition - step, 0);
      } else if (direction === 'right') {
        const maxScroll = this.list.length * this.itemWidth - this.$refs.slider.clientWidth;
        this.scrollPosition = Math.min(this.scrollPosition + step, maxScroll);
      }
      this.$refs.slider.scrollTo({
        left: this.scrollPosition,
        behavior: 'smooth',
      });
    },
    async getArchiveNodeList() {
      this.tabActiveName = this.currentNode?.node_name
    },
    // 获取第一个实例的 服务运行状态和是否开通了服务
    sendFetchInfor (obj) {
      this.fetchInforObj.last_run_time = obj.last_run_time
      this.fetchInforObj.health_check_time_span_seconds = obj.health_check_time_span_seconds
    },
    async getSaveDeviceList() {
      const res = await this.$pacsApi.pacsApi.getSaveDeviceList()
      const { code, data } = res
      if (code === 0) {
        let colorNum = 0
        let newArr = []
        data.forEach((ele) => {
          //文件存储、启用、有容量才能展示百分比
          if (
            ele.local_is_stopped != 1 &&
            ele.device_type != 1 &&
            ele.current_space &&
            ele.total_space
          ) {
            ele.colorStart = this.colorArr[colorNum].colorStart
            ele.colorStop = this.colorArr[colorNum].colorStop
            newArr.push(ele)
            if (colorNum < this.colorArr.length - 1) {
              colorNum++
            } else {
              colorNum = 0
            }
          } else if (ele.device_type == 1 && ele.oos_is_stopped != 1) {
            //已启用的对象存储
            newArr.push(ele)
          }
        })

        this.saveDeviceList = newArr
        this.dataFormat()
      }
    },
    dataFormat() {
      let num1 = []
      let num2 = []
      this.onlineDeviceList = []
      this.nearDeviceList = []
      this.saveDeviceList.forEach((item) => {
        if (item.device_category == 0) {
          //在线
          this.onlineDeviceList.push(item)
        } else if (item.device_category == 1) {
          //近线
          this.nearDeviceList.push(item)
        }

        num1.push(this.unitChange(item.current_space))
        num2.push(this.unitChange(item.total_space))
      })
      num1.forEach((ele) => {
        this.allUsed += ele
      })
      num2.forEach((ele) => {
        this.allTotal += ele
      })
      this.allText =
        this.diskSize(this.allUsed) + '/' + this.diskSize(this.allTotal)
      this.allUsedText = this.diskSize(this.allUsed)
      this.allTotalText = this.diskSize(this.allTotal)
      // this.allVal = this.allUsed / this.allTotal;
    },
    unitChange(str) {
      if (str == null) {
        return 0
      }
      const k = 1024
      let type = str.slice(str.length - 1)
      let num = str.slice(0, str.length - 1)
      const sizeStr = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'] //容量单位
      for (let i = 0; i < sizeStr.length; i++) {
        const size = sizeStr[i]
        if (type === size) {
          return Math.pow(k, i) * num
        }
      }
    },
    diskSize(num) {
      if (num === 0) return '0B'
      const k = 1024
      const sizeStr = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y']
      let i = 0
      for (let l = 0; l < sizeStr.length; l++) {
        if (num / Math.pow(k, l) < 1) {
          break
        }
        i = l
      }
      return (num / Math.pow(k, i)).toFixed(2) + sizeStr[i]
    },
    checkTimeErrorAlertClose() {
      this.checkTimeErrorAlertShow = false
    },
    imgSendFormat(percentage) {
      return `${percentage}/100`
      // return percentage === 100 ? '满' : `${percentage}%`;
    },
    dataCheckFormat(percentage) {
      return `${percentage}%`
    },
    toMatching() {
      this.$router.push({
        path: this.baseUrl + '/DataManagement/matching',
        query: { checktime: 'today', group: this.$store.getters.group },
      })
    },
    toStrategyConfig() {
      this.$router.push({
        name: 'RoutingStrategyConfig',
        query: { activeName: '5', group: this.$store.getters.group },
      })
    },
    toSetSaveStrategy() {
      this.$router.push({
        name: 'MemoryDeviceConfig',
        query: {
          SetSaveStrategyShow: 'open',
          group: this.$store.getters.group,
        },
      })
    },
    async imgStatistics() {
      let res = await this.$pacsApi.pacsApi.imgStatistics()
      let { code, data } = res
      if (code === 0) {
        this.todayStatistics = data
      }
    },
    async getImgDeviceAndInstitutionNum() {
      let res = await this.$pacsApi.pacsApi.getImgDeviceAndInstitutionNum()
      let { code, data } = res
      if (code === 0) {
        this.institutionCount = data.institution_count
        this.modalityCount = data.modality_count
      }
    },
    async getStrategyInfo() {
      let res = await this.$pacsApi.pacsApi.getStrategyInfo()
      let { code, data } = res
      if (code === 0) {
        this.strategyInfo = data
      }
    },
    async getCompleteDetails() {
      const res = await this.$pacsApi.pacsApi.getCompleteDetails()
      const { code, data } = res
      if (code === 0) {
        this.organizationName = data.platform_info.name
      }
    },
    async getLogo() {
      let res = await this.$pacsApi.pacsApi.getLogo()
      let { code, data } = res
      if (code === 0) {
        // this.organizationName = data.name;
        // if (data.logo === "0") {
        //   // 使用默认机构logo
        //   this.logoSrc = require("../../assets/images/pacs/defaultInstitution.png");
        //   return;
        // }
        // let fileRes = await this.$pacsApi.pacsApi.getLogoPic(data.logo)
        // let blobData = new Blob([fileRes])
        // this.logoSrc = configUrl.apiUrl + `/api-operate/medias/${data.logo}`
        // let picRes = await this.$pacsApi.pacsApi.getLogoPic(data.logo)
        const tid = JSON.parse(this.loginInfo)?.profile?.tenancy_id
        // let picRes = await this.$pacsApi.pacsApi.getTenanciesLogo(
        //   data.logo,
        //   tid
        // );
        let picRes = await this.$pacsApi.pacsApi
          .getPortalsLog(tid)
          .catch((err) => {
            // console.log(err);
            this.logoSrc = require('../../assets/images/pacs/defaultInstitution.png')
          })
        if (this.logoSrc) {
          return
        }
        let blobData = new Blob([picRes])
        this.logoSrc = URL.createObjectURL(blobData)
      } else {
        this.logoSrc = require('../../assets/images/pacs/defaultInstitution.png')
      }
    },
    async getRISCount() {
      let todayBegin = moment().format('yyyy-MM-DD') + ' 00:00:00'
      let todayEnd = moment().format('yyyy-MM-DD') + ' 23:59:59'
      let params = { BeginDate: todayBegin, EndDate: todayEnd }
      // 如果为dept, 入参加入systemid
      if (this.$store.getters.group === 'dept') {
        params.systemid = this.$store.getters.systemid
      }
      let res = await this.$pacsApi.pacsApi.getRISCount(params)
      let { code, data } = res
      if (code === 0) {
        this.todayRISCount = data
      }
    },
    async getDeviceInfo() {
      let res = await this.$pacsApi.pacsApi.getDeviceInfo()
      let { code, data } = res
      if (code === 0) {
        let keys = [
          'online_avail_percentage',
          'nearline_avail_percentage',
          'archive_service_speed',
          'storage_service_speed',
        ]

        this.dealValues(keys, data)
      }
    },
    dealValues(keys, data) {
      keys.map((e, index) => {
        let item = this.tips[index]
        item.subTitle = data[e]
        item.value = parseFloat(item.subTitle)
        let resStr = parseFloat(
          item.value?.toString()?.match(/^\d+(?:\.\d{0,2})?/)
        )
        if (resStr) {
          item.subTitle = item?.subTitle?.replace(item.value, resStr)
        }
      })
    },
  },
  activated() {
    this.refreshFn()
  },
  mounted() {
    if (this.$route.query.systemType) {
      this.systemType = this.$route.query.systemType
      if (this.systemType == 10) {
        // 云pacs
        this.firstTitle = '数据管理'
        this.subTitle = ''
      }
    }

    this.userInfo = JSON.parse(this.loginInfo)
    this.getConfigurationsFn()
    // this.getNodeList()
    // console.log('没有数据吗？',this.nodeList);
    this.baseUrl = process.env.NODE_ENV === 'development' ? '' : '/paservice'
    this.refreshFn()
    const timeId = setInterval(() => {
      if (this.imgSendPercentage === 100) {
        clearInterval(timeId)
      } else {
        this.imgSendPercentage++
      }
    }, 100)
    const timeId1 = setInterval(() => {
      if (this.dataCheckCurrent === this.dataCheckAll) {
        clearInterval(timeId1)
      } else {
        this.dataCheckCurrent++
      }
    }, 10)
  },
  components: {
    SystemMemory,
    CloudMemory,
    HeadNav,
    serviceStatus,
    dataBackup
  },
  beforeRouteEnter(to, from, next) {
    document.querySelector('html').style.backgroundColor = '#F5F5F5'
    document.querySelector('body').style.backgroundColor = '#F5F5F5'
    next()
  },
  beforeRouteLeave(to, from, next) {
    document.querySelector('html').style.backgroundColor = '#FFF'
    document.querySelector('body').style.backgroundColor = '#FFF'
    next()
  },
}
</script>

<style lang="less">
@import '../../style/pacs/pacsFont/iconfont.css';
</style>

<style lang="less" scoped>
.w_100 {
  width: 100px;
}
.tab {
  display: flex;
  height: 40px;
  line-height: 40px;
  border-bottom: 1px solid #ddd;
  background-color: #fff;
  padding-left: 35px;
  .tabItem {
    position: relative;
    padding: 0 10px;
    cursor: pointer;
    &.select {
      color: #0a70b0;
      &:after{
        position: absolute;
        left: 0;
        bottom: 0;
        width: 100%;
        height: 2px;
        background: #0a70b0;
        content: '';
      }
    }
  }
}

.iframeContent {
  width: 100%;
  flex: 1;
  overflow: hidden;
  .pageIframe {
    width: 100%;
    height: 100%;
    border: none;
    outline: none;
  }
}

.usage_situation {
  flex:1;
  display: flex;
  background-color: rgb(245, 245, 245);

  &_top {
    background-color: white;
    overflow-x: auto;
    width: calc(100% - 10px);
    padding-left: 10px;
    // margin-right:10px;
    display: flex;
    justify-content: flex-start;
    align-items: center;

    &_item {
      // flex: 1;
      border-radius: 4px;
      border-bottom: 1px dashed #dcdfe6;
      padding: 0px 10px;
      width:250px;
      height: 64px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      ::v-deep .el-button {
        padding: 0px;
      }

      &_icon {
        padding: 5px;
        margin-right: 5px;
        // background-color: rgba(28, 139, 228, 0.1);
        border-radius: 3px;
      }

      .iconfont {
        color: #606266;
      }

      // .icon-jinxianrongliang {
      //   font-size: 17px;
      // }
      .el-button {
        height: 20px;
      }

      span {
        line-height: 32px;
      }
    }
  }

  &_bottom {
    flex: 1;
    height:0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: rgb(245, 245, 245);
    //
    &_item {
      background-color: white;
      flex: 1;
      border-left: 1px solid #DCDFE6;
      overflow: auto;
      .no-data {
        height: calc(100% - 40px);
      }
      .chartCon{
        display: flex;
        align-items: center;
        flex-flow: wrap;
        // height: calc(100% - 40px);
        .curDeviceName{
          font-size:14px;
          color: #333333;
          margin-top:10px;
        }
        .someDeviceName{
          font-weight: 500;
          font-size: 14px;
          color: #333333;
          text-align: center;
          position: relative;
          top:-21px;
        }
      }
    }
  }

  // ul {
  //   display: block;
  //   overflow: hidden;
  //   white-space: nowrap;
  // }
  // li {
  //   display: inline-block;
  //   margin-left: 15px;
  //   list-style: none;
  //   min-width: 250px;
  // }
}

.pacs_main{
  display: flex;
  flex-direction: column;
  height: calc(100vh - 50px);
  padding: 0 0px 0px 5px;
  overflow: hidden;
  .main_top {
    display: flex;
    .inspectLeft{
      width: 300px;
      min-width: 300px;
      height: 275px;
      border-top-left-radius: 4px;
      border-bottom-left-radius: 4px;
      background-color: #FFF;
      text-align: center;
      margin-right: 1px;
      ::v-deep .imgCon{
        width:120px;
        height: 120px;
        display: flex;
        justify-content: center;
        align-items: center;
        border: 1px dashed #DBEFFF;
        img{
          width:auto;
          height: auto;
          max-width: 100%;
          max-height: 100%;
        }
      }
      .organizationName{
        font-weight: 600;
        font-size: 20px;
        color: #303133;
        margin-top:15px;
        margin-bottom: 25px;
      }
      .inspectLabel{
        font-size: 14px;
        color: #909399;
      }
      .inspectVal{
        font-family: Arial-Black;
        font-weight: 900;
        font-size: 28px;
        color: #1C8BE4;
        line-height: 40px;
      }
     }
    .inspectRight{
      width: calc(100% - 320px);
      // height: 275px;
      padding:10px;
      background-color: #FFF;
      .inspectTypeCon{
        display: flex;
        align-items: center;
        height: 90px;
        background: #F0F4F9;
        border-radius: 8px;
        padding:15px 0px 15px 20px;
        box-sizing: border-box;
        .todayImageInspect {
          height: 100%;
          display: flex;
          flex-flow: column;
          justify-content: space-between;
          border-right: 1px solid #DCDFE6;
          width:142px;
          .todayImageLabel{
            font-size: 14px;
            color: #1C8BE4;
            margin-bottom: 5px;
          }
          .todayImageVal{
            font-family: Arial-Black;
            font-weight: 900;
            font-size: 28px;
            color: #1C8BE4;
            line-height: 40px;
          }
          .inspectTypeName{
            color: #909399;
            font-size: 16px;
            font-weight: 500;
          }
          .inspectTypeCount{
            color: #303133;
          }
        }
        .todayImageInspect:last-of-type {
          border-right: none;
        }
        .todayTotalInspect{
          width:173px;
        }
        .scrollTab{
          display: flex;
          align-items: center;
          width:calc(100% - 218px);
          position: relative;
          .leftArrow{
            position: absolute;
            top:25px;
            left:15px;
            cursor: pointer;
            color:#909399;
          }
          .rightArrow{
            position: absolute;
            right:-30px;
            top:25px;
            cursor: pointer;
            color:#909399;
          }
        }
        .slider{
          overflow-x: hidden;
          white-space: nowrap;
          width:100%;
          li {
            display: inline-block;
            width: 140px!important; /* 根据需要调整 */
            box-sizing: border-box;
            padding-left:40px;
            text-align: left;
          }
        }
      }
      ul>li {

        border-right: 1px solid #DDDDDD;
        p {font-size: 14px;margin-bottom: 13px;}
        span {font-size: 28px;}
      }
      .strategy {
        display: flex;
        flex-flow: wrap;
        .strategy_box {
          //flex:1;
          // min-width: 445px;
          // width: 438px;
          width:calc((100% - 40px)/3);
          .strategyCon {
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 13px;
            border: 1px solid #EBEEF5;
            border-radius: 4px;
            box-sizing: border-box;
            .strategyMinBox{
              display: flex;
              align-items: center;
            }
            .isRunningLabel{
              line-height: 30px;
            }
            .strategyTitDiv{
              font-weight: 500;
              font-size: 14px;
              color: #333333;
              i{
                margin-right: 5px;
              }
            }
          }
          ::v-deep .el-popover__reference-wrapper{
            display: flex;
            align-items: center;
          }
        }
      }

      .todayCheck{
        display: flex;
        .todayCheckItem{
          border: 1px solid #EBEEF5;
          border-radius: 4px;
          color:#303133;
          flex: 1;
          display: flex;
          align-items: center;
          .todayCheckLabel{
            font-weight: 500;
            font-size: 14px;
            color: #303133;
          }
          .numberVal{
            font-size: 14px;
            color: #303133;
            font-family: Arial-Black;
            font-weight: 900;
          }
          .errorNumberVal,.todayNoMatchCheckLabel{
            color:#FF6F6F;
          }
        }
        .todayNoMatchCheck{
          border-color:#EBEEF5;

        }
      }
    }
  }
  .moduleTitBox{
    height: 40px;
    display: flex;
    align-items: center;
    .icon{
      width: 3px;
      height: 14px;
      background: #0A70B0;
    }
    .moduleTit{
      font-weight: 500;
      font-size: 15px;
      color: #303133;
      margin-left:5px;
    }
  }
  &.inIframe{
    height: 100vh;
  }
  .contentContainer {
    // padding: 10px 5px 5px 5px;
    padding: 10px;
    width: calc(100% - 20px);
    height: calc(100% - 75px)!important;
  }
  .content {
    padding-top: 0px;
    height: calc(100% - 0px);
    background-color: transparent;
    //  #EBEEF5;

    .flex_column_start {
      display: flex;
      flex: column;
      align-items: flex-start;
      justify-content: flex-start;
    }
  }
  .h390 {
    height: 390px;
  }
}
.storageAndDeviceCon{
  height: calc(100% - 496px);
}
.systemStorageBox{
  display: flex;
  height: 100%;
}
.systemStorageCon{
  width:537px;
  height: 100%;
  display: flex;
  align-items: center;
  .h205{
    height: 205px;
  }
  .w205{
    width:205px;
  }
  .usage_situation_top{
    display: flex;
    flex-flow: column;
  }
  .systemStorageTit{
    font-size:16px;
    color:#303133;
    font-weight: 500;
    text-align: center;
    position: relative;
    top:-10px;
  }
}

.bg_fff {
  background-color: white;
}

.f14i {
  font-size: 14px !important;
}

.f24i {
  font-size: 24px !important;
}
.f22i {
  font-size: 22px !important;
}
.w230{width: 230px;}
.h230 { height: 230px;}

.w236 { width: 236px;}
.h236 { height: 236px;}

.w188 { width: 188px;}
.h188 { height: 188px;}
.el-alert.el-alert--warning.is-light {
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
}

/deep/.el-alert .el-alert__description {
  font-size: 14px;
  margin-top: 0;
}

/deep/.el-alert.is-light .el-alert__closebtn {
  top: 15px !important;
}

.slide-fade-enter-active,
.slide-fade-leave-active {
  transition: all 0.3s;
}

.slide-fade-enter,
.slide-fade-leave-to

/* .slide-fade-leave-active for below version 2.1.8 */ {
  transform: translateX(460px);
  opacity: 0;
}

.imgSendTip {
  /deep/.el-progress__text {
    font-size: 12px !important;
    margin-left: 0;
    color: #999999;
  }
}

.dataCheckTip {
  /deep/.el-progress__text {
    font-size: 12px !important;
    margin-left: 10px;
    color: #0a70b0;
  }
}

.no-data {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}

ul > li {
  text-align: center;
}
</style>
