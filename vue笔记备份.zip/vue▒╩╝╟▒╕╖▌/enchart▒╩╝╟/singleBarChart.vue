<template>
  <common-box :title="headTit" subTitle="">
    <div v-if="curOrgObj.orgName&& inspectType !== 'inspectReport'" slot="headerRight" class="curTenancyNameCon">
      <span class="curTenancyName">({{curOrgObj.orgName}})</span>
      <span class="returnBtn" @click="returnPreChart">返回</span>
    </div>
    <!-- 超声和内镜 检查报告耗时--->
    <div v-if="inspectType == 'inspectReport'" slot="headerRight" class="itemClassBox">
      <el-select
          v-model="itemClass"
          @change="refreshChart"
          filterable
          placeholder="全部项目分类"
          class="itemClassSelect"
        >
        <el-option
          v-for="(item, index) in itemClassArr"
          :key="index"
          :label="item.name"
          :value="item.id"
        ></el-option>
      </el-select>
    </div>
    <div slot="chart" class="chart" ref="chart"></div>
  </common-box>
</template>

<script>
import * as echarts from 'echarts'
import commonBox from './commonBox.vue'
import { dynamicInvoke } from '@/api/dataapi'
import Big from 'big.js'
export default {
  components: {
    commonBox
  },
  props: {
    params: {
      type: Object,
      default: () => {}
    },
    itemClassArr: Array,
    inspectType: String,
    activeBtnValue: String,
  },
  data() {
    return {
      headTit: '报告优良率',
      myChart: null,
      chartData: [],
      curOrgObj: {
        orgName: '',
      },
      chartDetailData: [],
      itemClass: '',
      singleBarOption: {
        backgroundColor: '',
        grid: {
          top: '35px',
          left: '0px',
          right: '0px',
          bottom: '0px',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: [],
          // 强制显示所有标签
          axisLabel: {
            interval: 0,
            color: '#fff'
          },
          axisTick: {
            show: false
          },
          axisLine: {
            //x轴线的颜色以及宽度
            show: true,
            lineStyle: {
              color: 'rgba(255,255,255,.1)',
              width: 1,
              type: "solid",
            },
          },
        },
        yAxis: {
          type: 'value',
          show: true,
          min: 0,
          max: 100,
          axisLabel: {
            formatter: '{value}%',
            textStyle: {
              color: 'rgba(255,255,255,.5)',
            },
          },
          splitLine: { show: false },
          axisLine: {
            //y轴线的颜色以及宽度
            show: true,
            lineStyle: {
              color: 'rgba(255,255,255,.1)',
              width: 1,
              type: "solid",
            },
          },
          axisTick: {
            show: false
          }
        },
        series: [
          {
            data: [],
            type: 'bar',
            name: '上报数据',
            barWidth: '30%',
            label: {
              show: true,
              position: 'top',
              formatter: '{c}%',// 如果下面一行再定义normal的话 那这里就会不生效 不会显示 100% 等
              // normal: {
              //   show: true,
              //   position: "top",
              //   color: function(params) {
              //     let num = colorArr.length;
              //     return colorArr[params.dataIndex % num].top
              //   },
              //   fontFamily: "PingFangSC-Medium",
              //   fontWeight: 500,
              // },
            },
            itemStyle: {
              normal: {
                color: function(params) {
                  // let num = colorArr.length;
                  // return new echarts.graphic.LinearGradient(0, 1, 0, 0,[{
                  //     offset: 0,
                  //     color: colorArr[index].top // 0% 处的颜色
                  // },{//可根据具体情况决定哪根柱子显示哪种颜色
                  //     offset: 1,
                  //     color: colorArr[index].bottom // 100% 处的颜色
                  // }],false)
                },
              }
            }
          }
        ]
      }
    }
  },
  computed: {},
  created () {
    if (this.inspectType == 'imageRate') {// 影像优良率
      this.headTit = '影像优良率'
    } 
    if (this.activeBtnValue == 'RIS') { // 放射
      if (this.inspectType == 'reportYLRate') {
        this.headTit = '报告优良率'
      }
      
    } else if (this.activeBtnValue == 'UIS' || this.activeBtnValue == 'EIS') { // 超声和内镜
      if (this.inspectType == 'inspectOrder') {
        this.headTit = '预约人次(人次)'
      }
      if (this.inspectType == 'inspectPeople') {
        this.headTit = '检查人次(人次)'
      }
      if (this.inspectType == 'inspectReport') {
        this.headTit = '检查报告平均耗时(分钟)'
      }
    }
    
  },
  mounted() {

  },
  methods: {
    // 点击某根柱子后 展现其机构下的 检查类型 数据
    async drawInspectTypeChart (index,inspectType) {
      const self = this
      // self.myChart.dispose()
      // self.myChart = null
      let option  = null
      let res = null
      const newParams = Object.assign({}, self.params, self.curOrgObj)
      if (inspectType == 'imageRate') { // 影像优良率
        res = await dynamicInvoke('QC_1176',newParams)
      }
      if (res.code == 0) {
        // self.chartDetailData = [
        //   {
        //     name: 'CT',
        //     value: 80,
        //     orgName: 'TEST'
        //   },
        //   {
        //     name: 'XR',
        //     value: 60,
        //     orgName: 'TEST2'
        //   },
        // ]
        self.chartDetailData = res.data.map((item) => {
          item.ratio = item.ratio || 0
          return {
            name: item.itemType,
            value: Big(item.ratio)
              .times(100)
              .toString(),
            ...item
          }
        })
      } else {
        self.$message.error(res.msg)
      }
      if (!self.myChart) {
        self.myChart = echarts.init(self.$refs.chart, 'dark')
      }
      var colorArr = [
        {
          top: '#1BB54A',//绿色
          bottom: '#11D4B6',
        },
        {
          top: '#FDB200',//黄色
          bottom: '#FFE800'
        },
        {
          top: '#004CFF',//蓝色
          bottom: '#1CDAE4'
        },
        {
          top: '#ff6958',//蓝色
          bottom: '#ff7d6f'
        }
      ];
      option = JSON.parse(JSON.stringify(this.singleBarOption));
      const xData = self.chartDetailData.map((item) => item.name);
      option.xAxis.data = xData;
      // option.series[0].data = self.chartDetailData;
      const yData = self.chartDetailData.map((item) => {
        return {
          value: item.value,
          label:{textStyle: { color: colorArr[index].top }}// 设置柱子上数值的颜色
        }
       })
      option.series[0].data = yData;
      option.series[0].itemStyle.normal.color = function(params) {
        return new echarts.graphic.LinearGradient(0, 1, 0, 0,[{
            offset: 0,
            color: colorArr[index].top // 0% 处的颜色
        },{//可根据具体情况决定哪根柱子显示哪种颜色
            offset: 1,
            color: colorArr[index].bottom // 100% 处的颜色
        }],false)
      }
      option && self.myChart.setOption(option,{ notMerge: true })
      self.myChart.getZr().off('click')
    },
    returnPreChart () {
      this.refreshChart()
    },
    async refreshChart() {
      const self = this
      let option  = null
      let res = null
      
      if (self.curOrgObj.orgName) {
        self.curOrgObj.orgName = ''
        //self.myChart.clear();
      }
      if (self.activeBtnValue == 'RIS') {
        if (self.inspectType == 'reportYLRate') { // 报告优良率
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1003',self.params)
        }
        
        if (self.inspectType == 'imageRate') { // 影像优良率
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1002',self.params)
        }

      } else if (self.activeBtnValue == 'UIS' || self.activeBtnValue == 'EIS') {   // 超声和内镜
        if (self.inspectType == 'reportYLRate') { // 有了
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1003',self.params)
        }
        if (self.inspectType == 'inspectOrder') { // 预约人次
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen-XIS_1001',self.params)
        }
        if (self.inspectType == 'inspectPeople') { // 检查人次
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen-XIS_1002',self.params)
        }
        if (self.inspectType == 'imageRate') { // 影像优良率
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen_1002',self.params)
        }

        if (self.inspectType == 'inspectReport') { // 检查报告
          const newParams = Object.assign({}, self.params, {itemClass: self.itemClass})
          res = await dynamicInvoke('YZ-Area-Quality-YWScreen-XIS_1005',newParams)
        }
        
      }
      
      if (res.code == 0) {
        // self.chartData = [
        //   {
        //     name: 'CT',
        //     value: 80,
        //     orgName: 'TEST'
        //   },
        //   {
        //     name: 'XR',
        //     value: 60,
        //     orgName: 'TEST2'
        //   },
        // ]
        if (self.inspectType == 'imageRate') {
          self.chartData = res.data.map((item) => {
            item.ratio = item.ratio || 0
            return {
              name: item.orgName,
              value: Big(item.ratio)
              .times(100)
              .toString(),
              ...item
            }
          })
        } else if (self.inspectType == 'inspectReport') {//超声或内镜 检查报告耗时
          self.chartData = res.data.map((item) => {
            item.reportTime = item.reportTime || 0
            return {
              name: item.orgName,
              value: item.reportTime,
              ...item
            }
          })
          // self.chartData = [
          //   {orgName: "鄞州人民医院医共体",value:10},
          //   {orgName: "鄞州二院医共体",value:20},
          //   {orgName: "市六医院医共体",value:30},
          // ]
        }
         else {
          self.chartData = res.data.map((item) => {
            item.totalNum = item.totalNum || 0
            return {
              name: item.orgName,
              value: item.totalNum,
              ...item
            }
          })
        }

      } else {
        self.$message.error(res.msg)
      }
      if (!self.myChart) {
        self.myChart = echarts.init(self.$refs.chart, 'dark')
      }
      var colorArr = [
        {
          top: '#1BB54A',//绿色
          bottom: '#11D4B6',
        },
        {
          top: '#FDB200',//黄色
          bottom: '#FFE800'
        },
        {
          top: '#004CFF',//蓝色
          bottom: '#1CDAE4'
        },
        {
          top: '#ff6958',//蓝色
          bottom: '#ff7d6f'
        }
      ];

      option = JSON.parse(JSON.stringify(this.singleBarOption));
      const xData = self.chartData.map((item) => item.orgName);
      option.xAxis.data = xData;
      const yData = self.chartData.map((item,i) => {
        return {
          value: item.value,
          label:{textStyle: { color: colorArr[i].top }}
        }
       })
      option.series[0].data = yData;
      
      if (this.inspectType == 'inspectPeople' || this.inspectType == 'inspectReport') {// 超声 检查人次&& 超声内镜 检查报告耗时
        option.series[0].label.formatter = '{c}' 
        option.yAxis = {
          type: 'value',
          show: true,
          min: 0,
          axisLabel: {
            formatter: '{value}',
            textStyle: {
              color: 'rgba(255,255,255,.5)',
            },
          },
          splitLine: { show: false },
          axisLine: {
            //y轴线的颜色以及宽度
            show: true,
            lineStyle: {
              color: 'rgba(255,255,255,.1)',
              width: 1,
              type: "solid",
            },
          },
          axisTick: {
            show: false
          }
        }
      }
      
      option.series[0].label.color = function(params) {
        let num = colorArr.length;
        return colorArr[params.dataIndex % num].top
      }
      // option.series[0].label.normal.color = function(params) {
      //   let num = colorArr.length;
      //   return colorArr[params.dataIndex % num].top
      // }
      option.series[0].itemStyle.normal.color = function(params) {
        let num = colorArr.length;
        return new echarts.graphic.LinearGradient(0, 1, 0, 0,[{
            offset: 0,
            color: colorArr[params.dataIndex % num].top // 0% 处的颜色
        },{//可根据具体情况决定哪根柱子显示哪种颜色
            offset: 1,
            color: colorArr[params.dataIndex % num].bottom // 100% 处的颜色
        }],false)
      }


      option && self.myChart.setOption(option,{ notMerge: true })
      // 给影像阳性率 柱状图 增加点击事件
      if (self.inspectType == 'imageRate' && !self.curOrgObj.orgName) {
        self.myChart.getZr().on('click', function(params) {
          let pointInPixel = [params.offsetX, params.offsetY]
          if (self.myChart.containPixel('grid', pointInPixel)) {
            let xIndex = self.myChart.convertFromPixel({ seriesIndex: 0 }, [params.offsetX, params.offsetY])[0]
            //console.log(xIndex)
            //console.log(params)
            self.myChart.dispatchAction({
              type:'select',
				        seriesIndex: xIndex,//这行不能省
            })
            //self.$emit('clickChartFunc',xIndex, self.inspectType)
            if (!self.curOrgObj.orgName) {
              self.curOrgObj.orgName = self.chartData[xIndex].orgName
              self.drawInspectTypeChart(xIndex, self.inspectType)
            }
            
          }
        })
      }
    }
  },
  destroyed() {
    if (!this.myChart) {
      return
    }
    this.myChart.dispose()
    this.myChart = null
  }
}
</script>

<style lang="scss" scoped>
.chart {
  width: 100%;
  height: 100%;
}
.curTenancyNameCon{
 flex:1;
 display: flex;
 justify-content: space-between;
  .curTenancyName{
    color: #fff;
    font-size: vh(16);
    margin-left: vw(15);
  }
  .returnBtn{
    color: #fff;
    font-size: vh(16);
    cursor: pointer;
  }
}
.itemClassSelect{
  width: vw(180);
  height: vw(32);
}
::v-deep .itemClassBox{
  flex:1;
  text-align: right;
  font-weight: 500;
  font-size: vh(16);
  color: #00d3ff;
  .el-icon-arrow-up:before{
    color: #00d3ff;
  }
  .el-input__inner {
    border-color: #00d3ff;
    background:initial;
    border-radius: 5px;
  }
  .el-input__inner::-webkit-input-placeholder {
    color: #00d3ff; /* 指定颜色 */
  }
 
  .el-input__inner:-moz-placeholder {
    color: #00d3ff; /* 老版本Firefox */
  }
  .el-input__inner::-moz-placeholder {
    color: #00d3ff; /* 新版本Firefox */
  }
  .el-input__inner:-ms-input-placeholder {
    color: #00d3ff; /* 老版本IE */
  }
}
</style>
