<template>
  <div class="dataVisualizationCon">
    <head-nav :firstTitle="firstTitle" :subTitle="subTitle"></head-nav>
    <div class="contentContainer">
      <!-- 影像总览--->
      <div class="imageOverview mb10">
        <div class="navHead">
           <span class="navHeadIcon"></span>
           <span class="navHeadTit">影像总览</span>
           <el-popover placement="top-start" trigger="hover">
            <div class="pl10 pr10 pt10 pb10">为确保数据的准确性，本页面除检查量统计之外的所有统计都不包含当日数据！</div>
            <i
            class="ml5 el-icon-question clr_c0c vam tipIcon"
            slot="reference"
            ></i>
           </el-popover>
        </div>
        <el-row class="imageDataCon" :gutter="13">
           <el-col :span="6" v-for="(item,index) in file_size_list" :key="index">
            <div class="oneImgageData" :class="{'oneImageErrorData': item.is_error}">
              <!---整体数据-->
              <div class="oneImgageDataHead" v-if="item.data_type === 0">
                <span ><i class="iconfont">&#xe6c8;</i><span class="oneImgageDataHeadTit">所有数据</span></span>
                <span class="oneImgageDataParamLabel">范围：{{item.start_date}} ~ {{item.end_date}}</span>
              </div>
              <!---在线数据-->
              <div class="oneImgageDataHead" v-if="item.data_type === 1">
                <span><i class="iconfont onlineIcon">&#xe6c8;</i><span class="oneImgageDataHeadTit">在线数据</span></span>
                <span class="oneImgageDataParamLabel">
                  范围：
                  <span v-if="item.start_date&& item.end_date">{{item.start_date}} ~ {{item.end_date}}</span>
                </span>
                <span class="dataStatus" v-if="!item.is_error">正常</span>
                <span class="dataStatus dataErrorStatus" v-else>异常</span>
              </div>
              <!---近线数据-->
              <div class="oneImgageDataHead" v-if="item.data_type === 2">
                <span><i class="iconfont atLineIcon">&#xe6c8;</i><span class="oneImgageDataHeadTit">近线数据</span></span>
                <span class="oneImgageDataParamLabel">
                  范围：
                  <span v-if="item.start_date&& item.end_date">{{item.start_date}} ~ {{item.end_date}}</span>
                </span>
                <span class="dataStatus" v-if="!item.is_error">正常</span>
                <span class="dataStatus dataErrorStatus" v-else>异常</span>
              </div>
              <!---离线数据-->
              <div class="oneImgageDataHead" v-if="item.data_type === 3">
                <span><i class="iconfont offlineIcon">&#xe6c8;</i><span class="oneImgageDataHeadTit">离线数据</span></span>
                <span class="oneImgageDataParamLabel">范围：
                   <span v-if="item.start_date&& item.end_date">{{item.start_date}} ~ {{item.end_date}}</span>
                </span>
                <span class="dataStatus" v-if="!item.is_error">正常</span>
                <span class="dataStatus dataErrorStatus" v-else>异常</span>
              </div>


              <div class="imgageDataParamCon">
                <div class="oneImgageDataParam">
                  <div class="oneImgageDataParamBox">
                    <span class="oneImgageDataParamLabel mb5">检查数</span>
                    <span class="paramValue">{{item.study_count}}<span class="unit">条</span></span>
                  </div>
                </div>
                <div class="splitLine"></div>
                <div class="oneImgageDataParam">
                  <span class="oneImgageDataParamLabel mb5">容量</span>
                  <span class="paramValue">{{item.file_size_description}}</span>
                  <!-- <span class="paramValue">1.151<span class="unit">PB</span></span> -->
                </div>
              </div>
            </div>
            </el-col>
        </el-row>
        <el-row class="rangContainer">
          <el-col class="containerLeft" :span="24">
             <div class="rangCon">
             <!-- <div v-if="domainDataList.length == 0 && !requestDomainLoading" class="noDataContent">
                    <div class="noDataImg"></div>
                    <span> 暂无数据 </span>
                </div>
             <dataRangeLine v-else class="mt10 data_line" :dataList="domainDataList"></dataRangeLine> -->
              <dataRangeLine class="data_line" :dataList="rangList"></dataRangeLine>
           </div>
          </el-col>
        </el-row>  
      </div>
      <!-- 影像数据范围 和 检查量统计 和 检查占比 和 数据同步 --->
      <el-row class="imageDataRangAndOther" :gutter="10">
        <el-col class="containerLeft">
          <!---检查量统计--->
          <div class="inspectNumTotal">
            <div class="navHead">
                <span class="navHeadIcon"></span>
                <span class="navHeadTit">检查数统计</span>
                <div class="navHeadRight">
                  <div class="searchInspectQuery">
                    <span
                    :class="{'activeSpan': tabIndex == curInspectTimeTabIndex}"
                    v-for="(timeTab,tabIndex) in inspectTimeTab" :key="tabIndex" @click="searchInspectNumByTime(tabIndex,timeTab)">
                        {{timeTab.name}}
                    </span>
                </div>
                <span class="splitIcon"></span>
                <span class="watchTotalReport" @click="gotoTotalReportPage(1)"><i class="iconfont mr5 totalChartIcon">&#xe6c7;</i><span>统计报表</span></span>
                </div>
           </div>
            <div class="inspectNumbar" v-bind:class="{'indexNoData': inspectTotalArr.length == 0 }">
             <chart-item :option="inspectNumBarOption" v-show="inspectNumBarOption"></chart-item>
            </div>
          </div>
        </el-col>

        <el-col class="containerRight">
          <!----检查占比--->
          <div class="inspectProportion">
            <div class="navHead inspectNavHead">
                <span>
                  <span class="navHeadIcon"></span>
                  <span class="navHeadTit">检查占比</span>
                </span>
                
                <div class="inspectReportCon" @click="gotoTotalReportPage(2)">
                  <i class="iconfont mr5 totalChartIcon">&#xe6c7;</i><span>统计报表</span>
                </div>
            </div>
            <div class="inspectProportionQuery">
              <span class="queryLabel">统计范围：</span>
              <SearchTime
              ref="searchTimeModel"
              :formatTime="true"
              :disableTime="'after'"
              @getTimes="getTimes"
              style="width: 230px"
             />
             <span class="queryLabel ml10">系统名称：</span>
            <el-select
              size="small"
              v-model="chooseSystemId"
              placeholder="请选择"
              style="width: 166px"
              clearable
              filterable
              @change="beganGetStudyProportion"
             >
              <el-option value="" label="所有系统"></el-option>
              <el-option
                v-for="(item,index) in node_system_list"
                :key="index"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
           </div>

           <div class="inspectProportionChart" v-bind:class="{'noData': inspectProportionArr.length == 0 }">
             <chart-item :option="inspectProportionCookieOption"></chart-item>
             <span class="watchMoreInspect" @click="showInspectDeatil">查看更多<i class="iconfont">&#xe704;</i></span>
            </div>
          </div>
        </el-col>
      </el-row>
   
      <!-- 数据近线、数据离线、数据压缩 -->
      <div class="dataLineContainer mt10">
        <dataStatus></dataStatus>
      </div>
      <!-- 数据备份、数据恢复、数据预取 -->
      <!-- <div class="dataBackContainer mt10">
        <dataBackup></dataBackup>
      </div> -->
      <!-- 在线存储、近线存储 -->
      <el-row class="storageDeviceContainer mt10" :gutter="10">
        <el-col class="containerLeft" :span="12">
           <div class="containerLeftBox">
              <div class="navHead">
                <span class="navHeadIcon"></span>
                <span class="navHeadTit">在线存储</span>
              </div>
             <device class="onlineDevice" :class="{'noTableData': onlineDeviceArr.length == 0}" :deviceArr="onlineDeviceArr"></device>
           </div>
        </el-col>
     

        <el-col class="containerRight" :span="12">
          <div class="containerRightBox">
            <div class="navHead">
                <span class="navHeadIcon"></span>
                <span class="navHeadTit">近线存储</span>
              </div> 
            <device class="offlineDevice" :class="{'noTableData': offineDeviceArr.length == 0}" :deviceArr="offineDeviceArr"></device>
          </div>
        </el-col>
      </el-row>
    </div>
  <!--检查占比--->
    <el-dialog
      v-el-drag-dialog
      v-if="showInspectDetailAlert"
      title="检查占比"
      :visible.sync="showInspectDetailAlert"
      :close-on-click-modal="false"
      width="900px"
      top="3%"
    >
      <inspectDetail ref="inspectDetailRef" :node_system_list="node_system_list"></inspectDetail>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" @click="showInspectDetailAlert=false">关闭</el-button>
        <!-- <el-button size="small" type="primary" @click="handleSure">确定</el-button> -->
      </span>
    </el-dialog>

  </div>
</template>
<script>
import * as echarts from "echarts";
import ChartItem from "@/components/common/ChartItem.vue";
import HeadNav from '@/components/common/HeadNav' // 头部导航
import dataRangeLine from './components/dataRangeLine.vue';
import SearchTime from './components/SearchTime' // 搜索时间
import inspectDetail from './components/inspectDetail'
import dataBackup from './components/dataBackup'
import dataStatus from './components/dataStatus'
import device from './components/device'
import moment from 'moment'
import { mapGetters } from 'vuex'
export default {
   components: {
     HeadNav,
     ChartItem,
     dataRangeLine,
     SearchTime,
     inspectDetail,
     dataBackup,
     dataStatus,
     device,
   },
   data () {
    return {
      firstTitle: '影像存档',
      subTitle: '数据可视化',
      inspectTimeTab: [
        {
          type:3,
          name: '近1天'
        },
        {
          type:2,
          name: '近7天'
        },
        {
          type:1,
          name: '近1月'
        },
        {
          type:0,
          name: '近1年'
        },
      ],
      file_size_list: [],
      rangList: [],
      dimension: 1,
      curInspectTimeTabIndex: 2,
      inspectTotalArr: [],
      initTime: [],
      chooseSystemId: '',
      searchProportionData: {// 检查占比 的查询条件
        start_time: '',
        end_time: '',
        system_ids: [],
        page_index: 1,
        page_size: 5,
      },
      totalInspect: 0,// 总检查
      inspectProportionArr: [],
      showInspectDetailAlert:false,
      onlineDeviceArr: [],
      offineDeviceArr: [],
    }
   },
   computed: {
     ...mapGetters(['node_system_list','currentNode',]),
    inspectNumBarOption () {
      let self = this;
      let option = null
      if (self.inspectTotalArr.length == 0) {
        return option;
      }
      let ydata = []
      let xdata = []
      self.inspectTotalArr.forEach(function (val) {
        xdata.push(val.statistics_time_description)
        ydata.push(val.study_count);
      });
      option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        grid: {
          left: '0',
          right: 0,
          bottom: '4%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: xdata,
          axisTick: {
            alignWithLabel: true
          },
          axisLine:{
            lineStyle:{
              show:true,//是否显示坐标轴轴线，
              color:'#D9D9D9',//x轴轴线的颜色
              width:1,//x轴粗细
           }
        },
        axisTick:{
          show:false,//是否显示刻度
          //lineStyle:{show:false,}    // x轴刻度的颜色
        },
        axisLabel: {
            color: 'rgba(0, 0, 0, 0.45)',// x轴字体颜色
            interval:0//轴显示所有的数据
          },
        },
        yAxis: {
          type: 'value',
           axisLine:{
             show:false,
           },
           axisTick:{
            show:false,
           },
           axisLabel: {
            color: 'rgba(0, 0, 0, 0.45)',// x轴字体颜色
            interval:0//轴显示所有的数据
          },
          splitLine: {
            show: true,
            lineStyle: {
              // 设置横线颜色
              color: '#EBEEF5'
            }
          }
        },
        series: [
          {
            name: '检查量',
            type: 'bar',
            barWidth: '20px',
            itemStyle: {
            // 设置柱子颜色
              color: '#6E99FF'
            },
            label: {
              show: true,
              position: 'top',
            },
            data: ydata
          }
        ]
      };
      // 如果横坐标太多 就特殊设置成倾斜状态
      if(self.inspectTotalArr.length >= 30) {
        option.xAxis.axisLabel.rotate = 45
      }
      return option;
    },
    inspectProportionCookieOption () {
      let self = this;
      let option = null
      var color = [
        "#6E99FF",
        "#4AE7D4",
        "#FEC240",
        "#FF6F6F",
        "#C380FF",
      ];
      let ydata = []
      let xdata = []
      
      self.inspectProportionArr.forEach(function (val) {
        let obj = {
          name: val.system_name,
          value: val.study_count,
        };
        if (val.study_count != '0') {
          // 注意转为number 如果percent: '0.09' 是不行的 应该要 percent: 0.09
          obj.percent = Number((val.study_count / self.totalInspect).toFixed(2));
        } else {
          obj.percent = 0;
        }
        xdata.push(val.system_name)
        ydata.push(obj);
      });
      // var xdata = ['财务管理决策实训', "商品流通业实训", "暖心陪伴（津乐园20cm定制蛋糕）", "嘉果荟萃（津乐园20cm定制蛋糕）", '优雅圆舞曲（津乐园20cm）','巧克力之夏（津乐园20cm定制蛋糕）','财税宝4G','成本会计','纳税会计与筹划','金融担保业实训'];
       option = {
        title: {
          text: self.totalInspect.toLocaleString() + '条', // 数字超过3位数后面加逗号
          subtext: "检查总量" ,
          textStyle: {
            fontSize: 18,
            color: "#333",
            fontFamily: "Aarial",
            fontWeight: "500",
          },
          subtextStyle: {
            fontSize: 14,
            color: "#909399",
            lineHeight: 20,
            fontWeight: "initial",
          },
          textAlign: "center",
          left: "22%",
          top: "40%",
        },
        // tooltip: {
        //     trigger: 'item',
        // },
        backgroundColor: "rgba(255,255,255,1)",
        color: color,
        tooltip: {
          trigger: "item",
          formatter: function (parms) {
            var str =
              parms.name +
              "</br>" +
              "数量：" +
              parms.data.value +
              "</br>" +
              "占比：" +
              parms.percent +
              "%";
            return str;
          },
        },
        legend: {
          type: "scroll",
          icon: 'circle',
          orient: 'vertical',
          x: "left",
          // top: 'center',
          top: 5,
			    bottom: 5,
          left: "45%",
          data: xdata,
          itemWidth: 10,
          itemHeight: 10,
          itemGap: 15, // 设置图例条目之间的间隔为20像素

          pageButtonPosition: 'end', // 翻页的位置。'start'：控制块在左或上,end控制块在右或下。
          pageIconColor: '#29bca8', // 可以点击的翻页按钮颜色
          pageIconInactiveColor: '#7f7f7f', // 禁用的按钮颜色
          pageIconSize: 12, //这当然就是按钮的大小
          pageButtonItemGap: 5, // 调整分页按钮项之间的间隔
          pageButtonGap: 0, // 调整分页按钮与图例项之间的间隔
          formatter: (name) => {
            const value = self.inspectProportionArr.filter(x => x.system_name == name)[0].study_count
            const fileSize = self.inspectProportionArr.filter(x => x.system_name == name)[0].file_size_description
            const newName = name.length > 10 ? `${name.slice(0, 10)}...` : name;
            var arr  = [
              '{name|'+ newName  + '}',
              '{study_count|'+ value.toLocaleString() + '条'+ '}',
              '{storage|'+ fileSize.toLocaleString() + '}',
              // '{storage|'+ fileSize.toLocaleString() + '000TB'+ '}',
            ]
            return arr.join('');
          },
          tooltip: {
            show: true,
            formatter: (params) => {
              return params.name;
            }
          },
          textStyle: {
            rich: {
              name: {
                fontSize: 14,
                align: 'left',
                color:'#303133',
                // lineHeight: 30,
                width: 140,// lengend 名字和 后面的值 之间的距离
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              },
              study_count: {
                fontSize: 14,
                align: 'center',
                color:'#303133',
                fontFamily: "Aarial",
                width: 60,
                //padding: [0, 30, 0, 0]// count 数量 的 上下前后之间的间隔设置
              },
              file_size_description: {
                fontSize: 14,
                align: 'left',
                color:'#303133',
                fontFamily: "Aarial",
                padding: [0, 20, 0, 0]
              },
              
            }
          }
        },
        series: [
          {
            type: "pie",
            radius: [65, 90],
            center: ["23%", "50%"],
            label: {
              show: false,
            },
            labelLine: {
              show: false,
            },
            itemStyle: {
              borderWidth: 2,
              borderColor: "#fff",
            },
            data: ydata,
          },
        ],
      };
      return option;
    },
   },
   watch: {
     currentNode: {
      handler(val) {
        if (val) {
          this.initVisualizationData()
        }
      },
      deep: true,
    },
   },
   methods: {
    // 存档中所有、在线、近线、离线数据的时间范围、检查数量、文件容量
    async beganGetDicomOverview () {
      const self = this
      self.file_size_list = []
      self.rangList = []// 数据范围列表
      const res = await self.$pacsApi.pacsApi.getDicomOverview();
      const { code, data, msg } = res
      if (code == 0) {
        if (data.file_size_list.length != 0) {
          data.file_size_list.forEach((item) => {
            item.start_date = item.start_date ? moment(item.start_date).format('YYYY-MM-DD') : ''
            item.end_date = item.end_date ? moment(item.end_date).format('YYYY-MM-DD') : ''
            if (item.error_date_range_list.length != 0) {
              item.error_date_range_list = item.error_date_range_list.map((oneError) => {
                return {
                  data_type: oneError.data_type,
                  data_type_name:oneError.data_type_name,
                  start_date:oneError.start_date ? moment(oneError.start_date).format('YYYY-MM-DD') : '',
                  end_date:oneError.end_date ? moment(oneError.end_date).format('YYYY-MM-DD') : '',
                }
              })
            }
            
            // 赋值 数据范围列表
            if (item.data_type !== 0){
              self.rangList.push(item)
            }
            
            if (item.data_type == 0) {//整体
              self.file_size_list.unshift(item)
            } else {
              self.file_size_list.push(item)
            }
            

          })
        }
      } else {
        self.$message.error(msg);
      }
    },
    // 获取检查统计
    async beganGetInspectTotal () {
      const res = await this.$pacsApi.pacsApi.getDicomStudyTotal({dimension: this.dimension});
      const { code, data, msg } = res
      if (code == 0) {
        this.inspectTotalArr =  data
      } else {
        this.$message.error(msg);
      }
    },
    // 跳转到统计报表界面
    gotoTotalReportPage (type) {
      var path = process.env.NODE_ENV === "development" ? "/" : "/paservice/";
      const params = {
        start_time: '',
        end_time: '',
        system_id: '',
      }
      if (type == 1) { // 检查数统计
        params.system_id = ''
        if (this.dimension === 0) {// 近一年
          params.start_time = moment().days(-364).format('YYYY-MM-DD')
          params.end_time = moment().days(1).format('YYYY-MM-DD')
        } else if (this.dimension === 1){ // 近1月
          params.start_time = moment().days(-29).format('YYYY-MM-DD')
          params.end_time = moment().days(1).format('YYYY-MM-DD')
        } else if (this.dimension === 2){ // 近7天
          params.start_time = moment().days(-6).format('YYYY-MM-DD')
          params.end_time = moment().days(1).format('YYYY-MM-DD')
        } else if (this.dimension === 3){ // 近1天
          params.start_time = moment().days(0).format('YYYY-MM-DD')
          params.end_time = moment().days(1).format('YYYY-MM-DD')
        }
      } else {// 检查占比
        params.system_id = this.chooseSystemId
        params.start_time = this.searchProportionData.start_time
        params.end_time = this.searchProportionData.end_time
      }
      this.$router.push({
        path: `${path}DataManagement/dataStatistics`,
        query: { system_id: params.system_id, start_time: params.start_time, end_time: params.end_time},
      });
    },
    // 根据时间 查询检查量
    searchInspectNumByTime (index,item) {
      if (this.curInspectTimeTabIndex == index) {
        return false
      }
      this.curInspectTimeTabIndex = index
      this.dimension = item.type
      // 重新获取影像数据范围
      this.beganGetInspectTotal()
    },
    // 获取检查占比
    async beganGetStudyProportion () {
      this.searchProportionData.system_ids = []
      if (this.chooseSystemId) {
        this.searchProportionData.system_ids.push(this.chooseSystemId)
      }
      const res = await this.$pacsApi.pacsApi.getStudyProportion(this.searchProportionData);
      const { code, data, msg } = res
      if (code == 0) {
        this.inspectProportionArr =  data
        if (res.page) {
          this.totalInspect = res.page.total_count
        }
      } else {
        this.$message.error(msg);
      }
    },
    // 检查占比时间查询
    getTimes(val) {
      val = val || ['', '']
      this.searchProportionData.start_time = val[0]
      this.searchProportionData.end_time = val[1]
      this.beganGetStudyProportion()
    },
    showInspectDeatil () {
      const self = this
      self.showInspectDetailAlert = true
      self.$nextTick(() => {
        self.$refs.inspectDetailRef.chooseSystemId = self.chooseSystemId
        self.$refs.inspectDetailRef.initData([this.searchProportionData.start_time,this.searchProportionData.end_time])
      })
    },
    // 获取设备列表
    async beganGetDicomDeviceUsageList () {
      const self = this
      self.onlineDeviceArr = []
      self.offineDeviceArr = []
      const res = await self.$pacsApi.pacsApi.getDicomDeviceUsageList();
      const { code, data, msg } = res
      if (code == 0) {
        if (data.length != 0) {
          data.forEach((item) => {
            item.record_date_start =  moment(item.record_date_start).format('YYYY-MM-DD')
            item.record_date_end =  moment(item.record_date_start).format('YYYY-MM-DD')
            if (item.device_category === 0) { // 在线
              self.onlineDeviceArr.push(item)
            } else if (item.device_category === 1) {// 近线
              self.offineDeviceArr.push(item)
            }
          })
        }
      } else {
        self.$message.error(msg);
      }
    },
    // 初始化 数据可视化数据
    initVisualizationData () {
      // 设置检查占比 的统计范围时间默认为近一个月
      this.$refs.searchTimeModel.time = [moment().days(-29).format('YYYY-MM-DD'), moment().days(1).format('YYYY-MM-DD')]
      this.searchProportionData.start_time = moment().days(-29).format('YYYY-MM-DD')
      this.searchProportionData.end_time = moment().days(1).format('YYYY-MM-DD')
      // 获取影像数据总览
      this.beganGetDicomOverview()
      // 获取检查量统计
      this.beganGetInspectTotal()
      // 获取检查量占比
      this.beganGetStudyProportion()
      // 获取设备列表
      this.beganGetDicomDeviceUsageList()
    },
   },
   created () {
     // 设置检查占比 的统计范围时间默认为近一个月
    //this.$refs.searchTimeModel.time = [moment().days(-29).format('YYYY-MM-DD'), moment().days(1).format('YYYY-MM-DD')]
   },
   mounted() {
    this.initVisualizationData()
    // this.inspectProportionArr = [
    //    {
    //      content:'放射系统',
    //      count: 20,
    //    },
    //    {
    //      content:'核医学系统',
    //      count: 40,
    //    },
    //    {
    //      content:'放疗系统',
    //      count: 30,
    //    },
    //    {
    //      content:'放疗系统2',
    //      count: 30,
    //    },
    //    {
    //      content:'放疗系统3',
    //      count: 30,
    //    },
    //    {
    //      content:'放疗系统4',
    //      count: 30,
    //    },
    //    {
    //      content:'放疗系统5',
    //      count: 30,
    //    },
    //    {
    //      content:'放疗系统6',
    //      count: 30,
    //    },
    //   //  {
    //   //    content:'放疗系统7',
    //   //    count: 30,
    //   //  },
    //   //  {
    //   //    content:'放疗系统8',
    //   //    count: 30,
    //   //  },
    //  ]
   }
}
</script>
<style lang="less" scoped>
.dataVisualizationCon{
//   height: calc(100vh - 50px);
  overflow: hidden;
  height: 100%;
  .contentContainer{
    padding:10px;
    height: calc(100% - 47px);
    overflow-y: auto;
    overflow-x: hidden;
    background-color: #EBEEF5;
    box-sizing: border-box;
    width: 100%;
    .imageOverview{
      padding: 10px 0;
      background: #fff;
      padding-top:0;
      border-radius: 4px;
    }
    ::v-deep .navHead{
      display: flex;
      align-items: center;
      border-bottom: 1px solid #DCDFE6;
      padding: 0 10px;
      height: 30px;
      box-sizing: border-box;
      .navHeadIcon{
        width: 3px;
        height: 14px;
        margin-right: 5px;
        background: #0A70B0;
      }
      .tipIcon{
        font-size:14px;
        cursor: pointer;
        position: relative;
        top:-1px;
      }
      .navHeadRight{
        flex: 1;
        text-align: right;
        display: flex;
        align-items: center;
        justify-content: flex-end;
        .totalChartIcon{
          font-size:16px;
          color:#0A70B0;
          cursor: pointer;
        }
        .searchInspectQuery{
          display: flex;
          align-items: center;
          span{
            padding:5px 10px;
            font-size: 14px;
            color: #303133;
            cursor: pointer;
            margin-right:5px;
          }
          .activeSpan{
            background: #F0F4F9;
            border-radius: 4px;
            color: #0A70B0;
          }
        }
        .splitIcon{
          width: 1px;
          height: 20px;
          background: #DCDFE6;
          margin-right: 15px;
          margin-left:5px;
        }
        .serviceStatusBox{
          display: flex;
          align-items: center;
          .statusIcon{
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #0AA539;
            margin-right:5px;
            margin-left:20px;
          }
        }
      }
      .watchTotalReport{
        cursor: pointer;
      }
      
      .inspectReportCon{
        cursor: pointer;
        .totalChartIcon{
          font-size:16px;
          color:#0A70B0;
          cursor: pointer;
        }
      }
    }
    .inspectNavHead{
      justify-content: space-between;
     }
    .imageDataCon{
       background:#fff;
       display: flex;
       flex-flow: wrap;
       margin: 0 3.5px!important;
      .oneImgageData{
        padding:13px 10px;
        margin-top:10px;
        background:#F0F4F9;
        position: relative;
        border-radius: 4px;
        .oneImgageDataHead{
          display: flex;
          justify-content: space-between;
          align-items: center;
          i {
            font-size:16px;
            color:#419EFF;
            margin-right: 5px;
          }
          .onlineIcon{
            color:#14C3C3;
          }
          .atLineIcon{
            color:#FBCD14;
          }
          .offlineIcon{
            color:#D8D8D8;
          }
          .oneImgageDataHeadTit{
            font-weight: 500;
            font-size: 14px;
            color: #303133;
          }
        }
        .oneImgageDataParamLabel{
          font-size: 14px;
          color: #606266;
        }
        .imgageDataParamCon{
          display: flex;
          align-items: center;
          margin-top:10px;
        }
        .splitLine{
          width:2px;
          height: 46px;
          background:rgba(48, 49, 51, 0.1);
        }
        .oneImgageDataParam{
          flex: 1;
          display: flex;
          flex-flow: column;
          align-items: center;
          justify-content: center;
          .oneImgageDataParamBox{
            display: flex;
            flex-flow: column;
            align-items: center;
          }
          .paramValue{
            color: #303133;
            font-size: 22px;
            font-family: Arial;
            font-weight: 900;
            .unit{
              color: #303133;
              font-size: 14px;
              font-weight: 600;
              padding-left:5px;
            }
          }
        }
      }
      .oneImageErrorData{
        background: #FFF1F0;
        border: 1px solid #FFCCC7;
      }
      .normalStatus  {
        background:#F0F4F9;
      }
      // .oneImgageData:last-of-type{
      //   margin-right: 0;
      // } 
    }
    .rangContainer{
      .containerLeft{
        .rangContainer{
          background:#fff;
          display: flex;
          flex-flow: column;
          padding-top:10px
        }
        .rangCon{
          background: #fff;
          border-radius: 4px;
          margin: 10px;
          margin-top:30px;
        }
      }
    }
    // 影像数据范围 和 检查量统计 和 检查占比 和 数据同步
    .imageDataRangAndOther{
      display: flex;
      .containerLeft{
        width: calc(100% - 566px);
        .inspectNumTotal{
          background:#fff;
          border-radius: 4px;
          .inspectNumbar{
            height: 237px;
            padding:0 20px;
            // width:calc(100% - 40px);
          }
        }
      }
      .containerRight{
        width:566px;
        .inspectProportion{
          background: #fff;
          border-radius: 4px;
        }
        .inspectProportionQuery{
          display: flex;
          align-items: center;
          margin-top:10px;
          padding: 0 10px;
          .queryLabel{
            font-size:13px;
            color:#303133;
          }
        }
        .inspectProportionChart{
          height: 195px;
          padding-left:20px;
          width:calc(100% - 20px);
          position: relative;
          .watchMoreInspect{
            position: absolute;
            right: 10px;
            bottom: 10px;
            font-size: 14px;
            color: #6C89BB;
            cursor: pointer;
            i{
              font-size:16px;
              position: relative;
              top: 1px
            }
          }
        }
      }
    }
    ::v-deep .dataSync{
          width:380px;
          background:#fff;
          margin-right: 10px;
          border-radius: 4px;
          .dataSyncCon{
            padding:10px;
            height: 110px;
            box-sizing: border-box;
            overflow: hidden;
            .dataSyncStatus{
              height: 28px;
              background: #F0F4F9;
              border-radius: 4px;
              display:flex;
              align-items: center;
              justify-content: space-between;
              padding:0 10px;
              font-weight: 500;
              font-size: 14px;
              color: #1C8BE4;
              .serviceStatusNum{
                font-size: 14px;
                color: #FF0000;
                text-decoration: underline;
                cursor: pointer;
              }
              img{
                width:60px;
              }
            }
            .dataSyncPathCon{
              // margin-top:7px;
              .doingOperateName{
                font-size: 13px;
                color: #606266;
              }
            }
          }
        }
    .dataStatus{
      width: 40px;
      height: 20px;
      line-height: 18px;
      margin-left:5px;
      text-align: center;
      background: #F6FFED;
      border: 1px solid #D9F7BE;
      border-radius: 4px;
      font-size: 12px;
      color: #1CB54A;
      position: absolute;
      bottom: 0px;
      right:0px;
    }
    .dataErrorStatus{
      background: #FFF1F0;
      border-color: #FFCCC7;
      color:#FF0000;
      font-weight: 700;
    }
    // 数据近线 压缩 离线
    .dataLineContainer{
      display: flex;
      .dataRecentLine{
        background: #fff;
      }
      .dataHead{
        justify-content: space-between;
        .dataHeadLeft{
          display: flex;
          align-items: center;
        }
        .dataStatus{
          position: initial;
        }
      }
    }
    // 在线存储、近线存储
    .storageDeviceContainer{
      display: flex;
      .containerLeft{
        .containerLeftBox{
          height: 100%;
          background:#fff;
          border-radius: 4px;
          .onlineDevice{
            height: calc(100% - 30px);
          }
        }
      }
      .containerRight{
        .containerRightBox{
          height: 100%;
          background:#fff;
          border-radius: 4px;
          .offlineDevice{
            height: calc(100% - 30px);
          }
        }
      }
    }
  }
}
</style>
