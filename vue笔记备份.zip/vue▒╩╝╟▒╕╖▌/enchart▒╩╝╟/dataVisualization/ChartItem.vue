<template>
  <div class="chart-container" ref="chartContainer">

  </div>
</template>
<script>
import * as echarts from 'echarts'
export default {
  props: {
    option: {
      type: Object,
      require: true
    },
    action: String
  },
  data() {
    return {
      charObj: null
    }
  },
  watch: {
    option:{
      handler () {
        const self = this
        self.charObj = self.charObj || echarts.init(self.$refs.chartContainer)
        const option = self.option
        option && self.charObj.setOption(option, { notMerge: true })

        // 监听图例鼠标移入事件
        // self.charObj.on('mouseover', function(e) {
        //   if (e.componentType === 'legend') {
        //     // 显示所有系列
        //     self.charObj.dispatchAction({
        //       type: 'showTip',
        //       seriesIndex: 'all'
        //     });
        //   }
        // });

         self.charObj.getZr().on('click', function(params) {
            let pointInPixel = [params.offsetX, params.offsetY]
            if (self.charObj.containPixel('grid', pointInPixel)) {
              let xIndex = self.charObj.convertFromPixel({ seriesIndex: 0 }, [params.offsetX, params.offsetY])[0]
              //console.log(xIndex)
              //console.log(params)
              self.charObj.dispatchAction({
                    type:'select',
				            seriesIndex: xIndex,//这行不能省
                })
              self.$emit('clickChartFunc',xIndex, self.action)
            }
        })
      },
      deep: true
    } 
  },
  mounted() {
    const self = this
    self.$nextTick(()=> {
      if (self.option) {
       self.charObj = echarts.init(self.$refs.chartContainer)
       self.charObj.setOption(self.option, { notMerge: true })
       // self.charObj.getZr().on('click', function(params) {
      
     }
  })
    
  },
}
</script>
<style lang="less" scoped>
.chart-container {
  width: 100%;
  height: 100%;
}
</style>