<template>
  <div class="h_full">
    <div class="title-bar flex_row">
      <div class="crumbsCon pl10">
        <!-- <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>医疗机构<i
            class="iconfont iconzhankaishouqi"
          ></i>
        </span> -->
        <div class="m-tab">
          <div
            class="m-tab-item"
            :class="tabIndex === index ? 'm-tab-item-active' : ''"
            v-for="(item, index) in tabList"
            :key="index"
            @click="toggleTab(index, item.value)"
          >
            {{ item.label }}
          </div>
          <div class="tab-line" :style="{ left: number + 'px' }"></div>
        </div>
      </div>
    </div>
    <div class="productContainer h_full" v-if="this.tabType == 1">
      <div class="productContainerLeft" :style="{'width':offsetWidth+'px'}">
        <div class="treeBox" :style="{'width':offsetWidth+'px'}">
          <div class="productSearch">
            <el-input
              size="small"
              class="productSearchInput"
              v-model="prodName"
              suffix-icon="el-icon-search"
              placeholder="输入产品名称查询"
            ></el-input>
            <span class="addProductBtn" @click="addFolder">
              <i class="iconfont dev-iconfont">&#xe626a;</i>
            </span>
          </div>
          <div class="treeCon">
            <treeMenu
              ref="treeMenu"
              :treeData="treeData"
              :defaultProps="defaultProps"
              :selectData="selectData"
              :offsetWidth="offsetWidth"
              :isEdit="isEdit"
              @handleAdd="handleAdd"
              @handleEdit="handleEdit"
              @handleRemove="handleRemove"
              @handleTitleRemove="handleTitleRemove"
              @clickTreeItem="clickTreeItem"
              @refreshTree="getTree"
            >
            </treeMenu>
          </div>
         </div>
        <!-- <ul class="mt5 ml10 mr10 f15 list">
          <li
            v-for="(item, index) in cProdList"
            :key="index"
            :class="[item.id === currentProd.id ? 'active' : '']"
            class="strong prod-css1 pointer h32 lh32 pl12 pr12 mb2"
            @click="changeCurrentProd(item)"
            :title="item.productName"
          >
            <span class="fl ellipsis1 list-item__name dib">
              {{ item.productName }}
            </span>
            <span
              class="fr fArial clr_ff9900"
              :class="[item.id === currentProd.id ? 'clr_main' : '']"
            >
              {{ item.subCount }} / {{ item.relyCount }} /
              {{ item.subCount + item.relyCount }}
            </span>
          </li>
        </ul> -->
        <div class="resize" title="收缩侧边栏"></div>
        
      </div>
      <div class="productContainerRight h_full" :style="{'width':'calc(100% - ' + (offsetWidth + 1) + 'px)'}">
        <!--选择的是文件夹 子系统 -->
        <div class="moreSystem" v-if="selectData.is_group">
          <div class="curProductInfor">
            <div class="curProductNameCon">
              <span class="curProductName">产品组名称：{{productDetailObj.name}}</span>
              <span class="updateProductIcon" @click="beganUpdateProductGroup"><i class="dev-iconfont">&#xe661e;</i>编辑</span>
            </div>
            <div class="productDesc">
              产品描述：{{productDetailObj.description}}
            </div>
          </div>
          <div class="productTitHead">
            <div class="productTitHeadLeft">
              <img src="@/assets/images/common/governmentProduct.png" /><span
                class="productTitText"
                >管辖产品</span
              ><span class="productTitHeadTip"
                >（本产品内包含的所有子产品信息）</span
              >
            </div>
            <div class="addProductCon" @click="addProductToGroup" v-if="selectData.is_group">
              <i class="dev-iconfont">&#xe626a;</i
              ><span class="addProductConText">添加产品</span>
            </div>
          </div>
          <div class="governmentProduct" :class="{ noTableData: groupProductList.length == 0 }">
            <el-table
              :data="groupProductList"
              ref="governmentProductTable"
              class="governmentProductTable"
              height="100%"
              border
              stripe
              @row-click="rowTypeClick"
              :header-cell-style="{background: '#F2F2F2',color: '#333'}"
              highlight-current-row
              header-row-class-name="strong"
            >
              <el-table-column
                type="index"
                width="50"
                label="序"
              ></el-table-column>
              <el-table-column
                prop="servicePort"
                label="状态"
                width="90"
              >
                <template slot-scope="scope">
                  <div :style="{ color: scope.row.state ? statusObj[1].color :  statusObj[2].color }">
                    <span class="clircle mr5" :class="[scope.row.state ? 'running' : 'running stoped']" :style="{ background: scope.row.state ? statusObj[1].color :  statusObj[2].color}">
                      </span>{{ scope.row.state ? statusObj[1].label :  statusObj[2].label }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column
                prop="servicePort"
                label="目录"
                width="180"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="name"
                label="产品名称"
                width="180"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="description"
                label="产品描述"
                width="180"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="all_members"
                label="产品成员"
                show-overflow-tooltip
              ></el-table-column>
            </el-table>
          </div>
          <div class="productTitHead">
            <div class="productTitHeadLeft">
              <img src="@/assets/images/common/governmentService.png" /><span
                class="productTitText"
                >管辖服务</span
              ><span class="productTitHeadTip"
                >（本产品内包含的所有微服务信息）</span
              >
            </div>
            <div class="addProductCon" @click="addMicroservices" v-if="currentProductId">
              <i class="dev-iconfont">&#xe626a;</i
              ><span class="addProductConText">添加微服务</span>
            </div>
          </div>
          <div class="governmentService" :class="{ noTableData: productMicroserviceList.length == 0 }">
            <el-table
              :data="productMicroserviceList"
              class="governmentServiceTable"
              :height="tableHeight"
              border
              stripe
            >
              <el-table-column
                type="index"
                width="50"
                label="序"
              ></el-table-column>
              <!-- <el-table-column prop="servicePort" label="操作" width="90">
                <template slot-scope="scope">
                  <div class="serviceOperate">
                    <span class="updateServe">编辑</span>
                    <span class="deleteServe" v-if="scope.row.enable">停用</span>
                    <span class="updateServe" v-else>启用</span>
                  </div>
                </template>
              </el-table-column> -->
              <el-table-column
                prop="enable"
                label="状态"
                width="90"
                show-overflow-tooltip
              >
                <template slot-scope="scope">
                  <div :style="{ color: scope.row.enable ? statusObj[1].color :  statusObj[2].color }">
                    <span class="clircle mr5" :class="[scope.row.enable ? 'running' : 'running stoped']" :style="{ background: scope.row.enable ? statusObj[1].color :  statusObj[2].color}">
                      </span>{{ scope.row.enable ? statusObj[1].label :  statusObj[2].label }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column
                prop="product_name"
                label="产品"
                width="180"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="name"
                label="微服务"
                width="180"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="describle"
                label="产品描述"
                width="180"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="relationship"
                label="产品依赖"
                show-overflow-tooltip
              >
                <template slot-scope="scope">
                   <span>{{scope.row.relationship == 1 ? '基础服务' : '依赖服务'}} </span>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <!-- <pagination
            :pageIndex="governmentServiceParam.pageIndex"
            :pageSize="governmentServiceParam.pageSize"
            :total="totalService"
            @pagination="getProductServicePageList"
          ></pagination> -->
        </div>

        <!---选择了子系统下的 某个产品-->
        <div class="systemProductBox" v-if="!selectData.is_group">
           <systemProduct :productDetailObj="productDetailObj" :productMicroserviceList="productMicroserviceList" @addMicroservices="addMicroservices" @beganUpdateProduct="beganUpdateProduct"></systemProduct>
        </div>
      </div>
    </div>
    <!--产品清单-->
    <div class="inventoryContainer" v-show="this.tabType == 2">
      <inventory ref="inventory" @addMicroservices="addMicroservices"></inventory>
    </div>
    <!--产品微服务列表-->
    <div class="inventoryContainer" v-show="this.tabType == 3">
      <productMicroServiceList ref="productMicroServiceList" @addMicroservices="addMicroservices"></productMicroServiceList>
    </div>
    <!-- 添加产品或编辑产品 -->
    <el-dialog
      title="添加产品"
      :top="'10vh'"
      class="addProductAlert"
      :visible.sync="showAddProductAlert"
      width="500px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <addProduct
        ref="addProduct"
        :treeData="treeData"
        :addProductParams="addProductParams"
      ></addProduct>
      <template slot="footer">
        <el-button size="small" plain @click="showAddProductAlert=false">取消</el-button>
        <el-button type="primary" size="small" @click="sureAddProduct">确定</el-button>
      </template>
    </el-dialog>

    <!-- 添加产品或编辑产品 -->
    <el-dialog
      title="新增文件夹"
      :top="'10vh'"
      :visible.sync="showAddFolderAlert"
      width="500px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <addFolder
        ref="addFolder"
        :treeData="treeData"
        :addFolderParams="addFolderParams"
      ></addFolder>
      <template slot="footer">
        <el-button size="small" plain @click="showAddFolderAlert=false">取消</el-button>
        <el-button type="primary" size="small" @click="sureAddFolder">确定</el-button>
      </template>
    </el-dialog>

    <!-- 编辑产品组 -->
    <el-dialog
      title="编辑产品组"
      :top="'10vh'"
      :visible.sync="showUpdateProductGroupAlert"
      width="450px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <updateProductGroup
        ref="updateProductGroup"
        :updateProductGroupParams="updateProductGroupParams"
      ></updateProductGroup>
      <template slot="footer">
        <el-button size="small" plain @click="showUpdateProductGroupAlert=false">取消</el-button>
        <el-button type="primary" size="small" @click="sureUpdateProductGroup">确定</el-button>
      </template>
    </el-dialog>

    <!-- 编辑产品 -->
    <el-dialog
      :title="productTitle"
      :top="'10vh'"
      :visible.sync="showUpdateProductAlert"
      width="750px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <updateProduct
        ref="updateProduct"
        :isUpdate="true"
        :updateProductParams="updateProductParams"
      ></updateProduct>
      <template slot="footer">
        <el-button size="small" plain @click="showUpdateProductAlert=false">取消</el-button>
        <el-button type="primary" size="small" @click="sureUpdateProduct">确定</el-button>
      </template>
    </el-dialog>

    <!-- 添加微服务 -->
    <el-dialog
      title="添加微服务"
      :top="'10vh'"
      :visible.sync="showAddServiceAlert"
      width="420px"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <addMicroservices
        ref="addMicroservices"
        :addServiceParams="addServiceParams"
      ></addMicroservices>
      <template slot="footer">
        <el-button size="small" plain @click="showAddServiceAlert=false">取消</el-button>
        <el-button type="primary" size="small" @click="sureAddService">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import treeMenu from "./treeMenu";
import inventory from "./inventory";
import productMicroServiceList from "./productMicroServiceList"
import systemProduct from "./components/systemProduct";
import addFolder from './components/addFolder'
import addProduct from "./components/addProduct";
import addMicroservices from "./components/addMicroservices";
import updateProductGroup from "./components/updateProductGroup"
import updateProduct from "./components/updateProduct"
import pagination from "@/components/common/pagination";
import { getProductPageList, getProductServicePageList } from "@/api/devops";
import { getStandardTree, addMicroservicesFn,addFolderFn, updateProductGroupFn, addProductToGroup, updateProductFn, getProductGroupDetail, getProductDetail,
getGroupProductList, getProductMicroserviceList, createProductFn, removeGroupProduct, addProductMicroservice } from "@/api/productManage";
export default {
  name: "index",
  components: {
    treeMenu,
    inventory,
    productMicroServiceList,
    pagination,
    systemProduct,
    addFolder,
    addProduct,
    addMicroservices,
    updateProductGroup,
    updateProduct,
  },
  data() {
    this.serviceType = {
      1: "基础服务",
      2: "依赖服务",
      3: "关联服务",
    };
    return {
      tabIndex: 0,
      number: 0,
      tabType: 1,
      tabList: [
        {
          label: "产品设置",
          value: 1,
        },
        {
          label: "产品清单",
          value: 2,
        },
        {
          label: "产品微服务",
          value: 3,
        },
        {
          label: "服务依赖清单",
          value: 4,
        },
      ],
      statusObj:{
        1: { label: '在用',  color: '#1890ff' },
        2: { label: '停用',  color: '#da4a4a' },
      },
      tableHeight: "100%",
      governmentProductList: [], // 管辖产品列表
      keyWord: "",
      prodName: "",
      currentProd: {},
      pageIndex: 1,
      pageSize: 20,
      total: 0,
      // 树形图数据
      treeData: [],
      defaultProps: {
        // children: "childrenStandard",
        // label: "label",
        children: "children",
        label: "name"
      },
      selectData: {
        nameList: [],
      },
      offsetWidth: 245,
      isEdit: -1,
      governmentServiceParam: {
        pageIndex: 1,
        pageSize: 10,
      },
      totalService: 0,
      addProductParams: {
        product_ids: [],
        group_id: '',
      },
      addFolderParams: {
        name: '',
        parent_id: '',
      },
      showAddProductAlert: false,// 添加产品
      showAddServiceAlert: false,// 添加服务
      showAddFolderAlert: false, // 添加文件夹
      addServiceParams: {
        product_id: '',
        enable: false,
        microservice_id: '',
        relationship: '',
      },
      showUpdateProductGroupAlert: false,
      showUpdateProductAlert: false,
      updateProductParams: {
        id: '',
        name: '',
        short_name: '',
        code: '',
        description: '',
        state:true,
        allMemberList: [],
        demandMemberList: [],
        issueMemberList: [],
      },
      updateProductGroupParams: {
        id: '',
        name: '',
        description: '',
      },
      productDetailObj: {
        parent_id: '',
        name: '',
        description: '',
        enabled: false,
      },
      groupProductList: [],
      productMicroserviceList: [],
      productTitle: '新增产品',
      isUpdateProduct: true,
      currentProductId: '',
    };
  },
  watch: {
    prodName(val) {
      this.$refs.treeMenu.filterText(val);
    },
    groupProductList: function () {
      this.$nextTick(function () {
        if (this.groupProductList.length != 0) {
          this.$refs.governmentProductTable.setCurrentRow(this.groupProductList[0])
        }
      })
    }
  },
  computed: {
    cProdList() {
      const name = this.prodName.trim();
      if (name) {
        return this.prodList.filter(
          (ele) => ele.productName.indexOf(name) > -1
        );
      }
      return this.prodList;
    },
  },
  async mounted() {
    // if (this.prodList[0]) {
    //   this.currentProd = this.prodList[0]
    //   this.getProductServicePageList()
    // }
    this.getTree();
    setTimeout(() => {
      this.dragControllerDiv()
    },1000)

  },
  methods: {
    dragControllerDiv() {
      const _this = this
      var resize = document.getElementsByClassName('resize');
      for (let i = 0; i < resize.length; i++) {
        resize[i].onmousedown = function(e) {
          const menuWidth = localStorage.getItem('isCollapse') === 'false' ? 245 : 64
          _this.moveStatus = true
          document.onmousemove = function(e) {
            if (_this.moveStatus && ((e.clientX - menuWidth) < 500 && (e.clientX - menuWidth) > 200)) {
              _this.offsetWidth = e.clientX - menuWidth - 130
            }
          };
          document.onmouseup = function(evt) {
            _this.moveStatus = false
          };
          return false;
        };
      }
    },

    toggleTab(index, value) {
      this.tabType = value;
      if (this.tabIndex < index) {
        this.number = index * 90 + index * 10; //90既是一个tab的宽度 也是tab下滑动横线的宽度
      } else {
        this.number =
          this.number -
          (this.tabIndex - index) * 90 -
          (this.tabIndex - index) * 10; // 10为tab之前的margin值 下面样式有设置
      }
      if (this.tabIndex != index) {
        if (this.tabType == 1) {
          // 获取产品树和产品详情
          this.getTree();
        } else if (this.tabType == 2) {
          // 产品清单列表
          this.$refs.inventory.benganGetInventoryList()
        } else if (this.tabType == 3) {
          // 产品微服务
          this.$refs.productMicroServiceList.benganGetProductMicroServiceList()
        }
      }
      this.tabIndex = index;
    },
    // 确定添加产品
    async sureAddProduct () {
      if (this.addProductParams.product_ids.length == 0) {
        this.$message.error('请至少选择一个产品')
        return
      }
      const res = await addProductToGroup(this.addProductParams)
      if (res.code == 0) {
        this.$message.success('新增产品成功')
        this.showAddProductAlert = false
        this.getTree()
      } else {
        this.$message.error(res.message)
      }
    },
    // 添加文件夹
    addFolder () {
      this.showAddFolderAlert = true
    },
    // 确定新增文件夹
    async sureAddFolder () {
      if (this.addFolderParams.name == '') {
        this.$message.error('请输入文件夹名称')
        return
      }
      const res = await addFolderFn(this.addFolderParams)
      if (res.code == 0) {
        this.$message.success('新增文件夹成功')
        this.showAddFolderAlert = false
        this.getTree()
      } else {
        this.$message.error(res.message)
      }
    },
    // 添加微服务
    addMicroservices () {
      const self = this
      self.addServiceParams = {
        product_id: '',
        enable: false,
        microservice_id: '',
        relationship: '',
      }
      self.showAddServiceAlert = true
      self.$nextTick(() => {
        self.$refs.addMicroservices.getAllProductMicroservice()
      })
    },
    validateAddService(){
      if (this.addServiceParams.microservice_id == '') {
        this.$message.error('请选择一个微服务')
        return
      }
      if (this.addServiceParams.relationship == '') {
        this.$message.error('请选择依赖关系')
        return
      }
      return true
    },
    // 确定添加微服务
    async sureAddService () {
      if (this.validateAddService()) {
        if (this.selectData.is_group) { // 当前的是产品分组
          this.addServiceParams.product_id = this.currentProductId
        } else {
          this.addServiceParams.product_id = this.selectData.id
        }
        const res = await addProductMicroservice(this.addServiceParams)
        if (res.code == 0) {
          this.$message.success('新增微服务成功')
          this.showAddServiceAlert = false
          if (this.selectData.is_group) { // 当前的是产品分组
            this.beganGetProductMicroserviceList(this.currentProductId)
          } else { // 选择的是 子系统(某个产品)
            this.beganGetProductMicroserviceList(this.selectData.id)
          }
        } else {
          this.$message.error(res.message)
        }
      }
    },
    // 编辑产品
    beganUpdateProduct () {
      this.productTitle = '编辑'
      this.isUpdateProduct = true
      this.showUpdateProductAlert = true
    },
    validateUpdateOrAddProduct () {
      if (this.updateProductParams.name == '') {
        this.$message.error('请输入产品名称')
        return
      }
      return true
    },
    // 确定编辑或新增产品
    async sureUpdateProduct () {
     if (this.validateUpdateOrAddProduct()) {
        let tip = this.isUpdateProduct? '编辑产品成功' : '新增产品成功'
        const res = await updateProductFn(this.updateProductParams)
        if (res.code == 0) {
          this.$message.success(tip)
          this.showUpdateProductAlert = false
          this.beganGetProductDetail(this.updateProductParams.id)
        } else {
          this.$message.error(res.message)
        }
      }     
    },
    // 添加产品 到某个文件夹（子系统）
    addProductToGroup () {
      const self = this
      self.addProductParams.group_id = self.selectData.id
      self.showAddProductAlert = true
      self.$nextTick(() => {
        self.$refs.addProduct.beganGetAllProduct() 
      })
    },
    beganUpdateProductGroup () {
      this.showUpdateProductGroupAlert = true
    },
    // 验证编辑产品组
    validateUpdateProductGroup () {
      if (this.updateProductGroupParams.name == '') {
        this.$message.error('请输入产品组名称')
        return
      }
      return true
    },
    // 编辑产品组
    async sureUpdateProductGroup () {
      if (this.validateUpdateProductGroup()) {
        let tip = '编辑产品组成功'
        const res = await updateProductGroupFn(this.updateProductGroupParams)
        if (res.code == 0) {
          this.$message.success(tip)
          this.showUpdateProductGroupAlert = false
          this.beganGetProductGroupDetail(this.updateProductGroupParams.id)
        } else {
          this.$message.error(res.message)
        }
      }       
    },
    // 树形绑定方法
    handleAdd(val) {
      this.isEdit = -1;
      // this.selectData = val
      this.editFormStatus = true;
      this.editForm = val;
    },
    // 树状图 编辑产品目录
    handleEdit(productGroupDetailObj) {
      this.showUpdateProductGroupAlert = true;
      this.updateProductGroupParams.id = productGroupDetailObj.id
      this.updateProductGroupParams.name = productGroupDetailObj.name
      this.updateProductGroupParams.description = productGroupDetailObj.description
    },
    handleTitleRemove() {
      if (this.selectData.id) {
        if (this.selectData.level === 1) {
          this.$message.warning("一级标准不能删除!");
          return false;
        }
        this.handleRemove(this.selectData);
      }
    },
    handleRemove(row) {
      this.$confirm(
        '是否确定删除 <span style="color: #0099ff">' + row.key + "</span> ?",
        "删除",
        {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          dangerouslyUseHTMLString: true,
          type: "warning",
        }
      )
        .then(() => {
          const titleParams = {
            group_id: row.parent_id,
            product_ids: [row.id],
          };
          removeGroupProduct(titleParams).then((res) => {
            if (res.code === 0) {
              this.$message.success("删除成功!");
              if (this.treeData.length && this.selectData.id === row.id) {
                this.selectData = this.treeData[0];
              }
              if (row.level === 5) {
                this.editMappingClose();
              } else {
                this.getTree();
              }
            }
          });
        })
        .catch(() => {});
    },
    clickTreeItem(data) {
      this.selectData = data;
      //console.log('this.selectData',this.selectData)
      // 获取右侧产品详情
      if (this.selectData.is_group) { // 如果是产品分组
        this.beganGetProductGroupDetail(this.selectData.id)
      } else { // 子系统
        this.beganGetProductDetail(this.selectData.id)
      }
      
      // 获取右侧 文件夹(子系统) 下的产品列表
      this.beganGetGroupProductList(this.selectData.id)
      // 获取右侧 文件夹(子系统) 下的微服务列表
      this.beganGetProductMicroserviceList(this.selectData.id)
    },
    // 获取右侧产品详情
    async beganGetProductGroupDetail(productId){
      const res = await getProductGroupDetail(productId)
      if (res.code == 0) {
        this.productDetailObj = res.data
        this.updateProductGroupParams.id = res.data.id
        this.updateProductGroupParams.name = res.data.name
        this.updateProductGroupParams.description = res.data.description
      } else {
        this.$message.error(res.message)
      }
    },
    // 获取右侧子系统的 产品详情
    async beganGetProductDetail(productId){
      const res = await getProductDetail(productId)
      if (res.code == 0) {
        this.productDetailObj = res.data
        this.updateProductParams = {
          id:res.data.id,
          name: res.data.name,
          short_name: res.data.short_name,
          code: res.data.code,
          description: res.data.description,
          state:res.data.state,
          allMemberList: res.data.allMemberList,
          demandMemberList: res.data.demandMemberList,
          issueMemberList: res.data.issueMemberList,
        }
      } else {
        this.$message.error(res.message)
      }
    },
    // 点击选择 右侧的某个产品
    rowTypeClick (row, column, event) {
      if (row.id !== this.currentProductId) {
        this.currentProductId = row.id
        this.beganGetProductMicroserviceList(row.id)
      }
    },
    // 获取右侧 文件夹(子系统) 下的产品列表
    async beganGetGroupProductList(productId){
      const res = await getGroupProductList(productId)
      if (res.code == 0) {
        this.groupProductList = res.data
        // 如果当前的是产品分组的话  默认展示 第一个产品的 微服务
        if (this.selectData.is_group && this.groupProductList.length != 0) {
          this.currentProductId = this.groupProductList[0].id
          this.beganGetProductMicroserviceList(this.groupProductList[0].id)
        }
      } else {
        this.$message.error(res.message)
      }
    },
    // 获取右侧 文件夹(子系统) 下的微服务列表
    async beganGetProductMicroserviceList(productId){
      const res = await getProductMicroserviceList(productId)
      if (res.code == 0) {
        this.productMicroserviceList = res.data
      } else {
        this.$message.error(res.message)
      }
    },
    handleCheck(val) {
      this.$refs.treeMenu.setCurrentSelect(val);
      this.selectData = this.$refs.treeMenu.$refs.tree.getCurrentNode();
    },
    getTree() {
      // const res = {
      //   code: 0,
      //   msg: "请求成功",
      //   data: [
      //     {
      //       id: 1,
      //       tenancyId: "1286595526610915328",
      //       key: "国家标准",
      //       value: "Ws364",
      //       path: "/",
      //       level: 1,
      //       organizationId: null,
      //       organizationName: null,
      //       businessTag: null,
      //       businessValue: null,
      //       describe: "国标是值域类型",
      //       udfFuncId: null,
      //       createBy: null,
      //       createId: null,
      //       createTime: "2023-04-21 17:08:35",
      //       updateBy: null,
      //       updateId: null,
      //       updateTime: "2023-04-21 17:08:35",
      //       isDeleted: 0,
      //       children: [
      //         {
      //           id: 188,
      //           tenancyId: "1286595526610915328",
      //           key: "测试",
      //           value: null,
      //           path: "/1/",
      //           level: 2,
      //           organizationId: null,
      //           organizationName: null,
      //           businessTag: null,
      //           businessValue: null,
      //           describe: null,
      //           udfFuncId: null,
      //           createBy: "未知用户",
      //           createId: "0",
      //           createTime: "2023-08-01 13:51:24",
      //           updateBy: null,
      //           updateId: null,
      //           updateTime: "2023-08-01 13:51:24",
      //           isDeleted: 0,
      //           children: [],
      //         },
      //       ],
      //     },
      //     {
      //       id: 2,
      //       tenancyId: "1286595526610915328",
      //       key: "明天医网标准",
      //       value: "mtyw",
      //       path: "/",
      //       level: 1,
      //       organizationId: null,
      //       organizationName: null,
      //       businessTag: null,
      //       businessValue: null,
      //       describe: "明天医网标准是值域类型",
      //       udfFuncId: null,
      //       createBy: null,
      //       createId: null,
      //       createTime: "2023-04-21 17:08:35",
      //       updateBy: null,
      //       updateId: null,
      //       updateTime: "2023-04-21 17:08:35",
      //       isDeleted: 0,
      //       children: [
      //         {
      //           id: 39,
      //           tenancyId: "1286595526610915328",
      //           key: "社会经济学特征",
      //           value: "2",
      //           path: "/2/",
      //           level: 2,
      //           organizationId: null,
      //           organizationName: null,
      //           businessTag: null,
      //           businessValue: null,
      //           describe: "",
      //           udfFuncId: null,
      //           createBy: null,
      //           createId: null,
      //           createTime: "2023-04-25 16:28:01",
      //           updateBy: "未知用户",
      //           updateId: "0",
      //           updateTime: "2023-08-01 14:00:31",
      //           isDeleted: 0,
      //           children: [
      //             {
      //               id: 189,
      //               tenancyId: "1286595526610915328",
      //               key: "地理位置",
      //               value: "dlwz",
      //               path: "/2/39/",
      //               level: 3,
      //               organizationId: null,
      //               organizationName: null,
      //               businessTag: null,
      //               businessValue: null,
      //               describe: null,
      //               udfFuncId: null,
      //               createBy: "未知用户",
      //               createId: "0",
      //               createTime: "2023-08-01 13:53:53",
      //               updateBy: "未知用户",
      //               updateId: "0",
      //               updateTime: "2023-08-01 14:00:18",
      //               isDeleted: 0,
      //               children: [],
      //             },
      //           ],
      //         },
      //         {
      //           id: 77,
      //           tenancyId: "1286595526610915328",
      //           key: "人口学特征",
      //           value: "test1",
      //           path: "/2/",
      //           level: 2,
      //           organizationId: null,
      //           organizationName: null,
      //           businessTag: null,
      //           businessValue: null,
      //           describe: null,
      //           udfFuncId: null,
      //           createBy: null,
      //           createId: null,
      //           createTime: "2023-04-28 13:23:36",
      //           updateBy: "未知用户",
      //           updateId: "0",
      //           updateTime: "2023-08-01 14:00:37",
      //           isDeleted: 0,
      //           children: [
      //             {
      //               id: 78,
      //               tenancyId: "1286595526610915328",
      //               key: "性别类",
      //               value: "xb",
      //               path: "/2/77/",
      //               level: 3,
      //               organizationId: null,
      //               organizationName: null,
      //               businessTag: null,
      //               businessValue: null,
      //               describe: null,
      //               udfFuncId: null,
      //               createBy: null,
      //               createId: null,
      //               createTime: "2023-04-28 13:24:01",
      //               updateBy: "未知用户",
      //               updateId: "0",
      //               updateTime: "2023-08-01 14:02:26",
      //               isDeleted: 0,
      //               children: [
      //                 {
      //                   id: 209,
      //                   tenancyId: "1286595526610915328",
      //                   key: "性别",
      //                   value: "Sex",
      //                   path: "/2/77/78/",
      //                   level: 4,
      //                   organizationId: null,
      //                   organizationName: null,
      //                   businessTag: null,
      //                   businessValue: null,
      //                   describe: null,
      //                   udfFuncId: null,
      //                   createBy: "未知用户",
      //                   createId: "0",
      //                   createTime: "2024-01-08 16:58:41",
      //                   updateBy: null,
      //                   updateId: null,
      //                   updateTime: "2024-02-27 11:04:31",
      //                   isDeleted: 0,
      //                   children: null,
      //                 },
      //                 {
      //                   id: 210,
      //                   tenancyId: "1286595526610915328",
      //                   key: "年龄",
      //                   value: "Age",
      //                   path: "/2/77/78/",
      //                   level: 4,
      //                   organizationId: null,
      //                   organizationName: null,
      //                   businessTag: null,
      //                   businessValue: null,
      //                   describe: null,
      //                   udfFuncId: null,
      //                   createBy: "未知用户",
      //                   createId: "0",
      //                   createTime: "2024-01-08 17:01:48",
      //                   updateBy: null,
      //                   updateId: null,
      //                   updateTime: "2024-01-08 17:01:58",
      //                   isDeleted: 0,
      //                   children: null,
      //                 },
      //                 {
      //                   id: 217,
      //                   tenancyId: "1286595526610915328",
      //                   key: "AAB",
      //                   value: "AAB",
      //                   path: "/2/77/78/",
      //                   level: 4,
      //                   organizationId: null,
      //                   organizationName: null,
      //                   businessTag: null,
      //                   businessValue: null,
      //                   describe: null,
      //                   udfFuncId: null,
      //                   createBy: "未知用户",
      //                   createId: "0",
      //                   createTime: "2024-01-08 17:35:48",
      //                   updateBy: null,
      //                   updateId: null,
      //                   updateTime: "2024-01-08 17:58:40",
      //                   isDeleted: 0,
      //                   children: null,
      //                 },
      //                 {
      //                   id: 227,
      //                   tenancyId: "1286595526610915328",
      //                   key: "dddfff",
      //                   value: "Ffffff",
      //                   path: "/2/77/78/",
      //                   level: 4,
      //                   organizationId: null,
      //                   organizationName: null,
      //                   businessTag: null,
      //                   businessValue: null,
      //                   describe: null,
      //                   udfFuncId: null,
      //                   createBy: "未知用户",
      //                   createId: "0",
      //                   createTime: "2024-01-08 18:24:33",
      //                   updateBy: null,
      //                   updateId: null,
      //                   updateTime: "2024-01-08 18:24:43",
      //                   isDeleted: 0,
      //                   children: null,
      //                 },
      //               ],
      //             },
      //           ],
      //         },
      //         {
      //           id: 105,
      //           tenancyId: "1286595526610915328",
      //           key: "检查费用",
      //           value: null,
      //           path: "/2/",
      //           level: 2,
      //           organizationId: null,
      //           organizationName: null,
      //           businessTag: null,
      //           businessValue: null,
      //           describe: null,
      //           udfFuncId: null,
      //           createBy: null,
      //           createId: null,
      //           createTime: "2023-05-06 16:24:23",
      //           updateBy: "未知用户",
      //           updateId: "0",
      //           updateTime: "2023-08-01 13:54:56",
      //           isDeleted: 0,
      //           children: [
      //             {
      //               id: 190,
      //               tenancyId: "1286595526610915328",
      //               key: "检查收费状态",
      //               value: "ER0005",
      //               path: "/2/105/",
      //               level: 3,
      //               organizationId: null,
      //               organizationName: null,
      //               businessTag: null,
      //               businessValue: null,
      //               describe: null,
      //               udfFuncId: null,
      //               createBy: "未知用户",
      //               createId: "0",
      //               createTime: "2023-08-01 13:55:07",
      //               updateBy: null,
      //               updateId: null,
      //               updateTime: "2023-08-01 13:55:07",
      //               isDeleted: 0,
      //               children: [],
      //             },
      //           ],
      //         },
      //         {
      //           id: 106,
      //           tenancyId: "1286595526610915328",
      //           key: "医技清洗规范",
      //           value: null,
      //           path: "/2/",
      //           level: 2,
      //           organizationId: null,
      //           organizationName: null,
      //           businessTag: null,
      //           businessValue: null,
      //           describe: null,
      //           udfFuncId: null,
      //           createBy: null,
      //           createId: null,
      //           createTime: "2023-05-23 10:00:17",
      //           updateBy: null,
      //           updateId: null,
      //           updateTime: "2023-05-23 10:00:17",
      //           isDeleted: 0,
      //           children: [
      //             {
      //               id: 107,
      //               tenancyId: "1286595526610915328",
      //               key: "RIS",
      //               value: "RIS",
      //               path: "/2/106/",
      //               level: 3,
      //               organizationId: null,
      //               organizationName: null,
      //               businessTag: null,
      //               businessValue: null,
      //               describe: null,
      //               udfFuncId: null,
      //               createBy: null,
      //               createId: null,
      //               createTime: "2023-05-23 10:00:44",
      //               updateBy: null,
      //               updateId: null,
      //               updateTime: "2023-05-23 10:00:44",
      //               isDeleted: 0,
      //               children: [
      //                 {
      //                   id: 108,
      //                   tenancyId: "1286595526610915328",
      //                   key: "工作状态",
      //                   value: "sdfs",
      //                   path: "/2/106/107/",
      //                   level: 4,
      //                   organizationId: null,
      //                   organizationName: null,
      //                   businessTag: null,
      //                   businessValue: null,
      //                   describe: null,
      //                   udfFuncId: null,
      //                   createBy: null,
      //                   createId: null,
      //                   createTime: "2023-05-23 10:01:13",
      //                   updateBy: null,
      //                   updateId: null,
      //                   updateTime: "2023-05-30 18:57:44",
      //                   isDeleted: 0,
      //                   children: null,
      //                 },
      //                 {
      //                   id: 151,
      //                   tenancyId: "1286595526610915328",
      //                   key: "设备信息值",
      //                   value: "equipmentValue",
      //                   path: "/2/106/107/",
      //                   level: 4,
      //                   organizationId: null,
      //                   organizationName: null,
      //                   businessTag: null,
      //                   businessValue: null,
      //                   describe: null,
      //                   udfFuncId: null,
      //                   createBy: "未知用户",
      //                   createId: "0",
      //                   createTime: "2023-07-25 15:19:51",
      //                   updateBy: "未知用户",
      //                   updateId: "0",
      //                   updateTime: "2023-07-25 15:51:39",
      //                   isDeleted: 0,
      //                   children: null,
      //                 },
      //               ],
      //             },
      //           ],
      //         },
      //         {
      //           id: 191,
      //           tenancyId: "1286595526610915328",
      //           key: "医技检查",
      //           value: null,
      //           path: "/2/",
      //           level: 2,
      //           organizationId: null,
      //           organizationName: null,
      //           businessTag: null,
      //           businessValue: null,
      //           describe: null,
      //           udfFuncId: null,
      //           createBy: "未知用户",
      //           createId: "0",
      //           createTime: "2023-08-01 13:56:01",
      //           updateBy: null,
      //           updateId: null,
      //           updateTime: "2023-08-01 13:56:01",
      //           isDeleted: 0,
      //           children: [
      //             {
      //               id: 192,
      //               tenancyId: "1286595526610915328",
      //               key: "检查预约",
      //               value: "jcyy",
      //               path: "/2/191/",
      //               level: 3,
      //               organizationId: null,
      //               organizationName: null,
      //               businessTag: null,
      //               businessValue: null,
      //               describe: null,
      //               udfFuncId: null,
      //               createBy: "未知用户",
      //               createId: "0",
      //               createTime: "2023-08-01 13:56:21",
      //               updateBy: "未知用户",
      //               updateId: "0",
      //               updateTime: "2023-08-01 13:56:53",
      //               isDeleted: 0,
      //               children: [],
      //             },
      //             {
      //               id: 194,
      //               tenancyId: "1286595526610915328",
      //               key: "检查登记",
      //               value: "jcdj",
      //               path: "/2/191/",
      //               level: 3,
      //               organizationId: null,
      //               organizationName: null,
      //               businessTag: null,
      //               businessValue: null,
      //               describe: null,
      //               udfFuncId: null,
      //               createBy: "未知用户",
      //               createId: "0",
      //               createTime: "2023-08-01 13:57:37",
      //               updateBy: null,
      //               updateId: null,
      //               updateTime: "2023-08-01 13:57:37",
      //               isDeleted: 0,
      //               children: [
      //                 {
      //                   id: 196,
      //                   tenancyId: "1286595526610915328",
      //                   key: "检查登记状态",
      //                   value: "ER0006",
      //                   path: "/2/191/194/",
      //                   level: 4,
      //                   organizationId: null,
      //                   organizationName: null,
      //                   businessTag: null,
      //                   businessValue: null,
      //                   describe: null,
      //                   udfFuncId: null,
      //                   createBy: "未知用户",
      //                   createId: "0",
      //                   createTime: "2023-08-01 13:58:09",
      //                   updateBy: null,
      //                   updateId: null,
      //                   updateTime: "2023-12-15 14:57:58",
      //                   isDeleted: 0,
      //                   children: null,
      //                 },
      //               ],
      //             },
      //             {
      //               id: 195,
      //               tenancyId: "1286595526610915328",
      //               key: "检查执行",
      //               value: "jczx",
      //               path: "/2/191/",
      //               level: 3,
      //               organizationId: null,
      //               organizationName: null,
      //               businessTag: null,
      //               businessValue: null,
      //               describe: null,
      //               udfFuncId: null,
      //               createBy: "未知用户",
      //               createId: "0",
      //               createTime: "2023-08-01 13:57:59",
      //               updateBy: null,
      //               updateId: null,
      //               updateTime: "2023-08-01 13:57:59",
      //               isDeleted: 0,
      //               children: [
      //                 {
      //                   id: 197,
      //                   tenancyId: "1286595526610915328",
      //                   key: "检查类型",
      //                   value: "ER0007",
      //                   path: "/2/191/195/",
      //                   level: 4,
      //                   organizationId: null,
      //                   organizationName: null,
      //                   businessTag: null,
      //                   businessValue: null,
      //                   describe: null,
      //                   udfFuncId: null,
      //                   createBy: "未知用户",
      //                   createId: "0",
      //                   createTime: "2023-08-01 13:58:21",
      //                   updateBy: null,
      //                   updateId: null,
      //                   updateTime: "2023-08-01 13:58:21",
      //                   isDeleted: 0,
      //                   children: null,
      //                 },
      //               ],
      //             },
      //             {
      //               id: 198,
      //               tenancyId: "1286595526610915328",
      //               key: "检查报告",
      //               value: "jcbg",
      //               path: "/2/191/",
      //               level: 3,
      //               organizationId: null,
      //               organizationName: null,
      //               businessTag: null,
      //               businessValue: null,
      //               describe: null,
      //               udfFuncId: null,
      //               createBy: "未知用户",
      //               createId: "0",
      //               createTime: "2023-08-01 13:58:29",
      //               updateBy: null,
      //               updateId: null,
      //               updateTime: "2023-08-01 13:58:29",
      //               isDeleted: 0,
      //               children: [
      //                 {
      //                   id: 199,
      //                   tenancyId: "1286595526610915328",
      //                   key: "检查报告状态",
      //                   value: "ER0020",
      //                   path: "/2/191/198/",
      //                   level: 4,
      //                   organizationId: null,
      //                   organizationName: null,
      //                   businessTag: null,
      //                   businessValue: null,
      //                   describe: null,
      //                   udfFuncId: null,
      //                   createBy: "未知用户",
      //                   createId: "0",
      //                   createTime: "2023-08-01 13:58:44",
      //                   updateBy: null,
      //                   updateId: null,
      //                   updateTime: "2023-08-01 13:58:44",
      //                   isDeleted: 0,
      //                   children: null,
      //                 },
      //               ],
      //             },
      //             {
      //               id: 200,
      //               tenancyId: "1286595526610915328",
      //               key: "会诊",
      //               value: "jchz",
      //               path: "/2/191/",
      //               level: 3,
      //               organizationId: null,
      //               organizationName: null,
      //               businessTag: null,
      //               businessValue: null,
      //               describe: null,
      //               udfFuncId: null,
      //               createBy: "未知用户",
      //               createId: "0",
      //               createTime: "2023-08-01 13:59:17",
      //               updateBy: null,
      //               updateId: null,
      //               updateTime: "2023-08-01 13:59:17",
      //               isDeleted: 0,
      //               children: [
      //                 {
      //                   id: 201,
      //                   tenancyId: "1286595526610915328",
      //                   key: "会诊类型",
      //                   value: "ER0017",
      //                   path: "/2/191/200/",
      //                   level: 4,
      //                   organizationId: null,
      //                   organizationName: null,
      //                   businessTag: null,
      //                   businessValue: null,
      //                   describe: null,
      //                   udfFuncId: null,
      //                   createBy: "未知用户",
      //                   createId: "0",
      //                   createTime: "2023-08-01 13:59:27",
      //                   updateBy: null,
      //                   updateId: null,
      //                   updateTime: "2023-08-01 13:59:27",
      //                   isDeleted: 0,
      //                   children: null,
      //                 },
      //               ],
      //             },
      //           ],
      //         },
      //       ],
      //     },
      //   ],
      //   page: null,
      // };
      getStandardTree().then(res => {
      if (res.code === 0) {
        this.treeData = res.data;
        this.treeData = this.treeData.sort((a, b) => a.sort - b.sort)
        for (const i of this.treeData) {
          i.label = i.key;
          i.children = i.children.sort((a, b) => a.sort - b.sort)
          for (const j of i.children || []) {
            j.label = j.key;
            j.children = j.children.sort((a, b) => a.sort - b.sort)
            for (const k of j.children || []) {
              k.label = k.key;
              k.children = k.children.sort((a, b) => a.sort - b.sort)
              if (
                !this.selectData.id &&
                k.children &&
                k.children.length
              ) {
                this.selectData = k.children[0];
                // this.$nextTick(() => {
                //   this.handleCheck(k.children[0].id)
                // })
              }
              for (const l of k.children || []) {
                l.label = l.key;
              }
            }
          }
        }
        // 主要赋值给 treeMenu组件里面的新增产品 新建文件夹用的
        // this.$refs.treeMenu.myTreeData = JSON.parse(JSON.stringify(this.treeData))
        if (this.selectData.id) {
          this.$nextTick(() => {
            this.handleCheck(this.selectData.id);
          });
        } else {
          if (this.treeData.length) {
            this.$nextTick(() => {
              this.handleCheck(this.treeData[0].id);
            });
          }
        }
      }
      })
    },
    // 树形绑定方法结束
    changeCurrentProd(prod) {
      this.currentProd = prod;
      this.reset();
    },
    // 获取微服务列表
    async getProductServicePageList() {
      const params = {
        productId: this.currentProd.id,
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
      };
      this.keyWord && (params.keyWords = this.keyWord);
      const res = await getProductServicePageList(params);
      if (res.code !== 0) {
        this.$message.error(res.message);
        return;
      }
      this.governmentProductList = res.data || [];
      this.total = res.totalElements || 0;
    },
    query() {
      this.pageIndex = 1;
      this.pageSize = 20;
      this.getProductServicePageList();
    },
    reset() {
      this.keyWord = "";
      this.query();
    },
    changeSearchKey(obj) {
      this[obj.key] = obj.value;
      this.getProductServicePageList();
    },
  },
};
</script>

<style scoped lang="scss">
.crumbsCon {
  display: flex;
  width: 100%;
  height: 46px;
  border-top: 1px solid #e4e7ed;
  border-bottom: 1px solid #e4e7ed;
  .m-tab {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .m-tab-item {
    width: 90px;
    color: #303133;
    font-size: 15px;
    text-align: center;
    cursor: pointer;
    font-weight: 700;
    margin-right: 10px;
  }
  .m-tab-item-active {
    color: #0a70b0;
    font-weight: 700;
  }
  .tab-line {
    height: 2px;
    width: 90px;
    background: #0a70b0;
    position: absolute;
    bottom: 0;
    left: 0;
    transition: all 0.3s ease;
  }
}
.productContainer {
  display: flex;
  .productContainerLeft {
    width: 245px;
    // border-right: 5px solid #e1e7f3;
    position: relative;
    .productSearch {
      display: flex;
      border-bottom: 1px solid #dcdfe6;
      padding: 8px 10px;
      .productSearchInput {
        margin-right: 8px;
        flex: 1;
      }
      .addProductBtn {
        width: 32px;
        height: 32px;
        background: #ffffff;
        border: 1px solid #dcdfe6;
        border-radius: 3px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        i {
          font-size: 16px;
          color: #0a70b0;
        }
      }
    }
  }
  .productContainerRight {
    padding: 8px 15px;
    padding-bottom: 8px;
    width: calc(100% - 245px);
    .systemProductBox{
      height: 100%;
      overflow: auto;
    }
    .moreSystem {
      height: 100%;
      .curProductInfor {
        padding: 10px 12px;
        border-radius: 3px;
        background: #fff4ea;
      }
      .curProductNameCon {
        display: flex;
        justify-content: space-between;
        margin-bottom: 4px;
        .curProductName {
          font-weight: 600;
          font-size: 17px;
          color: #000000;
          line-height: 24px;
        }
        .updateProductIcon {
          font-size: 14px;
          color: #0a70b0;
          cursor: pointer;
          i {
            margin-right: 5px;
          }
        }
      }
      .productDesc {
        font-size: 14px;
        color: #303133;
        line-height: 24px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      .productTitHead {
        display: flex;
        height: 40px;
        justify-content: space-between;
        align-items: center;
        .productTitHeadLeft {
          display: flex;
          img {
            margin-right: 5px;
          }
          .productTitText {
            font-weight: 600;
            font-size: 15px;
            color: #303133;
          }
          .productTitHeadTip {
            font-size: 14px;
            color: #909399;
          }
        }
        .addProductCon {
          cursor: pointer;
          i {
            font-size: 16px;
            color: #0a70b0;
            margin-right: 5px;
          }
          .addProductConText {
            font-size: 14px;
            color: #0a70b0;
          }
        }
      }
      .governmentProduct {
        height: calc(50% - 98px);
        ::v-deep .governmentProductTable {
          height: 100%;
          .el-table__body-wrapper {
            height: calc(100% - 40px);
            overflow: auto;
          }
          // .current-row{
          //       position: relative;
          //       td{
          //           position: relative;
          //         background:#e3f4ff!important;
          //         color: #606266;
          //       }
          //   }
          //  .current-row td:nth-of-type(1)::before{
          //       content: "";
          //       display: block;
          //       height: 41px;
          //       width: 3px;
          //       position: absolute;
          //       top:0px;
          //       left:0px;
          //       background: #0a70b0;
          //   }
        }
      }
      .governmentService {
        height: calc(50% - 98px);
        ::v-deep .governmentServiceTable {
          height: 100%;
          .el-table__body-wrapper {
            height: calc(100% - 40px);
            overflow: auto;
          }
        }
        .serviceOperate {
          display: flex;
          font-size: 14px;
          .updateServe {
            color: #0a70b0;
          }
          .deleteServe {
            color: #da4a4a;
            margin-left: 10px;
          }
        }
      }
    }
  }
}
.bd1-prod {
  border-left: 1px solid #dcdfe6;
  border-right: 1px solid #dcdfe6;
  border-bottom: 1px solid #dcdfe6;
}
.prod-css1 {
  border-radius: 3px;
  &:hover {
    color: #0a70b0;
    background-color: #ebf3ff;
  }
  &.active {
    color: #0a70b0;
    background-color: #e1eaff;
    padding-left: 8px;
    border-left: 4px solid #0a70b0;
  }
}
.rr {
  width: calc(100% - 300px);
}
/deep/ .el-input--suffix .el-input__inner {
  padding-right: 25px;
}
/deep/ .el-input--small .el-input__icon {
  font-size: 16px;
}
/deep/ .el-dialog__body {
  padding-left: 10px;
}
.css1 /deep/ .el-textarea__inner {
  height: 100px;
}
.inventoryContainer {
  height: 100%;
}
.clircle {
  position: relative;
  top: -2px;
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  &.running::after {
    position: absolute;
    top: -1px;
    left: -1px;
    width: 100%;
    height: 100%;
    border-width: 1px;
    border-style: solid;
    border-radius: 50%;
    content: '';
    border-color: #1890ff;
    animation: animate 1.2s ease-in-out infinite;
  }
  &.stoped::after{
    border-color: #da4a4a;
  }
}
@keyframes animate {
  0% {
    transform: scale(0.8);
    opacity: 0.5;
  }
  to {
    transform: scale(2);
    opacity: 0;
  }
}
.resize {
  cursor: col-resize;
  float: left;
  position: absolute;
  background-size: cover;
  background-position: center;
  z-index: 1;
  top: 0;
  right: -2px;
  background-color: #dcdfe6;
  width: 4px;
  height: 100%;
}
.resize:hover {
  color: #444444;
  background-color: #c0c4cc;
}
</style>
