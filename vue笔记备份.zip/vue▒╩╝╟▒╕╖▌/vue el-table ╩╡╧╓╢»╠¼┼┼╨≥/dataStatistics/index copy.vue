<template>
  <!--【万达】客户管理，增加远程诊断统计功能，可根据诊断中心进行筛选统-->
  <div class="inspectPage flex_row flex_column">
    <div class="title-bar flex_row ">
      <div class="crumbsCon">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>数据统计
          <i class="iconfont iconzhankaishouqi"></i>服务开展统计
        </span>

        <div class="m-tab">
          <div class="m-tab-item" :class="tabIndex === index ? 'm-tab-item-active' : ''" v-for="(item, index) in tabList" :key="index" @click="toggleTab(index,item.value)">{{item.label}}</div>
          <div class="tab-line" :style="{left: number + 'px'}"></div>
        </div>

      </div>
      <div class="tr col">
        <span @click="importTableData" class="function-btn bg_0a clr_ff mr15">
          <i class="iconfont icondaochu pr5"></i>导出
        </span>
        <!-- <span @click="printData" class="function-btn bg_e6 clr_ff">
          <i class="iconfont icondayin pr5"></i>打印
        </span> -->
      </div>
    </div>
    <div class="inspectCon  col">
      <div class="med-query">
        <div class="search-bar">
          <div class="searchTop mb10 clear">
            <div class="fl mr20">
              <span class="search-bar-label fl">开展时间 :</span>
              <SearchTime
                @getTimes="getTime"
                class="fl"
                width="240px"
                :clearTime="clearTime"
                :initTime="initTime"
              />
            </div>
            <div class="fl mr20">
              <span class="search-bar-label fl">服务机构:</span>
              <el-select
                multiple
                filterable
                collapse-tags
                :clearable="true"
                v-model="searchData.service_institution_ids"
                class="ele-select_32 width_240_select"
                placeholder="全部"
                style="width:240px"
                @change="changeServiceInstitute"
              >
                <el-option
                  v-for="(item, index) in institutionArr"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
            </div>
            <div class="applyInstituteForm fl mr20" v-if="tabType == 2">
              <span class="search-bar-label fl">申请机构:</span>
              <el-select
                multiple
                filterable
                collapse-tags
                :clearable="true"
                v-model="searchData.request_institution_ids"
                class="ele-select_32 width_240_select"
                placeholder="全部"
                style="width:240px"
                @change="search"
              >
                <el-option
                  v-for="(item, index) in applyInstitutionArr"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
            </div>
             <div class="fl operateBtnDiv" :class="{'activeBtnCon':tabType ==2}">
              <el-button type="primary" size="small" @click="search"
                >查询</el-button
              >
              <el-button size="small" plain @click="resetSearch"
                >重置</el-button
              >
            </div>
          </div>
        </div>
      </div>
      <div
        id="workTable"
        v-show="tabType === 1"
        class="tableBox"
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-background="rgba(255,255,255,0.6)"
        :class="{noTableData: workTableData.length === 0}">
        <el-table
          :data="workTableData"
          border
          @sort-change="sortChange"
          :span-method="arraySpanMethod"
          stripe
          width="100%"
          height="100%"
          ref="workTable"
          row-key="id"
          :expand-row-keys="tableOneRowKeys"
          :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
          :cell-class-name="handleCellClassName"
          :default-sort="{prop: 'region', order: 'descending'}"
        >
          <template>
            <el-table-column v-if="workTableData.length != 0"  type="index" label="序号" width="60" fixed="left">
            </el-table-column>
            <el-table-column
              v-for="(item, index) in workTableHead"
              :key="index"
              align="center"
              :prop="item.field"
              :min-width="index==0 ? 120 : index === 1 ? 200 : ''"
              :label="item.title"
              :fixed="index === 0 ? true : false"
              :sortable="(index == 0 || index == 1) ? 'custom' : false"
            >
               

              <el-table-column
                v-for="(sub, subIndex) in item.sub_columns"
                :key="subIndex"
                :label="sub.title"
                :prop="sub.field"
                align="center"
                sortable="custom"
              >
                <template slot-scope="scope">
                  <span v-if="sub.field.indexOf('implementation') != -1 " :class="{'clr_red': scope.row[sub.field]=='否'}">{{scope.row[sub.field]}}</span>
                  <span v-else>{{scope.row[sub.field]}}</span>
                </template>
              </el-table-column>
            </el-table-column>
          </template>
        </el-table>
      </div>
      <div
        id="applyTable"
        v-show="tabType === 2"
        class="tableBox"
        :class="{noTableData: applyTableData.length === 0}"
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-background="rgba(255,255,255,0.6)">
        <el-table
          :data="applyTableData"
          @sort-change="sortChange"
          :span-method="arraySpanMethod"
          border
          stripe
          width="100%"
          height="100%"
          ref="applyTable"
          row-key="id"
          :expand-row-keys="tableTwoRowKeys"
          :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
          :cell-class-name="handleCellClassName"
          :default-sort="{prop: 'region', order: 'descending'}"
        >
          <template>
            <el-table-column v-if="applyTableData.length != 0"  type="index" label="序号" width="60" fixed="left">
            </el-table-column>
            <el-table-column
              v-for="(item, index) in applyTableHead"
              :key="index"
              align="center"
              :prop="item.field"
              :min-width="index==0 ? 120 : index === 1 ? 200 : index === 2 ? 200 :''"
              :label="item.title"
              :fixed="index === 0 ? true : false"
              :sortable="(index == 0 || index == 2) ? 'custom' : false"
            >
              <el-table-column
                v-for="(sub, subIndex) in item.sub_columns"
                :key="subIndex"
                :label="sub.title"
                :prop="sub.field"
                align="center"
                sortable="custom"
              >
                <template slot-scope="scope">
                  <span v-if="sub.field.indexOf('implementation') != -1 " :class="{'clr_red': scope.row[sub.field]=='否'}">{{scope.row[sub.field]}}</span>
                  <span v-else>{{scope.row[sub.field]}}</span>
                </template>
              </el-table-column>
            </el-table-column>
          </template>
        </el-table>
      </div>
    </div>
  </div>
</template>
<script>
import Mgr from '@/utils/SecurityService'
import SearchTime from './components/newSearchTime' // 搜索时间
import html2canvas from 'html2canvas'
import moment from 'moment'
import { getServiceInstituteQuantity, getApplyInstituteQuantity } from '@/api/seviceCenterManage/dataStatic'
import {
  getServiceInstitutions,
  getApplyInstitutions,
} from '@/api/platform_costomer/telemedicine'
import mixin from '@/utils/mixin/dataStatic'
import { PrintHelper } from '@/utils/printHelper'
import utils from '@/utils' // 分页
export default {
  components: {
    SearchTime
  },
  mixins: [mixin],
  data () {
    return {
      userName: '',
      tabIndex: 0,
      number: 0,
      tabType: 1,
      firstRequestWorkTable: false,
      firstRequestApplyTable: false,
      tabList: [
        {
          label: '服务机构开展情况',
          value: 1,
        },
        {
          label: '申请机构开展情况',
          value: 2,
        }
      ],
      token: '',
      initTime: [],
      clearTime: false,
      statisticsType: 1,
      cellClassNameSet: '诊断申请量',
      applyTableData: [],
      applyTableHead: [],
      workTableData: [],
      workTableHead: [],
      tableOneRowKeys: [],
      tableTwoRowKeys: [],
      loading: false,
      searchData: {
        implementation_start_time: '',
        implementation_end_time: '',
        service_institution_ids: [],
        request_institution_ids: [],
        sorts: ['region|desc','service_institution|desc']
      },
      sortsObj: {
        region: 'region|desc',
        service_institution: 'service_institution|desc',
      },
      institutionArr: [],
      applyInstitutionArr: [],
      institutePropData: [],
    }
  },
  methods: {
    // 给第一行 弟1列 定义一个新的class类名
    handleCellClassName ({ row, column, rowIndex, columnIndex }) {
     if (rowIndex  === 0) {
        if (columnIndex === 1) {
          return 'mergeCell'
        }
     }
    },
    // 合并列
    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      if (this.tabType == 1) {
       if (rowIndex  === 0) {
        if (columnIndex === 1) {
          column.region = '总计'
          return [1, 2];
        } else if (columnIndex === 2){
          return [0, 0];
        }
       }
     }
      if (this.tabType == 2) {
        if (rowIndex  === 0) { // 对第一行进行特殊合并
         if (columnIndex === 1) {
          column.region = '总计'
          return [1, 3]; // 第一行 第一列开始向右合并3列(第二列 和第三列)  下面设置第二列和第三列不显示
         } else if (columnIndex === 2){ 
          return [0, 0]; // 第二列不显示
         } else if (columnIndex === 3){
          return [0, 0];// 第三列不显示
        }
       } else { // 其它行的   有合计的 第二列和第三列进行合并
          // console.log(row)
          if (row.request_institution== "合计") {
            if (columnIndex === 2) {
              return [1, 2];
            }else if (columnIndex === 3){
              return [0, 0];
            }
          }
         
       }
      }
    },
    // 服务机构或申请机构开展排序
    sortChange (sort) {
      // console.log(sort)
      this.searchData.sorts = []
      // 跟产品确认 区域、服务机构、公共(所有的开展和数量)
      if (sort.order === 'descending') {
        if (sort.prop  == 'region' || sort.prop == 'service_institution') {
          this.sortsObj[sort.prop] =  sort.prop + '|' + 'desc'
        } else {
          this.sortsObj.commonKey =  sort.prop + '|' + 'desc'
        }
        
      } else {
        if (sort.order) {
          if (sort.prop  == 'region' || sort.prop == 'service_institution') {
            this.sortsObj[sort.prop] = sort.prop + '|' + 'asc'
          } else {
            this.sortsObj.commonKey =  sort.prop + '|' + 'asc'
          }
        } else { // 取消了排序
          this.sortsObj[sort.prop] = null
          if (sort.prop  != 'region' && sort.prop != 'service_institution') {
            this.sortsObj.commonKey = null
          }
        }
        
      }
      for (let key in this.sortsObj) {
        if (this.sortsObj[key]) {
          this.searchData.sorts.push(this.sortsObj[key])
        }
      }
      //this.searchData.sorts = [sort.prop + '|' + 'desc']
      if (this.tabType == 1) {
        this.getServiceInstituteQuantity()
      } else {
        this.getApplyInstituteQuantity()
      }
      
    },
    toggleTab(index, value) {
      this.tabType = value
      if (this.tabIndex < index) {
        this.number = index * 150  //60既是一个tab的宽度 也是tab下滑动横线的宽度
      } else {
        this.number = this.number - ((this.tabIndex-index) * 150)
      }
      if (this.tabIndex != index) {
        if (this.tabType == 1) {
          this.sortsObj = {
            region: 'region|desc',
            service_institution: 'service_institution|desc',
          }
          this.searchData.sorts = ['region|desc','service_institution|desc']
          this.firstRequestWorkTable = false
        } else {
          this.sortsObj = {
            region: 'region|desc',
            request_institution: 'request_institution|desc',
          }
          this.searchData.sorts = ['region|desc','request_institution|desc']
          this.firstRequestApplyTable = false
        }
        this.search()
      }
      this.tabIndex = index
    },
    // 改变服务机构
    changeServiceInstitute () {
      if (this.tabType == 2) {
        this.searchData.request_institution_ids = []
        // 获取该服务（所属）机构 对应的服务中心下的 申请(签约)机构
        this.getApplyInstitutionData()
      }
      this.search()
    },
    // 获取查询时间
    getTime (time) {
      //console.log('time',time)
      if (time) {
        this.searchData.implementation_start_time = time[0]
        this.searchData.implementation_end_time = time[1]
        this.search()
      } else {
        this.$message.warning('查询近一个月数据')
        this.initTime = [moment().subtract(1, "month").format("YYYY-MM-DD"),moment().format('YYYY-MM-DD')]
      }
    },
    formatJson (filterVal, jsonData) {
      return jsonData.map(v =>
        filterVal.map(j => {
          return v[j]
        })
      )
    },
    async onExport(dom, tableName, config = {}) {
      //this.isExporting = true

      await utils.excel.exportExcelWithHeader(dom, tableName, config)

      //this.isExporting = false
    },
    importTableData () {
      // let begin_date = ''
      // let end_date = ''
      // if (Array.isArray(this.applyTime) && this.applyTime.length > 0) {
      //   begin_date = this.applyTime[0]
      //   end_date = this.applyTime[1]
      // }
      const exportTime = `开展时间：${this.searchData.implementation_start_time}~${this.searchData.implementation_end_time}`
      const userName = `制表人：${this.userName}`

      if (this.tabType == 1) {
        // 服务机构开展情况
        this.onExport(this.$refs.workTable.$el, '服务机构开展情况', {
          title: '服务机构开展情况',
          exportTime,
          userName,
          needTitle: true
      })
      } else if (this.tabType == 2) {
        // 申请机构开展情况
        this.onExport(this.$refs.applyTable.$el, '申请机构开展情况', {
          title: '申请机构开展情况',
          exportTime,
          userName,
          needTitle: true
        })
      }
    },
    // 获取服务机构
    async getInstitutionData () {
      const res = await getServiceInstitutions()
      if (res.code === 0) {
        this.institutionArr = res.data
      } else {
        this.$message.error(res.msg)
      }
    },
    // 获取申请机构
    async getApplyInstitutionData () {
      const res = await getApplyInstitutions({service_institution_ids:this.searchData.service_institution_ids})
      if (res.code === 0) {
        this.applyInstitutionArr = res.data
      } else {
        this.$message.error(res.msg)
      }
    },
    // 全部关闭
    closeAll () {
      if (this.tabType == 1) {
        this.tableOneRowKeys = []
      } else if (this.tabType == 2) {
        this.tableTwoRowKeys = []
      }
    },
    // 全部打开
    openAll() {
      if (this.tabType == 1) {
        this.tableOneRowKeys = this.workTableData.map(item => {
          return item.id
        })
      } else if (this.tabType == 2) {
        this.tableTwoRowKeys = this.applyTableData.map(item => {
          return item.id
        })
      }
    },
    // 打印
    printData() {
      let id = ''
      let title = ''
      if (this.tabType === 1) {
        id = '#workTable'
        title = '服务机构开展情况'
        this.openAll()
      } else if (this.tabType === 2) {
        id = '#applyTable'
        title = '申请机构开展情况'
        this.openAll()
      }
      this.$nextTick(() => {
        const table = document.querySelector(id)
        const date = `${this.searchData.implementation_start_time}~${this.searchData.implementation_end_time}`
        const username = this.userName
        new PrintHelper().table(table).prepend({
          title,
          date,
          username
        }).print()
      })
    },
    // 打印
    // printData () {
    //   let id = ''
    //   if (this.statisticsType === 1) {
    //     id = '#applyTable'
    //     this.openAll()
    //   } else if (this.statisticsType === 2) {
    //     this.openAll()
    //     if (this.searchData.show_combined_columns) {
    //       id = '#workTable'
    //     } else {
    //       id = '#workTable2'
    //     }
    //   } else if (this.statisticsType === 3){
    //     id = "#centerTable"
    //   }
    //   this.$nextTick(() => {
    //     html2canvas(document.querySelector(id)).then(canvas => {
    //       var url = canvas.toDataURL()
    //       print({
    //         printable: url,
    //         type: 'image',
    //         documentTitle: this.cellClassNameSet
    //       })
    //     })
    //   })
    // },
    // 查询
    search () {
      this.loading = true
      if (this.tabType === 1) {
        this.getServiceInstituteQuantity()
      } else if (this.tabType === 2) {
        this.getApplyInstituteQuantity()
      }
    },
    // 重置
    resetSearch () {
      
      this.searchData = {
        implementation_start_time: '',
        implementation_end_time: '',
        service_institution_ids: [],
        request_institution_ids: [],
        sorts: ['region|desc','service_institution|desc']
      }
      // 近一个月
      // this.initTime = [moment().subtract(1, "month").format("YYYY-MM-DD"),moment().format('YYYY-MM-DD')]
      // this.searchData.implementation_start_time = moment().subtract(1, "month").format("YYYY-MM-DD")
      // this.searchData.implementation_end_time = moment().format('YYYY-MM-DD')
      // 上个月
      this.initTime = [moment(new Date()).subtract(1,'months').startOf('month').format('YYYY-MM-DD'),moment(new Date()).subtract(1,'months').endOf('month').format('YYYY-MM-DD')]
      this.searchData.implementation_start_time = this.initTime[0]
      this.searchData.implementation_end_time = this.initTime[1]

      if (this.tabType == 1) {
        this.firstRequestWorkTable = false
        this.sortsObj = {
          region: 'region|desc',
          service_institution: 'service_institution|desc',
        }
        this.searchData.sorts = ['region|desc','service_institution|desc']
        this.getServiceInstituteQuantity()
      } else {
        this.firstRequestApplyTable = false
        this.sortsObj = {
          region: 'region|desc',
          request_institution: 'request_institution|desc',
        }
        this.searchData.sorts = ['region|desc','request_institution|desc']
        this.getApplyInstituteQuantity()
      }
    },
    // 获取服务机构开展量
    getServiceInstituteQuantity () {
      const self = this
      self.searchData.request_org_ids = self.searchData.request_institution_ids
      self.institutePropData = []
      getServiceInstituteQuantity(self.searchData).then(res => {
        self.loading = false
        if (res.code !== 0) {
          self.$message.error(res.msg)
          return
        }
        self.workTableHead = res.data.columns
        res.data.statics.forEach((item, index) => {
          item.id = index + ''
          if (item.children && item.children.length > 0) {
            item.children.forEach((c, cindex) => {
              c.id = item.id + '-' + cindex
              c.doctor_name = ''
            })
          }
        })
        self.workTableData = res.data.statics
        
        self.$nextTick(() => {
          self.$refs.workTable.doLayout()
          if (!self.firstRequestWorkTable) {// 用来判断第一次默认加载时 
            self.$refs.workTable.sort('region', 'descending')// 点亮那个排序
          }
          self.firstRequestWorkTable = true
        })
      })
    },
    // 获取申请机构开展量
    getApplyInstituteQuantity () {
      const self = this
      getApplyInstituteQuantity(self.searchData).then(res => {
        self.loading = false
        if (res.code !== 0) {
          self.$message.error(res.msg)
          return
        }
        res.data.statics.forEach((item, index) => {
          item.id = index + ''
          if (item.children && item.children.length > 0) {
            item.children.forEach((c, cindex) => {
              c.id = item.id + '-' + cindex
            })
          }
        })
        self.applyTableHead = res.data.columns
        self.applyTableData = res.data.statics
        self.$nextTick(() => {
          self.$refs.applyTable.doLayout()
          if (!self.firstRequestApplyTable) { // 用来判断第一次默认加载时 
            self.$refs.applyTable.sort('region', 'descending') // 点亮那个排序
          }
          self.firstRequestApplyTable = true // 不是第一次了
        })
      }).catch(() => {
        console.log("出错了啦")
        self.loading = false
      })
    },
  },
  mounted () {
    const self = this
    // 获取服务机构
    self.getInstitutionData()
    // 默认获取所有的申请机构
    self.getApplyInstitutionData()
    // 初始化查询时间
    // 近1个月
    // self.initTime = [moment().subtract(1, "month").format("YYYY-MM-DD"),moment().format('YYYY-MM-DD')]
    // self.searchData.implementation_start_time = moment().subtract(1, "month").format("YYYY-MM-DD")
    // self.searchData.implementation_end_time = moment().format('YYYY-MM-DD')
    // 上个月
    self.initTime = [moment(new Date()).subtract(1,'months').startOf('month').format('YYYY-MM-DD'),moment(new Date()).subtract(1,'months').endOf('month').format('YYYY-MM-DD')]
    self.searchData.implementation_start_time = self.initTime[0]
    self.searchData.implementation_end_time = self.initTime[1]
    var manager = new Mgr()
    manager.getRole().then(logindata => {
      self.token = logindata.token_type + ' ' + logindata.access_token
      self.userName = logindata.profile.name
    })
  }
}
</script>
<style lang="less" scoped>
.m-tab { position: relative;display: flex; align-items: center; justify-content: space-between;}
.m-tab-item { width: 150px; color: #303133; font-size: 15px; text-align: center;cursor: pointer;font-weight: 700;}
.m-tab-item-active {color: #0a70b0;font-weight: 700;}
.tab-line {height: 2px; width: 150px; background: #0a70b0; position: absolute; bottom: 0; left: 0; transition: all 0.3s ease;}
.crumbsCon{
  display: flex;
}
::v-deep .el-select__tags-text{
  float: left;
  max-width: 117px;
  text-overflow: ellipsis;
  overflow: hidden;
}
::v-deep .el-select__input{
  margin-left: 5px;
}
.inspectPage {
  height: 100%;
}
.inspectCon {
  padding: 10px 15px;
  .tableBox{
    height: calc(100vh - 160px);
  }
}
::v-deep .mergeCell {
  .cell{
    visibility: visible!important;;
  }
}
@media screen and (max-width: 1372px) {
  .applyInstituteForm{
    clear:both;
    margin-top:5px;
  }
  .activeBtnCon{
    margin-top:5px!important;
  }
  #applyTable{
    height: calc(100vh - 197px);
  }
}
</style>
