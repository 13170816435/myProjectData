import axios from 'axios'
import qs from 'qs'

const mixin = {
  // mixins: [commonMixin],
  data() {
    return {
      token: ''
    }
  },
  methods: {
    // 数组更换键名
    changeArrName(arr) {
      const self = this
      if (arr.length !== 0) {
        arr.forEach((val) => {
          if (val.sub_columns.length !== 0) {
            var myArr = val.sub_columns
            delete val.sub_columns
            var prop = val.field
            var label = val.title
            // 删掉field title属性  换成 prop 和 label
            delete val.field
            delete val.title
            if (prop) {
              val.prop = prop
            }
            if (label) {
              val.label = label
            }
            // 将键名sub_columns 删掉 换成 children 键名
            val.children = myArr
            // 执行递归
            self.changeArrName(myArr)
          } else {
            var newprop = val.field
            var newlabel = val.title
            // 删掉field title属性  换成 prop 和 label
            delete val.field
            delete val.title
            if (newprop) {
              val.prop = newprop
            }
            if (newlabel) {
              val.label = newlabel
            }
            delete val.sub_columns
          }
        })
      }
      return arr
    },
    // // 导出excel方法
    // url 导出接口地址  param 导出接口要传的参数 token 授权token  systemId(科室id 或服务中心id ) excelTit 为 excel文件的名字
    importExcel(url, param, token, SystemId, excelTit) {
      const self = this
      axios.get(url, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded', // 请求的数据类型为form data格式
          'Authorization': token,
          'SystemId': SystemId
        },
        'responseType': 'blob',
        params: param,
        paramsSerializer: params => {
          return qs.stringify(params, {
            indices: false
          })
        }
      }).then(function (response) {
        const result = response.data
        if (response.status === 200) {
          const url = window.URL.createObjectURL(new Blob([response.data], {type: 'application/vnd.ms-excel'}))
          const link = document.createElement('a')
          link.style.display = 'none'
          link.href = url
          link.setAttribute('download', excelTit + '.xls')
          document.body.appendChild(link)
          link.click()
        } else {
          self.$message.error(result.msg)
        }
      })
    }
  },
  mounted() {
  },
  filters: {
    // 获取含数字的字符串里面数字
    getStringNum(str) {
      if (str) {
        var num = str.replace(/[^0-9]/ig, '')
        return num
      }
    },
    dealTotal(arr) {

    }
  }
}
export default mixin
