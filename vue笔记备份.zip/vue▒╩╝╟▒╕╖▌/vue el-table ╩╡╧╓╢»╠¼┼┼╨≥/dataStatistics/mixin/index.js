import * as excel from './excel'

const getFrontEndUrl = () => {
  return process.env.NODE_ENV === 'development'? 'https://dev-portal.mtywcloud.com': configUrl.frontEndUrl
}

export default {
  excel,
  getFrontEndUrl
}
