<template>
  <!--【万达】客户管理，增加远程诊断统计功能，可根据诊断中心进行筛选统-->
  <div class="inspectPage flex_row flex_column">
    <div>
      <head-nav
        :firstTitle="'数据管理'"
        :subTitle="'统计报表'"
        :hiddenChangeNode="true"
      ></head-nav>
    </div>
    <div class="inspectCon  col">
      <div class="med-query">
        <div class="search-bar">
          <div class="searchTop mb10 clear">
            <span class="search-bar-label fl">检查时间：</span>
            <SearchTime
            @getTimes="getTime"
            class="mr10"
            style="width: 230px"
            :clearTime="clearTime"
            :initTime="initTime"
            />
            <span class="search-bar-label">系统名称：</span>
            <el-select
                filterable
                :clearable="true"
                v-model="system_id"
                class="w180 mr10"
                size="small"
                placeholder="全部"
                @change="changeSystem"
              >
                <el-option
                  v-for="(item, index) in node_system_list"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
            <span class="search-bar-label">机构名称：</span>
              <el-select
                multiple
                filterable
                collapse-tags
                :clearable="true"
                v-model="searchData.institution_ids"
                class="w180 mr10"
                size="small"
                placeholder="全部"
                @change="getImageDataStatistics"
              >
                <el-option
                  v-for="(item, index) in institutionArr"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                ></el-option>
              </el-select>
             <el-button type="primary" size="small" @click="search"
                >统计</el-button
              >
              <el-button size="small" plain @click="resetSearch"
                >重置</el-button
              >
              <span @click="importTableData" class="importBtn ml10">
                导出
              </span>
          </div>

          <div class="searchBottom">
            <div class="radioChoose">
              <el-radio-group v-model="searchData.dimension" @change="getImageDataStatistics">
                <el-radio :label="0">按系统/机构</el-radio>
                <el-radio :label="1">按检查类型</el-radio>
              </el-radio-group>
            </div>
            <div class="reportTit">
               <span class="inspectTime">{{searchData.study_date_time_start}}~{{searchData.study_date_time_end}}</span>
               <span>影像数据统计</span>
            </div>
          </div>
        </div>
      </div>
      <div
        id="workTable"
        v-show="tabType === 1"
        class="tableBox"
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-background="rgba(255,255,255,0.6)"
        :class="{noTableData: workTableData.length === 0}">
        <el-table
          :data="workTableData"
          style="width: 100%;margin-bottom: 20px;"
          row-key="id"
          ref="workTable"
          height="100%"
          border
          default-expand-all
          @sort-change="sortChange"
          :default-sort="{prop: 'file_size', order: 'descending'}"
          :tree-props="{children: 'detail_list', hasChildren: 'hasChildren'}">
          <el-table-column
            prop="name"
            label="统计维度"
            width="220">
          </el-table-column>
          <el-table-column
            prop="study_count"
            label="检查量"
            sortable="custom"
            width="180">
          </el-table-column>
          <el-table-column
            prop="file_size"
            sortable="custom"
            label="容量">
             <template slot-scope="scope">
                <span >{{scope.row.file_size_description}}</span>
              </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>
<script>
import HeadNav from '@/components/common/HeadNav' // 头部导航
import Mgr from '@/utils/SecurityService'
import SearchTime from '@/components/common/SearchTime' // 搜索时间
import moment from 'moment'
import mixin from './mixin/dataStatic'
// import { PrintHelper } from '@/utils/printHelper'
import utils from './mixin/index' // 分页
import { mapGetters } from 'vuex'
import { getInstitutionListLite } from '@/operate/api/commonHttp'
export default {
  components: {
    HeadNav,
    SearchTime
  },
  mixins: [mixin],
  data () {
    return {
      radio: '',
      userName: '',
      tabType: 1,
      token: '',
      initTime: [],
      clearTime: false,
      workTableData: [],
      tableOneRowKeys: [],
      loading: false,
      system_id: '',
      searchData: {
        dimension: 0,
        study_date_time_start: '',
        study_date_time_end: '',
        system_ids: [],
        institution_ids: [],
        order_by: 'file_size',
        sort: 'desc',
      },
      institutionArr: [],
    }
  },
  computed: {
    ...mapGetters(['node_system_list']),
  },
  methods: {
    // 给第一行 弟1列 定义一个新的class类名
    handleCellClassName ({ row, column, rowIndex, columnIndex }) {
     if (rowIndex  === 0) {
        if (columnIndex === 1) {
          return 'mergeCell'
        }
     }
    },
    // 点击表格上面的排序
    sortChange (sort) {
      // console.log(sort)
      this.searchData.sort = ''
      this.searchData.order_by = ''
      if (sort.order === 'descending') {
        if (sort.prop  == 'file_size' || sort.prop == 'study_count') {
          this.searchData.order_by =  sort.prop
        }
        this.searchData.sort = 'desc'
      } else {
        if (sort.order) {
          if (sort.prop  == 'file_size' || sort.prop == 'study_count') {
            this.searchData.order_by =  sort.prop
          }
          this.searchData.sort = 'asc'
        }
      }
      this.getImageDataStatistics()
    },
    // 改变系统
    changeSystem (val) {
      this.searchData.institution_ids = []
      if (val) {
        this.beganGetInstitutionsLiteList(val)
      }
      this.getImageDataStatistics()
    },
    // 获取某个系统下的机构列表
    async beganGetInstitutionsLiteList () {
      const res = await getInstitutionListLite({system_id: this.searchData.system_ids})
      if (res.code == 0) {
        this.institutionArr = res.data
      } else {
        this.$message.error(res.msg);
      }
    },
    // 获取查询时间
    getTime (time) {
      //console.log('time',time)
      if (time) {
        this.searchData.study_date_time_start = time[0]
        this.searchData.study_date_time_end = time[1]
        this.search()
      } else {
        this.$message.warning('查询近一个月数据')
        this.initTime = [moment().subtract(1, "month").format("YYYY-MM-DD"),moment().format('YYYY-MM-DD')]
        this.search()
      }
    },
    formatJson (filterVal, jsonData) {
      return jsonData.map(v =>
        filterVal.map(j => {
          return v[j]
        })
      )
    },
    async onExport(dom, tableName, config = {}) {
      await utils.excel.exportExcelWithHeader(dom, tableName, config)
    },
    // 导出表格
    async importTableData () {
      this.searchData.system_ids = []
      if (this.system_id) {
        this.searchData.system_ids.push(this.system_id)
      }
      const res = await this.$pacsApi.pacsApi.importStudyStatement(this.searchData)
      if (res.code == 0) {
        
      } else {
        this.$message.error(res.msg);
      } 


      // 前端自己导出表格
      // const exportTime = `检查时间：${this.searchData.study_date_time_start}~${this.searchData.study_date_time_end}`
      // const userName = `制表人：${this.userName}`

      // // 导出 影像数据统计表
      // this.onExport(this.$refs.workTable.$el, '影像数据统计', {
      //   title: '影像数据统计',
      //   exportTime,
      //   userName,
      //   needTitle: true
      // })

    },
    // 全部关闭
    closeAll () {
      this.tableOneRowKeys = []
    },
    // 全部打开
    openAll() {
      this.tableOneRowKeys = this.workTableData.map(item => {
        return item.id
      })
    },
    // 打印
    printData() {
      let id = ''
      let title = ''
      if (this.tabType === 1) {
        id = '#workTable'
        title = '服务机构开展情况'
        this.openAll()
      } else if (this.tabType === 2) {
        id = '#applyTable'
        title = '申请机构开展情况'
        this.openAll()
      }
      this.$nextTick(() => {
        const table = document.querySelector(id)
        const date = `${this.searchData.study_date_time_start}~${this.searchData.study_date_time_end}`
        const username = this.userName
        new PrintHelper().table(table).prepend({
          title,
          date,
          username
        }).print()
      })
    },
    // 查询
    search () {
      this.loading = true
      this.getImageDataStatistics()
    },
    // 重置
    resetSearch () {
      this.system_id = ''
      this.institutionArr = []
      this.searchData = {
        dimension: 0,
        system_ids: [],
        study_date_time_start: '',
        study_date_time_end: '',
        institution_ids: [],
        order_by: 'file_size',
        sort: 'desc',
      }
      this.initTime = [moment(new Date()).subtract(1,'months').startOf('month').format('YYYY-MM-DD'),moment(new Date()).subtract(1,'months').endOf('month').format('YYYY-MM-DD')]
      this.searchData.study_date_time_start = this.initTime[0]
      this.searchData.study_date_time_end = this.initTime[1] 
    },
    // 获取影像数据统计
    getImageDataStatistics () {
      const self = this
      self.searchData.system_ids = []
      if (self.system_id) {
        self.searchData.system_ids.push(self.system_id)
      }
      self.workTableData = []
      try {
        self.$pacsApi.pacsApi.getStudyStatement(self.searchData).then(res => {
            self.loading = false
            if (res.code !== 0) {
              self.$message.error(res.msg)
              return
            }
            const result = res.data
            result.forEach((item, index) => {
              item.name = item.system_name
              if (item.detail_list && item.detail_list.length > 0) {
                item.detail_list.forEach((c, cindex) => {
                if (self.searchData.dimension === 0) { // 按系统->机构
                  c.name = c.institution_name
                }
                if (self.searchData.dimension === 1) {// 按检查类型
                  c.name = c.modality
                }
              })
             }
             // 赋值表格数据
              self.workTableData.push(item)
            })
            self.$nextTick(() => {
              self.$refs.workTable.doLayout()
            })
        }).catch(() =>{
          self.loading = false   
        })
      }
      catch (error){
        self.loading = false 
      }
    },
  },
  mounted () {
    const self = this
    // 初始化查询时间
    // 近1个月
    if (this.$route.query.system_id) {// 从可视化那边跳转过来的
      this.system_id = this.$route.query.system_id
    }
    if (this.$route.query.start_time) { // 从可视化那边跳转过来的
      self.initTime = [this.$route.query.start_time,this.$route.query.end_time]
      self.searchData.study_date_time_start = self.initTime[0]
      self.searchData.study_date_time_end = self.initTime[1] 
    } else {
      self.initTime = [moment(new Date()).subtract(1,'months').startOf('month').format('YYYY-MM-DD'),moment(new Date()).subtract(1,'months').endOf('month').format('YYYY-MM-DD')]
      self.searchData.study_date_time_start = self.initTime[0]
      self.searchData.study_date_time_end = self.initTime[1] 
    }
    var manager = new Mgr()
    manager.getRole().then(logindata => {
      self.token = logindata.token_type + ' ' + logindata.access_token
      self.userName = logindata.profile.name
    })
  }
}
</script>
<style lang="less" scoped>
.searchTop{
  display: flex;
  align-items: center;
}
.searchBottom{
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
  margin-bottom: 15px;
  height: 32px;
  position: relative;
  .radioChoose{
    position: absolute;
    left:0px;
  }
  .reportTit{
    display: flex;
    align-items: center;
    justify-content: center;
    font-size:16px;
    color:#303133;
    .inspectTime{
      color: #0a70b0;
      font-size:16px;
      font-weight: 500;
      margin-right: 15px;
    }
  }
}
::v-deep .el-select__tags-text{
  float: left;
  max-width: 117px;
  text-overflow: ellipsis;
  overflow: hidden;
}
::v-deep .el-select__input{
  margin-left: 5px;
}
.inspectPage {
  height: 100%;
}
.inspectCon {
  padding: 10px 15px;
  box-sizing: border-box;
  ::v-deep .tableBox{
    width: 800px;
    margin: 0 auto;
    height: 600px;
    max-height: calc(100vh - 225px);
    .el-table__body-wrapper{
      overflow-y: auto!important;
      max-height: calc(100vh - 270px);
    }
  }
}
::v-deep .mergeCell {
  .cell{
    visibility: visible!important;;
  }
}
::v-deep #workTable{
  .el-table th{
    background: #F0F4F9;
    font-weight: 500;
    font-size: 14px;
    color: #303133;
  }
}
.importBtn{
  width: 58px;
  height: 32px;
  background: #FFFFFF;
  border: 1px solid #DCDFE6;
  border-radius: 4px;
  text-align: center;
  line-height: 32px;
  cursor: pointer;
  font-size: 14px;
  color: #1CB54A;
}
.importBtn:hover{
  color:#fff;
  background: #1CB54A;
  border-color: #1CB54A;
}
@media screen and (max-width: 1372px) {
  .applyInstituteForm{
    clear:both;
    margin-top:5px;
  }
  .activeBtnCon{
    margin-top:5px!important;
  }
  #applyTable{
    height: calc(100vh - 197px);
  }
}
</style>
