  <template>
   <div class="video-container">
    <!-- 播放器容器 -->
    <div v-if="videoUrl">
      <video-player 
        ref="videoPlayer"
        :options="playerOptions"
        @ready="onPlayerReady"
        @error="onPlayerError"
      />
      <!-- <button @click="playVideo" class="play-button">点击播放</button> -->
    </div>
    <div v-else class="loadingVideo">
      视频加载中...
    </div>
  </div>
  </template>
  <script>
  import { videoPlayer } from 'vue-video-player';
  import 'video.js/dist/video-js.css';
  import {getDocumentUrl, getDocumentUrlByShortChain, getReportDetails, downloadOfdFile, } from '@/api/memorySharing/dataMemory'
  export default {
    components: { videoPlayer },
    props: {
      fileName: String,
      fileId: String,
    },
    data() {
      return {
        videoUrl: null,
      playerOptions: {
        controls: true,       // 显示控制条
        fluid: true,         // 自适应容器
        preload: 'auto',
        sources: [{
          type: 'video/mp4', // 必须与实际MIME类型一致
          src: ''            // 初始留空，后续动态赋值
        }]
        } 
      }
    },
    methods: {
        getDocumentUrl(id) {
      getDocumentUrl(id).then(res => {
        if(res.code === 0) {
          //this.shortChain = res.data
          getDocumentUrlByShortChain(res.data).then(res => {
            if(res.code === 0) {
              if (res.data.url == '') { // 说明该文件不能浏览
                this.$confirm('<i class="iconfont icontishi clr_e6 mr5"></i>非常抱歉，当前文件不支持浏览', '浏览文件', {
                distinguishCancelAndClose: true,
                dangerouslyUseHTMLString: true,
                // confirmButtonText: '确定',
                // cancelButtonText: '取消'
              }).then(() => {
                this.sureUnBindCa()
              })
              } else {
                this.shortChain = res.data.url
                this.beganGetReportDetails(res.data.hash_id,)
              }
            } else {
              this.$message.error(res.msg)
            }
          })
        }else {
          this.$message.error(res.msg)
        }
      })
    },
    async beganGetReportDetails(accessId) {
      let params = {
        // accessId: 'cCcMVxFadYv', // 图片
        accessId: accessId, // pdf
        bussinessId: ''
      }
      let res = await getReportDetails(params)
      let { Code, Data } = res
      if(Code === 0) {
        if(Data.Details.length > 0) {
          let { DeviceID, FilePath} = Data.Details[0]
          let fileRes = await downloadOfdFile(DeviceID, FilePath)
          //this.fileData = fileRes 
          // 将返回的 blob 转成url
          this.createVideoUrl(fileRes)
        }else {
          this.$message({
            type: 'warning',
            message: '没有相关内容'
          })
        }
      } else {
        this.fileData = null
        this.$message({
          type: 'warning',
          message: res.Msg
        })
      }
    },


    // 生成Blob URL
    createVideoUrl(blob) {
      // 检查视频MIME类型
      if (!blob.type.includes('mp4')) {
        console.warn('非MP4格式，当前类型:', blob.type)
      }
      
      this.videoUrl = URL.createObjectURL(blob)
      this.updatePlayerSource()
    },

    // 更新播放器源
    updatePlayerSource() {
      this.$nextTick(() => {
        const player = this.$refs.videoPlayer.player
        player.src({
          type: 'video/mp4',
          src: this.videoUrl
        })
        player.load() // 强制重新加载
      })
    },

    // 播放器准备就绪
    onPlayerReady(player) {
      console.log('播放器已就绪')
      this.player = player
    },

    // 错误处理
    onPlayerError() {
      const error = this.player.error()
      console.error('播放错误:', error ? error.code : '未知错误')
    },

    // 用户手动触发播放
    playVideo() {
      this.player.play().catch(error => {
        console.warn('自动播放被阻止:', error)
      })
    }

    },
    created() {
      this.videoUrl = null;
      this.getDocumentUrl(this.fileId)
    },
    beforeDestroy() {
      if (this.videoUrl) URL.revokeObjectURL(this.videoUrl);
     }
  };
  </script>
  <style lang="less" scoped>
  .video-container{
    width:100%;
    height:100%;
    // display:flex;
    // justify-content: center;
    // align-items: center;
    ::v-deep .vjs-big-play-button {
      left:50%;
      top:50%;
    }
  }
  .loadingVideo{
    width:100%;
    height:100%;
    display:flex;
    justify-content: center;
    align-items: center;
  }
  </style>