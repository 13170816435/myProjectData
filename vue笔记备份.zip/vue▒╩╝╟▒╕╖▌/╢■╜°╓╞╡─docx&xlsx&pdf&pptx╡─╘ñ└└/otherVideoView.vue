<!-- <template>
  <div>
    <input type="file" @change="convertVideo" accept=".avi,.wmv" />
    <video v-if="mp4Url" :src="mp4Url" controls />
  </div>
</template>

<script>
import { createFFmpeg, fetchFile } from '@ffmpeg/ffmpeg';
import {getDocumentUrl, getDocumentUrlByShortChain, getReportDetails, downloadOfdFile, } from '@/api/memorySharing/dataMemory'
export default {
  props: {
    fileName: String,
    fileId: String,
  },
  data() {
    return { ffmpeg: null, mp4Url: '' };
  },
  async mounted() {
    this.ffmpeg = createFFmpeg({ log: true });
    await this.ffmpeg.load(); // 加载 FFmpeg 核心库‌:ml-citation{ref="3,7" data="citationList"}
  },
  methods: {
    getDocumentUrl(id) {
      getDocumentUrl(id).then(res => {
        if(res.code === 0) {
          //this.shortChain = res.data
          getDocumentUrlByShortChain(res.data).then(res => {
            if(res.code === 0) {
              if (res.data.url == '') { // 说明该文件不能浏览
                this.$confirm('<i class="iconfont icontishi clr_e6 mr5"></i>非常抱歉，当前文件不支持浏览', '浏览文件', {
                distinguishCancelAndClose: true,
                dangerouslyUseHTMLString: true,
                // confirmButtonText: '确定',
                // cancelButtonText: '取消'
              }).then(() => {
                this.sureUnBindCa()
              })
              } else {
                this.shortChain = res.data.url
                this.beganGetReportDetails(res.data.hash_id,)
              }
            } else {
              this.$message.error(res.msg)
            }
          })
        }else {
          this.$message.error(res.msg)
        }
      })
    },
    async beganGetReportDetails(accessId) {
      let params = {
        // accessId: 'cCcMVxFadYv', // 图片
        accessId: accessId, // pdf
        bussinessId: ''
      }
      let res = await getReportDetails(params)
      let { Code, Data } = res
      if(Code === 0) {
        if(Data.Details.length > 0) {
          let { DeviceID, FilePath} = Data.Details[0]
          let fileRes = await downloadOfdFile(DeviceID, FilePath)
          
          // 写入二进制流到 FFmpeg 虚拟文件系统
          this.ffmpeg.FS('writeFile', 'input', fileRes);

          // 执行转码命令（AVI/WMV → MP4）
          await this.ffmpeg.run(
            '-i', 'input',
            '-c:v', 'libx264', // H.264 编码
            '-preset', 'fast', // 加速转码
            '-crf', '23',      // 平衡画质与体积
            'output.mp4'
          );

          // 生成可播放的 MP4 URL
          const data = this.ffmpeg.FS('readFile', 'output.mp4');
          this.mp4Url = URL.createObjectURL(
            new Blob([data.buffer], { type: 'video/mp4' })
          );


        }else {
          this.$message({
            type: 'warning',
            message: '没有相关内容'
          })
        }
      } else {
        this.fileData = null
        this.$message({
          type: 'warning',
          message: res.Msg
        })
      }
    },
    async convertVideo(e) {
      const file = e.target.files;
      if (!file) return;

      // 写入二进制流到 FFmpeg 虚拟文件系统
      this.ffmpeg.FS('writeFile', 'input', await fetchFile(file));

      // 执行转码命令（AVI/WMV → MP4）
      await this.ffmpeg.run(
        '-i', 'input',
        '-c:v', 'libx264', // H.264 编码
        '-preset', 'fast', // 加速转码
        '-crf', '23',      // 平衡画质与体积
        'output.mp4'
      );

      // 生成可播放的 MP4 URL
      const data = this.ffmpeg.FS('readFile', 'output.mp4');
      this.mp4Url = URL.createObjectURL(
        new Blob([data.buffer], { type: 'video/mp4' })
      );
    }
  },
  created() {
    this.getDocumentUrl(this.fileId)
  },
};
</script> -->