<template>
  <div class="addDialog">
    <el-dialog
      :title="addDialogData.title"
      :visible.sync="addDialogData.show"
      :close-on-click-modal="false"
      width="1100px"
      top="3%"
      :before-close="handlerClose"
    >
      <div class="">
        <el-form
          ref="addPrintDeviceForm"
          :inline="true"
          :disabled="addDialogData.type == 'view'"
          class="demo-form-inline"
          label-width="auto"
          label-position="left"
          :rules="rules"
          :model="dialogData"
        >
        <div class="of bb_solid pb15">
          <div class="deviceTitle f16 mt5 clr_333">基本信息</div>
          <div class="clear_fixed">
            <el-form-item label="设备描述：" prop="description">
              <el-input
                class=""
                size="small"
                v-on:keyup.enter.native="searchCondation"
                v-model="dialogData.description"
                placeholder="请输入"
                style="width: 240px;margin-right: 30px;"
                clearable
              ></el-input>
            </el-form-item>

            <el-form-item label="设备状态：" prop="state">
              <el-select
              v-model="dialogData.state"
              size="small"
              style="width: 240px"
              clearable
            >
              <el-option
                v-for="(item, index) in devicesState"
                :key="index"
                :value="item.value"
                :label="item.name"
              >
              </el-option>
            </el-select>
            </el-form-item><br/>

            
            <el-form-item label="普通打印：" label-width="80.38px" class="noRequireLabel">
              <el-select
              v-model="common_print"
              size="small"
              style="width: 240px;margin-right: 40px;"
              clearable
            >
              <el-option
                v-for="(item, index) in commonPrintArr"
                :key="index"
                :value="item.value"
                :label="item.name"
              >
              </el-option>
            </el-select>
            </el-form-item>
            <el-form-item label="打印方式：" prop="printer_name">
              <el-select
              v-model="dialogData.printer_name"
              :disabled="common_print == -1"
              size="small"
              style="width: 240px;margin-right: 30px;"
              clearable
            >
              <el-option
                v-for="(item, index) in printWayArr"
                :key="index"
                :value="item.value"
                :label="item.name"
              >
              </el-option>
            </el-select>
            </el-form-item>

            <el-form-item label="监控超时：" prop="heart_interval">
              <el-input
                size="small"
                placeholder="请输入"
                style="width: 173px"
                v-model="dialogData.heart_interval"
                clearable
              >
              </el-input>
              <span class="unit ml10">秒</span>
            </el-form-item><br/>
            <el-form-item label="应用标识：" prop="ae_title">
              <el-input
                size="small"
                placeholder="请输入"
                style="width: 240px;margin-right: 30px;"
                v-model="dialogData.ae_title"
                clearable
              >
              </el-input>
            </el-form-item>

            <el-form-item label="设备地址：" prop="host_name">
              <el-input
                size="small"
                placeholder="请输入"
                v-model="dialogData.host_name"
                style="width: 240px;margin-right: 45px;"
                clearable
              >
              </el-input>
            </el-form-item>
            <el-form-item label="端口号：" prop="dicom_port">
              <el-input
                size="small"
                placeholder="请输入"
                v-model="dialogData.dicom_port"
                style="width: 173px"
                clearable
              >
              </el-input>

              <el-button class="ml10" @click="testPort" size="small" type="primary">测 试</el-button>
            </el-form-item>
          </div>
          </div>

          <div class="of pb15">
            <div class="deviceTitle f16 mt5 clr_333">打印参数</div>
            <div class="clear_fixed">
              <el-form-item label="插值方式：" prop="default_magnification">
                <el-select
                v-model="dialogData.default_magnification"
                size="small"
                style="width: 240px;margin-right: 50px;"
                clearable
              >
                <el-option
                  v-for="(item, index) in magnificationArr"
                  :key="index"
                  :value="item.value"
                  :label="item.name"
                >
                </el-option>
              </el-select>
              </el-form-item>

              <el-form-item label="胶片介质：" prop="default_medium_type">
                <el-select
                v-model="dialogData.default_medium_type"
                size="small"
                style="width: 240px;margin-right: 45px;"
                clearable
              >
                <el-option
                  v-for="(item, index) in filmTypeArr"
                  :key="index"
                  :value="item.value"
                  :label="item.name"
                >
                </el-option>
              </el-select>
              </el-form-item>

              <el-form-item label="胶片规格：" prop="default_film_size_id">
                <el-select
                v-model="dialogData.default_film_size_id"
                size="small"
                style="width: 240px"
                clearable
              >
                <el-option
                  v-for="(item, index) in fileSizeArr"
                  :key="index"
                  :value="item.value"
                  :label="item.label"
                >
                </el-option>
              </el-select>
              </el-form-item>

              <el-form-item label="拼接打印：" prop="merge_format">
               <el-input
                size="small"
                placeholder="请输入"
                style="width: 240px;"
                v-model="dialogData.merge_format"
                clearable
               >
              </el-input>
            </el-form-item><br/>
            
            <el-form-item label="" label-width="110px" prop="days_range">
              <el-checkbox class="customCheckbox ml70" :true-label="checkBoxValue" :false-label="nocheckBoxValue" v-model="dialogData.support_color" :disabled="common_print == 1">支持彩色图像打印</el-checkbox><br/>
            </el-form-item><br/>
            
            <el-form-item label="" label-width="110px" prop="limit_rect">
              <el-checkbox class="customCheckbox ml70" :true-label="checkBoxValue" :false-label="nocheckBoxValue" v-model="dialogData.limit_rect">限制大小</el-checkbox>
            </el-form-item>

            <el-form-item label="宽：" label-width="" prop="max_width">
              <el-input
                size="small"
                class="shortInput"
                placeholder="请输入"
                v-model="dialogData.max_width"
                style="width: 80px;margin-right: 20px;"
                clearable
              >
              </el-input>
            </el-form-item>

            <el-form-item label="高：" label-width="30" prop="max_heigth">
              <span class=""></span>
              <el-input
                size="small"
                class="shortInput"
                placeholder="请输入"
                v-model="dialogData.max_heigth"
                style="width: 80px;margin-right: 20px;"
                clearable
              >
              </el-input>
            </el-form-item><br/>
            

            <el-form-item label="" label-width="" prop="b_black_fill">
              <el-checkbox class="customCheckbox ml70" :true-label="checkBoxValue" :false-label="nocheckBoxValue" v-model="dialogData.b_black_fill">黑色填充</el-checkbox>
            </el-form-item>
 
            <el-form-item label="上：" label-width="30" prop="n_fill_top">
              <el-input
                size="small"
                class="shortInput"
                placeholder="请输入"
                v-model="dialogData.n_fill_top"
                style="width: 80px;margin-right: 20px;"
                clearable
              >
              </el-input>
            </el-form-item>
            <el-form-item label="下：" label-width="30" prop="n_fill_bottom">
              <el-input
                size="small"
                class="shortInput"
                placeholder="请输入"
                v-model="dialogData.n_fill_bottom"
                style="width: 80px;margin-right: 20px;"
                clearable
              >
              </el-input>
            </el-form-item>
            <el-form-item label="左：" label-width="30" prop="n_fill_left">
              <el-input
                size="small"
                class="shortInput"
                placeholder="请输入"
                v-model="dialogData.n_fill_left"
                style="width: 80px;margin-right: 20px;"
                clearable
              >
              </el-input>
            </el-form-item>
            <el-form-item label="右：" label-width="30" prop="n_fill_right">
              <el-input
                size="small"
                class="shortInput"
                placeholder="请输入"
                v-model="dialogData.n_fill_right"
                style="width: 80px;"
                clearable
              >
              </el-input>
            </el-form-item>
          </div>
          </div>
        </el-form>
      </div>

    <div slot="footer" class="dialog-footer tr">
      <el-button @click="handlerClose" size="small" class="mr10">取 消</el-button>
      <el-button
        v-if="dialogType !== 'view'"
        type="primary"
        @click="beganAddPrintDevice"
        size="small"
        >保 存</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { validPort, validPath, validURL, validIP } from '@/utils/validate'
import { mapGetters } from "vuex";

export default {
  data() {
    let requiredValidator = function (tip) {
      return (rule, value, callback) => {
        if (value === "") {
          callback(new Error(tip));
        } else {
          callback();
        }
      };
    };
    let portValidator = (rule, value, callback) => {
        if (value !== '') {
          if (validPort(value)) {
            callback()
          } else {
            callback(new Error('端口号范围为0-65535'))
          }
        } else {
          callback(new Error('请输入端口号'))
        }
    }
   // 验证设备地址
    let urlValidator = (rule, value, callback) => {
      if (value && value.length > 0) {
        if (validURL(value) || validIP(value)) {
          callback()
        } else {
          callback(new Error('设备地址格式错误'))
        }
      } else {
        callback(new Error('请输入'))
      }
    }
    // 验证日志保存时长
    let iptNumValidator = (rule, value, callback) => {
      if (value === undefined || value === '') {
        callback(new Error('请输入'))
      } else {
        const num = Number(value);
        if (Number.isInteger(num)) {
          callback()
        } else {
          callback(new Error('请输入数字'))
        }
      }
    }

    // 验证最大宽   最大高
    let widthOrHeightNumValidator = (rule, value, callback) => {
      if (value == '') {
        callback()
      } else {
        const num = Number(value);
        if (Number.isInteger(num)) {
          callback()
        } else {
          callback(new Error('请输入数字'))
        }
      }
    }

    return {
      testState: 0,
      passTest: true,
      checkBoxValue:1,
      nocheckBoxValue: 0,
      devicesList: [],
      devicesState: [
        {
          name: '检修',
          value: -2,
        },
        {
          name: '故障',
          value: -1,
        },
        {
          name: '正常',
          value: 1,
        },
        {
          name: '未知',
          value: 0,
        },
        {
          name: '片量低',
          value: 2,
        },
        {
          name: '缺片',
          value: 3,
        },
      ],
      common_print: '', // 普通打印
      commonPrintArr: [// 普通打印
        {
          name: '是',
          value: 1,
        },
        {
          name: '否',
          value: -1,
        }
      ],
      printWayArr: [// 打印方式
        {
          name: 'ZDKJ VPinter',
          value: 'ZDKJ VPinter',
        },
        {
          name: 'OneNote for Window 10',
          value:'OneNote for Window 10',
        },
        {
          name: 'Micosoft XPS Document Wr',
          value:'Micosoft XPS Document Wr',
        },
        {
          name: 'Micosoft XPS Document Wr',
          value:'Micosoft Print to PDF',
        },
        {
          name: 'fax',
          value:'fax',
        },
      ],
      magnificationArr: [// 插值方式
        {
          name: 'REPLICATE',
          value:'REPLICATE',
        },
        {
          name: 'BILINEAR',
          value:'BILINEAR',
        },
        {
          name: 'CUBIC',
          value:'CUBIC',
        },
        {
          name: 'NONE',
          value:'NONE',
        },
        {
          name: 'DEFAULT',
          value:'DEFAULT',
        },
      ],
      filmTypeArr: [// 胶片介质(类型)
        {
          name: 'PAPER',
          value:'PAPER',
        },
        {
          name: 'CLEAR FILM',
          value:'CLEAR FILM',
        },
        {
          name: 'BLUE FILM',
          value:'BLUE FILM',
        },
        {
          name: 'BLUE FILM',
          value:'BLUE FILM',
        },
      ],
      fileSizeArr: [// 胶片大小
        {
          name: '8INX10IN',
          value:'8INX10IN',
        },
        {
          name: '8_5INX11IN',
          value:'8_5INX11IN',
        },
        {
          name: '10INX12IN',
          value:'10INX12IN',
        },
        {
          name: '10INX14IN',
          value:'10INX14IN',
        },
        {
          name: '11INX14IN',
          value:'11INX14IN',
        },
        {
          name: '11INX17IN',
          value:'11INX17IN',
        },
        {
          name: '14INX14IN',
          value:'14INX14IN',
        },
        {
          name: '14INX17IN',
          value:'14INX17IN',
        },
      ],
      dialogData: {
        id: '0',
        description: "",// 设备描述
        state: '', // 设置状态
        printer_name: '',// 打印方式
        heart_interval: 0,// 监控超时
        ae_title: '',// 应用标识
        host_name: '',//设备地址
        dicom_port: '',// 端口号
        default_magnification: '',// 插值方式
        default_medium_type: '',// 胶片介质
        default_film_size_id: '',// 胶片规格
        merge_format: '',// 拼接打印
        support_color: 0, // 彩色图像打印
        limit_rect: 0, // 限制大小
        max_width: 0,// 宽
        max_heigth: 0,// 高
        b_black_fill: 0,// 黑色填充
        n_fill_top: 0,// 上
        n_fill_bottom: 0,// 下
        n_fill_left: 0,// 左
        n_fill_right: 0,// 右
      },

      rules: {
        description: [{required:true, message: "请输入", trigger: "blur",  validator: requiredValidator('请输入设备描述') }],
        state: [{required:true, message: "请选择", trigger: "change",    validator: requiredValidator('请选择') }],
        heart_interval: [{required:true, trigger: "blur",  validator: iptNumValidator }],
        ae_title: [{required:true, message: "请输入", trigger: "blur",  validator: requiredValidator('请输入应用标识') }],
        host_name: [{required:true, trigger: "blur",  validator: urlValidator}],
        dicom_port: [
         // { required:true, message: "请输入", trigger: "blur",  validator: portValidator },
          { required:true, trigger: "blur",  validator: portValidator }
        ],
        max_width:[{ trigger: 'blur',  validator: widthOrHeightNumValidator }],
        max_heigth:[{ trigger: "blur",  validator: widthOrHeightNumValidator }],
        n_fill_top:[{ trigger: "blur",  validator: widthOrHeightNumValidator }],
        n_fill_bottom:[{ trigger: "blur",  validator: widthOrHeightNumValidator }],
        n_fill_left:[{ trigger: "blur",  validator: widthOrHeightNumValidator }],
        n_fill_right:[{ trigger: "blur",  validator: widthOrHeightNumValidator }],
      },
    };
  },
  props: ["addDialogData",'dialogType'],
  computed: {},
  mounted() {
    this.addType = this.addDialogData.type == 'add' ? 0 : 1
    // this.dialogData = this.addDialogData.dialogData
  },
  watch: {
  },
  methods: {
    handlerClose() {
      this.$emit("addPrintDeiveClose");
    },
    isValueEmpty(value) {
      if (value?.length > 0) {
        return false;
      }
      return true;
    },
    // 测试端口号
    async testPort() {
      this.$refs.addPrintDeviceForm.validate(async (result) => {
        if (result) {
          const res = await this.$pacsApi.pacsApi.testPrintDevice(this.dialogData)
          const { code, data, msg } = res
          if (code != 0) {
            this.testState = -1
            this.$message.error(msg)
            return
          }
          this.testState = 1
        }
      });
    },
    // 编辑打印设备时  回显打印设备信息
    editPrintDevice (formData) {
      for (let key in formData) {
        this.dialogData[key] = formData[key]
      }
      this.common_print = this.dialogData.printer_name ? 1 : -1
    },
    // 开始添加打印设备
    beganAddPrintDevice() {
      // if (this.addDialogData.type == "view") {
      //   this.$emit("addPrintDeiveClose");
      // } else {
      //   this.$refs.addPrintDeviceForm.validate(async (result) => {
      //     console.log("验证失败了吗？", result);
      //     if (result) {
      //       this.sureAddOrUpdateRequestDevice();
      //     }
      //   });
      // }
      
      this.$refs.addPrintDeviceForm.validate(async (result) => {
        //console.log("验证失败了吗？", result);
        if (result) {
          this.sureAddOrUpdateRequestDevice();
        }
      });
    },
   // 确定添加设备
    async sureAddOrUpdateRequestDevice() {
      // if (this.testState != 1) {
      //   this.$message.error('请测试设备，通过后才可保存！')
      //   return
      // }
      let params = { ...this.dialogData };
      let result = [];
      if (this.addDialogData.type == "add") {
        result = await this.$pacsApi.pacsApi.addPrintDevice(params);
      } else if (this.addDialogData.type == "modify") {
        result = await this.$pacsApi.pacsApi.updatePrintDevice(
          params.id,
          params
        );
      }
      let { code, msg } = result;
      const loading = this.$loading({
        lock: true,
        text: this.addDialogData.type == "add" ? "正在新增打印设备，请稍等..." : '正在修改打印设备，请稍等...',
        spinner: 'el-icon-loading',
        background: 'rgba(255, 255, 255, 0.6)'
      })
      if (code == 0) {
        let newMsg = ''
        if (this.addDialogData.type == "add") {
          newMsg = '新增打印设备成功'
        } else {
          newMsg = '修改打印设备成功'
        }
        this.$message.success(newMsg);
        loading.close()
        this.$emit("addPrintDeiveClose", true);
      } else {
        loading.close()
        this.$message.error(msg);
      }
    },
  },
};
</script>
<style lang='less' scoped>
.addDialog {
  ::v-deep .el-dialog__footer {
    padding: 10px 20px;
    border-top: 1px solid #dcdfe6;
  }
  ::v-deep .el-input--small .el-input__icon{
    line-height: 40px;
  }
  .mr0{
    margin-right: 0px!important;
  }
  ::v-deep .el-form-item__label-wrap{
    margin-left:0!important;
  }
  ::v-deep .el-checkbox{
    margin-right: 0px!important;
  }
  ::v-deep .shortInput{
    .el-input__inner{
      padding: 0 15px!important;
    }
  }
  ::v-deep .el-form-item__content{
    line-height: 40px;
  }
  .mb15{margin-bottom: 15px!important;}
  ::v-deep .noRequireLabel {
    .el-form-item__label {
      text-align: right;
    }
  }
  ::v-deep .el-form-item__error {
    padding-top:0px!important;
  }
}
.deviceTitle {
  line-height: 40px;
  height: 40px;
  position: relative;
  padding: 0 10px;
  font-size: 14px;
  color: #303133;
  font-weight: 600;
  &:before {
    position: absolute;
    left: 0;
    top: 13px;
    width: 4px;
    height: 14px;
    background: #0a70b0;
    content: '';
  }
}
.bb_solid{
  border-bottom: 2px solid #EBEEF5;  
}
</style>