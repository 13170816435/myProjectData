<template>
    <el-form
      label-position="right"
      :model="formData"
      :inline="true"
      :rules="printParamRules"
      class="printParamForm"
      ref="strategyForm"
    >
      <!-- <div class="bb_dashed lh32 pt15">
        <el-form-item>
          <div slot="label" class="paramItemTit mr15">启用状态</div>
          <div>
            <el-switch
              v-model="formData.enable"
              :active-value="1"
              :inactive-value="0"
            >
            </el-switch>
          </div>
        </el-form-item>
      </div> -->
      <div class="bb_dashed lh32 pt15">
        <el-form-item class="flex_row">
            <div slot="label" class="paramItemTit">服务信息</div>
            <div>
              <el-form-item
                label="应用标识："
                label-width="110px"
                prop="ae_title"
              >
                <el-input
                  size="small"
                  disabled
                  placeholder="请输入应用标识"
                  style="width: 240px;"
                  v-model="formData.ae_title"
                >
                </el-input>
              </el-form-item>
              

              <el-form-item
              label="主机地址："
              label-width="110px"
              prop="host_name"
            >
              <el-input
                  size="small"
                  placeholder="请输入"
                  style="width: 240px"
                  v-model="formData.host_name"
                >
                </el-input>
            </el-form-item> 

              <el-form-item
              label="端口号："
              label-width="110px"
              prop="scp_port"
            >
              <el-input
                  size="small"
                  placeholder="请输入"
                  style="width: 240px;"
                  v-model="formData.scp_port"
                >
                </el-input>
            </el-form-item><br/>

            <el-form-item
              label="日志保存路径："
              class="mt15"
              label-width="110px"
              prop="log_save_path"
            >
              <el-input
                  size="small"
                  placeholder="请输入"
                  style="width: 240px"
                  v-model="formData.log_save_path"
                >
                </el-input>
            </el-form-item>

            <el-form-item
              label="日志保存时长："
              label-width="110px"
              class="mt15"
              prop="log_save_days"
            >
              <el-input-number
                v-model="formData.log_save_days"
                controls-position="right"
                size="small"
                :min="1"
              ></el-input-number>
              <span class="ml10">天</span>
            </el-form-item>
            <br/>

            <el-form-item label="日志等级：" class="mt5"  prop="log_mode" label-width="110px">
              <el-radio-group v-model="formData.log_mode" class="customRadio">
                <el-radio :label="0">致命</el-radio>
                <el-radio :label="1">错误</el-radio>
                <el-radio :label="2">警告</el-radio>
                <el-radio :label="3">过程</el-radio>
                <el-radio :label="4">调试</el-radio>
                <el-radio :label="5">跟踪</el-radio>
              </el-radio-group>
             </el-form-item>
          </div>
        </el-form-item>
      </div>
    
      <div class="bb_dashed lh32 pt15 pb10 paramsItem">
        <el-form-item>
          <div slot="label" class="paramItemTit">存储信息</div>
          <div>
            <el-form-item
              label="缓存路径："
              label-width="110px"
              prop="cache_path"
            >
              <el-input
                  size="small"
                  placeholder="请输入"
                  style="width: 400px"
                  v-model="formData.cache_path"
                >
                </el-input>
            </el-form-item>
  
          </div>
        </el-form-item>
        <span class="clr_orange ">打印任务中图像文件在服务器的存储路径</span>
      </div>

      <div class="bb_dashed lh32 pt15 pb10 paramsItem moreTipCon">
        <el-form-item>
          <div slot="label" class="paramItemTit">匹配策略</div>
          
          <el-form-item label="启用状态：" label-width="110px">
              <el-switch
                v-model="formData.auto_matching"
                :active-value="1"
                :inactive-value="0"
              >
              </el-switch>

          </el-form-item>

          <div class="">
              <el-form-item label="检查范围：" label-width="110px" prop="search_days">
              <el-input
                  size="small"
                  placeholder="请输入"
                  style="width: 75px"
                  v-model="formData.search_days"
                >
                </el-input>
              <span class="ml5 mr5">天内的</span>
              
              </el-form-item>
              
              <el-form-item label="" label-width="110px" prop="max_return">
                <el-input
                  size="small"
                  placeholder="请输入"
                  style="width: 75px"
                  v-model="formData.max_return"
                >
                </el-input>
                <span class="ml5">条数据</span>
                <el-checkbox class="customCheckbox ml50" :true-label="checkBoxValue" :false-label="nocheckBoxValue" v-model="formData.is_push_two_times">覆盖范围不足时前推2次</el-checkbox>
              </el-form-item>
          </div>
        </el-form-item>
        <span class="clr_orange moreLineText">
            在业务系统中查询指定天数内，指定数量的检查记录，并进行匹配<br/>
            启用“覆盖范围不足时前推2次”后，如果首次查询结果中没有满足匹配条件的检查，则会将天数往前再推两次，进行查询<br/>
            如：配置3天内3000条，则首次查询0~3天的3000条数据；若无法匹配，则第一次前推，查询4~6天内的3000条；若还是<br/>
            无法匹配，则第二次前推，查询7~9天内的3000条数据
          </span>
      </div>

      <div class="bb_dashed lh32 pt15 pb10 paramsItem" style="padding-left:30px;">
          <el-form-item label="匹配成功后通知云PACS："
          label-width="180px" prop="cloud_pacs_notice">
              <el-switch
                v-model="formData.cloud_pacs_notice"
                :active-value="1"
                :inactive-value="0"
              >
              </el-switch>
          </el-form-item>
          <span class="clr_orange ">启用后，胶片任务匹配成功后将通知云PACS</span>
      </div>


      <div class="bb_dashed lh32 pt15 pb10 paramsItem" style="padding-left:54px;">
          <el-form-item label="OCR识别地址："
          label-width="112px" prop="paddle_ocrurl">

            <el-input
                size="small"
                placeholder="请输入"
                style="width: 400px"
                v-model="formData.paddle_ocrurl"
                >
            </el-input>
          </el-form-item>
          <span class="clr_orange ">填写OCR地址，用于在线OCR识别</span>
      </div>

      <div class="bb_dashed lh32 pt15 pb10 paramsItem" style="padding-left:54px;">
          <el-form-item label="DPI参数："
          label-width="110px" prop="def_resolution">
          <el-input
              size="small"
              placeholder="请输入"
              style="width: 400px"
              v-model="formData.def_resolution"
            >
            </el-input>
          </el-form-item>
          <span class="clr_orange ">控制DICOM转换JPG时，JPG图片的分辨率</span>
      </div>

      <div class="bb_dashed lh32 pt15 pb10 paramsItem">
        <el-form-item>
          <div slot="label" class="paramItemTit">打印策略</div>
          <el-form-item label="启用状态：" label-width="110px">
              <el-switch
                v-model="formData.auto_print"
                :active-value="1"
                :inactive-value="0"
              >
              </el-switch>
          </el-form-item>
          <div class="">
            <el-form-item
              label=""
              label-width="110px"
              prop="storage_device_key"
            >
              <el-checkbox class="customCheckbox ml40" :true-label="checkBoxValue" :false-label="nocheckBoxValue" v-model="formData.multi_thread">多线程打印</el-checkbox>
              </el-form-item>
              
          </div>
        </el-form-item>
        <span class="clr_orange specailTip">启用后，当用户的目标相机有多台时，为提供拍片速度，为每个相机启动一条执行线程</span>
      </div>

      <div class="bb_dashed lh32 pt15 pb10 paramsItem pl96">
          <el-form-item  prop="auto_unlock_film">
            <el-checkbox class="customCheckbox" :true-label="checkBoxValue" :false-label="nocheckBoxValue" v-model="formData.auto_unlock_film">自动解锁打印失败任务</el-checkbox>
          </el-form-item>
          <span class="clr_orange">启用后，执行打印之前，会自动解锁“打印失败但仍然被锁定”的任务</span>
      </div>

      <div class="bb_dashed lh32 pt15 pb10 paramsItem pl96">
          <el-form-item  prop="is_has_direct_print_ae">
            <el-checkbox class="customCheckbox treatmentCheckbox" v-model="is_has_direct_print_ae">急诊打印应用标识</el-checkbox>
            <el-input
                size="small"
                placeholder="请输入"
                style="width: 100px"
                v-model="formData.direct_print_ae"
              >
              </el-input>
          </el-form-item>
          <span class="clr_orange ">启用后，当收到该应用标识的请求设备的打印任务后，则立即进行打印</span>
      </div>
      <div class="bb_dashed lh32 pt15 pb10 paramsItem pl96">
          <el-form-item  prop="detect_printer">
            <el-checkbox class="customCheckbox" :true-label="checkBoxValue" :false-label="nocheckBoxValue" v-model="formData.detect_printer">检测相机状态</el-checkbox>
          </el-form-item>
          <span class="clr_orange phoneStatusTip">启用后，在拍片过程中每执行5个任务，检测一下相机的状态，以便及时将诸如片量低，缺片，故障等状态反馈给客户端</span>
      </div>

      <div class="bb_dashed lh32 pt15 pb10 paramsItem pl96">
          <el-form-item  prop="print_fail_retry">
            <el-checkbox class="customCheckbox" size="mini" :true-label="checkBoxValue" :false-label="nocheckBoxValue" v-model="formData.print_fail_retry">打印失败重试2次</el-checkbox>
          </el-form-item>
          <span class="clr_orange ">启用后，打印任务执行失败后，将自动重新执行2次</span>
      </div>

      <div class="bb_dashed lh32 pt15 pb10 paramsItem pl96">
          <el-form-item  prop="reserve_merge_cache">
            <el-checkbox class="customCheckbox mr58" :true-label="checkBoxValue" :false-label="nocheckBoxValue" v-model="formData.reserve_merge_cache">保留拼接临时文件</el-checkbox>
          </el-form-item>
          <span class="clr_orange moreText">
              注意：该参数在调试时使用，平时无需开启！<br/>
             启用后，会保留拼接后的DICOM文件，并存储在缓存路径下</span>
      </div>


      <div class="pt10 pb10">
        <el-button @click="cancelSave" size="small"
          >取消</el-button
        >
        <el-button @click="submitEvent" size="small" type="primary"
          >保存</el-button
        >
      </div>
    </el-form>
  </template>
  <script>
  import { validPort, validPath, validURL, validIP } from '@/utils/validate'
  import { modalityType } from '@/utils/dataDictionary'
  import { mapGetters } from 'vuex'
  export default {
    data() {
      return {
        checkBoxValue:1,
        nocheckBoxValue: 0,
        more_modality: '',
        formData: {
          id: 0,
          split_task_file: 0,

          ae_title: '', // 应用标识
          host_name: '', // 主机
          scp_port: '', // 端口号
          log_save_path: '',// 日志保存路径
          log_save_days: 5, // 日志保存时长
          log_mode: '',// 日志等级

          cache_path: '', // 存储路径
          
          auto_matching: 0, // 匹配策略 开关
          search_days: 3, //检查范围多少天
          max_return: 3000, // 最大检查条数---字段要待确认
          is_push_two_times: 0, // 是否覆盖范围不足时前推2次
          
          cloud_pacs_notice: 0, //匹配成功后通知云PACS
          paddle_ocrurl: '',   // OCR识别地址
          def_resolution: 300, //DPI参数

          auto_print: 0,   // 打印策略 开关
          multi_thread: 0, // 是否多线程打印
          auto_unlock_film: 0, // 是否自动解锁打印
          direct_print_ae: '', // 急诊标识
          detect_printer: 0, // 是否检测相机状态
          reserve_merge_cache: 0, // 是否保留临时文件
          print_fail_retry: 0, // 是否打印失败后重试2次
        },
        devicesList: [],
      }
    },
    computed: {
      ...mapGetters(['loginInfo']),
      // 是否填写了急诊打印应用标识
      is_has_direct_print_ae () {
        if (this.formData.direct_print_ae) {
          return true
        } else {
          return false
        }
      },
      printParamRules() {
        let requiredValidator = (tip) => {
          return (rule, value, callback) => {
            if (value === '' || value === null || value === undefined) {
              callback(new Error(tip))
            } else {
              callback()
            }
          }
        }
        // 验证主机
        let urlValidator = (iptNumName) => {
          return (rule, value, callback) => {
          if (value && value.length > 0) {
            if (validURL(value) || validIP(value)) {
              callback()
            } else {
              if (iptNumName == 'paddle_ocrurl') {
                callback(new Error('OCR识别地址格式错误'))
              } else {
                callback(new Error('访问地址格式错误'))
              }
            }
          } else {
            // callback(new Error('请输入访问地址'))
            if (iptNumName == 'paddle_ocrurl') {
              callback(new Error('请输入'))
            } else {
              callback()
            }
          }
         }
        }
        // 验证端口号
        let portValidator = (rule, value, callback) => {
          //return (rule, value, callback) => {
            if (value && value.length > 0) {
              if (validPort(value)) {
                callback()
              } else {
                callback(new Error('端口号范围为0-65535'))
              }
            } else {
              // callback(new Error('请输入端口号'))
              callback()
            }
          //}
        }
        // 验证日志路径
        let pathValidator = (type) => {
          return (rule, value, callback) => {
            if (value && value.length > 0) {
              if (validPath(value)) {
                callback()
              } else {
                if (type == 'logPath') {
                  callback(new Error('日志保存路径输入错误'))
                }
                if (type == 'storagePath') {
                  callback(new Error('日志保存路径输入错误'))
                }
              }
            } else {
              if (type == 'logPath') {
                callback(new Error('请输入日志保存路径'))
              }
              if (type == 'storagePath') {
                callback(new Error('请输入存储路径'))
              }
            }
          }
        }
        // 验证日志保存时长
        let iptNumValidator = (iptNumName) => {
          return (rule, value, callback) => {
            if (value === undefined || value === '') {
              callback(new Error('请输入'))
            } else {
              if (iptNumName == 'log_save_days' || iptNumName == 'def_resolution') {
                const reg = /^[0-9]*$/;
                if (reg.test(value)) {
                  this.formData[iptNumName] = parseInt(value)
                  callback()
                } else {
                  callback(new Error('请输入数字'))
                }
              }
            }
          }
        }
        // 验证检查范围
        let inspectRangeNumValidator = (iptNumName) => {
          return (rule, value, callback) => {
            if (value === undefined || value === '') {
              callback(new Error('请输入'))
            } else if (iptNumName == 'search_days' || iptNumName == 'max_return') {
              const reg = /^[0-9]*$/;
              if (reg.test(value)) {
                this.formData[iptNumName] = parseInt(value)

                if (iptNumName == 'search_days') {
                  if (parseInt(value) > 3) {
                    callback(new Error('只能输入0-3数字'))
                  } else {
                    callback()
                  }
                }
                // 检查条数
                if (iptNumName == 'max_return') {
                  if (parseInt(value) > 10000) {
                    callback(new Error('只能输入0-10000数字'))
                  } else {
                    callback()
                  }
                }
              } else {
                callback(new Error('请输入数字'))
              }
            }
          }
        }


        let formRules = {
          host_name: [
            {
              trigger: 'blur',
              validator: urlValidator('host_name'),
            },
          ],
          scp_port: [
            {
              trigger: 'blur',
              validator: portValidator,
            },
          ],
          log_save_path:[
            {
              required: true,
              trigger: 'blur',
              validator: pathValidator('logPath'),
            },
          ],
          log_save_days:[
            {
              required: true,
              trigger: 'blur',
              validator: iptNumValidator('log_save_days'),
            },
          ],
          cache_path:[
            {
              required: true,
              trigger: 'blur',
              validator: pathValidator('storagePath'),
            },
          ],
          search_days  :[
            {
              required: true,
              trigger: 'blur',
              validator: inspectRangeNumValidator('search_days'),
            },
          ],
          max_return  :[
            {
              required: true,
              trigger: 'blur',
              validator: inspectRangeNumValidator('max_return'),
            },
          ],
          paddle_ocrurl:[
            {
              required: true,
              trigger: 'blur',
              validator: urlValidator('paddle_ocrurl'),
            },
          ],
          def_resolution:[
            {
              required: true,
              trigger: 'blur',
              validator: iptNumValidator('def_resolution'),
            },
          ],
        }
        return formRules
      },
    },
    watch: {},
    methods: {
      // 获取备份设备
      async getDevices() {
        this.deviceObj = {}
        let res = await this.$pacsApi.pacsApi.getPrefetchDevices()
        if (res.code != 0) {
          this.$message.error(res.data)
          return
        }
        this.devicesList = res.data.filter((item) => {
          if (item.device_type == 0) {
            return item.local_is_stopped == 0
          } else if ([1, 3].includes(item.device_type)) {
            return item.oos_is_stopped == 0
          } else if (item.device_type == 4) {
            return item.dicom_is_stopped == 0
          }
        })
      },
      // 取消保存
      cancelSave () {

      },
      // 开始保存
      submitEvent() {
        this.$refs.strategyForm.validate((valid) => {
          if (!valid) {
            return false
          }
          this.savePrintBasicParams()
        })
      },
      // 保存打印参数的基本配置
      async savePrintBasicParams() {
        let res = await this.$pacsApi.pacsApi.savePrintParams(this.formData)
        if (res.code != 0) {
          this.$message.error(res.msg)
          return
        }
        this.$message.success('保存成功')
      },
      // 获取打印参数基本配置
      async getPrintBasicParams() {
        let res = await this.$pacsApi.pacsApi.getPrintParams()
        if (res.code != 0) {
          this.$message.error(res.msg)
          return
        }
        const result = res.data
        for (let key in this.formData) {
          this.formData[key] = result[key]
        }
      },
      async initData() {
        await this.getDevices()
        this.getPrintBasicParams()
      }
    },
    mounted() {
      this.initData()
    },
  }
  </script>
  <style lang="less" scoped>
  .printParamForm{
    // max-width: 1140px;
    ::v-deep .el-form-item__content{
      line-height: 32px;
    }
  }
  .alert_button {
    .el-button {
      padding: 9px 0px;
    }
  }
  .warningDiv {
    color: rgba(239, 137, 0, 1);
    ::v-deep .iconfont {
      line-height: 20px;
    }
  }
  .flex{
    display: flex;
    align-items: center;
  }
  .bb_dashed {
    border-bottom: 1px dashed #dcdfe6;
  }
  .w240 {
    width: 240px;
  }
  .w200{
    width:200px;
  }
  .w180 {
    width: 180px;
  }
  .w94 {
    width: 94px;
  }
  .ml100{
    margin-left:100px;
  }
  .ml40{
    margin-left:40px; 
  }
  .mr58 {
    margin-right: 58px;
  }
  ::v-deep .el-form-item__label {
    padding: 0;
    line-height: 32px;
    height: 32px;
  }
  .paramItemTit{
    font-weight: 600;
    font-size: 14px;
    color: #303133;
    width: 56px;
    text-align: left;
  }
  ::v-deep .el-form-item__error {
    padding-top: 0;
    margin-top: -2px;
  }
  .treatmentCheckbox{
    margin-right: 5px!important;
  }
  .checkboxGroup{
    display: inline-block;
  }
  .savePathBox{
    position: relative;
    left:-60px;
  }
  .perfetchTaskWay{
    position: relative;
    left:-30px;
  }
  .flex_row{
    display: flex!important;
  }
  .paramsItem{
    position: relative;
    .clr_orange{
      position: absolute;
      left:700px;
    }
    .moreText{
      line-height: 20px;
      top: 10px;
    }
    .moreLineText{
      line-height: 20px;
      top:15px;
    }
    .specailTip{
      top:35px;
    }
    .phoneStatusTip{
      line-height: 20px;
      top: 20px;
    }
  }
  .moreTipCon{
    padding: 20px 0px;
  }
  .pl96{
    padding-left:96px;
  }
  @media screen and (max-width: 1600px) {
    .phoneStatusTip{
      top: 12px!important;
    }
    .moreTipCon{
      padding:30px 0px!important;
    }
    .moreLineText{
      top:5px!important;
    }
  }
  @media screen and (max-width: 1510px) {
    .specailTip{
      top:15px!important;
    }
  }
  @media screen and (max-width: 1380px) {
    .moreTipCon{
      padding:40px 0px!important;
    }
  }

  // @media screen and (min-width: 1550px) and (max-width: 1600px){
  //   .moreLineText{
  //     top:25px!important;
  //   }
  // }
  </style>
  