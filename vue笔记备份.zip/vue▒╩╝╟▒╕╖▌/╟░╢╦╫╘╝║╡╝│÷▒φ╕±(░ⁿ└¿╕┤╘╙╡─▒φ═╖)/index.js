import * as excel from './excel'

export default {
  excel
}
