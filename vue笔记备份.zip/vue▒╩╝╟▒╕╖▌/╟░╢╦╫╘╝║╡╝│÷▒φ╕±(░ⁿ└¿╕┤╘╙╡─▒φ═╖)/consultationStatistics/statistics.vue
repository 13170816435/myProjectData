<template>
  <div class="statistics-layout">
    <title-bar @on-click="exportExcel">
      <div class="statistics-title-bar">
        <i class="iconfont icondingwei mr10"></i>数据统计
        <i class="iconfont iconzhankaishouqi"></i> 会诊统计
        <tab v-model="active" :tabList="tabList"></tab>
      </div>
    </title-bar>
    <component :is="active" :ref="active"></component>
  </div>
</template>

<script>
import TitleBar from './components/title-bar'
import Tab from './components/tab'
import ApplyNum from './pages/apply-num'
import WorkNum from './pages/work-num'
import {tabList} from './utils'


export default {
  name: "statistics",

  data() {
    return {
      tabList,
      active: tabList[0].value,
    }
  },
  methods: {
    // 导出
    exportExcel () {
      this.$refs[this.active].exportEvent()
    }
  },
  components: {
    TitleBar,
    Tab,
    ApplyNum,
    WorkNum
  }
}

</script>

<style lang='less' src="./index.less">

</style>
