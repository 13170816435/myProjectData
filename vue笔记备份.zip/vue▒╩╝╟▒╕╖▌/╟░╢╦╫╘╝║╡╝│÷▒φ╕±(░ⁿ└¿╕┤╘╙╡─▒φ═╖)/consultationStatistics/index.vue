<template>
<!--  <div class="wrapper" :class="{ closeBar: opened }">
    <m-header @changeUserState="changeUserState"></m-header>
    <div class="wrap_content">
      <silder-bar></silder-bar>
      <div class="main">
        <statistics></statistics>
      </div>
    </div>
  </div>-->
  <statistics></statistics>
</template>
<script>
import Statistics from './statistics'
export default {
  components: {
    Statistics
  }
}
</script>
<style lang="less">
</style>
