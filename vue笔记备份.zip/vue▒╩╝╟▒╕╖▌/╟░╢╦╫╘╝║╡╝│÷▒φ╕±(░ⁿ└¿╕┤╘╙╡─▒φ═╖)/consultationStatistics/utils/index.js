import {EwDate} from '@/views/ServiceCenterManagement/dataStatic/serviceCenterReport/utils'

export const tabList = [
  {
    label: '会诊申请量',
    value: 'applyNum'
  },
  {
    label: '会诊工作量',
    value: 'workNum'
  }
]


export const ApplyNumViewType = {
  Table: 1,   // 表格
  Chart: 2,   // 图表
  Detail: 3,  // 详情
  HospitalTable: 4,   // 科室管理表格
  HospitalChart: 5,   //  科室管理图表
  HospitalDetailTable: 6    // 科室管理详情列表
}

export const DetailMode = {
  Apply: 1,
  Reject: 2
}


export const applyTypeList = [
  {
    value: 6,
    label: '近7天'
  },
  {
    value: 14,
    label: '近15天'
  },
  {
    value: 29,
    label: '近30天'
  },
  {
    value: -1,
    label: '自定义'
  }
]


export const applyTabList = [
  {
    label: '报表',
    value: 1,
  }, {
    label: '图表',
    value: 2
  }
]

export const applyHospitalTabList = [
  {
    label: '报表',
    value: 4,
  },
  {
    label: '图表',
    value: 5
  }
]


/**
 * 序列化近几天
 * @param day
 * @returns {[*,*]}
 */
export const serializeTime = day => {
  const end = new Date()
  const start = new Date()
  start.setTime(start.getTime() - 3600 * 1000 * 24 * day)
  return [
    new EwDate(start).default(),
    new EwDate(end).default()
  ]
}


export const serializeTimeType = (date, timeList) => {
  const [start, end] = date
  const now = new EwDate(new Date()).default()
  if (now !== end) {
    return -1
  }

  const startDate = new Date(start)
  const endDate = new Date(end)

  const dis = (endDate - startDate) / (24 * 60 * 60 * 1000)

  const val = timeList.find(item => item.value === dis && dis !== -1)
  if (val) {
    return dis
  }
  return -1
}

export const serialDataSource = dataSource => {
  const _dataSource = dataSource.map(item => {
    const propItem = item.details.reduce((pre, currentItem) => {

      pre[`${currentItem.consult_kind_code}_quantity`] = currentItem.quantity
      pre[`${currentItem.consult_kind_code}_percent`] = `${currentItem.percent}%`
      pre[`${currentItem.consult_kind_code}_reject_quantity`] = currentItem.reject_quantity

      return pre
    }, {})

    return {
      ...item,
      ...propItem
    }
  })

  const list = []
  for (let item of _dataSource) {
    const i = _dataSource.indexOf(item)
    const index = list.findIndex(listItem => listItem.consult_center_id === item.consult_center_id)
    if (index === -1) {
      list.push({
        ...item,
        __id: `${item.consult_center_id}_${i}`,
        __regional_nature_code_desc: `${item.regional_nature_code_desc}医院`,
        __open: true,
        children: [],
      })
    } else {
      list[index]['children'].push({
        ...item,
        __parent: true,
        __open: true,
        __id: `${item.consult_center_id}_${i}`,
        __regional_nature_code_desc: `${item.regional_nature_code_desc}医院`
      })
    }
  }

  return list
}


const serialDataSource1 = dataSource => {
  const _dataSource = dataSource.map(item => {
    const propItem = item.details.reduce((pre, currentItem) => {

      pre[`${currentItem.consult_kind_code}_quantity`] = currentItem.quantity
      pre[`${currentItem.consult_kind_code}_percent`] = `${currentItem.percent}%`
      pre[`${currentItem.consult_kind_code}_reject_quantity`] = currentItem.reject_quantity

      return pre
    }, {})

    return {
      ...item,
      ...propItem
    }
  })

  const list = []
  for (let item of _dataSource) {
    const i = _dataSource.indexOf(item)
    const index = list.findIndex(listItem => listItem.consult_center_id === item.consult_center_id)
    if (index === -1) {
      list.push({
        ...item,
        request_org_name: '',
        __id: `${item.consult_center_id}_${i}`,
        __regional_nature_code_desc: `合计`,
        __open: true,
        __isTotal: true,
        children: [{
          ...item,
          __id: `${item.consult_center_id}_${i}_${i}`,
          __regional_nature_code_desc: `${item.regional_nature_code_desc}医院`,
          __parent: true,
          __open: true,
        }],
      })
    } else {
      list[index]['children'].push({
        ...item,
        __parent: true,
        __open: true,
        __id: `${item.consult_center_id}_${i}`,
        __regional_nature_code_desc: `${item.regional_nature_code_desc}医院`
      })
    }
  }

  return list
}

export const serializeTableDataSource = dataSource => {

  const typeList = dataSource.flatMap(item => item.details)

  const totalItem = typeList.reduce((pre, item) => {
    const quantityKey = `${item.consult_kind_code}_quantity`
    if (pre[quantityKey]) {
      pre[quantityKey] = pre[quantityKey] + Number(item['quantity'])
    } else {
      pre[quantityKey] = Number(item['quantity'])
    }

    const percentKey = `${item.consult_kind_code}_percent`
    if (pre[percentKey]) {
      pre[percentKey] = pre[percentKey] + Number(item['percent'])
    } else {
      pre[percentKey] = Number(item['percent'])
    }

    const rejectKey = `${item.consult_kind_code}_reject_quantity`
    if (pre[rejectKey]) {
      pre[rejectKey] = pre[rejectKey] + Number(item['reject_quantity'])
    } else {
      pre[rejectKey] = Number(item['reject_quantity'])
    }

    return pre
  }, {consult_center_name: '总计', isTotal: true})

  const list = serialDataSource1(dataSource)

  // 合计
  return [
    /*totalItem,*/
    ...list
  ]
}

export const serializeHeaders = dataSource => {
  const list = []
  const typeList = dataSource.flatMap(item => item.details)
  for (let item of typeList) {
    const isExist = list.find(listItem => listItem.consult_kind_name === item.consult_kind_name)
    if (!isExist) {
      list.push({
        ...item,
        __consult_kind_name: `${item.consult_kind_name}会诊`
      })
    }
  }
  return list
}

export const serializeTableHeaders = dataSource => {
  const list = serializeHeaders(dataSource)

  return list.map(item => {
    return {
      ...item,
      label: item.__consult_kind_name,
      applyProp: `${item.consult_kind_code}_quantity`,
      percentProp: `${item.consult_kind_code}_percent`,
      rejectProp: `${item.consult_kind_code}_reject_quantity`
    }
  })
}


export const serializeColumnView = ({row, column: {property}}) => row[property] !== undefined ? row[property] : 0


export const serializeChartDataSource = dataSource => {
  const _dataSource = dataSource.map(item => {
    return item.details.map(detailItem => ({
      ...detailItem,
      statistics_date: item.statistics_date
    }))
  })

  const __dataSource = _dataSource.flatMap(item => {
    return item
  })

  // 聚合服务中心
  const ___dataSource = []
  for (const item of __dataSource) {
    let listItem = ___dataSource.find(listItem => listItem.consult_center_id === item.consult_center_id)
    if (listItem === undefined) {
      listItem = {
        consult_center_id: item.consult_center_id,
        consult_center_name: item.consult_center_name,
        typeList: []
      }
      ___dataSource.push(listItem)
    }
    listItem.typeList.push({
      ...item
    })
  }

  // 聚合日期

  return ___dataSource.map(item => {
    const typeList = []
    for (const typeListItem of item.typeList) {
      let subTypeListItem = typeList.find(_typeListItem => _typeListItem.consult_kind_name === typeListItem.consult_kind_name)

      if (subTypeListItem === undefined) {
        subTypeListItem = {
          consult_kind_name: typeListItem.consult_kind_name,
          data: []
        }
        typeList.push(subTypeListItem)
      }
      subTypeListItem.data.push({
        ...typeListItem
      })
    }

    return {
      ...item,
      typeList
    }
  })
}


export const serializeHospitalChartData = dataSource => {
  return dataSource.map(item => {
    const subItem = item.details && item.details.length > 0 ? item.details[0] : {}
    return {
      ...item,
      ...subItem,
      name: subItem.consult_kind_name,
      value: subItem.quantity,
    }
  })
}


export const serializeDetailDataSource = dataSource => {
  return dataSource.map(item => {

    const sexMap = new Map([
      [0, '未知'],
      [1, '男'],
      [2, '女']
    ])

    return {
      ...item,
      __sex: sexMap.get(item.patient_sex)
    }
  })
}


/**
 * 是否是数组
 * @param val
 * @returns {boolean}
 */
const isArray = val => Object.prototype.toString.call(val).includes('Array')

/**
 * 转num
 * @param val
 * @returns {number|number|number}
 */
const toNum = val => {
  try {
    const _val = Number(val)
    return isNaN(_val) ? 0 : _val
  } catch (e) {
    return 0
  }
}

/**
 * 数据适配器
 * @param dataSource
 * @returns {*}
 */
const dataSourceAdapter = dataSource => {
  return dataSource.map(item => {
    if (isArray(item.details)) {
      item.children = dataSourceAdapter(item.details)
    }
    const {details, ...obj} = item
    return {
      ...obj
    }
  })
}

/**
 * 数据转百分比，且保留两位小数过滤器
 * @param val
 * @returns {string}
 */
export const percentFilter = val => {
  if (val === 0) {
    return `0%`
  }
  try {
    const _val = Math.round(val * 100)
    return `${_val / 100}%`
  } catch (e) {
    return '0%'
  }
}

/**
 * 序列化表头
 * @param dataSource
 * @returns {(*&{percentProp: string, applyProp: string, label: string, rejectProp: string})[]}
 */
export const serializeTableHeadersNew = dataSource => {
  const _dataSource = isArray(dataSource.consult_kind_details) ? dataSource.consult_kind_details : []

  return _dataSource.map(item => ({
    ...item,
    label: `${item.consult_kind_name}会诊`,
    applyProp: `${item.consult_kind_code}_quantity`,
    percentProp: `${item.consult_kind_code}_percent`,
    rejectProp: `${item.consult_kind_code}_reject_quantity`
  }))
}

/**
 * 序列化表格数据
 * @param dataSource
 * @returns {*[]}
 */
export const serializeTableDataSourceNew = dataSource => {
  if (dataSource.details && dataSource.details.length === 0) {
    return []
  }

  /**
   * 适配数据
   */
  const _dataSource = dataSourceAdapter(dataSource.details)

  const totalObj = {
    consult_center_name: '总计',
    org_quantity: dataSource.total_request_quantity,
    org_reject_quantity: dataSource.total_reject_quantity,
    __id: 1,
    __isAllTotal: true
  }

  const totalKeyList = []

  /**
   * 处理数据
   * **/
  const __dataSource = _dataSource.map((item, index) => {
      const itemId = `${item.consult_center_id}_${index}`

      const centerObj = {
        ...item,
        __regional_nature_code_desc: '合计',
        org_quantity: toNum(item.center_quantity),
        org_reject_quantity: toNum(item.center_reject_quantity),
        __id: itemId,
        __isCenterSummary: true,
        __isServiceCenter: true,
        children: [],
        __itemCount: 1,
        __open: true,
        regional_nature_code_desc: '合计'
      }

      const keyList = []
      centerObj.children = item.children.map((areaItem, areaIndex) => {
        const areaId = `${itemId}_${areaItem.regional_nature_code}_${areaIndex}`

        centerObj.__itemCount += 1

        const areaObj = {
          ...areaItem,
          __regional_nature_code_desc: `${areaItem.regional_nature_code_desc}医院`,
          request_org_name: '小计',
          org_quantity: toNum(areaItem.regional_quantity),
          org_reject_quantity: toNum(areaItem.regional_reject_quantity),
          __id: areaId,
          consult_center_id: item.consult_center_id,
          consult_center_name: item.consult_center_name,
          regional_nature_code_desc: areaItem.regional_nature_code_desc,
          __isSummary: true,
          __isArea: true,
          __isServiceCenter: false,
          children: []
        }


        areaObj.children = areaItem.children.map((hosItem, hosIndex) => {
          centerObj.__itemCount += 1

          const hosId = `${areaId}_${hosItem.request_org_id}_${hosIndex}`
          const {children, ...hosItemObj} = hosItem

          const conObj = hosItem.children.reduce((obj, listItem) => {
            const quantityKey = `${listItem.consult_kind_code}_quantity`
            const percentKey = `${listItem.consult_kind_code}_percent`
            const rejectKey = `${listItem.consult_kind_code}_reject_quantity`

            const quantityNum = toNum(listItem.quantity)
            const percentNum = toNum(listItem.percent)
            const rejectNum = toNum(listItem.reject_quantity)

            obj[quantityKey] = quantityNum
            obj[percentKey] = percentNum
            obj[rejectKey] = rejectNum

            if (areaObj.hasOwnProperty(quantityKey)) {
              areaObj[quantityKey] += quantityNum
            } else {
              areaObj[quantityKey] = quantityNum
            }

            if (!areaObj.hasOwnProperty(percentKey)) {
              areaObj[percentKey] = (quantityNum / areaItem.regional_quantity * 100)
            }

            if (areaObj.hasOwnProperty(rejectKey)) {
              areaObj[rejectKey] += rejectNum
            } else {
              areaObj[rejectKey] = rejectNum
            }

            if (centerObj.hasOwnProperty(quantityKey)) {
              centerObj[quantityKey] += quantityNum
            } else {
              keyList.push({
                quantityKey,
                percentKey
              })
              centerObj[quantityKey] = quantityNum
            }

            if (centerObj.hasOwnProperty(rejectKey)) {
              centerObj[rejectKey] += rejectNum
            } else {
              centerObj[rejectKey] = rejectNum
            }

            if (totalObj.hasOwnProperty(quantityKey)) {
              totalObj[quantityKey] += quantityNum
            } else {
              totalKeyList.push({
                quantityKey,
                percentKey
              })
              totalObj[quantityKey] = quantityNum
            }

            if (totalObj.hasOwnProperty(rejectKey)) {
              totalObj[rejectKey] += rejectNum
            } else {
              totalObj[rejectKey] = rejectNum
            }

            return obj
          }, {})


          return {
            ...hosItemObj,
            __id: hosId,
            ...conObj,
            consult_center_id: item.consult_center_id,
            consult_center_name: item.consult_center_name,
            regional_nature_code_desc: areaItem.regional_nature_code_desc,
            __isAreaChild: true,
            __isServiceCenter: false,
          }
        })

        return areaObj
      })


      for (const keyItem of keyList) {
        centerObj[keyItem['percentKey']] = centerObj[keyItem['quantityKey']] / item.center_quantity * 100
      }

      return centerObj
    }
  )

  for (let totalKeyItem of totalKeyList) {
    totalObj[totalKeyItem['percentKey']] = totalObj[totalKeyItem['quantityKey']] / totalObj['org_quantity'] * 100
  }

  return [
    totalObj,
    ...__dataSource
  ]
}


/**
 * 合并所有的单元格
 * @param row
 * @param _
 * @param rowIndex
 * @param columnIndex
 * @returns {{colspan: number, rowspan: *}|{colspan: number, rowspan: (number|*)}|{colspan: number, rowspan: number}}
 */
export const mergeSpan = ({row, _, rowIndex, columnIndex}) => {
  if (rowIndex === 0 && columnIndex === 0) {
    return {
      rowspan: 1,
      colspan: 3
    }
  }
  if (rowIndex === 0 && [1, 2].includes(columnIndex)) {
    return {
      rowspan: 0,
      colspan: 0
    }
  }

  /** 处理合计 */
  if (columnIndex === 1 && row.__isCenterSummary) {
    return {
      rowspan: 1,
      colspan: 2
    }
  }

  if (columnIndex === 2 && row.__isCenterSummary) {
    return {
      rowspan: 0,
      colspan: 0
    }
  }

  /** 处理区域 */
  if (columnIndex === 1 && row.__isArea) {
    return {
      rowspan: row.children.length + 1,
      colspan: 1
    }
  }

  if (columnIndex === 1 && row.__isAreaChild) {
    return {
      rowspan: 0,
      colspan: 0
    }
  }

  /** 处理服务中心 */
  if (columnIndex === 0 && rowIndex > 0) {
    if (row.__open) {
      if (row.__isServiceCenter === true) {
        return {
          rowspan: row.__itemCount,
          colspan: 1
        }
      }

      if (row.__isServiceCenter === false) {
        return {
          rowspan: 0,
          colspan: 0
        }
      }
    } else {
      if (row.__isServiceCenter === false) {
        return {
          rowspan: 0,
          colspan: 0
        }
      }
    }
  }
  // if (columnIndex === 0 && row.__isServiceCenter === true) {
  //   return {
  //     rowspan: row.__itemCount,
  //     colspan: 1
  //   }
  // }
  //
  // if (columnIndex === 0 && row.__isServiceCenter === false) {
  //   return {
  //     rowspan: 0,
  //     colspan: 0
  //   }
  // }
}


export const serializeAllIds = (children, idList = []) => {
  for (let item of children) {
    if (item.children) {
      serializeAllIds(item.children, idList)
    }
    if (item.request_org_id) {
      idList.push(item.request_org_id)
    }
  }
  return idList
}


export const serializeWorkHeaders = dataSource => {
  const _dataSource = dataSource.flatMap(item => item.details)
  const __dataSource = _dataSource.reduce((list, item) => {
    const _item = list.find(__item => __item.consult_kind_code === item.consult_kind_code)
    if (_item === undefined) {
      list.push(item)
    }
    return list
  }, [])

  return __dataSource.map(item => {
    return {
      ...item,
      label: `${item.consult_kind_name}会诊`
    }
  })
}


export const serializeWorkChartTotalDataSource = dataSource => {
  return dataSource.map(item => {
    return {
      ...item,
      name: item.consult_center_name,
      value: item.quantity
    }
  })
}


export const serializeWorkChartList = dataSource => {
  const _dataSource = dataSource.map(item => {
    return {
      ...item,
      details: item.details.map(item2 => {
        return {
          ...item2,
          details: item2.details.map(item3 => {
            return {
              ...item3,
              statistics_date: item2.statistics_date
            }
          })
        }
      })
    }
  })

  const __dataSource = _dataSource.map(item => {
    const list = item.details.flatMap(item2 => item2.details)
    return {
      ...item,
      dataList: [...list]
    }
  })


  return __dataSource.map(item => {
    const __dataList = item.dataList.reduce((typeList, currentItem) => {
      const index = typeList.findIndex(item3 => item3.consult_kind_code === currentItem.consult_kind_code)
      if (index !== -1) {
        typeList[index].data.push({
          ...currentItem
        })
      } else {
        typeList.push({
          consult_kind_code: currentItem.consult_kind_code,
          consult_kind_name: currentItem.consult_kind_name,
          data: [{
            ...currentItem
          }]
        })
      }
      return typeList
    }, [])

    return {
      ...item,
      dataList: __dataList
    }
  })
}


export const serializeWorkDataSource = dataSource => {
  let total = 0

  dataSource.forEach(center => {
    // 添加服务中心合计行
    center.__id = center.consult_center_id
    center.consult_kind_name = '合计'
    center.consult_kind_percent = '100.0'
    center.consult_kind_quantity = center.center_quantity
    center.centerRowspan = 1
    center.__isServiceCenter = true
    center.__open = true
    center.details.map((item, index) => {
      item.__id = `${center.consult_center_id}-${item.consult_kind_code || 'consult_kind_code'}-${index}`
      item.consult_center_id = center.consult_center_id
      item.consult_center_name = center.consult_center_name
      item.detailRowspan = 1
      item.isChild = true
      item.__isServiceCenter = false
      if (item.details && item.details.length) {
        // 因为存在空白行，所以将详情第一个数据，赋值上来
        item.user_name = item.details[0].user_name
        item.user_id = item.details[0].user_id
        item.quantity = item.details[0].quantity
        item.details.map((d, di) => {
          if (di > 0) {
            d.__id = `${item.__id}-${d.user_id}-${di}`
            d.consult_center_id = center.consult_center_id
            d.consult_center_name = center.consult_center_name
            d.isChild = true
            d.__isServiceCenter = false
            d.consult_kind_code = item.consult_kind_code
          }
        })
        // 去掉详情第一条数据
        item.details.splice(0, 1)
        item.detailRowspan += item.details.length
      }
      center.centerRowspan += item.detailRowspan
    })
    // 总计
    total += center.center_quantity
  })

  if (dataSource.length > 0) {
    dataSource.unshift({
      __id: 'total',
      consult_center_name: '总计',
      consult_kind_quantity: total
    })
  }

  return dataSource
}


export const conObj = {
  '121': 'RIS',
  '122': 'UIS',
  '123': 'ECGIS',
  '124': 'PIS',
  '125': 'CIS',
  '126': 'MDT',
  '127': 'EIS',
  '128': 'Referral'
}


export const serializeHospitalDataSource = dataSource => {
  const totalItem = {
    request_office_name: '总计',
    __isTotal: true
  }
  const list = dataSource.map(item => {
    const conObj = item.details.reduce((obj, conItem) => {
      const quantityKey = `${conItem.consult_kind_code}_quantity`
      const rejectKey = `${conItem.consult_kind_code}_reject_quantity`
      const quantityNum = conItem.quantity
      const rejectNum = conItem.reject_quantity

      obj[quantityKey] = quantityNum
      obj[rejectKey] = rejectNum

      if (totalItem[quantityKey]) {
        totalItem[quantityKey] += quantityNum
      } else {
        totalItem[quantityKey] = quantityNum
      }

      if (totalItem[rejectKey]) {
        totalItem[rejectKey] += rejectNum
      } else {
        totalItem[rejectKey] = rejectNum
      }

      return obj
    }, {})

    return {
      ...item,
      ...conObj
    }
  })

  if (list.length > 0) {
    list.unshift(totalItem)
  }

  return list
}


const serializeDateByDate = dateList => {
  if (!isArray(dateList) || dateList.length === 0) {
    return []
  }

  let [startDate, endDate] = dateList
  const _dateList = []
  _dateList.push(startDate)

  while (new Date(startDate) < new Date(endDate)) {
    const _startDate = new Date(startDate)
    _startDate.setDate(_startDate.getDate() + 1)
    startDate = new EwDate(_startDate).default()
    _dateList.push(startDate)
  }

  return _dateList
}

const serializeDateByMonth = dateList => {
  if (!isArray(dateList) || dateList.length === 0) {
    return []
  }

  let [startDate, endDate] = dateList
  const _dateList = []
  while (new Date(startDate) < new Date(endDate)) {
    _dateList.push(new EwDate(startDate).format('YYYY-MM'))
    const _startDate = new Date(startDate)
    _startDate.setMonth(_startDate.getMonth() + 1)
    startDate = new EwDate(_startDate).default()
  }

  return _dateList
}

export const serializeDateByType = (dateList, type) => {
  if (type === 1) {
    return serializeDateByDate(dateList)
  }
  return serializeDateByMonth(dateList)
}
