<template>
  <div class="tableBox" :class="isEmpty && 'noTableData'" v-loading="loading" element-loading-text="拼命加载中"
       element-loading-background="rgba(255,255,255,0.6)">
    <slot></slot>
  </div>
</template>

<script>

export default {
  name: "table-layout",

  props: {
    isEmpty: {
      type: Boolean,
      default: true
    },

    loading: {
      type: Boolean,
      default: false
    }
  }
}

</script>
