<template>
  <div>
    <div class="title-bar flex_row">
      <div class="tl col org-title-bar">
        <span class="title-name clr_303 mr20">
          <slot></slot>
        </span>
      </div>

      <div class="tr col" v-if="showPrint">
<!--        <span class="function-btn bg_e6 clr_ff mr15" @click="executeCommand('print')">
          <i class="iconfont icondayin pr5"></i>打印
        </span>-->
        <span class="function-btn bg_0a clr_ff" @click="executeCommand('export')">
          <i class="iconfont icondaochu pr5"></i>导出
        </span>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: "title-bar",

  props: {
    showPrint: {
      type: Boolean,
      default: true
    }
  },

  methods: {
    executeCommand(type) {
      this.$emit('on-click', type)
    }
  }
}

</script>
<style>

</style>
