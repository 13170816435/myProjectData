<template>
  <el-date-picker
      :value="date"
      class="range-date-picker"
      type="daterange"
      align="right"
      :style="pickerStyle"
      :disabled="disabled"
      unlink-panels
      range-separator="至"
      start-placeholder="开始日期"
      end-placeholder="结束日期"
      @input="onDateChanged"
      value-format="yyyy-MM-dd">
  </el-date-picker>
</template>

<script>
export default {
  name: 'date-picker-range',

  props: {
    value: {
      type: [String, Date, Array],
      default: ''
    },

    options: {
      type: Object,
      default: () => ({
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 6)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近半个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 14)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      })
    },

    pickerStyle: {
      type: Object,
      default: () => ({
        width: '240px'
      })
    },

    disabled: {
      type: Boolean,
      default: false
    }
  },

  watch: {
    value(val) {
      this.date = val
    }
  },

  data() {
    return {
      date: this.value
    }
  },

  methods: {
    onDateChanged(value) {
      this.$emit('input', value)
    }
  }
}
</script>

<style lang="less">
.statistics-bar {
  .el-date-editor .el-range__close-icon {
    line-height: 24px!important;
  }
}
</style>
