<template>
  <div class="switch-btn-list">
    <span v-for="item of tabList" :key="item.value"
          :class="active === item.value && 'active'" @click="changeActive(item.value)">{{ item.label }}</span>
  </div>
</template>

<script>

export default {
  name: "switch-bar",

  props: {
    value: {
      type: [String, Number],
      default: ''
    },

    tabList: {
      type: Array,
      default: () => []
    }
  },

  data() {
    return {
      active: this.value
    }
  },

  watch: {
    value(val) {
      this.active = val
    }
  },

  methods: {
    changeActive(val) {
      if (val === this.active) {
        return
      }

      this.$emit('input', val)
      this.$emit('change', val)
    }
  }
}

</script>
