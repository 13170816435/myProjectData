<template>
  <div class="statistics-tab">
    <span v-for="item of tabList" :key="item[valueKey]"
          :class="item[valueKey] === value && 'active'"
          @click="changeTab(item)"
    >{{ item[labelKey] }}</span>
  </div>
</template>

<script>

export default {
  name: "tab",

  props: {
    value: {
      type: [String, Number],
      default: ''
    },

    tabList: {
      type: Array,
      default: () => []
    },

    valueKey: {
      type: String,
      default: 'value'
    },

    labelKey: {
      type: String,
      default: 'label'
    }
  },

  methods: {
    changeTab(item) {
      if (this.value === item[this.valueKey]) {
        return
      }
      this.$emit('input', item[this.valueKey])
      this.$emit('change', item[this.valueKey])
    }
  }
}

</script>
