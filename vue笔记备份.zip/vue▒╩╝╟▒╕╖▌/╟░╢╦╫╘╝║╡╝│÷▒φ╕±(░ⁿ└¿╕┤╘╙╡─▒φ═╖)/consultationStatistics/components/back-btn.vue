<template>
  <a href="javascript:" class="con-back-btn" @click="onClick">
    <img src="~@/assets/images/pre.png" alt="返回">
    返回上一级
  </a>
</template>

<script>

export default {
  name: "back-btn",

  methods: {
    onClick() {
      this.$emit('on-click')
    }
  }
}

</script>
<style lang="less">
.con-back-btn {
  display: flex;
  color: #0a70b0;
  align-items: center;

  img {
    width: 16px;
    height: 16px;
    margin-right: 5px;
  }

  &:hover {
    opacity: .8;
    color: #0a70b0;
  }

  &:active {
    opacity: .7;
  }
}
</style>
