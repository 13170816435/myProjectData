<template>
  <div class="statistics-pages" v-loading.fullscreen.lock="isExporting"  element-loading-text="导出中..."
          element-loading-background="rgba(255,255,255,0.6)">
    <div class="search-toolbar">

      <div class="search-bar-line">
        <div class="search-toolbar-item">
          <span class="label">申请时间：</span>
          <el-select
              v-model="applyType"
              placeholder="全部"
              class="w_85"
              @change="onApplyTimeChanged"
              :disabled="isDetailMode"
          >
            <el-option
                v-for="(item, index) of applyTypeList"
                :key="index"
                :label="item.label"
                :value="item.value"
            ></el-option>
          </el-select>
          <date-picker-range :value="applyTime" @input="onTimeChanged" :disabled="isDetailMode"></date-picker-range>
        </div>

        <div class="search-toolbar-item">
          <span class="label">会诊类型：</span>
          <el-select
              multiple
              filterable
              collapse-tags
              clearable
              v-model="consultationType"
              placeholder="全部"
              :disabled="isDetailMode"
              class="width_260_select"
          >
            <el-option
                v-for="item of consultationList"
                :key="item.dic_code"
                :label="item.dic_name"
                :value="item.__dic_name"
            ></el-option>
          </el-select>
        </div>
      </div>

      <div class="search-bar-between">
        <div class="search-bar-line">
          <div class="search-toolbar-item">
            <span class="label">服务中心：</span>
            <el-select
                multiple
                filterable
                collapse-tags
                clearable
                v-model="serviceCenter"
                placeholder="全部"
                class="width_330"
                @change="onServiceCenterChanged"
                :disabled="isDetailMode"
            >
              <el-option
                  v-for="item of serviceCenterList"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
              ></el-option>
            </el-select>
          </div>

          <div class="search-toolbar-item">
            <span class="label">申请医院：</span>
            <el-select
                multiple
                filterable
                collapse-tags
                clearable
                v-model="applyHospital"
                placeholder="全部"
                class="width_260_select"
                :disabled="isDetailMode"
            >
              <el-option
                  v-for="item in applyHospitalList"
                  :key="item.institution_id"
                  :label="item.institution_name"
                  :value="item.institution_id"
              ></el-option>
            </el-select>
          </div>

          <div class="search-toolbar-item">
            <el-button type="primary" size="small" @click="queryList" :disabled="isDetailMode">查询</el-button>
            <el-button size="small" plain @click="resetData" :disabled="isDetailMode">重置</el-button>
          </div>
        </div>

        <div class="switch-bar">
          <el-radio-group
              v-model="filterType"
              class="filter-type-list"
              v-if="viewType === ApplyNumViewType.Chart"
              @change="queryList"
          >
            <el-radio :label="1">按天</el-radio>
            <el-radio :label="2">按月</el-radio>
          </el-radio-group>

          <switch-bar v-model="viewType" :tab-list="applyTabList" @change="changeViewType"
                      v-if="isShowSwitchBar" key="table"></switch-bar>
        </div>
      </div>

    </div>

    <div class="statistics-detail-bar" v-if="isShowToolBar" :class="isTableBar && 'statistics-table-bar'">
      <div class="left">
        <back-btn @on-click="onClickBackBtn"></back-btn>
        <span class="split-line"></span>
        <back-line :list="backStack" @on-click="onBackLineClick"></back-line>
      </div>
      <div class="right">
        <switch-bar v-model="viewType" :tab-list="applyHospitalTabList" @change="changeViewType"
                    v-if="isShowHosSwitchBar" key="hosTable"></switch-bar>
      </div>
    </div>

    <table-layout
        v-if="viewType === ApplyNumViewType.Table"
        class="statistics-main"
        :loading="loading"
        :is-empty="isEmpty"
    >
      <el-table border :data="dataSource" row-key="__id" default-expand-all
                :tree-props="{children: 'children'}"
                :span-method="mergeSpan"
                @expand-change="expandChange"
                ref="tb" height="100%" key="list" class="static-table-layout">
        <el-table-column label="服务中心" prop="consult_center_name" show-overflow-tooltip
                         width="180" align="right" header-align="center" :fixed="!isExporting"></el-table-column>
        <el-table-column label="所属区域" prop="__regional_nature_code_desc" show-overflow-tooltip
                         width="120" align="right" header-align="center" :fixed="!isExporting"></el-table-column>
        <el-table-column label="申请医院" prop="request_org_name" show-overflow-tooltip width="180" align="right"
                         header-align="center"
                         :fixed="!isExporting">
          <template v-slot="{row}">
            <span :class="!row.__isSummary && 'apply-hos-btn'" @click="showHospitalDetail(row)">
              {{ row.request_org_name }}
            </span>
          </template>
        </el-table-column>

        <el-table-column v-for="item of headers" :key="item.label" :label="item.label" align="center">
          <el-table-column label="申请量" :prop="item.applyProp" align="center" show-overflow-tooltip width="150">
            <template v-slot="data">
              <span :class="serializeColumnView(data) > 0 && 'apply-hos-btn'"
                    @click="toDetailsView(serializeColumnView(data), data, DetailMode.Apply, false, item.label)">
                {{ serializeColumnView(data) }}
              </span>
            </template>
          </el-table-column>
          <el-table-column label="申请量占比" :prop="item.percentProp" align="center" show-overflow-tooltip width="150">
            <template v-slot="data">
              {{ serializeColumnView(data) | percentFilter }}
            </template>
          </el-table-column>
          <el-table-column label="驳回量" :prop="item.rejectProp" align="center" show-overflow-tooltip width="150">
            <template v-slot="data">
              <span :class="serializeColumnView(data) > 0 && 'apply-hos-btn'"
                    @click="toDetailsView(serializeColumnView(data), data, DetailMode.Reject, false, item.label)">
                {{ serializeColumnView(data) }}
              </span>
            </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="总计" align="center">
          <el-table-column label="申请量" prop="org_quantity" align="center" min-width="160">
            <template v-slot="data">
              <span v-if="data.row.org_quantity > 0" class="apply-hos-btn"
                    @click="toDetailsView(data.row.org_quantity, data, DetailMode.Apply, true)">
                {{ data.row.org_quantity }}
              </span>
              <template v-else>
                {{ data.row.org_quantity }}
              </template>
            </template>
          </el-table-column>
          <el-table-column label="总驳回量" prop="org_reject_quantity" align="center" min-width="160">
            <template v-slot="data">
              <span
                  v-if="data.row.org_reject_quantity > 0"
                  class="apply-hos-btn"
                  @click="toDetailsView(data.row.org_reject_quantity, data, DetailMode.Reject, true)"
              >
                {{ data.row.org_reject_quantity }}
              </span>
              <template v-else>
                {{ data.row.org_reject_quantity }}
              </template>
            </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </table-layout>

    <table-layout v-if="viewType === ApplyNumViewType.Chart" class="statistics-main statistics-chart"
                  :is-empty="isChartEmpty" :loading="loadingChart">
      <div class="chart-list" ref="chartContainer">
        <div class="chart-item"
             v-for="item of chartDataSource"
             :key="item.consult_center_id"
             :class="chartDataSource.length === 1 && 'chart-item-single'"
        >
          <div class="title">
            {{ item.consult_center_name }}
          </div>
          <div class="chart-main">
          </div>
        </div>
      </div>
    </table-layout>

    <table-layout v-if="viewType === ApplyNumViewType.Detail" class="statistics-main" :is-empty="isDetailEmpty"
                  :loading="loadingDetail">
      <el-table border stripe :data="detailDataSource" height="100%" key="detail" ref="details">
        <el-table-column type="index" width="50" label="序号"></el-table-column>
        <el-table-column prop="patient_name" label="患者姓名" show-overflow-tooltip width="100"></el-table-column>
        <el-table-column prop="__sex" label="性别" show-overflow-tooltip width="80"></el-table-column>
        <el-table-column prop="age_detail" label="年龄" show-overflow-tooltip width="80"></el-table-column>
        <template v-if="detailType === DetailMode.Apply">
          <el-table-column prop="consult_expert_name" label="会诊医生" show-overflow-tooltip
                           width="100"></el-table-column>
          <el-table-column prop="consult_date" label="会诊时间" show-overflow-tooltip width="180"></el-table-column>
        </template>
        <template v-if="detailType === DetailMode.Reject">
          <el-table-column prop="audit_user_name" label="审核医生" show-overflow-tooltip width="100"></el-table-column>
          <el-table-column prop="reason" label="驳回原因" show-overflow-tooltip width="180"></el-table-column>
        </template>

        <el-table-column prop="purpose" label="会诊目的" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_kind_name" label="会诊类型" show-overflow-tooltip width="120"></el-table-column>
        <el-table-column prop="consult_class_name" label="会诊方式" show-overflow-tooltip width="120"></el-table-column>
        <el-table-column prop="request_org_name" label="申请医院" show-overflow-tooltip width="180"></el-table-column>
        <el-table-column prop="request_user_name" label="申请医生" show-overflow-tooltip width="100"></el-table-column>
        <el-table-column prop="request_date" label="申请时间" show-overflow-tooltip width="180"></el-table-column>
      </el-table>

       <!---用来导出会诊申请量详情(明细)所有数据用的表格--->
      <el-table v-show="showAllDetailTableData" border stripe :data="allDetailDataSource" height="100%" key="detailAllTable" ref="detailAllTable">
        <el-table-column type="index" width="50" label="序号"></el-table-column>
        <el-table-column prop="patient_name" label="患者姓名" show-overflow-tooltip width="100"></el-table-column>
        <el-table-column prop="__sex" label="性别" show-overflow-tooltip width="80"></el-table-column>
        <el-table-column prop="age_detail" label="年龄" show-overflow-tooltip width="80"></el-table-column>
        <template v-if="detailType === DetailMode.Apply">
          <el-table-column prop="consult_expert_name" label="会诊医生" show-overflow-tooltip
                           width="100"></el-table-column>
          <el-table-column prop="consult_date" label="会诊时间" show-overflow-tooltip width="180"></el-table-column>
        </template>
        <template v-if="detailType === DetailMode.Reject">
          <el-table-column prop="audit_user_name" label="审核医生" show-overflow-tooltip width="100"></el-table-column>
          <el-table-column prop="reason" label="驳回原因" show-overflow-tooltip width="180"></el-table-column>
        </template>

        <el-table-column prop="purpose" label="会诊目的" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_kind_name" label="会诊类型" show-overflow-tooltip width="120"></el-table-column>
        <el-table-column prop="consult_class_name" label="会诊方式" show-overflow-tooltip width="120"></el-table-column>
        <el-table-column prop="request_org_name" label="申请医院" show-overflow-tooltip width="180"></el-table-column>
        <el-table-column prop="request_user_name" label="申请医生" show-overflow-tooltip width="100"></el-table-column>
        <el-table-column prop="request_date" label="申请时间" show-overflow-tooltip width="180"></el-table-column>
      </el-table>
    </table-layout>


    <table-layout
        class="statistics-main"
        :loading="loadingHospital"
        :is-empty="isHospitalEmpty"
        v-if="viewType === ApplyNumViewType.HospitalTable"
    >
      <el-table border stripe :data="hospitalDataSource" height="100%" ref="hosTb" key="hos">
        <el-table-column prop="request_office_name" label="申请科室" :fixed="!isExporting"></el-table-column>
        <el-table-column label="申请科室" align="center" v-for="item of hospitalHeaders" :key="item.label"
                         :label="item.label">
          <el-table-column label="申请量" :prop="item.applyProp" align="center">
            <template v-slot="data">
              <span :class="serializeColumnView(data) > 0 && 'apply-hos-btn'"
                    @click="toHosDetailView(serializeColumnView(data), data, DetailMode.Apply)">
                {{ serializeColumnView(data) }}
              </span>
            </template>
          </el-table-column>
          <el-table-column label="驳回量" :prop="item.rejectProp" align="center">
            <template v-slot="data">
              <span :class="serializeColumnView(data) > 0 && 'apply-hos-btn'"
                    @click="toHosDetailView(serializeColumnView(data), data, DetailMode.Reject)">
                {{ serializeColumnView(data) }}
              </span>
            </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </table-layout>


    <template v-if="viewType === ApplyNumViewType.HospitalChart">
      <div class="hos-tab-wrapper">
        <span class="label"></span>
        <p class="hos-title">机构科室申请量排行</p>
        <tab
            v-model='currentConsultKindCode'
            :tab-list="hospitalHeaders"
            value-key="consult_kind_code"
            @change="changeHosTab"
        ></tab>
      </div>
      <table-layout
          class="statistics-main"
          :loading="loadingHospitalChart"
          :is-empty="isHospitalChartEmpty"
      >
        <div class="hospital-chart-container">
          <div class="hospital-chart-box">
            <div class="chart" ref="hosChart">
            </div>
          </div>
        </div>
      </table-layout>
    </template>


    <table-layout
        v-if="viewType === ApplyNumViewType.HospitalDetailTable"
        class="statistics-main"
        :loading="loadingHospitalDetailList"
        :is-empty="isHospitalDetailListEmpty"
    >
      <el-table border stripe :data="hospitalDetailList" height="100%" key="hosDetailTable" ref="hosDetailTable">
        <el-table-column type="index" width="50" label="序号"></el-table-column>
        <el-table-column prop="patient_name" label="患者姓名" show-overflow-tooltip width="100"></el-table-column>
        <el-table-column prop="__sex" label="性别" show-overflow-tooltip width="80"></el-table-column>
        <el-table-column prop="age_detail" label="年龄" show-overflow-tooltip width="80"></el-table-column>
        <template v-if="hospitalDetailType === DetailMode.Apply">
          <el-table-column prop="consult_expert_name" label="会诊医生" show-overflow-tooltip
                           width="100"></el-table-column>
          <el-table-column prop="consult_date" label="会诊时间" show-overflow-tooltip width="180"></el-table-column>
        </template>
        <template v-if="hospitalDetailType === DetailMode.Reject">
          <el-table-column prop="audit_user_name" label="审核医生" show-overflow-tooltip width="100"></el-table-column>
          <el-table-column prop="reason" label="驳回原因" show-overflow-tooltip width="180"></el-table-column>
        </template>

        <el-table-column prop="purpose" label="会诊目的" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_kind_name" label="会诊类型" show-overflow-tooltip width="120"></el-table-column>
        <el-table-column prop="consult_class_name" label="会诊方式" show-overflow-tooltip width="120"></el-table-column>
        <el-table-column prop="request_org_name" label="申请医院" show-overflow-tooltip width="180"></el-table-column>
        <el-table-column prop="request_user_name" label="申请医生" show-overflow-tooltip width="100"></el-table-column>
        <el-table-column prop="request_date" label="申请时间" show-overflow-tooltip width="180"></el-table-column>
      </el-table>

      <!---用来科室详情详情(明细)所有数据用的表格--->
      <el-table v-if="showAllHospitalDetailData" border stripe :data="allHospitalDetailList" height="100%" key="hosDetailAllTable" ref="hosDetailAllTable">
        <el-table-column type="index" width="50" label="序号"></el-table-column>
        <el-table-column prop="patient_name" label="患者姓名" show-overflow-tooltip width="100"></el-table-column>
        <el-table-column prop="__sex" label="性别" show-overflow-tooltip width="80"></el-table-column>
        <el-table-column prop="age_detail" label="年龄" show-overflow-tooltip width="80"></el-table-column>
        <template v-if="hospitalDetailType === DetailMode.Apply">
          <el-table-column prop="consult_expert_name" label="会诊医生" show-overflow-tooltip
                           width="100"></el-table-column>
          <el-table-column prop="consult_date" label="会诊时间" show-overflow-tooltip width="180"></el-table-column>
        </template>
        <template v-if="hospitalDetailType === DetailMode.Reject">
          <el-table-column prop="audit_user_name" label="审核医生" show-overflow-tooltip width="100"></el-table-column>
          <el-table-column prop="reason" label="驳回原因" show-overflow-tooltip width="180"></el-table-column>
        </template>

        <el-table-column prop="purpose" label="会诊目的" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_kind_name" label="会诊类型" show-overflow-tooltip width="120"></el-table-column>
        <el-table-column prop="consult_class_name" label="会诊方式" show-overflow-tooltip width="120"></el-table-column>
        <el-table-column prop="request_org_name" label="申请医院" show-overflow-tooltip width="180"></el-table-column>
        <el-table-column prop="request_user_name" label="申请医生" show-overflow-tooltip width="100"></el-table-column>
        <el-table-column prop="request_date" label="申请时间" show-overflow-tooltip width="180"></el-table-column>
      </el-table>
    </table-layout>
    <div v-if="viewType === ApplyNumViewType.HospitalDetailTable">
      <pagination-tool :total="hospitalDetailTotalCount" :page.sync="hospitalPageIndex" :limit.sync="hospitalPageSize"
                       @pagination="getHospitalDetailList"/>
    </div>

    <div v-if="viewType === ApplyNumViewType.Detail">
      <pagination-tool :total="detailTotalCount" :page.sync="pageIndex" :limit.sync="pageSize"
                       @pagination="getDetailList"/>
    </div>
  </div>
</template>

<script>

import DatePickerRange from '../components/date-picker-range'
import SwitchBar from '../components/switch-bar'
import TableLayout from '../components/table-layout'
import BackBtn from '../components/back-btn'
import BackLine from '../components/back-line'
import Tab from '../components/tab'
import PaginationTool from '@/components/common/PaginationTool' // 分页

import {
  ApplyNumViewType,
  applyTypeList,
  serializeTime,
  serializeTimeType,
  applyTabList,
  applyHospitalTabList,
  serializeTableHeaders,
  serializeColumnView,
  serializeChartDataSource,
  serialDataSource,
  serializeHospitalChartData,
  DetailMode,
  serializeDetailDataSource,
  serializeTableHeadersNew,
  serializeTableDataSourceNew,
  percentFilter,
  mergeSpan,
  serializeAllIds, conObj, serializeHospitalDataSource
} from '../utils'
import SecurityServiceWrapper from '@/utils/SecurityService'
import {getAllServiceCenter, getCooperationsList} from '@/api/platform_costomer/telemedicine'
import {
  disposeCharts,
  drawChartList, drawHosChart,
  resizeCharts
} from '@/views/CustomerManagement/consultationStatistics/utils/charts'
import {getAllInspectClass} from '@/api/seviceCenterManage/centerSet'
import {
  getTenancyRequest,
  getTenancyRequestDetails,
  getTenancyRequestOffice,
  getTenancyRequestRank
} from '@/api/seviceCenterManage/dataStatic'
import utils from '@/utils'
import Mgr from '@/utils/SecurityService'

export default {
  name: "apply-num",

  components: {
    DatePickerRange,
    SwitchBar,
    TableLayout,
    BackBtn,
    Tab,
    BackLine,
    PaginationTool
  },

  filters: {
    percentFilter
  },

  computed: {
    isEmpty() {
      return this.dataSource.length === 0
    },

    isChartEmpty() {
      return this.chartDataSource.length === 0
    },

    isShowSwitchBar() {
      return [ApplyNumViewType.Table, ApplyNumViewType.Chart].includes(this.viewType)
    },

    isShowHosSwitchBar() {
      return [ApplyNumViewType.HospitalTable, ApplyNumViewType.HospitalChart].includes(this.viewType)
    },

    isHospitalEmpty() {
      return this.hospitalDataSource.length === 0
    },

    isHospitalChartEmpty() {
      return this.hospitalChartDataSource.length === 0
    },

    isDetailEmpty() {
      return this.detailDataSource.length === 0
    },

    isHospitalDetailListEmpty() {
      return this.hospitalDetailList.length === 0
    },

    isShowToolBar() {
      return [
        ApplyNumViewType.HospitalTable,
        ApplyNumViewType.Detail,
        ApplyNumViewType.HospitalDetailTable,
        ApplyNumViewType.HospitalChart
      ].includes(this.viewType)
    },

    isTableBar() {
      return [ApplyNumViewType.HospitalTable, ApplyNumViewType.HospitalDetailTable, ApplyNumViewType.Detail].includes(this.viewType)
    },

    isDetailMode() {
      return [ApplyNumViewType.Detail, ApplyNumViewType.HospitalTable, ApplyNumViewType.HospitalChart, ApplyNumViewType.HospitalDetailTable].includes(this.viewType)
    }
  },

  data() {
    return {
      showAllDetailTableData: false,
      allDetailDataSource: [],
      showAllHospitalDetailData: false,
      allHospitalDetailList: [],
      DetailMode,
      mergeSpan,
      serializeColumnView,
      ApplyNumViewType,
      applyTabList,
      applyHospitalTabList,
      viewType: ApplyNumViewType.Table,
      institutionId: '',
      applyType: applyTypeList[0].value,
      applyTypeList,
      applyTime: serializeTime(applyTypeList[0].value)/*['2022-05-01', '2022-05-31']*/,
      serviceCenter: [],
      consultationType: [],
      consultationList: [],
      serviceCenterList: [],
      applyHospital: [],
      applyHospitalList: [],
      headers: [],
      dataSource: [],
      tabActive: applyTabList[0].value,

      chartDataSource: [],
      chartInstanceList: [],
      observer: null,
      filterType: 1,

      state: new Map(),
      exportState: new Map(),
      loading: false,
      loadingChart: false,
      loadingHospital: false,

      hospitalDataSource: [],
      hospitalHeaders: [],
      currentHospitalId: null,        // 也就是去详情表时用的
      currentCenterId: null,          // 也是去详情表时用的
      currentConsultKindCode: null,
      currentHospitalName: '',

      hospitalChartDataSource: [],
      loadingHospitalChart: false,
      hosChartInstanceList: [],

      detailType: 1,
      detailDataSource: [],
      loadingDetail: false,
      loadingHospitalDetailList: false,
      hospitalDetailList: [],
      hospitalDetailType: DetailMode.Apply,
      requestOfficeName: '',
      backStack: [],             // 返回栈
      detailTotalCount: 0,
      pageIndex: 1,
      pageSize: 20,
      hospitalDetailTotalCount: 0,
      hospitalPageIndex: 1,
      hospitalPageSize: 20,
      isExporting: false
    }
  },

  methods: {
    prepareParams() {
      let begin_date = ''
      let end_date = ''
      if (Array.isArray(this.applyTime) && this.applyTime.length > 0) {
        begin_date = this.applyTime[0]
        end_date = this.applyTime[1]
      }
      return {
        statistice_date_type: this.filterType,
        begin_date,
        end_date,
        consult_center_ids: this.serviceCenter,
        consult_kind_codes: this.consultationType,
        request_org_ids: this.applyHospital
      }
    },

    changeViewType(type) {
      this.viewType = type
      this.onViewTypeChanged()
    },

    onClickBackBtn() {
      const item = this.popStack()
      this.viewType = item.value
      this.onViewTypeChanged()
    },

    onViewTypeChanged() {
      const query = this.state.get(this.viewType)
      if (query) {
        query()
      }
    },

    async queryList() {
      this.onViewTypeChanged()
    },

    resetData() {
      this.applyType = applyTypeList[0].value
      this.applyTime = serializeTime(applyTypeList[0].value)
      this.consultationType = []
      this.consultationList = []
      this.serviceCenter = []
      this.serviceCenterList = []
      this.applyHospital = []
      this.applyHospitalList = []

      this.getConsultationList()
      this.getServiceCenterList()
      this.getApplyHospitalList()
      this.onViewTypeChanged()
    },

    async onQueryTableList() {
      await this.getList()
    },

    async onQueryChartList() {
      await this.getChartList()
    },

    async onQueryDetailList() {
      await this.getDetailList()
    },

    async onQueryHospitalList() {
      await this.getHospitalList()
    },

    async onQueryHospitalChartList() {
      await this.getHospitalChart()
    },

    async onQueryHospitalDetailList() {
      this.pageIndex = 1
      await this.getHospitalDetailList()
    },

    onApplyTimeChanged(val) {
      if (val === -1) {
        this.applyTime = []
        return
      }
      this.applyTime = serializeTime(val)
    },

    onTimeChanged(val) {
      this.applyTime = val
      if (!(Array.isArray(val) && val.length > 0)) {
        this.applyType = -1
        return
      }

      this.applyType = serializeTimeType(val, applyTypeList)
    },

    /**
     * 获取当前机构id
     * @returns {Promise<void>}
     */
    async getUserInfo() {
      const res = await new SecurityServiceWrapper().getRole()
      if (res && res.profile) {
        this.institutionId = res.profile.inst_id
      }
    },

    /**
     * 获取会诊中心下拉列表
     * @returns {Promise<void>}
     */
    async getConsultationList() {
      const params = {
        lookup_key: 'InstitutionOpen'
      }
      const res = await getAllInspectClass(params)
      if (res.code === 0) {
        const list = res.data.filter(item => {
          const num = Number(item.dic_code)
          return 120 < num && num < 129
        })

        this.consultationList = list.map(item => {
          const name = conObj.hasOwnProperty(item.dic_code) ? conObj[item.dic_code] : ''
          return {
            ...item,
            __dic_name: name
          }
        })
      }
    },

    /**
     * 获取服务中心下拉列表
     * @returns {Promise<void>}
     */
    async getServiceCenterList() {
      const params = {
        service_codes: [121, 122, 123, 124, 125, 126, 127, 128]
      }
      const res = await getAllServiceCenter(params)
      if (res.code === 0) {
        this.serviceCenterList = res.data
      }
    },

    /**
     * 获取申请医院列表
     * @returns {Promise<void>}
     */
    async getApplyHospitalList() {
      const params = {
        service_center_ids: this.serviceCenter,
        service_codes: [121, 122, 123, 124, 125, 126, 127, 128],
        offset: 1,
        limit: 999
      }

      const res = await getCooperationsList(params)
      if (res.code === 0) {
        this.applyHospitalList = res.data
      }
    },

    /**
     * 获取表格数据
     * @returns {Promise<void>}
     */
    async getList() {
      this.headers = []
      this.dataSource = []
      this.loading = true
      const params = this.prepareParams()
      const res = await getTenancyRequest(params)
      if (res.code === 0) {
        this.headers = serializeTableHeadersNew(res.data)
        this.dataSource = serializeTableDataSourceNew(res.data)
        this.doLayout(this.$refs.tb)
        /*this.headers = serializeTableHeaders(res.data)
        this.dataSource = serializeTableDataSource(res.data)
        this.doLayout(this.$refs.tb)*/
      } else {
        this.headers = []
        this.dataSource = []
      }
      this.loading = false
    },

    /**
     * 获取图表数据
     * @returns {Promise<void>}
     */
    async getChartList() {
      this.chartDataSource = []
      this.loadingChart = true
      const params = this.prepareParams()
      const res = await getTenancyRequestRank(params)
      if (res.code === 0) {
        this.chartDataSource = serializeChartDataSource(res.data)
        this.drawCharts()
      } else {
        this.chartDataSource = []
      }
      this.loadingChart = false
    },

    showHospitalDetail(row) {
      if (row.__isSummary) {
        return
      }

      const currentName = `${row.consult_center_name}-${row.request_org_name}`
      this.currentCenterId = row.consult_center_id
      this.currentHospitalId = row.request_org_id
      this.currentHospitalName = row.request_org_name
      this.viewType = ApplyNumViewType.HospitalTable
      this.pushStack('会诊申请量', ApplyNumViewType.Table, currentName)
      this.onViewTypeChanged()
    },

    pushStack(name, value, currentName) {
      this.backStack.push({
        name,
        value,
        currentName
      })
    },

    popStack() {
      return this.backStack.pop()
    },

    /**
     * 获取科室管理数据
     * @returns {Promise<void>}
     */
    async getHospitalList() {
      this.hospitalHeaders = []
      this.hospitalDataSource = []
      this.loadingHospital = true
      const params = {
        ...this.prepareParams(),
        consult_center_ids: this.currentCenterId,
        request_org_ids: this.currentHospitalId
      }

      const res = await getTenancyRequestOffice(params)
      if (res.code === 0) {
        this.hospitalHeaders = serializeTableHeaders(res.data)
        this.hospitalDataSource = serializeHospitalDataSource(res.data)
        if (this.hospitalHeaders.length > 0) {
          this.currentConsultKindCode = this.hospitalHeaders[0].consult_kind_code
        }
        this.doLayout(this.$refs.hosTb)
      }

      this.loadingHospital = false
    },

    /**
     * 获取科室管理图表数据
     * @returns {Promise<void>}
     */
    async getHospitalChart() {
      this.hospitalChartDataSource = []
      this.loadingHospitalChart = true
      const params = {
        ...this.prepareParams(),
        consult_center_ids: this.currentCenterId,
        request_org_ids: this.currentHospitalId,
        consult_kind_codes: this.currentConsultKindCode
      }

      const res = await getTenancyRequestOffice(params)
      if (res.code === 0) {
        this.hospitalChartDataSource = serializeHospitalChartData(res.data)
        this.drawHosCharts()
      }

      this.loadingHospitalChart = false
    },

    changeHosTab() {
      this.onViewTypeChanged()
    },
    // 获取详情列表 所有数据
    async getDetailTableAllData() {
      const self = this
      self.allDetailDataSource = []
      const params = {
        ...self.prepareParams(),
        statistics_request_type: self.detailType,
        consult_center_ids: self.currentCenterId,
        request_org_ids: self.currentHospitalId,
        consult_kind_codes: self.currentConsultKindCode,
        is_export: false,
        page_index: 1,
        page_size: self.detailTotalCount
      }
      const res = await getTenancyRequestDetails(params)
      if (res.code === 0) {
        self.allDetailDataSource = serializeDetailDataSource(res.data)
        self.$nextTick(()=> {
          self.onExport(self.$refs.detailAllTable.$el, '会诊申请量详情')
        })
        
      } else {
        self.isExporting = false
        self.$message.error(res.msg)
      }
    },
    /**
     * 获取详情列表
     * @returns {Promise<void>}
     */
    async getDetailList() {
      this.detailDataSource = []
      this.loadingDetail = true
      console.log(this.pageIndex,this.pageSize)
      const params = {
        ...this.prepareParams(),
        statistics_request_type: this.detailType,
        consult_center_ids: this.currentCenterId,
        request_org_ids: this.currentHospitalId,
        consult_kind_codes: this.currentConsultKindCode,
        is_export: false,
        page_index: this.pageIndex,
        page_size: this.pageSize
      }
      const res = await getTenancyRequestDetails(params)
      if (res.code === 0) {
        this.detailDataSource = serializeDetailDataSource(res.data)
        this.detailTotalCount = res.page.total_count

      }
      this.loadingDetail = false
    },
    /**
     * 获取科室详情所有列表
     * @returns {Promise<void>}
     */
    async getAllHospitalDetailList() {
      const self = this
      self.allHospitalDetailList = []
      const params = {
        ...self.prepareParams(),
        statistics_request_type: self.hospitalDetailType,
        consult_center_ids: self.currentCenterId,
        request_org_ids: self.currentHospitalId,
        consult_kind_codes: self.currentConsultKindCode,
        request_office_name: self.requestOfficeName,
        is_export: false,
        page_index: 1,
        page_size: self.hospitalDetailTotalCount
      }
      const res = await getTenancyRequestDetails(params)
      if (res.code === 0) {
        self.allHospitalDetailList = serializeDetailDataSource(res.data)
        self.$nextTick(()=> {
          self.onExport(self.$refs.hosDetailAllTable.$el, `会诊申请量_${self.currentHospitalName}_详情`)
        })
      } else {
        self.isExporting = false
        self.$message.error(res.msg)
      }
    },
    /**
     * 获取科室详情列表
     * @returns {Promise<void>}
     */
    async getHospitalDetailList() {
      this.hospitalDetailList = []
      this.loadingHospitalDetailList = true
      const params = {
        ...this.prepareParams(),
        statistics_request_type: this.hospitalDetailType,
        consult_center_ids: this.currentCenterId,
        request_org_ids: this.currentHospitalId,
        consult_kind_codes: this.currentConsultKindCode,
        request_office_name: this.requestOfficeName,
        is_export: false,
        page_index: this.hospitalPageIndex,
        page_size: this.hospitalPageSize
      }

      const res = await getTenancyRequestDetails(params)
      if (res.code === 0) {
        this.hospitalDetailList = serializeDetailDataSource(res.data)
        this.hospitalDetailTotalCount = res.page.total_count
      }
      this.loadingHospitalDetailList = false
    },

    toDetailsView(count, {row, column}, type, isTotal = false, label = '') {
      if (count <= 0) {
        return
      }
      let hospitalIds = []
      let serviceCenterId
      if (row.__isSummary || row.__isServiceCenter) {
        hospitalIds = serializeAllIds(row.children)
        if (row.consult_center_id) {
          serviceCenterId = [row.consult_center_id]
        }
      } else if (row.__isAllTotal) {
        hospitalIds = []
        serviceCenterId = []
      } else {
        hospitalIds.push(row.request_org_id)
        serviceCenterId = [row.consult_center_id]
      }

      let _property
      if (isTotal) {
        _property = ''
      } else {
        const property = column.property.split('_')
        _property = property.length > 0 ? property[0] : ''
      }

      this.viewType = ApplyNumViewType.Detail
      this.detailType = type

      this.currentCenterId = serviceCenterId
      this.currentHospitalId = hospitalIds
      this.currentConsultKindCode = _property

      const typeName = type === 1 ? '申请量明细' : '驳回量明细'
      let currentName = ''
      if (row.__isAllTotal) {
        currentName = `${typeName}-总计`
      } else if (row.__isServiceCenter) {
        currentName = `${typeName}-${row.consult_center_name}-合计`
      } else {
        currentName = `${typeName}-${row.consult_center_name}-${row.regional_nature_code_desc}医院-${row.request_org_name}`
      }

      if (label.length > 0) {
        currentName += `-${label}`
      }

      this.pushStack('会诊申请量', ApplyNumViewType.Table, currentName)
      this.onViewTypeChanged()
    },

    toHosDetailView(count, {column, row}, type) {
      if (count <= 0) {
        return
      }

      const property = column.property.split('_')
      const _property = property.length > 0 ? property[0] : ''

      this.hospitalDetailType = type
      this.currentConsultKindCode = _property
      if (row.__isTotal) {
        this.requestOfficeName = ''
      } else {
        this.requestOfficeName = row.request_office_name
      }
      this.viewType = ApplyNumViewType.HospitalDetailTable

      const name = this.backStack[this.backStack.length - 1].currentName

      let currentName = type === 1 ? '申请量明细' : '驳回量明细'
      currentName = row.__isTotal ? currentName : `${row.request_office_name}${currentName}`
      this.pushStack(name, ApplyNumViewType.HospitalTable, currentName)
      this.onViewTypeChanged()
    },

    drawCharts() {
      this.$nextTick(() => {
        disposeCharts(this.chartInstanceList)
        const list = Array.from(this.$refs.chartContainer.querySelectorAll('.chart-main'))
        this.chartInstanceList = drawChartList(list, this.chartDataSource, this.applyTime, this.filterType)
      })
    },

    drawHosCharts() {
      this.$nextTick(() => {
        disposeCharts(this.hosChartInstanceList)
        this.hosChartInstanceList = drawHosChart(this.$refs.hosChart, this.hospitalChartDataSource)
      })
    },

    /**
     * 服务中心更改以后重新获取申请医院列表
     */
    onServiceCenterChanged() {
      this.applyHospital = []
      this.getApplyHospitalList()
    },

    resizeCharts() {
      if (window.ResizeObserver === undefined) {
        return
      }
      this.observer = new ResizeObserver(() => {
        resizeCharts(this.chartInstanceList)
        resizeCharts(this.hosChartInstanceList)
      })
      this.observer.observe(document.body)
    },

    releaseResize() {
      if (this.observer === null) {
        return
      }
      this.observer.disconnect()
    },

    doLayout(tb) {
      this.$nextTick(() => {
        if (tb && tb.doLayout) {
          tb.doLayout()
        }
      })
    },

    async init() {
      this.state.set(ApplyNumViewType.Table, this.onQueryTableList.bind(this))
      this.state.set(ApplyNumViewType.Chart, this.onQueryChartList.bind(this))
      this.state.set(ApplyNumViewType.Detail, this.onQueryDetailList.bind(this))
      this.state.set(ApplyNumViewType.HospitalTable, this.onQueryHospitalList.bind(this))
      this.state.set(ApplyNumViewType.HospitalChart, this.onQueryHospitalChartList.bind(this))
      this.state.set(ApplyNumViewType.HospitalDetailTable, this.onQueryHospitalDetailList.bind(this))

      this.exportState.set(ApplyNumViewType.Table, this.onExportTable.bind(this))
      this.exportState.set(ApplyNumViewType.Detail, this.onExportDetailTable.bind(this))
      this.exportState.set(ApplyNumViewType.HospitalTable, this.onExportHospitalTable.bind(this))
      this.exportState.set(ApplyNumViewType.HospitalDetailTable, this.onExportHospitalDetailTable.bind(this))

      /**
       * 监听 dom 宽高变化，重新绘制 echarts
       */
      this.resizeCharts()
      await this.getLoginInfo()
      /*await this.getUserInfo()*/
      const consult = this.getConsultationList()
      const serviceCenter = this.getServiceCenterList()
      const hospital = this.getApplyHospitalList()
      this.onViewTypeChanged()
      await consult
      await serviceCenter
      await hospital
    },

    expandChange(row, open) {
      row.__open = open
    },

    onExportTable() {
      let begin_date = ''
      let end_date = ''
      if (Array.isArray(this.applyTime) && this.applyTime.length > 0) {
        begin_date = this.applyTime[0]
        end_date = this.applyTime[1]
      }
      const exportTime = `申请时间：${begin_date}~${end_date}`
      const userName = `制表人：${this.userName}`
      this.onExport(this.$refs.tb.$el, '会诊申请量', {
        title: '会诊申请量',
        exportTime,
        userName,
        needTitle: true
      })
    },

    onExportDetailTable() {
      this.isExporting = true
      this.getDetailTableAllData()
    },

    onExportHospitalTable() {
      this.onExport(this.$refs.hosTb.$el, `会诊申请量_${this.currentHospitalName}`)
    },

    onExportHospitalDetailTable() {
      this.isExporting = true
      this.getAllHospitalDetailList()
    },

    async onExport(dom, tableName, config = {}) {
      this.isExporting = true

      await utils.excel.exportExcelWithHeader(dom, tableName, config)

      this.isExporting = false
    },

    exportEvent() {
      const exportEvent = this.exportState.get(this.viewType)
      if (exportEvent) {
        exportEvent()
      }
    },

    onBackLineClick(val) {
      const index = this.backStack.findIndex(item => item.value === val)

      let lastItem
      while (this.backStack.length > index) {
        lastItem = this.popStack()
      }

      this.viewType = val
      this.onViewTypeChanged()
    },

    async getLoginInfo() {
      try {
        const role = await new Mgr().getRole()
        this.userName = role.profile.name
      } catch (e) {
        this.userName = ''
      }
    }
  },

  mounted() {
    this.init()
  },

  beforeDestroy() {
    this.releaseResize()
  }
}

</script>

