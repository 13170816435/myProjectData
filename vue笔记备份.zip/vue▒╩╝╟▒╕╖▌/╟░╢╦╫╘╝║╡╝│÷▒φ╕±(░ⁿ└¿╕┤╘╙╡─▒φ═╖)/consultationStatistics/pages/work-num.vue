<template>
  <div class="statistics-pages" v-loading.fullscreen.lock="isExporting"  element-loading-text="导出中..."
          element-loading-background="rgba(255,255,255,0.6)">
    <div class="search-toolbar">

      <div class="search-bar-line">
        <div class="search-toolbar-item">
          <span class="label">会诊时间：</span>
          <el-select
              v-model="applyType"
              placeholder="全部"
              class="w_85"
              @change="onApplyTimeChanged"
              :disabled="isDetailMode"
          >
            <el-option
                v-for="(item, index) of applyTypeList"
                :key="index"
                :label="item.label"
                :value="item.value"
            ></el-option>
          </el-select>
          <date-picker-range :value="applyTime" @input="onTimeChanged" :disabled="isDetailMode"></date-picker-range>
        </div>

        <div class="search-toolbar-item">
          <span class="label">会诊类型：</span>
          <el-select
              multiple
              filterable
              collapse-tags
              clearable
              v-model="consultationType"
              placeholder="全部"
              class="width_260_select"
              :disabled="isDetailMode"
          >
            <el-option
                v-for="item of consultationList"
                :key="item.__dic_name"
                :label="item.dic_name"
                :value="item.__dic_name"
            ></el-option>
          </el-select>
        </div>
      </div>

      <div class="search-bar-between">
        <div class="search-bar-line">
          <div class="search-toolbar-item">
            <span class="label">服务中心：</span>
            <el-select
                multiple
                filterable
                collapse-tags
                clearable
                v-model="serviceCenter"
                placeholder="全部"
                class="width_330"
                @change="onServiceCenterChanged"
                :disabled="isDetailMode"
            >
              <el-option
                  v-for="item of serviceCenterList"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
              ></el-option>
            </el-select>
          </div>

          <div class="search-toolbar-item">
            <span class="label">服务医生：</span>
            <el-select
                multiple
                filterable
                collapse-tags
                clearable
                v-model="serviceDoctor"
                placeholder="全部"
                class="width_260_select"
                :disabled="isDetailMode"
            >
              <el-option
                  v-for="item in serviceDoctorList"
                  :key="item.doctor_id"
                  :label="item.name"
                  :value="item.doctor_id"
              ></el-option>
            </el-select>
          </div>

          <div class="search-toolbar-item">
            <el-button type="primary" size="small" @click="queryList" :disabled="isDetailMode">查询</el-button>
            <el-button size="small" plain @click="resetData" :disabled="isDetailMode">重置</el-button>
          </div>
        </div>
        <div class="switch-bar">
          <el-radio-group
              v-model="filterType"
              class="filter-type-list"
              v-if="viewType === ApplyNumViewType.Chart"
              @change="queryChart"
          >
            <el-radio :label="1">按天</el-radio>
            <el-radio :label="2">按月</el-radio>
          </el-radio-group>

          <switch-bar v-model="viewType" :tab-list="applyTabList" @change="changeViewType"
                      v-if="isShowSwitchBar"></switch-bar>
        </div>
      </div>
    </div>

    <table-layout
        v-if="viewType === ApplyNumViewType.Table"
        class="statistics-main" :is-empty="isEmpty" :loading="loading">
      <el-table border
                :data="dataSource"
                ref="tb" height="100%" row-key="__id" default-expand-all
                :tree-props="{children: 'details'}"
                :span-method="arraySpanMethod"
                @expand-change="expandChange"
                class="static-table-layout"
      >
        <el-table-column prop="consult_center_name" label="服务中心" :fixed="!isExporting"></el-table-column>
        <el-table-column prop="consult_kind_name" label="会诊类型" :fixed="!isExporting"></el-table-column>
        <el-table-column prop="consult_kind_quantity" label="会诊总量">
          <template v-slot="data">
            <span :class="data.row.consult_kind_quantity && 'apply-hos-btn'"
                  @click="toDetailsView(serializeColumnView(data), data, 'consult_kind_quantity')">
              {{ serializeColumnView(data) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="consult_kind_percent" label="服务占比">
          <template v-slot="data">
            <span>
              {{
                data.row.consult_kind_percent && data.row.consult_kind_percent > 0 ? `${data.row.consult_kind_percent}%` : ''
              }}
            </span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="医生工作量明细">
          <el-table-column prop="user_name" label="会诊医生"></el-table-column>
          <el-table-column prop="quantity" label="会诊量">
            <template v-slot="data">
              <span :class="data.row.quantity && 'apply-hos-btn'"
                    @click="toDetailsView(serializeColumnView(data), data, 'quantity')">
                {{ data.row.quantity }}
              </span>
            </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </table-layout>
    <div class="statistics-detail-bar" v-if="isShowToolBar" :class="isTableBar && 'statistics-table-bar'">
      <div class="left">
        <back-btn @on-click="onClickBackBtn"></back-btn>
        <span class="split-line"></span>
        {{ detailTitle }}
      </div>
    </div>
    <table-layout v-if="viewType === ApplyNumViewType.Detail" class="statistics-main"
                  :loading="loadingDetail" :is-empty="isDetailEmpty"
    >
      <el-table border stripe :data="detailDataSource" height="100%" key="detail" ref="detail">
        <el-table-column type="index" width="50" label="序号"></el-table-column>
        <el-table-column prop="patient_name" label="患者姓名" show-overflow-tooltip></el-table-column>
        <el-table-column prop="__sex" label="性别" show-overflow-tooltip></el-table-column>
        <el-table-column prop="age_detail" label="年龄" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_expert_name" label="会诊医生" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_date" label="会诊时间" show-overflow-tooltip></el-table-column>
        <el-table-column prop="purpose" label="会诊目的" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_kind_name" label="会诊类型" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_class_name" label="会诊方式" show-overflow-tooltip></el-table-column>
        <el-table-column prop="request_org_name" label="申请医院" show-overflow-tooltip></el-table-column>
        <el-table-column prop="request_user_name" label="申请医生" show-overflow-tooltip></el-table-column>
        <el-table-column prop="request_date" label="申请时间" show-overflow-tooltip></el-table-column>
      </el-table>

      <!---用来导出会诊工作量详情(明细)所有数据用的表格--->
      <el-table v-show="showAllDetailTableData" border stripe :data="allDetailDataSource" height="100%" key="detailAllTable" ref="detailAllTable">
        <el-table-column type="index" width="50" label="序号"></el-table-column>
        <el-table-column prop="patient_name" label="患者姓名" show-overflow-tooltip></el-table-column>
        <el-table-column prop="__sex" label="性别" show-overflow-tooltip></el-table-column>
        <el-table-column prop="age_detail" label="年龄" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_expert_name" label="会诊医生" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_date" label="会诊时间" show-overflow-tooltip></el-table-column>
        <el-table-column prop="purpose" label="会诊目的" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_kind_name" label="会诊类型" show-overflow-tooltip></el-table-column>
        <el-table-column prop="consult_class_name" label="会诊方式" show-overflow-tooltip></el-table-column>
        <el-table-column prop="request_org_name" label="申请医院" show-overflow-tooltip></el-table-column>
        <el-table-column prop="request_user_name" label="申请医生" show-overflow-tooltip></el-table-column>
        <el-table-column prop="request_date" label="申请时间" show-overflow-tooltip></el-table-column>
      </el-table>
    </table-layout>
    <div v-if="viewType === ApplyNumViewType.Detail">
      <pagination-tool :total="detailTotalCount" :page.sync="pageIndex" :limit.sync="pageSize"
                       @pagination="getDetailList"/>
    </div>
    <table-layout v-if="isShowChart" class="statistics-main statistics-chart"
                  :loading="loadingChart" :is-empty="isChartEmpty"
    >
      <div class="chart-list" ref="chartContainer">
        <div class="chart-item work-chart-total"
             :class="chartDataSource.length === 0 && 'chart-item-single'"
        >
          <div class="title">
            服务中心工作量排行榜
            <tab
                v-model='currentConsultKindCode'
                :tab-list="conHeaders"
                value-key="consult_kind_code"
                @change="changeConTab"
            ></tab>
          </div>
          <div class="chart-main" ref="total">
          </div>
        </div>

        <div class="chart-item"
             v-for="item of chartDataSource"
             :key="item.consult_center_id"
        >
          <div class="title">
            {{ item.consult_center_name }}
          </div>
          <div class="chart-main">
          </div>
        </div>
      </div>
    </table-layout>
  </div>
</template>

<script>

import DatePickerRange from '../components/date-picker-range'
import SwitchBar from '../components/switch-bar'
import TableLayout from '../components/table-layout'
import BackBtn from '../components/back-btn'
import Tab from '../components/tab'
import {
  ApplyNumViewType,
  applyTypeList,
  serializeTime,
  serializeTimeType,
  applyTabList,
  serializeColumnView,
  serializeDetailDataSource,
  serializeWorkHeaders,
  serializeWorkChartTotalDataSource,
  serializeWorkChartList, serializeWorkDataSource, conObj,
} from '../utils'
import {getAllInspectClass} from '@/api/seviceCenterManage/centerSet'
import {getAllServiceCenter, getServiceDoctorLite} from '@/api/platform_costomer/telemedicine'
import {
  getTenancyWorkReport,
  getTenancyWorkTrend,
  getTenancyWorkDetails,
  getTenancyWorkTrendRank
} from '@/api/seviceCenterManage/dataStatic'
import {
  disposeCharts,
  drawChartList, drawTotalChartList, drawWorkChartList, resizeCharts
} from '@/views/CustomerManagement/consultationStatistics/utils/charts'
import PaginationTool from '@/components/common/PaginationTool'
import Mgr from '@/utils/SecurityService'
import utils from '@/utils' // 分页

export default {
  name: "apply-work",

  computed: {
    isEmpty() {
      return this.dataSource.length === 0
    },
    isDetailEmpty() {
      return this.detailDataSource.length === 0
    },
    isShowToolBar() {
      return [
        ApplyNumViewType.Detail
      ].includes(this.viewType)
    },
    isTableBar() {
      return [ApplyNumViewType.Detail].includes(this.viewType)
    },
    isShowChart() {
      return [ApplyNumViewType.Chart].includes(this.viewType)
    },
    isChartEmpty() {
      return this.chartDataSource.length === 0
    },

    isShowSwitchBar() {
      return [ApplyNumViewType.Table, ApplyNumViewType.Chart].includes(this.viewType)
    },

    isDetailMode() {
      return [ApplyNumViewType.Detail].includes(this.viewType)
    }
  },

  data() {
    return {
      showAllDetailTableData: false,
      allDetailDataSource: [],
      serializeColumnView,
      applyTypeList,
      applyTabList,
      ApplyNumViewType,
      applyType: applyTypeList[0].value,
      applyTime: serializeTime(applyTypeList[0].value)/*['2022-05-01', '2022-05-31']*/,
      consultationType: [],
      consultationList: [],
      serviceCenter: [],
      serviceCenterList: [],
      serviceDoctor: [],
      serviceDoctorList: [],
      viewType: ApplyNumViewType.Table,

      dataSource: [],
      loading: false,
      loadingDetail: false,

      state: new Map(),
      exportState: new Map(),
      filterType: 1,       // 按日期，按月份
      detailDataSource: [],
      currentCenterId: null,          // 也是去详情表时用的
      currentConsultKindCode: null,
      backStack: [],             // 返回栈
      detailTitle: '',
      loadingChart: false,
      chartDataSource: [],
      detailTotalCount: 0,
      pageIndex: 1,
      pageSize: 20,
      conHeaders: [],

      chartTotalData: [],
      totalChartInstanceList: [],
      chartInstanceList: [],
      observer: null,
      currentUserId: null,

      isExporting: false,
      userName: '',
    }
  },

  methods: {
    async changeConTab() {
      await this.getChartTotal()
      this.updateCharts()
    },

    changeViewType(type) {
      this.viewType = type
      this.onViewTypeChanged()
    },

    onViewTypeChanged() {
      const query = this.state.get(this.viewType)
      if (query) {
        query()
      }
    },

    queryList() {
      this.onViewTypeChanged()
    },

    resetData() {
      this.applyType = applyTypeList[0].value
      this.applyTime = serializeTime(applyTypeList[0].value)
      this.consultationType = []
      /*this.consultationList = []*/
      this.serviceCenter = []
      /*this.serviceCenterList = []*/
      this.serviceDoctor = []
      /*this.serviceDoctorList = []*/

      this.getServiceDoctorList()
      this.onViewTypeChanged()
    },

    onApplyTimeChanged(val) {
      if (val === -1) {
        this.applyTime = []
        return
      }
      this.applyTime = serializeTime(val)
    },

    onTimeChanged(val) {
      this.applyTime = val
      if (!(Array.isArray(val) && val.length > 0)) {
        this.applyType = -1
        return
      }

      this.applyType = serializeTimeType(val, applyTypeList)
    },

    /**
     * 服务中心更改以后重新获取申请医院列表
     */
    onServiceCenterChanged() {
      this.applyHospital = []
      this.getServiceDoctorList()
    },
    prepareParams() {
      let begin_date = ''
      let end_date = ''
      if (Array.isArray(this.applyTime) && this.applyTime.length > 0) {
        begin_date = this.applyTime[0]
        end_date = this.applyTime[1]
      }
      return {
        statistice_date_type: this.filterType,
        begin_date,
        end_date,
        consult_center_ids: this.serviceCenter,
        consult_kind_codes: this.consultationType,
        user_ids: this.serviceDoctor
      }
    },
    /**
     * 获取表格数据
     * @returns {Promise<void>}
     */
    async getList() {
      this.loading = true
      const params = this.prepareParams()
      const res = await getTenancyWorkReport(params)
      if (res.code === 0) {
        this.conHeaders = serializeWorkHeaders(res.data)
        if (this.conHeaders.length > 0) {
          this.currentConsultKindCode = this.conHeaders[0].consult_kind_code
        }

        this.dataSource = serializeWorkDataSource(res.data)

        this.$nextTick(() => {
          const tb = this.$refs.tb
          if (tb && tb.doLayout) {
            tb.doLayout()
          }
        })
      } else {
        this.dataSource = []
      }
      this.loading = false
    },

    // 合并行，合并列
    arraySpanMethod({row, column, rowIndex, columnIndex}) {
      // 总计行
      if (rowIndex === 0 && columnIndex === 0) {
        return {rowspan: 1, colspan: 2}
      }
      if (rowIndex === 0 && columnIndex === 1) {
        return {rowspan: 0, colspan: 0}
      }
      // 处理服务中心列
      /*if (columnIndex === 0 && rowIndex > 0 && row.centerRowspan) {
        return {rowspan: row.centerRowspan, colspan: 1}
      }*/

      if (columnIndex === 0 && rowIndex > 0 && row.centerRowspan) {
        if (row.__open) {
          if (row.__isServiceCenter === true) {
            return {
              rowspan: row.centerRowspan,
              colspan: 1
            }
          }

          if (row.__isServiceCenter === false) {
            return {
              rowspan: 0,
              colspan: 0
            }
          }
        } else {
          if (row.__isServiceCenter === false) {
            return {
              rowspan: 0,
              colspan: 0
            }
          }
        }
      }

      // 服务中心下二级
      if (columnIndex === 0 && rowIndex > 0 && !row.centerRowspan) {
        return {rowspan: 0, colspan: 1}
      }
      // 处理会诊类型列
      if ([1, 2, 3].includes(columnIndex) && rowIndex > 0 && row.detailRowspan) {
        return {rowspan: row.detailRowspan, colspan: 1}
      }
      // 处理会诊类型下二级
      if ([1, 2, 3].includes(columnIndex) && rowIndex > 0 && !row.detailRowspan && !row.centerRowspan) {
        return {rowspan: 0, colspan: 1}
      }
    },

    // 导出数据
    exportEvent() {
      const exportEvent = this.exportState.get(this.viewType)
      if (exportEvent) {
        exportEvent()
      }
    },

    async onExport(dom, tableName, config = {}) {
      
      
      await utils.excel.exportExcelWithHeader(dom, tableName, config)

      this.isExporting = false
    },

    onExportTable() {
      let begin_date = ''
      let end_date = ''
      if (Array.isArray(this.applyTime) && this.applyTime.length > 0) {
        begin_date = this.applyTime[0]
        end_date = this.applyTime[1]
      }
      const exportTime = `会诊时间：${begin_date}~${end_date}`
      const userName = `制表人：${this.userName}`

      this.onExport(this.$refs.tb.$el, '会诊工作量', {
        title: '会诊工作量',
        exportTime,
        userName,
        needTitle: true
      })
    },

    onExportDetailTable() {
      // this.onExport(this.$refs.detail.$el, '会诊工作量详情')
      this.isExporting = true
      this.getDetailTableAllData()
    },
    // key值替换
    detailToChildren(arr) {
      arr.forEach(item => {
        if (item.details) {
          this.detailToChildren(item.details)
          item.children = item.details
        }
      })
      arr.forEach(item => {
        if (item.details) {
          delete item.details
        }
      })
    },

    onQueryTableList() {
      this.getList()
    },

    async onQueryChartList() {
      await this.getChartTotal()
      await this.getChartList()
      this.updateCharts()
    },

    async queryChart() {
      await this.getChartList()
    },

    async onQueryDetailList() {
      this.pageIndex = 1
      await this.getDetailList()
    },


    /**
     * 获取服务医生列表
     * @returns {Promise<void>}
     */
    async getServiceDoctorList() {
      const params = {
        service_center_ids: this.serviceCenter,
        service_codes: [121, 122, 123, 124, 125, 126, 127, 128]
      }

      const res = await getServiceDoctorLite(params)
      if (res.code === 0) {
        this.serviceDoctorList = res.data
      }
    },

    /**
     * 获取会诊中心下拉列表
     * @returns {Promise<void>}
     */
    async getConsultationList() {
      const params = {
        lookup_key: 'InstitutionOpen'
      }
      const res = await getAllInspectClass(params)
      if (res.code === 0) {
        const list = res.data.filter(item => {
          const num = Number(item.dic_code)
          return 121 <= num && num < 129
        })

        this.consultationList = list.map(item => {
          const name = conObj.hasOwnProperty(item.dic_code) ? conObj[item.dic_code] : ''
          return {
            ...item,
            __dic_name: name
          }
        })
      }
    },

    /**
     * 获取服务中心下拉列表
     * @returns {Promise<void>}
     */
    async getServiceCenterList() {
      const params = {
        institution_id: this.institutionId,
        service_codes: [121, 122, 123, 124, 125, 126, 127, 128]
      }
      const res = await getAllServiceCenter(params)
      if (res.code === 0) {
        this.serviceCenterList = res.data
      }
    },

    async getChartTotal() {
      if (this.currentConsultKindCode === null) {
        return
      }

      const params = {
        ...this.prepareParams(),
        consult_kind_code: this.currentConsultKindCode,

      }
      const res = await getTenancyWorkTrendRank(params)
      if (res.code === 0) {
        this.chartTotalData = serializeWorkChartTotalDataSource(res.data)
        this.drawTotalCharts()
      }
    },

    /**
     * 获取图表数据
     * @returns {Promise<void>}
     */
    async getChartList() {
      this.chartDataSource = []
      this.loadingChart = true
      const params = this.prepareParams()
      const res = await getTenancyWorkTrend(params)
      if (res.code === 0) {
        this.chartDataSource = serializeWorkChartList(res.data)
        this.drawCharts()
      } else {
        this.chartDataSource = []
      }
      this.loadingChart = false
    },

    drawTotalCharts() {
      disposeCharts(this.totalChartInstanceList)
      this.totalChartInstanceList = drawTotalChartList(this.$refs.total, this.chartTotalData)
    },

    drawCharts() {
      this.$nextTick(() => {
        disposeCharts(this.chartInstanceList)
        const list = Array.from(this.$refs.chartContainer.querySelectorAll('.chart-main'))
        const _list = list.splice(1)
        this.chartInstanceList = drawWorkChartList(_list, this.chartDataSource, this.applyTime, this.filterType)
      })
    },

    updateCharts() {
      resizeCharts(this.totalChartInstanceList)
    },

    resizeCharts() {
      if (window.ResizeObserver === undefined) {
        return
      }
      this.observer = new ResizeObserver(() => {
        resizeCharts(this.chartInstanceList)
        resizeCharts(this.totalChartInstanceList)
      })
      this.observer.observe(document.body)
    },
    // 获取详情列表 所有数据
   async getDetailTableAllData () {
      const self = this
      self.allDetailDataSource = []
      const params = {
        ...self.prepareParams(),
        consult_center_ids: self.currentCenterId,
        consult_kind_codes: self.currentConsultKindCode,
        is_export: false,
        user_ids: [self.currentUserId],
        page_index: 1,
        page_size: self.detailTotalCount
      }

      const res = await getTenancyWorkDetails(params)
      if (res.code === 0) {
        self.allDetailDataSource = serializeDetailDataSource(res.data)
        self.$nextTick(()=> {
           self.onExport(self.$refs.detailAllTable.$el, '会诊工作量详情')
        })
        
      } else {
        self.isExporting = false
        self.$message.error(res.msg)
      }
   },
    /**
     * 获取详情列表
     * @returns {Promise<void>}
     */
    async getDetailList() {
      this.detailDataSource = []
      this.loadingDetail = true
      const params = {
        ...this.prepareParams(),
        consult_center_ids: this.currentCenterId,
        consult_kind_codes: this.currentConsultKindCode,
        is_export: false,
        user_ids: [this.currentUserId],
        page_index: this.pageIndex,
        page_size: this.pageSize
      }

      const res = await getTenancyWorkDetails(params)
      if (res.code === 0) {
        this.detailDataSource = serializeDetailDataSource(res.data)
        this.detailTotalCount = res.page.total_count
      }
      this.loadingDetail = false
    },

    async init() {
      this.state.set(ApplyNumViewType.Table, this.onQueryTableList.bind(this))
      this.state.set(ApplyNumViewType.Chart, this.onQueryChartList.bind(this))
      this.state.set(ApplyNumViewType.Detail, this.onQueryDetailList.bind(this))

      this.exportState.set(ApplyNumViewType.Table, this.onExportTable.bind(this))
      this.exportState.set(ApplyNumViewType.Detail, this.onExportDetailTable.bind(this))

      this.resizeCharts()

      await this.getLoginInfo()
      const con = this.getConsultationList()
      const service = this.getServiceCenterList()
      const doc = this.getServiceDoctorList()

      this.onViewTypeChanged()
      await con
      await service
      await doc
    },

    toDetailsView(count, {row}, type) {
      if (count <= 0) {
        return
      }
      this.viewType = ApplyNumViewType.Detail
      this.currentCenterId = row.consult_center_id
      this.currentConsultKindCode = row.consult_kind_code
      this.currentUserId = row.user_id
      this.detailTitle = `${row.consult_center_name}`
      if (row.consult_kind_name) {
        this.detailTitle = `${this.detailTitle} - ${row.consult_kind_name}`
      }
      this.pushStack('会诊工作量', ApplyNumViewType.Table, row.consult_center_name)
      this.onViewTypeChanged()
    },

    onClickBackBtn() {
      const item = this.popStack()
      this.viewType = item.value
      this.onViewTypeChanged()
    },

    pushStack(name, value, currentName) {
      this.backStack.push({
        name,
        value,
        currentName
      })
    },

    popStack() {
      return this.backStack.pop()
    },

    releaseResize() {
      if (this.observer === null) {
        return
      }
      this.observer.disconnect()
    },

    expandChange(row, open) {
      row.__open = open
    },

    async getLoginInfo() {
      try {
        const role = await new Mgr().getRole()
        this.userName = role.profile.name
      } catch (e) {
        this.userName = ''
      }
    }
  },

  mounted() {
    this.init()
  },

  components: {
    TableLayout,
    DatePickerRange,
    SwitchBar,
    BackBtn,
    PaginationTool,
    Tab
  },

  beforeDestroy() {
    this.releaseResize()
  }
}

</script>
<style lang="less" scoped>
.statistics-pages{
  height: 100%;
}
</style>