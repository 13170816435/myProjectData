export const exportExcelWithHeader = async (dom, tableName = '', config = {}) => {
  const {
    title = '',
    exportTime = '',
    userName = '',
    needTitle = false
  } = config

  const tb = document.createElement('table')
  const rawTable = dom

  const thead = rawTable.querySelector('.el-table__header thead')
  const tbody = rawTable.querySelector('.el-table__body tbody')

  const _thead = thead.cloneNode(true)
  const _tbody = tbody.cloneNode(true)

  const trList = _tbody.querySelectorAll('tr')
  for (let tr of Array.from(trList)) {
    if (tr.style.display === 'none') {
      _tbody.removeChild(tr)
    }
  }

  tb.appendChild(_thead)
  tb.appendChild(_tbody)

  const tr = thead.querySelector('tr')
  const len = thead.querySelectorAll('tr').length

  if (needTitle) {
    const tdList = tr.querySelectorAll('th')
    const colNum = Array.from(tdList).reduce((total, td) => {
      const col = td.getAttribute('colspan')
      const colNum = Number(col)
      return total + colNum
    }, 0)

    const titleTr = document.createElement('tr')
    titleTr.innerHTML = `<td colspan='${colNum}'>${title}</td>`

    const subTitleTr = document.createElement('tr')
    subTitleTr.innerHTML = `<td colspan='${colNum}'>${exportTime}&nbsp;&nbsp;&nbsp;&nbsp;${userName}</td>`
    _thead.insertBefore(subTitleTr, _thead.children[0])
    _thead.insertBefore(titleTr, _thead.children[0])

    const XLSX = await import('xlsx-js-style')

    const sheet = XLSX.utils.table_to_sheet(tb, {raw: true})
    sheet['!cols'] = new Array(30).fill(null).map(_ => ({wpx: 120}))
    const trLen = len + 2
    for (let key in sheet) {
      if (!key.startsWith('!')) {
        const reg = /[^\d+](?<num>\d+)/
        const execRes = reg.exec(key)
        const colNum = Number(execRes.groups.num)

        if (colNum <= trLen) {
          if (key === 'A1') {
            sheet[key]['s'] = {
              font: {
                bold: true,
                sz: 20
              },
              alignment: {
                horizontal: 'center',
                vertical: 'center'
              }
            }
          } else if (key === 'A2') {
            sheet[key]['s'] = {
              font: {
                bold: true,
                sz: 16
              },
              alignment: {
                vertical: 'center',
              }
            }
          } else {
            sheet[key]['s'] = {
              font: {
                bold: true
              },
              alignment: {
                horizontal: 'center',
                vertical: 'center',
              }
            }
          }
        } else {
          sheet[key]['s'] = {
            alignment: {
              horizontal: 'center'
            }
          }
        }
      }
    }

    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, sheet, 'sheet1')
    XLSX.writeFile(wb, `${tableName}.xlsx`)
  } else {
    const XLSX = await import('xlsx-js-style')
    const sheet = XLSX.utils.table_to_sheet(tb, {raw: true})
    sheet['!cols'] = new Array(30).fill(null).map(_ => ({wpx: 120}))

    for (let key in sheet) {
      if (!key.startsWith('!')) {
        const reg = /[^\d+](?<num>\d+)/
        const execRes = reg.exec(key)
        const colNum = Number(execRes.groups.num)

        if (colNum <= len) {
          sheet[key]['s'] = {
            font: {
              bold: true
            },
            alignment: {
              horizontal: 'center',
              vertical: 'center',
            }
          }
        } else {
          sheet[key]['s'] = {
            alignment: {
              horizontal: 'center'
            }
          }
        }
      }
    }

    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, sheet, 'sheet1')
    XLSX.writeFile(wb, `${tableName}.xlsx`)
  }
}
