<template>
  <div class="f14" :class="isShowAll?'mb10':''" >
    <div class="row">
      <!-- <span style="white-space: nowrap;">筛选条件：</span> -->
      <div class="row">
        <i style="cursor: pointer;color:#6C89BB" v-if="isShowAllBtn"  @click="changeShowAll">{{isShowAll?'高级筛选∧':'高级筛选∨'}} </i>
        <div v-if="selectionItem.length>0" class="mb10 row flex_1">
          <div class="row flex_wrap">
            <div class="selectionItemTag" v-for="item in selectionItem"   :key="item.field_name" >{{item.field_name}}：{{item.name}} <i @click="handleTagClose(item)"  class=" ml5 el-icon-close"></i></div>
          </div>
          <div @click="clearAll" class="clearAllBtm">清空</div>
        </div>
      </div>
    </div>
    <div class="" v-show="isShowAll">
      <el-form
        ref="filterForm"
        style="padding-top: 10px !important;"
        size="small"
        @submit.native.prevent
        :model="value"
        class="filterForm"
        label-position="left"
        :inline="true"
        
      >
        <template v-for="item in searchList">
          <el-form-item
            v-if="item.field_type == FIELD_DISPLAY_TYPE.下拉框"
            :key="item.id+item.column_name"
            :label="item.field_name + '：'"
            :prop="item.column_name"
          >
            <el-select
              v-model="value[item.column_name]"
              placeholder="请选择"
              clearable
            >
              <el-option
                v-for="optionItem in OptionsData[item.column_name]"
                :key="optionItem.value"
                :label="optionItem.key"
                :value="optionItem.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            v-else-if="item.field_type == FIELD_DISPLAY_TYPE.下拉框多选"
            :key="item.id+item.column_name"
            :label="item.field_name + '：'"
            :prop="item.column_name"
          >
            <el-select
              v-model="value[item.column_name]"
              placeholder="请选择"
              collapse-tags
              filterable
              clearable
              multiple
            >
              <el-option
                v-for="optionItem in OptionsData[item.column_name]"
                :key="optionItem.value"
                :label="optionItem.key"
                :value="optionItem.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            v-else-if="item.field_type == FIELD_DISPLAY_TYPE.时间 || item.field_type == FIELD_DISPLAY_TYPE.日期"
            :key="item.id+item.column_name"
            :label="item.field_name + '：'"
            :prop="item.column_name"
          >
            <el-date-picker
              v-model="value[item.column_name]"
              type="daterange"
              :picker-options="pickerOptions"
              range-separator="——"
              start-placeholder="开始日期"
              format="yyyy-MM-dd"
              value-format="yyyy-MM-dd"
              end-placeholder="结束日期"
              align="right"
            />
          </el-form-item>
          <el-form-item
            v-else
            :key="item.id+item.column_name"
            :label="item.field_name + '：'"
            :prop="item.column_name"
          >
            <el-input
              v-model="value[item.column_name]"
              class="text"
              clearable
              @keyup.enter.native="handelSearch"
              :placeholder="'请输入' + item.field_name"
            />
          </el-form-item>
        </template>
      </el-form>
    </div>
  </div>
</template>

<script>
import {
  parseTime,
  getMonthTime,
  pickerOptions,
  FIELD_DATA_TYPE,
  FIELD_DISPLAY_TYPE,
} from "@/utils";
export default {
  props:{
    searchList:{
      type:Array,
      require:false,
      default:()=>[]
    },
    OptionsData:{
      type:Object,
      require:false,
      default:()=>[]
    },
    value: {
      type: Object,
      required: true
    },
    isShowAllBtn:{
      type:Boolean,
      default:true
    },
  },
  components:{},
  data(){
    return{
      isShowAll:false,
      FIELD_DISPLAY_TYPE: FIELD_DISPLAY_TYPE,
      FIELD_DATA_TYPE: FIELD_DATA_TYPE,
      pickerOptions: {
        shortcuts: pickerOptions,
      },
      selectionItem:[],
    }
  },
  watch:{
    value:{
      handler(){
        const list =[];
        this.searchList.forEach(element => {
          const {column_name,field_type,field_name} = element
          let valueName =``
          if(field_type === this.FIELD_DISPLAY_TYPE.下拉框多选){
            if(this.value[column_name] && this.value[column_name].length>0){
              const valNameList = []
              this.value[column_name].forEach(item=>{
                this.OptionsData[column_name].forEach(o=>{
                  if(o.value === item){
                    valNameList.push(o.key)
                  }
                })
              })
              valueName = valNameList.join(",")
            }
          }else if(field_type === this.FIELD_DISPLAY_TYPE.时间 ||field_type === this.FIELD_DISPLAY_TYPE.日期){
            if(this.value[column_name] && this.value[column_name].length>0){
              valueName = this.value[column_name].join(" ~ ")
            }
          }else if(field_type === this.FIELD_DISPLAY_TYPE.下拉框){
            if(this.value[column_name]){
              this.OptionsData[column_name].forEach(item=>{
                  if(item.value === this.value[column_name]){
                    valueName = item.key
                  }
                })
            }
          }else{
            if(this.value[column_name]){
              valueName = this.value[column_name]
            }
          }
          if(valueName){
            list.push({
              name:valueName,
              field_name,
              column_name,field_type
            })
          }
        });
        console.log('updateSearchselectionItem')
        this.$emit("changeShowAll")
        this.$emit("updateSearch")
        this.selectionItem = list
      },
      deep:true,
    }
  },
  created () {
  },
  methods: {
    changeShowAll(){
      this.isShowAll = !this.isShowAll
      this.$emit("changeShowAll")
    },
    clearAll(){
      for (const key in this.value) {
        this.value[key] = null;
      }
    },
    handleTagClose(tag){
      const {column_name} = tag
      this.value[column_name] = null
      this.$emit("DelTag")
    },
  }
}
</script>

<style lang="less" scoped>

.selectionItemTag{
  margin-right:10px;
  color: #909399;
  i{
    cursor: pointer;
  }
  &:after{
    content: '|';
    color: #F0F0F0;
    margin-left:10px;
  }
}
.selectionItemTag:last-child{
  &:after{
    content: '';
  }
}
.filterForm{
  background: #F8F8F8;
  padding: 10px 10px 0 10px ;
}
.clearAllBtm{
  color: #E6A23C;
  cursor: pointer;
  white-space: nowrap;
}
.settingIcon{
  position: absolute;
  left: -17px;
  font-size: 16px;
  top: 7px;
  cursor: pointer;
}
</style>
