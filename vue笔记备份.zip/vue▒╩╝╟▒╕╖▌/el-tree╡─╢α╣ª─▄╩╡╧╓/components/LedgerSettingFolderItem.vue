<template>
  <div v-loading="saveBtnStatue" class="settingContent">
    <el-form
      class="settingForm"
      ref="dataForm"
      :rules="formRules"
      :model="formData"
      label-position="right"
      size="small"
      label-width="auto"
    >
      <el-form-item label="所在目录：" prop="filePath">
        <el-cascader
          style="width:350px"
          v-model="formData.filePath"
          :options="parentOptions"
          :disabled='!(isAllowManage || isPerson)'
          :props="{ label:'name' ,value:'id',checkStrictly: true}"
        ></el-cascader>
      </el-form-item>
      <el-form-item label="文件夹名称：" prop="name">
        <el-input
          v-model="formData.name"
          clearable
          style="width:350px"
          :placeholder="`请输入文件夹名称`"
        />
      </el-form-item>
      <el-form-item label="备注：" prop="description">
        <el-input
          v-model="formData.description"
          placeholder="请输入描述"
          type="textarea"
          :maxlength="1024"
          show-word-limit
        />
      </el-form-item>
    </el-form>
    <div class="footBtn" >
      <el-button size="small" @click='resetChange' >取消</el-button>
      <el-button type="primary" :disabled="saveBtnStatue" :loading='btnLoading'
        size="small" @click="submit"
      >保存</el-button>
    </div>
  </div>
</template>

<script>
import { saveCategoryUpdate ,getLedgerCategoryTree } from '@/api/anymark/markcategory'
import * as webRequest from '@/api/anymark/qiniu'
export default {
  components:{
  },
  props: {
    categoryObj: {
      require: true,
      type: Object,
    },
    parentId:{
      type:String,
      require:false,
      default:''
    },
  },
  data(){
    return{
      btnLoading:false,
      parentOptions:[],
      formData:{
        filePath:[],
        name:'',
        description:'',
      },
      formRules: {
        // filePath: [
        //   { required: true, message: "请选择所在目录", trigger: "change" },
        // ],
        name: [{ required: true, message: "请输入姓名", trigger: "blur" }],
      },
      saveBtnStatue: true, // 保存按钮初始状态，防止连点
    }
  },
  computed:{
    isPerson(){
      return this.categoryObj.user_type === 1
    },
    isAllowManage(){
      //是否允许管理分类文件夹
      return this.$prm_codes.includes('ssj_ml_gl')
    },
  },
  watch: {
    "categoryObj.id": {
      async handler(n, o) {
        if (n) {
          this.ResetData();
          this.getDetailFn()
          this.saveBtnStatue = false
        }
      },
      deep: true,
      immediate:true,
    },
  },
  created(){
    this.fetchList();
  },
  methods:{
    async getDetailFn(){
      let categoryId = this.categoryObj.id
      if(['0_0','0_1'].includes(categoryId)){
        categoryId = 0
      }
      const { code,data,msg } = await webRequest.GetDetailById('category',categoryId)
      if (code === 0) {
        //赋值
          const path = data.category_path.split('/')
          //去除最后一个当前文件夹 就是目前所在的文件夹位置
          path.shift();
          path.pop();
          this.formData.filePath = path
          this.formData.name = data.name
          this.formData.description = data.description
      }else{  
        this.$message.error(msg);
      }
    },
    async submit(){
      //提交接口
      if(!this.formData.name){
        this.$message.warning('请输入文件夹名称');
        return
      }
      const params={
        id:this.categoryObj.id,
        name:this.formData.name,
        description:this.formData.description,
      }
      params.parent_id = this.formData.filePath[this.formData.filePath.length-1]
      this.btnLoading = true
      const { code,data,msg } = await saveCategoryUpdate(params)
      this.btnLoading = false
      if (code === 0) {
        this.$message.success('保存成功');
        this.$emit('updateTree')
      }else{
        this.$message.error(msg);
      }
    },
    resetChange(){
      this.ResetData();
      //赋值
      const path = this.categoryObj.path.split('/')
      //去除最后一个当前文件夹 就是目前所在的文件夹位置
      path.pop();
      this.formData.filePath = path
      this.formData.name = this.categoryObj.name
      this.formData.description = this.categoryObj.description
    },
    ResetData(){
      this.formData = {
        filePath:[],
        name:'',
        description:'',
      }
    },
    // 获取分类列表
    async fetchList() {
      const params={
        user_type: this.categoryObj.user_type,
        only_folder:1,//是否只查询文件夹 0否1是
        exclude_root_node_id:this.categoryObj.id,
      }
      this.btnLoading = true
      const { code,data,msg } = await getLedgerCategoryTree(params)
      this.btnLoading = false
      if (code === 0) {
        if(data && data.length>0){
          data[0].id = '0'
          //去除其他文件夹 目前使用场景为设备管理  只显示设备管理相关文件夹 固定为科室管理下级
          if(this.parentId && data[0].children){
            data[0].disabled = true
            data[0].children = data[0].children.filter(item=> item.id === this.parentId)
          }
          this.parentOptions = this.setEmptyChildrenToUndefined(this.removeNodesWithTempId(data))
        }else{
        
          this.parentOptions = []
        }
      }else{
        this.$message.error(msg);
      }
    },
     removeNodesWithTempId(treeData) {
      const processedData = [];
      for (const node of treeData) {
        //设备管理 只能移动到设备管理的文件夹下
        if(this.categoryObj.sub_business_type === 'EquipmentManage'){
          node.disabled = node.sub_business_type !=='EquipmentManage'
        }else{//反之 不允许选中设备管理
          node.disabled = node.sub_business_type ==='EquipmentManage'
        }
        if (!node.template_id) {
          const processedNode = { ...node };
          if (processedNode.children && processedNode.children.length > 0) {
            processedNode.children = this.removeNodesWithTempId(processedNode.children); // 递归处理子节点
          }
          processedData.push(processedNode);
        }
      }
      return processedData;
    },
    setEmptyChildrenToUndefined(treeData) {
      const processedData = [...treeData]; // 复制一份以保留原数据
      for (const node of processedData) {
        if (node.children && node.children.length === 0) {
          node.children = undefined; // 将 children 为空数组的节点的 children 设置为 undefined
        } else if (node.children && node.children.length > 0) {
          node.children = this.setEmptyChildrenToUndefined(node.children); // 递归处理子节点并赋值给当前节点的 children
        }
      }
      return processedData; // 返回处理后的数据
    },
  },
}
</script>

<style lang="less" scoped>
.settingContent{
  height: 100%;
  display: flex;
  flex-direction: column;
  .settingForm{
    flex: 1;
    overflow: auto;
  }
  .footBtn{
    padding-top: 10px;
    text-align: right;
  }
}

</style>