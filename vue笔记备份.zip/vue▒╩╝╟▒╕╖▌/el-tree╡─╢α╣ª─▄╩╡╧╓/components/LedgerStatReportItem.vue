<template>
  <div class="statContentMain">
    <div style="background: #fff;">
      <el-form
        ref="filterForm"
        size="small"
        @keyup.enter.native="handelSearch"
        @submit.native.prevent
        :model="searchForm"
        label-position="left"
        :inline="true"
        class="filterForm"
      >
        <el-form-item label="发布人：" prop="user_id">
          <el-select
            clearable
            v-model="searchForm.user_id"
            filterable
            placeholder="请选择"
          >
            <el-option
              v-for="item in publishUserList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
              <span style="float: left">{{ item.name }}</span>
              <span
                v-if="item.work_no"
                style="color: #8492a6; font-size: 13px"
                >（{{ item.work_no }}）</span
              >
            </el-option>
          </el-select>
        </el-form-item>
        <!-- <regionalDateItem v-model="searchForm.createTime" :labelName="['发布时间']"></regionalDateItem> -->
        <el-form-item label="发布时间：" >
          <dateRangePicker style="width:260px" v-model="searchForm.createTime" ></dateRangePicker>
        </el-form-item>
        <el-form-item>
          <el-button
            size="small"
            class="filter-item"
            type="primary"
            @click="handelSearch"
            >查询</el-button
          >
          <el-button
            size="small"
            class="filter-item"
            type="default"
            @click="handleReset"
            >重置</el-button
          >
          <el-button size="small" style="margin-left:0;padding-left: 10px;" class="filter-item" type="text" v-if="searchList.length>0" @click="clickShowAll" >{{isShowAll?'高级筛选':'高级筛选'}}<i :class="isShowAll?'el-icon-arrow-down':'el-icon-arrow-up'" ></i></el-button>
          <!-- <setDefaultItem ref="setDefaultItem" :presetList="presetList" @setDefault="setDefault" @dealConditionItem="dealConditionItem" @changeCondition="changeCondition" class="ml10"></setDefaultItem> -->
        </el-form-item>
          <el-button
            v-if="isAllowManage || isActiveAdminUser || categoryObj.permissions.includes(8)"
            class="fr"
            icon="el-icon-plus"
            type="warning"
            size="small"
            style="margin-left: 10px"
            @click="addTable"
            >统计表</el-button
          >
      </el-form>
      <filterSelectionitem ref="filterSelectionitem" v-if="searchList.length>0" :isShowAllBtn='false' @updateSearch='handelSearch' v-model="searchData" :searchList='searchList' :OptionsData='OptionsData'></filterSelectionitem>
    </div>
    <div class="reportContent" >
      <template v-if="defineList.length>0">
        <div v-for="(item,index) in defineList" :key="item.stat_id" class="reportContentItem">
          <div class="reportContentItemMain">
            <div class="row space_between">
              <div class="mb10">
                <span class="strong mr10 f15" >{{item.stat_name}}</span>
              </div>
              <div>
                <i v-if="isAllowManage || isActiveAdminUser || categoryObj.permissions.includes(8)" @click="delItem(item)"  class="mr10 el-icon-delete cursor strong clr_red"></i>
                <span v-if="isAllowManage || isActiveAdminUser || categoryObj.permissions.includes(8)" ><i @click="editItem(item)" class="el-icon-my-statEdit cursor"></i></span>
              </div>
            </div>
            <template v-if="item.fields_valid">
              <el-table class="flex_1" ref="dataTable" :data="item.dataList" :key="tableKey+index" row-key="name" fit border stripe >
                <el-table-column type="index" fixed="left" align="center" width="50" label="序号">
                  <template slot-scope="scope">
                    <span>{{ (item.pagination.page_index - 1) * item.pagination.page_size + scope.$index + 1 }}</span>
                  </template>
                </el-table-column>
                <el-table-column v-for="(colum,i) in item.fields" :key="colum.field_name+index" :label="colum.display_name" :width="(i === item.fields.length-1)?'':'80'"  :prop="colum.field_name" ></el-table-column>
              </el-table>
              <Pagination
                :total="item.pagination.total"
                :page.sync="item.pagination.page_index"
                :limit.sync="item.pagination.page_size"
                :hideSingle="true"
                @pagination="(pageInfo)=>{handleCurrentChange(pageInfo,item,index)}"
              ></Pagination>
            </template>
            <div class="emptyImg1 flex_1" v-else>
                <div>
                    <img src="@/assets/images/common/NoData.png"/>
                    <div class="emptyImg_text" >存在统计字段被删除，无法显示，您可以调整或删除该统计报表</div> 
                </div>
            </div>

          </div>
        </div>
      </template>
      <div class="emptyImg flex_1" v-else>
          <div>
              <img src="@/assets/images/common/NoData.png"/>
              <div class="emptyImg_text" >当前无统计报表，请点击新增</div> 
          </div>
      </div>
    </div>
    <reportItem v-if="isShowReportItem" :detailId='editId' :categoryId='categoryObj.id' :templateId='currentTemplateId' @updateDate='updateDate' @closeDialog='closeDialog' ></reportItem>
  </div>
</template>

<script>
import { getUsersLite } from "@/api/department/commonHttp";
import {GetDetailById,getStatDefineList,getStatPageData,delAnymarkStatDefine,getStatCategoryList} from "@/api/anymark/qiniu";
import { FieldSourceDataList } from "@/api/anymark/marktemplatefield";
import { addCategorySearch,categorySearchSetDefault,delCategorySearch,categorySearchList } from "@/api/anymark/markcontent";
import setDefaultItem from "@/views/departManage/item/setDefaultItem"
import { getItemList } from "@/api/dictionary";
import reportItem from "@/views/statReport/components/reportItem";
import Pagination from "@/components/Pagination";
import { pickerOptions, FIELD_DATA_TYPE, FIELD_DISPLAY_TYPE, } from "@/utils";
import filterSelectionitem from "@/views/LedgerManage/components/filterSelectionitem"
export default {
    components:{setDefaultItem,reportItem,Pagination,filterSelectionitem},
    props:{
      categoryObj:{
        type:Object,
        require:true,
      },
      isActiveAdminUser:{
        require:true,
        type:Boolean
      },
    },
    data(){
      return{
        activeName:"",
        tabList:[],
        isEmpty:false,
        searchForm: {
          user_id: "",
          searchFieldList: [], // 查询条件字段
          createTime: [],
        },
        searchList:[],
        searchData:{},
        OptionsData: {},
        isFirstIn:true,
        presetObj:{},
        presetList:[],
        currentTemplateId:'',
        publishUserList:[],
        FIELD_DISPLAY_TYPE: FIELD_DISPLAY_TYPE,
        FIELD_DATA_TYPE: FIELD_DATA_TYPE,
        pickerOptions: {
          shortcuts: pickerOptions,
        },
        isShowReportItem:false,
        defineList:[],
        editId:'',
        tableKey:'11',
        isShowAll:false,
      }
    },
    watch:{
      categoryObj:{
        handler(){
          this.activeName = this.categoryObj.id
          this.changeCategory()
        },
        deep:true,
        immediate:true,
      }
    },
    computed:{
      isAllowManage(){
      //是否允许管理分类文件夹 新增 移动 重命名 启用停用等
        return this.$prm_codes.includes('ssj_ml_gl')
      },
    },
    created(){
      this.getUsersLiteFn();
    },
    methods:{
      clickShowAll (){
        this.isShowAll = !this.isShowAll
        this.$refs.filterSelectionitem.changeShowAll()
      },
      async delItem(item){
        try {
          await this.$confirm(`是否删除【${item.stat_name}】?`, "删除",{customClass: 'confirm-dialog--ew',});
        } catch (error) {
          return;
        }
        const {code, data,msg } = await delAnymarkStatDefine(item.stat_id);
        if(code === 0){
          this.$message.success('删除成功')
          this.getStatDefineListFn()
        }else{
          this.$message.error(msg)
        }
      },
      editItem(item){
        this.editId = item.stat_id
        this.isShowReportItem = true
      },
      closeDialog(){
        this.editId=''
        this.isShowReportItem = false
      },
      updateDate(){
        // 重新查询
        this.getStatDefineListFn()
        this.editId=''
        this.isShowReportItem = false
      },
      async getStatPageDataFn(pageInfo,id,index){
        const params = {
          page_index :pageInfo.page_index,
          page_size :pageInfo.page_size,
          statistic_id:id,
        };
        const searchParams =  Object.assign({}, this.searchData);
        if (this.searchForm.createTime.length > 0) {
          searchParams.create_time = [this.searchForm.createTime[0]?this.searchForm.createTime[0]:'',this.searchForm.createTime[1]?this.searchForm.createTime[1]:''];
          searchParams.create_user_id = this.searchForm.user_id;
        }
        params.search_params = searchParams;

        const {code, data,msg,page } = await getStatPageData(params);
        if(code === 0){
           this.$set(this.defineList[index],'dataList',data)
           const {total_count} = page
           this.$set(this.defineList[index].pagination,'total',total_count)
        }else{
          this.$message.error(msg)
        }
      },
      handleCurrentChange(pageInfo,item,index) {
        if (pageInfo) {
          this.$set(this.defineList[index].pagination,'page_index',pageInfo.page)
          this.$set(this.defineList[index].pagination,'page_size',pageInfo.limit)
        }
        //根据分页信息 与id查询对应详情
        this.getStatPageDataFn(this.defineList[index].pagination,item.stat_id,index)
      },
      async getStatDefineListFn(){
        const params = {
          category_id :this.categoryObj.id
        };
        const {code, data,msg } = await getStatDefineList(params);
        if(code === 0){
          if(data){
            data.forEach((item,i)=>{
              //每个都有一个分页
              item.pagination= {
                page_index: 1,
                page_size: 10,
                total: 0,
              }
              if(item.fields_valid){
                this.getStatPageDataFn(item.pagination,item.stat_id,i)
              }
            })
            this.tableKey = new Date().getTime()
            this.defineList = data
          }else{
            this.defineList = []
          }
        }else{
          this.$message.error(msg)
        }
      },
      addTable(){
        this.isShowReportItem = true
      },
      handelSearch(){
        this.defineList.forEach((item,i)=>{
          const pagination= {
            page_index: 1,
            page_size: 10,
            total: 0,
          }
          this.$set(this.defineList[i],'pagination',pagination)
          this.getStatPageDataFn(item.pagination,item.stat_id,i)
        })
      },
      async getUsersLiteFn() {
        const params = {
          // institution_id: user.profile.inst_id,
          // office_id: user.profile.office_id,
          // business_system_id:sessionStorage.getItem("lastname"),
          // business_system_type:'dms',
        };
        //科室管理与 pacs项目查询用户传参不同
        if(this.$currentSystemClass === 'DMS_RIS'){
          params.business_system_id = sessionStorage.getItem("lastname")
          params.business_system_type = "dms"
        }else{
          params.system_id = sessionStorage.getItem("lastname")
        }
        const { data } = await getUsersLite(params);
        this.publishUserList = data;
      },
      handleReset() {
        this.setDate();
        // this.searchForm.createTime=[];
        this.searchForm.user_id = "";
        this.searchParams = [];

        this.searchList.forEach((item, index, array) => {
            this.$set(this.searchData, item.column_name, null);
          });

        // //重置为第一次查询
        this.isFirstIn = true;
        //并且重置 查询项为默认查询项
        this.presetObj = {};
        this.presetList.forEach(item=>{
          if(item.is_default){
            this.presetObj = item.search_content;
            //设置显示默认值
            this.$refs.setDefaultItem.currentSetObj = item;
          }
        })
        this.fetchCatgoryData();
      },
      async setDefault(val){
        const params={
          category_id:this.categoryObj.id,
          title:val,
        }
        let searchObj ={
          createTime:this.searchForm.createTime,
          user_id:this.searchForm.user_id,
        };
        searchObj =  Object.assign(searchObj, this.searchData);
        params.search_content =JSON.stringify(searchObj) 
        const {code} = await addCategorySearch(params);
        if(code === 0){
          this.$message.success("添加成功")
          this.getPresetList();
          this.$refs.setDefaultItem.isShowSetItem = false;
        }
      },
      dealConditionItem(item){
        //1设为默认 2取消默认 0 删除
        if(item.type){
          this.categorySearchSetDefaultFN(item.id,item.type)
        }else{
          this.delCategorySearchFn(item.id)
        }
      },
      async delCategorySearchFn(id){
        const {code} = await delCategorySearch(id);
        if(code === 0){
          this.$message.success("删除成功")
          this.getPresetList();
        }
      },
      async categorySearchSetDefaultFN(id,type){
        const {code} = await categorySearchSetDefault(id,{is_default:type===1?1:0});
        if(code === 0){
          this.$message.success("设置成功")
          this.getPresetList();
        }
      },
      changeCondition(item){
        this.isFirstIn = true;
        const search_content = item.search_content;
        const {createTime,user_id } = search_content
        //给固定项赋值
        this.searchForm.createTime = createTime?createTime:[]
        this.searchForm.user_id = user_id?user_id:''
        //给动态项赋值
        this.searchList.forEach((key) => {
          const defultVal = search_content[key.column_name]?search_content[key.column_name]:null
          this.$set(this.searchData, key.column_name, defultVal);
        });
        this.presetObj = search_content;
        this.fetchList();
      },
      setDate() {
        let dayTime = new Date(); //获取当前标准时间
        let lastY1 = dayTime.getFullYear();
        let lastM1 = dayTime.getMonth() + 1;
        let lastD1 = dayTime.getDate();
        var datetime =
          lastY1 +
          "-" +
          (lastM1 < 10 ? "0" + lastM1 : lastM1) +
          "-" +
          (lastD1 < 10 ? "0" + lastD1 : lastD1); //转换为yy-mm-dd格式

        let lw = new Date(dayTime - 1000 * 60 * 60 * 24 * 30);
        let lastY = lw.getFullYear();
        let lastM = lw.getMonth() + 1;
        let lastD = lw.getDate();
        let startThirtydate =
          lastY +
          "-" +
          (lastM < 10 ? "0" + lastM : lastM) +
          "-" +
          (lastD < 10 ? "0" + lastD : lastD); //三十天之前日期
        this.searchForm.createTime = [startThirtydate, datetime];
      },
      ResetData() {
        this.setDate();
        this.searchForm.user_id = "";
        this.searchList = [];
        this.searchData = {};
        this.defineList = [];
        //重置预查询项
        this.isFirstIn = true;
        this.presetObj = {}
        this.presetList = [];
      },
      changeCategory(){
        this.ResetData();
        //先获取预设列表
        this.$nextTick(async()=>{
          // await this.getPresetList();
          this.fetchCatgoryData();
        })
      },
      async getPresetList(){
        const params = {
          category_id:this.activeName,
        }
        //清空初始值
        this.presetObj = {};
        this.$refs.setDefaultItem.currentSetObj = {};
        const {code, data} = await categorySearchList(params)
        if(code === 0){
          //获取预设列表 
          data.forEach(item=>{
            const {search_content,is_default} = item;
            item.search_content = JSON.parse(search_content)
            if(is_default){
              this.presetObj = item.search_content;
              //设置显示默认值
              this.$refs.setDefaultItem.currentSetObj = item;
            }
          })
          this.presetList = data;
        }
      },
      // 分类同步查询
      async fetchCatgoryData() {
        this.loading = true;
        // 判断分类是否为个人分类
        //是否有预设表 并且为第一次进入 并且有设置默认预设
          if(this.presetList && this.presetList.length>0 && this.isFirstIn && Object.keys(this.presetObj).length > 0){
          const {createTime,user_id } = this.presetObj
            //给固定项赋值
            this.searchForm.createTime = createTime?createTime:[]
            this.searchForm.user_id = user_id?user_id:''
            this.fetchTemplateData();
          }else{
            
            this.fetchTemplateData();
          }
      },
      // 模板详情查询
      fetchTemplateData() {
        GetDetailById("customtemplate", this.categoryObj.template_id)
          .then((response) => {
            const { code, data } = response;
            if (code === 0) {
             
              this.searchForm.searchFieldList = [];
              this.currentTemplateId = data.id;

              // 过滤默认展示的列，若是没有设置，则默认显示全部列
              const filterfieldList = data.field_list.filter(
                (x) =>
                  x.is_display_column === 1 &&
                  x.is_related_business !== 1 &&
                  x.field_type !== FIELD_DISPLAY_TYPE.图片上传
              );
              const fieldColumnList =
                filterfieldList.length > 0 ? filterfieldList : data.field_list;
              this.getOptionsData(
                fieldColumnList.filter(
                  (x) => (x.field_type === FIELD_DISPLAY_TYPE.下拉框 || x.field_type === FIELD_DISPLAY_TYPE.下拉框多选)
                )
              );

              // 查询区域条件
              this.searchList = data.field_list.filter(
                (x) =>
                  x.is_search_field === 1 &&
                  x.is_related_business !== 1 &&
                  x.field_type !== FIELD_DISPLAY_TYPE.图片上传
              );
              this.searchList.forEach((item, index, array) => {
                if(this.isFirstIn){
                  //根据预查询项设置默认值
                  const defultVal = this.presetObj[item.column_name]?this.presetObj[item.column_name]:null
                  this.$set(this.searchData, item.column_name, defultVal);
                }else{
                  this.$set(this.searchData, item.column_name, null);
                }
              });
              this.fetchList();
            }
          })
          .catch((e) => {
            this.loading = false;
          });
      },
      async fetchList() {
        this.getStatDefineListFn()
      },
      // 下拉列表数据
      getOptionsData(selectFieldList) {
        if (selectFieldList) {
          selectFieldList.forEach((item, index, array) => {
            //    取数据源
            if (item.bind_source && item.bind_source.table.length > 0) {
              FieldSourceDataList({ field_id_list: [item.id] }).then((res) => {
                if (res.code === 0) {
                  const arr = res.data[0].sourceData.map((x) => {
                    return {
                      key: x.key,
                      value:
                        item.data_type === FIELD_DATA_TYPE.整数
                          ? parseInt(x.value)
                          : item.data_type === FIELD_DATA_TYPE.小数
                          ? parseFloat(x.value)
                          : x.value,
                    };
                  });

                  this.$set(this.OptionsData, item.column_name, arr);
                }
              });
            } else if (item.dic_code) {
              //获取字典选项
              this.getItemListFn(item);
            } else {
              if (
                item.dictionary_item_list &&
                item.dictionary_item_list.length > 0
              ) {
                const arr = item.dictionary_item_list.map((x) => {
                  return {
                    key: x.dict_key,
                    value:
                      item.data_type === FIELD_DATA_TYPE.整数
                        ? parseInt(x.dict_value)
                        : item.data_type === FIELD_DATA_TYPE.小数
                        ? parseFloat(x.dict_value)
                        : x.dict_value,
                  };
                });
                this.$set(this.OptionsData, item.column_name, arr);
              }
            }
          });
        }
      },
      async getItemListFn(item) {
        let params = {
          // category_code: item.dic_code,
          dic_type_code: item.dic_code,
        };
        const { data } = await getItemList(params);
        data.forEach((item) => {
          item.key = item.dic_define_value;
          item.value = item.dic_define_code;
        });
        this.$set(this.OptionsData, item.column_name, data);
      },
    },
}
</script>
<style lang="less" scoped>
.statContentMain{
  display: flex;
  flex-direction: column;
  height: 100%;
  background: #EBEEF5;
  .reportContent{
    flex: 1;
    overflow: auto;
  }
}
.emptyImg{
    text-align: center;
    margin-top: 200px;
    .emptyImg_text{
        margin-top: 15px;
        color: #909399;
    }
}
.emptyImg1{
    text-align: center;
    margin-top: 10%;
    .emptyImg_text{
        margin-top: 15px;
        color: #909399;
    }
}
::v-deep .el-tabs__nav-scroll{
  margin-top: -10px;
}
::v-deep .el-tabs__nav-prev{
    margin-top: -10px;
}
::v-deep .el-tabs__nav-next{
    margin-top: -10px;
}
::v-deep .el-tabs--top .el-tabs__item.is-top:last-child {
    padding-right: 10px;
}

.publicTabs{
    margin-bottom: 10px;
}
.reportContent{
  display: flex;
  flex-wrap: wrap;
  padding:5px;
  .reportContentItem{
    flex: 1;
    min-width: 50%;
    box-sizing: border-box;
    padding: 5px 5px 5px 5px;
    display: flex;
    flex-direction: column;
    background: #EBEEF5;
    .reportContentItemMain{
      padding: 10px 10px 0 10px;
      background: #fff;
      display:flex;
      flex-direction:column;
      justify-content: space-between;
      height: 100%;
    }
  }
}
.el-icon-my-statEdit{
  background: url(../../../assets/images/common/myStatEdit.png) center no-repeat;
  background-size: cover;
}
.el-icon-my-statEdit:before{
  content: "\e611";
  font-size: 14px;
  visibility: hidden;
}
</style>