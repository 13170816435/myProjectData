<template>
  <div class="f14">
    <div class="row mb10">
      <!-- <span style="white-space: nowrap;">筛选条件：</span> -->
      <div class="row">
        <i style="cursor: pointer;color:#6C89BB" @click="changeShowAll">{{isShowAll?'高级筛选∧':'高级筛选∨'}} </i>
        <div v-if="selectionItem.length>0" class=" ml10 row flex_1">
          <div class="row flex_wrap">
            <div class="selectionItemTag" v-for="item in selectionItem"   :key="item.id" >{{keyMap[item.key]}}：{{item.name}} <i @click="handleTagClose(item)"  class=" ml5 el-icon-close"></i></div>
          </div>
          <div @click="clearAll" class="clearAllBtm">清空</div>
        </div>
      </div>
    </div>
    <div class="" v-show="isShowAll">
      <el-form
        ref="filterForm"
        size="small"
        @submit.native.prevent
        :model="value"
        class="filterForm"
        label-position="left"
        :inline="true"
        
      >
        <el-form-item label="发起人：" v-if="isShowApplyUser" prop="publishUser">
            <el-select
              v-model="value.publishUser"
              filterable
              clearable 
              placeholder="请选择"
            >
              <el-option
                v-for="item in groupMemberList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
                <span style="">{{ item.name }}</span>
                <span
                  v-if="item.work_no"
                  style="color: #8492a6; font-size: 13px"
                  >( {{ item.work_no }} )</span
                >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="状态：" prop="form_states">
            <el-select
              v-model="value.form_states"
              filterable
              clearable 
              placeholder="请选择"
            >
              <el-option
                v-for="item in formStateList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="业务类型：" prop="business_sub_type_path">
            <el-cascader
              v-model="value.business_sub_type_path"
              :options="tabList"
              clearable 
              :props="{ label:'name' ,value:'path',checkStrictly: true}"
            ></el-cascader>
          </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import {getAllTenancies} from "@/api/department/user";
import {getRelationTree} from "@/api/workflow";
export default {
  props:{
    value: {
      type: Object,
      required: true
    },
    isShowApplyUser:{
      require:false,
      type:Boolean,
      default:true
    }
  },
  components:{},
  data(){
    return{
      keyMap:{
        publishUser:'发起人',
        form_states:'状态',
        business_sub_type_path:'业务类型',
      },

      isShowAll:false,
      formStateList:[//申请单状态（-1：草稿箱；0：通过；1：驳回；2：待审核；3：作废；4：发起）
        // { name:"草稿", id:-1 },
        { name:"归档", id:'0' },
        { name:"终止", id:'1' },
        { name:"待处理", id:'2'},
        { name:"删除", id:'99'},
      ],
      businessTypeList:[
        { name:"随手记", id:10 },
      ],
      groupMemberList: [],
      tabList:[],
    }
  },
  computed:{
    flatTreeList(){//拍平的树列表
      return this.flatData(this.tabList);
    },
    selectionItem(){
      const list =[];
      for (const key in this.value) {
        if(key === 'form_states' && (this.value[key] || this.value[key] ===0)){
          const  selectionData = this.formStateList.find(item=> item.id === this.value[key])
          selectionData.key = 'form_states'
          list.push(selectionData)
        }
        if(key === 'publishUser' && this.value[key] && this.isShowApplyUser){
          const  selectionData = this.groupMemberList.find(item=> item.id === this.value[key])
          selectionData.key = 'publishUser'
          list.push(selectionData)
        }
        if(key === 'business_sub_type_path' && this.value[key].length>0 ){
          const path = this.value[key][this.value[key].length-1];
          const  selectionData = this.flatTreeList.find(item=> item.path === path)
          selectionData.key = 'business_sub_type_path'
          list.push(selectionData)
        }
      }
      this.$emit("changeShowAll")
      // this.$emit("updateSearch")
      return list
    },
  },
  created () {
    this.getUsersLiteFn(1);
    this.getRelationTreeFn();
  },
  methods: {
    //获取审批关联分类树
    async getRelationTreeFn () {
        const params={
          user_type:0,
        }
        const {data} = await getRelationTree(params);
        if(data && data.length>0){
          this.tabList = this.dealTreeData(data);
        }else{
          this.tabList = []
        }
    },
    //解决el-cascader控件 最后一级暂无数据仍然显示。
    dealTreeData(data){
      for(let i=0; i<data.length; i++){
        if(!data[i].children || data[i].children.length<1){
          // children 若为空数组，则将 children 设为undefined
          data[i].children = undefined;
        }else {
          // children 若不为空数组，则继续 递归调用 本方法
          this.dealTreeData(data[i].children);
        }
      }
      return data;
    },
    flatData(data){
      return data.reduce((prev, curr) => {
        prev.push(curr);
        if (curr.children && curr.children.length > 0) {
          prev.push(...this.flatData(curr.children));
        }
        return prev;
      }, []);
    },
    async getUsersLiteFn(page) {
      const params = {
        offset: page,
        limit: 100,
        state: 1,
        };
      //科室管理与 pacs项目查询用户传参不同
      if(this.$currentSystemClass === 'DMS_RIS'){
        params.business_system_id = sessionStorage.getItem("lastname")
        params.business_system_type = "dms"
      }else{
        params.system_id = sessionStorage.getItem("lastname")
      }
      const { data } = await getAllTenancies(params);
      if (data.length > 0) {
        data.forEach((element) => {
          this.groupMemberList.push(element);
        });
        if (data.length === 100) {
          this.getUsersLiteFn(page + 1);
        }
      }
    },
    changeShowAll(){
      this.isShowAll = !this.isShowAll
      this.$emit("changeShowAll")
    },
    clearAll(){
      for (const key in this.value) {
        if(this.value[key] instanceof Array){
          this.value[key] = [];
        }else{
          this.value[key] = null;
        }
      }
    },
    handleTagClose(tag){
      const {key} = tag
      if(this.value[key] instanceof Array){
        this.value[key] = [];
      }else{
        this.value[key] = null;
      }
      this.$emit("DelTag")
    },
  }
}
</script>

<style lang="less" scoped>

.selectionItemTag{
  margin-right:10px;
  color: #909399;
  i{
    cursor: pointer;
  }
  &:after{
    content: '|';
    color: #F0F0F0;
    margin-left:10px;
  }
}
.selectionItemTag:last-child{
  &:after{
    content: '';
  }
}
.filterForm{
  background: #F8F8F8;
  padding: 10px 10px 0 10px;
}
.clearAllBtm{
  color: #E6A23C;
  cursor: pointer;
  white-space: nowrap;
}
.settingIcon{
  position: absolute;
  left: -17px;
  font-size: 16px;
  top: 7px;
  cursor: pointer;
}
</style>
