<template>
  <el-dialog
    :title="`移动【${dealNode.name}】到`"
    :visible.sync="dialogVisible"
    width="500px"
    :before-close="close"
    append-to-body
    v-el-drag-dialog
    :close-on-click-modal="false"
    >
    <el-form
      ref="filterForm"
      size="small"
      :model="formData"
      class="filterForm"
      label-width="auto"
    >
      <el-form-item label="选择目录：" prop="filePath">
        <el-cascader
          style="width:100%"
          v-model="formData.filePath"
          :options="parentOptions"
          :props="{ label:'name' ,value:'id',checkStrictly: true}"
        ></el-cascader>
      </el-form-item>
    </el-form>
    <div class="row space_between mt10">
      <div></div>
      <div>
        <el-button size="small" class="submitButtons" @click="close">关闭</el-button>
        <el-button size="small" class="submitButtons" type="primary" :loading="btnLoading"  @click="submit"   >确定</el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script>
import { saveCategoryMove ,getLedgerCategoryTree } from '@/api/anymark/markcategory'
export default {
  props:{
    parentId:{
      type:String,
      require:false,
      default:''
    },
    dealNode:{
      type:Object,
      require:true,
    }
  },
  created(){
    this.fetchList()
  },
  data(){
    return{
      dialogVisible:true,
      btnLoading:false,
      parentOptions:[],
      formData:{
        filePath:[],
      },
    }
  },
  methods:{
    async submit(){
      //移动提交接口
      const params={
        id: this.dealNode.id,
      }
      if(this.formData.filePath.length>0){
        params.target_id = this.formData.filePath[this.formData.filePath.length-1]
      }
      this.btnLoading = true
      const { code,data,msg } = await saveCategoryMove(params)
      this.btnLoading = false
      if (code === 0) {
        this.$message.success('移动成功')
        this.$emit('updatePage')
      }else{
        this.$message.error(msg);
      }
    },
    // 获取分类列表
    async fetchList() {
      const params={
        user_type: this.dealNode.user_type,
        exclude_root_node_id:this.dealNode.id,
        only_folder: 1
      }
      this.btnLoading = true
      const { code,data,msg } = await getLedgerCategoryTree(params)
      this.btnLoading = false
      if (code === 0) {
        if(data && data.length>0){
          //去除其他文件夹 目前使用场景为设备管理  只显示设备管理相关文件夹 固定为科室管理下级
          if(this.parentId && data[0].children){
            data[0].disabled = true
            data[0].children = data[0].children.filter(item=> item.id === this.parentId)
          }
          this.parentOptions = this.setEmptyChildrenToUndefined(this.removeNodesWithTempId(data))

        }else{
        
          this.parentOptions = []
        }
      }else{
        this.$message.error(msg);
      }
    },
     removeNodesWithTempId(treeData) {
      const processedData = [];
      for (const node of treeData) {
        //设备管理 只能移动到设备管理的文件夹下
        if(this.dealNode.sub_business_type === 'EquipmentManage'){
          node.disabled = node.sub_business_type !=='EquipmentManage'
        }else{//反之 不允许选中设备管理
          node.disabled = node.sub_business_type ==='EquipmentManage'
        }
        if (!node.template_id) {
          const processedNode = { ...node };
          if (processedNode.children && processedNode.children.length > 0) {
            processedNode.children = this.removeNodesWithTempId(processedNode.children); // 递归处理子节点
          }
          processedData.push(processedNode);
        }
      }
      return processedData;
    },
    setEmptyChildrenToUndefined(treeData) {
      const processedData = [...treeData]; // 复制一份以保留原数据
      for (const node of processedData) {
        if (node.children && node.children.length === 0) {
          node.children = undefined; // 将 children 为空数组的节点的 children 设置为 undefined
        } else if (node.children && node.children.length > 0) {
          node.children = this.setEmptyChildrenToUndefined(node.children); // 递归处理子节点并赋值给当前节点的 children
        }
      }
      return processedData; // 返回处理后的数据
    },
    close(){
      this.$emit('closeDialog')
    },
  },
}
</script>

<style>

</style>