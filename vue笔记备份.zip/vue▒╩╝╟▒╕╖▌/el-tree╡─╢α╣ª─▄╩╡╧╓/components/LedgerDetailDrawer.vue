<template>
  <el-drawer
    class="widthhandle"
    ref="exeDrawer"
    :with-header="false"
    size="100%"
    :visible.sync="dialogVisible"
    :modal="false"
    append-to-body
    :modal-append-to-body='false'
  >
    <div class="drawerContent">
      <template v-if="business_type === 10">
        <!-- <categoryDetail
          ref="categoryDetail"
          :isWGC ="anymarkObj.isWGC"
          :fieldList="anymarkObj.fieldList"
          :optionsData="anymarkObj.optionsData"
          :selectId="anymarkObj.contentId"
          :templateId="anymarkObj.templateId"
        /> -->
        <LedgerContentItem
          @backToList="backToList"
          @closeItem="backToList"
          :contentid="anymarkObj.contentId"
          :templateId="anymarkObj.templateId"
          :viewMode='1'
        ></LedgerContentItem>
      </template>
    </div>
    <div class="closeButton" @click="closeDrawer">
      <span style="font-size: 12px" class="icon iconfont icon-caidan"></span>
      收起
    </div>
  </el-drawer>
</template>

<script>
import categoryDetail from '@/views/LedgerManage/components/categoryDetail.vue'
import LedgerContentItem from "@/views/LedgerManage/components/anymarkCompent/LedgerContentItem";
export default {
  components:{
    categoryDetail,LedgerContentItem
  },
  props: {
    anymarkObj:{type:Object,require:false,default:()=>{
      return {
        isWGC:false,
        fieldList:[],
        optionsData:{},
        contentId:'',
        templateId:'',
      }
    } },
    business_type: { type: Number, require: true},
  },
  created(){
  },
  data() {
    return {
      dialogVisible: true,
    }
  },
  mounted() {
    // box-shadow: -10px 10px 10px #909399;
    setTimeout(() => {
      $(".widthhandle").css("box-shadow", "#0000001a -4px 0px 20px 0px");
    }, 300);
  },
  methods:{
    closeDrawer() {
      this.$emit("closeDrawer");
    },
    backToList() {
      this.$emit("backToList");
    },
  },
}
</script>

<style lang="less" scoped>
.drawerContent{
  // padding: 30px 30px 30px 36px;
  box-sizing: border-box;
  color: #303133;
  overflow: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%;
  font-size: 14px;
}
.contentMain{
  padding: 15px 20px;
  display: flex;
  flex-direction: column;
  flex: 1;
  overflow: auto;
  box-sizing: border-box;
  .contentLeft{
    
  }
  .contentRight{
    .timelineMain{  
      padding-right: 10px;
    }
    .timelinePartTitle{
        font-size: 16px;
        color: #28354C;
        margin-bottom: 15px;
        font-weight: bold;
    }
  }
}
.contentFoot{
  /deep/.footButtons{
    width: 100%;
    margin-left: 0;
    margin-bottom: 0;
    padding: 10px 20px;
    box-sizing: border-box;
  }
}
//修改滚动条样式
.contentMain::-webkit-scrollbar-track-piece {
  background-color: #f8f8f800;
}
.contentMain::-webkit-scrollbar {
  width: 6px;
  transition: all 2s;
}
.contentMain::-webkit-scrollbar-thumb {
  background-color: #dddddd;
  border-radius: 100px;
}
.contentMain::-webkit-scrollbar-thumb:hover {
  background-color: #bbb;
}
.contentMain::-webkit-scrollbar-corner {
  background-color: rgba(255, 255, 255, 0);
}
.widthhandle {
  width: 50%;
  z-index: 2000;
}
.closeButton {
  position: absolute;
  top: 43%;
  width: 30px;
  padding: 50px 5px;
  font-size: 14px;
  // border: 1px solid #fff;
  background: #0a70b01a;
  color: #0A70B0;
  font-weight: bold;
  border-radius: 0 20px 20px 0px;
  cursor: pointer;
  &:hover {
    background: #d9e6ef;
  }
}
</style>