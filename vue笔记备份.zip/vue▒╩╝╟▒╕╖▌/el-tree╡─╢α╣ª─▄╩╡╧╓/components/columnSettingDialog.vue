<template>
  <el-dialog
    title="列表显示设置"
    :visible.sync="dialogVisible"
    width="800px"
    :before-close="close"
    append-to-body
    v-el-drag-dialog
    :close-on-click-modal="false"
    >
    <el-table
      ref="dragTable"
      row-key="field_name"
      :height="500"
      stripe
      :header-cell-style="{ 'text-align': 'center' }"
      :data="filterFieldList"
      border
      fit
      highlight-current-row
    >
      <el-table-column
        type="index"
        align="center"
        label="序号"
        width="60"
      />
      <el-table-column label="显示" prop="field_name" width="80px" align="center">
        <template slot-scope="scope">
          <el-switch :disabled='isSearchDisabled(scope.row)' :active-value="1" :inactive-value='0' v-model="scope.row.is_display_column"></el-switch> 
        </template>
      </el-table-column>
      <el-table-column label="名称" prop="field_name" align="left">
        <template slot-scope="scope">
          <span>{{ scope.row.field_name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="输入方式" width="130px" prop="field_type" align="left">
        <template slot-scope="scope">
          <span>{{ getFieldTypeName(scope.row.field_type) }}</span>
        </template>
      </el-table-column>
    </el-table>
    <div class="clr_orange mt10">
      注意：文件上传、图片上传、视频、富文本等类型，不允许设置为列表显示项
    </div>
    <div class="row space_between mt10">
      <div></div>
      <div>
        <el-button size="small" class="submitButtons" @click="close">关闭</el-button>
        <el-button size="small" class="submitButtons" type="primary" :loading="btnLoading"  @click="batchSaveFieldList"   >确定</el-button>
      </div>
    </div>
    
  </el-dialog>
</template>

<script>
import { FIELD_DATA_TYPE, FIELD_DISPLAY_TYPE } from "@/utils";
import Sortable from "sortablejs";
import { UpdateTemplateFieldList,} from "@/api/anymark/marktemplatefield";
export default {
  props:{
    fieldList:{
      type: Array,
      required: true,
    },
  },
  computed:{
    filterFieldList(){
      // return this.allFieldList.filter(item=>{return ![//这些类型不允许设置为查询项
      //   FIELD_DISPLAY_TYPE.图片上传,
      //   FIELD_DISPLAY_TYPE.文件上传,
      //   FIELD_DISPLAY_TYPE.视频,
      // ].includes(item.field_type)})
      return this.allFieldList
    },
  },
  data(){
    return{
      FIELD_DISPLAY_TYPE,
      dialogVisible:true,
      allFieldList:[],
      btnLoading:false,
      fieldTypeList: [
        {
          name: "单行文本",
          value: FIELD_DISPLAY_TYPE.单行文本,
        },
        {
          name: "多行文本",
          value: FIELD_DISPLAY_TYPE.多行文本,
        },
        {
          name: "下拉框(单选)",
          value: FIELD_DISPLAY_TYPE.下拉框,
        },
        {
          name: "下拉框(多选)",
          value: FIELD_DISPLAY_TYPE.下拉框多选,
        },
        {
          name: "时间",
          value: FIELD_DISPLAY_TYPE.时间,
        },
        {
          name: "日期",
          value: FIELD_DISPLAY_TYPE.日期,
        },
        {
          name: "图片上传",
          value: FIELD_DISPLAY_TYPE.图片上传,
        },
        {
          name: "文件上传",
          value: FIELD_DISPLAY_TYPE.文件上传,
        },
        {
          name: "视频",
          value: FIELD_DISPLAY_TYPE.视频,
        },
        {
          name: "网址类型",
          value: FIELD_DISPLAY_TYPE.网址类型,
        },
        {
          name: "富文本",
          value: FIELD_DISPLAY_TYPE.富文本,
        },
      ],
    }
  },
  watch:{
    fieldList:{
      handler(n){
        if(n && n.length>0){
          this.allFieldList =  n
        }else{
          this.allFieldList = []
        }
      },
      deep:true,
      immediate:true
    }
  },
  created(){
  },
  mounted(){
    this.$nextTick(() => {
      this.setSort();
    });
  },
  methods:{
    async batchSaveFieldList() {
      if( this.allFieldList.every((item) => {return item.is_display_column === 0})){
        this.$message.warning('请至少保留一列显示')
        return
      }
      const params={
        field_list: this.allFieldList,
      }
      this.btnLoading = true
      const { code,data,msg } = await UpdateTemplateFieldList(params)
      this.btnLoading = false
      if (code === 0) {
        this.$message.success('保存成功')
        this.$emit('updateFieldList')
      }else{
        this.$message.error(msg);
      }
    },
    setSort() {
      const el = this.$refs.dragTable.$el.querySelectorAll(
        ".el-table__body-wrapper > table > tbody"
      )[0];
      Sortable.create(el, {
        ghostClass: "sortable-ghost", // Class name for the drop placeholder,
        onEnd: evt => {
          const targetRow = this.allFieldList.splice(evt.oldIndex, 1)[0];
          this.allFieldList.splice(evt.newIndex, 0, targetRow);
        }
      });
    },
    isSearchDisabled(row){
      return [this.FIELD_DISPLAY_TYPE.图片上传,
        this.FIELD_DISPLAY_TYPE.文件上传,
        this.FIELD_DISPLAY_TYPE.视频,
        this.FIELD_DISPLAY_TYPE.富文本,
      ].includes(row.field_type)
    },
    getFieldTypeName(value) {
      const item = this.fieldTypeList.find(item => item.value === value);
      return item ? item.name : "";
    },
    close(){
      this.$emit('closeDialog')
    },
  }
}
</script>

<style>

</style>