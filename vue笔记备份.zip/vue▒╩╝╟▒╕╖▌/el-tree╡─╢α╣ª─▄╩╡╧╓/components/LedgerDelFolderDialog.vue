<template>
  <el-dialog
    title="确认删除文件夹"
    :visible.sync="dialogVisible"
    width="400px"
    :before-close="close"
    append-to-body
    v-el-drag-dialog
    :close-on-click-modal="false"
    >
    <div class="row mb15">
      <i class="el-icon-warning warningIcon mr10"></i>
      <div class="clr_orange">
        <p>确认删除“{{delFolder.name}}”文件夹吗？</p>
        <p>删除后，文件夹下的内容会保留在您选择的文件夹下</p>
      </div>
    </div>
    <el-form
      ref="filterForm"
      size="small"
      :model="formData"
      class="filterForm"
      label-position='top'
      label-width="auto"
    >
      <el-form-item label="选择文件夹：" prop="filePath">
        <el-cascader
          style="width:100%"
          v-model="formData.filePath"
          :options="parentOptions"
           clearable 
          :props="{ label:'name' ,value:'id',checkStrictly: true}"
        ></el-cascader>
      </el-form-item>
    </el-form>
    <div class="row space_between mt10">
      <div></div>
      <div>
        <el-button size="small" class="submitButtons" @click="close">关闭</el-button>
        <el-button size="small" class="submitButtons" type="primary" :loading="btnLoading"  @click="submit"   >确定</el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script>
import { saveCategoryDel ,getLedgerCategoryTree } from '@/api/anymark/markcategory'
export default {
  props:{
    delFolder:{
      type:Object,
      require:true
    },
    parentId:{
      type:String,
      require:false,
      default:''
    },
  },
  created(){
    if(this.parentId){
      this.formData.filePath = ['0',this.parentId]
    }
    this.fetchList()
  },
  data(){
    return{
      dialogVisible:true,
      btnLoading:false,
      parentOptions:[],
      formData:{
        filePath:['0'],
      },
    }
  },
  methods:{
    async submit(){
      const params={
        id:this.delFolder.id
      }
      if(this.formData.filePath.length === 0){
        try {
          await this.$confirm(`<p class="clr_red">当前并未选择文件夹，【${this.delFolder.name}】下的内容将全部删除，是否继续操作？</p>`, "提醒",{
            dangerouslyUseHTMLString: true,
            customClass: 'confirm-dialog--ew',
            type: 'warning'
          });
          params.delete_children = 1
        } catch (error) {
          return;
        }
      }else{
        params.target_id = this.formData.filePath[this.formData.filePath.length-1]
      }
      const { code,data,msg } = await saveCategoryDel(params)
      if (code === 0) {
          this.$message.success('删除成功');
          this.$emit('updatePage');
      }else{
        this.$message.error(msg);
      }
    },
    // 获取分类列表
    async fetchList() {
      const params={
        user_type: this.delFolder.user_type,
        only_folder:1,//是否只查询文件夹 0否1是
        exclude_root_node_id: this.delFolder.id,//排除当前文件夹
      }
      this.btnLoading = true
      const { code,data,msg } = await getLedgerCategoryTree(params)
      this.btnLoading = false
      if (code === 0) {
        if(data && data.length>0){
          data[0].id = '0'
          //去除其他文件夹 目前使用场景为设备管理  只显示设备管理相关文件夹 固定为科室管理下级
          if(this.parentId && data[0].children){
            data[0].disabled = true
            data[0].children = data[0].children.filter(item=> item.id === this.parentId)
          }
          this.parentOptions = this.setEmptyChildrenToUndefined(this.removeNodesWithTempId(data))
        }else{
          this.parentOptions = []
        }
      }else{
        this.$message.error(msg);
      }
    },
     removeNodesWithTempId(treeData) {
      const processedData = [];
      for (const node of treeData) {
        //设备管理 只能移动到设备管理的文件夹下
        if(this.delFolder.sub_business_type === 'EquipmentManage'){
          node.disabled = node.sub_business_type !=='EquipmentManage'
        }else{
          node.disabled = node.sub_business_type ==='EquipmentManage'
        }
        if (!node.template_id) {
          const processedNode = { ...node };
          if (processedNode.children && processedNode.children.length > 0) {
            processedNode.children = this.removeNodesWithTempId(processedNode.children); // 递归处理子节点
          }
          processedData.push(processedNode);
        }
      }
      return processedData;
    },
    setEmptyChildrenToUndefined(treeData) {
      const processedData = [...treeData]; // 复制一份以保留原数据
      for (const node of processedData) {
        if (node.children && node.children.length === 0) {
          node.children = undefined; // 将 children 为空数组的节点的 children 设置为 undefined
        } else if (node.children && node.children.length > 0) {
          node.children = this.setEmptyChildrenToUndefined(node.children); // 递归处理子节点并赋值给当前节点的 children
        }
      }
      return processedData; // 返回处理后的数据
    },
    close(){
      this.$emit('closeDialog')
    },
  },
}
</script>

<style lang="less" scoped>
.warningIcon{
  font-size: 24px;
  color: #E6A23C;
}
/deep/ .el-form--label-top .el-form-item__label{
  padding:0px;
}

</style>