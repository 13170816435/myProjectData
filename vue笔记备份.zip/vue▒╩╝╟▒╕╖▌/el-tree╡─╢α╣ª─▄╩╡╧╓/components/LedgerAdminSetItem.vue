<template>
  <div>
    <div>
      <el-form
        ref="filterForm"
        size="small"
        :inline="true"
        class="filterForm"
        label-width="auto"
        label-position="left"
        @submit.native.prevent
      >
        <el-form-item prop="messagetypeList">
          <el-input
            @input="keyWordChange"
            v-model="contains_name"
            placeholder="请输入组别查询"
            clearable
            />
        </el-form-item>
        <el-form-item>
          <!-- <el-button size="mini" class="filter-item" type="primary"  @click="searchList" >查询</el-button>
          <el-button size="mini" class="filter-item" type="default" @click="resetForm">重置</el-button> -->
        </el-form-item>
        <el-button class="fr" style=" padding-right:0" type="text" size="small" @click="toHelp">
          <i class="el-icon-my-kanbanHelpIcon"></i> 帮助
        </el-button>
      </el-form>
      <!-- <el-row>
        <el-col :span="14" >
          <div class="main_search_item" style="text-align: left;" >
            <span class="search_left" style="width:50px" >组别：</span>
            <div class="search_right" >
              
            </div>
          </div>
        </el-col>
        <el-col  :span="10" >
         
        </el-col>
      </el-row> -->
    </div>
    <div class="limit_content_body">
      <el-table
        :data="tableData"
        style="width: 100%" height="500" v-adaptive="{ bottomOffset: 52 }" >
        <el-table-column  type="index" label="序号"  width="50"> </el-table-column>
        <el-table-column prop="name" label="组别"  width="150"> </el-table-column>
        <el-table-column  > 
          <template slot-scope="scope" slot="header">
            <el-checkbox v-model="isSelectAll"  @change="selecAll"><span style="font-weight: bold;" >全选</span>
            </el-checkbox>
            <span class="ml10" >操作权限</span>
          </template>
          <template v-for="(item,index) in allSelectHeadList" >
            <template v-if="item.isShow">
              <el-table-column  :key="index" > 
                <template slot-scope="scope" slot="header">
                    <el-checkbox  v-model="item.isChecked"  @change="((val) => updateAllSelected(item,index))">
                      {{item.label}}
                    </el-checkbox>
                </template>
                <template slot-scope="scope" >
                  <el-checkbox  style="margin-right:5px" v-model="scope.row[`isChecked_${item.type}`]"  @change="checked =>checkedChange(checked,scope.row,index,item.type)">
                    <el-tooltip class="item" effect="dark" :content="item.tip" placement="top-start">
                        <span>{{item.name}}</span>   
                    </el-tooltip>
                  </el-checkbox>
                                
                </template>
              </el-table-column>
            </template>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="footBtns ">
      <el-button size="mini" @click="cancle">取消</el-button>
      <el-button size="mini" type="primary" @click="submitForm" :loading="btnDisabled">保存</el-button>
    </div>
    <adminSetHelpDialog @closeDialog='isShowHelpDialog = false' v-if="isShowHelpDialog"></adminSetHelpDialog>
  </div>
</template>
<style lang="scss" scoped>
.limit_content_body{
  position: relative;
}
.limit_content_foot{
  text-align: right;
  padding: 10px 0 0 0;
}
</style>
<script>
import { getAuthorityUserGroupsList } from "@/api/department/user";
import * as channelApi from "@/api/website/channel";
import { categorySavePermission} from '@/api/anymark/markcategory'
import adminSetHelpDialog from '@/views/LedgerManage/components/adminSetHelpDialog'
import _ from 'lodash'
export default {
  components:{adminSetHelpDialog},
  props:{
    categoryId:{
      type:String,
      require:true,
    }
  },
  watch:{
    categoryId:{
      async handler(){
        this.clearFormData();
        await this.getList();
        await this.getUsergroupListFn();
      },
      immediate:true,
    }
  },
  data(){
    return{
      tableData: [],
      //1、仅本人（只能查看\操作自己发布的内容）
      //2、查看全部( 可以查看其他人的内容)
      //4、编辑全部 可以编辑删除全部内容
      //8、管理 有档案设置 档案权限设置tab 所以权限向上包容
      allSelectHeadList:[
        {
          type:1,
          label:"全选",
          isChecked:false,
          isShow:true,
          name:"仅本人",
          tip:'仅支持查看和处置与本人相关的记录'
        },
        {
          type:2,
          label:"全选",
          isChecked:false,
          isShow:true,
          name:"查看",
          tip:'包含“仅本人”权限，并支持查看本档案中全部归档记录'
        },
        {
          type:4,
          label:"全选",
          isChecked:false,
          isShow:true,
          name:"编辑",
          tip:'包含“查看”权限，并支持编辑本档案中全部归档记录'
        },
        {
          type:8,
          label:"全选",
          isChecked:false,
          isShow:false,//要隐藏编辑全部权限
          name:"编辑全部",
          tip:'包含“编辑”权限，并支持管理本档案中所有记录，及维护本档案基础设置和权限设置。建议提供给档案负责人使用。'
        },
        {
          type:16,
          label:"全选",
          isChecked:false,
          isShow:true,
          name:"管理",
          tip:'包含“编辑”权限，并支持管理本档案中所有记录，及维护本档案基础设置和权限设置。建议提供给档案负责人使用。'
        },
      ],
      contains_name:"",
      isSelectAll:false,//全选按钮
      btnDisabled: false,
      user_group_id_list:[],
      isShowHelpDialog:false,
    }
  },
  methods:{
    keyWordChange: _.debounce(function() {
      this.searchList()
    }, 300),
    toHelp(){
      this.isShowHelpDialog = true
    },
    clearFormData(){
      this.tableData=[];
      this.contains_name = ''
      this.isSelectAll = false,//全选按钮
      this.btnDisabled =  false;
    },
    async getUsergroupListFn(){
      const params = {
        user_group_id_list:this.user_group_id_list,
        data_id:this.categoryId,
        module:'Anymark'
      };
      const { data } = await channelApi.getUsergroupList(params);
      if(data && data.length> 0 ){
        data.forEach(d=>{
          const {data_permission_list,user_group_id	} = d;
          
          data_permission_list.forEach(item=>{
            const {data_id,permissions} = item
            this.tableData.forEach(j=>{
              if(user_group_id === j.id){
                if( permissions.includes(1) ){
                  j.isChecked_1 = true;
                }
                if(permissions.includes(2)){
                  j.isChecked_2 = true;
                }
                if(permissions.includes(4)){
                  j.isChecked_4 = true;
                }
                if(permissions.includes(8)){
                  j.isChecked_8 = true;
                }
                if(permissions.includes(16)){
                  j.isChecked_16 = true;
                }
              }
            })
          })

        })
        this.allSelectHeadList[0].isChecked = this.tableData.every(item=>{ return item.isChecked_1})
        this.allSelectHeadList[1].isChecked = this.tableData.every(item=>{ return item.isChecked_2})
        this.allSelectHeadList[2].isChecked = this.tableData.every(item=>{ return item.isChecked_4})
        this.allSelectHeadList[3].isChecked = this.tableData.every(item=>{ return item.isChecked_8})
        this.allSelectHeadList[4].isChecked = this.tableData.every(item=>{ return item.isChecked_16})
        this.checkAllSelect()
      } 
    },
    getPermissionList(){
      //获取勾选项 拼接权限列
      const permissionList = []
      this.tableData.forEach(item=>{
        const {id,isChecked_1,isChecked_2,isChecked_4,isChecked_8,isChecked_16 } =item;
        //选中列表
        let clickList = [];
        //按照产品要求 权限 一层层向下包容 
        if(isChecked_1)clickList = [1];
        if(isChecked_2)clickList = [1,2];
        if(isChecked_4)clickList = [1,2,4];
        if(isChecked_8)clickList = [1,2,4,8];
        if(isChecked_16)clickList = [1,2,4,8,16];
        if(clickList.length>0){
          permissionList.push({
            user_group_id:id,
            permissions:clickList
          })
        }

      })
      return permissionList
    },
    //提交表单
    async submitForm() {
      const permissionList = this.getPermissionList();
      console.log(permissionList)

      permissionList.forEach(item=>{ //要隐藏编辑全部权限
        item.permissions = item.permissions.filter(p=> p !== 8)
      })
      const params={
        category_id:this.categoryId,
        user_group_permission_list:permissionList
      }
      this.btnDisabled = true
      const { code, data, msg } = await categorySavePermission(params);
      this.btnDisabled = false
      if (code === 0) {
        this.$emit("updateTree")
        this.$message.success('保存成功');
      } else {
        this.$message({
          message: msg,
          type: "error",
        });
      }
    },
    async cancle() {
      //取消还原数据
      this.clearFormData();
      await this.getList();
      await this.getUsergroupListFn();
    },
    resetForm(){
      this.contains_name = "";
      this.searchList();
    },
    async searchList(){
      await this.getList();
      await this.getUsergroupListFn();
    },
    async getList(){
      this.systemId = sessionStorage.getItem("lastname");
      let params = {
        offset:1,
        limit:50,
        system_id:this.systemId,
        contains_name:this.contains_name?this.contains_name:""
      };
      // var params = `100&offset=1&system_id=${this.systemId}`;
      const { data } = await getAuthorityUserGroupsList(params);
      this.user_group_id_list = [];
      if(data.length>0){
        data.forEach(item => {
          item.isChecked_1 = false
          item.isChecked_2 = false
          item.isChecked_4 = false
          item.isChecked_8 = false
          item.isChecked_16 = false
          this.user_group_id_list.push(item.id);
        });
      }
      this.tableData = data;

      this.isSelectAll = false;
      this.selecAll()
    },
    selecAll(){
      this.allSelectHeadList.forEach(item=>{item.isChecked = this.isSelectAll})
        this.tableData.forEach(item=>{
          item.isChecked_1 = this.isSelectAll
          item.isChecked_2 = this.isSelectAll
          item.isChecked_4 = this.isSelectAll
          item.isChecked_8 = this.isSelectAll
          item.isChecked_16 = this.isSelectAll
        })
    },
    checkAllSelect(){
      this.isSelectAll =this.allSelectHeadList.every(item=>{return item.isChecked})
    },
    checkedChange(checked,row,index,type){
      const key = "isChecked_"+type;
      this.allSelectHeadList[index].isChecked = this.tableData.every(item=>{ return item[key]})
      this.checkAllSelect()
    },
    updateAllSelected(val,index){
      const {isChecked,type} = val;//1:浏览2:新增4:编辑8:删除
      const key = "isChecked_"+type
      this.tableData.forEach(item=>{
        item[key] = isChecked;
      })
      this.checkAllSelect()
    },
    
  }
}
</script>
<style lang="less" scoped>
.footBtns{
  text-align: center;
  padding-top: 12px;
  // border-top: 1px solid #dcdfe6;
}
.el-icon-my-kanbanHelpIcon{
  background: url(../../../assets/images/common/kanbanHelpIcon.png) center no-repeat;
  background-size: cover;
}
.el-icon-my-kanbanHelpIcon:before{
  content: "\e611";
  font-size: 14px;
  visibility: hidden;
}
</style>