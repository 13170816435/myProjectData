<template>
  <div style=" height: 100%; overflow: hidden;">
    <div  class="app-container">
      <div class="container">
        <el-form
          ref="filterForm"
          size="small"
          @keyup.enter.native="handelSearch"
          @submit.native.prevent
          :model="searchForm"
          label-position="left"
          :inline="true"
          class="filterForm"
        >
          <el-form-item prop="form_states">
            <el-radio-group @change="handelSearch" v-model="searchForm.content_query_state" size="mini">
              <el-radio-button v-for="type in formTypeList" :label="type.key" :key="type.key">{{type.name}} <i v-if="type.count && type.count>0">{{type.count}}</i></el-radio-button>
            </el-radio-group>
          </el-form-item>
          <template v-if="isEquipmentManage">
            <el-form-item v-if="isShowPublishUser" label="填报设备：" prop="deviceIds">
              <el-select v-model="searchForm.deviceIds" 
                style="width:100%" filterable multiple  placeholder="请选择" 
              >
                <el-option
                  v-for="item in equipmentList"
                  :key="item.equipment_id"
                  :value="item.equipment_id"
                  :label="item.equipment_name"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="填写时间：" >
              <dateRangePicker style="width:260px" v-model="searchForm.reportDate" ></dateRangePicker>
            </el-form-item>
          </template>
          <template v-else>
            <el-form-item v-if="isShowPublishUser" label="发布人：" prop="user_id">
              <el-select
                clearable
                v-model="searchForm.user_id"
                filterable
                placeholder="请选择"
              >
                <el-option
                  v-for="item in publishUserList"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
                >
                  <span style="float: left">{{ item.name }}</span>
                  <span
                    v-if="item.work_no"
                    style="color: #8492a6; font-size: 13px"
                    >（{{ item.work_no }}）</span
                  >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="发布时间：" >
              <dateRangePicker style="width:260px" v-model="searchForm.createTime" ></dateRangePicker>
            </el-form-item>
          </template>
          <template v-if="!currentTemplateId">
            <el-form-item label="关键字：" prop="keywords">
              <el-input
                v-model="searchForm.keywords"
                class="text"
                placeholder="输入关键字"
                clearable
              />
            </el-form-item>
          </template>
          <el-form-item>
            <el-button
              size="small"
              class="filter-item"
              type="primary"
              @click="btmSearch"
              >查询</el-button
            >
            <el-button
              size="small"
              class="filter-item"
              type="default"
              @click="handleReset"
              >重置</el-button
            >
            <el-dropdown trigger="click"  ref='moreDropdown'	>
              <el-button size="small" class="filter-item ml10"  >更多<i class="el-icon-arrow-down el-icon--right"></i></el-button>
              <el-dropdown-menu class="moreDropdownMenu" slot="dropdown">
                <div class="moreContent">
                  <div class="moreItem" v-loading="downloadLoading"  element-loading-spinner="el-icon-loading" @click="openExportDialog">导出</div>
                  <div class="moreItem"  element-loading-spinner="el-icon-loading" @click="openExportDig">导入</div>
                  <!-- 文件夹没有设置列表 跟保存筛选接口 -->
                  <template v-if="!categoryObj.is_folder">
                    <div class="moreItem" @click="isShowColumnSettingDialog = true">列表显示设置</div>
                    <!-- <div class="moreItem" @click="isShowFilterSettingDialog = true">筛选条件设置</div> -->
                    <div class="moreItem" @click="openSetItem" >保存常用筛选</div>
                    <!-- <div class="moreItem row" @click="toDraftList" >我发起的<el-badge class="ml5" v-if="draftCount>0" :value="draftCount" ></el-badge></div> -->
                    <div class="moreLint"></div>
                    <template v-if="presetList.length>0">
                      <div class="morePart">常用筛选组合</div>
                      <div class="moreItem" v-for="item in presetList" :key="item.id"
                        :label="item.title"
                        :value="item">
                        <span @click="changeCondition(item)" class="setTitle">{{item.title}}</span>
                        <i v-if="!item.is_default" title="设为默认" @click.stop="dealConditionItem(1,item)" class="el-icon-circle-check clr_ccc setIcon mr5"></i>
                        <i v-else title="取消默认" @click.stop="dealConditionItem(2,item)" class="el-icon-circle-check clr_warn setIcon mr5"></i>
                        <i title="删除预设" @click.stop="dealConditionItem(0,item)" class="el-icon-circle-close clr_red setIcon"></i>
                      </div>
                    </template>
                  </template>
                </div>
              </el-dropdown-menu>
            </el-dropdown>
            <el-button size="small" style="padding-left: 10px;" class="filter-item" type="text" v-if="searchList.length>0" @click="clickShowAll" >{{isShowAll?'高级筛选':'高级筛选'}}<i :class="isShowAll?'el-icon-arrow-down':'el-icon-arrow-up'" ></i></el-button>
          </el-form-item>
          <div class="fr">
            <!-- <el-button
                size="small"
                class="filter-item"
                type="default"
                @click="showDraftList = true"
                >
                <div class="row">
                  草稿箱<el-badge v-if="draftCount>0" :value="draftCount" ></el-badge>
                </div>
                
                </el-button
              > -->
            <el-button
              icon="el-icon-plus"
              type="warning"
              size="small"
              style="margin-left: 10px"
              @click="openDialog('add')"
              >新增</el-button
            >
          </div>
        </el-form>
        <filterSelectionitem  ref="filterSelectionitem" v-if="searchList.length>0" :isShowAllBtn='false' @changeShowAll='changeShowAll' @updateSearch='handelSearch' v-model="searchData" :searchList='searchList' :OptionsData='OptionsData'></filterSelectionitem>
        <!-- v-adaptive="{ bottomOffset: 125 }" -->
        <!-- :height="tableHeight -->
        <el-table
          ref="contentTable"
          v-loading="loading"
          height="400"
          :data="dataList"
          class="tableLimit"
          stripe
          border
          fit
          highlight-current-row
          v-adaptive="{ bottomOffset: 50 }"
          @header-dragend="colChange"
          @row-click='handleViewerContent'

        >
          <el-table-column type="index" fixed="left" align="center" width="50" label="序号">
            <template slot-scope="scope">
              <span>{{
                (pagination.page_index - 1) * pagination.page_size +
                scope.$index +
                1
              }}</span>
            </template>
          </el-table-column>
          <el-table-column  width="80" prop="content_state" label="状态">
            <template slot-scope="scope">
              <el-tag size="mini" :type="dealStateType(scope.row.content_state)" > {{scope.row.content_state}}</el-tag>
            </template>
          </el-table-column>
          <template v-for="(item,index) in fieldColumnList">
            <el-table-column
              :key="item.id+index"
              :label="item.field_name"
              align="left"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <span>{{ getDictValue(item, scope.row[item.column_name]) }}</span>
              </template>
            </el-table-column>
          </template>
          <template v-if="!currentTemplateId">
            <el-table-column
              label="标题"
              align="left"
              prop="title"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              v-if="categoryChildren.length > 0"
              label="所属分类"
              align="left"
              width="200"
              prop="category_path_name"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              v-if="!isPerson"
              label="发布人"
              width="80"
              align="left"
              prop="publish_user_name"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              label="发布时间"
              align="center"
              width="170"
              prop="create_time"
              show-overflow-tooltip
            ></el-table-column>
          </template>
          <el-table-column
            v-if="isPerson || hasDeptPermisson"
            label="操作"
            align="left"
            width="60"
            fixed="left"
          >
            <template slot-scope="scope">
              <el-button
                type="text"
                @click.stop.prevent.native="handleViewerContent(scope.row)"
              >
                查看
              </el-button>
                <!-- :disabledText="(!!workflowId || !!scope.row.workflow_id)?'已经存在审批记录，不允许编辑':'您无随手记编辑权限，请联系管理员'" -->
              <!-- <tooltipButton
                class="ml10"
                :isDisabled="
                  !( scope.row.user_id === userId || scope.row.create_user_id === userId ||
                  scope.row.isAllowEdit )"
                disabledText="'您无随手记编辑权限，请联系管理员'"
                :buttonText="'编辑'"
                @clickButton="handleEditContent(scope.row)"
              ></tooltipButton>
              <tooltipButton
                :isDisabled="
                  !(scope.row.user_id === userId || scope.row.create_user_id === userId ||
                  scope.row.isAllowDel) "
                disabledText="'您无随手记编辑权限，请联系管理员'"
                :buttonText="'删除'"
                :buttonClass="'clr_red'"
                @clickButton="handleDeleteContent(scope.row)"
              ></tooltipButton> -->
            </template>
          </el-table-column>
        </el-table>
        <div class="contentFoot" >
          <div>
            <!-- <el-button
              :loading="downloadLoading"
              size="small"
              class="filter-item"
              type="default"
              icon="el-icon-my-upload"
              @click="openExportDialog"
            >导出
            </el-button> -->
            <!-- <el-button
              icon="el-icon-my-export"
              size="small"
              class="btn"
              type="default"
              @click="openExportDig"
            >导入
            </el-button> -->

            <!-- <el-button
              :loading="downloadLoading"
              size="small"
              class="filter-item"
              type="primary"
              icon="el-icon-download"
              @click="batchExport"
            >
              批量导入
            </el-button> -->
          </div>
          <pagination
            :total="pagination.total"
            :page.sync="pagination.page_index"
            :limit.sync="pagination.page_size"
            :page-sizes.sync="pagination.sizeArray"
            @pagination="changePagination"
          />
        </div>
      </div>

      <el-dialog
        v-dialogDragWidth
        v-dialogDrags
        width="80%"
        custom-class="limitDialogWidth1"
        @close="closeContentDialog"
        :visible.sync="contentDialogVisible"
        :close-on-click-modal="false"
        :append-to-body="true"
      >
        <span slot="title" class="dialog-tile"> 详情 </span>
        <contentDetail
          v-if="contentDialogVisible"
          :isUnLimit='true'
          ref="contentDetail"
          :field-list="allFieldList"
          :options-data="OptionsData"
          :select-id="selectID"
          :selectDetailItem="selectDetailItem"
          :template-id="selectTemplateId"
          @closeItem="closeContentDialog"
        />
      </el-dialog>
      <!-- 选择分类弹窗 -->
      <el-dialog
        v-el-drag-dialog
        width="500px"
        :visible.sync="isShwoSelectDialog"
        :append-to-body="true"
      >
        <span slot="title" class="dialog-tile"> 选择分类 </span>
        <div>
          <el-cascader
            placeholder="请选择（支持模糊查询）"
            style="width: 100%"
            @change="changeDialogCategory"
            v-model="dialogCategoryID"
            :filterable="true"
            clearable
            :options="filterSelection(selectedCategoryChildren)"
            :props="{
              expandTrigger: 'hover',
              value: 'id',
              label: 'name',
            }"
          ></el-cascader>
          <div style="text-align: right; margin-top: 20px">
            <el-button
              size="small"
              class="filter-item"
              @click="cancelSelect"
              >取消</el-button
            >
            <el-button
              v-if="dialogType !== 'upload'"
              size="small"
              class="filter-item"
              :loading="dialogLoading"
              type="primary"
              @click="typeSeleted"
              >确定</el-button
            >
            <el-upload
              v-else
              class="upload-demo"
              ref="upload"
              action="#"
              :disabled="!this.dialogTemplateId"
              :http-request="uploadExcelData"
              :limit="1"
              :show-file-list="false"
              :format="['xlsx', 'xls']"
              accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
            >
              <el-button
                :disabled="!this.dialogTemplateId"
                size="small"
                class="btn"
                type="default"
                icon="el-icon-my-export"
              >导入</el-button
              >
            </el-upload>
          </div>
        </div>
      </el-dialog>
    </div>
    <el-dialog
      v-el-drag-dialog
      width="500px"
      :visible.sync="isShowExportDialog"
      :append-to-body="true"
    >
      <span slot="title" class="dialog-tile"> 选择导出分类 </span>
      <div>
        <el-cascader
          placeholder="请选择（支持模糊查询）"
          style="width: 100%"
          v-model="exportId"
          :filterable="true"
          clearable
          :options="[categoryObj]"
          :props="{
            expandTrigger: 'hover',
            value: 'id',
            label: 'name',
            checkStrictly: true
          }"
        ></el-cascader>
        <div style="text-align: right; margin-top: 20px">
          <el-button
            size="small"
            class="filter-item"
            @click="isShowExportDialog = false"
            >取消</el-button
          >
          <el-button
            size="small"
            class="filter-item"
            :loading="dialogLoading"
            type="primary"
            @click="exportExl"
            >确定</el-button
          >
        </div>
      </div>
    </el-dialog>
    <!-- <categoryContent
      @backToList="backToList"
      :contentid="addEditContentid"
      :templateId="addEditTemplateId"
      :draftId="draftId"
      v-if="isShowAddEditItem"
    ></categoryContent> -->
    <uploadCommonDialog 
      ref="uploadCommonDialog"
      v-if="isShowUploadCommonDialog" 
      @importExcel='uploadExcelData' 
      @downlodeDemo="downlodeDemo" 
      @closePostInfo="isShowUploadCommonDialog = false"
      @complete="upLoadComplete"
      acceptList='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel' >
      <template v-if="isShowCascader">
        <div class="cascaderItem">
          <span>分类：</span>
          <el-cascader
            placeholder="请选择（支持模糊查询）"
            style="width: 100%"
            @change="changeDialogCategory"
            v-model="dialogCategoryID"
            :filterable="true"
            clearable
            :options="filterSelection(selectedCategoryChildren)"
            :props="{
              expandTrigger: 'hover',
              value: 'id',
              label: 'name',
            }"
          ></el-cascader>
        </div>
      </template>
    </uploadCommonDialog>
    <!-- <draftListDialog 
      v-if="showDraftList" :categoryPath="searchForm.categoryPath"
      :userType='categoryObj.user_type'
      @editDrafts="editDrafts"  @closeDialog="closeDraft" >
    </draftListDialog> -->
    <el-dialog v-el-drag-dialog width="300px" title="存为预设" @close="setTitleVal=''" :visible.sync="isShowSetItem">
      <el-input   type="text"
        placeholder="请输入预设"
        v-model="setTitleVal"
        maxlength="8"
        show-word-limit></el-input>
      <div class="dialog-footer">
        <el-button size="small" @click="isShowSetItem = false">取 消</el-button>
        <el-button size="small" type="primary" @click="setDefault()">确 定</el-button>
      </div>
    </el-dialog>
    <filterSettingDialog v-if="isShowFilterSettingDialog" @updateFieldList='updateFieldList' @closeDialog='isShowFilterSettingDialog = false' :fieldList='allFieldList'></filterSettingDialog>
    <columnSettingDialog v-if="isShowColumnSettingDialog" @updateFieldList='updateFieldList' @closeDialog='isShowColumnSettingDialog = false' :fieldList='allFieldList'></columnSettingDialog>
    <LedgerDetailDrawer @closeDrawer='closeDrawer' @backToList="backToList" v-if="isShowLedgerDetailDrawer" :business_type='10' :anymarkObj='currentAnymarkObj'></LedgerDetailDrawer>
    <LedgerAddEditDrawer @closeDrawer='backToList' @backToList="backToList" v-if="isShowAddEditItem" :business_type='10' :anymarkObj='addEditObj' :defultDeviceForm='defultDeviceForm' ></LedgerAddEditDrawer>
  </div>
</template>

<script>
import * as webRequest from "@/api/anymark/qiniu";
import { FieldSourceDataList } from "@/api/anymark/marktemplatefield";
import { DeleteContent,addCategorySearch,categorySearchSetDefault,delCategorySearch,categorySearchList } from "@/api/anymark/markcontent";
import { msg } from "@/utils/common";
import { anymarkIndexPage,anymarkIndexExport } from "@/api/website/usermessage";

import {
  parseTime,
  getMonthTime,
  pickerOptions,
  FIELD_DATA_TYPE,
  FIELD_DISPLAY_TYPE,
} from "@/utils";
import Pagination from "@/components/Pagination"; // 公共的分页组件
// import ComDate from '@/components/DateRange'
import { getUsersLite } from "@/api/department/commonHttp";
import contentDetail from "@/views/anymarkwebsite/mark-content/content-form.vue";
import elDragDialog from "@/directive/el-drag-dialog";
// import { mapGetters } from 'vuex'
import categoryContent from "@/views/departManage/item/categoryContent";
import { getItemList } from "@/api/dictionary";
import setDefaultItem from "@/views/departManage/item/setDefaultItem"
import draftListDialog from "@/views/departManage/item/draftListDialog"
import {getWorkflowFormPageList,getWorkflowFormCount,dealworkflowform} from "@/api/workflow";
import filterSelectionitem from "@/views/LedgerManage/components/filterSelectionitem"
import filterSettingDialog from "@/views/LedgerManage/components/filterSettingDialog"
import columnSettingDialog from "@/views/LedgerManage/components/columnSettingDialog"
import LedgerDetailDrawer from "@/views/LedgerManage/components/LedgerDetailDrawer"
import LedgerAddEditDrawer from "@/views/LedgerManage/components/LedgerAddEditDrawer"
import {getAnymarkDraftList,getAnymarkDraftCount} from "@/api/draft";
import {getAnymarkEquipment,getEquipmentUnreported } from '@/api/anymark/markcategory'
import moment from 'moment' // 表格
export default {
  directives: { elDragDialog },
  components: { 
    Pagination, contentDetail, 
    categoryContent, setDefaultItem,LedgerDetailDrawer,LedgerAddEditDrawer,
    draftListDialog,filterSelectionitem,filterSettingDialog,columnSettingDialog
  },
  data() {
    return {
      apiName: "customtemplatecontent",
      loading: false,
      searchForm: {
        childCategoryID: [],
        categoryPath: "",
        user_id: "",
        categoryID: undefined,
        template_id: undefined,
        keywords: undefined,
        searchFieldList: [], // 查询条件字段
        StartDate: parseTime(getMonthTime(), "{y}-{m}-{d}"),
        EndDate: parseTime(new Date(), "{y}-{m}-{d}"),
        createTime: [],
        content_query_state:'null',

        deviceIds:[],
        reportDate:[],
      },
      currentTemplateId: "", //当前的templeId

      dialogTemplateId: "",
      dialogCategoryID: [], //分类弹窗选中的id
      dialogType: "", //弹框操作类型
      dialogLoading: false,

      publishUserList: [],
      dialogStatus: "",
      textMap: {
        update: "编辑内容",
        create: "新增内容",
      },
      searchParams: [],
      allFieldList: [],
      fieldColumnList: [],
      searchList: [],
      searchData: {},
      dataList: [],
      // isPerson: false,
      pagination: {
        page_index: 1,
        total: 1,
        page_size: 10,
        sizeArray: [10, 20, 30, 50],
      },
      contentDialogVisible: false,
      selectID: undefined,
      selectDetailItem: {},
      selectTemplateId: "",
      contentDetail: {},
      OptionsData: {},
      downloadLoading: false,
      downloadLoading1: false,
      tableHeight: 400,
      cardHeight: document.body.clientHeight - 100,
      pickerOptions: {
        shortcuts: pickerOptions,
      },
      FIELD_DISPLAY_TYPE: FIELD_DISPLAY_TYPE,
      FIELD_DATA_TYPE: FIELD_DATA_TYPE,
      PREVIEW_IMAGE_URL: webRequest.PREVIEW_IMAGE_URL,
      hasDeptPermisson: true,
      isShwoSelectDialog: false,
      isShowAddEditItem: false,
      addEditContentid: "",
      addEditTemplateId: "",
      userId: "",
      selectedCategoryChildren: [], //选中分类的下级分类树形列表（不含选中的分类）
      prm_codes: "", //权限码
      isShowUploadCommonDialog:false,
      isShowCascader:false,

      presetList:[],//预设列表
      presetObj:{},//预设选项
      isFirstIn:true,//判断是否为第一次进入  如果是则需要去设置默认选项
      draftCount:0,

      showDraftList:false,
      draftId:'',

      workflowId:"",//流程id如果绑定了流程 则不能编辑删除（有权限也不行）  
      //需要区分为外层（可能存在部分绑定，部分未绑定，所以需要接口/anymark/index/page返回workflowId 不适用本参数）
      //如果为内层会查询模板接口会返回workflow_id存下做为判断即可
      currentPermissions:[],//权限 1:浏览2:新增 编辑 删除

      isShowExportDialog:false,
      exportId:[],

      isShowSetItem:false,
      setTitleVal:'',
      isShowFilterSettingDialog:false,
      isShowColumnSettingDialog:false,
      isShowLedgerDetailDrawer:false,
      currentAnymarkObj:{},//当前查看详情的 随手记信息
      isShowAll:false,

      equipmentList:[],
      formTypeList:[//1待审核2已审核3我发起的
        { name:"全部", key:'null', count:0 },
        { name:"归档", key:0, count:0 },
        { name:"处理中", key:2, count:0 },
        { name:"草稿", key:-1, count:0 },
        { name:"其他", key:99, count:0 },
      ],

      defultDeviceForm:{//设备填报 默认选中的日期跟设备
        date:'',
        deviceId:''
      },
    };
  },
  props: {
    categoryObj: {
      require: true,
      type: Object,
    },
    // categoryID:{
    //   require:true,
    //   type:String
    // },
    // categoryPath:{
    //   require:true,
    //   type:String
    // },
    isActiveAdminUser:{
      require:true,
      type:Boolean
    },
    categoryChildren: {
      require: false,
      type: Array,
      default: () => {
        return [];
      },
    },

    defultDeviceId:{//选项中默认选中的设备id
      type:String,
      require:false,
      default:''
    },
    defultDeviceReportDate:{//选项中默认选中的报告填写时间
      type:String,
      require:false,
      default:''
    },
  },
  watch: {
    "categoryObj.id": {
      async handler(n, o) {
        if (n) {
          this.ResetData();
          this.searchForm.categoryID = this.categoryObjId;
          this.searchForm.categoryPath = this.categoryObj.path;
          
          if(this.defultDeviceId){
            this.searchForm.deviceIds = [this.defultDeviceId]
          }
          console.log(this.defultDeviceId,this.defultDeviceReportDate)
          if(this.defultDeviceReportDate){
            this.searchForm.reportDate = [this.defultDeviceReportDate,this.defultDeviceReportDate]
          }

          //先获取预设列表
          this.$nextTick(async()=>{
            this.getAnymarkEquipmentFn()
            await this.getPresetList();
            this.fetchCatgoryData(this.categoryObjId);
            this.selectedCategoryChildren = this.categoryChildren;
            this.dealTableHeight();
            this.getWorkflowFormCountFn();
            this.$refs.contentTable.doLayout();
          })
        }
      },
      deep: true,
      immediate:true,
    },
  },
  computed:{
    isEquipmentManage(){
      return this.categoryObj.sub_business_type === 'EquipmentManage' && this.currentTemplateId
    },
    flatCategoryChildren(){//拍平的树列表
      if(this.categoryChildren && this.categoryChildren.length>0){
        return this.flatData(this.categoryChildren);
      }else{
        return []
      }
    },
    addEditObj(){
      return{
        contentId:this.addEditContentid,
        templateId:this.addEditTemplateId,
        draftId:this.draftId,
      }
    },
    categoryObjId(){
      return ['0_0','0_1'].includes(this.categoryObj.id)? 0 : this.categoryObj.id
    },
    isPerson(){
      return this.categoryObj.user_type === 1
    },
    isShowPublishUser(){
      //个人分类直接不显示
      if(this.isPerson){
        return false
      }else{
        if(this.isAllowManage || this.isActiveAdminUser){
          return true
        }else{
          //档案需要判断权限 
          if(this.currentTemplateId){
            return this.currentPermissions.includes(2)//2 是查看全部的权限 有就可以查看别人的内容
          }else{//文件夹直接显示
            return true
          }
        }
      }
    },
    isAllowManage(){
      //是否允许管理分类文件夹 新增 移动 重命名 启用停用等
      return this.$prm_codes.includes('ssj_ml_gl')
    },
    isAllowAdd(){
      //操作菜单设置权限最大
      // if(this.$prm_codes.includes('ssj_add_content')){
      //   return true
      // }else{
        //随手记单独设置权限 1:浏览2:新增 编辑 删除
        if(this.currentTemplateId){
          return this.currentPermissions.includes(2)
        }else{
          //只要当前分类下任何1个分类有新增权限就显示新增按钮
          let isAllowed = false;
          this.categoryChildren.forEach(item=>{
            if(item.permissions && item.permissions.includes(2)){
              isAllowed = true;
            }else{
              if(item.children){
                item.children.forEach(c=>{
                  if(c.permissions&&c.permissions.includes(2)){
                    isAllowed = true;
                  }
                })
              }
            }
          })
          return isAllowed
        }
      // }
    },
  },
  created() {
    this.getUsersLiteFn();

    // let loginInfo = localStorage.getItem("loginInfo");//1
    let loginInfo =  this.$loginInfo;
    if (loginInfo) {
      loginInfo = JSON.parse(loginInfo);
      this.userId = loginInfo.profile.sub;
    }

    this.selectedCategoryChildren = this.categoryChildren;
    this.prm_codes = window.prm_codes;
  },
  mounted() {
    this.dealTableHeight()
  },
  updated() {
    // 动态新增列，fixed固定列，内容错位的问题
    this.$nextTick(() => {
      this.$refs.contentTable.doLayout();
    });
  },
  filters:{
    },
  methods: {
    dealStateType(val){
      let text =''
      switch (val) {
        case '归档':
          text = 'success'
          break;
        case '处理中':
          text = 'warning'
          break;
        case '已删除':
          text = 'danger'
          break;
        case '草稿':
          text = ''
          break;
        case '终止':
          text = 'info'
          break;
      
        default:
          break;
      }
      return text;
    },
    async getAnymarkEquipmentFn(){
      const params={
        category_id:this.categoryObjId
      }
      const res = await getAnymarkEquipment(params)
      if (res.code === 0) {
        this.equipmentList = res.data
      }
    },
    clickShowAll (){
      this.isShowAll = !this.isShowAll
      this.$refs.filterSelectionitem.changeShowAll()
    },
    closeDrawer(){
      this.currentAnymarkObj = {};
      this.isShowLedgerDetailDrawer = false;
    },
    updateFieldList(){
      this.fetchTemplateData(this.currentTemplateId);
      this.isShowFilterSettingDialog = false
      this.isShowColumnSettingDialog = false
    },
    toDraftList(){
      //关闭更多
      this.$refs.moreDropdown.visible = false
      this.showDraftList = true;
    },
    openSetItem(){
      this.setTitleVal='';
      this.isShowSetItem = true;
    },
     changeShowAll(){
      this.$nextTick(()=>{
        const el = this.$refs.contentTable
        const tableHeight = window.innerHeight - el.$el.getBoundingClientRect().top - 50
        el.layout.setHeight(tableHeight);
        el.doLayout();
      })
    },
    exportExl(){
      const flatlist = this.flatData([this.categoryObj]);
      const selectedId = this.exportId[this.exportId.length-1]
      const currentObj = flatlist.filter(item=>{return item.id === selectedId})[0]
      if(currentObj.template_id){
        this.handleDownload(currentObj.template_id);
      }else{
        this.anymarkIndexExportFn(currentObj)
      }
    },
    async anymarkIndexExportFn(obj){
      const params={
        is_enabled: 1,
        is_permission_filter:true,
        category_path :obj.path,
        keywords :this.searchForm.keywords,
        user_id :this.searchForm.user_id
      }
      const query_description_dic={}
      if (this.searchForm.createTime && this.searchForm.createTime.length > 0) {
        params.create_time_start = this.searchForm.createTime[0]?this.searchForm.createTime[0]:'';
        params.create_time_end = this.searchForm.createTime[1]?this.searchForm.createTime[1]:'';
        query_description_dic['开始日期'] = this.searchForm.createTime[0]
        query_description_dic['结束日期'] = this.searchForm.createTime[1]
      }
      if(this.searchForm.user_id){
        const currentUser = this.publishUserList.find(item => item.id === this.searchForm.user_id)
        query_description_dic['创建人'] =currentUser.name
      }

      if (this.searchForm.content_query_state !== 'null') {
        params.content_query_state = this.searchForm.content_query_state;
      }
      if(this.isPerson){
        params.user_type = 1
      }
      params.query_description_dic = query_description_dic;
      this.dialogLoading = true
      const res = await anymarkIndexExport(params);
      if(!res.success){
        this.dialogLoading = false
        this.isShowExportDialog = false;
        return this.$message.warning('导出数据为空')
      }
      var blob = this.createFile(res.byte_array, {
        type: "application/vnd.ms-excelcharset=utf-8",
      });
      // 针对于IE浏览器的处理, 因部分IE浏览器不支持createObjectURL
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob, res.file_name);
      } else {
        var downloadElement = document.createElement("a");
        var href = window.URL.createObjectURL(blob); // 创建下载的链接
        downloadElement.href = href;
        downloadElement.download = res.file_name; // 下载后文件名
        document.body.appendChild(downloadElement);
        downloadElement.click(); // 点击下载
        document.body.removeChild(downloadElement); // 下载完成移除元素
        window.URL.revokeObjectURL(href); // 释放掉blob对象
      }
      this.dialogLoading = false
      this.isShowExportDialog = false;

    },
    flatData(data){
      return data.reduce((prev, curr) => {
          prev.push(curr);
          if (curr.children && curr.children.length > 0) {
          prev.push(...this.flatData(curr.children));
          }
          return prev;
      }, []);
    },
    openExportDialog(){
      if(this.downloadLoading){
        return
      }
      //关闭更多
      this.$refs.moreDropdown.visible = false
      if(this.categoryObj.template_id){
        this.handleDownload(this.categoryObj.template_id);
      }else if(this.currentTemplateId){
        this.handleDownload(this.currentTemplateId);
      }else{
        this.exportId =[this.categoryObjId,...this.searchForm.childCategoryID]
        this.isShowExportDialog = true;
      }
    },
    filterSelection(list){
      const dealList = list?JSON.parse(JSON.stringify(list)):[]
      //导出不做判断 如果有新增权限 也不做过滤
      // || this.$prm_codes.includes('ssj_add_content') 
      // if(!(this.dialogType === "download" )){
      //   dealList.forEach(item=>{
      //     if(item.permissions&&item.permissions.includes(2)){
      //       item.disabled = false;
      //     }else{
      //       item.disabled = true;
      //     }
      //     if(item.children){
      //       item.children.forEach(c=>{
      //         if(c.permissions&&c.permissions.includes(2)){
      //           //子集有权限 则父级也有权限
      //           item.disabled = false;
      //           c.disabled = false;
      //         }else{
      //           c.disabled = true;
      //         }
      //       })
      //     }
      //   })
      // }
      return dealList
    },
    
    closeDraft(){
      this.showDraftList= false;
      this.getWorkflowFormCountFn();
    },
    // editDrafts(item){
    //   // if(item.business_type === 10){//随手记
    //   // }
    //   this.anymarkIndexFn(item.index_id);
    // },
    // async anymarkIndexFn(id){
    //   const { code, data, msg } = await webRequest.anymarkIndex(id);
    //   if (code === 0) {
    //     //关闭弹窗
    //     this.dialogCategoryID = [];
    //     this.dialogTemplateId = "";
    //     this.isShwoSelectDialog = false;
        
    //     this.draftId = data.content_id
    //     this.addEditTemplateId = data.template_id;
    //     this.isShowAddEditItem = true;
    //     this.showDraftList = false;
    //   } else {
    //     this.$message({
    //       message: msg,
    //       type: "error",
    //     });
    //   }
    // },
    async getWorkflowFormCountFn(){
      const params={
        business_sub_type_path:this.searchForm.categoryPath,
        business_type : 10
      }
      const { code, data, msg } = await getWorkflowFormCount(params);
      if (code === 0) {
        const {wait_approved , i_start_item} = data;
        this.$emit('updateCount',wait_approved)
      } else {
        this.$message({
          message: msg,
          type: "error",
        });
      }
    },
    async getAnymarkCount(params){
      if(this.currentTemplateId){
        const { code, data, msg } = await webRequest.getAnymarkContentCount (params);
        if (code === 0) {
          const {draft,approval} = data
          this.formTypeList[2].count = approval?approval:0
          this.formTypeList[3].count = draft?draft:0
        } else {
          this.$message({
            message: msg,
            type: "error",
          });
        }
      }else{
        
        const { code, data, msg } = await webRequest.getAnymarkIndexListCount (params);
        if (code === 0) {
          const {draft,approval} = data
          this.formTypeList[2].count = approval?approval:0
          this.formTypeList[3].count = draft?draft:0
        } else {
          this.$message({
            message: msg,
            type: "error",
          });
        }

      }
    },
    async setDefault(){
      if(!this.setTitleVal){
        this.$message.error('请填写预设名称');
        return;
      }
      const params={
        category_id:this.categoryObjId,
        title:this.setTitleVal,
      }
      let searchObj ={
        keywords:this.searchForm.keywords,
        createTime:this.searchForm.createTime,
        user_id:this.searchForm.user_id,

        deviceIds:this.searchForm.deviceIds,
        
        content_query_state:this.searchForm.content_query_state,

        reportDate:this.searchForm.reportDate,
        childCategoryID:[],
      };
      if(this.searchForm.childCategoryID.length > 0){
        searchObj.childCategoryID = this.searchForm.childCategoryID
      }
      searchObj =  Object.assign(searchObj, this.searchData);
      params.search_content =JSON.stringify(searchObj) 
      const {code} = await addCategorySearch(params);
      if(code === 0){
        this.$message.success("添加成功")
        this.getPresetList();
        this.isShowSetItem = false;
      }
    },
    dealConditionItem(type,item){
      //1设为默认 2取消默认 0 删除
      if(type){
        this.categorySearchSetDefaultFN(item.id,type)
      }else{
        this.$confirm("确定要删除该条内容吗?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          customClass: 'confirm-dialog--ew',
          type: "warning",
        }).then(()=>{
          this.delCategorySearchFn(item.id)
        })
      }
    },
    async delCategorySearchFn(id){
      const {code} = await delCategorySearch(id);
      if(code === 0){
        this.$message.success("删除成功")
        this.getPresetList();
      }
    },
    async categorySearchSetDefaultFN(id,type){
      const {code} = await categorySearchSetDefault(id,{is_default:type===1?1:0});
      if(code === 0){
        this.$message.success("设置成功")
        this.getPresetList();
      }
    },
    changeCondition(item){
      this.isFirstIn = true;
      const search_content = item.search_content;
      const {childCategoryID ,keywords,createTime,user_id,deviceIds,reportDate,content_query_state } = search_content
      //给固定项赋值
      this.searchForm.keywords = keywords?keywords:''
      this.searchForm.createTime = createTime?createTime:[]
      this.searchForm.user_id = user_id?user_id:''
      this.searchForm.deviceIds = deviceIds?deviceIds:[]
      this.searchForm.content_query_state = content_query_state !== undefined?content_query_state:'null'
      this.searchForm.reportDate = reportDate?reportDate:[]
      //给动态项赋值
      this.searchList.forEach((key) => {
        const defultVal = search_content[key.column_name]?search_content[key.column_name]:null
        this.$set(this.searchData, key.column_name, defultVal);
      });
      this.presetObj = search_content;
      //根据categoryChildren 判断是否有分类 有分类就可能存在切换分类的情况
      //有分类并且选择了 分类 赋值之后会触发changeChildCategory
      if(this.categoryChildren.length > 0){
        //分类不变直接查询
        if(this.searchForm.childCategoryID === childCategoryID){
          this.fetchList();
        }else{
          //分类变了 赋值触发changeChildCategory
          this.searchForm.childCategoryID = childCategoryID?childCategoryID:[]
          this.changeChildCategory();
        }
      }else{
        //没分类直接赋值查询
        this.fetchList();
      }
    },
    upLoadComplete(){
      //关闭弹窗
      this.dialogCategoryID = [];
      this.dialogTemplateId = "";
      this.isShwoSelectDialog = false;
      this.isShowUploadCommonDialog = false
    },
    downlodeDemo(){
      if (this.currentTemplateId) {
        this.exportTemplate(this.currentTemplateId);
      }else{
        if (this.dialogCategoryID.length === 0) {
          this.$message.warning("请选择分类");
          return;
        } else if (!this.dialogTemplateId) {
          this.$message.warning("档案未配置模板，请先创建。");
          return;
        } else {
          this.exportTemplate(this.dialogTemplateId);
        }
      }
    },
    openExportDig(){
      //判断是否显示分类选择
      if (
        this.categoryChildren.length > 0 
        // &&
        // this.searchForm.childCategoryID.length === 0
      ){
        this.dialogCategoryID =JSON.parse(JSON.stringify(this.searchForm.childCategoryID))  
        this.isShowCascader = true;
      }else{
        this.isShowCascader = false;
        if (!this.currentTemplateId){
          //未创建模板
          if (this.selectedCategoryChildren.length > 0) {
            //如果有子分类，则也需要选择
            this.isShowCascader = true;
          } else {
            //如果没有子分类，则提示去创建模板
            this.$message.warning("当前分类下没有档案，请先创建。");
            return;
          }
        }
      }
      this.isShowUploadCommonDialog = true;
    },
    dealTableHeight(){
      console.log("dealTableHeight")
      this.$nextTick(() => {
        const h = document.querySelector(".main").clientHeight - 20;
        const f = document.querySelector(".filterForm").clientHeight;
        const publicTabs = document.querySelector(".publicTabs")?document.querySelector(".publicTabs").clientHeight:0;
        const typeItemTabs =49 
        // document.querySelector(".typeItemTabs").clientHeight;
        const contentFoot = document.querySelector(".contentFoot").clientHeight;
        // console.log(h,f,publicTabs,typeItemTabs,contentFoot)
        this.tableHeight = h - f - publicTabs - typeItemTabs -contentFoot;
      });
    },
    setDate() {
      let dayTime = new Date(); //获取当前标准时间
      let lastY1 = dayTime.getFullYear();
      let lastM1 = dayTime.getMonth() + 1;
      let lastD1 = dayTime.getDate();
      var datetime =
        lastY1 +
        "-" +
        (lastM1 < 10 ? "0" + lastM1 : lastM1) +
        "-" +
        (lastD1 < 10 ? "0" + lastD1 : lastD1); //转换为yy-mm-dd格式

      let lw = new Date(dayTime - 1000 * 60 * 60 * 24 * 30);
      let lastY = lw.getFullYear();
      let lastM = lw.getMonth() + 1;
      let lastD = lw.getDate();
      let startThirtydate =
        lastY +
        "-" +
        (lastM < 10 ? "0" + lastM : lastM) +
        "-" +
        (lastD < 10 ? "0" + lastD : lastD); //三十天之前日期
      this.searchForm.createTime = [startThirtydate, datetime];
    },
    backToList() {
      if (this.isShowAddEditItem || this.isShowLedgerDetailDrawer) {
        this.addEditContentid = "";
        this.addEditTemplateId = "";
        this.draftId = "";
        // this.defultDeviceForm={
        //   date:'',
        //   deviceId:'',
        // }
        this.isShowAddEditItem = false;
        this.isShowLedgerDetailDrawer = false;
        this.fetchList();
        this.getWorkflowFormCountFn();
      }
    },
    openDialog(type) {
      if (
        this.categoryChildren.length > 0 &&
        this.searchForm.childCategoryID.length === 0
      ) {
        this.dialogType = type;
        this.isShwoSelectDialog = true;
      } else {
        if (this.currentTemplateId) {
          //有创建模板
          switch (type) {
            case "add":
              this.handleNewContent(this.currentTemplateId);
              break;
            case "download":
              this.handleDownload(this.currentTemplateId);
              break;
            case "export":
              this.exportTemplate(this.currentTemplateId);
              break;
            default:
              break;
          }
        } else {
          //未创建模板
          if (this.selectedCategoryChildren.length > 0) {
            //如果有子分类，则弹窗选择
            this.dialogType = type;
            this.isShwoSelectDialog = true;
          } else {
            //如果没有子分类，则提示去创建模板
            this.$message.warning("当前分类下没有档案，请先创建。");
          }
        }
      }
    },
    changeDialogCategory() {
      //通过联机选择表 选中的id 获取对应的path与template_id
      if (this.dialogCategoryID.length > 0) {
        const selectId =
          this.dialogCategoryID[this.dialogCategoryID.length - 1];
        let selectObj = {};
        this.flatCategoryChildren.forEach((item) => {
          const id = item.id;
          if (selectId === id) {
            selectObj = item;
          }
        });
        if(selectObj.is_folder){
          this.$message.warning("当前分类下没有档案，请先创建。");
        }else if(!selectObj.template_id) {
          this.$message.warning("档案未配置模板，请先创建。");
        }
        this.dialogTemplateId = selectObj.template_id;
      }
    },
    cancelSelect() {
      this.dialogCategoryID = [];
      this.dialogTemplateId = "";
      this.isShwoSelectDialog = false;
    },
    async typeSeleted() {
      if (this.dialogCategoryID.length === 0) {
        this.$message.warning("请选择分类");
        return;
      } else if (!this.dialogTemplateId) {
        this.$message.warning("档案未配置模板，请先创建。");
        return;
      } else {
        this.dialogLoading = true;
        switch (this.dialogType) {
          case "add":
            this.handleNewContent(this.dialogTemplateId);
            break;
          case "download":
            await this.handleDownload(this.dialogTemplateId);
            break;
          case "export":
            await this.exportTemplate(this.dialogTemplateId);
            break;
          default:
            break;
        }
        this.dialogLoading = false;
      }
    },
    changeChildCategory() {
      console.log("changeChildCategory")
      if (this.searchForm.childCategoryID.length > 0) {
        //通过联机选择表 选中的id 获取对应的path与template_id
        const selectId =
          this.searchForm.childCategoryID[
            this.searchForm.childCategoryID.length - 1
          ];
        let selectObj = {};
        this.categoryChildren.forEach((item) => {
          const id = item.id;
          const children = item.children;
          if (selectId === id) {
            selectObj = item;
          } else {
            //因为只能选中最后一层
            if (children) {
              children.forEach((child) => {
                const cId = child.id;
                if (selectId === cId) {
                  selectObj = child;
                }
              });
            }
          }
        });
        this.searchForm.categoryPath = selectObj.path;
        // if(!selectObj.template_id){
        //   this.$message.warning("当前分类下没有档案，请先创建。")
        // }
        this.currentTemplateId = selectObj.template_id;

        //当前模板权限
        this.currentPermissions = selectObj.permissions;
        //如果当前分类有下级，则进行赋值（用于弹窗选择）
        // if (selectObj.children) {
        //   this.selectedCategoryChildren = selectObj.children;
        // } else {
        //   this.selectedCategoryChildren = [];
        // }
        // console.log(this.selectedCategoryChildren);
      } else {
        this.searchForm.categoryPath = this.categoryObj.path;
        this.currentTemplateId = this.categoryObj.template_id;
        this.selectedCategoryChildren = this.categoryChildren;
        //当前模板权限
        this.currentPermissions = this.categoryObj.permissions;
      }

      if(this.currentTemplateId){
        this.fetchTemplateData(this.currentTemplateId)
      }else{
        this.fieldColumnList = [];
        this.searchList = [];
        this.searchData = {};
        this.fetchList();
      }
      //重新查询草稿箱数量
      this.getWorkflowFormCountFn()
    },
    async getUsersLiteFn() {
      const params = {
        // institution_id: user.profile.inst_id,
        // office_id: user.profile.office_id,
        // business_system_id:sessionStorage.getItem("lastname"),
        // business_system_type:'dms',
      };
      //科室管理与 pacs项目查询用户传参不同
      if(this.$currentSystemClass === 'DMS_RIS'){
        params.business_system_id = sessionStorage.getItem("lastname")
        params.business_system_type = "dms"
      }else{
        params.system_id = sessionStorage.getItem("lastname")
      }
      const { data } = await getUsersLite(params);
      this.publishUserList = data;
    },
    handleChange(file) {
      console.log(file);
    },
    async uploadExcelData(content) {
      let tempId = "";
      if (  this.isShowCascader ) {
        if (this.dialogCategoryID.length === 0) {
          this.$message.warning("请选择分类");
          return;
        } else if (!this.dialogTemplateId) {
          this.$message.warning("档案未配置模板，请先创建。");
          return;
        } 
        tempId = this.dialogTemplateId;
      } else {
        tempId = this.currentTemplateId;
      }
      if (!tempId) {
        this.$message.warning("档案未配置模板，请先创建。");
        return;
      }
      //声明一个FormDate对象
      let formData = new FormData();
      //把文件信息放入对象中
      formData.append("file", content.raw);
      formData.append("file_name", content.name);

      formData.append("template_id", tempId);
      const { code, msg } = await webRequest.templateImport(formData);
      if (code === 0) {
        this.$refs.uploadCommonDialog.upLoadSuccess();
        this.pagination.page_index = 1;
        this.fetchList();
      } else {
        this.$refs.uploadCommonDialog.upLoadError(msg);
      }
    },
    //导出模板
    exportTemplate(TemplateId) {
      this.downloadLoading1 = true;
      webRequest.templateExport({ template_id: TemplateId }).then((res) => {
        if (res.code === 0) {
          let { file_base64_str, file_name } = res.data;
          this.excelSheet(file_base64_str, file_name);
        } else {
          this.$message.error(res.msg);
        }
      });
    },
    excelSheet(data, name) {
      var raw = window.atob(data);
      var uInt8Array = new Uint8Array(raw.length);
      for (var i = 0; i < raw.length; i++) {
        uInt8Array[i] = raw.charCodeAt(i);
      }
      const link = document.createElement("a");
      const blob = new Blob([uInt8Array], {
        type: "application/vnd.ms-excel",
      });
      link.style.display = "none";
      link.href = URL.createObjectURL(blob);
      link.setAttribute("download", name + ".xlsx");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      this.$message.success("导出成功！");
      this.downloadLoading1 = false;
    },
    // 创建时间查询项
    getApplyDate(val) {
      if (val.length > 0) {
        this.searchForm.StartDate = val[0] === null ? "" : val[0];
        this.searchForm.EndDate = val[1] === null ? "" : val[1];
        this.searchForm.createTime = val;
      }
    },
    async getPresetList(){
      const params = {
        category_id:this.categoryObjId,
      }
      //清空初始值
      this.presetObj = {};
      // this.$refs.setDefaultItem.currentSetObj = {};
      const {code, data} = await categorySearchList(params)
      if(code === 0){
        //获取预设列表 
        data.forEach(item=>{
          const {search_content,is_default} = item;
          item.search_content = JSON.parse(search_content)
          if(is_default){
            this.presetObj = item.search_content;
            //设置显示默认值
            // this.$refs.setDefaultItem.currentSetObj = item;
          }
        })
        this.presetList = data;
      }
    },
    // 分类同步查询
    async fetchCatgoryData(categoryID) {
      if(categoryID === 0){//等于0 代表为最顶部的 科室档案或者个人档案 不请求获取模板接口 直接查询列表
        this.currentTemplateId = "";
        this.fieldColumnList = [];
        this.searchList = [];
        this.searchData = {};
        this.fetchList();
        return 
      }
      this.loading = true;
      // 判断分类是否为个人分类
      const res = await webRequest.GetDetailById("category",categoryID)
      if (res.code === 0) {
        //是否有预设表 并且为第一次进入 并且有设置默认预设
        if(this.presetList && this.presetList.length>0 && this.isFirstIn && Object.keys(this.presetObj).length > 0){
         const {childCategoryID ,keywords,createTime,user_id,deviceIds,reportDate,content_query_state } = this.presetObj
          //给固定项赋值
          this.searchForm.keywords = keywords?keywords:''
          this.searchForm.createTime = createTime?createTime:[]
          this.searchForm.user_id = user_id?user_id:''
          this.searchForm.deviceIds = deviceIds?deviceIds:[]
          this.searchForm.content_query_state = content_query_state !== undefined?content_query_state:'null'
          this.searchForm.reportDate = reportDate?reportDate:[]
          //根据categoryChildren 判断是否有分类
          //有分类并且选择了 分类 赋值之后会触发changeChildCategory
          if(this.categoryChildren && this.categoryChildren.length > 0){
            //没选择分类正常流程
            if(!(childCategoryID && childCategoryID.length>0)){
              this.currentTemplateId = "";
              this.fieldColumnList = [];
              this.searchList = [];
              this.searchData = {};
              this.fetchList();
              return false;
            }else{
              
              this.searchForm.childCategoryID = childCategoryID?childCategoryID:[]
              this.changeChildCategory();
            }
          }else{
            //赋值权限
            // this.currentPermissions = this.categoryObj.permissions
            this.currentPermissions = res.data.permissions
            //没分类
            this.fetchTemplateData(res.data.template_id);
          }
        }else{
          // this.isPerson = res.data.userType === 1;
          //如果没有按正常流程
          if (!res.data.template_id) {
            this.currentTemplateId = "";
            this.fieldColumnList = [];
            this.searchList = [];
            this.searchData = {};
            this.workflowId="";
            this.fetchList();
            return false;
          }
          //赋值权限
          this.currentPermissions = res.data.permissions
          this.fetchTemplateData(res.data.template_id);
        }

      }
    },
    // 模板详情查询
    fetchTemplateData(templetaId) {
      webRequest
        .GetDetailById("customtemplate", templetaId)
        .then((response) => {
          const { code, data } = response;
          if (code === 0) {
            this.workflowId = data.workflow_id?data.workflow_id:'';
            this.searchForm.searchFieldList = [];
            this.currentTemplateId = data.id;

            data.field_list.map((item, index) => {
              if (
                item.field_property != null &&
                item.field_property.search_type != null
              ) {
                const field = Object.assign({}, item);

                this.searchForm.searchFieldList.push(field);
              }
            });

            this.allFieldList = data.field_list.filter(
              (x) => x.is_related_business !== 1
            );
            // 过滤默认展示的列，若是没有设置，则默认显示全部列
            const filterfieldList = data.field_list.filter(
              (x) =>
                x.is_display_column === 1 &&
                x.is_related_business !== 1 &&
                x.field_type !== FIELD_DISPLAY_TYPE.图片上传
            );
            this.fieldColumnList =
              filterfieldList.length > 0 ? filterfieldList : data.field_list;
            this.getOptionsData(
              this.fieldColumnList.filter(
                (x) => (x.field_type === FIELD_DISPLAY_TYPE.下拉框 || x.field_type === FIELD_DISPLAY_TYPE.下拉框多选)
              )
            );

            // 查询区域条件
            this.searchList = data.field_list.filter(
              (x) =>
                x.is_search_field === 1 &&
                x.is_related_business !== 1 &&
                x.field_type !== FIELD_DISPLAY_TYPE.图片上传
            );
            // console.log(this.fieldColumnList)
            this.searchList.forEach((item, index, array) => {
              if(this.isFirstIn){
                //根据预查询项设置默认值
                const defultVal = this.presetObj[item.column_name]?this.presetObj[item.column_name]:null
                this.$set(this.searchData, item.column_name, defultVal);
              }else{
                this.$set(this.searchData, item.column_name, null);
              }
            });
            this.fetchList();

            this.$nextTick(()=>{
              if(this.isEquipmentManage){
                this.toDeviceAdd(this.currentTemplateId)
              }
            })
          }
        })
        .catch((e) => {
          this.loading = false;
        });
    },
    async fetchList() {
      if(this.currentTemplateId){
        await this.customtemplatecontentFn();
      }else{
        await this.anymarkIndexPageFn();
      }
      //查询过后设置为 非第一次
      this.isFirstIn = false;
    },
    async customtemplatecontentFn() {
      const searchParams = Object.assign({}, this.searchData);
      if (this.searchForm.createTime.length > 0) {
        searchParams.create_time = [this.searchForm.createTime[0]?this.searchForm.createTime[0]:'',this.searchForm.createTime[1]?this.searchForm.createTime[1]:''];
      }
      if (this.searchForm.user_id) {
        searchParams.create_user_id = this.searchForm.user_id;
      }
      if(this.isEquipmentManage){
        searchParams.equipment_id = this.searchForm.deviceIds
        searchParams.report_date = this.searchForm.reportDate
      }
      const data1 = Object.assign(
        {},
        {
          template_id: this.currentTemplateId,
          page_index: this.pagination.page_index,
          page_size: this.pagination.page_size,
          search_params: searchParams,
        }
      );
      if (this.searchForm.content_query_state !== 'null') {
        data1.content_query_state = this.searchForm.content_query_state;
      }
      this.loading = true;
      //查询科室档案数量
      this.getAnymarkCount(data1)
      const { code, data, page } = await webRequest.GetList(
        this.apiName,
        data1
      );

      this.pagination.total = page?page.total_count:0;
      if (this.publishUserList.length === 0) {
        await this.getUsersLiteFn();
      }
      data.forEach((item) => {
        const { create_user_id } = item;
        this.publishUserList.forEach((p) => {
          if (p.id === create_user_id) {
            item.create_user_name = p.name;
          }
        });
        item.template_id =this.currentTemplateId
        item.content_id =item.id
        // if(this.categoryObj.admin_user_ids && this.categoryObj.admin_user_ids.includes(this.userId)){
        //   item.isAllowEdit = true
        //   item.isAllowDel = true
        // }else{
        //   // this.$prm_codes.includes('ssj_bj')? true :
        //   // this.$prm_codes.includes('ssj_sc')? true : 
        // }
        item.isAllowEdit = this.currentPermissions.includes(4) || this.isAllowManage
        item.isAllowDel = this.currentPermissions.includes(4) || this.isAllowManage
      });
      this.dataList = data;
      this.loading = false;
      this.$nextTick(() => {
        if( this.$refs.contentTable )this.$refs.contentTable.doLayout();
      });
    },
    anymarkIndexPageFn(){
      const params = {
        // category_id:this.categoryID,
        page_index: this.pagination.page_index,
        page_size: this.pagination.page_size,
        is_enabled: 1,
        is_permission_filter:true,
      };

      params.category_path = this.searchForm.categoryPath;

      params.keywords = this.searchForm.keywords;
      params.user_id = this.searchForm.user_id;

      if (this.searchForm.content_query_state !== 'null') {
        params.content_query_state = this.searchForm.content_query_state;
      }
      if (this.searchForm.createTime && this.searchForm.createTime.length > 0) {
        params.create_time_start = this.searchForm.createTime[0]?this.searchForm.createTime[0]:'';
        params.create_time_end = this.searchForm.createTime[1]?this.searchForm.createTime[1]:'';
      }
      if(this.isPerson){
        params.user_type = 1
      }
      this.loading = true;
      //查询科室档案数量
      this.getAnymarkCount(params)
      anymarkIndexPage(params).then((response) => {
        const { code, data, page } = response;
        //遍历类型  拍平对象数组 对比模板名找到对应的权限
        const flatList =  this.flatData(this.categoryChildren);
        flatList.forEach(item=>{
          const {template_id,permissions,admin_user_ids} = item;
          data.forEach(val=>{
              if(template_id === val.template_id){
                // //需要单个分别判断是否为负责人
                // if(admin_user_ids && admin_user_ids.includes(this.userId)){
                //   val.isAllowEdit = true
                //   val.isAllowDel = true
                // }else{
                //   // this.$prm_codes.includes('ssj_bj')? true : 
                //   // this.$prm_codes.includes('ssj_sc')? true : 
                // }
                val.isAllowEdit =permissions.includes(4) || this.isAllowManage || this.isActiveAdminUser
                val.isAllowDel = permissions.includes(4) || this.isAllowManage || this.isActiveAdminUser
            }
          })
        })
        this.dataList = data;
        this.pagination.total = page?page.total_count:0;
        this.loading = false;
        this.$nextTick(() => {
          this.$refs.contentTable.doLayout();
        });
      });
    },
    flatData(data){
      return data.reduce((prev, curr) => {
        prev.push(curr);
        if (curr.children && curr.children.length > 0) {
          prev.push(...this.flatData(curr.children));
        }
        return prev;
      }, []);
    },
    btmSearch(){
      if(this.isShowAll){
        this.clickShowAll()
      }
      this.pagination.page_index = 1;
      this.fetchList();
    },
    handelSearch() {
      // this.searchForm.createTime = [
      //   this.searchForm.StartDate,
      //   this.searchForm.EndDate,
      // ];
      

      this.pagination.page_index = 1;
      this.fetchList();
    },
    ResetData() {
      // this.setDate();
      this.searchForm.createTime =[]
      this.searchForm.keywords = "";
      this.searchForm.childCategoryID = [];
      
      this.searchForm.content_query_state = 'null';
      this.searchForm.deviceIds = [];
      this.searchForm.reportDate = [];

      this.currentTemplateId = "";
      // this.searchForm.createTime=[];
      this.searchForm.user_id = "";
      this.searchParams = [];

      this.currentPermissions = [];

      this.fieldColumnList = [];
      this.searchList = [];
      this.searchData = {};
      //重置预查询项
      this.isFirstIn = true;
      this.presetObj = {}
      this.presetList = [];
      this.workflowId = "";
      //关闭弹框
      this.isShowLedgerDetailDrawer = false;
      this.isShowAddEditItem = false
      this.isShowAll = false
    },
    handleReset() {
      // this.setDate();
      this.searchForm.createTime =[]
      this.searchForm.categoryPath = this.categoryObj.path;
      this.searchForm.keywords = "";
      this.searchForm.childCategoryID = [];

      this.searchForm.content_query_state = 'null'
      this.searchForm.deviceIds = [];
      this.searchForm.reportDate = [];

      // this.searchForm.createTime=[];
      this.searchForm.user_id = "";
      this.searchParams = [];

      this.searchList.forEach((item, index, array) => {
          this.$set(this.searchData, item.column_name, null);
        });
      this.selectedCategoryChildren = this.categoryChildren;
      this.pagination.page_index = 1;

      // //重置为第一次查询
      this.isFirstIn = true;
      //并且重置 查询项为默认查询项
      this.presetObj = {};
      this.presetList.forEach(item=>{
        if(item.is_default){
          this.presetObj = item.search_content;
          //设置显示默认值
          // this.$refs.setDefaultItem.currentSetObj = item;
        }
      })
      this.getWorkflowFormCountFn();
      this.fetchCatgoryData(this.categoryObjId);
      // this.fetchList();
    },
    // 下拉列表数据
    getOptionsData(selectFieldList) {
      if (selectFieldList) {
        selectFieldList.forEach((item, index, array) => {
          //    取数据源
          if (item.bind_source && item.bind_source.table.length > 0) {
            FieldSourceDataList({ field_id_list: [item.id] }).then((res) => {
              if (res.code === 0) {
                const arr = res.data[0].sourceData.map((x) => {
                  return {
                    key: x.key,
                    value:
                      item.data_type === FIELD_DATA_TYPE.整数
                        ? parseInt(x.value)
                        : item.data_type === FIELD_DATA_TYPE.小数
                        ? parseFloat(x.value)
                        : x.value,
                  };
                });

                this.$set(this.OptionsData, item.column_name, arr);
              }
            });
          } else if (item.dic_code) {
            //获取字典选项
            this.getItemListFn(item);
          } else {
            if (
              item.dictionary_item_list &&
              item.dictionary_item_list.length > 0
            ) {
              const arr = item.dictionary_item_list.map((x) => {
                return {
                  key: x.dict_key,
                  value:
                    item.data_type === FIELD_DATA_TYPE.整数
                      ? parseInt(x.dict_value)
                      : item.data_type === FIELD_DATA_TYPE.小数
                      ? parseFloat(x.dict_value)
                      : x.dict_value,
                };
              });
              this.$set(this.OptionsData, item.column_name, arr);
            }
          }
        });
      }
    },
    async getItemListFn(item) {
      let params = {
        // category_code: item.dic_code,
        dic_type_code: item.dic_code,
      };
      const { data } = await getItemList(params);
      data.forEach((item) => {
        item.key = item.dic_define_value;
        item.value = item.dic_define_code;
      });
      this.$set(this.OptionsData, item.column_name, data);
    },
    // 获取字段查询类型
    getFieldSearchType(fieldID) {
      var fieldItem = this.searchForm.searchFieldList.find(
        (item) => item.id === fieldID
      );
      if (fieldItem == null) {
        return 0;
      }
      if (
        fieldItem.field_property == null ||
        fieldItem.field_property.search_type == null
      ) {
        return 0;
      }
      return fieldItem.field_property.search_type;
    },
    // 动态查询条件字段参数
    getDynamicParameters() {
      const dynamicParams = {};
      if (this.searchForm.searchFieldList.length > 0) {
        this.searchForm.searchFieldList.map((item, index) => {
          const search_type = this.getFieldSearchType(item.id);
          if (
            search_type === 7 &&
            this.searchParams[index] != null &&
            this.searchParams[index].length > 1
          ) {
            // 日期范围查询
            dynamicParams[item.column_name + "_Start"] =
              this.searchParams[index][0];
            dynamicParams[item.column_name + "_End"] =
              this.searchParams[index][1];
          } else {
            dynamicParams[item.column_name] = this.searchParams[index];
          }
        });
      }
      return dynamicParams;
    },
    async fetchDetailTemplateData(templetaId) {
      const response = await webRequest.GetDetailById(
        "customtemplate",
        templetaId
      );
      const { code, data } = response;
      if (code === 0) {
        this.allFieldList = data.field_list.filter(
          (x) => x.is_related_business !== 1
        );
      }
    },
    // 查看详细
    async handleViewerContent(row) {
      if(row.content_id){
        this.currentAnymarkObj.templateId =row.template_id
        //判断是否为空对象
        // await this.fetchDetailTemplateData(row.template_id);
        this.$set(this.currentAnymarkObj,'contentId',row.content_id)
        // this.selectID = row.content_id;
        // this.selectDetailItem = row;
        // this.selectTemplateId = row.template_id;
      }else{
        this.currentAnymarkObj.templateId =this.currentTemplateId;
        this.$set(this.currentAnymarkObj,'contentId',row.id)
        // this.selectID = row.id;
        // this.selectTemplateId = this.currentTemplateId;
        // this.selectDetailItem = row;
      }
      this.currentAnymarkObj.optionsData = this.OptionsData
      this.currentAnymarkObj.fieldList = this.allFieldList
      this.currentAnymarkObj.isWGC = this.categoryObj.name.includes('随手记')
      // this.contentDialogVisible = true;
      this.isShowLedgerDetailDrawer = true;
    },
    closeContentDialog() {
      this.selectID = "";
      // this.allFieldList = [];
      this.contentDialogVisible = false;
    },
    // 删除内容
    handleDeleteContent(row) {
      //关闭弹框
      this.isShowLedgerDetailDrawer = false
      this.isShowAddEditItem = false
      this.$confirm("确定要删除该条内容吗?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        customClass: 'confirm-dialog--ew',
        type: "warning",
      })
        .then(() => {
          this.loading = true;
          DeleteContent({
            template_id: row.template_id,
            id: row.content_id,
          }).then((response) => {
            if (response.code === 0) {
              this.loading = true;
              this.fetchList();
              msg.ok("内容删除成功", "msg");
            } else msg.warning(response.msg, "msg");
          });
        })
        .catch(() => {});
    },
    // 新增内容
    handleNewContent(templateId) {
      //关闭弹窗
      this.dialogCategoryID = [];
      this.dialogTemplateId = "";
      this.isShwoSelectDialog = false;

      this.addEditTemplateId = templateId;
      this.isShowAddEditItem = true;
      // this.$router.push({
      //   path: `/markcontent/create/${templateId}`,
      // })
    },
    async toDeviceAdd(templateId) {
      //调用接口 判断是否当日已填写
      const params ={
        anymark_category_id :this.categoryObjId
      }
      const {data,code,msg} = await getEquipmentUnreported(params)
      const nowDate = moment().format('YYYY-MM-DD HH:mm:ss')
      this.defultDeviceForm={
        date: nowDate,
        deviceId: ''
      }
      if(code === 0){
        if(data && data.unreport_equipment_id_list){
          //如果有传入默认设备 检查改设备是否未填写  未填写则自动选中新增
          if(this.defultDeviceId){
            if(data.unreport_equipment_id_list.includes(this.defultDeviceId)){
              this.addEditTemplateId = templateId;
              this.defultDeviceForm={
                date: nowDate,
                deviceId: this.defultDeviceId
              }
              this.isShowAddEditItem = true;
            }
          }
        }
      }else{
        this.$message.error(msg)
      }
    },
    // 内容编辑
    // handleEditContent(row) {
    //   // this.addEditTemplateId = row.template_id;
    //   this.addEditTemplateId = '';//新修改 编辑时通过contentId查询详情会返回 templetaId 跟 审批表单id
    //   this.addEditContentid = row.content_id;
    //   this.isShowAddEditItem = true;
    //   // this.$router.push({
    //   //   path: `/markcontent/edit/${row.template_id}/${row.content_id}`,
    //   // });
    // },
    createFile(urlData, fieldType) {
      const bytes = window.atob(urlData);
      let n = bytes.length;
      const u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bytes.charCodeAt(n);
      }
      return new Blob([u8arr], { type: fieldType });
    },
    // 导出excel
    async handleDownload(templateId) {
      this.downloadLoading = true;

      // 查询条件
      const data = {
        template_id: templateId,
        // keywords: this.searchForm.keywords,
      };
      const query_description_dic={}
      const searchParams =  Object.assign({}, this.searchData);
      if (this.searchForm.createTime.length > 0) {
        searchParams.create_time = [this.searchForm.createTime[0]?this.searchForm.createTime[0]:'',this.searchForm.createTime[1]?this.searchForm.createTime[1]:''];
        // searchParams.title = this.searchForm.keywords;
        query_description_dic['开始日期'] = this.searchForm.createTime[0]
        query_description_dic['结束日期'] = this.searchForm.createTime[1]
      }
      if(this.searchForm.user_id){
        searchParams.create_user_id = this.searchForm.user_id;
        const currentUser = this.publishUserList.find(item => item.id === this.searchForm.user_id)
        query_description_dic['创建人'] =currentUser.name
      }
      if (this.searchForm.content_query_state !== 'null') {
        data.content_query_state = this.searchForm.content_query_state;
      }
      data.search_params = searchParams;
      data.query_description_dic = query_description_dic;

      webRequest
        .excelInfo(this.apiName, data)
        .then((res) => {
         
          if(!res.success){
             this.downloadLoading = false;
            this.$message.warning('导出数据为空')
          }else{
            var blob = this.createFile(res.byte_array, {
              type: "application/vnd.ms-excelcharset=utf-8",
            });
            // 针对于IE浏览器的处理, 因部分IE浏览器不支持createObjectURL
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
              window.navigator.msSaveOrOpenBlob(blob, res.file_name);
            } else {
              var downloadElement = document.createElement("a");
              var href = window.URL.createObjectURL(blob); // 创建下载的链接
              downloadElement.href = href;
              downloadElement.download = res.file_name; // 下载后文件名
              document.body.appendChild(downloadElement);
              downloadElement.click(); // 点击下载
              document.body.removeChild(downloadElement); // 下载完成移除元素
              window.URL.revokeObjectURL(href); // 释放掉blob对象
            }
            this.downloadLoading = false;
          }
        })
        .catch(() => {
          msg.warning("下载附件失败，请联系管理员", "msg");
          this.downloadLoading = false;
        });
    },
    //   当拖动表头改变了列的宽度的时候会触发该事件
    colChange(newWidth, oldWidth, column, event) {
      const dom = document.getElementsByClassName(column.id);
      let index = 0;
      for (index = 0; index < dom.length; index++) {
        dom[index].childNodes[0].style.width = `${newWidth - 2}px`; // 动态改变文本宽度
      }

      this.$refs.contentTable.doLayout();
    },
    // 下拉选项的文本
    getDictValue(fieldItem, val) {
      let selectedValue = "";
      // if (fieldItem.field_type !== this.FIELD_DISPLAY_TYPE.下拉框) return val
      //非下拉框 复选框 不需要匹配选项文本
      if (!( [this.FIELD_DISPLAY_TYPE.下拉框,this.FIELD_DISPLAY_TYPE.下拉框多选].includes(fieldItem.field_type))) return val;
      else {
        if (!this.OptionsData || !this.OptionsData[fieldItem.column_name]) {
          return val;
        }
        if(fieldItem.field_type === this.FIELD_DISPLAY_TYPE.下拉框多选){
          const valList = val?val.split(","):[]
          const valNameList = []
          this.OptionsData[fieldItem.column_name].forEach((x) =>{
            valList.forEach(v=>{
              if(x.value === v){
                valNameList.push(x.key)
              }
            })
          });
          selectedValue = valNameList.join(",")
        }else{
          const arr = this.OptionsData[fieldItem.column_name].find(
            (x) => x.value == val
          );
          selectedValue = arr ? arr.key : "";
        }
        return selectedValue;
      }
    },
    // 处理图片预览地址
    getImageURL(val, index) {
      if (!val) return index > -1 ? "" : [];
      const urls = val.map((x) => {
        return webRequest.PREVIEW_IMAGE_URL + x.name;
      });
      return index > -1 ? urls[0] : urls;
    },
    changePagination({page,limit}){
      this.pagination.page_index = page
      this.pagination.page_size = limit
      this.fetchList()
    },
  },
};
</script>
<style lang="less">
.moreDropdownMenu{
  padding: 0;
}
</style>
<style lang="scss" scoped>
.search-header {
  .title {
    margin: 10px 0px 0px 0px;
    text-align: right;
  }
  .text {
    margin-left: 5px;
  }
  .button {
    margin-left: 15px;
  }
}
.search-button {
  margin-top: 20px;
  text-align: center;
}
.custom {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
}
.newButton {
  padding-left: 0px;
}

.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}

.totalimg {
  display: block;
  margin-top: -20px;
}
.upload-demo {
  display: inline-block;
  /* height: 20px; */
  margin-left: 10px;
}
.el-upload {
  height: 30px;
}
.upload_icon {
  background: #1ab54a;
  border: #1ab54a;
}
.contentFoot{
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-top: 10px;
  ::v-deep.pagination-container{
    padding: 0px !important;
  }
}
.cascaderItem{
  display: flex;
  margin-bottom: 10px;
  align-items: center;
  span{
    white-space: nowrap;
  }
}
::v-deep .el-badge{
  position: relative;
  vertical-align: bottom;
  display: inline-block;
  height: 14px;
  .el-badge__content{
    height: 14px;
    line-height: 14px;
    padding: 0 5px;
    border:0;
  }
}
::v-deep .el-dialog__body {
  height: calc(100% - 40px);
  box-sizing: border-box;
}
.moreContent{
  font-size: 14px;
  .moreItem{
    padding: 5px 15px;
    cursor: pointer;
    &:hover{
      background: #ecf5ff;
    }
    ::v-deep .el-loading-spinner{
      margin-top: -10px;
    }
    .setTitle{
      width: 8em;
      margin-right:10px ;
      display: inline-block;
    }
    .setIcon{
      cursor: pointer;
      font-size: 16px;
      font-weight: bold;
    }
  }
  .moreLint{
    width: 100%;
    padding: 0 15px;
    box-sizing: border-box;
    &:before{
      content: "";
      background: #DCDFE6;
      width: 100%;
      display: block;
      height: 1px;
    }
    
  }
  .morePart{
    padding: 5px 15px;
    font-size: 13px;
    color: #909399;
  }
}
.dialog-footer{
  text-align: right;
  margin-top: 20px;
}

</style>
