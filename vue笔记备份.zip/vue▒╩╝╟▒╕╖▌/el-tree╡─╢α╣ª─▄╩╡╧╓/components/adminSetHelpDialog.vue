<template>
  <el-dialog
    v-el-drag-dialog
    :visible="dialogVisible"
    title="权限说明"
    custom-class="noPaddingDialog"
    append-to-body
    :close-on-click-modal="false"
    width="1000px"
    @close="close"
  >
  <div class="clr_303" style="padding:15px 20px;">
    <div class="setItem" v-for="item in setList" :key="item.name" >
      <div class="clr_0a70b0 strong">{{item.name}}</div>
      <div class="mb10">{{item.desc}}</div>
      <div>
        <img style="width:100%" :src="item.gifImg" alt="">
      </div>
    </div>
  </div>
  <div slot="footer" class="dialog-footer fr">
    <el-button @click="close" size="small">取消</el-button>
    <el-button @click="close" type="primary" size="small">确定</el-button>
  </div>
  </el-dialog>
</template>

<script>
export default {
  data(){
    return{
      dialogVisible:true,
      setList:[
        {
          // name:'编辑',
          // desc:'您可以根据使用需求，来搭建属于自己的个人中心。点击右侧的“编辑”按钮，进入个人中心看板的编辑页面',
          gifImg: require('@/assets/images/common/adminSettingHelp.png')
        },
      ],
    }
  },
  methods:{
    close(){
      this.$emit("closeDialog")
    },
  },
}
</script>
<style lang="less">
.noPaddingDialog{
  .el-dialog__body{
    padding: 0px !important;
  }
}
</style>
<style lang="less" scoped>
.setItem{
  margin-bottom: 40px;
}
.setItem:last-child{
  margin-bottom: 0px;
}

</style>