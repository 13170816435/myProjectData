<template>
  <div v-loading="loading" class="drawerContent1">
    <div v-if="allFieldList.length>0" class="contentMain">
      <div>
        <!-- <LedgerViewContentItem v-if="viewMode===0"
          :contentid='currentContentId'
          :templateId='currenttemplateId'
          :fieldGroupList='fieldGroupList'
          :contentDetail='contentData'
          :OptionsData='OptionsData'
          ></LedgerViewContentItem> -->
        <LedgerEditContentItem 
          ref="LedgerEditContentItem"
        :template_name='template_name'
        :description='description'
        :contentid='currentContentId'
        :templateId='currenttemplateId'
        :contentDetail='contentData'
        :OptionsData='OptionsData'
        :allFieldList='allFieldList'
        :fieldGroupList='fieldGroupList'
        :defultDeviceForm='defultDeviceForm'

        :isContentPadding='isContentPadding'
         ></LedgerEditContentItem>
        <!-- 内容 -->
      </div>
      <div v-if="workflowFormDetail.logs && workflowFormDetail.logs.length>0" class="contentRight">
        <div class="timelinePartTitle">流转记录</div>
        <examineTimelineItem :logs="workflowFormDetail.logs" class="timelineMain contentMain"></examineTimelineItem>
      </div>
    </div>
    <div v-if="allFieldList.length>0 && viewMode === 1" class="saveButton">
      <el-button class="mr10" size="mini"  @click="jump">返回列表</el-button>

      <!-- 当没有详情id时 为新增之间显示存草稿等按钮 当动态按钮点击编辑 时修改状态 显示保存按钮-->
      <div style="display:inline-block" v-if='!currentContentId || isEdit'>
        <!-- 复制不允许存草稿 -->
        <el-button size="mini" v-if="!isCopy" :disabled="saveBtnDisabled" @click="valid(1)"
          >存草稿</el-button
        >
        <el-button size="mini" type="primary" :disabled="saveBtnDisabled" @click="valid"
          >提交内容</el-button
        >
      </div>
      <!-- 动态按钮 -->
      <template v-else >
        <examineDealItem  ref="examineDealItem" 
          style="display:inline-block"
          class="tl"
          :buttonList='buttonList'
          :contentStatut="2" :workflowFormDetail='workflowFormDetail'
          @editDrafts='editDrafts' @toExamine='toExamine'
          @updateData="updateData" 
          @closeItem="closeItem" 
        >
          <el-button v-if="buttonList.includes(1)" size="mini" type="primary" :disabled="saveBtnDisabled" @click="toEdit" >编辑</el-button >
          <el-button v-if="buttonList.includes(2)" size="mini" type="danger" :disabled="saveBtnDisabled" @click="handleDeleteContent" >删除</el-button>
          <el-button v-if="buttonList.includes(3)" size="mini" type="primary" @click="addCopy">复制新增</el-button>
          <el-button v-if="buttonList.includes(4)" size="mini" type="primary" @click="recoverContent">恢复</el-button>
        </examineDealItem>
      </template>
    </div>
    <dialogItem
      dialogTitle="提醒"
      :setWidth="'400px'"
      :setMT="0"
      :isHeightCenter="true"
      :isShowCLoseIcon="false"
      :isShowSubmit="false"
      :isShowCencel="false"
      :footerAlign="'right'"
      v-if="isShowCloseTip"
    > 
      <div style="padding:15px 20px;">
        <i class="el-icon-warning mr5" style="font-size: 24px !important; vertical-align: text-top; color: #e6a23c;"></i>
        <span v-if="workflowName">{{`提交成功，待"${workflowName}"审批`}}</span>
        <span v-else>提交成功</span>
      </div>
      <el-button
        slot="footer_button"
        type="default"
        size="mini"
        @click="closeDeal(3)"
        >返回列表</el-button
      >
      <el-button
        slot="footer_button"
        type="primary"
        size="mini"
        @click="closeDeal(2)"
        >继续新增</el-button
      >
    </dialogItem>
  </div>
</template>

<script>
import examineTimelineItem from '@/views/examine/examineTimelineItem'
import * as webRequest from "@/api/anymark/qiniu";
import { UpdateContent } from "@/api/anymark/markcontent";
import { FIELD_DATA_TYPE, FIELD_DISPLAY_TYPE } from "@/utils";
import { FieldSourceDataList } from "@/api/anymark/marktemplatefield";
import { getItemList } from "@/api/dictionary";
import LedgerEditContentItem from '@/views/LedgerManage/components/anymarkCompent/LedgerEditContentItem'
import LedgerViewContentItem from '@/views/LedgerManage/components/anymarkCompent/LedgerViewContentItem'
import {getWorkflowFormDetail} from "@/api/workflow";
import examineDealItem from '@/views/examine/examineDealItem'
import { DeleteContent} from "@/api/anymark/markcontent";
export default {
  components:{
    examineTimelineItem,LedgerViewContentItem,LedgerEditContentItem,examineDealItem,
  },
  props:{
    viewMode:{//编辑新增1  还是查看0
      type: Number,
      default: 0,
    },
    origin:{//origin:1 审批中心查详情。其他不传
      type: Number,
      require:false,
      default: null,
    },
    // workflowContentId:{//审批流内容id
    //   type: String,
    //   default: '',
    // },
    contentid: {
      type: String,
      default: '',
    },
    templateId: {
      type: String,
      //   required: true,
      default: '',
    },
    draftId: {
      type: String,
      //   required: true,
      default: '',
    },
    // isCopy: {//是否复制  复制直接调用新增接口
    //   require: false,
    //   type: Boolean,
    //   default: false,
    // },
    defultDeviceForm: {//设备管理 默认设备  填写时间
      require: false,
      type: Object,
      default: ()=>{
        return {}
      },
    },
    isContentPadding:{//内容是否增加padding 主要抽屉需要添加防止被按钮挡住 展示页面不需要添加
      require:false,
      type:Boolean,
      default:true
    },
  },
  watch:{
    templateId: {
      handler(n, o) {
        if(this.loading){
          return
        }
        if (n && n !== o) {
          this.resetDate()
          this.currenttemplateId = n
          if(this.draftId){//
            this.editDraftId = this.draftId
          }
          this.currentContentId = this.contentid?this.contentid:this.draftId
          this.fetchContentForm(n);
        }
      },
      immediate: true,
    },
    contentid: {
      handler(n, o) {
        if(this.loading){
          return
        }
        if (n && n !== o) {
          this.resetDate()
          this.currenttemplateId = this.templateId
          if(this.draftId){//
            this.editDraftId = this.draftId
          }
          this.currentContentId = this.contentid?this.contentid:this.draftId
          this.fetchContentForm(this.currenttemplateId);
        }
      },
      immediate: true,
    },
    // workflowContentId: {
    //   handler(n, o) {
    //     if (n && n !== o) {
    //       this.resetDate()
    //       this.getWorkflowFormDetailFn()
    //     }
    //   },
    //   immediate: true,
    // },
  },
  data(){
    return{
      apiName: "customtemplatecontent",
      FIELD_DISPLAY_TYPE: FIELD_DISPLAY_TYPE,
      FIELD_DATA_TYPE: FIELD_DATA_TYPE,
      workflowFormDetail:{},
      workflowId:'',
      workflowName:'',
      template_name:'',
      allFieldList:[],
      OptionsData:{},
      contentData: {},
      loading:false,
      editDraftId:'',
      saveBtnDisabled:false,
      isShowCloseTip:false,
      isEdit:false,//编辑状态
      isCopy:false,//是否为复制状态
      
      currentContentId:'',
      currenttemplateId:'',
      fieldGroupList:[],//动态字段分组
      buttonList:[],//底部按钮列表
      workflowContentId:'',
    }
  },
  methods:{
    recoverContent(){
      //关闭弹框
      this.$confirm("确定要恢复该条内容吗?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        customClass: 'confirm-dialog--ew',
        type: "warning",
      })
        .then(() => {
          this.loading = true;
          webRequest.anymarkContentRecover({
            id: this.currentContentId,
            template_id: this.currenttemplateId,
          }).then((response) => {
            if (response.code === 0) {
              this.$message.success("内容恢复成功", "msg");
              this.jump()
            } else this.$message.warning(response.msg, "msg");
          });
        })
        .catch(() => {});
    },
    // 删除内容
    handleDeleteContent() {
      //关闭弹框
      this.$confirm("确定要删除该条内容吗?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        customClass: 'confirm-dialog--ew',
        type: "warning",
      })
        .then(() => {
          this.loading = true;
          DeleteContent({
            template_id: this.currenttemplateId,
            id: this.currentContentId,
          }).then((response) => {
            if (response.code === 0) {
              this.$message.success("内容删除成功", "msg");
              this.jump()
            } else this.$message.warning(response.msg, "msg");
          });
        })
        .catch(() => {});
    },
    toEdit(){
      this.isEdit = true
      this.getFieldGroupPermissionFn(this.allFieldList)
    },
    async updateData(){
      this.getContentData()
      this.getFieldGroupPermissionFn(this.allFieldList)
      // this.getWorkflowFormDetailFn()
      // this.$refs.examineDealItem.init();
    },
    toExamine(item){
      // this.$emit("toExamine",item)
      this.getContentData()
      this.getFieldGroupPermissionFn(this.allFieldList)
    },
    editDrafts(item){
      // this.$emit("editDrafts",item)
      this.toEdit()
    },
    addCopy(item){
      // this.$emit("addCopy",item)
      this.isCopy = true
      this.workflowFormDetail = {}
      this.isEdit = true
      //只取第一级分类 因为复制新增只新增发起人内容
      const publicItem = this.fieldGroupList[0]
      publicItem.is_editable= true
      this.fieldGroupList = [publicItem]

    },
    closeItem(type){
      this.$emit("closeItem",type)
    },
    jump() {
      this.$emit("backToList");
      //给父窗口发送消息通知关闭窗口 1为提交成功 0为关闭页面
      window.parent.postMessage({ returnType:'centerDetailPageClose',flag:1 }, "*");
    },
    //1转到待办、2继续新增、3返回列表
    closeDeal(type){
      if(type === 1){
        if(this.$route.path === "/anymark/workflow/todo"){
          this.jump();
        }else{
          this.$router.push({ 
            path: '/anymark/workflow/todo' ,
            query: {
              type:3
            },
          })
        }
      }else if(type === 2){
        this.isShowCloseTip = false
        this.saveBtnDisabled = false;
        this.isCopy = false;
        this.editDraftId ="";
        this.currentContentId ="";
        this.$refs.LedgerEditContentItem.clearDate()
        this.$emit('updateCount')//外部更新数量
      }else{
        this.jump();
      }
    },
    //检测编辑内容 并返回详情
    async checkForm(flag){
      const val = await this.$refs.LedgerEditContentItem.submitForm(flag)
      if(val){
        return val
      }else{
        return false
      }
    },
    async valid(flag){
      const val =await this.checkForm(flag)
      if(val){
        this.saveData(val,flag)
      }else{
        return
      }
    },
    // 内容保存 flag 1存草稿 2审批提交  state审批提交后返回的状态吗
    async saveData(tempData,flag,state) {
      console.log(flag)
      if (!this.currenttemplateId) {
        this.$message.error("请选择随记模板", "msg");
        return;
      }
      const data = {
        template_id: this.currenttemplateId,
        field_data: tempData,
      };
      if(flag === 2){//审批提交增加参数 防止表单被重新发起
        data.is_workflow_update=true
      }else{
        //新增编辑增加传审批流id
        if(this.workflowId){
          data.workflow_id = this.workflowId
        }
      }
      if(flag === 1){
        data.business_state = -1;
      }else{
        data.business_state = state
      }
      this.saveBtnDisabled = true;
      //是复制内容 直接进新增
      if (( this.currentContentId) && !this.isCopy) {
        data.field_data["id"] =this.currentContentId;
        const response =await UpdateContent(data)
        const { code } = response;
        if (code === 0) {
          this.saveBtnDisabled = false;
          if(flag === 1){
            this.$message.success("暂存成功", "msg");
            this.jump();
          }else if(flag === 2){

          }else{
            if(this.editDraftId){
              this.isShowCloseTip= true;
            }else{
              this.$message.success("内容更新成功", "msg");
              this.jump();
            }
          }
          
        } else {
          this.saveBtnDisabled = false;
          this.$message.error(response.msg);
        }
      } else {
        const response = await webRequest.Create(this.apiName, data)
        const { code } = response;
        if (code === 0) {
            if(flag === 1){
              this.$message.success("内容暂存成功", "msg");
              this.jump();
            }else{

              this.isShowCloseTip= true;
            }
          this.saveBtnDisabled = false;
        } else {
          this.saveBtnDisabled = false;
          this.$message.error(response.msg);
        }
      }
    },
    resetDate(){
      this.workflowFormDetail ={},
      this.workflowId ='',
      this.workflowName ='',
      this.template_name ='',
      this.allFieldList = [],
      this.OptionsData = {},
      this.editDraftId = '',
      this.contentData = {};
      this.currentContentId=''
      this.currenttemplateId=''
      this.workflowContentId=''
      this.fieldGroupList = []
      this.buttonList = []
    },
    // 初始化form表单内容
    async fetchContentForm(templateId) {
      if (templateId) {
        const param ={
          referrer:1
        }
        this.loading = true
        const { code, data } = await webRequest.GetDetailById("customtemplate", templateId,param)
        if (code === 0) {
          //审批流id
          this.workflowId = data.workflow_id;
          this.workflowName = data.workflow_name;
         
          this.template_name = data.template_name
          this.description = data.description
          data.field_list.forEach(item =>{
            const {field_type} = item;
            if (field_type === FIELD_DISPLAY_TYPE.文件上传 || field_type === FIELD_DISPLAY_TYPE.视频) {
              item.progress = 0
            }
            if(!item.field_property){
              item.field_property = {}
            }
          })

          const fildeList = data.field_list.filter(
            (x) => x.is_related_business !== 1
          );
          await this.getOptionsData(
            fildeList.filter(
              (x) => (x.field_type === FIELD_DISPLAY_TYPE.下拉框 || x.field_type === FIELD_DISPLAY_TYPE.下拉框多选)
            )
          );
          
          //新增时 查看模板是否有默认项 有则赋值
          if (!this.currentContentId ) {
            this.contentData = {};
            //新增时 只有第一个分组（发起人分组）可以编辑
            data.field_group_list.forEach((item,i)=>{
              item.is_editable= i===0
            })
            this.fieldGroupList = this.getWorkflowStepsTemplateGroup(fildeList,data.field_group_list)
          }else{
            await this.getContentData()
            
            //如果有审批内容id  说明是审批页面进入 如果为待处理 调用接口判断哪些能编辑
            if(this.workflowContentId && this.workflowFormDetail.form_state=== 2){
              //其他情况 按照接口返回显示 是否能编辑
              await this.getFieldGroupPermissionFn(fildeList)
            }else{
              //因为现在外面表格统一为查看 所以进入后只做查看处理
              data.field_group_list.forEach((item,i)=>{
                item.is_editable= false
              })
              this.fieldGroupList = this.getWorkflowStepsTemplateGroup(fildeList,data.field_group_list)
            }
          }
          this.loading = false
          this.allFieldList = fildeList
        }
      }
    },
    async getFieldGroupPermissionFn(fildeList){
      const param ={
        content_id: this.currentContentId,
        template_id: this.currenttemplateId,
      }
      const { code, data } = await webRequest.getFieldGroupPermission(param)
      this.fieldGroupList = this.getWorkflowStepsTemplateGroup(fildeList,data)
    },
    getWorkflowStepsTemplateGroup(fildeList,list){
      const groupList =JSON.parse(JSON.stringify(list)) 
      groupList.forEach(item=>{
        const {field_group_id} = item;
        const list = [];
        fildeList.forEach(f=>{
          if(f.field_group_id === field_group_id){
            list.push(f)
          }
        })
        item.fieldList = list
      })
      return groupList
    },
    // 加载内容
    async getContentData() {
      // 内容详情查询
      this.contentData = {};
      if (this.currenttemplateId && (this.currentContentId )) {
        let params = {
          id: this.currentContentId,
          template_id: this.currenttemplateId,
        };
        if(this.origin){
          params.origin = this.origin
        }
        this.loading = true
        // let { data, code } =  await webRequest.GetDetail(this.apiName, params);
        let { data, code } =  await webRequest.GetAnymarkContentDetail(params);
        this.loading = false
        if (code === 0) {
          this.contentData = data.content;
          if(data.form_id){
            this.workflowContentId = data.form_id
            await this.getWorkflowFormDetailFn()
          }
          if(data.button_list && data.button_list.length>0){
            const list = []
            data.button_list.forEach(item => list.push(item.type))
            this.buttonList = list
          }
        }
      }
    },
     // 获取申请单详细信息
    async getWorkflowFormDetailFn(){
      const { code, data, msg } = await getWorkflowFormDetail(this.workflowContentId);
      if (code === 0) {
        if(data){
          data.title = data.form_title
          this.workflowFormDetail = data;
          // if(data.business_type === 10){//随手记
          //   this.anymarkIndexFn(data.business_data_id)//获取随手记详情
          //   // this.isWGC = data.business_sub_type_name === '微广场'//判断是否为微广场
          // }
        }else{
          this.workflowFormDetail = {};
        }
      } else {
        this.$message({
          message: msg,
          type: "error",
        });
      }
    },
    // async anymarkIndexFn(id){
    //   const { code, data, msg } = await webRequest.anymarkIndex(id);
    //   if (code === 0) {
    //     this.currenttemplateId = data.template_id
    //     this.currentContentId = data.content_id
    //     this.fetchContentForm(data.template_id)
    //   } else {
    //     this.$message({
    //       message: msg,
    //       type: "error",
    //     });
    //   }
    // },
    // 下拉列表数据
    async getOptionsData(selectFieldList) {
      console.log('getOptionsData,',selectFieldList)
      for (let index = 0; index < selectFieldList.length; index++) {
        const item = selectFieldList[index];
        //    取数据源
        if (item.bind_source && item.bind_source.table.length > 0) {
          await FieldSourceDataList({ field_id_list: [item.id] }).then((res) => {
            if (res.code === 0) {
              const arr = res.data[0].sourceData.map((x) => {
                return {
                  key: x.key,
                  value:
                    item.data_type === FIELD_DATA_TYPE.整数
                      ? parseInt(x.value)
                      : item.data_type === FIELD_DATA_TYPE.小数
                      ? parseFloat(x.value)
                      : x.value,
                };
              });

              this.$set(this.OptionsData, item.column_name, arr);
            }
          });
        } else if (item.dic_code) {
          //获取字典选项
          await this.getItemListFn(item);
        } else {
          if (
            item.dictionary_item_list &&
            item.dictionary_item_list.length > 0
          ) {
            const arr = item.dictionary_item_list.map((x) => {
              return {
                key: x.dict_key,
                value:
                  item.data_type === FIELD_DATA_TYPE.整数
                    // ? parseInt(x.dict_value)
                    ? x.dict_value
                    : item.data_type === FIELD_DATA_TYPE.小数
                    ? parseFloat(x.dict_value)
                    : x.dict_value,
              };
            });
            this.$set(this.OptionsData, item.column_name, arr);
          }
        }
        
      }
    },
    async getItemListFn(item) {
      let params = {
        // category_code: item.dic_code,
        dic_type_code: item.dic_code,
      };
      const { data } = await getItemList(params);
      data.forEach((item) => {
        item.key = item.dic_define_value;
        item.value = item.dic_define_code;
      });
      this.$set(this.OptionsData, item.column_name, data);
    },
  },
}
</script>

<style lang="less" scoped>
.drawerContent1{
  // padding: 30px 30px 0px 36px;
  box-sizing: border-box;
  color: #303133;
  overflow: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%;
  font-size: 14px;
}
.contentMain{
  display: flex;
  flex-direction: column;
  flex: 1;
  overflow: auto;
  box-sizing: border-box;
  .contentLeft{
    
  }
  .contentRight{
    padding: 0 20px;
    .timelineMain{  
      padding-right: 10px;
    }
    .timelinePartTitle{
        font-size: 16px;
        color: #28354C;
        margin-bottom: 15px;
        font-weight: bold;
    }
  }
}
.contentFoot{
  /deep/.footButtons{
    width: 100%;
    margin-left: 0;
    margin-bottom: 0;
    padding: 10px 0px;
    box-sizing: border-box;
  }
}
//修改滚动条样式
.contentMain::-webkit-scrollbar-track-piece {
  background-color: #f8f8f800;
}
.contentMain::-webkit-scrollbar {
  width: 6px;
  transition: all 2s;
}
.contentMain::-webkit-scrollbar-thumb {
  background-color: #dddddd;
  border-radius: 100px;
}
.contentMain::-webkit-scrollbar-thumb:hover {
  background-color: #bbb;
}
.contentMain::-webkit-scrollbar-corner {
  background-color: rgba(255, 255, 255, 0);
}
.saveButton {
  border-top: 1px solid #dcdfe6;
  padding: 10px;
  text-align: right;
}
</style>