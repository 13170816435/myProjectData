<template>
  <div>
    <el-form
      class="editForm"
      ref="editForm"
      :model="contentData"
      label-position="top"
      label-width="auto"
    >
      <el-row :gutter="10">
        <template v-for="(item,index) in fieldList">
          <div :key="item.id">
            <el-col :span="dealColWidth(item.page_proportion)">
              
              <el-form-item
                v-if="item.column_name === 'create_user_id'"
                :key="item.id"
                :rules="fieldRules[item.column_name]"
                :label="item.field_name + '：'"
                :prop="item.column_name"
              >
                <el-select
                  v-model="contentData[item.column_name]"
                  filterable
                  style="width: 100%"
                >
                <el-option
                    v-for="item in groupMemberList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                    <span style="">{{ item.name }}</span>
                    <span
                      v-if="item.work_no"
                      style="color: #8492a6; font-size: 13px"
                      >( {{ item.work_no }} )</span
                    >
                </el-option>
                </el-select>
              </el-form-item>
              <el-form-item
                v-else-if="item.field_type == FIELD_DISPLAY_TYPE.下拉框"
                :key="item.id"
                :rules="fieldRules[item.column_name]"
                :label="item.field_name + '：'"
                :prop="item.column_name"
              >
                <el-select
                  v-model="contentData[item.column_name]"
                  :placeholder="
                    item.field_property
                      ? item.field_property.tip_message
                      : item.field_name
                  "
                  style="width: 100%"
                  clearable
                >
                  <el-option
                    v-for="optionItem in OptionsData[item.column_name]"
                    :key="optionItem.value"
                    :label="optionItem.key"
                    :value="optionItem.value"
                  />
                </el-select>
              </el-form-item>
              <el-form-item
                v-else-if="item.field_type == FIELD_DISPLAY_TYPE.下拉框多选"
                :key="item.id"
                :rules="fieldRules[item.column_name]"
                :label="item.field_name + '：'"
                :prop="item.column_name"
              >
                <el-select
                  v-model="contentData[item.column_name]"
                  :placeholder="
                    item.field_property
                      ? item.field_property.tip_message
                      : item.field_name
                  "
                  multiple
                  filterable
                  style="width: 100%"
                  clearable
                >
                  <el-option
                    v-for="optionItem in OptionsData[item.column_name]"
                    :key="optionItem.value"
                    :label="optionItem.key"
                    :value="optionItem.value"
                  />
                </el-select>
              </el-form-item>
              <el-form-item
                v-else-if="item.field_type == FIELD_DISPLAY_TYPE.富文本"
                :key="item.id"
                :rules="fieldRules[item.column_name]"
                :label="item.field_name + '：'"
                :prop="item.column_name"
              >
                <TinymceEditor
                  :editorKey="item.id"
                  :businessId="contentid?contentid:'0'" typeCode='Anymark'
                  v-model="contentData[item.column_name]"
                ></TinymceEditor>
              </el-form-item>
              <el-form-item
                v-else-if="item.field_type == FIELD_DISPLAY_TYPE.时间"
                :key="item.id"
                :rules="fieldRules[item.column_name]"
                :label="item.field_name + '：'"
                :prop="item.column_name"
              >
                <el-date-picker
                  v-model="contentData[item.column_name]"
                  clearable
                  value-format="yyyy-MM-dd HH:mm:ss"
                  type="datetime"
                  style="width: 100%"
                  :placeholder="
                    item.field_property
                      ? item.field_property.tip_message
                      : item.field_name
                  "
                />
              </el-form-item>
              <el-form-item
                v-else-if="item.field_type == FIELD_DISPLAY_TYPE.日期"
                :key="item.id"
                :rules="fieldRules[item.column_name]"
                :label="item.field_name + '：'"
                :prop="item.column_name"
              >
                <el-date-picker
                  v-model="contentData[item.column_name]"
                  clearable
                  value-format="yyyy-MM-dd"
                  type="date"
                  style="width: 100%"
                  :placeholder="
                    item.field_property
                      ? item.field_property.tip_message
                      : item.field_name
                  "
                />
              </el-form-item>
              <el-form-item
                class="defaultRowItem"
                v-else-if="item.field_type == FIELD_DISPLAY_TYPE.图片上传"
                :key="item.id"
                :rules="fieldRules[item.column_name]"
                :label="item.field_name + '：'"
                :prop="item.column_name"
              >
                <el-upload
                  :ref="'image_' + item.column_name"
                  action=""
                  :auto-upload="false"
                  :on-change="
                    (file, fileList) => {
                      changFile(file, fileList, item.column_name);
                    }
                  "
                  accept="image/*"
                  list-type="picture-card"
                  :multiple="
                    item.field_property.image_field_property
                      .upload_image_type == 1
                  "
                  :limit="item.field_property.image_field_property.maximum"
                  :file-list="uploadFileList[item.column_name]"
                  :on-success="
                    (response, file, fileList) => {
                      handlesuccess(response, file, fileList, item.column_name);
                    }
                  "
                  :on-preview="
                    (file) => {
                      handlePictureCardPreview(file, item.column_name);
                    }
                  "
                  :on-remove="
                    (file, fileList) => {
                      handleRemove(file, fileList, item.column_name);
                    }
                  "
                  :on-exceed="
                    (file, fileList) => {
                      handleExceed(
                        file,
                        fileList,
                        item.field_property.image_field_property.maximum
                      );
                    }
                  "
                  :before-upload="beforeUpload"
                  :before-remove="beforeRemove"
                >
                  <i class="el-icon-plus" />
                </el-upload>
              </el-form-item>
              <el-form-item
                class="defaultRowItem"
                v-else-if="item.field_type == FIELD_DISPLAY_TYPE.文件上传"
                :key="item.id"
                :rules="fieldRules[item.column_name]"
                :label="item.field_name + '：'"
                :prop="item.column_name"
              >
                <el-upload
                  :ref="'file_' + item.column_name"
                  action=""
                  :auto-upload="false"
                  :disabled="!(item.progress === 0 || item.progress === 100)"
                  drag
                  :file-list="paperFileList[item.column_name]"
                  :on-remove="
                    (file, fileList) => {
                      handleFileRemove(file, fileList, item.column_name);
                    }
                  "
                  :on-change="
                    (file, fileList) => {
                      handlefileSuccess(file, fileList, item.column_name, index);
                    }
                  "
                >
                  <i class="el-icon-upload"></i>
                  <div class="el-upload__text">
                    将文件拖到此处，或<em>点击上传</em>
                  </div>
                  <div class="el-upload__tip" slot="tip">
                    附件支持上传文件格式：.xls .xlsx .ppt .pptx .doc .docx .pdf
                    .zip .rar .txt .xmid .visio
                  </div>
                </el-upload>
                <el-progress v-if="item.progress>0" style="width:411px" :percentage="item.progress" />
              </el-form-item>
              <el-form-item
                class="defaultRowItem"
                v-else-if="item.field_type == FIELD_DISPLAY_TYPE.视频"
                :key="item.id"
                :rules="fieldRules[item.column_name]"
                :label="item.field_name + '：'"
                :prop="item.column_name"
              >
                <!-- action必选参数, 上传的地址 -->
                <el-upload
                  :ref="'video_' + item.column_name"
                  :disabled="!(item.progress === 0 || item.progress === 100)"
                  class="avatar-uploader el-upload--text"
                  action=""
                  :auto-upload="false"
                  drag
                  :file-list="videoFileList[item.column_name]"
                  :on-remove="
                    (file, fileList) => {
                      handleVideoRemove(file, fileList, item.column_name);
                    }
                  "
                  :on-change="
                    (file, fileList) => {
                      handleVideoSuccess(file, fileList, item.column_name, index);
                    }
                  "
                >
                  <!--  -->
                  <!-- :on-progress="uploadVideoProcess" -->
                  <i class="el-icon-upload"></i>
                  <div class="el-upload__text">
                    将文件拖到此处，或<em>点击上传</em>
                  </div>
                  <div class="el-upload__tip" slot="tip">
                    附件支持上传文件格式：.mp4,.ogg,.flv,.avi,.wmv,.rmvb,请保证视频格式正确。
                  </div>
                </el-upload>
                <el-progress v-if="item.progress>0" style="width:411px" :percentage="item.progress" />
              </el-form-item>
              <el-form-item
                class="defaultRowItem"
                v-else-if="item.field_type == FIELD_DISPLAY_TYPE.多行文本"
                :key="item.id"
                :rules="fieldRules[item.column_name]"
                :label="item.field_name + '：'"
                :prop="item.column_name"
              >
                <el-input
                  v-if="item.length > 0"
                  v-model="contentData[item.column_name]"
                  :autosize="{ minRows: 4, maxRows: 8 }"
                  type="textarea"
                  :placeholder="
                    item.field_property
                      ? item.field_property.tip_message
                      : item.field_name
                  "
                  :maxlength="item.length"
                  show-word-limit
                />
                <el-input
                  v-else
                  v-model="contentData[item.column_name]"
                  :autosize="{ minRows: 4, maxRows: 8 }"
                  type="textarea"
                  :placeholder="
                    item.field_property
                      ? item.field_property.tip_message
                      : item.field_name
                  "
                />
              </el-form-item>

              <el-form-item
                v-else
                :key="item.id"
                :rules="fieldRules[item.column_name]"
                :label="item.field_name + '：'"
                :prop="item.column_name"
              >
                <!-- <el-tag
                  v-if="item.is_title === 1"
                  slot="label"
                  type="success"
                  >{{ item.field_name }}</el-tag
                > -->
                <!-- 正常标签 -->
                <span slot="label">{{ item.field_name + "：" }}</span>
                <el-input
                  v-if="
                    item.length > 0 && item.data_type === FIELD_DATA_TYPE.字符串
                  "
                  v-model="contentData[item.column_name]"
                  class="text"
                  clearable
                  :placeholder="
                    item.field_property ? item.field_property.tip_message : ''
                  "
                  :maxlength="item.length"
                  show-word-limit
                />
                <!-- 小数单行文本 -->
                <el-input-number
                  size="small"
                  v-else-if="
                    item.length > 0 && item.data_type === FIELD_DATA_TYPE.小数
                  "
                  v-model="contentData[item.column_name]"
                  :precision="item.scale"
                />
                <!-- 整数单行文本 -->
                <el-input-number
                  size="small"
                  v-else-if="
                    item.length > 0 && item.data_type === FIELD_DATA_TYPE.整数
                  "
                  v-model="contentData[item.column_name]"
                  :precision="0"
                />
                <el-input
                  v-else
                  v-model="contentData[item.column_name]"
                  class="text"
                  clearable
                  :placeholder="
                    item.field_property ? item.field_property.tip_message : ''
                  "
                />
              </el-form-item>
            </el-col>
          </div>
        </template>
      </el-row>
    </el-form>
    <!-- <div class="saveButton">
      <el-button v-show="isShowToTypeListBtn" @click="jumpToType">跳转到分类</el-button>
      <el-button v-show="!isShowReturnBtn" @click="jump">返回列表</el-button>
      <el-button :disabled="saveBtnDisabled" @click="valid(1)"
        >存草稿</el-button
      >
      <el-button type="primary" :disabled="saveBtnDisabled" @click="valid"
        >提交内容</el-button
      >
    </div> -->
    <!-- 预览图片的弹窗 -->
    <el-dialog v-el-drag-dialog :visible.sync="dialogVisible">
      <div class="imgbody">
        <img :src="dialogImageUrl" style="height: 100%" alt="" />
      </div>
    </el-dialog>
    <!-- <dialogItem
      dialogTitle="提醒"
      :setWidth="'400px'"
      :setMT="0"
      :isHeightCenter="true"
      :isShowCLoseIcon="false"
      :isShowSubmit="false"
      :isShowCencel="false"
      :footerAlign="'right'"
      v-if="isShowCloseTip"
    > 
      <div style="padding:15px 20px;">
        <i class="el-icon-warning mr5" style="font-size: 24px !important; vertical-align: text-top; color: #e6a23c;"></i>
        <span v-if="workflowName">{{`提交成功，待"${workflowName}"审批`}}</span>
        <span v-else>提交成功</span>
      </div>
      <el-button
        slot="footer_button"
        type="default"
        size="mini"
        v-if="workflowId"
        @click="closeDeal(1)"
        >转到待办</el-button
      >
      <el-button
        slot="footer_button"
        type="default"
        size="mini"
        @click="closeDeal(3)"
        >返回列表</el-button
      >
      <el-button
        slot="footer_button"
        type="primary"
        size="mini"
        @click="closeDeal(2)"
        >继续新增</el-button
      >
    </dialogItem> -->
  </div>
</template>

<script>
import { FieldSourceDataList } from "@/api/anymark/marktemplatefield";
import { UpdateContent } from "@/api/anymark/markcontent";
import * as webRequest from "@/api/anymark/qiniu";
import { msg } from "@/utils/common";
import { FIELD_DATA_TYPE, FIELD_DISPLAY_TYPE } from "@/utils";
import { validateRule } from "@/utils/rules";
import elDragDialog from "@/directive/el-drag-dialog";
import { getItemList } from "@/api/dictionary";
import TinymceEditor from "@/components/tinymce-editor/index.vue";
import { getAllTenancies} from "@/api/department/user";
import Mgr from "@/utils/SecurityService";
import { DeleteContent } from "@/api/anymark/markcontent"
import moment from 'moment'
export default {
  components: { TinymceEditor },
  directives: { elDragDialog },
  props: {
    contentid: {
      type: String,
      default: undefined,
    },
    templateId: {
      type: String,
      //   required: true,
      default: undefined,
    },
    categoryId: {
      type: String,
      //   required: true,
      default: undefined,
    },
    isPublic: {
      type: Number,
      required: false,
      default: 0,
    },
    isPerson: {
      require: false,
      type: Boolean,
      default: false,
    },
    contentDetail: {
      type: Object,
      require: false,
      default() {
        return {}
      },
    },
    OptionsData: {
      type: Object,
      require: false,
      default() {
        return {}
      },
    },
    allFieldList: {
      type: Array,
      require: true,
      default() {
        return []
      },
    },
    defultDeviceForm: {//设备管理 默认设备  填写时间
      require: false,
      type: Object,
      default: ()=>{
        return {}
      },
    },
  },
  data() {
    return {
      apiName: "customtemplatecontent",
      fieldList: [],
      businessFieldList: [],
      fieldRules: [],
      contentData: {},
      editForm: {
        categoryID: undefined,
      },
      // OptionsData: {},
      FIELD_DISPLAY_TYPE: FIELD_DISPLAY_TYPE,
      FIELD_DATA_TYPE: FIELD_DATA_TYPE,
      dialogImageUrl: "",
      dialogVisible: false,
      uploadURL: webRequest.UPLOAD_IMAGE_URL,
      uploadURL1: webRequest.PREVIEW_FILE_URL,
      uploadFileList: {},
      paperFileList: {},
      videoFileList: {},
      uploadImgListTemp: [],
      imageFieldList: [],
      saveBtnDisabled: true,
      readyFileList: [],
      readyColumnName: "",
      fileList: [],
      videoList: [],
      formdata: new FormData(),
      Video: "",
      // 防抖方法
      debounceHandleFileChange: undefined,
      groupMemberList:[],//用户列表
      editDraftId:"",//保存第一次草稿进入编辑后传过过来的draftId  防止草稿新增后 再次存为草稿会变成更新上次删除的草稿
      workflowId:'',//审批流id
      workflowName:'',//审批流name
      template_name:'',//模板name
      description:'',//模板备注
      isShowCloseTip:false,
      loading:false,
    };
  },
  computed: {
    isShowReturnBtn() {
      return window.history.length <= 2 || this.$route.query.ShowMode === 0;
    },
    routeQueryData() {
      return this.$route.query;
    },
  },
  watch: {
    defultDeviceForm: {
      handler(n, o) {
        const nowDate = moment().format('YYYY-MM-DD HH:mm:ss')
        //设备运行记录 设置默认值
        this.$set( this.contentData, 'report_date', n.date?n.date:nowDate);
        this.$set( this.contentData, 'equipment_id', n.deviceId?n.deviceId:'' );
      },
      immediate: true,
      deep:true
    },
    
    templateId: {
      handler(n, o) {
        this.fetchContentForm();
        this.setFormRule();
      },
      immediate:true,
      deep:true
    },
    // 监视待上传文件列表，延时上传
    readyFileList: {
      handler() {
        this.debounceHandleFileChange();
      },
    },
  },
  created() {
    const _ = require("lodash"); // 引用
    this.debounceHandleFileChange = _.debounce(this.submitformdata, 1000); // 此处submitformdata是在methods中定义的函数， 1000单位为毫秒，延迟1秒再调用，
    if(this.isPublic && this.isPerson && this.$prm_codes.includes('person_maintain_data')){
        this.getUsersLiteFn(1);
    }
  },
  methods: {
    clearDate(){//继续新增 保存完，就停留在当前页面，但是清空表单
      this.fieldList
      .filter((x) => x.field_type === FIELD_DISPLAY_TYPE.图片上传)
      .forEach((item, index, array) => {
        this.$set(this.uploadFileList, item.column_name, []);
        this.$refs[`image_${item.column_name}`][0].clearFiles(); // 清空已上传的图片
      });
      this.fieldList
        .filter((x) => x.field_type === FIELD_DISPLAY_TYPE.文件上传)
        .forEach((item, index, array) => {
          this.$set(this.paperFileList, item.column_name, []);
          this.$refs[`file_${item.column_name}`][0].clearFiles(); // 清空已上传的文件
        });
      this.fieldList
        .filter((x) => x.field_type === FIELD_DISPLAY_TYPE.视频)
        .forEach((item, index, array) => {
          this.$set(this.videoFileList, item.column_name, []);
          this.$refs[`video_${item.column_name}`][0].clearFiles(); // 清空已上传的视频
        });
      this.contentData={}
      this.$refs["editForm"].resetFields(); // 创建内容，保存完，就停留在当前页面，但是清空表单
    },
    async getUsersLiteFn(page) {
      const params = {
        offset: page,
        limit: 100,
        state: 1,
      };
      //科室管理与 pacs项目查询用户传参不同
      if(this.$currentSystemClass === 'DMS_RIS'){
        params.business_system_id = sessionStorage.getItem("lastname")
        params.business_system_type = "dms"
      }else{
        params.system_id = sessionStorage.getItem("lastname")
      }
      const { data } = await getAllTenancies(params);
      if (data.length > 0) {
        data.forEach((element) => {
          this.groupMemberList.push(element);
        });
        if (data.length === 100) {
          this.getUsersLiteFn(page + 1);
        }
      }
    },
    dealColWidth(val) {
      let widthVal = "";
      if (val) {
        switch (val) {
          case 1:
            widthVal = 6;
            break;
          case 2:
            widthVal = 12;
            break;
          case 3:
            widthVal = 18;
            break;
          default:
            widthVal = 18;
            break;
        }
      } else {
        widthVal = 24;
      }
      return widthVal;
    },
    spanfilter(fieldtype, datatype, width) {
      return fieldtype === FIELD_DISPLAY_TYPE.多行文本 ||
        (fieldtype === FIELD_DISPLAY_TYPE.单行文本 &&
          datatype === FIELD_DATA_TYPE.字符串) ||
        fieldtype === FIELD_DISPLAY_TYPE.图片上传 ||
        fieldtype === FIELD_DISPLAY_TYPE.文件上传 ||
        fieldtype === FIELD_DISPLAY_TYPE.视频
        ? 24
        : width;
    },
    // 初始化form表单内容
    fetchContentForm() {
      this.allFieldList.forEach(item =>{
        const {field_type} = item;
        if (field_type === FIELD_DISPLAY_TYPE.文件上传 || field_type === FIELD_DISPLAY_TYPE.视频) {
          item.progress = 0
        }
        if(!item.field_property){
          item.field_property = {}
        }
      })
      //如果有设置 设备与填报时间  编辑页面不显示 设备与填报时间阻断
      // if(JSON.stringify(this.defultDeviceForm) !== '{}'){
      //   this.allFieldList = this.allFieldList.filter(item=> !['report_date','equipment_id'].includes(item.column_name))
      // }
      this.fieldList = this.allFieldList.filter(
        (x) => x.is_related_business !== 1
      );
      this.businessFieldList = this.allFieldList.filter(
        (x) => x.is_related_business === 1
      );
      // this.getOptionsData(
      //   this.fieldList.filter(
      //     (x) => (x.field_type === FIELD_DISPLAY_TYPE.下拉框 || x.field_type === FIELD_DISPLAY_TYPE.下拉框多选)
      //   )
      // );
      //新增时 查看模板是否有默认项 有则赋值
      if (!this.contentid && !this.editDraftId) {
        this.fieldList.forEach((item) => {
          const {
            column_name,
            field_property,
            field_type,
            dictionary_item_list,
          } = item;
          //下拉框如果有默认选中项则 赋值默认选项
          if (field_type === FIELD_DISPLAY_TYPE.下拉框 || field_type === FIELD_DISPLAY_TYPE.下拉框多选) {
            if (
              dictionary_item_list &&
              dictionary_item_list.length > 0
            ) {
              dictionary_item_list.forEach((dictionary) => {
                if (dictionary.is_default) {
                  if(field_type === FIELD_DISPLAY_TYPE.下拉框多选){
                    this.$set(
                      this.contentData,
                      column_name,
                      [dictionary.dict_value]
                    );
                  }else{
                    this.$set(
                      this.contentData,
                      column_name,
                      dictionary.dict_value
                    );
                  }
                  
                }
              });
            }
          } else {
            if (field_property && field_property.default_value) {
              this.$set(
                this.contentData,
                column_name,
                field_property.default_value
              );
            }
          }
          if(column_name === 'create_user_id'){
            // const loginInfo = JSON.parse(localStorage.getItem('loginInfo'))//1
            const loginInfo = JSON.parse(this.$loginInfo)
            this.$set(
                this.contentData,
                column_name,
                loginInfo.profile.sub
            );
          }
          //设备运行记录 设置默认值
          if(column_name === 'report_date'){
            this.$set(
                this.contentData,
                column_name,
                this.defultDeviceForm.date?this.defultDeviceForm.date:''
            );
          }
          if(column_name === 'equipment_id'){
            this.$set(
                this.contentData,
                column_name,
                this.defultDeviceForm.deviceId?this.defultDeviceForm.deviceId:''
            );
          }
        });
      }else{
        this.setContentData()
      }
      this.saveBtnDisabled = false;
    },
    // 加载内容
    async setContentData() {
      console.log('setContentData',this.contentDetail)
      this.contentData =JSON.parse(JSON.stringify(this.contentDetail));
          if (this.fieldList.length > 0) {
            this.fieldList.map((item) => {
              if (
                item.field_type === 7 ||
                item.field_type === 8 ||
                item.field_type === 10
              ) {
                let urls = this.contentData[item.column_name].map((x) => {
                  return {
                    name: x.old_name,
                    link: x.id,
                    url:
                      item.field_type === 7?
                      webRequest.PREVIEW_IMAGE_URL +`?documentId=${x.id}&tenancyid=${this.$tenancyId}` 
                      :webRequest.PREVIEW_FILE_URL +`?documentId=${x.id}&tenancyid=${this.$tenancyId}`,
                  };
                });
                switch (item.field_type) {
                  case 7:
                    this.$set(this.uploadFileList, item.column_name, urls);
                    return;
                  case 8:
                    this.$set(this.paperFileList, item.column_name, urls);
                    return;
                  case 10:
                    this.$set(this.videoFileList, item.column_name, urls);
                    return;
                }
              }else if (item.field_type === this.FIELD_DISPLAY_TYPE.下拉框多选) {
                const fxData = this.contentData[item.column_name]?this.contentData[item.column_name].split(','):[]
                this.$set(this.contentData, item.column_name, fxData);
              }else if (item.field_type === this.FIELD_DISPLAY_TYPE.富文本) {
                //处理 富文本内容 如果包含图片 使用占位符dms_image_domain 替换掉前部configUrl.apiUrl 内容 以防内外网显示不出来
                if( this.contentData[item.column_name]){
                  let value = this.contentData[item.column_name].replaceAll(
                    "dms_image_domain",
                    `${configUrl.docUrl}/api-document`
                  );
                  this.$set(this.contentData, item.column_name, value);
                }
              }
            });
          }
    },
    // 初始化随记内容对象
    initContentData() {
      this.fieldList.forEach((item, index, array) => {
        this.$set(this.contentData, item.column_name, null);
        if (item.field_type === FIELD_DISPLAY_TYPE.图片上传) {
          this.$set(this.uploadFileList, item.column_name, null);
        }
        if (item.field_type === FIELD_DISPLAY_TYPE.文件上传) {
          this.$set(this.paperFileList, item.column_name, null);
        }
        if (item.field_type === FIELD_DISPLAY_TYPE.视频) {
          this.$set(this.videoFileList, item.column_name, null);
        }
      });
    },
    // 新增模板字段验证规则
    setFormRule() {
      this.fieldRules = []; // 先清空原来的验证规则
      this.fieldList.forEach((item, index, array) => {
        let rules = [];
        // 必填字段
        if (item.is_must === 1) {
          rules.unshift({
            required: true,
            message:
              item.field_type === FIELD_DISPLAY_TYPE.图片上传
                ? `【${item.field_name}】为必填字段，必须上传图片`
                : `请${item.field_type < 2 ? "输入" : "选择"}${
                    item.field_name
                  }`,
            trigger: `${item.field_type < 2 ? "blur" : "change"}`,
          });
        }
        // 整数
        if (item.data_type === FIELD_DATA_TYPE.整数) {
          if (item.field_property.is_set_range) {
            const integerRule = (rule, value, callback) => {
              if (
                value &&
                !(
                  Number(value) >=
                    item.field_property.number_field_property.lower_limit &&
                  Number(value) <=
                    item.field_property.number_field_property.upper_limit
                )
              ) {
                callback(
                  new Error(
                    `${item.field_name}的区间范围是${item.field_property.number_field_property.lower_limit}-${item.field_property.number_field_property.upper_limit}`
                  )
                );
              } else if (
                !value ||
                (Number.isInteger(Number(value)) && Number(value) > 0)
              ) {
                callback();
              } else {
                callback(new Error("请输入大于零的正整数"));
              }
            };

            rules.unshift({
              validator: integerRule,
              //   trigger: `${item.field_type < 2 ? 'blur' : 'change'}`,
              trigger: ["blur", "change"],
            });
          } else {
            rules.unshift({
              validator: validateRule.integerP,
              message: `${item.field_name}必须为正整数，且大于0`,
              //   trigger: `${item.field_type < 2 ? 'blur' : 'change'}`,
              trigger: ["blur", "change"],
            });
          }
        }
        // 小数
        if (item.data_type === FIELD_DATA_TYPE.小数) {
          if (item.field_property.is_set_range) {
            const numberRule = (rule, value, callback) => {
              if (
                value &&
                !(
                  Number(value) >=
                    item.field_property.number_field_property.lower_limit &&
                  Number(value) <=
                    item.field_property.number_field_property.upper_limit
                )
              ) {
                callback(
                  new Error(
                    `${item.field_name}的区间范围是${item.field_property.number_field_property.lower_limit}-${item.field_property.number_field_property.upper_limit}`
                  )
                );
              } else if (
                !value ||
                (Number(value) && !/^-?\d+\.?\d*$/.test(value))
              ) {
                callback(new Error(`${item.field_name}必须为数字`));
              } else {
                callback();
              }
            };

            rules.unshift({
              validator: numberRule,
              //   trigger: `${item.field_type < 2 ? 'blur' : 'change'}`,
              trigger: ["blur", "change"],
            });
          } else {
            rules.unshift({
              pattern: /^-?\d+\.?\d*$/,
              message: `${item.field_name}必须为数字`,
              //   trigger: `${item.field_type < 2 ? 'blur' : 'change'}`,
              trigger: ["blur", "change"],
            });
          }
        }
        // 长度验证
        if (
          item.length > 0 &&
          item.data_type === FIELD_DATA_TYPE.字符串 &&
          item.field_type !== FIELD_DISPLAY_TYPE.图片上传 &&
          item.field_type !== FIELD_DISPLAY_TYPE.文件上传 &&
          item.field_type !== FIELD_DISPLAY_TYPE.视频 &&
          item.field_type !== FIELD_DISPLAY_TYPE.下拉框多选 
        ) {
          rules.unshift({
            max: item.length,
            message: `长度不能超过${item.length}个字符`,
            trigger: `${item.field_type < 2 ? "blur" : "change"}`,
          });
        }
        if(item.field_type === FIELD_DISPLAY_TYPE.下拉框多选 && item.is_must === 1){
          rules = [{
            required: true,
            message:`请选择${item.field_name}`,
            trigger:"blur"
          }]
        }
        this.$set(this.fieldRules, item.column_name, rules);
        // console.log(rules)
        // this.$set(this.contentData, item.column_name, null)
      });
    },
    changFile(file, fileList, column_name) {
      //  this.beforeUpload(file)
      if (
        ["image/jpeg", "image/gif", "image/bmp", "image/png"].indexOf(
          file.raw.type
        ) == -1
      ) {
        this.$message.error("上传图片只能是 JPG、GIF、BMP、PNG 格式!");
        if (!this.uploadFileList.hasOwnProperty(column_name)) {
          console.log(1);
          this.$set(this.uploadFileList, column_name, []);
        } else {
          let arr = fileList.filter((item) => {
            return item.name !== file.name;
          });

          this.$set(this.uploadFileList, column_name, arr);
          this.contentData[column_name] = arr.length; // 赋值文件长度，防止验证报错
        }
        return false;
      }
      this.readyFileList = fileList.filter((x) => x.status === "ready");
      this.readyColumnName = column_name;
    },
    async submitformdata() {
      const column_name = this.readyColumnName;
      // this.formdata = new FormData();
      // this.readyFileList.forEach((i) => {
      //   this.formdata.append("files", i.raw); // 自行组建，上传的文件
      // });
      let count = 0
      for (let index = 0; index < this.readyFileList.length; index++) {
        const element = this.readyFileList[index];
        // const formdata = new FormData();
        console.log(element.raw)
        // formdata.append("file", element.raw);
        const param={
          businessId:this.contentid?this.contentid:'0',
          typeCode:'Anymark'
        }
        const  { document_id, code } = await  this.$uploadSplitFile(element.raw,param)
        if (code === 0) {
          if (!this.uploadFileList.hasOwnProperty(column_name)) {
            this.$set(this.uploadFileList, column_name, []);
          }
          this.uploadFileList[column_name].push({
            name: element.name,
            link: document_id,
            url: `${webRequest.PREVIEW_IMAGE_URL}?documentId=${document_id}&tenancyid=${this.$tenancyId}`,
          });
          if (!this.contentData.hasOwnProperty(column_name)) {
            this.$set(this.contentData, column_name, "");
          }
          count++
        }
      }
      this.contentData[column_name] = count; // 赋值文件长度，防止验证报错
     
    },

    // 单个自动上传图片
    handlesuccess(response, file, fileList, column_name) {
      console.log("handlesuccess", response, file, fileList);
      if (response.code === 0) {
        msg.info(response.message, "msg");
        this.uploadImgListTemp.push({
          name: file.response.data.imageUrl,
          url: webRequest.PREVIEW_IMAGE_URL + file.response.data.previewUrl,
        });

        if (!this.contentData.hasOwnProperty(column_name)) {
          this.$set(this.contentData, column_name, "");
        }
        this.contentData[column_name] = fileList.length; // 赋值文件长度，防止验证报错
      } else msg.error(response.msg, "msg");
    },
    // 删除图片
    handleRemove(file, fileList, column_name) {
      // console.log("handleRemove", file, fileList);
      if (file && file.status === "success") {
        this.contentData[column_name] =
          fileList.length === 0 ? "" : fileList.length; // 赋值文件长度，防止验证报错
        const index = this.uploadFileList[column_name].findIndex(
          (x) => x.name === file.name
        );
        this.uploadFileList[column_name].splice(index, 1);
      }
    },
    handleFileRemove(file, fileList, column_name) {
      this.contentData[column_name] =
        fileList.length === 0 ? "" : fileList.length; // 赋值文件长度，防止验证报错
      const index = this.paperFileList[column_name].findIndex(
        (x) => x.name === file.name
      );
      this.paperFileList[column_name].splice(index, 1);
    },
    handleVideoRemove(file, fileList, column_name) {
      this.contentData[column_name] =
        fileList.length === 0 ? "" : fileList.length; // 赋值文件长度，防止验证报错
      const index = this.videoFileList[column_name].findIndex(
        (x) => x.name === file.name
      );
      this.videoFileList[column_name].splice(index, 1);
    },
    // 预览图片
    handlePictureCardPreview(file, column_name) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    handleExceed(files, fileList, maxlength) {
      msg.warning(
        `当前限制上传${maxlength}张图片，本次选择了 ${files.length} 张图片，已达到限制的最大上传数量`,
        "msg"
      );
    },

    // 删除图片前确认提示框
    beforeRemove(file, fileList) {
      //   console.log('beforeRemove', file, fileList)
      let a = true;
      if (file && file.status === "success") {
        a = this.$confirm(`确定移除这张图片吗？`, "提示",{customClass: 'confirm-dialog--ew',});
      }
      return a;
    },
    // 文件上传之前验证
    beforeUpload(file) {
      // 方法不能额外加参数，不然这个return false之后还是会上传！！
      console.log("beforeUpload", file);
      const types = ["image/jpeg", "image/gif", "image/bmp", "image/png"];
      const isImage = types.includes(file.type);
      const isLtSize = file.size / 1024 / 1024 < 5;
      if (!isImage) {
        console.log("上传图片");
        msg.error("上传图片只能是 JPG、GIF、BMP、PNG 格式!", "msg");
        return false; // 返回false不会自动上传
      }

      if (!isLtSize) {
        msg.error("上传图片大小不能超过 5MB!", "msg");
        return false;
      }

      // this.uploadImgListTemp = [];
      return true;
    },
    beforeUploadVideo(file) {
      console.log(file);
    },
    handleVideoSuccess(file, data, column_name, index) {
      const isLt10M = file.size / 1024 / 1024 < 10;
      if (
        [
          "video/mp4",
          "video/ogg",
          "video/flv",
          "video/avi",
          "video/wmv",
          "video/rmvb",
        ].indexOf(file.raw.type) == -1
      ) {
        this.$message.error("请上传正确的视频格式");
        if (!this.videoFileList.hasOwnProperty(column_name)) {
          this.$set(this.videoFileList, column_name, []);
        } else {
          // console.log(this.videoFileList[column_name])
          let arr = data.filter((item) => {
            return item.name !== file.name;
          });
          this.$set(this.videoFileList, column_name, arr);
        }
        return false;
      }
      // if (!isLt10M) {
      //     this.$message.error('上传视频大小不能超过10MB哦!');
      //     return false;
      // }
      // let formdata = new FormData();
      // formdata.append("file", file.raw);
      this.saveBtnDisabled = true;
      const param={
        businessId:this.contentid?this.contentid:'0',
        typeCode:'Anymark'
      }
      this.$uploadSplitFile(file.raw,param,this,index).then((res) => {
        this.saveBtnDisabled = false;
        let { document_id } = res;
        if (!this.videoFileList.hasOwnProperty(column_name)) {
          this.$set(this.videoFileList, column_name, []);
        }
        this.videoFileList[column_name].push({
          name: file.name,
          url: document_id,
          link: document_id,
        });
        console.log(this.videoFileList);
        this.$set(this.contentData, column_name, this.videoFileList[column_name]);
        // this.contentData[column_name] = this.videoFileList[column_name];
        this.fieldList[index].progress  = 0;
      }).catch(e=>{
        this.saveBtnDisabled = false;
      })
    },
    handlefileSuccess(file, data, column_name, index) {
      const isLt10M = file.size / 1024 / 1024 < 10;
      const param={
        businessId:this.contentid?this.contentid:'0',
        typeCode:'Anymark'
      }
      this.saveBtnDisabled = true;
      this.$uploadSplitFile(file.raw,param,this,index).then((res) => {
        this.saveBtnDisabled = false;
        let { document_id } = res;
        if (!this.paperFileList.hasOwnProperty(column_name)) {
          this.$set(this.paperFileList, column_name, []);
        }
        this.paperFileList[column_name].push({
          name: file.name,
          url: document_id,
          link: document_id,
        });
        // let files = this.paperFileList[column_name].map(item=>{return item.url});
        this.$set(this.contentData, column_name, this.paperFileList[column_name]);
        // this.contentData[column_name] =  this.paperFileList[column_name]
        this.fieldList[index].progress  = 0;
      }).catch(e=>{
        this.saveBtnDisabled = false;
      })
    },
    async valid(flag) {//flag为1表示 暂存不验证是否必填
      const resetKey = {};
      let isValid = true
      await this.$refs["editForm"].validate((valid) => {
        if (!valid) {
          if(flag !== 1){
            this.saveBtnDisabled = false;
            // msg.warning('验证未通过', 'msg')
            isValid = false
            return false;
          }
        }
        if(flag){//存草稿 清除验证
          this.clearValidate()
        }
          // 动态拼接实体对象
          // const resetKey = {};
          this.fieldList.map((x) => {
            if (x.field_type === FIELD_DISPLAY_TYPE.文件上传) {
              let urls = [];
              if (
                this.paperFileList[x.column_name] &&
                this.paperFileList[x.column_name].length > 0
              ) {
                urls = this.paperFileList[x.column_name].map((item) => {
                  return item.link;
                });
              }
              resetKey[x.column_name] = urls.length > 0 ? urls.toString() : "";
            } else if (x.field_type === FIELD_DISPLAY_TYPE.富文本) {
              console.log(this.contentData[x.column_name]);
              //处理 富文本内容 如果包含图片 使用占位符dms_image_domain 替换掉前部configUrl.apiUrl 内容 以防内外网显示不出来
              if (this.contentData[x.column_name]) {
                resetKey[x.column_name] = this.contentData[
                  x.column_name
                ].replaceAll(`${configUrl.docUrl}/api-document`, "dms_image_domain");
              }
            } else if (x.field_type === FIELD_DISPLAY_TYPE.视频) {
              let urls = [];
              if (
                this.videoFileList[x.column_name] &&
                this.videoFileList[x.column_name].length > 0
              ) {
                urls = this.videoFileList[x.column_name].map((item) => {
                  return item.link;
                });
              }
              //  let urls = this.videoFileList[x.column_name].map(item=>{return item.link});
              resetKey[x.column_name] = urls.length > 0 ? urls.toString() : "";
            }else if (x.field_type === FIELD_DISPLAY_TYPE.下拉框多选) {
              resetKey[x.column_name] = this.contentData[x.column_name].join(',');
            } 
            else if (x.data_type === FIELD_DATA_TYPE.小数 ||x.data_type === FIELD_DATA_TYPE.整数  ) {
              resetKey[x.column_name] = this.contentData[x.column_name]?this.contentData[x.column_name]:0;
            }
            else if (x.field_type !== FIELD_DISPLAY_TYPE.图片上传) {
              resetKey[x.column_name] = this.contentData[x.column_name]?this.contentData[x.column_name]:null;
            } else {
              const _uploadimgs =
                this.$refs[`image_${x.column_name}`][0].uploadFiles; // 上传成功的图片
              resetKey[x.column_name] = _uploadimgs
                ? _uploadimgs
                    .map((img) => {
                      return img.status === "success"
                        ? img.hasOwnProperty("response")
                          ? img.response.data.imageUrl
                          : img.link
                        : "";
                    })
                    .join(",")
                : "";
            }
          });

          // 过滤业务数据
          this.businessFieldList.forEach((item) => {
            if (this.routeQueryData.hasOwnProperty(item.column_name)) {
              resetKey[item.column_name] =
                this.routeQueryData[item.column_name];
            }
          });
          //如果有设置 设备与填报时间  编辑页面不显示 设备与填报时间阻断
          // if(JSON.stringify(this.defultDeviceForm) !== '{}'){
          //   resetKey['report_date'] = this.defultDeviceForm.date?this.defultDeviceForm.date:''
          //   resetKey['equipment_id'] = this.defultDeviceForm.deviceId?this.defultDeviceForm.deviceId:''
          // }

          // console.log(resetKey);
          this.saveBtnDisabled = true;
          // this.saveData(resetKey,flag);
      });
      if(isValid){
        console.log("resetKey",resetKey)
        return resetKey
      }else{
        return false
      }
    },
    clearValidate() {
      this.$refs["editForm"].clearValidate();
    },
    jump() {
      this.$emit("backToList");
    },
    jumpToType(){
      //判断跳转到 个人 还是科室页面
      if(!this.isPerson){
        this.$router.push({ 
          path: '/anymark/dept/markcontent/deptlist' ,
          query: {categoryId: this.categoryId },
        })
      }else{
        this.$router.push({ 
          path: '/anymark/person/markcontent/personlist' ,
          query: {
            categoryId: this.categoryId,
            isPublic:this.isPublic
           },
        })
      }
    },
    resetForm() {
      if (this.contentid) {
        this.$router.go(-1); // 返回上一级路由
      } else {
        this.$refs["editForm"].resetFields();
      }
    },
    async deleteContentFn(row){
      await DeleteContent({
        template_id: row.template_id,
        id: row.content_id,
      })
    },
  },
};
</script>

<style lang="scss" scoped>
.container {
  // width:600px;
  // margin: 0 auto;
  height: 100%;
}
.editForm {
  overflow: hidden;
  padding-right: 5px;
  box-sizing: border-box;
}
.saveButton {
  border-top: 1px solid #dcdfe6;
  padding-top: 10px;
  // margin-top: 20px;
  text-align: center;
}

//在样式把这个is-ready给隐藏掉就好了，就是这么Easy
::v-deep.el-upload-list__item.is-ready {
  display: none;
}
::v-deep .el-list-enter-active,
::v-deep .el-list-leave-active {
  transition: none;
}

::v-deep .el-list-enter,
::v-deep .el-list-leave-active {
  opacity: 0;
}
::v-deep .el-upload-list__item {
  //   text-align: center;
  position: relative;

  .el-upload-list__item-thumbnail {
    width: 100%;
    height: 100%;
    position: absolute;
    -o-object-fit: cover;
    object-fit: cover;
  }
}

.imgbody {
  height: calc(100vh - 500px);
  text-align: center;
}
::v-deep .el-upload-list {
  /* max-width: 800px; */
  // display: inline-block;
}
::v-deep .el-form-item__content {
  line-height: 1;
}
::v-deep .el-form-item__label {
  line-height: 32px;
}
::v-deep .el-form-item__label {
  // min-width: 100px;
  // text-align: center;
  // background: #F6F9FF;
  // border: 1px solid #DCDFE6;
  // border-right: 0;
  height: 32px;
  // padding:0 10px;
}
::v-deep .el-form--inline .el-form-item {
  width: 100%;
  display: flex;
}
::v-deep .el-form-item__content {
  flex: 1;
}
.defaultRowItem ::v-deep .el-form-item__label {
  background: #fff;
  border: 0;
  text-align: right;
  // padding-right: 0px;
}
::v-deep .el-input__inner {
    height: 32px;
    line-height: 32px;
    font-size: 14px;
}
</style>
