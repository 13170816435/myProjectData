<template>
  <div class="detail-container">
    <el-form label-position="top" class="itemBody" size="mini" label-width="auto">
      <el-row style="display: flex;flex-wrap: wrap;" :gutter="10">
        <template v-for="item in fieldList" >
          <el-col
          class="mb10"
          :key="item.id"
          v-if="!item.field_property || item.field_property.is_display_detail"
          :span="dealColWidth(item.page_proportion)"
          >
            <el-form-item v-if="item.field_type == FIELD_DISPLAY_TYPE.图片上传&&detailModel[item.column_name]"
                          :key="item.id"  :label="`${item.field_name}：`">
              <span class="imgtd">
                <template v-for="imgItem in detailModel[item.column_name]">
                  <el-image 
                            fit="cover"
                            :key="imgItem.url"
                            :src="PREVIEW_IMAGE_URL + `?documentId=${imgItem.id}&tenancyid=${$tenancyId}&origin=1`"
                            :preview-src-list="getImageURL(detailModel[item.column_name],-1)" />
                </template>
            </span>
            </el-form-item>
            <el-form-item  v-else-if="item.field_type == FIELD_DISPLAY_TYPE.文件上传&&detailModel[item.column_name]"
                          :key="item.id" :label="`${item.field_name}：`">
              <span class="imgtd">
                <template v-for="file in detailModel[item.column_name]">
                    <div :key="file.url">
                    <div class="target_b" target='_blank' @click="downFile(file)" > {{file.old_name}}</div>
                    </div>
                </template>
            </span>
            </el-form-item>
            <el-form-item 
                v-else-if="item.field_type == FIELD_DISPLAY_TYPE.视频&&detailModel[item.column_name]"
                :key="item.id"
                :label="`${item.field_name}：`"
            >
              <span class="imgtd">
                <template v-for="(video,index) in detailModel[item.column_name]">
                  <div :key="video.url" class="video_item">
                      <el-button type="primary" size="small" @click="videoPlayer(video)">视频文件{{index+1}}</el-button>
                      <div>{{video.oldName}}</div>
                  </div>
                </template>
            </span>
            </el-form-item>
            <el-form-item 
                v-else-if="item.field_type == FIELD_DISPLAY_TYPE.网址类型&&detailModel[item.column_name]"
                :key="item.id"
                :label="`${item.field_name}：`"
            >
              <span>
              <a  class="target_b" :href="`${detailModel[item.column_name]}`" target="blank">{{detailModel[item.column_name]}}</a>
              </span>
            </el-form-item>
            <el-form-item v-else-if="item.field_type == FIELD_DISPLAY_TYPE.富文本"
                          :key="item.id"
                          :label="`${item.field_name}：`">
              <div class="richTextItem" v-html="detailModel[item.column_name]"></div>
            </el-form-item>
            <el-form-item v-else
                          :key="item.id"
                          :label="`${item.field_name}：`">
              <span style="white-space: pre-wrap;" >{{ detailModel[item.column_name] }}</span>
            </el-form-item>
          </el-col>
        </template>
      </el-row>
    </el-form>
    <el-dialog
      v-el-drag-dialog
      width="900px"
      :close-on-click-modal="false"
      :visible.sync="videoSync"
      :append-to-body="true"
    >
      <span slot="title" class="dialog-tile">视频</span>
      <div id="dplayer" style="width:100%;height:400px;"></div>
    </el-dialog>
  </div>
</template>

<script>
import * as webRequest from '@/api/anymark/qiniu'
import { FieldSourceDataList } from '@/api/anymark/marktemplatefield'
import { FIELD_DISPLAY_TYPE, FIELD_DATA_TYPE } from '@/utils'
import elDragDialog from "@/directive/el-drag-dialog";
import DPlayer from 'dplayer';
import {getItemList} from "@/api/dictionary";
export default {
  directives: { elDragDialog },
  props: {
    isUnLimit:{//是否设置最大最小高度
      type:Boolean,
      require:false,
      default:false
    },
    isColWidth:{//是否根据模板设置的占用宽度设置显示宽度  默认为启用  审批页面为关闭 避免页面拥挤
      type:Boolean,
      require:false,
      default:true
    },
    isWGC:{
      type:Boolean,
      require:false,
      default:false
    },
    fieldList: {
      type: Array,
      require: true,
      default() {
        return []
      },
    },
    contentid: {
      type: String,
      require: true,
      default: '',
    },
    templateId: { type: String, require: true, default: '' },
    optionsData: {
      type: Object,
      require: true,
      default() {
        return {}
      },
    },
    contentDetail: {
      type: Object,
      require: true,
      default() {
        return {}
      },
    },
  },
  data() {
    return {
      apiName: 'customtemplatecontent',
      videoSync:false,
      FIELD_DISPLAY_TYPE: FIELD_DISPLAY_TYPE,
      FIELD_DATA_TYPE: FIELD_DATA_TYPE,
      PREVIEW_IMAGE_URL: webRequest.PREVIEW_IMAGE_URL,
      PREVIEW_FILE_URL:webRequest.PREVIEW_FILE_URL,
      detailModel: {},
    }
  },
  created(){
    this.fetchData();
  },
  methods: {
    async downFile(val) {
      await webRequest.DownMedias(val.id).then((response) => {
        var blob = new Blob([response], {
          type: "application/octet-stream",
        });
        // 针对于IE浏览器的处理, 因部分IE浏览器不支持createObjectURL
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob, val.old_name);
        } else {
          var downloadElement = document.createElement("a");
          var href = window.URL.createObjectURL(blob); // 创建下载的链接
          downloadElement.href = href;
          downloadElement.download = val.old_name; // 下载后文件名
          document.body.appendChild(downloadElement);
          downloadElement.click(); // 点击下载
          document.body.removeChild(downloadElement); // 下载完成移除元素
          window.URL.revokeObjectURL(href); // 释放掉blob对象
        }
      });
    },
    dealColWidth(val){
        let widthVal="";
        if(val && this.isColWidth){
            switch (val) {
                case 1:
                widthVal = 6
                break;
                case 2:
                widthVal = 12
                break;
                case 3:
                widthVal = 18
                break;
                default:
                widthVal = 18
                break;
            }
        }else{
            widthVal=24
        }
        return widthVal;
    },
    //播放视频
    videoPlayer(val){
      this.videoSync= true;
      this.$nextTick(()=>{
        const dp = new DPlayer({
        container: document.getElementById('dplayer'),
        video: {
          // url:'http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4'
            url:`${this.PREVIEW_FILE_URL}?documentId=${val.id}&tenancyid=${this.$tenancyId}`,
        },
      });
      })
    },
    fetchData() {
      this.detailModel = {}
      this.fieldList.forEach((item) => {
        let value = ''
        if(item.field_type === FIELD_DISPLAY_TYPE.图片上传||item.field_type === FIELD_DISPLAY_TYPE.文件上传||item.field_type === FIELD_DISPLAY_TYPE.视频){
            value =this.contentDetail[item.column_name]
            this.$set(this.detailModel, item.column_name, value)
        }else if(item.field_type === this.FIELD_DISPLAY_TYPE.富文本){
          if(this.contentDetail[item.column_name]){
            //处理 富文本内容 如果包含图片 使用占位符dms_image_domain 替换掉前部configUrl.apiUrl 内容 以防内外网显示不出来
            value = this.contentDetail[item.column_name].replaceAll('dms_image_domain',`${configUrl.docUrl}/api-document`);
            this.$set(this.detailModel, item.column_name, value);
          }
        }else if(item.field_type === this.FIELD_DISPLAY_TYPE.下拉框 && item.dic_code){
          //获取字典选项
          this.getItemListFn(item,this.contentDetail)
        }else if(item.field_type === this.FIELD_DISPLAY_TYPE.下拉框多选){
          console.log("复选框")
          if(item.dic_code){
            //获取字典选项
            this.getItemListFn(item,data)
          }else{
            //复选框 需要遍历查询对应项
            const datalist = this.contentDetail[item.column_name]?this.contentDetail[item.column_name].split(","):[]
            const listNames = []
            datalist.forEach( val => {
              listNames.push(this.getDictValue(item, val))
            })
            this.$set(this.detailModel, item.column_name, listNames.join(","))
          }
        }
          else{
          value= this.getDictValue(item, this.contentDetail[item.column_name])
          this.$set(this.detailModel, item.column_name, value)
        }
      })
    },
    async getItemListFn(item , datav ) {
      let params = {
        // category_code: item.dic_code
        dic_type_code: item.dic_code,
      };
      const { data } = await getItemList(params);
      if(item.field_type === this.FIELD_DISPLAY_TYPE.下拉框多选){
        //复选框 转换为列表遍历查询对应的字典名
        const list = datav[item.column_name]?datav[item.column_name].split(","):[]
        let listText = []
        data.forEach(val=>{
          list.forEach(v=>{
            if(val.dic_define_code === v){
              listText.push(val.dic_define_value)
            }
          })
        })
        this.$set(this.detailModel, item.column_name, listText.join(","));
      }else{
        data.forEach(val=>{
          if(val.dic_define_code === datav[item.column_name]){
            this.$set(this.detailModel, item.column_name, val.dic_define_value);
          }
        })
      }
      
    },
    // 处理下拉选项的文本
    getDictValue(fieldItem, val) {
      if (!( [this.FIELD_DISPLAY_TYPE.下拉框,this.FIELD_DISPLAY_TYPE.下拉框多选].includes(fieldItem.field_type))) return val;
      else {
        if (!this.optionsData || !this.optionsData[fieldItem.column_name]) {
          // 不是搜索条件的重新查找下拉选项
          if (fieldItem.dictionary_item_list) {
            const tempVal = fieldItem.dictionary_item_list.find(
              (x) =>
                (fieldItem.data_type === FIELD_DATA_TYPE.整数
                  ? parseInt(x.dict_value)
                  : fieldItem.data_type === FIELD_DATA_TYPE.小数
                  ? parseFloat(x.dict_value)
                  : x.dict_value) === val
            )
            return tempVal ? tempVal.dict_key : val
          }
        } else if (
          fieldItem.bind_source &&
          fieldItem.bind_source.table.length > 0
        ) {
          FieldSourceDataList({ field_id_list: [fieldItem.id] }).then((res) => {
            if (res.code === 0) {
              const tempVal = res.data[0].sourceData.find(
                (x) =>
                  (fieldItem.data_type === FIELD_DATA_TYPE.整数
                    ? parseInt(x.value)
                    : fieldItem.data_type === FIELD_DATA_TYPE.小数
                    ? parseFloat(x.value)
                    : x.value) === val
              )

              return tempVal ? tempVal.key : val
            }
          })
        }

        const arr = this.optionsData[fieldItem.column_name].find(
          (x) => x.value == val
        )
        // console.log(fieldItem.field_name, selectedValue)
        return arr ? arr.key : val
      }
    },
    // 处理图片预览地址
    getImageURL(val, index) {
      if (!val) return index > -1 ? '' : []
      const urls = val.map((x) => {
        return webRequest.PREVIEW_IMAGE_URL + `?documentId=${x.id}&tenancyid=${this.$tenancyId}&origin=1`
      })
      return index > -1 ? urls[0] : urls
    },
  },
}
</script>
<style lang="scss" scoped>
.detail-container {
  background: #ffffff;
  // height: 100%;
  // min-height: 500px;
  // max-height: calc(100vh - 300px);
  table {
    width: 100%;
    border-collapse: collapse;
    tr th,
    tr,
    td {
      border: solid 5px #ffffff;
      padding: 5px 10px;
    }

    td.imgtd .el-image {
      margin-right: 10px;
      width: 100px;
      height: 100px;
      border: solid 1px #ccc;
    }
  }
}
.el-form-item__content {
  padding-left: 50px;
}
.el-form-item {
  margin-bottom: 0px;
}
.imgtd .el-image {
  margin: 13px 10px 0 0;
  width: 100px;
  height: 100px;
  // border: solid 1px #ccc;
  border-radius: 5px;
}
.item {
  margin-top: 10px;
  margin-right: 40px;
}

::v-deep .el-form-item__label{
  text-align: right;
  // font-weight: 700 !important;
  color: #909399;
}
.video_item{
 display: inline-block;
 margin-right: 15px;
}
.target_b{
  color: #1c8be4;
  cursor: pointer;
  text-decoration: underline!important;
}
.detailTop{
  .detailTitle{
    font-size: 18px;
    text-align: center;
    margin-bottom: 5px;
  }
  .detailInfo{
    display: flex;
    justify-content: space-between;
    color: #999;
  }
}
.el-form{
  padding: 0 5px;
  // max-height: 65vh;
  // min-height: 50vh;
  // overflow: auto;
}
.unLimit{
  max-height: unset;
  min-height: unset;
  height: calc(100% - 80px);
}
.unLimit_noTitle{
  max-height: unset;
  min-height: unset;
  height: 100%;
}
//修改滚动条样式
.itemBody::-webkit-scrollbar-track-piece {
  background-color: #f8f8f800;
}
.itemBody::-webkit-scrollbar {
  width: 6px;
  transition: all 2s;
}
.itemBody::-webkit-scrollbar-thumb {
  background-color: #dddddd;
  border-radius: 100px;
}
.itemBody::-webkit-scrollbar-thumb:hover {
  background-color: #bbb;
}
.itemBody::-webkit-scrollbar-corner {
  background-color: rgba(255, 255, 255, 0);
}
::v-deep .el-form--label-top .el-form-item__label{
  padding: 0px;
}
</style>
