<template>
  <div class="container">
    <div class="containerHead">
      <div v-if="contentDetail.title" class="detailTop" :style="!isContentPadding?'padding: 0px;':''">
        <div class="detailTitle">{{contentDetail.title}}</div>
        <div class="detailInfo">
          <div>{{contentDetail.create_user_name?contentDetail.create_user_name:contentDetail.user_name}}</div>
          <div>{{contentDetail.create_time}}</div>
          <shareItem :shareData="shareData"></shareItem>
        </div>
        <el-divider></el-divider>
      </div>
      <template v-else>
        <div v-if="description" class="descriptionTitle">
            说明：{{description}}
        </div>
        <div class="contentTitle mt20">
          {{template_name}}
          <el-divider></el-divider>
        </div>
        
      </template>

      <div :style="isContentPadding?'padding: 0px 20px 0px 36px;':''">
        <!--  :is="fieldGroupList.length>1?'el-card':'div'" -->
        <div  v-for="(item,index) in fieldGroupList" :key="item.field_group_name+item.field_group_id">
          <div style="border-bottom: 1px dashed #e8eaec" class="mb10" v-if="item.fieldList.length>0">
            <div v-if="fieldGroupList.length>1" class="f15 strong">{{item.field_group_name}}</div>
            <div v-if="item.fieldList.length>0">
              <anymarkDetailItem
                v-if="!item.is_editable"
                :contentid='contentid'
                :templateId='templateId'
                :contentDetail='contentDetail'
                :optionsData='OptionsData'
                :fieldList='item.fieldList'
              ></anymarkDetailItem>
              <anymarkTempItem 
                v-else
                :ref="`anymarkTempItem${index}`"
                :contentid='contentid'
                :templateId='templateId'
                :contentDetail='contentDetail'
                :OptionsData='OptionsData'
                :allFieldList='item.fieldList'
                :defultDeviceForm='defultDeviceForm'
              ></anymarkTempItem>
            </div>
          </div>
        </div>
      </div>
    </div>
    
  </div>
</template>

<script>
import anymarkTempItem from '@/views/LedgerManage/components/anymarkCompent/anymarkTempItem'
import anymarkDetailItem from '@/views/LedgerManage/components/anymarkCompent/anymarkDetailItem'
import shareItem from '@/views/departManage/item/shareItem'
export default {
  components: { anymarkTempItem,anymarkDetailItem,shareItem },
  props: {
    description: {
      type: String,
      default: '',
    },
    template_name: {
      type: String,
      default: '',
    },
    contentid: {
      type: String,
      default: undefined,
    },
    templateId: {
      type: String,
      //   required: true,
      default: undefined,
    },
    isPublic: {
      type: Number,
      required: false,
      default: 0,
    },
    isPerson: {
      require: false,
      type: Boolean,
      default: false,
    },
    contentDetail: {
      type: Object,
      require: false,
      default() {
        return {}
      },
    },
    OptionsData: {
      type: Object,
      require: false,
      default() {
        return {}
      },
    },
    // allFieldList: {
    //   type: Array,
    //   require: true,
    //   default() {
    //     return []
    //   },
    // },
    fieldGroupList: {
      type: Array,
      require: true,
    },
    defultDeviceForm: {//设备管理 默认设备  填写时间
      require: false,
      type: Object,
      default: ()=>{
        return {}
      },
    },

    isContentPadding:{//内容是否增加padding 主要抽屉需要添加防止被按钮挡住 展示页面不需要添加
      require:false,
      type:Boolean,
      default:true
    },
  },
  watch: {
    contentid: {
      handler(n, o) {
        if (n && n !== o) {
          this.shareData.id = this.contentid
          this.shareData.template_id = this.templateId
        }
      },
      immediate: true,
    },
  },
  data() {
    return {
      shareData:{
        module:this.isWGC?40:20,//微广场为40  其他为20
        id:"",
        template_id:""
      },
    };
  },

  created() {
   
  },
  methods: {
    //flag为1表示 暂存不验证是否必填
    async submitForm(flag){
      let isAllow = true;
      let retrunObj={};
      for (let i = 0; i < this.fieldGroupList.length; i++) {
        const item = this.fieldGroupList[i];
        //这里需要验证是查看模块  还是 输入模块
        //输入编辑模块获取详情
        if(item.fieldList.length>0){
          
          // 查看模块获取详情  需要根据模块的fieldList的column_name取contentDetail对应的值 因为只查看所以传过来是什么 传回去就是什么
          if(!item.is_editable){
            // item.fieldList.forEach(element => {
            //   const {column_name} = element
            //   if (//文件 视频 图片 需要特殊处理
            //     element.field_type === 7 ||
            //     element.field_type === 8 ||
            //     element.field_type === 10
            //   ){
            //     let idList = []
            //     if(this.contentDetail[column_name] && this.contentDetail[column_name].length>0){
            //       idList = this.contentDetail[column_name].map(item => item.id)
            //     }
            //     retrunObj[column_name] = idList.join(',')
            //   }else{
            //     retrunObj[column_name] = this.contentDetail[column_name]
            //   }
            // });
          }else{
            //暂存不验证必填
            const val = await this.$refs[`anymarkTempItem${i}`][0].valid(flag);
            if(!val){
              isAllow = false;
            }else{
              retrunObj = {
                ...retrunObj,
                ...val
              }
            }
          }
        }
      }
      if(!isAllow){
        this.$message.warning('验证未通过,请检查', 'msg')
        return;
      }else{
        return retrunObj
      }
    },
    clearDate(){
      for (let i = 0; i < this.fieldGroupList.length; i++) {
        if(this.$refs[`anymarkTempItem${i}`]){
          this.$refs[`anymarkTempItem${i}`][0].clearDate();
        }
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.container {
  // width:600px;
  // margin: 0 auto;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.editForm {
  flex: 1;
  overflow-x: auto;
  padding: 10px 10px 0px 30px;
  box-sizing: border-box;
}
.saveButton {
  border-top: 1px solid #dcdfe6;
  padding: 10px;
  text-align: right;
}

//在样式把这个is-ready给隐藏掉就好了，就是这么Easy
::v-deep.el-upload-list__item.is-ready {
  display: none;
}
::v-deep .el-list-enter-active,
::v-deep .el-list-leave-active {
  transition: none;
}

::v-deep .el-list-enter,
::v-deep .el-list-leave-active {
  opacity: 0;
}
::v-deep .el-upload-list__item {
  //   text-align: center;
  position: relative;

  .el-upload-list__item-thumbnail {
    width: 100%;
    height: 100%;
    position: absolute;
    -o-object-fit: cover;
    object-fit: cover;
  }
}

.imgbody {
  height: calc(100vh - 500px);
  text-align: center;
}
::v-deep .el-upload-list {
  /* max-width: 800px; */
  // display: inline-block;
}
::v-deep .el-form-item__content {
  line-height: 1;
}
::v-deep .el-form-item__label {
  line-height: 32px;
}
::v-deep .el-form-item__label {
  // min-width: 100px;
  // text-align: center;
  // background: #F6F9FF;
  // border: 1px solid #DCDFE6;
  // border-right: 0;
  height: 32px;
  // padding:0 10px;
}
::v-deep .el-form--inline .el-form-item {
  width: 100%;
  display: flex;
}
::v-deep .el-form-item__content {
  flex: 1;
}
.defaultRowItem ::v-deep .el-form-item__label {
  background: #fff;
  border: 0;
  text-align: right;
  padding-right: 0px;
}
.contentTitle{
    padding: 0 20px;
    font-size: 16px;
    text-align: center;
    margin-bottom: 20px;
    font-weight: bold;
}
.descriptionTitle{
    padding: 10px;
    white-space: pre-line;
    background: #ecf9ff;
    color: #1989fa;
    box-sizing: border-box;

}
::v-deep .el-card__body{
  padding: 10px;
}
.detailTop{
  padding: 20px 20px 0;
  .detailTitle{
    font-size: 18px;
    text-align: center;
    margin-bottom: 5px;
  }
  .detailInfo{
    display: flex;
    justify-content: space-between;
    color: #999;
  }
}
</style>
