<template>
  <div class="detail-container">
    <div  class="detailTop">
      <div class="detailTitle">{{contentDetail.title}}</div>
      <div class="detailInfo">
        <div>{{contentDetail.create_user_name?contentDetail.create_user_name:contentDetail.user_name}}</div>
        <div>{{contentDetail.create_time}}</div>
        <shareItem :shareData="shareData"></shareItem>
      </div>
      <el-divider></el-divider>
    </div>
    <template v-for="item in fieldGroupList" >
      <anymarkDetailItem
        v-if="item.fieldList.length>0"
        :key="item.field_group_name+item.field_group_id"
        :contentid='contentid'
        :templateId='templateId'
        :contentDetail='contentDetail'
        :optionsData='OptionsData'
        :fieldList='item.fieldList'
      ></anymarkDetailItem>
    </template>
  </div>
</template>

<script>
import anymarkDetailItem from '@/views/LedgerManage/components/anymarkCompent/anymarkDetailItem'
import shareItem from '@/views/departManage/item/shareItem'
export default {
  components:{
    shareItem,anymarkDetailItem,
  },
  props: {
    isUnLimit:{//是否设置最大最小高度
      type:Boolean,
      require:false,
      default:false
    },
    isColWidth:{//是否根据模板设置的占用宽度设置显示宽度  默认为启用  审批页面为关闭 避免页面拥挤
      type:Boolean,
      require:false,
      default:true
    },
    isWGC:{
      type:Boolean,
      require:false,
      default:false
    },
    contentid: {
      type: String,
      default: undefined,
    },
    templateId: {
      type: String,
      //   required: true,
      default: undefined,
    },
    // allFieldList: {
    //   type: Array,
    //   require: true,
    //   default() {
    //     return []
    //   },
    // },
    contentDetail: {
      type: Object,
      require: false,
      default() {
        return {}
      },
    },
    OptionsData: {
      type: Object,
      require: false,
      default() {
        return {}
      },
    },
    fieldGroupList: {
      type: Array,
      require: false,
    },
  },
  computed:{
    
  },
  watch: {
    contentid: {
      handler(n, o) {
        if (n && n !== o) {
          this.shareData.id = this.contentid
          this.shareData.template_id = this.templateId
        }
      },
      immediate: true,
    },
  },
  data() {
    return {
      shareData:{
        module:this.isWGC?40:20,//微广场为40  其他为20
        id:"",
        template_id:""
      },
    }
  },

  methods: {},
}
</script>
<style lang="scss" scoped>
.detail-container {
  background: #ffffff;
  // height: 100%;
  // min-height: 500px;
  // max-height: calc(100vh - 300px);
  table {
    width: 100%;
    border-collapse: collapse;
    tr th,
    tr,
    td {
      border: solid 5px #ffffff;
      padding: 5px 10px;
    }

    td.imgtd .el-image {
      margin-right: 10px;
      width: 100px;
      height: 100px;
      border: solid 1px #ccc;
    }
  }
}
.el-form-item__content {
  padding-left: 50px;
}
.el-form-item {
  margin-bottom: 0px;
}
.imgtd .el-image {
  margin: 13px 10px 0 0;
  width: 100px;
  height: 100px;
  // border: solid 1px #ccc;
  border-radius: 5px;
}
.item {
  margin-top: 10px;
  margin-right: 40px;
}

::v-deep .el-form-item__label{
  text-align: right;
  // font-weight: 700 !important;
  color: #909399;
}
.video_item{
 display: inline-block;
 margin-right: 15px;
}
.target_b{
  color: #1c8be4;
  cursor: pointer;
  text-decoration: underline!important;
}
.detailTop{
  .detailTitle{
    font-size: 18px;
    text-align: center;
    margin-bottom: 5px;
  }
  .detailInfo{
    display: flex;
    justify-content: space-between;
    color: #999;
  }
}
.el-form{
  padding: 0 5px;
}
.unLimit{
  max-height: unset;
  min-height: unset;
  height: calc(100% - 80px);
}
.unLimit_noTitle{
  max-height: unset;
  min-height: unset;
  height: 100%;
}
//修改滚动条样式
.itemBody::-webkit-scrollbar-track-piece {
  background-color: #f8f8f800;
}
.itemBody::-webkit-scrollbar {
  width: 6px;
  transition: all 2s;
}
.itemBody::-webkit-scrollbar-thumb {
  background-color: #dddddd;
  border-radius: 100px;
}
.itemBody::-webkit-scrollbar-thumb:hover {
  background-color: #bbb;
}
.itemBody::-webkit-scrollbar-corner {
  background-color: rgba(255, 255, 255, 0);
}
::v-deep .el-form--label-top .el-form-item__label{
  padding: 0px;
}
</style>
