<template>
  <div class="app-container">
    <div>
      <!-- <el-tabs class="typeItemTabs" v-model="activeName" @tab-click="handleClick">
          <el-tab-pane name="1">
            <span slot="label">待审批<el-badge class="tabBadge" v-if="waitApprovedCount>0" :value="waitApprovedCount" ></el-badge></span>
          </el-tab-pane>
          <el-tab-pane name="2">
            <span class="row" slot="label">已审批</span>
          </el-tab-pane>
          <el-tab-pane name="3">
            <span slot="label">已发起<el-badge class="tabBadge" v-if="iStartCount>0" :value="iStartCount" ></el-badge></span>
          </el-tab-pane>
      </el-tabs> -->
      <div>
        <el-form
          ref="filterForm"
          size="small"
          @keyup.enter.native="searchList"
          @submit.native.prevent
          :model="searchForm"
          :inline="true"
          class="filterForm"
          label-position="left"
        >
          <el-form-item prop="form_states">
          <el-radio-group @change="searchList" v-model="searchForm.form_list_type" size="mini">
            <el-radio-button v-for="type in formTypeList" :label="type.key" :key="type.key">{{type.name}} <i v-if="type.count && type.count>0">{{type.count}}</i></el-radio-button>
          </el-radio-group>
        </el-form-item>
          <el-form-item v-if="searchForm.form_list_type !== 3" label="发起人：" prop="publishUser">
            <el-select
              v-model="searchForm.publishUser"
              filterable
              clearable 
              placeholder="请选择"
            >
              <el-option
                v-for="item in groupMemberList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
                <span style="">{{ item.name }}</span>
                <span
                  v-if="item.work_no"
                  style="color: #8492a6; font-size: 13px"
                  >( {{ item.work_no }} )</span
                >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="发布时间：" >
            <dateRangePicker style="width:260px" v-model="searchForm.create_time" ></dateRangePicker>
          </el-form-item>
          <el-form-item>
            <el-button
              size="small"
              class="filter-item"
              type="primary"
              @click="searchList"
              >查询</el-button
            >
            <el-button
              size="small"
              class="filter-item"
              type="default"
              @click="resetForm"
              >重置</el-button
            >
          </el-form-item>
        </el-form>
        <el-table 
          :data="dataList"
          v-loading="listLoading"
          fit
          border
          stripe
          v-adaptive="{ bottomOffset: 52 }"
          height="300"
          @row-click='handleViewerContent'
        >
          <el-table-column type="index" fixed="left" align="center" width="50" label="序号"></el-table-column>
          <el-table-column
            label="操作"
            align="left"
            :width="60"
            fixed="left"
          >
            <template slot-scope="scope">
              <el-button type="text"  @click.native="handleViewerContent(scope.row)" >{{searchForm.form_list_type === 1?'处理':'查看'}}</el-button>
              <!-- <template v-if="searchForm.form_list_type === 2">
                <el-button  type="text"  @click.native="handleViewerContent(scope.row)" >查看</el-button>
                <revokeTodoBtn 
                    class="ml10 mr10" style="display:inline-block;"  :dealStatus='6'
                    v-if="searchForm.form_list_type === 2 && scope.row.permissions[1]=== 1" :flowform='scope.row' 
                    @toEdit='toExamine' @updateList='searchList' ></revokeTodoBtn>
              </template>
              <template v-if="searchForm.form_list_type === 3">
                  <template v-if="scope.row.form_state === 1">
                    <el-button type="text" @click.native="handleViewerContent(scope.row)" >查看</el-button>
                    <el-button type="text" @click.native="addCopy(scope.row)" >复制新增</el-button>
                  </template>
                  <template  v-else>
                    <el-button type="text" @click.native="handleViewerContent(scope.row)" >查看</el-button>
                    <revokeTodoBtn 
                    class="ml10 mr10" style="display:inline-block;"  :dealStatus='5'
                    v-if="scope.row.permissions[0]=== 1" :flowform='scope.row' 
                    @toEdit='editDrafts' @updateList='searchList' ></revokeTodoBtn>
                    <el-button v-if="scope.row.form_state === 0" type="text" @click.native="dealworkflowformFn(scope.row,3)" >作废</el-button>
                  </template>
              </template> -->
            </template>
          </el-table-column>
          <el-table-column width="80"  show-overflow-tooltip label="状态" >
            <template slot-scope="scope">
              <el-tag size="mini" type="" v-if="scope.row.form_state=== -1">草稿</el-tag>
              <template v-if="scope.row.form_state=== 0">
                <el-tag v-if="scope.row.business_is_deleted" size="mini" type="danger" >删除</el-tag>
                <el-tag v-else size="mini" type="success" >归档</el-tag>
              </template>
              <el-tag size="mini" type="danger" v-if="scope.row.form_state=== 1">终止</el-tag>
              <el-tag size="mini" type="warning" v-if="scope.row.form_state=== 2">待处理</el-tag>
              <el-tag size="mini" type="info" v-if="scope.row.form_state=== 3">作废</el-tag>
              <el-tag size="mini" type="" v-if="scope.row.form_state=== 4">发起</el-tag>
            </template>
          </el-table-column>
          <el-table-column  show-overflow-tooltip prop="befor_step" label="上一环节" ></el-table-column>
          <el-table-column  show-overflow-tooltip prop="business_sub_type_name" label="分类" ></el-table-column>
          <el-table-column  show-overflow-tooltip prop="form_title" label="概要" ></el-table-column>
          <el-table-column width="80" show-overflow-tooltip prop="create_user_name" label="发起人" ></el-table-column>
          <el-table-column width="170" show-overflow-tooltip prop="create_time" label="发起时间" ></el-table-column>
        </el-table>
        <Pagination
          :total="pagination.total"
          :page.sync="pagination.page_index"
          :limit.sync="pagination.page_size"
          @pagination="handleCurrentChange"
        ></Pagination>
      </div>
    </div>
    <LedgerAddEditDrawer @closeDrawer='backToList' @backToList="backToList" v-if="isShowAddEditItem" :business_type='10' :anymarkObj='addEditObj'></LedgerAddEditDrawer>
    <LedgerWorkflowDetailDrawer v-if="contentDialogVisible" @toExamine='toExamine' @editDrafts='editDrafts' @addCopy="addCopy" :workflowId="workflowId" @closeItem="closeItem" :contentStatut="contentStatut"  ></LedgerWorkflowDetailDrawer>
  </div>
</template>

<script>
import * as webRequest from "@/api/anymark/qiniu";
import {getAllTenancies} from "@/api/department/user";
import {getWorkflowFormPageList,getWorkflowFormCount,dealworkflowform} from "@/api/workflow";
import Pagination from "@/components/Pagination";
import LedgerWorkflowDetailDrawer from '@/views/LedgerManage/components/LedgerWorkflowDetailDrawer'
// import categoryContent from "@/views/departManage/item/categoryContent";
import LedgerAddEditDrawer from "@/views/LedgerManage/components/LedgerAddEditDrawer"
import revokeTodoBtn from "@/views/LedgerManage/components/revokeTodoBtn"
export default {
  components:{
    Pagination,LedgerAddEditDrawer,
    LedgerWorkflowDetailDrawer,revokeTodoBtn,
  },
   props:{
    categoryObj: {
      require: true,
      type: Object,
    },
  },
  data(){
    return{
      activeName:'1',
      dataList:[],
      searchForm:{
        publishUser:"",
        create_time:[],
        step_approval_time:[],
      },
      groupMemberList: [],
      pagination: {
        page_index: 1,
        page_size: 10,
        total: 0,
      },
      listLoading:false,
      iStartCount:0,//我发起数量
      iStartCountItem:{},//我发起数量模块
      contentDialogVisible:false,
      workflowId:'',

      isPublic: 1,
      isPerson:false,
      isShowAddEditItem: false,
      addEditTemplateId:"",
      addEditContentid:"",
      tipMsgMap:{
        1:"同意", 2:"驳回",3:'作废内容',5:'撤回提交',6:"撤销审核"
      },
      formTypeList:[//1待审核2已审核3我发起的
        { name:"待审核", key:1, count:0 },
        { name:"已审核", key:2, count:'' },
        { name:"我发起的", key:3, count:0 },
      ],
      isCopy:false,
    }
  },
  computed:{
    addEditObj(){
      return{
        contentId:this.addEditContentid,
        templateId:this.addEditTemplateId,
        isCopy:this.isCopy,
        draftId:this.addEditContentid,
      }
    },
    contentStatut(){
      let val = 0
      switch (this.searchForm.form_list_type) {
        case 1:
          val = 2
          break;
        case 2:
          val = 4
          break;
        case 3:
          val = 3
          break;
      
        default:
          break;
      }
      return val
    },
  },
  watch:{
    "categoryObj.id": {
      async handler(n, o) {
        if (n) {
          this.resetForm();
        }
      },
      deep: true,
      immediate:true,
    },
  },
  created(){
    // this.setDate();
    this.getUsersLiteFn(1);
    // this.searchList();
    const {type} = this.$route.query
    if(type){
      this.activeName = String(type);
    }
  },
  methods:{
    toExamine(row){
      this.contentDialogVisible = false
      this.searchForm.form_list_type = 1
      this.$nextTick(async ()=>{
        await this.searchList();
        this.handleViewerContent(row)
      })
    },
    //1-同意,2-驳回，3-作废，5撤回 ,6撤销审核
    async dealworkflowformFn(row,type) {
      this.$confirm(`是否确定${this.tipMsgMap[type]}?`, "提示",{type: 'warning',customClass: 'confirm-dialog--ew',}).then(async () => {
        const params = {
          form_id: row.id, 
          workflow_id: row.workflow_id, 
          business_data_id: row.business_data_id, 
          step_result:type
        };
        const { code, data, msg } = await dealworkflowform(params);
        if (code === 0) {
          this.$message.success("处理成功")
          this.searchList();
        } else {
          this.$message({
            message: msg,
            type: "error",
          });
        }
      })
    },
    async getWorkflowFormCountFn(){
      this.isShowAddEditItem = false
      const params={}
      if(this.categoryObj){
        params.business_sub_type_path = this.categoryObj.path
        params.business_type = 10
      }
      const { code, data, msg } = await getWorkflowFormCount(params);
      if (code === 0) {
        const {wait_approved , i_start_item} = data;
        this.waitApprovedCount = wait_approved;
        this.iStartCount =i_start_item.approval;
        this.iStartCountItem = i_start_item;
        this.formTypeList =[//1待审核2已审核3我发起的
          { name:"待处理", key:1, count:wait_approved },
          { name:"已处理", key:2, count:'' },
          { name:"我发起的", key:3, count:i_start_item.approval },
        ],
        this.$emit('updateCount',wait_approved)
      } else {
        this.$message({
          message: msg,
          type: "error",
        });
      }
    },
    backToList() {
      if (this.isShowAddEditItem) {
        this.addEditTemplateId = "";
        this.addEditContentid = "";
        this.isCopy = false;
        this.searchList();
        this.isShowAddEditItem = false;
      }
    },
    //只有撤回才能新增复制
    addCopy(item){
      this.workflowId = "";
      this.contentDialogVisible = false;
      this.isCopy = true
      if(item.business_type === 10){//随手记
        this.anymarkIndexFn(item.business_data_id);
      }
    },
    editDrafts(item){
      this.workflowId = "";
      this.isCopy = false
      this.contentDialogVisible = false;
      if(item.business_type === 10){//随手记
        this.anymarkIndexFn(item.business_data_id);
      }

      this.pagination.page_index = 1;
      this.searchDataFn()
      this.getWorkflowFormCountFn();
    },
    async anymarkIndexFn(id){
      const { code, data, msg } = await webRequest.anymarkIndex(id);
      if (code === 0) {
        this.addEditTemplateId = data.template_id
        this.addEditContentid = data.content_id
        this.isPublic = data.is_public;
        this.isPerson = data.user_type === 1;
        this.isShowAddEditItem = true;
      } else {
        this.$message({
          message: msg,
          type: "error",
        });
      }
    },
    handleViewerContent(row){
      this.workflowId = row.id;
      this.contentDialogVisible =true;
    },
    closeItem(type){
      if(type){
         this.searchList()
      }
      this.workflowId = "";
      this.contentDialogVisible = false;
    },
    closeContentDialog() {
      this.workflowId = "";
      this.contentDialogVisible = false;
    },
    // handleClick(){
    //   this.isShowAddEditItem = false
    //   if(this.activeName === '3'){
    //     //查询我发起的
    //   }else{
    //     //查询待审批 已审批
    //     this.searchList()
    //   }
    // },
    resetForm(){
      this.searchForm = {
        form_list_type:1,
        publishUser:"",
        create_time:[],
      }
      this.searchList();
    },
    async searchDataFn(){
      const params={
        business_type:10,//只查随手记草稿
        form_list_type: this.searchForm.form_list_type,// 1待审核2已审核3我发起的
        page_index:this.pagination.page_index,
        page_size:this.pagination.page_size,
      }
      if(this.categoryObj){
        params.business_sub_type_path = this.categoryObj.path
      }
      if(this.searchForm.publishUser && this.searchForm.form_list_type !== 3){
        params.create_user_id = this.searchForm.publishUser
      }
      if(this.searchForm.create_time.length>0){
        params.create_time_start = this.searchForm.create_time[0]
        params.create_time_end = this.searchForm.create_time[1]
      }
      this.listLoading = true;
      const {data, code, msg, page} = await getWorkflowFormPageList(params);
      this.listLoading = false;
      if (code === 0) {
        this.dataList = data;
        this.pagination.total = page.total_count;
      } else {
        this.$message({
          message: msg,
          type: "error",
        });
      }
    },
    searchList(){
      this.isShowAddEditItem = false
      this.pagination.page_index = 1;
      this.searchDataFn()
      this.getWorkflowFormCountFn();
    },
    handleCurrentChange(val) {
      if (val) {
        this.pagination.page_index = val.page;
        this.pagination.page_size = val.limit;
      }
      this.searchDataFn();
    },
    async getUsersLiteFn(page) {
      const params = {
        offset: page,
        limit: 100,
        state: 1,
      };
      //科室管理与 pacs项目查询用户传参不同
      if(this.$currentSystemClass === 'DMS_RIS'){
        params.business_system_id = sessionStorage.getItem("lastname")
        params.business_system_type = "dms"
      }else{
        params.system_id = sessionStorage.getItem("lastname")
      }
      const { data } = await getAllTenancies(params);
      if (data.length > 0) {
        data.forEach((element) => {
          this.groupMemberList.push(element);
        });
        if (data.length === 100) {
          this.getUsersLiteFn(page + 1);
        }
      }
    },
    setDate() {
      let dayTime = new Date(); //获取当前标准时间
      var datetime =
        dayTime.getFullYear() +
        "-" +
        (dayTime.getMonth() + 1) +
        "-" +
        dayTime.getDate(); //转换为yy-mm-dd格式

      let lw = new Date(dayTime - 1000 * 60 * 60 * 24 * 30);
      let lastY = lw.getFullYear();
      let lastM = lw.getMonth() + 1;
      let lastD = lw.getDate();
      let startThirtydate =
        lastY +
        "-" +
        (lastM < 10 ? "0" + lastM : lastM) +
        "-" +
        (lastD < 10 ? "0" + lastD : lastD); //三十天之前日期
      this.searchForm.create_time = [startThirtydate, datetime];
    },
  }
}
</script>

<style lang="less" scoped>
.pagination-container {
  text-align: right;
  background: #fff;
}
.pagination-container.hidden {
  display: none;
}

::v-deep .el-tabs__nav-scroll{
  margin-top: -10px;
}
::v-deep .el-tabs__nav-wrap{
  overflow: unset;
}
.tabBadge{
  margin-top: -10px;
  position: absolute;
  top: 15px;
  margin-top: -10px;
}
.tabBadge2{
  // position: absolute;
  // top: -3px;
  // right: -6px;
}
.filterForm{
  padding-top: 0px !important;
}
</style>