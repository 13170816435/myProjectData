<template>
  <el-dialog
    :title="addType?'新增文件夹':'新增档案'"
    :visible.sync="dialogVisible"
    width="500px"
    :before-close="close"
    append-to-body
    v-el-drag-dialog
    :close-on-click-modal="false"
    >
    <el-form
      ref="filterForm"
      size="small"
      :model="formData"
       :rules="formRules"
      class="filterForm"
      label-width="auto"
    >
      <el-form-item label="所在目录：" prop="filePath">
        <el-cascader
          style="width:100%"
          v-model="formData.filePath"
          :options="parentOptions"
          :props="{ label:'name' ,value:'id',checkStrictly: true}"
        ></el-cascader>
      </el-form-item>
      <el-form-item :label="addType?'文件夹名称：':'档案名称：'" prop="name">
        <el-input
          v-model="formData.name"
          clearable
          :placeholder="`请输入${addType?'文件夹名称':'档案名称'}`"
        />
      </el-form-item>
    </el-form>
    <div class="row space_between mt10">
      <div></div>
      <div>
        <el-button size="small" class="submitButtons" @click="close">关闭</el-button>
        <el-button size="small" class="submitButtons" type="primary" :loading="btnLoading"  @click="submit(1)"   >确定并继续新增</el-button>
        <el-button size="small" class="submitButtons" type="primary" :loading="btnLoading"  @click="submit"   >确定</el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script>
import { saveCategoryAdd ,getLedgerCategoryTree } from '@/api/anymark/markcategory'
export default {
  props:{
    addType:{//是否新增 1文件夹 还是0档案
      type:Number,
      require:false,
      default:1
    },
    parentId:{
      type:String,
      require:false,
      default:''
    },
    addDefaultPath:{//默认选中的目录
      type:Array,
      require:false,
      default:()=>[]
    },
  },
  created(){
    if(this.addDefaultPath.length>0){
      this.formData.filePath = this.addDefaultPath
    }
    this.fetchList()
  },
  computed:{
    isAllowManage(){
      //是否允许管理分类文件夹 新增 移动 重命名 启用停用等
      return this.$prm_codes.includes('ssj_ml_gl')
    },
    flatTreeList(){//拍平的树列表
      return this.flatData(this.parentOptions);
    },
  },
  data(){
    return{
      dialogVisible:true,
      btnLoading:false,
      parentOptions:[],
      formData:{
        filePath:[],
        name:'',
      },
      formRules: {
        name: [{ required: true, message: "请输入名称", trigger: "blur" }],
        filePath: [{ required: true, message: "请选择所在目录", trigger: "blur" }],
      },
    }
  },
  methods:{
    flatData(data){
      return data.reduce((prev, curr) => {
        prev.push(curr);
        if (curr.children && curr.children.length > 0) {
          prev.push(...this.flatData(curr.children));
        }
        return prev;
      }, []);
    },
    async submit(type){
      if(this.formData.filePath.length === 0){
        this.$message.warning(`所在目录不能为空`)
        return
      }
      if(!this.formData.name){
        this.$message.warning(`${this.addType?'文件夹名称':'档案名称'}不能为空`)
        return
      }
      //提交接口
      const params={
       name:this.formData.name,
       is_folder:this.addType
      }
      const pId = this.formData.filePath[this.formData.filePath.length-1]
      const pNode = this.flatTreeList.find(item=>{return item.id === pId})
      // 0_0  0_1 是科室分类与个人分类的id 是我添加的 所以如果选的是这两个id就不用传了
      if(!['0_0','0_1'].includes(pNode.id)){
        params.parent_id = pNode.id
      }else{
        params.parent_id = 0
      }
      params.user_type = pNode.user_type
      this.btnLoading = true
      const { code,data,msg } = await saveCategoryAdd(params)
      this.btnLoading = false
      if (code === 0) {
        this.$message.success('新增成功')
        if(type === 1){
          this.formData.name = ''
        }
        this.$emit('addUpdate',data,type)
      }else{
        this.$message.error(msg);
      }
    },
    // 获取分类列表
    async fetchList() {
      const params={
        user_type:null,
        only_folder:1,//是否只查询文件夹 0否1是
      }
      //如果没有管理权限 那只能新增个人分类
      if(!this.isAllowManage){
        params.user_type = 1
      }
      if(this.parentId){//只显示设备管理相关文件夹 固定为科室管理下级
        params.user_type = 0
      }
      this.btnLoading = true
      const { code,data,msg } = await getLedgerCategoryTree(params)
      this.btnLoading = false
      if (code === 0) {
        if(data && data.length>0){
          data.forEach((item,index)=>{
            item.id = `0_${item.user_type}`
            item.is_folder = 1
          })
          //去除其他文件夹 目前使用场景为设备管理  只显示设备管理相关文件夹 固定为科室管理下级
          if(this.parentId && data[0].children){
            data[0].disabled = true
            data[0].children = data[0].children.filter(item=> item.id === this.parentId)
          }

          this.parentOptions = this.setEmptyChildrenToUndefined(data)
        }else{
          this.parentOptions = []
        }
      }else{
        this.$message.error(msg);
      }
    },
    setEmptyChildrenToUndefined(treeData) {
      const processedData = [...treeData]; // 复制一份以保留原数据
      for (const node of processedData) {
        if (node.children && node.children.length === 0) {
          node.children = undefined; // 将 children 为空数组的节点的 children 设置为 undefined
        } else if (node.children && node.children.length > 0) {
          node.children = this.setEmptyChildrenToUndefined(node.children); // 递归处理子节点并赋值给当前节点的 children
        }
      }
      return processedData; // 返回处理后的数据
    },
    close(){
      this.$emit('closeDialog')
    },
  },
}
</script>

<style>

</style>