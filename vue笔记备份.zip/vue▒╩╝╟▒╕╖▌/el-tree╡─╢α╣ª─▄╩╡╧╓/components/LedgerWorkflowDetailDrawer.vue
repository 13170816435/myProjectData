<template>
  <el-drawer
    class="widthhandle"
    ref="exeDrawer"
    :with-header="false"
    size="100%"
    :visible.sync="dialogVisible"
    :modal="false"
    append-to-body
    :modal-append-to-body='false'
  >
    <div class="drawerContent">
      <!-- <div class="contentMain">
        <div>
          <template v-if="business_type === 10">
            <categoryDetail
              ref="categoryDetail"
              :isWGC ="isWGC"
              :fieldList="fieldList"
              :optionsData="optionsData"
              :selectId="contentId"
              :selectDetailItem="workflowFormDetail"
              :templateId="templateId"
            />
          </template>
        </div>
        <div v-if="workflowFormDetail.logs && workflowFormDetail.logs.length>0" class="contentRight">
          <div class="timelinePartTitle">流转记录</div>
          <examineTimelineItem :logs="workflowFormDetail.logs" :userInfo="userInfo" class="timelineMain contentMain"></examineTimelineItem>
        </div>
      </div>
      <div class="contentFoot">
        <examineDealItem ref="examineDealItem" @editDrafts='editDrafts' @toExamine='toExamine' @addCopy="addCopy" @updateData="updateData" :contentStatut="contentStatut" @closeItem="closeItem" :workflowFormDetail='workflowFormDetail'></examineDealItem>
      </div> -->
      <LedgerContentItem  v-if="business_type === 10"
          :contentid="contentId"
          :templateId="templateId"
          :viewMode='1'
          :origin='1'
          @closeItem="closeItem"
          @backToList="closeItem(1)"
        ></LedgerContentItem>
        <!--@editDrafts='editDrafts'  @toExamine='toExamine' @addCopy="addCopy" @updateData="updateData" -->
    </div>
    <div class="closeButton" @click="closeItem()">
      <span style="font-size: 12px" class="icon iconfont icon-caidan"></span>
      收起
    </div>
  </el-drawer>
</template>

<script>
import categoryDetail from '@/views/LedgerManage/components/categoryDetail.vue'
import examineTimelineItem from '@/views/examine/examineTimelineItem'
import examineDealItem from '@/views/examine/examineDealItem'
import {getWorkflowFormDetail} from "@/api/workflow";
import * as webRequest from '@/api/anymark/qiniu'
import { getItemList } from "@/api/dictionary";
import Mgr from "@/utils/SecurityService";
import LedgerContentItem from "@/views/LedgerManage/components/anymarkCompent/LedgerContentItem";
import {
  parseTime,
  getMonthTime,
  pickerOptions,
  FIELD_DATA_TYPE,
  FIELD_DISPLAY_TYPE,
} from "@/utils";
export default {
  components:{
    categoryDetail,examineTimelineItem,examineDealItem,LedgerContentItem
  },
  props: {
    workflowId: { type: String, require: false, default: '' },
    //1 科室专区进入查看详情（没有底部处理按钮） 
    //2待办事项（待审批模块进入 审批视角）
    //4待办事项（已审批模块进入 审批视角）
    //3待办事项（已发起模块进入 申请人视角）
    contentStatut: { type: Number, require: false, default: 1 },
  },
  watch:{
    workflowId: {
      async handler(n, o) {
        if (n && n !== o) {
          //根据流程id 查询流程详情
          await this.getWorkflowFormDetailFn(n);
          // this.$refs.examineDealItem.init();
        }
      },
      immediate: true,
    },
  },
  created(){
    this.$nextTick(async()=>{
       var manager = new Mgr();
       const user = await manager.getRole(); // 获取登录信息
       this.userInfo={
         institution_id:user.profile.inst_id,
         office_id:user.profile.office_id
       }
    })
  },
  mounted() {
    // box-shadow: -10px 10px 10px #909399;
    setTimeout(() => {
      $(".widthhandle").css("box-shadow", "#0000001a -4px 0px 20px 0px");
    }, 300);
  },
  data() {
    return {
      workflowFormDetail:{
        logs:[],
        form_state:null,//申请单状态（-1：草稿箱；0：通过；1：驳回；2：待审核；3：作废；4：发起）
      },
      isWorkFlow:true,//是否有审批流程 通过getWorkflowFormDetail接口返回data判断 如果返回null 则为没有审批流程 按原来样式展示
      business_type:10,
      //随手记详情显示所需数据
      isWGC:false,
      fieldList:[],
      optionsData:{},
      contentId:'',
      templateId:'',
      userInfo:{
        institution_id:'',
        office_id:''
      },
      dialogVisible: true,
    }
  },
  methods:{
    // async updateData(){
    //   await this.getWorkflowFormDetailFn(this.workflowId)
    //   this.$refs.examineDealItem.init();
    // },
    // toExamine(item){
    //   this.$emit("toExamine",item)
    // },
    // editDrafts(item){
    //   this.$emit("editDrafts",item)
    // },
    // addCopy(item){
    //   this.$emit("addCopy",item)
    // },
    closeItem(type){
      this.$emit("closeItem",type)
    },
    // 获取申请单详细信息
    async getWorkflowFormDetailFn(id){
      const { code, data, msg } = await getWorkflowFormDetail(id);
      if (code === 0) {
        if(data){
          data.title = data.form_title
          this.workflowFormDetail = data;
          this.isWorkFlow = true;
          this.business_type = data.business_type
          if(this.business_type === 10){//随手记
            this.anymarkIndexFn(data.business_data_id)//获取随手记详情
            this.isWGC = data.business_sub_type_name === '微广场'//判断是否为微广场
          }
        }else{
          this.workflowFormDetail = {};
          this.isWorkFlow = false;
        }
      } else {
        this.$message({
          message: msg,
          type: "error",
        });
      }
    },
    async anymarkIndexFn(id){
      const { code, data, msg } = await webRequest.anymarkIndex(id);
      if (code === 0) {
        // await this.fetchDetailTemplateData(data.template_id);
        this.templateId = data.template_id
        this.contentId = data.content_id
      } else {
        this.$message({
          message: msg,
          type: "error",
        });
      }
    },
    // async fetchDetailTemplateData(id) {
    //   const response = await webRequest.GetDetailById( "customtemplate", id );
    //   const { code, data } = response;
    //   if (code === 0) {
    //     this.fieldList = data.field_list.filter(
    //       (x) => x.is_related_business !== 1
    //     );
    //     this.optionsData = {};
    //     this.getOptionsData(
    //       this.fieldList.filter(
    //         (x) => x.field_type === FIELD_DISPLAY_TYPE.下拉框
    //       )
    //     );
    //   }
    // },
    // // 下拉列表数据
    // getOptionsData(selectFieldList) {
    //   if (selectFieldList) {
    //     selectFieldList.forEach((item, index, array) => {
    //       //    取数据源
    //       if (item.bind_source && item.bind_source.table.length > 0) {
    //         FieldSourceDataList({ field_id_list: [item.id] }).then((res) => {
    //           if (res.code === 0) {
    //             const arr = res.data[0].sourceData.map((x) => {
    //               return {
    //                 key: x.key,
    //                 value:
    //                   item.data_type === FIELD_DATA_TYPE.整数
    //                     ? parseInt(x.value)
    //                     : item.data_type === FIELD_DATA_TYPE.小数
    //                     ? parseFloat(x.value)
    //                     : x.value,
    //               };
    //             });

    //             this.$set(this.optionsData, item.column_name, arr);
    //           }
    //         });
    //       } else if (item.dic_code) {
    //         //获取字典选项
    //         this.getItemListFn(item);
    //       } else {
    //         if (
    //           item.dictionary_item_list &&
    //           item.dictionary_item_list.length > 0
    //         ) {
    //           const arr = item.dictionary_item_list.map((x) => {
    //             return {
    //               key: x.dict_key,
    //               value:
    //                 item.data_type === FIELD_DATA_TYPE.整数
    //                   ? parseInt(x.dict_value)
    //                   : item.data_type === FIELD_DATA_TYPE.小数
    //                   ? parseFloat(x.dict_value)
    //                   : x.dict_value,
    //             };
    //           });
    //           this.$set(this.optionsData, item.column_name, arr);
    //         }
    //       }
    //     });
    //   }
    // },
    // async getItemListFn(item) {
    //   let params = {
    //     // category_code: item.dic_code,
    //     dic_type_code: item.dic_code,
    //   };
    //   const { data } = await getItemList(params);
    //   data.forEach((item) => {
    //     item.key = item.dic_define_value;
    //     item.value = item.dic_define_code;
    //   });
    //   this.$set(this.optionsData, item.column_name, data);
    // },
  },
}
</script>

<style lang="less" scoped>
.drawerContent{
  // padding: 30px 30px 0px 36px;
  box-sizing: border-box;
  color: #303133;
  overflow: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%;
  font-size: 14px;
}
.contentMain{
  display: flex;
  flex-direction: column;
  flex: 1;
  overflow: auto;
  box-sizing: border-box;
  .contentLeft{
    
  }
  .contentRight{
    .timelineMain{  
      padding-right: 10px;
    }
    .timelinePartTitle{
        font-size: 16px;
        color: #28354C;
        margin-bottom: 15px;
        font-weight: bold;
    }
  }
}
.contentFoot{
  /deep/.footButtons{
    width: 100%;
    margin-left: 0;
    margin-bottom: 0;
    padding: 10px 0px;
    box-sizing: border-box;
  }
}
//修改滚动条样式
.contentMain::-webkit-scrollbar-track-piece {
  background-color: #f8f8f800;
}
.contentMain::-webkit-scrollbar {
  width: 6px;
  transition: all 2s;
}
.contentMain::-webkit-scrollbar-thumb {
  background-color: #dddddd;
  border-radius: 100px;
}
.contentMain::-webkit-scrollbar-thumb:hover {
  background-color: #bbb;
}
.contentMain::-webkit-scrollbar-corner {
  background-color: rgba(255, 255, 255, 0);
}
.widthhandle {
  width: 50%;
  z-index: 2000;
}
.closeButton {
  position: absolute;
  top: 43%;
  width: 30px;
  padding: 50px 5px;
  font-size: 14px;
  // border: 1px solid #fff;
  background: #0a70b01a;
  color: #0A70B0;
  font-weight: bold;
  border-radius: 0 20px 20px 0px;
  cursor: pointer;
  &:hover {
    background: #d9e6ef;
  }
}
</style>