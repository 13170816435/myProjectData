<template>
  <el-dialog
    title="重命名"
    :visible.sync="dialogVisible"
    width="400px"
    :before-close="close"
    append-to-body
    v-el-drag-dialog
    :close-on-click-modal="false"
    >
    <el-form
      ref="filterForm"
      size="small"
      :model="formData"
      class="filterForm"
      label-width="auto"
    >
      <el-form-item label="名称：" prop="fileName">
        <el-input v-model="formData.fileName" placeholder="请输入名称"></el-input>
      </el-form-item>
    </el-form>
    <div class="row space_between mt10">
      <div></div>
      <div>
        <el-button size="small" class="submitButtons" @click="close">关闭</el-button>
        <el-button size="small" class="submitButtons" type="primary" :loading="btnLoading"  @click="submit"   >确定</el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script>
import { saveCategoryUpdate } from '@/api/anymark/markcategory'
export default {
  props:{
    dealItem:{
      type:Object,
      require:true
    },
  },
  watch:{
    'dealItem.name':{
      handler(val){
        this.formData.fileName = val
      },
      deep:true,
      immediate:true
    }
  },
  data(){
    return{
      dialogVisible:true,
      btnLoading:false,
      formData:{
        fileName:'',
      },
    }
  },
  methods:{
    async submit(){
      //提交接口
      if(!this.formData.fileName){
        this.$message.warning('请输入名称');
        return
      }
      if(this.formData.fileName === this.dealItem.name){
        this.$message.warning('当前名称没有变化，不用提交');
        return
      }
      //重命名接口
      const params={
        id:this.dealItem.id,
        parent_id:this.dealItem.parent_id,
        name:this.formData.fileName,
        description:this.dealItem.description,
      }
      const { code,data,msg } = await saveCategoryUpdate(params)
      if (code === 0) {
        this.$message.success('修改成功');
        this.$emit('submit')
      }else{
        this.$message.error(msg);
      }
    },
    close(){
      this.$emit('closeDialog')
    },
  },
}
</script>

<style lang="less" scoped>

</style>