<template>
  <div ref="container" class="custom-input-container">
    <el-input
      v-model="inputValue"
      @focus="isFocused = true"
      @dragenter.native.capture.stop="dragenter"
      placeholder="拖动字段到该区域，可动态组合标题"
      ref="inputRef"
    />
    <el-popover
      placement="bottom-start"
      trigger="manual"
      v-model="isFocused"
      class="custom-popover"
      :width='inputWidth'
    >
      <div class="tags-list">
        <div class="tagsContent" >
          <div
            v-for="field in templeList" :key="field.column_name"
            :draggable="true"
            @dragstart="onTagDragStart(field, $event)"
            @dragend="onDrop"
          >
            <el-tag type="info" size="small" class="tag">{{ field.field_name }}</el-tag>
          </div>
        </div>
      </div>
      <div slot="reference"></div>
    </el-popover>
  </div>
</template>

<script>
export default {
  props: {
    templeList: Array,
    value: String,
  },
  data() {
    return {
      isFocused: false,
      dragItemName:'',
      isInArea:false,//是否停留在标题框中
      inputWidth: 0,
    };
  },
  computed: {
    inputValue: {
      get() {
        return this.value;
      },
      set(newValue) {
        this.$emit('input', newValue);
      },
    },
  },
  watch: {
    isFocused(newVal) {
      if (newVal) {
        this.updateInputWidth();
      }
    },
  },
  created(){
    window.addEventListener('click',this.handleClickOutside)
  },
  beforeDestroy(){
    window.removeEventListener('click',this.handleClickOutside)
  },
  methods: {
    updateInputWidth() {
      if (this.$refs.inputRef) {
        this.inputWidth = this.$refs.inputRef.$el.clientWidth;
      }
    },
    handleClickOutside(event) {
      const container = this.$refs.container;
      if (!container.contains(event.target)) {
        this.isFocused = false;
      }
    },
    onTagDragStart(field, event) {
      this.isFocused = true
      this.dragItemName = `『${field.column_name}』`
    },
    dragenter(){
      this.isInArea = true;
    },
    onDrop(event) {
      console.log('onDrop',this.dragItemName)
      if (this.isInArea) {
        event.preventDefault();
        this.inputValue =this.inputValue +this.dragItemName
        this.dragItemName = ''
        this.isInArea = false
      }
    },
  },
};
</script>

<style lang="less" scoped>

.custom-input-container {
  /* display: flex;
  align-items: flex-start; */
}
.custom-popover {
  min-width: auto;
  max-width: auto;
  min-width: 120px;
}

.tags-list {
  background-color: #fff;
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
  min-width: 500px;
  min-height: 200px;
  overflow: auto;
  .tagsContent{
    display: flex;
    flex-wrap: wrap;
  }
}

.tag {
  margin: 5px;
  cursor:move;
}

.input-content {
  min-height: 30px;
  padding: 5px;
}
</style>
