<template>
  <div v-loading="saveBtnStatue" class="settingContent">
    <el-form
      class="settingForm"
      ref="dataForm"
      :rules="formRules"
      :model="formData"
      label-position="right"
      size="small"
      label-width="auto"
    >
      <el-row>
        <el-col :span="8">
          <el-form-item label="档案名称：" prop="category_name">
            <el-input
              v-model="formData.category_name"
              clearable
              :placeholder="`请输入档案名称`"
            />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="所在目录：" prop="filePath">
            <el-cascader
              style="width:100%"
              v-model="formData.filePath"
              :options="parentOptions"
              clearable 
              :disabled='!(isAllowManage || isActiveAdminUser || isPerson)'
              :props="{ label:'name' ,value:'id',checkStrictly: true}"
            ></el-cascader>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="档案启用：" prop="is_enabled">
            <el-switch 
            v-model="formData.is_enabled"
            :active-value="1" size='mini'
            :inactive-value="0"
            />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item v-if="!isPerson" label="负责人：" prop="adminUserIdList" >
            <el-select v-model="formData.adminUserIdList"  style="width:100%"
            filterable multiple  placeholder="请选择"  value-key="id"
            >
              <el-option
                v-for="item in groupMemberList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
                <span style="">{{ item.name }}</span>
                <span v-if="item.work_no" style="color: #8492a6; font-size: 13px">( {{item.work_no}} )</span>
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item v-if="!isPerson && !isDeviceManage" label="审批流程：" prop="workflow_id">
            <el-select style="width:100%" filterable @change="changeWorkflow" v-model="formData.workflow_id" placeholder="请选择" >
              <el-option
                v-for="item in workflowList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
                :disabled="item.is_disabled === 1"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="16">
          <el-form-item v-if="!isPerson" label="消息提醒：" >
            <!-- <el-switch @change="changeRemind" v-model="formData.isRemind" :active-value="1" :inactive-value="0" ></el-switch> -->
            <div :class="remindInfo.length>0?'':'mt5'" >
              <messageReminder
                :defaultList="remindInfo"
                :isAll='true'
                applyType="AnymarkNotifyCustomUser"
                notifyCategory="Anymark" ></messageReminder>
            </div>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row v-if="isDeviceManage">
        <el-col :span="8">
          <el-form-item v-if="!isPerson" label="填报设备："  >
            <el-select v-model="formData.equipment_manage_setting.equipment_id_list"  
            style="width:100%" filterable multiple  placeholder="请选择"  value-key="id"
            >
              <el-option
                v-for="item in deviceList"
                :key="item.equipment_id"
                :value="item.equipment_id"
                :label="item.equipment_name"
                :disabled='!!item.anymark_category_id && item.anymark_category_id !== categoryObj.id'
              >
                <span >{{ item.equipment_name }}</span>
                <span v-if="item.anymark_category_name" style="color: #8492a6; font-size: 13px">( {{item.anymark_category_name}} )</span>
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item v-if="!isPerson" label="填报频次：" >
            <el-select  v-model="formData.equipment_manage_setting.report_frequency_list" 
            style="width:100%" filterable multiple :multiple-limit="1" placeholder="请选择" >
              <el-option
                v-for="item in frequencyList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      
      <el-form-item label="备注：" prop="description">
        <el-input
          v-model="formData.description"
          placeholder="请输入描述"
          type="textarea"
          :maxlength="1024"
          rows="1"
          show-word-limit
        />
      </el-form-item>
      <div class="settingTitle">
        <i class="titleTip"></i>
        <div class="f15 strong">模板设置</div>
      </div>
      <el-form-item label="标题显示：" prop="template_title">
        <templateNameSelectItem style="width:100%" :templeList='allMoveTemplateList' v-model="formData.template_title"></templateNameSelectItem>
        <div style="color:#EF8900" class="f12 ">您可以在设置完下方模板字段后，选用一个或多个模板字段， 动态拼接在标题中使用</div>
      </el-form-item>
      <div >
        <div :class="workflowStepsTemplateGroup.length === 1?'':'timeline-item'" v-for="(item,index) in workflowStepsTemplateGroup" :key="item.field_group_name+item.field_group_id">
          <div class="timeline-item-tail"></div>
          <div class="timeline-item__node"></div>
          <div class="timeline-item__wrapper">
            <template v-if="workflowStepsTemplateGroup.length === 1">
              <div class="settingTitle">
                <div class="f14 strong">模板字段：</div>
                <el-button  style="margin-left: auto;" type="warning" icon="el-icon-plus" size="mini" @click="handleAddField(item)" >字段</el-button>
              </div>
            </template>
            <div v-else class="fieldGroupTitle">
              <span class="clr_303">审批流节点</span> <span class="clr_909">( {{item.field_group_name}}填写 )</span>
              <el-button  class="fr" type="text" icon="el-icon-plus" size="mini" @click="handleAddField(item)" >新增</el-button>
            </div>
            <el-table
              :ref="'dragTable'+index"
              row-key="field_name"
              stripe
              :header-cell-style="{ 'text-align': 'center' }"
              :data="item.fieldList"
              border
              fit
              highlight-current-row
            >
              <el-table-column align="center" type="index" label="序号" width="50"></el-table-column>
              <el-table-column align="center" label="操作" width="100">
                <template slot-scope="scope">
                  <el-button :disabled='scope.row.is_system === 2' type="text" @click="editContent(scope.row,scope.$index)" >编辑</el-button>
                  <el-button :disabled='scope.row.is_system === 2' type="text" @click="deleteContent(scope.row,scope.$index)" class="clr_red">删除</el-button>
                </template>
              </el-table-column>
              <el-table-column label="显示列名" prop="field_name" align="left">
                <template slot-scope="scope">
                  <span>{{ scope.row.field_name }}</span>
                </template>
              </el-table-column>
              <el-table-column label="列名" prop="column_name" align="left">
                <template slot-scope="scope">
                  <span>{{ scope.row.column_name }}</span>
                </template>
              </el-table-column>
              <el-table-column label="数据类型" prop="data_type" align="left">
                <template slot-scope="scope">
                  <span>{{ getDataTypeName(scope.row.data_type) }}</span>
                </template>
              </el-table-column>
              <el-table-column label="输入方式" prop="field_type" align="left">
                <template slot-scope="scope">
                  <span>{{ getFieldTypeName(scope.row.field_type) }}</span>
                </template>
              </el-table-column>
              <el-table-column label="是否显示" align="center" width="80">
                <template slot-scope="scope">
                  <span>{{
                    (!scope.row.field_property || scope.row.field_property.is_display_detail) ? "是" : "否"
                  }}</span>
                </template>
              </el-table-column>
              <el-table-column label="是否必填" prop="is_must" align="center" width="80">
                <template slot-scope="scope">
                  <span>{{
                    scope.row.is_must === 1 ? "是" : "否"
                  }}</span>
                </template>
              </el-table-column>
              <el-table-column label="绑定业务数据" prop="is_related_business" align="center" width="120">
                <template slot-scope="scope">
                  <span>{{
                    scope.row.is_related_business === 1 ? "是" : "否"
                  }}</span>
                </template>
              </el-table-column>
              <el-table-column label="系统业务字段" prop="is_system" align="center" width="120">
                <template slot-scope="scope">
                  <span>{{ scope.row.is_system === 2 ? "是" : "否" }}</span>
                </template>
              </el-table-column>
            </el-table>

          </div>
        </div>
        
      </div>
    </el-form>
    <div class="footBtn" >
      <el-button size="small" @click="resetChange" >取消</el-button>
      <el-button type="primary" :loading='btnLoading' :disabled="saveBtnStatue"
        size="small" @click="handleSaveTemplate('formData')"
      >保存</el-button>
    </div>
    <el-dialog
      class="pub_dialog"
      v-el-drag-dialog
      :close-on-click-modal="false"
      :visible.sync="fieldDialogVisible"
      top="20px"
      width="800px"
    >
      <span slot="title" class="dialog-tile">
        {{ textMap[dialogStatus] }}
      </span>
      <LedgerTemplateFieldItem
        ref="templateFieldForm"
        :select-show-type.sync="selectShowType"
        :is-new-field="isNewField"
        :field-form="fieldForm"
        :datatypelist="dataTypeList"
        :widthList="widthList"
        :fieldtypelist="fieldTypeList"
        :fieldGroupList="field_group_list"
        @handleSaveField="handleSaveField"
      />
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="cancelSubmitField">取消</el-button>
        <el-button type="primary" size="mini" @click="handleSubmitField(1)"
          >保存并继续新增</el-button
        >
        <el-button type="primary" size="mini" @click="handleSubmitField"
          >保存</el-button
        >
        <div></div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import * as webRequest from "@/api/anymark/qiniu";
import { getLedgerCategoryTree,getCategoryTemplateSettings,saveCategoryTemplateSettings,getAnymarkEquipment } from '@/api/anymark/markcategory'
import { getAllTenancies } from "@/api/department/user";
import { getWorkflowList } from "@/api/workflow"
import templateNameSelectItem from '@/views/LedgerManage/components/templateNameSelectItem.vue'
import LedgerTemplateFieldItem from '@/views/LedgerManage/components/LedgerTemplateFieldItem.vue'
import { FIELD_DATA_TYPE, FIELD_DISPLAY_TYPE,WIDTH_LIST } from "@/utils";
import Sortable from "sortablejs";
export default {
  components:{
    templateNameSelectItem,LedgerTemplateFieldItem
  },
  props: {
    parentId:{
      type:String,
      require:false,
      default:''
    },
    categoryObj: {
      require: true,
      type: Object,
    },
    isActiveAdminUser:{
      require:true,
      type:Boolean
    },
  },
  data(){
    return{
      btnLoading:false,
      parentOptions:[],
      formData:{
        filePath:[],
        category_name:'',
        adminUserIdList:[],
        template_title:'',
        workflow_id:'',
        description:'',
        is_enabled:1,
        // isRemind:0,
        equipment_manage_setting:{
          equipment_id_list:[],
          report_frequency_list:[],
        },
      },
      remindInfo: [],
      groupMemberList:[],
      workflowList:[],
      formRules: {
        category_name: [{ required: true, message: "档案名称不能为空", trigger: "blur" }],
        template_title: [{ required: true, message: "标题不能为空", trigger: "blur" }],
      },
      templateFieldList: [],
      saveBtnStatue: true, // 保存按钮初始状态，防止连点
      selectShowType: 0, // 字段展示形式
      dialogStatus: "",
      textMap: {
        update: "编辑字段",
        create: "新增字段"
      },
      fieldDialogVisible: false,
      selectIndex: -1,
      selectFieldGroupId:0,//被选中行的 分组id 用来判断编辑时 是否改变了分组 是否需要调整位置
      isNewField: false,
      FIELD_DISPLAY_TYPE: FIELD_DISPLAY_TYPE,
      FIELD_DATA_TYPE: FIELD_DATA_TYPE,
      widthList: WIDTH_LIST,
      dataTypeList: [
        // { name: '请选择', value: -1, length: 0, field: -1 },
        // { name: '文本域', value: 1, length: 4000, field: 0, types: [0, 1, 7] },
        {
          name: "字符串",
          value: FIELD_DATA_TYPE.字符串,
          length: 256,
          field: 0,
          types: [
            FIELD_DISPLAY_TYPE.单行文本,
            FIELD_DISPLAY_TYPE.多行文本,
            FIELD_DISPLAY_TYPE.下拉框,
            FIELD_DISPLAY_TYPE.下拉框多选,
            FIELD_DISPLAY_TYPE.图片上传,
            FIELD_DISPLAY_TYPE.文件上传,
            FIELD_DISPLAY_TYPE.视频,
            FIELD_DISPLAY_TYPE.网址类型
          ]
        },
        {
          name: "整数",
          value: FIELD_DATA_TYPE.整数,
          length: 15,
          field: 0,
          types: [FIELD_DISPLAY_TYPE.单行文本, FIELD_DISPLAY_TYPE.下拉框]
        },
        {
          name: "长整数",
          value: FIELD_DATA_TYPE.长整数,
          length: 20,
          field: 0,
          types: [FIELD_DISPLAY_TYPE.单行文本, FIELD_DISPLAY_TYPE.下拉框]
        },
        {
          name: "时间",
          value: FIELD_DATA_TYPE.时间,
          length: 25,
          field: 6,
          types: [FIELD_DISPLAY_TYPE.时间, FIELD_DISPLAY_TYPE.日期]
        },
        {
          name: "小数",
          value: FIELD_DATA_TYPE.小数,
          length: 15,
          field: 0,
          types: [FIELD_DISPLAY_TYPE.单行文本, FIELD_DISPLAY_TYPE.下拉框]
        },
        {
          name: "文本域",
          value: FIELD_DATA_TYPE.文本域,
          length: 4000,
          field: 0,
          types: [FIELD_DISPLAY_TYPE.多行文本,FIELD_DISPLAY_TYPE.图片上传,FIELD_DISPLAY_TYPE.富文本,]
        }
      ],
      fieldTypeList: [
        // { name: '请选择', value: -1 },
        {
          name: "单行文本",
          value: FIELD_DISPLAY_TYPE.单行文本,
          types: [
            FIELD_DATA_TYPE.字符串,
            FIELD_DATA_TYPE.整数,
            FIELD_DATA_TYPE.小数,
            FIELD_DATA_TYPE.长整数
          ]
        },
        {
          name: "多行文本",
          value: FIELD_DISPLAY_TYPE.多行文本,
          types: [FIELD_DATA_TYPE.字符串, FIELD_DATA_TYPE.文本域]
        },
        {
          name: "下拉框(单选)",
          value: FIELD_DISPLAY_TYPE.下拉框,
          types: [
            FIELD_DATA_TYPE.字符串,
            FIELD_DATA_TYPE.整数,
            FIELD_DATA_TYPE.小数,
            FIELD_DATA_TYPE.长整数
          ]
        },
        {
          name: "下拉框(多选)",
          value: FIELD_DISPLAY_TYPE.下拉框多选,
          types: [
            FIELD_DATA_TYPE.字符串,
            // FIELD_DATA_TYPE.整数,
            // FIELD_DATA_TYPE.小数,
            // FIELD_DATA_TYPE.长整数
          ]
        },
        {
          name: "时间",
          value: FIELD_DISPLAY_TYPE.时间,
          types: [FIELD_DATA_TYPE.时间]
        },
        {
          name: "日期",
          value: FIELD_DISPLAY_TYPE.日期,
          types: [FIELD_DATA_TYPE.时间]
        },
        {
          name: "图片上传",
          value: FIELD_DISPLAY_TYPE.图片上传,
          types: [FIELD_DATA_TYPE.字符串, FIELD_DATA_TYPE.文本域]
        },
        {
          name: "文件上传",
          value: FIELD_DISPLAY_TYPE.文件上传,
          types: [FIELD_DATA_TYPE.字符串]
        },
        {
          name: "视频",
          value: FIELD_DISPLAY_TYPE.视频,
          types: [FIELD_DATA_TYPE.字符串]
        },
        {
          name: "网址类型",
          value: FIELD_DISPLAY_TYPE.网址类型,
          types: [FIELD_DATA_TYPE.字符串]
        },
        {
          name: "富文本",
          value: FIELD_DISPLAY_TYPE.富文本,
          types: [FIELD_DATA_TYPE.文本域]
        },
      ],
      fieldForm: {
        page_proportion: 0,
        field_group_id:0,//所属流程分组
        field_name: "",
        column_name: "",
        data_type: null,
        field_type: null,
        length: null,
        scale: null,
        is_must: 1,
        is_related_business: 0,
        is_title: 0,
        is_system: 0,
        is_display_column: 1,
        is_search_field: 0,
        field_property: {
          system_dic_code:'',
          default_value: "",
          is_set_range: false,
          is_display_detail: true,
          image_field_property: {
            maximum: 1,
            upload_image_type: 0
          },
          number_field_property: {
            upper_limit: undefined,
            lower_limit: undefined
          }
        },
        file_field_property:{
          default_value: "",
          is_set_range: false,
          image_field_property: {
            maximum: 1,
          },
          number_field_property: {
            upper_limit: undefined,
            lower_limit: undefined
          }
        },
        video_field_property:{
          default_value: "",
          is_set_range: false,
          image_field_property: {
            maximum: 1,
          },
          number_field_property: {
            upper_limit: undefined,
            lower_limit: undefined
          }
        },
        bind_source: {
          table: "",
          key_field: "",
          value_field: "",
          condition: ""
        },
        dictionary_item_list: [],
      },
      deviceList:[],//设备列表
      frequencyList:[
        {name:'一天一次',id:'1'},
        {name:'一天两次（上午、下午）',id:'2'},
      ],//频次列表
      field_group_list:[
        {
          field_group_id:0,
          field_group_name:'发起人',
        }
      ],
      startInde:0,
      endInde:0,
      moveNameListCount:0
    }
  },
  computed:{
    isPerson(){
      return this.categoryObj.user_type === 1
    },
    isAllowManage(){
      //是否允许管理分类文件夹
      return this.$prm_codes.includes('ssj_ml_gl')
    },
    isNewTemplate() {
      // 是否为新建模板
      return (
        this.categoryObj.template_id === "" || this.categoryObj.template_id == null
      );
    },
    allMoveTemplateList(){
      //过滤掉不能当作标题的字段
      const dealList = this.templateFieldList.filter(item=>{
        if(!(item.data_type == FIELD_DATA_TYPE.文本域 || 
            item.field_type == FIELD_DISPLAY_TYPE.多行文本 ||
            item.field_type == FIELD_DISPLAY_TYPE.图片上传 ||
            item.field_type == FIELD_DISPLAY_TYPE.文件上传 ||
            item.field_type == FIELD_DISPLAY_TYPE.视频 ||
            item.field_type == FIELD_DISPLAY_TYPE.网址类型)){
          if(!item.field_group_id || parseInt(item.field_group_id) === 0){
            return true
          }else{
            return false
          }
        }else{
          return false
        }
      })
      this.moveNameListCount = dealList.length
      return dealList
    },
    isDeviceManage(){
      return this.categoryObj.sub_business_type ==='EquipmentManage'
    },
    workflowStepsTemplateGroup(){
      const groupList =JSON.parse(JSON.stringify(this.field_group_list)) 
      groupList.forEach(item=>{
        const {field_group_id} = item;
        const list = [];
        this.templateFieldList.forEach(f=>{
          //没有field_group_id 统一放到发起人中
          if(!f.field_group_id && field_group_id === 0){
            f.field_group_id=0
            list.push(f)
          }else if(f.field_group_id === field_group_id){
            list.push(f)
          }
        })
        item.fieldList = list
      })
      return groupList
    } 
  },
  watch: {
    "categoryObj.id": {
      async handler(n, o) {
        if (n) {
          this.ResetData();
          this.fetchCategory(n)
        }
      },
      deep: true,
      immediate:true,
    },
    moveNameListCount(n, o){
      if(n < o){//如果发起人显示标题减少 清空标题显示
        this.formData.template_title = ''
      }
    }
  },
  created(){
    this.fetchList();
    this.getUsersLiteFn(1);
    this.getWorkflowListFn();
    this.getAnymarkEquipmentFn();
  },
  methods:{
  //根据field_group_id计算新增位置
    getFieldIndex(field){
      let countIndex =0
      let isStop = false
      this.workflowStepsTemplateGroup.forEach(item=>{
        if(item.field_group_id !== field.field_group_id){
          if( !isStop){
            countIndex = countIndex + item.fieldList.length
          }
        }else{
          isStop = true
          countIndex = countIndex + item.fieldList.length
        }
      })
      return countIndex
    },
    changeWorkflow(val){
      //修改关联审批流程 全部自定义字段合并到发起人分类下面
      this.templateFieldList.forEach(item=>item.field_group_id = 0)
      let list = [
        {
          field_group_id:0,
          field_group_name:'发起人',
        },
      ]
      if(val){
        const currentWorkflow = this.workflowList.find(item=>item.id === val)
        if(currentWorkflow && currentWorkflow.workflow_steps){
          const stepList = currentWorkflow.workflow_steps.map(item=>{
            item.field_group_id = item.id
            item.field_group_name = item.name
            return item
          })
          list=[
            {
              field_group_id:0,
              field_group_name:'发起人',
            },
            ...stepList
          ]
        }
      }
      this.field_group_list = list
      this.$nextTick(() => {
        this.setSort();
      });
    },
    async getAnymarkEquipmentFn () {
      const res = await getAnymarkEquipment()
      if (res.code === 0) {
        this.deviceList = res.data
      }
    },
    // changeRemind(val){
    //   if(val){
    //     if(this.remindInfo.length === 0){
    //       this.remindInfo = [{"userOption":"10","timeOption":"10","datetime":"","wayOption":['10'],"userGroupList":[],"userList":[]}]
    //     }
    //   }
    // },
    resetChange(){
      this.ResetData();
      this.fetchCategory(this.categoryObj.id)
    },
    handleSaveTemplate() {
      this.$refs.dataForm.validate(async (valid) => {
        if (!valid) {
          return false;
        }
        //原本为过滤 只取is_system为0的字段 但是目前还能修改is_system为2（可修改的系统字段） 
        //1 为不可编辑的系统字段 并且不会返回到编辑页面 所以这里将过滤方法去掉
        const nonSystemFieldList = this.templateFieldList
        
        if(nonSystemFieldList.length === 0){
          this.$message.warning('请设置模板字段')
          return
        }
        //如果选的是字典选项 则去除dictionary_item_list
        nonSystemFieldList.forEach(item=>{
          if(item.field_property && item.field_property.system_dic_code){
            item.dictionary_item_list = []
          }
          // 移除多余属性
          delete item.not_null_column
        })
        const params = {
          category_id: this.categoryObj.id,
          category_name: this.formData.category_name,
          template_title: this.formData.template_title,
          description: this.formData.description,
          is_enabled: this.formData.is_enabled,
          field_list: nonSystemFieldList,
          field_group_list:this.field_group_list
        };
        if(this.remindInfo.length > 0){
          //判断消息提醒是否每项都填写了
          if(this.remindInfo.some(item=>{ return item.wayOption.length===0 || !item.userOption || !item.timeOption })){
            this.$message.warning('请检查消息提醒设置，确保每项都已选择')
            return
          }
          //赋值提醒
          params.notify_strategy_list = this.getNotifyStrategyList()
        }
        else{
          params.notify_strategy_list = []
        }
        if(this.formData.adminUserIdList.length>0){
          const userList = []
          this.formData.adminUserIdList.forEach(item=>{
            const user = this.groupMemberList.find(u=>{return u.id === item})
            userList.push(user)
          })
          params.admin_user_ids = userList.map(item=>{return item.id}).join(',')
          params.admin_user_names = userList.map(item=>{return item.name}).join(',')
        }
        if(this.formData.workflow_id && this.formData.workflow_id !== "0"){
          params.workflow_id = this.formData.workflow_id
        }
        
        if(this.formData.filePath.length>0){
          params.parent_category_id = this.formData.filePath.slice(-1)[0]
        }else{
          params.parent_category_id = null
        }
        //设备管理 管理设备
        if(this.isDeviceManage){
          params.equipment_manage_setting = this.formData.equipment_manage_setting
        }
        this.btnLoading = true;
        const {code,data,msg} = await saveCategoryTemplateSettings(params);
        this.btnLoading = false
        if (code === 0) {
          this.$emit("updateTree")
          this.$message.success('保存成功');
          
        } else{
          //保存失败重置页面
          this.resetChange()
          this.$message.error(msg);
        }
      })
    },
    deleteContent(row,index){
      if (this.templateFieldList.filter(x => x.is_system == 0).length == 1) {
        this.$message.warning("该模板下必须存在至少一个非系统字段，不允许删除！");
        return;
      }
      if (row.is_system == 2) {
        this.$message.warning( `【${row.field_name}】为系统初始化字段，不允许删除` );
        return;
      }
      if (row.id) {
        this.$confirm( `删除字段【${row.field_name}】不可恢复数据，确定删除吗?`, "提示",
          {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            customClass: 'confirm-dialog--ew',
            type: "warning"
          }
        ).then(() => {
          if (row.notNullColumn) {
            this.$confirm( `请确认，字段【${row.field_name}】已有数据录入，确定删除吗?`, "提示",
              {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                customClass: 'confirm-dialog--ew',
                type: "warning"
              }
            ).then(() => {
                // this.templateFieldList.splice(index, 1);
                this.DeleteField(row.id);
              })
              .catch(() => {});
          } else {
            // this.templateFieldList.splice(index, 1);
            this.DeleteField(row.id);
          }
        })
        .catch(() => {});
      } else {
        //新添加的字段 不需要提示 直接删除
        const delIndex = this.templateFieldList.findIndex(
          x => x.column_name === row.column_name
        );
        this.templateFieldList.splice(delIndex, 1);
      }
    },
    DeleteField(id) {
      // webRequest
      //   .DeleteById("customtemplatefield", id)
      //   .then(response => {
      //     if (response.code === 0) {
      //       const index = this.templateFieldList.findIndex(
      //         item => item.id === id
      //       );
      //       if (index >= 0) {
      //         this.templateFieldList.splice(index, 1);
      //       }
      //       msg.ok("字段删除成功", "msg");
      //     } else msg.warning(response.msg, "msg");
      //   });
      const index = this.templateFieldList.findIndex(
        item => item.id === id
      );
      if (index >= 0) {
        this.templateFieldList.splice(index, 1);
      }
    },
    editContent(row,index){
      this.selectIndex = this.templateFieldList.findIndex(
        x => x.column_name === row.column_name
      );
      this.selectFieldGroupId = row.field_group_id
      if (row.id) {
        // 已有字段编辑
        const field = this.templateFieldList.find( item => item.id === row.id );
        if (!field.bind_source) {
          field.bind_source = {
            table: "",
            key_field: "",
            value_field: "",
            condition: ""
          };
        }
        if (!field.field_property) {
          field.field_property = {
            system_dic_code:'',
            default_value: "",
            is_set_range: false,
            is_display_detail: true,
            image_field_property: {
              maximum: 1,
              upload_image_type: 0
            },
            number_field_property: {
              upper_limit: undefined,
              lower_limit: undefined
            }
          };
        }else{
          if(!field.field_property.hasOwnProperty('default_value')){
            field.field_property.default_value = null
          }
        }
        console.log(111111111111,field)
        this.fieldForm = JSON.parse(JSON.stringify(field)); // 深拷贝
      } else {
        const field = this.templateFieldList[this.selectIndex];
        this.fieldForm = JSON.parse(JSON.stringify(field)); // 深拷贝
      }

      if (this.fieldForm.field_type === FIELD_DISPLAY_TYPE.下拉框 || this.fieldForm.field_type === FIELD_DISPLAY_TYPE.下拉框多选) {
        if (
          this.fieldForm.bind_source &&
          this.fieldForm.bind_source.table.length > 0
        ) {
          this.selectShowType = 1;
        }else if(this.fieldForm.field_property.system_dic_code){
          this.selectShowType = 3;
        } else {
          this.selectShowType = 2;
        }
      } else this.selectShowType = 0;

      this.dialogStatus = "update";
      this.isNewField = false;
      this.fieldDialogVisible = true;
      this.$nextTick(() => {
        this.$refs.templateFieldForm.clearValidate();
        this.setSort();
      });
    },
    async customtemplateGetcolumnnameFn(name){
      const params={
        fieldName:name
      }
      const {code,data,msg} = await webRequest.customtemplateGetcolumnname(params);
      if (code === 0) {
        return data
      } else{
        this.$message.error(msg);
        return ""
      }
    },
    // 保存字段信息 type为1等于继续新增 不关闭页面
    async handleSaveField(tempData,type) {
      console.log(tempData)
      const field = JSON.parse(JSON.stringify(tempData));
     
      if (!field.column_name) {//没有column_name 请求接口获取 有则不需要
        //通过显示列名获取 列名 方便标题拖拽
        const groupIndex = this.field_group_list.findIndex(item=> item.field_group_id===field.field_group_id)
        const column_name = await this.customtemplateGetcolumnnameFn(field.field_name);
        field.column_name = column_name+groupIndex;
      }
      // 新建模板
      if (this.isNewTemplate) {
        if (this.isNewField) {
           if ( this.templateFieldList.some(x => x.field_name === field.field_name) ) {
            this.$message.error("列名已存在");
            return false;
          }
          const addIndex = this.getFieldIndex(field)
          this.templateFieldList.splice(addIndex, 0, field);;
          this.$message.success("字段已新增到列表");
        } else {
          var existFieldIndex = this.templateFieldList.findIndex(
            x => x.field_name === field.field_name
          );
          if (existFieldIndex > -1 && existFieldIndex !== this.selectIndex) {
              msg.error("列名已存在", "msg");
              return false;
          }
          if(this.selectFieldGroupId === field.field_group_id){
            this.templateFieldList.splice(this.selectIndex, 1, field);
          }else{
            //先移除
            this.templateFieldList.splice( this.selectIndex, 1 );
            //再新增
            const addIndex = this.getFieldIndex(field)
            this.templateFieldList.splice(addIndex, 0, field);
          }
          this.$message.success("字段修改成功");
        }
      }else{
        field.template_id = this.categoryObj.template_id;
         if (this.selectIndex !== -1) {//编辑 存在id为编辑已有的 弹提示
          if(field.id){
            try {
               await this.$confirm("此操作会修改模板表结构, 是否继续?", "提示", {
                 confirmButtonText: "确定",
                 cancelButtonText: "取消",
                 customClass: 'confirm-dialog--ew',
                 type: "warning"
               })
            } catch (error) {
              return
            }
          }
          if(field.field_property && field.field_property.system_dic_code){
            field.dictionary_item_list = []
          }

          if(this.selectFieldGroupId === field.field_group_id){
            this.templateFieldList.splice(this.selectIndex, 1, field);
          }else{
            //先移除
            this.templateFieldList.splice( this.selectIndex, 1 );
            //再新增
            const addIndex = this.getFieldIndex(field)
            this.templateFieldList.splice(addIndex, 0, field);
          }
         }else{
          if ( this.templateFieldList.some(x => x.field_name === field.field_name) ) {
            this.$message.warning("列名已存在");
            return false;
          }
            //字典去除选项
            if(field.field_property && field.field_property.system_dic_code){
              field.dictionary_item_list = []
            }

            const addIndex = this.getFieldIndex(field)
            this.templateFieldList.splice(addIndex, 0, field);
         }
      }
      console.log(this.templateFieldList.map(v=>v.field_name).join(','))
      this.templateFieldList.forEach((element, index) => {
        element.sort_index = this.templateFieldList.length - index;
      });
      this.initFormData();
      this.$nextTick(() => {
        this.$refs.templateFieldForm.clearValidate();
      });
      if(type === 1){//新增并继续
        //恢复选中所属分组
        this.fieldForm.field_group_id = field.field_group_id
        this.isNewField = true//设置为新增
      }else{
        this.fieldDialogVisible = false;
      }
    },
     getDataTypeName(value) {
      const item = this.dataTypeList.find(item => item.value === value);
      return item ? item.name : "";
    },
    getFieldTypeName(value) {
      const item = this.fieldTypeList.find(item => item.value === value);
      return item ? item.name : "";
    },
     // 关闭模板字段弹窗
    cancelSubmitField() {
      this.fieldDialogVisible = false;
      if (this.isNewTemplate) {
        this.$message.info("请不要忘记单击保存按钮，保存模板信息哦！", "msg");
      }
    },
    handleSubmitField(type){
      this.$refs.templateFieldForm.valid(type);
    },
    initFormData() {
      this.fieldForm = {
        page_proportion: 0,
        id: "",
        field_name: "",
        column_name: "",
        data_type: null,
        field_type: null,
        length: null,
        scale: null,
        is_must: 1,
        is_related_business: 0,
        is_title: 0,
        is_system: 0,
        is_display_column: 1,
        is_search_field: 0,
        sort_index: 0,
        field_property: {
          system_dic_code:'',
          default_value: "",
          is_set_range: false,
          is_display_detail: true,
          image_field_property: {
            maximum: 1,
            upload_image_type: 0
          },
          number_field_property: {
            upper_limit: undefined,
            lower_limit: undefined
          }
        },
        bind_source: {
          table: "",
          key_field: "",
          value_field: "",
          condition: ""
        },
        dictionary_item_list: []
      };
      this.selectIndex = -1
      this.selectFieldGroupId = 0
      this.selectID = undefined;
    },
    // 新建字段
    handleAddField(item) {
      this.isNewField = true;
      this.initFormData();
      
      this.fieldForm.field_group_id = item.field_group_id

      this.dialogStatus = "create";
      this.selectShowType = 0;
      this.fieldDialogVisible = true;
      this.$nextTick(() => {
        this.$refs.templateFieldForm.clearValidate();
      });
    },
    ResetData(){
      this.formData = {
        filePath:[],
        category_name:'',
        adminUserIdList:[],
        template_title:'',
        workflow_id:'',
        description:'',
        is_enabled:1,
        // isRemind:0,
        equipment_manage_setting:{
          equipment_id_list:[],
          report_frequency_list:[],
        },
      }
    },
    // 分类详情获取
    async fetchCategory(categoryId) {
      const params = {
        category_id :categoryId
      }
      const {code ,data, msg} = await getCategoryTemplateSettings(params)
      if (code === 0) {
        this.formData.category_name = data.category_name;
        this.formData.adminUserIdList = data.admin_user_ids?data.admin_user_ids.split(','):[];
        this.formData.template_title = data.template_title?data.template_title:'';
        // if(data.notify_strategy_list.length>0){
        //   this.formData.isRemind = 1;
        // }
        //设置提醒默认
        this.setRemindInfo(data.notify_strategy_list)
        if(data.parent_category_path){
          const list = data.parent_category_path.split('/')
          // //去掉第一层0
          // list.shift()
          this.formData.filePath =  list
        }else{
          this.formData.filePath =['0']
        }
         
        this.formData.workflow_id = data.workflow_id?data.workflow_id:'0';
        this.formData.description = data.description;
        //处理模板字段 如果下拉框并且绑定了字典 则删除返回的选项 
        if(data.field_list.length>0){
          data.field_list.forEach(item=>{
            if(item.field_property && item.field_property.system_dic_code){
              item.dictionary_item_list = []
            }
          })
        }
        this.formData.is_enabled = data.is_enabled;
        if(data.equipment_manage_setting){
          this.formData.equipment_manage_setting.equipment_id_list = data.equipment_manage_setting.equipment_id_list;
          this.formData.equipment_manage_setting.report_frequency_list = data.equipment_manage_setting.report_frequency_list;
        }
        this.templateFieldList = data.field_list;
        //动态字段分组
        if(data.field_group_list){
          this.field_group_list = data.field_group_list;
        }


        this.saveBtnStatue = false;

        this.$nextTick(() => {
          this.setSort();
        });
      } else {
        this.$message.warning(msg);
      }
    },
    // 获取提醒信息参数
    getNotifyStrategyList() {
      let strategy_base_setting_models = []
      for (let i = 0; i < this.remindInfo.length; i++) {
        const item = this.remindInfo[i]
        // 提醒途径
        const way_model = {
          way_list: item.wayOption
        }
        let custom_target_model_list = []
        item.userGroupList.forEach((item) => {
          custom_target_model_list.push({
            target_id: item.id,
            // 对象类型(10:用户20:用户组)
            target_type: 20
          })
        })
        item.userList.forEach((item) => {
          custom_target_model_list.push({
            target_id: item.id,
            // 对象类型(10:用户20:用户组)
            target_type: 10
          })
        })
        // 提醒对象
        const target_model = {
          target_type_list: [item.userOption],
          custom_target_model_list:
            item.userOption == '-1' ? custom_target_model_list : []
        }
        // 提醒时间
        const time_model = {
          time_type_list: [item.timeOption],
          custom_time_list: item.timeOption == '-1' ? [item.datetime] : []
        }
        const obj = {
          strategy: {
            way_model: way_model,
            target_model: target_model,
            time_model: time_model
          }
        }
        strategy_base_setting_models.push(obj)
      }
      return strategy_base_setting_models
    },
    setRemindInfo(data) {
      if (!data || !data.length) {
        this.remindInfo = []
      }
      this.remindInfo = data.map((item) => {
        const strategy = item.strategy
        let custom_target_model_list =
          strategy.target_model.custom_target_model_list || []
        custom_target_model_list = custom_target_model_list.map((item) => {
          return {
            id: item.target_id,
            name: item.target_name,
            ...item
          }
        })
        return {
          userOption: strategy.target_model.target_type_list[0] || '',
          timeOption: strategy.time_model.time_type_list[0] || '',
          datetime: strategy.time_model.custom_time_list[0] || '',
          wayOption: strategy.way_model.way_list || [],
          userGroupList: custom_target_model_list.filter(
            (item) => item.target_type == 20
          ),
          userList: custom_target_model_list.filter(
            (item) => item.target_type == 10
          )
        }
      })
    },
    setSort() {
       // 使用 ref 获取表格的 DOM 元素
      const that = this
      this.field_group_list.forEach((item,index)=>{
        // 使用 ref 获取表格的 DOM 元素
        const tableEl = this.$refs['dragTable' + index][0].$el.querySelectorAll(
          ".el-table__body-wrapper > table > tbody"
        )[0];
        // 初始化 Sortable.js
        Sortable.create(tableEl, {
          group: 'tables',  // 指定组名称，允许不同组之间拖动
          animation: 150,
          onStart: evt => {
           //将开始结束下标 都定为同一个
           that.startInde = index
           that.endInde = index
          },
          onAdd: function (evt) {
            //进入这里说明元素从一个列表拖拽到另一个列表 改变结束表格下标
            that.endInde = index
          },
          onEnd: evt => {
            //由于这边是整个动态字段去交换位置  所以需要判断
            let startCount = 0//移动之前的定位
            let endCount = 0
            that.workflowStepsTemplateGroup.forEach((w,i)=>{
              if(i < that.endInde){
                endCount = endCount + w.fieldList.length
              }
              if(i < that.startInde){
                startCount = startCount + w.fieldList.length
              }
            })

            const targetRow = that.templateFieldList.splice((startCount+evt.oldIndex), 1)[0];
            //不同代表跨表格拖动 需要修改成对应的field_group_id
            if(that.startInde !== that.endInde){
              targetRow.field_group_id = that.field_group_list[that.endInde].field_group_id
            }
            
            let putCount = endCount+evt.newIndex
            if(that.endInde > that.startInde){
              putCount = putCount -1
            }
            that.templateFieldList.splice(putCount, 0, targetRow);
            console.log(that.templateFieldList.map(v=>v.field_name).join(','))
          },
        });
      })
    },
    async getWorkflowListFn(){
      const { code , data ,msg} = await getWorkflowList();
      if (code === 0) {
        
        data.forEach(item=>{
          const {is_disabled,name} = item;
          item.name = `${name} (${is_disabled===0?'启用':'禁用'})`
        })
        data.unshift({
          id:'0',
          name:'未设置'
        })
        this.workflowList = data;
      } else{
        this.$message.error(msg);
      }
    },
    async getUsersLiteFn(page){
      const params = {
        offset : page,
        limit : 100,
        state:1,
      };
      //科室管理与 pacs项目查询用户传参不同
      if(this.$currentSystemClass === 'DMS_RIS'){
        params.business_system_id = sessionStorage.getItem("lastname")
        params.business_system_type = "dms"
      }else{
        params.system_id = sessionStorage.getItem("lastname")
      }
      const {data} = await getAllTenancies(params);
      if(data.length>0){
        data.forEach(element => {
          this.groupMemberList.push(element)
        });
        if(data.length === 100){
          this.getUsersLiteFn(page+1)
        }
      }
      
    },
    // 获取分类列表
    async fetchList() {
      const params={
        user_type: this.categoryObj.user_type,
        only_folder:1,//是否只查询文件夹 0否1是
      }
      this.btnLoading = true
      const { code,data,msg } = await getLedgerCategoryTree(params)
      this.btnLoading = false
      if (code === 0) {
        if(data && data.length>0){
          //处理树
          data[0].id = '0'
          //去除其他文件夹 目前使用场景为设备管理  只显示设备管理相关文件夹 固定为科室管理下级
          if(this.parentId && data[0].children){
            data[0].disabled = true
            data[0].children = data[0].children.filter(item=> item.id === this.parentId)
          }
          this.parentOptions = this.setEmptyChildrenToUndefined(this.removeNodesWithTempId(data))
        }else{
          this.parentOptions = []
        }
      }else{
        this.$message.error(msg);
      }
    },
     removeNodesWithTempId(treeData) {
      const processedData = [];
      for (const node of treeData) {
        //设备管理 只能移动到设备管理的文件夹下
        if(this.categoryObj.sub_business_type === 'EquipmentManage'){
          node.disabled = node.sub_business_type !=='EquipmentManage'
        }else{//反之 不允许选中设备管理
          node.disabled = node.sub_business_type ==='EquipmentManage'
        }
        if (!node.template_id) {
          const processedNode = { ...node };
          if (processedNode.children && processedNode.children.length > 0) {
            processedNode.children = this.removeNodesWithTempId(processedNode.children); // 递归处理子节点
          }
          processedData.push(processedNode);
        }
      }
      return processedData;
    },
    setEmptyChildrenToUndefined(treeData) {
      const processedData = [...treeData]; // 复制一份以保留原数据
      for (const node of processedData) {
        if (node.children && node.children.length === 0) {
          node.children = undefined; // 将 children 为空数组的节点的 children 设置为 undefined
        } else if (node.children && node.children.length > 0) {
          node.children = this.setEmptyChildrenToUndefined(node.children); // 递归处理子节点并赋值给当前节点的 children
        }
      }
      return processedData; // 返回处理后的数据
    },
  },
}
</script>

<style lang="less" scoped>
.settingContent{
  height: 100%;
  display: flex;
  flex-direction: column;
  .settingForm{
    flex: 1;
    overflow: auto;
  }
  .footBtn{
    padding-top: 10px;
    text-align: center;
  }
}
.settingTitle{
  display: flex;
  align-items: center;
  margin-bottom: 10px;
  font-size: 14px;
  .titleTip{
    height: 14px;
    width: 4px;
    background: #0a70b0;
    margin-top: 2px;
    margin-right: 5px;
  }
}
.fieldGroupTitle{
  font-size: 14px;
  // font-weight: bold;
  margin-bottom: 10px;
}
.timeline-item{
  position: relative;
  padding-bottom: 20px;
  .timeline-item-tail {
    position: absolute;
    left: 4px;
    height: 100%;
    border-left: 2px solid #DCDFE6;
  }
  .timeline-item__node {
    position: absolute;
    background-color: #0A70B0;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;

    left: 1px;
    width: 8px;
    height: 8px;
  }
  .timeline-item__wrapper{
    position: relative;
    padding-left: 22px;
    top: -5px;
  }
  &:last-child .timeline-item-tail{
    display: none;
  }
}



</style>