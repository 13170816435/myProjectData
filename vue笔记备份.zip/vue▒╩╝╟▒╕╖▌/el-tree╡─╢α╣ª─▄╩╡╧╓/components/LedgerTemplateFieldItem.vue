<template>
  <el-form
    ref="fieldForm"
    :model="fieldForm"
    label-position="right"
    label-width="120px"
    size="small"
    style="margin:0 15px;"
  >
    <el-row :gutter="22">
      <el-col v-if="fieldGroupList.length>1" :span="spanfilter(12)">
        <el-form-item
          label="所属分组："
          prop="field_group_id"
          :rules="fieldFormRules.field_group_id"
        >
          <el-select
            v-model="fieldForm.field_group_id"
            placeholder="请选择所属分组"
            style="width:100%"
          >
            <el-option
              v-for="(item) in fieldGroupList"
              :key="item.field_group_id"
              :label="item.field_group_name"
              :value="item.field_group_id"
            />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="spanfilter(12)">
        <el-form-item
          label="显示列名："
          prop="field_name"
          :rules="fieldFormRules.field_name"
        >
          <el-input
            v-model="fieldForm.field_name"
            :maxlength="30"
            show-word-limit
            placeholder="请输入显示列名"
            clearable
          />
        </el-form-item>
      </el-col>

      <!-- <el-col :span="spanfilter(12)">
        <el-form-item
          label="列名"
          prop="column_name"
          :rules="fieldFormRules.column_name"
        >
          <el-input
            v-model="fieldForm.column_name"
            :maxlength="30"
            show-word-limit
            placeholder="请输入列名(字母开头)"
            clearable
          />
        </el-form-item>
      </el-col> -->

      <el-col :span="spanfilter(12)">
        <el-form-item
          label="数据类型："
          prop="data_type"
          :rules="fieldFormRules.data_type"
        >
          <el-select
            v-model="fieldForm.data_type"
            placeholder="请选择数据类型"
            clearable
            style="width:100%"
          >
            <el-option
              v-for="(item, index) in datatypelist"
              :key="index"
              :label="item.name"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
      </el-col>

      <el-col
        v-if="
          fieldForm.data_type != FIELD_DATA_TYPE.整数 &&
            fieldForm.data_type != FIELD_DATA_TYPE.长整数 &&
            fieldForm.field_type != FIELD_DISPLAY_TYPE.图片上传
        "
        :span="spanfilter(6)"
      >
        <el-form-item label="长度：" prop="length" :rules="fieldFormRules.length">
          <el-input-number
            v-model="fieldForm.length"
            :precision="0"
            :min="1"
            :max="5000"
          />
        </el-form-item>
      </el-col>

      <el-col
        v-if="
          selectDataType == FIELD_DATA_TYPE.小数 ||
            fieldForm.data_type == FIELD_DATA_TYPE.小数
        "
        :span="spanfilter(6)"
      >
        <el-form-item label="精度：" prop="scale">
          <el-input-number
            v-model="fieldForm.scale"
            :precision="0"
            :min="2"
            :max="10"
          />
        </el-form-item>
      </el-col>
    </el-row>

    <el-row>
      <el-col
        v-if="
          fieldForm.data_type == FIELD_DATA_TYPE.整数 ||
            fieldForm.data_type == FIELD_DATA_TYPE.小数
        "
        :span="spanfilter(12)"
      >
        <el-form-item label="是否设置范围：" prop="fieldPropertyIsSetRange">
          <el-radio
            v-model="fieldForm.field_property.is_set_range"
            :label="true"
            >是</el-radio
          >
          <el-radio
            v-model="fieldForm.field_property.is_set_range"
            :label="false"
            >否</el-radio
          >
        </el-form-item>
      </el-col>

      <el-col
        v-if="
          fieldForm.field_property &&
            fieldForm.field_property.is_set_range &&
            (fieldForm.data_type == FIELD_DATA_TYPE.整数 ||
              fieldForm.data_type == FIELD_DATA_TYPE.小数)
        "
        :span="spanfilter(6)"
      >
        <el-form-item
          label="区间下限："
          prop="fieldPropertyLowerLimit"
          :rules="fieldFormRules.fieldPropertyLowerLimit"
        >
          <el-input-number
            v-model="fieldForm.field_property.number_field_property.lower_limit"
          />
        </el-form-item>
      </el-col>
      <el-col
        v-if="
          fieldForm.field_property &&
            fieldForm.field_property.is_set_range &&
            (fieldForm.data_type == FIELD_DATA_TYPE.整数 ||
              fieldForm.data_type == FIELD_DATA_TYPE.小数)
        "
        :span="spanfilter(6)"
      >
        <el-form-item
          label="区间上限："
          prop="fieldPropertyUpperLimit"
          :rules="fieldFormRules.fieldPropertyUpperLimit"
        >
          <el-input-number
            v-model="fieldForm.field_property.number_field_property.upper_limit"
          />
        </el-form-item>
      </el-col>
    </el-row>

    <el-row :gutter="22">
      <el-col :span="spanfilter(6)">
        <el-form-item
          label="输入方式："
          prop="field_type"
          :rules="fieldFormRules.field_type"
        >
          <el-select
            v-model="fieldForm.field_type"
            placeholder="请选择输入方式"
            style="width:100%"
            clearable
          >
            <el-option
              v-for="(item, index) in fliterFieldTypeList"
              :key="index"
              :label="item.name"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col 
        v-if="
          !(fieldForm.field_type == FIELD_DISPLAY_TYPE.多行文本 ||
          fieldForm.field_type == FIELD_DISPLAY_TYPE.图片上传 ||
          fieldForm.field_type == FIELD_DISPLAY_TYPE.文件上传 ||
          fieldForm.field_type == FIELD_DISPLAY_TYPE.文本域 ||
          fieldForm.field_type == FIELD_DISPLAY_TYPE.富文本 ||
          fieldForm.field_type == FIELD_DISPLAY_TYPE.视频 )
        "
        :span="spanfilter(6)">
        <el-form-item
          label="占用宽度："
          prop="page_proportion"
        >
          <el-tooltip class="item" effect="dark"  placement="top-end">
              <div style="color:#909399" slot="content">关于占用整行的宽度：你可以定义该字段在填写页面占用的页面宽度为多少，仅在PC端生效。</div>
              <i class="el-icon-question ordinalTip"></i>
            </el-tooltip>
          <el-select
            v-model="fieldForm.page_proportion"
            placeholder="请选择输入方式"
            style="width:100%"
            clearable
          >
            <el-option
              v-for="(item, index) in widthList"
              :key="index"
              :label="item.name"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
      </el-col>

      <el-col :span="spanfilter(12)">
        <el-form-item
          label="输入提示："
          prop="field_type"
          :rules="fieldFormRules.fieldPropertyTipMessage"
        >
          <el-input
            v-model="fieldForm.field_property.tip_message"
            :maxlength="50"
            show-word-limit
            placeholder="字段输入提示,例如：详情描述(什么时间发生?出现什么样的情况?如何处理?)"
            clearable
          />
        </el-form-item>
      </el-col>
      <el-col 
        v-if="
          fieldForm.field_type == FIELD_DISPLAY_TYPE.单行文本 ||
          fieldForm.field_type == FIELD_DISPLAY_TYPE.多行文本 ||
          fieldForm.field_type == FIELD_DISPLAY_TYPE.时间 ||
          fieldForm.field_type == FIELD_DISPLAY_TYPE.日期 ||
          fieldForm.field_type == FIELD_DISPLAY_TYPE.网址类型 ||
          fieldForm.field_type == FIELD_DISPLAY_TYPE.富文本 
        "
        :span="spanfilter(12)"
      >
        <el-form-item
          label="默认值："
          prop="field_type"
          :rules="fieldFormRules.fieldPropertyDefaultValue"
        >
          <el-date-picker
            v-if="fieldForm.field_type == FIELD_DISPLAY_TYPE.日期"
            v-model="fieldForm.field_property.default_value"
            clearable
            value-format="yyyy-MM-dd"
            type="date"
          />
          <el-date-picker
            v-else-if="fieldForm.field_type == FIELD_DISPLAY_TYPE.时间"
            v-model="fieldForm.field_property.default_value"
            clearable
            value-format="yyyy-MM-dd HH:mm:ss"
            type="datetime"
          />
          <el-input-number
            size="small"
            v-else-if="
              fieldForm.data_type == FIELD_DATA_TYPE.整数 ||
              fieldForm.data_type == FIELD_DATA_TYPE.小数
            "
            v-model="fieldForm.field_property.default_value"
            :precision=' fieldForm.data_type === FIELD_DATA_TYPE.小数 ? fieldForm.scale:0 '
          />
          <el-input
            v-else
            v-model="fieldForm.field_property.default_value"
            clearable
          />
        </el-form-item>
      </el-col>

      <el-col
        v-if="fieldForm.field_type == FIELD_DISPLAY_TYPE.图片上传"
        :span="spanfilter(6)"
      >
        <el-form-item
          label="图片上传类型："
          prop="field_type"
          :rules="fieldFormRules.fieldPropertyUploadImageType"
        >
          <el-radio
            v-model="
              fieldForm.field_property.image_field_property.upload_image_type
            "
            :label="0"
            >单图上传</el-radio
          >
          <el-radio
            v-model="
              fieldForm.field_property.image_field_property.upload_image_type
            "
            :label="1"
            >多图上传</el-radio
          >
        </el-form-item>
      </el-col>
      <el-col
        v-if="fieldForm.field_type == FIELD_DISPLAY_TYPE.图片上传"
        :span="spanfilter(6)"
      >
        <el-form-item
          label="最大上传数量："
          prop="field_type"
          :rules="fieldFormRules.fieldPropertyMaximum"
        >
          <el-input-number
            v-model="fieldForm.field_property.image_field_property.maximum"
            :disabled="
              fieldForm.field_property.image_field_property.upload_image_type ==
                0
            "
            :precision="0"
            :min="1"
          />
        </el-form-item>
      </el-col>
      <el-col
        v-if="fieldForm.field_type == FIELD_DISPLAY_TYPE.文件上传"
        :span="spanfilter(12)"
      >
        <el-form-item
          label="最大上传数量："
          prop="field_type"
          :rules="fieldFormRules.fieldPropertyMaximum"
        >
          <el-input-number
            v-model="fieldForm.file_field_property.image_field_property.maximum"
            :precision="0"
            :min="1"
          />
        </el-form-item>
      </el-col>
      <el-col
        v-if="fieldForm.field_type == FIELD_DISPLAY_TYPE.视频"
        :span="spanfilter(12)"
      >
        <el-form-item
          label="最大上传数量："
          prop="field_type"
          :rules="fieldFormRules.fieldPropertyMaximum"
        >
          <el-input-number
            v-model="fieldForm.video_field_property.image_field_property.maximum"
            :precision="0"
            :min="1"
          />
        </el-form-item>
      </el-col>
      <!-- <el-col :span="spanfilter(6)">
        <el-form-item label="列表展示：" prop="is_display_column">
          <el-radio
            v-model="fieldForm.is_display_column"
            :label="1"
            :disabled="ShowRadio[0]"
            >是</el-radio
          >
          <el-radio
            v-model="fieldForm.is_display_column"
            :label="0"
            :disabled="ShowRadio[0]"
            >否</el-radio
          >
        </el-form-item>
      </el-col> -->

      <el-col :span="spanfilter(6)">
        <el-form-item label="作为查询条件：" prop="is_search_field">
          <el-radio
            v-model="fieldForm.is_search_field"
            :label="1"
            :disabled="ShowRadio[1]"
            >是</el-radio
          >
          <el-radio
            v-model="fieldForm.is_search_field"
            :label="0"
            :disabled="ShowRadio[1]"
            >否</el-radio
          >
        </el-form-item>
      </el-col>

      <!-- <el-col :span="spanfilter(6)">
        <el-form-item label="绑定业务数据：" prop="is_related_business">
          <el-radio
            v-model="fieldForm.is_related_business"
            disabled
            :label="1"
            >是</el-radio
          >
          <el-radio
            v-model="fieldForm.is_related_business"
            :disabled="ShowRadio[2]"
            :label="0"
            >否</el-radio
          >
        </el-form-item>
      </el-col> -->

      <!-- <el-col :span="spanfilter(6)">
        <el-form-item
          label="设置为标题"
          prop="is_title"
        >
          <el-radio v-model="fieldForm.is_title" :label="1">是</el-radio>
          <el-radio v-model="fieldForm.is_title" :label="0">否</el-radio>
        </el-form-item>

      </el-col> -->

      <el-col :span="spanfilter(6)">
        <el-form-item label="是否必填：" prop="is_must">
          <el-radio
            v-model="fieldForm.is_must"
            :disabled="ShowRadio[3]"
            :label="1"
            >是</el-radio
          >
          <el-radio
            v-model="fieldForm.is_must"
            :disabled="ShowRadio[3]"
            :label="0"
            >否</el-radio
          >
        </el-form-item>
      </el-col>
      <el-col :span="spanfilter(6)" >
        <el-form-item label="详情页是否显示：" prop="fieldPropertyIsSetRange">
          <el-radio
            v-model="fieldForm.field_property.is_display_detail"
            :label="true"
            >是</el-radio
          >
          <el-radio
            v-model="fieldForm.field_property.is_display_detail"
            :label="false"
            >否</el-radio
          >
        </el-form-item>
      </el-col>
      <!-- sass科室管理 下拉框只有自定义选项 -->
      <el-col v-if="$currentSystemClass !== 'DMS_RIS'" :span="spanfilter(12)">
        <el-radio-group
          v-if="fieldForm.field_type === FIELD_DISPLAY_TYPE.下拉框 || fieldForm.field_type === FIELD_DISPLAY_TYPE.下拉框多选"
          v-model="mapSelectShowType"
          style="float:right;"
        >
          <el-radio-button :label="3">绑定数据字典</el-radio-button>
          <el-radio-button :label="2">自定义选项</el-radio-button>
          <!-- <el-radio-button :label="1">绑定数据源</el-radio-button> -->
        </el-radio-group>
      </el-col>
      <el-col v-if="mapSelectShowType === 3" :span="24">
        <div>
          <el-divider>绑定数据字典</el-divider>
          <el-select
            v-model="fieldForm.field_property.system_dic_code"
            placeholder="请选择数据字典"
            style="width:100%"
            clearable
          >
            <el-option
              v-for="(item, index) in categoryList"
              :key="index"
              :label="item.description"
              :value="item.name"
            />
          </el-select>
        </div>
      </el-col>
      <el-col v-if="mapSelectShowType === 1" :span="24">
        <el-col :span="spanfilter(12)">
          <el-divider>绑定数据源</el-divider>
          <el-form-item
            label="数据源"
            prop="bind_source.table"
            :rules="fieldFormRules.bindSourceTable"
          >
            <el-select
              v-model="fieldForm.bind_source.table"
              placeholder="请选择数据源"
              clearable
              filterable
              style="width:100%"
            >
              <el-option
                v-for="(item, index) in tableSource"
                :key="index"
                :label="item.name"
                :value="item.name"
              />
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="spanfilter(6)">
          <el-form-item
            label="显示文本"
            prop="bind_source.key_field"
            :rules="fieldFormRules.bindSourceKeyField"
          >
            <el-select
              v-model="fieldForm.bind_source.key_field"
              placeholder="请选择列"
              clearable
              filterable
              style="width:100%"
            >
              <el-option
                v-for="(item, index) in tableFieldList"
                :key="index"
                :label="item.name"
                :value="item.name"
              />
            </el-select>
          </el-form-item>
        </el-col>

        <el-col :span="spanfilter(6)">
          <el-form-item
            label="值"
            prop="bind_source.value_field"
            :rules="fieldFormRules.bindSourceValueField"
          >
            <el-select
              v-model="fieldForm.bind_source.value_field"
              placeholder="请选择列"
              clearable
              filterable
              style="width:100%"
              @change="handleBindSourceValueChange"
            >
              <el-option
                v-for="(item, index) in tableFieldList"
                :key="index"
                :label="item.name"
                :value="item.name"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="spanfilter(12)">
          <el-form-item label="过滤条件" prop="bind_source.condition">
            <el-alert
              title="科室ID变量名：{DepartmentId}  机构ID变量名：{OrganizationID}"
              type="warning"
              :closable="false"
              size="mini"
              style="margin-bottom: 15px;"
            />
            <el-input
              v-model="fieldForm.bind_source.condition"
              clearable
              :autosize="{ minRows: 6, maxRows: 8 }"
              type="textarea"
              placeholder="请输入过滤条件"
            />
          </el-form-item>
        </el-col>
      </el-col>
      <el-col v-if="mapSelectShowType === 2" :span="24">
        <el-divider>下拉框选项</el-divider>
        <el-button
          size="small"
          style="margin-bottom: 25px;"
          type="primary"
          icon="el-icon-plus"
          @click="handleAddDict"
          >新增下拉选项</el-button
        >
        <el-table
          :data="fieldForm.dictionary_item_list"
          stripe
          border
          height="240"
          ref="dictionaryTable"
          fit
          class="fieldTable"
          highlight-current-row
          :header-cell-style="{ 'text-align': 'center' }"
          @current-change="dictRowClick"
        >
          <el-table-column
            label="序号"
            align="center"
            width="50px"
            type="index"
          />
          <el-table-column prop="dict_key" label="选项名称" align="left">
            <template slot-scope="scope">
              <span v-if="scope.row.show">
                <el-form-item
                  :prop="'dictionary_item_list.' + scope.$index + '.dict_key'"
                  :rules="fieldFormRules.dict_key"
                >
                  <el-input
                    v-model="scope.row.dict_key"
                    maxlength="64"
                    clearable
                    placeholder="请输入内容"
                  />
                </el-form-item>
              </span>
              <span v-else>{{ scope.row.dict_key }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="dict_value" label="选项代码" align="left">
            <template slot-scope="scope">
              <span v-if="scope.row.show&&!scope.row.id">
                <el-form-item
                  :prop="'dictionary_item_list.' + scope.$index + '.dict_value'"
                  :rules="fieldFormRules.dict_value"
                >
                  <!-- 整数 -->
                  <el-input-number
                    size="mini"
                    v-if="fieldForm.data_type === FIELD_DATA_TYPE.整数"
                    v-model="scope.row.dict_value"
                    :precision="0"
                  />
                  <!-- 长整数 -->
                  <el-input-number
                    size="mini"
                    v-else-if="fieldForm.data_type === FIELD_DATA_TYPE.长整数"
                    v-model="scope.row.dict_value"
                  />
                  <!-- 日期 -->
                  <el-date-picker
                    v-else-if="fieldForm.data_type === FIELD_DATA_TYPE.时间"
                    v-model="scope.row.dict_value"
                    clearable
                    value-format="yyyy-MM-dd"
                    type="date"
                    size="mini"
                    placeholder="选择日期"
                    style="width:100%"
                  />
                  <!-- 小数 -->
                  <el-input-number
                    size="mini"
                    v-else-if="fieldForm.data_type === FIELD_DATA_TYPE.小数"
                    v-model="scope.row.dict_value"
                    :precision="fieldForm.scale"
                  />
                  <!-- 文本 -->
                  <el-input
                    v-else
                    size="mini"
                    v-model="scope.row.dict_value"
                    maxlength="20"
                    clearable
                    placeholder="请输入选项代码"
                  />
                </el-form-item>
              </span>
              <span v-else>
                <!-- 小数显示文本保留两位小数 -->
                <span v-if="fieldForm.data_type === FIELD_DATA_TYPE.小数">{{
                  keepTwo(scope.row.dict_value)
                }}</span>
                <span v-else>{{ scope.row.dict_value }}</span>
              </span>
            </template>
          </el-table-column>
          <el-table-column v-if="fieldForm.field_type !== FIELD_DISPLAY_TYPE.下拉框多选" label="是否默认" width="80" align="left">
            <template slot-scope="scope">
              <el-switch
                v-model="scope.row.is_default"
                :active-value="1"
                :inactive-value="0"
                @change="(val) =>{switchChange(val,scope.$index)}">
              </el-switch>
            </template>
          </el-table-column>
          <el-table-column
            prop="sort_index"
            label="排序"
            align="center"
            width="160"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.show">
                <el-form-item
                  :prop="'dictionary_item_list.' + scope.$index + '.sort_index'"
                  :rules="fieldFormRules.sort_index"
                >
                  <el-input-number
                    size="mini"
                    v-model="scope.row.sort_index"
                    :precision="0"
                    :min="0"
                  />
                </el-form-item>
              </span>
              <span v-else>{{ scope.row.sort_index }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="操作"
            align="center"
            fixed="right"
            width="100"
          >
            <template slot-scope="scope">
                <!-- :type="scope.row.show ? 'success' : 'primary'" -->
              <el-button
                type="text"
                @click="
                  scope.row.show
                    ? handleSaveDict(scope.row, scope.$index)
                    : handleEditDict(scope.row, scope.$index)
                "
                >{{ scope.row.show ? "保存" : "编辑" }}</el-button
              >
                <!-- :type="scope.row.show ? 'warning' : 'danger'" -->
              <el-button
                type="text"
                @click="
                  scope.row.show
                    ? handleCancelDict(scope.row, scope.$index)
                    : handleDeleteDict(scope.row, scope.$index)
                "
                >{{ scope.row.show ? "取消" : "删除" }}</el-button
              >
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>

    <el-input v-model="fieldForm.id" style="display:none" />
    <el-input v-model="fieldForm.sort_index" style="display:none" />
  </el-form>
</template>
<script>
import {
  FieldSourceTableList,
  FieldSourceFieldList
} from "@/api/anymark/marktemplatefield";
import { msg } from "@/utils/common";
import { FIELD_DATA_TYPE, FIELD_DISPLAY_TYPE } from "@/utils";
import { getCategoryList } from "@/api/dictionary";
// import { validateRule } from '@/utils/rules'
export default {
  name: "LedgerTemplateFieldItem",
  props: {
    isNewField: { type: Boolean, required: true },
    fieldForm: {
      type: Object,
      required: true
    },
    datatypelist: { type: Array, required: true },
    fieldtypelist: { type: Array, required: true },
    widthList: { type: Array, required: true },
    selectShowType: { type: Number, required: true },
    fieldGroupList:{ type: Array, required: true },
  },
  data() {
    var validateColumnName = (rule, value, callback) => {
      const regExp = new RegExp("^[a-zA-Z][a-zA-Z_0-9]{3,29}$");
      if (regExp.test(value) === false) {
        callback(new Error("请输入字母、数字或下划线,长度4-30个字符"));
      } else {
        callback();
      }
    };

    var checkLowerLimit = (rule, value, callback) => {
      if (
        !Number.isFinite(
          this.fieldForm.field_property.number_field_property.lower_limit
        )
      ) {
        callback(new Error("请输入区间下限,只能填写数字"));
      } else {
        // if (this.fieldForm.field_property.number_field_property.lower_limit < 0) {
        //   callback(new Error('区间下限不能小于0'))
        // } else

        if (
          this.fieldForm.field_property.number_field_property.upper_limit &&
          this.fieldForm.field_property.number_field_property.lower_limit >=
            this.fieldForm.field_property.number_field_property.upper_limit
        ) {
          callback(
            new Error(
              `区间下限不能大于等于${this.fieldForm.field_property.number_field_property.upper_limit}`
            )
          );
        } else {
          callback();
        }
      }
    };

    var checkUpperLimit = (rule, value, callback) => {
      if (
        !Number.isFinite(
          this.fieldForm.field_property.number_field_property.upper_limit
        )
      ) {
        callback(new Error("请输入区间上限,只能填写数字"));
      } else {
        if (!this.fieldForm.field_property.number_field_property.lower_limit) {
          this.$refs.fieldForm.validateField("fieldPropertyLowerLimit");
          callback();
        } else if (
          this.fieldForm.field_property.number_field_property.lower_limit >=
          this.fieldForm.field_property.number_field_property.upper_limit
        ) {
          callback(
            new Error(
              `区间上限不能小于等于${this.fieldForm.field_property.number_field_property.lower_limit}`
            )
          );
        } else {
          callback();
        }
      }

      if (!value || !Number.isInteger(Number(value))) {
        callback(new Error("请输入区间上限，必须为数字"));
      } else {
        if (
          this.fieldForm.field_property.number_field_property.lower_limit &&
          value <=
            this.fieldForm.field_property.number_field_property.lower_limit
        ) {
          callback(new Error("区间上限不能小于或等于区间下限"));
        } else {
          callback();
        }
      }
    };

    return {
      selectDataType: -1,
      bIsMust: true,
      tableSource: [],
      tableFieldList: [],
      fieldFormRules: {
        field_group_id:[{
          required: true,
          message: "请选择所属分组",
          trigger: "change"
        }],
        field_name: [
          {
            required: true,
            message: "请输入显示列名",
            trigger: "blur"
          },
          {
            min: 1,
            max: 30,
            message: "长度在1到30个字符",
            trigger: "blur"
          }
        ],
        column_name: [
          { validator: validateColumnName, trigger: "blur" }
          // { required: true, message: '请输入列名', trigger: 'blur' },
          // { min: 4, max: 30, message: '长度在4到30个字符', trigger: 'blur' }
        ],
        data_type: [
          {
            required: true,
            message: "请选择数据类型",
            trigger: "change"
          }
        ],
        length: [
          {
            required: true,
            message: "请选择长度",
            trigger: "change"
          }
        ],
        field_type: [
          {
            required: true,
            message: "请选择输入方式",
            trigger: "change"
          }
        ],
        dict_key: [
          {
            required: true,
            message: "请输入显示的文本",
            trigger: "blur"
          },
          {
            min: 1,
            max: 64,
            message: "长度在1到64个字符",
            trigger: "blur"
          }
        ],
        dict_value: [
          {
            required: true,
            message: "请输入选项的值",
            trigger: "blur"
          }
          //   { min: 1, max: 64, message: '长度在1到64个字符', trigger: 'blur' }
        ],
        bindSourceTable: [
          {
            required: true,
            message: "请选择数据源",
            trigger: "change"
          }
        ],
        bindSourceKeyField: [
          { required: true, message: "请选择列", trigger: "change" }
        ],
        bindSourceValueField: [
          { required: true, message: "请选择列", trigger: "change" }
        ],
        fieldPropertyUploadImageType: [
          {
            required: true,
            message: "请选择上传图片类型",
            trigger: "change"
          }
        ],
        fieldPropertyMaximum: [
          {
            required: true,
            message: "请输入上传数量",
            trigger: "change"
          }
        ],
        scale: [
          {
            required: true,
            message: "请输入精度",
            trigger: "change"
          }
        ],
        fieldPropertyLowerLimit: [
          //   { required: true, message: '请输入区间下限', trigger: 'change' },
          { validator: checkLowerLimit, trigger: "change" }
        ],
        fieldPropertyUpperLimit: [
          //   { required: true, message: '请输入区间上限', trigger: 'change' },
          { validator: checkUpperLimit, trigger: "change" }
        ]
      },
      FIELD_DISPLAY_TYPE: FIELD_DISPLAY_TYPE,
      FIELD_DATA_TYPE: FIELD_DATA_TYPE,
      ShowRadio: [false, false, false, false],
      fliterFieldTypeList: [],
      categoryList:[],
    };
  },
  computed: {
    mapSelectShowType: {
      get() {
        if (this.selectShowType === 1) this.getOptions();
        return this.selectShowType;
      },
      set(val) {
        this.$emit("update:selectShowType", val);
      }
    }
  },
  watch: {
    // 监视数据源表名，同步更新列
    "fieldForm.bind_source.table": {
      handler: function(n, o) {
        if (n && n !== o) this.handleTableFieldList(n);
        else this.tableFieldList = [];
      },
      immediate: true
    },

    // 监视数据类型
    "fieldForm.data_type": {
      handler: function(n, o) {
        console.log("templateField.fieldForm", this.fieldForm);
        this.fliterFieldTypeList = [];
        const _isRelatedBusiness = this.fieldForm.is_related_business;
        if (_isRelatedBusiness === 1 && n !== FIELD_DATA_TYPE.字符串) {
          msg.warning("字段已经关联业务,展现形式只能为字符串", "msg");
          this.fieldForm.data_type = FIELD_DATA_TYPE.字符串;
          return false;
        }

        if (n) {
          const option = this.datatypelist.find(x => x.value === n);
          console.log(option)
          console.log(this.fieldtypelist)
          this.fliterFieldTypeList = option
            ? this.fieldtypelist.filter(y => option.types.includes(y.value))
            : [];
            console.log(this.fliterFieldTypeList)
          // 不存在展示类型，则清空
          if (
            !this.fliterFieldTypeList.some(
              x => x.value === this.fieldForm.field_type
            )
          ) {
            this.fieldForm.field_type = null;
            this.mapSelectShowType = 0;
          }
          //   if (!option.types.includes(this.fieldForm.field_type) && this.fieldForm.field_type) {
          //     msg.warning(`字段数据类型为${option.name}，展现形式只能为${typenames.join(',')}`, 'msg')
          //     this.fieldForm.field_type = null
          //     return false
          //   }

          this.fieldForm.length = option.length;
          if (option && this.isNewField) {
            this.fieldForm.field_type =
              this.fieldForm.field_type === -1
                ? option.field
                : this.fieldForm.field_type;
          }
          // 选择小数
          if (n === FIELD_DATA_TYPE.小数 || n === FIELD_DATA_TYPE.整数) {
            this.fieldForm.scale = 2;

            if (
              !this.fieldForm.field_property ||
              this.fieldForm.field_property.number_field_property == null
            ) {
              this.fieldForm.field_property.number_field_property = {
                upper_limit: undefined,
                lower_limit: undefined
              };
            }
          }
          // if (
          //   n === FIELD_DATA_TYPE.时间 ||
          //   this.fieldForm.field_type === FIELD_DISPLAY_TYPE.时间
          // ) {
          //   this.fieldForm.field_type = FIELD_DISPLAY_TYPE.时间;
          //   this.fieldForm.length = 25;
          // }
        }
      },
      immediate: true
    },
    // 监视展示类型
    "fieldForm.field_type": {
      handler: function(n, o) {
        const _isRelatedBusiness = this.fieldForm.is_related_business;
        //防止编辑时field_type修改清空了default_value
        if(o !== undefined){
          //清空默认值
          this.fieldForm.field_property.default_value = null;
        }
        
        if (n) {
          this.mapSelectShowType = 0;
          if (_isRelatedBusiness === 1 && n !== FIELD_DISPLAY_TYPE.单行文本) {
            msg.warning("字段已经关联业务,展现形式只能为单行文本", "msg");
            this.fieldForm.field_type = FIELD_DISPLAY_TYPE.单行文本;
            return false;
          }

          if (
            this.fieldForm.is_title === 1 &&
            n !== FIELD_DISPLAY_TYPE.单行文本
          ) {
            msg.warning("字段已经被设置为标题,展现形式只能为单行文本", "msg");
            this.fieldForm.field_type = FIELD_DISPLAY_TYPE.单行文本;
            return false;
          }

          if (
            this.fieldForm.field_property &&
            this.fieldForm.field_property.is_set_range &&
            n !== FIELD_DISPLAY_TYPE.单行文本
          ) {
            msg.warning(
              "字段已经设置区间范围,展现形式只能为单行文本",
              "msg",
              null,
              1
            );
            this.fieldForm.field_type = FIELD_DISPLAY_TYPE.单行文本;
            return false;
          }

          const option = this.fieldtypelist.find(x => x.value === n);
          const typenames = option
            ? option.types.map(x => {
                return this.datatypelist.find(y => y.value === x).name;
              })
            : [];

          if (
            !option.types.includes(this.fieldForm.data_type) &&
            this.fieldForm.data_type
          ) {
            msg.warning(
              `展现形式为${option.name}，字段数据类型只能为${typenames.join(
                ","
              )}`,
              "msg"
            );
            this.fieldForm.field_type = null;
            return false;
          }

          // if ((this.fieldForm.data_type !== FIELD_DATA_TYPE.字符串 && this.fieldForm.data_type !== FIELD_DATA_TYPE.文本域) && n === FIELD_DISPLAY_TYPE.图片上传) {
          //   msg.warning('字段数据类型为字符串或者文本域，才能选择图片上传', 'msg')
          //   this.fieldForm.field_type = FIELD_DISPLAY_TYPE.单行文本
          //   return false
          // }

          // if (this.fieldForm.data_type === FIELD_DATA_TYPE.时间 || n === FIELD_DISPLAY_TYPE.时间) {
          //   this.fieldForm.field_type = FIELD_DISPLAY_TYPE.时间
          //   this.fieldForm.length = 25
          // }

          if (n === FIELD_DISPLAY_TYPE.时间) {
            //   this.fieldForm.data_type = FIELD_DATA_TYPE.时间
            this.mapSelectShowType = 0;
            this.changeShowRadio([false, false, true, false]);
          } else if (n === FIELD_DISPLAY_TYPE.下拉框) {
            // 选择为下拉框，默认选中数据字典
            if(this.fieldForm.field_property.system_dic_code){
              this.mapSelectShowType = 3;
            }else{
              this.mapSelectShowType =
                this.fieldForm.bind_source.table.length === 0 ? 2 : 1;
            }
            this.changeShowRadio([false, false, true, false]);
          } else if (n === FIELD_DISPLAY_TYPE.下拉框多选) {
            // 选择为下拉框，默认选中数据字典
            if(this.fieldForm.field_property.system_dic_code){
              this.mapSelectShowType = 3;
            }else{
              this.mapSelectShowType =
                this.fieldForm.bind_source.table.length === 0 ? 2 : 1;
            }
            this.changeShowRadio([false, false, true, false]);
          }  else if (n === FIELD_DISPLAY_TYPE.多行文本) {
            // this.fieldForm.is_search_field = 0;
            this.changeShowRadio([false, false, true, false]);
            this.mapSelectShowType = 0;
          } else if (n === FIELD_DISPLAY_TYPE.富文本) {
            console.log('富文本')
            this.fieldForm.is_search_field = 0;
            this.fieldForm.is_display_column = 0;
            this.fieldForm.is_must = 0;
            this.$nextTick(()=>{
              this.changeShowRadio([true, false, true, false]);
            })
            this.mapSelectShowType = 0;
          } else if (n === this.FIELD_DISPLAY_TYPE.图片上传) {
            console.log('图片上传')
            this.fieldForm.is_search_field = 0;
            this.fieldForm.is_display_column = 0;
            // 编辑字段，选择图片上传，避免fieldProperty=null的情况
            if (
              !this.fieldForm.field_property ||
              !this.fieldForm.field_property.image_field_property ||
              !this.fieldForm.field_property.image_field_property.maximum
            ) {
              this.fieldForm.field_property = {
                defaultValue: "",
                image_field_property: {
                  maximum: 1,
                  upload_image_type: 0
                }
              };
            }

            this.changeShowRadio([true, true, true, false]);
            this.mapSelectShowType = 0;
          }else if (n === this.FIELD_DISPLAY_TYPE.文件上传) {
            this.fieldForm.is_search_field = 0;
            this.fieldForm.is_display_column = 0;
            // 编辑字段，选择图片上传，避免fieldProperty=null的情况
            if (
              !this.fieldForm.file_field_property 
              // !this.fieldForm.field_property.video_field_property 
              // !this.fieldForm.file_field_property.image_field_property.maximum
            ) {
              this.fieldForm.file_field_property = {
                defaultValue: "",
                image_field_property: {
                  maximum: 1,
                  // upload_image_type: 0
                }
              };
            }

            this.changeShowRadio([true, true, true, false]);
            this.mapSelectShowType = 0;
          }else if (n === this.FIELD_DISPLAY_TYPE.视频) {
            this.fieldForm.is_search_field = 0;
            this.fieldForm.is_display_column = 0;
            // 编辑字段，选择图片上传，避免fieldProperty=null的情况
            if (
              !this.fieldForm.video_field_property 
              // !this.fieldForm.field_property.video_field_property 
              // !this.fieldForm.file_field_property.image_field_property.maximum
            ) {
              this.fieldForm.video_field_property = {
                defaultValue: "",
                image_field_property: {
                  maximum: 1,
                  // upload_image_type: 0
                }
              };
            }

            this.changeShowRadio([true, true, true, false]);
            this.mapSelectShowType = 0;
          } else {
            this.mapSelectShowType = 0;
            const values =
              _isRelatedBusiness === 1
                ? [true, true, false, true]
                : [false, false, false, false];
            this.changeShowRadio(values);
          }
        } else {
          this.mapSelectShowType = 0;
          const values =
            _isRelatedBusiness === 1
              ? [true, true, false, true]
              : [false, false, false, false];
          this.changeShowRadio(values);
        }
      },
      immediate: true
    },
    // 监视是否关联业务
    "fieldForm.is_related_business": {
      handler: function(n, o) {
        if (n === 1) {
          if (this.fieldForm.is_title === 1) {
            msg.warning("字段已经被设置为标题，不能关联业务", "msg");
            this.fieldForm.is_related_business = 0;
            return false;
          }
          this.fieldForm.field_type = FIELD_DISPLAY_TYPE.单行文本;
          this.fieldForm.data_type = FIELD_DATA_TYPE.字符串;
          this.fieldForm.is_display_column = 0;
          this.fieldForm.is_search_field = 0;
          this.fieldForm.is_must = 0;
          this.changeShowRadio([true, true, false, true]);
        } else {
          this.changeShowRadio([false, false, false, false]);
        }

        if (this.fieldForm.is_title === 1) {
          this.fieldForm.is_must = 1;
          this.$nextTick(() => {
            this.ShowRadio.splice(3, 1, true);
          });
        }
      },
      immediate: true
    }
  },
  created() {
    // this.getOptions()
    this.getCategoryListFn();
  },
  methods: {
    async getCategoryListFn() {
      // let params = {
      //   page_index: 1,
      //   total: 1,
      //   page_size: 1000,
      //   sizeArray: [10, 20, 30, 50]
      // };
      // const { data } = await getCategoryList(params);
      const { data } = await this.$pacsApi.pacsApi.getEnum({
        enumType: 'SystemDictionaryType'
      })
      this.categoryList = data || [];
    },
    switchChange(val, index) {
      if (val){
        this.fieldForm.dictionary_item_list.forEach((item, i) => {
          if (i !== index) {
            item.is_default = 0;
          }
        })
      }
    },
    spanfilter(span) {
      return span * 2;
    },
    changeShowRadio(values) {
      this.$nextTick(() => {
        // this.$set(this.ShowRadio, index, value)
        // this.ShowRadio.splice(index, 1, value)
        this.ShowRadio = values;
      });
    },
    // 选项表格选中行
    dictRowClick(nRow, oRow) {
      if (nRow != null) {
        this.DicTemp = Object.assign({}, nRow);
      }
    },
    // 新增下拉选项
    handleAddDict() {
      if (this.fieldForm.data_type === -1) {
        msg.warning("请先选择数据类型！", "msg");
        return false;
      }
      const temp = {
        id: "",
        dict_key: "",
        dict_value: "",
        sort_index: 0,
        show: true,
        is_default:0,
      };
      if (this.fieldForm.dictionary_item_list === null) {
        this.fieldForm.dictionary_item_list = [];
      }
      this.fieldForm.dictionary_item_list.push(temp);
    },
    // 取消下拉选项
    handleCancelDict(row, index) {
      if (row.id === "") this.fieldForm.dictionary_item_list.splice(index, 1);
      // 新增取消
      else {
        this.DicTemp.show = false;
        this.$set(this.fieldForm.dictionary_item_list, index, this.DicTemp); // 编辑取消
      }
    },
    // 编辑下拉选项
    handleEditDict(row, index) {
      this.DicTemp = Object.assign({}, row);
      row.show = true;
      this.$set(this.fieldForm.dictionary_item_list, index, row);
    },
    // 保存下拉选项
    handleSaveDict(row, index) {
      // 修改后保存
      this.$refs["fieldForm"].validate(valid => {
        if (valid) {
          row.show = false;
          this.$set(this.fieldForm.dictionary_item_list, index, row);
        } else {
          // msg.warning('验证未通过', 'msg')
          return false;
        }
      });
    },
    // 删除下拉选项
    handleDeleteDict(row, index) {
      this.$confirm("此操作将删除此下拉选项, 是否继续?", "提示", {
         customClass: 'confirm-dialog--ew',
        type: "warning"
      }).then(() => {
        const index1 = this.fieldForm.dictionary_item_list.indexOf(row);
        this.fieldForm.dictionary_item_list.splice(index1, 1);
        msg.ok("删除选项成功", "msg");
      });
    },
    valid(type) {
      this.$refs["fieldForm"].validate(valid => {
        if (valid) {
          if (this.fieldForm.field_type === this.FIELD_DISPLAY_TYPE.图片上传) {
            if (
              this.fieldForm.field_property.image_field_property
                .upload_image_type === 0
            ) {
              this.fieldForm.field_property.image_field_property.maximum = 1;
            }
          } else this.fieldForm.field_property.image_field_property = null;

          if (!this.fieldForm.field_property.tip_message)
            this.fieldForm.field_property.tip_message = `请${
              this.fieldForm.field_type < 2 ? "输入" : "选择"
            }${this.fieldForm.field_name}`;

          if (
            this.fieldForm.field_type === this.FIELD_DISPLAY_TYPE.下拉框 &&
            this.fieldForm.data_type === this.FIELD_DATA_TYPE.小数 &&
            this.mapSelectShowType === 2
          ) {
            this.fieldForm.dictionary_item_list = this.fieldForm.dictionary_item_list.map(
              x => {
                const temp = Object.assign({}, x);
                temp.dict_value = Number.parseFloat(x.dict_value).toFixed(
                  this.fieldForm.scale
                );
                return temp;
              }
            );
          }
          if(this.mapSelectShowType !== 3){
            delete this.fieldForm.field_property.system_dic_code;
          }else{
            //清空自定义的选项
            this.fieldForm.dictionary_item_list = [];
            if(!this.fieldForm.field_property.system_dic_code){
              msg.warning('请选择绑定的数据字典', 'msg');
              return;
            }
          }
          //设置默认占用宽度
          if (
            this.fieldForm.field_type == FIELD_DISPLAY_TYPE.多行文本 ||
            this.fieldForm.field_type == FIELD_DISPLAY_TYPE.图片上传 ||
            this.fieldForm.field_type == FIELD_DISPLAY_TYPE.文件上传 ||
            this.fieldForm.field_type == FIELD_DISPLAY_TYPE.文本域 ||
            this.fieldForm.field_type == FIELD_DISPLAY_TYPE.富文本 ||
            this.fieldForm.field_type == FIELD_DISPLAY_TYPE.视频
          ) {
            this.fieldForm.page_proportion = 0;
          }

          this.$emit("handleSaveField", this.fieldForm,type);
        } else {
          // msg.warning('验证未通过', 'msg')
          return false;
        }
      });
    },
    clearValidate() {
      this.$refs["fieldForm"].clearValidate();
    },
    resetForm() {
      this.$refs["fieldForm"].resetFields();
    },
    getOptions() {
      // 初始化数据源
      if (this.tableSource.length === 0) {
        FieldSourceTableList().then(res => {
          if (res.code === 0) {
            this.tableSource = res.data;
          }
        });
      }
    },
    // 选择数据源之后，加载列名
    handleTableFieldList(val) {
      if (val) {
        FieldSourceFieldList(val).then(res => {
          if (res.code === 0) {
            this.tableFieldList = res.data;
            if (
              !this.tableFieldList.some(
                x => x.name === this.fieldForm.bind_source.key_field
              )
            ) {
              this.fieldForm.bind_source.key_field = "";
            }

            if (
              !this.tableFieldList.some(
                x => x.name === this.fieldForm.bind_source.value_field
              )
            ) {
              this.fieldForm.bind_source.value_field = "";
            }
          }
        });
      } else {
        this.tableFieldList = [];
        this.fieldForm.bind_source.key_field = "";
        this.fieldForm.bind_source.value_field = "";
      }
    },
    // 数据源选择值
    handleBindSourceValueChange(val) {
      const bindField = this.tableFieldList.find(x => x.name === val);
      if (!bindField) return false;

      this.fieldForm.data_type = bindField.columnDataType;
      this.fieldForm.length = bindField.length;
      this.fieldForm.scale = bindField.scale;
    },
    keepTwo(value) {
      // 截取当前数据到小数点后三位
      const tempVal = Number(value).toFixed(this.fieldForm.scale + 1);
      if (tempVal === "NaN") {
        return "0.00";
      }
      const realVal = tempVal.substring(0, tempVal.length - 1);
      return realVal;
    }
  },
  filters: {
    // keepTwo(value) {
    //   // 截取当前数据到小数点后三位
    //   const tempVal = Number(value).toFixed(3)
    //   if (tempVal === 'NaN') {
    //     return '0.00'
    //   }
    //   const realVal = tempVal.substring(0, tempVal.length - 1)
    //   return realVal
    // },
  }
};
</script>

<style lang="scss" scoped>
::v-deep .cell {
  .el-form-item__content {
    margin-left: 0 !important;
  }
}
.ordinalTip{
  color: #e6a23c;
  margin-left: 5px;
  font-size: 16px;
  position: absolute;
  left: -95px;
  top: 8px;
}
.fieldTable{
  ::v-deep .el-form-item--small.el-form-item{
    margin-bottom: 0px;
  }
}
</style>
