<template>
  <div>
    <slot></slot>
    <el-button  :type="isBtn?'primary':'text'" :disabled="btnDisabled" size="mini" @click="dialogVisible = true">{{btnNameMap.btnName}}</el-button>
    <el-dialog
      v-el-drag-dialog
      :visible="dialogVisible"
      width="500px"
      :close-on-click-modal="false"
      title="撤回确认"
      @close="close"
      append-to-body
    >
      <div>{{btnNameMap.tipMsg}}</div>
      <div slot="footer" class="dialog-footer" style="text-align:right">
        <el-button size="small" @click="close">取 消</el-button>
        <el-button size="small" type="primary" @click="dealworkflowformFn">{{btnNameMap.dialogName1}}</el-button>
        <el-button size="small" type="primary" @click="dealworkflowformFn(1)">{{btnNameMap.dialogName2}}</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {dealworkflowform} from "@/api/workflow";
export default {
  props:{
    dealStatus:{
      type:Number,
      require:true,
    },
    flowform:{
      type:Object,
      require:true,
    },
    btnDisabled:{
      type:Boolean,
      require:false,
      default:false,
    },
    isBtn:{
      type:Boolean,
      require:false,
      default:false,
    },
  },
  computed:{
    btnNameMap(){
      let nameMap={}
      switch (this.dealStatus) {
        case 5:
          nameMap.btnName = '撤销'
          nameMap.dialogName1 = '撤销'
          nameMap.dialogName2 = '撤销并编辑'
          nameMap.tipMsg =`确认撤销提交“${this.flowform.business_sub_type_name}”记录?`
          break;
        case 6:
          nameMap.btnName = '撤销'
          nameMap.dialogName1 = '撤销'
          nameMap.dialogName2 = '撤销并重审'
          nameMap.tipMsg =`确认撤销“${this.flowform.business_sub_type_name}”处理?`
          break;
      
        default:
          break;
      }
      return nameMap
    },
  },
  data(){
    return{
      dialogVisible:false,
    }
  },
  methods:{
    close(){
      this.dialogVisible = false
    },
    async dealworkflowformFn(type){
      const params = {
        form_id: this.flowform.id, 
        workflow_id: this.flowform.workflow_id, 
        business_data_id: this.flowform.business_data_id, 
        step_result:this.dealStatus
      };
      const { code, data, msg } = await dealworkflowform(params);
      if (code === 0) {
        this.$message.success("处理成功")
        if(type === 1){
          this.$emit("toEdit",this.flowform)
        }else{
          this.$emit("updateList")
        }
        this.close()
      } else {
        this.$message({
          message: msg,
          type: "error",
        });
      }
    }
  }
}
</script>

<style>

</style>