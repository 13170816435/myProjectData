<template>
  <div class="contentMain" v-loading="listLoading">
    <div v-show="openLeftTree" class="LedgerMenu">
      <div class="row">
        <el-select class="mr10" v-model="searchForm.is_enabled" @change="searchList" style="width:80px" placeholder="请选择">
          <el-option v-for="item in statusList" :key="item.value" :label="item.label" :value="item.value"> </el-option>
        </el-select>
        <el-input class="flex_1" v-model="filterText"  placeholder="按名称查找"  clearable />
        <el-dropdown class="ml10"  trigger="click">
          <span v-show="!viewMode" class="el-dropdown-link">
            <i title="新建档案/文件夹" class="addBtm el-icon-plus"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item @click.native="addItem(null,0)">新增档案</el-dropdown-item>
            <el-dropdown-item @click.native="addItem(null,1)">新增文件夹</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
      <div class="menuContent">
        <el-tree
          ref="menuTree"
          :data="treeList"
          node-key="id"
          default-expand-all
          :props="{ label: 'name' }"
          @node-click="handleNodeClick"
          :expand-on-click-node='false'
          draggable
          :allow-drop="allowDrop"
          :allow-drag="allowDrag"
           @node-drag-start="handleDragStart"
           @node-drag-end="handleDragEnd"
          :filter-node-method="filterNode"
          >
          <span class="custom-tree-node" slot-scope="{ node, data }">
            <template v-if="!data.is_folder">
              <span :id="data.id" v-if="data.is_enabled" :title="node.label" class="nodeTitle"><i class="mr5 el-icon-my-fileIcon"></i>{{ node.label}}</span>
              <span :id="data.id" v-else :title="node.label" class="nodeTitle unableTitle"><i class="mr5 el-icon-my-stopIcon"></i>{{ node.label}}</span>
            </template>
              <span :id="data.id" v-else :title="node.label" class="nodeTitle">
                <i class="mr5 el-icon-folder"></i>{{ node.label}} 
                <i class="el-icon-my-knowledge" v-if="isLockedFn(data)"></i> 
              </span>
            <!-- 有管理权限 或者 个人分类 或者 是管理人员 -->
            <span v-if="(isAllowManage||data.user_type === 1 || (data.admin_user_ids&&data.admin_user_ids.includes(userId)))" @click.prevent.stop>
              <el-dropdown trigger="click">
                <span v-show="!viewMode" class="el-dropdown-link">
                  <i class="el-icon-more moreIcon"></i>
                </span>
                <el-dropdown-menu slot="dropdown">
                  <template v-if="data.is_folder">
                    <el-dropdown-item @click.native="addItem(data,0)">新增档案</el-dropdown-item>
                    <el-dropdown-item @click.native="addItem(data,1)">新增文件夹</el-dropdown-item>
                  </template>
                  <template v-if="!['0_0','0_1'].includes(data.id) ">
                    <el-dropdown-item @click.native="moveNodeUp(node)"> 上移一行</el-dropdown-item>
                    <el-dropdown-item @click.native="moveNodeDown(node)">下移一行</el-dropdown-item>
                    <el-dropdown-item v-if="!isLockedFn(data)" @click.native="moveTo(data)">移动到</el-dropdown-item>
                    <template v-if="!data.is_folder">
                      <el-dropdown-item v-if="!data.is_enabled" @click.native="ChangeCommonStatus(1,data)" >启用</el-dropdown-item>
                      <el-dropdown-item v-else @click.native="ChangeCommonStatus(0,data)">停用</el-dropdown-item>
                    </template>
                    <!-- 知识库不允许编辑删除 以及移动到其他子目录  同级上下移动排序可以 -->
                    <template v-if="!isLockedFn(data)">
                      <el-dropdown-item @click.native="renameItem(node,data)">重命名</el-dropdown-item>
                      <el-dropdown-item @click.native="delItem(data)">删除</el-dropdown-item>
                    </template>
                  </template>
                </el-dropdown-menu>
              </el-dropdown>
            </span>
          </span>
        </el-tree>
      </div>
    </div>
    <div class="LedgerContent">
      <template v-if="activeNode">
      <div :class="viewMode?'mb10':''" class="row f14">
        <i @click="openLeftTree = !openLeftTree" class="cursor mr10 f18" :class="openLeftTree?'el-icon-s-fold':'el-icon-s-unfold'"></i>
        <!-- 个人分类不限制 -->
        <!-- <el-switch class="mr10" v-if="!activeNode.is_folder && (isAllowManage || currentUserType===1)"
          v-model="activeNode.is_enabled"
          :active-value="1" size='mini'
          :inactive-value="0"
          @change="(type)=>{ChangeCommonStatus(type,activeNode)}" /> -->
        <span class="noteTitle mr20">{{activeNode.name}}</span>
        <span v-if="currentUserType === 0 && !activeNode.is_folder " :title="activeNode.admin_user_names" class="mr20 clr_909"><i class="el-icon-my-admin mr5"></i>负责人：{{activeNode.admin_user_names?activeNode.admin_user_names:'无'}}</span>
        <span :title="activeNode.description" class="mr10 nodeRemake clr_909"><i class="el-icon-my-remark mr5"></i>备注：{{activeNode.description?activeNode.description:'无'}}</span>
      </div>
      <el-tabs 
        v-if="!viewMode"
        v-model="activeName"
        @tab-click="changeActive">
        <el-tab-pane key="tabs_0" label="发布记录" name="0">
        </el-tab-pane>
        <el-tab-pane key="tabs_1" v-if="currentUserType === 0 && this.activeNode.sub_business_type !== 'EquipmentManage'" name="1">
          <span slot="label">审批中心<el-badge class="countBadge" v-if="waitCount>0" :value="waitCount" ></el-badge></span>
        </el-tab-pane>
        <el-tab-pane key="tabs_2" v-if="currentUserType === 0 && !activeNode.is_folder" label="发布统计" name="2">
        </el-tab-pane>
        <el-tab-pane key="tabs_3" v-if="isAllowSetting" label="基础设置" name="3">
        </el-tab-pane>
        <el-tab-pane key="tabs_4" v-if="isAllowAdminSetting" label="权限设置" name="4">
        </el-tab-pane>
      </el-tabs>
      <div class="LedgerContentMain">
        <!-- 如果当前为档案并且没有设置模板 并且当前tab为列表 审批 统计 显示空页面 -->
        <template v-if="['0','1','2'].includes(activeName)">
          <div v-if="!activeNode.is_folder && !activeNode.template_id " class="emptyImg flex_1">
            <div>
                <img src="@/assets/images/common/NoData.png"/>
                <div class="emptyImg_text" >当前分类无模板信息，请在上方选择【基础设置】标签进行设置。若没有标签，请联系管理员。</div> 
            </div>
          </div>
          <template v-else>
            <LedgerListItem ref="LedgerListItem" v-if="activeName ==='0'" :isActiveAdminUser='isActiveAdminUser' 
            :categoryChildren='activeNode.children?activeNode.children:[]' @updateCount='updateCount' :categoryObj='activeNode' 
            :defultDeviceId='defultDeviceId' :defultDeviceReportDate='defultDeviceReportDate' ></LedgerListItem>
            <LedgerTodoListItem ref="LedgerTodoListItem" v-if="activeName ==='1'" :categoryObj='activeNode' @updateCount='updateCount' ></LedgerTodoListItem>
            <LedgerStatReportItem ref="LedgerStatReportItem" v-if="activeName ==='2'" :isActiveAdminUser='isActiveAdminUser' :categoryObj='activeNode' ></LedgerStatReportItem>
          </template>
        </template>
        <template v-if="activeName ==='3'" >
          <LedgerSettingItem :parentId='parentId' ref="LedgerSettingItem" v-if="!activeNode.is_folder" :isActiveAdminUser='isActiveAdminUser' @updateTree='updatePage' :categoryObj='activeNode' ></LedgerSettingItem>
          <LedgerSettingFolderItem :parentId='parentId' ref="LedgerSettingFolderItem" v-else :categoryObj='activeNode' @updateTree='updatePage' ></LedgerSettingFolderItem>
        </template>
        <LedgerAdminSetItem ref="LedgerAdminSetItem" v-if="activeName ==='4'" @updateTree='updatePage' :categoryId='activeNode.id' ></LedgerAdminSetItem>
        
      </div>
      </template>
      <template v-else>
        <div class="tc emptyImg">
          <img  src="@/assets/images/common/NoData.png"/>
          <div class="emptyImg_text" >没有档案，请联系管理员。</div> 
        </div>
      </template>
    </div>

    <addLedgerOrFileDialog @addUpdate='addUpdate'  @closeDialog='isShowAddLedgerOrFileDialog = false' 
      :addType='addType' :addDefaultPath='addDefaultPath' :parentId='parentId'
      v-if="isShowAddLedgerOrFileDialog"></addLedgerOrFileDialog>
    <LedgerMoveToDialog :parentId='parentId' @closeDialog='isShowLedgerMoveToDialog = false' @updatePage='updatePage' :dealNode='currentNode' v-if="isShowLedgerMoveToDialog"></LedgerMoveToDialog>
    <LedgerDelFolderDialog :parentId='parentId' @closeDialog='isShowLedgerDelFolderDialog = false' @updatePage='updatePage' :delFolder='currentDealItem' v-if="isShowLedgerDelFolderDialog"></LedgerDelFolderDialog>
    <LedgerRenameDialog @closeDialog='isShowLedgerRenameDialog = false' @submit='updatePage' :dealItem='currentDealItem' v-if="isShowLedgerRenameDialog"></LedgerRenameDialog>
  </div>
</template>

<script>
import { getLedgerCategoryTree ,categoryEnabledUpdate,saveCategoryMove,
  categorySortIndexUpdate,saveCategoryDel} from '@/api/anymark/markcategory'
import LedgerListItem from '@/views/LedgerManage/components/LedgerListItem'
import LedgerAdminSetItem from '@/views/LedgerManage/components/LedgerAdminSetItem'
import LedgerStatReportItem from '@/views/LedgerManage/components/LedgerStatReportItem'
import LedgerTodoListItem from '@/views/LedgerManage/components/LedgerTodoListItem'
import addLedgerOrFileDialog from '@/views/LedgerManage/components/addLedgerOrFileDialog'
import LedgerMoveToDialog from '@/views/LedgerManage/components/LedgerMoveToDialog'
import LedgerDelFolderDialog from '@/views/LedgerManage/components/LedgerDelFolderDialog'
import LedgerRenameDialog from '@/views/LedgerManage/components/LedgerRenameDialog'
import LedgerSettingItem from '@/views/LedgerManage/components/LedgerSettingItem'
import LedgerSettingFolderItem from '@/views/LedgerManage/components/LedgerSettingFolderItem'
import {getWorkflowFormPageList,getWorkflowFormCount,dealworkflowform} from "@/api/workflow";

export default {
  components:{
    LedgerListItem,LedgerAdminSetItem,LedgerStatReportItem,LedgerMoveToDialog,LedgerSettingItem,
    LedgerTodoListItem,addLedgerOrFileDialog,LedgerDelFolderDialog,LedgerRenameDialog,LedgerSettingFolderItem,
  },
  props:{
    isShowLeftTree:{
      type: Boolean,
      require:false,
      default:true
    },
    defultLedgerId:{
      type:String,
      require:false,
      default:''
    },
    parentId:{
      type:String,
      require:false,
      default:''
    },
    deviceId:{//选项中默认选中的设备id
      type:String,
      require:false,
      default:''
    },
    deviceReportDate:{//选项中默认选中的报告填写时间
      type:String,
      require:false,
      default:''
    },
    viewMode:{//只查看模式 不允许新增 编辑 移动树  不显示tab
      type: Boolean,
      require:false,
      default:false
    },

  },
  data(){
    return{
      openLeftTree:true,
      searchForm:{
        is_enabled:-1,
      },
      filterText:'',
      statusList:[{value:-1,label:'全部'},{value:1,label:'启用'},{value:0,label:'停用'},],
      listLoading:false,
      treeList:[],
      activeNode:{},
      activeName:'0',
      waitCount:0,
      originalTree:[],
      addType:0,
      addDefaultPath:[],
      isShowAddLedgerOrFileDialog:false,
      isShowLedgerMoveToDialog:false,
      isShowLedgerDelFolderDialog:false,
      isShowLedgerRenameDialog:false,
      currentDealItem:null,
      currentNode:[],
      currentUserType:'',//当前的类型是科室还是个人 科室个人右侧显示tab不同 所以如果切换 默认要跳到第一个tab
      userId:'',

      LedgerId:'',//通知进入档案管理 默认选中档案与审批id
      contentId:'',
      openType:'',//打开发布记录 还是 审批中心
    }
  },
  computed:{
    //设置默认的 设备id 与填报时间 主要为公用页面 新增页面进入 公用列表页面 需要默认选中设备id与填报时间
    defultDeviceId(){
      if(this.defultLedgerId ===  this.activeNode.id){
        return this.deviceId
      }else{
        return ''
      }
    },
    defultDeviceReportDate(){
      if(this.defultLedgerId ===  this.activeNode.id){
        return this.deviceReportDate
      }else{
        return ''
      }
    },
    isAllowAdminSetting(){
      if(this.activeNode.is_folder || this.currentUserType === 1){//文件夹 或者 个人分类 没有权限设置
        return false
      }else if(this.isAllowManage || this.isActiveAdminUser){//有ssj管理权限 或者是负责人 就显示权限设置  
        return true
      }else{
        //模板 需要查看档案权限中是否有管理权限
        return this.activeNode.permissions?this.activeNode.permissions.includes(16):false
      }
    },
    isAllowSetting(){
      //最上级 科室档案 个人分类不显示基础设置页面
      if(['0_0','0_1'].includes(this.activeNode.id)){
        return false
        //知识库不允许编辑
      }else if( this.isLockedFn(this.activeNode) ){
        return false
      }else if(this.currentUserType === 1){//个人分类不做限制
        return true
      }else if(this.isAllowManage || this.isActiveAdminUser){//文件夹只有 有ssj管理权限 或者是负责人才显示基础设置  
        return true
      }else{
        if(this.activeNode.is_folder){ 
          return false
        }else{
          //模板 需要查看档案权限中是否有管理权限
          return this.activeNode.permissions?this.activeNode.permissions.includes(16):false
        }
      }
    },
    isAllowManage(){
      //是否允许管理分类文件夹 新增 移动 重命名 启用停用等
      return this.$prm_codes.includes('ssj_ml_gl')
    },
    isActiveAdminUser(){//是否为当前选中项的负责人
      return this.activeNode.admin_user_ids && this.activeNode.admin_user_ids.includes(this.userId)
    },
    flatTreeList(){//拍平的树列表
      return this.flatData(this.treeList);
    },
  },
  watch: {
    filterText(val) {
      this.$refs.menuTree.filter(val);
    },
  },
  created(){
    this.openLeftTree = this.isShowLeftTree
    // let loginInfo = localStorage.getItem("loginInfo");//1
    let loginInfo =  this.$loginInfo;
    if (loginInfo) {
      loginInfo = JSON.parse(loginInfo);
      this.userId = loginInfo.profile.sub;
    }
    const {LedgerId,id,type} = this.$route.query
    if(LedgerId && id){
      this.LedgerId = LedgerId
      this.contentId = id
      this.openType = type
      this.fetchList(2);
    }else{
      this.searchList()
    }
  },
  methods:{
    isLockedFn(item){//判断是否锁定 设备管理 知识库 锁定不允许拖动
      if( ['KnowledgeBase','EquipmentManage'].includes(item.sub_business_type) && item.parent_id ==='0'){
        return true
      }else{
        return false
      }

    },
    moveTo(data){
      this.currentNode = data
      this.isShowLedgerMoveToDialog = true
    },
    async searchList(){
      await this.fetchList(0);
      // this.getWorkflowFormCountFn();
    },
     filterNode(value, data) {
      if (!value) return true;
      return data.name.indexOf(value) !== -1;
    },
    async addUpdate(val,type){
      //直接定位到新增的文件夹档案
      this.activeNode = val;
      await this.fetchList(1);
      if(type !== 1){
        this.isShowAddLedgerOrFileDialog = false
      }
      this.getWorkflowFormCountFn();
    },
    async updatePage(){
      this.isShowLedgerRenameDialog = false
      this.isShowLedgerMoveToDialog = false
      this.isShowLedgerDelFolderDialog = false
      this.isShowAddLedgerOrFileDialog = false
      await this.fetchList(1);
      // this.getWorkflowFormCountFn();
    },
    renameItem(node,data){
      this.currentDealItem = data;
      this.isShowLedgerRenameDialog = true
    },
    async delItem(val){
      if(!val.is_folder){
        try {
          await this.$confirm(`确认要删除 “${val.name}” 档案？<p class="clr_red">删除后所有档案记录将无法召回</p>`, '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            dangerouslyUseHTMLString: true,
            customClass: 'confirm-dialog--ew',
            type: 'warning'
          });
        } catch (error) {
          return;
        }
        //删除接口
        const params={
          id:val.id
        }
        const { code,data,msg } = await saveCategoryDel(params)
        if (code === 0) {
           this.$message.success('删除成功');
           this.updatePage();
        }else{
          this.$message.error(msg);
        }
      }else{
        this.currentDealItem = val
        this.isShowLedgerDelFolderDialog = true
      }
    },
    // 设置常用
    async ChangeCommonStatus(type,tempData) {
      try {
        await this.$confirm(`是否${ type?'启用':'禁用'}【${tempData.name}】?`, "提醒",{customClass: 'confirm-dialog--ew',});
      } catch (error) {
        tempData.is_enabled = type?0:1
        return;
      }
      const params={
        id:tempData.id,
        is_enabled : type,//是否启用
      }
      categoryEnabledUpdate(params).then((res) => {
        const {code,msg} = res;
        if(code === 0){
          if(tempData.id === this.activeNode.id){
            this.activeNode.is_enabled = type
          }
          tempData.is_enabled = type;
          this.$message.success('修改成功')
        }else{
          this.$message.warning(msg)
        }
        
      })
    },
    addItem(row, type){
      this.addType = type
      if(row){
        if(row.path){
          let path = row.path.split('/')
          path = path.map(item=>{ 
            if(item === '0'){
              item = `0_${row.user_type}`
            }
            return item
          })
          this.addDefaultPath = path
        }else{
          this.addDefaultPath = [`0_${row.user_type}`]
        }
      }else{
        const currentRow = this.activeNode
        //如果当前选中的为文件夹 则将选中的文件夹路径带入
        if(currentRow && currentRow.is_folder){
          //如果当前选中的是公共文件夹 并且 没有管理权限 路径为空
          if(currentRow.user_type === 0 && !this.isAllowManage){
            this.addDefaultPath = []
          }else{
            if(currentRow.path){
              let path = currentRow.path.split('/')
              path = path.map(item=>{ 
                if(item === '0'){
                  item = `0_${currentRow.user_type}`
                }
                return item
              })
              this.addDefaultPath = path
            }else{
              this.addDefaultPath = [`0_${currentRow.user_type}`]
            }
          }
        }else{
          this.addDefaultPath = []
        }
      }
      this.isShowAddLedgerOrFileDialog = true;
    },
    handleDragStart(node) {
      // 保存拖动前的树的副本，用于恢复树的状态
      this.originalTree = JSON.parse(JSON.stringify(this.treeList));
    },
    async handleDragEnd(draggingNode, dropNode, dropType, ev) {
      if(dropType === 'none'){
        return
      }
      // 计算整个树的最大层级
      const maxTreeLevel = this.calculateMaxTreeLevel(this.treeList);
      console.log(maxTreeLevel)
      if (maxTreeLevel > 4) {
        this.$message.warning('拖动操作超过 4 级层级限制');
        // 还原树的状态为拖动前的状态
        this.treeList = JSON.parse(JSON.stringify(this.originalTree));
      } else {
        // 执行实际的拖动操作 请求接口 根据dropType 判断放入位置
         //移动提交接口
         if(draggingNode.data.id === dropNode.data.id){
           return
         }
        console.log(dropType,'draggingNode',draggingNode,draggingNode.data.name,'dropNode',dropNode,dropNode.data.name)
        const params={
          id: draggingNode.data.id,
        }
        if(dropType === 'inner'){
          params.target_id = dropNode.data.id
        }else{
          params.target_id = dropNode.data.parent_id
        }
        const { code,data,msg } = await saveCategoryMove(params)
        if (code === 0) {
          //同时排序 先获取父类id 再获取移动后的children列表顺序 保存排序
          let pId = params.target_id
          if( pId=== '0'){//如果为最顶部 通过user_type判断当前是哪个分类
            pId = `0_${dropNode.data.user_type}`
          }
          const pNode = this.flatTreeList.find(item=>{ return item.id === pId})
          const childrenList = pNode.children.map(item=>{return item.id})
          this.categorySortIndexUpdateFn(childrenList,draggingNode.data)
        }else{
          this.$message.error(msg);
        }
      }
    },
    async categorySortIndexUpdateFn(list,draggingNode){
      const { code,data,msg } = await categorySortIndexUpdate(list)
      if (code === 0) {
        this.updatePage()
        this.$message.success('排序成功')
        //同时如果当前是在设置tab 需要更新 设置页面中的所在目录接口
        if(this.activeName ==='3'){
          if(this.activeNode.is_folder){
             //如果被移动的正好是当前显示的节点 则刷新内容
            if(draggingNode.id === this.activeNode.id){
              this.$refs.LedgerSettingFolderItem.fetchList()
              this.$refs.LedgerSettingFolderItem.ResetData();
              this.$refs.LedgerSettingFolderItem.getDetailFn()
            }
          }else{
            //如果被移动的正好是当前显示的节点 则刷新内容
            if(draggingNode.id === this.activeNode.id){
              this.$refs.LedgerSettingItem.fetchList()
              this.$refs.LedgerSettingItem.ResetData()
              this.$refs.LedgerSettingItem.fetchCategory(this.activeNode.id)
            }
          }
        }
      }else{
        this.$message.error(msg);
      }
    },
    calculateMaxTreeLevel(nodes) {
      // 递归计算整个树的最大层级
      let maxLevel = 0;
      for (const node of nodes) {
        const level = this.calculateNodeLevel(node);
        maxLevel = Math.max(maxLevel, level);
      }
      return maxLevel;
    },
    calculateNodeLevel(node, currentLevel = 1) {
      // 递归计算单个节点的层级
      if (node.children && node.children.length > 0) {
        let maxChildLevel = currentLevel;
        for (const child of node.children) {
          const childLevel = this.calculateNodeLevel(child, currentLevel + 1);
          maxChildLevel = Math.max(maxChildLevel, childLevel);
        }
        return maxChildLevel;
      } else {
        return currentLevel;
      }
    },
    updateCount(val){
      this.waitCount = val
    },
    async getWorkflowFormCountFn(){
      const params={
        business_sub_type_path:this.activeNode.path,
        business_type : 10
      }
      const { code, data, msg } = await getWorkflowFormCount(params);
      if (code === 0) {
        const {wait_approved , i_start_item} = data;
        //待审批数量
        this.waitCount =wait_approved;
      } else {
        this.$message({
          message: msg,
          type: "error",
        });
      }
    },
    handleNodeClick(data){
      if(data.id === this.activeNode.id){
        return
      }
      
      this.activeNode = data
      
      if(data.user_type !== this.currentUserType){
        this.activeName = '0'
        this.currentUserType = data.user_type
      }else{
        if(this.isAllowManage){
          //如果当前为分类 并且没有模板id 则默认跳到档案设置 并且只有档案设置tab可以点击
          if(!data.is_folder && !data.template_id && !this.viewMode){
            this.activeName = '3'
          }
          //如果当前为文件夹 并且tab在 统计报表或者权限页面 则将tab跳到第一个
          if(data.is_folder && ['2','4'].includes(this.activeName)){
            this.activeName = '0'
          }
        }else{
          if(data.user_type === 1){
            //个人分类不改变tab因为 个人分类显示的tab是固定的 
          }else{
            this.activeName = '0'
          }
        }
      }
      //如果为最顶层 科室档案跟 个人档案 默认直接跳第一个tab
      if(['0_0','0_1'].includes(data.id)){
        this.activeName = '0'
      }
      //知识库文件夹单独出来  因为不能编辑删除 所以直接跳到第一个tab
      if(data.is_folder && this.isLockedFn(data) ){
        this.activeName = '0'
      }
      //设备管理 没有审批 所以 如果当前为审批模块 切换到设备管理 默认跳到列表页
      if(this.activeNode.sub_business_type === 'EquipmentManage' && this.activeName === '1'){
        this.activeName = '0'
      }
      // this.getWorkflowFormCountFn();
    },
    changeActive(){
      
    },
    moveNodeUp(node) {
      const parentChildren = this.getParentChildren(node);
      const index = parentChildren.indexOf(node.data);
      if (index > 0) {
        this.swapNodes(parentChildren, index, index - 1);
      } else {
        this.showMoveLimitMessage('up');
      }
    },
    moveNodeDown(node) {
      const parentChildren = this.getParentChildren(node);
      const index = parentChildren.indexOf(node.data);
      if (index < parentChildren.length - 1) {
        this.swapNodes(parentChildren, index, index + 1);
      } else {
        this.showMoveLimitMessage('down');
      }
    },
    swapNodes(list, index1, index2) {
      const temp = list[index1];
      this.$set(list, index1, list[index2]);
      this.$set(list, index2, temp);
      const childrenList = list.map(item=>{return item.id})
      this.categorySortIndexUpdateFn(childrenList)
    },
    getParentChildren(node) {
      const parentNode = this.getParentNode(node);
      return parentNode ? parentNode.children : this.treeList;
    },
    getParentNode(node) {
      if(node.parent){
        const currentId = node.parent.data.id
        return this.findItemById(this.treeList,currentId)
      }else{
        return null
      }
    },
    findItemById(list,targetId) {
      const that = this
      let matchItem = null
      list.forEach(item => {
        if (item.id === targetId) {
          matchItem = item
          return item;
        }
        if (item.children && item.children.length > 0) {
          const foundInChildren = that.findItemById(item.children, targetId);
          if (foundInChildren) {
            matchItem = foundInChildren
            return foundInChildren;
          }
        }
      }); 
      return matchItem;
    },
    showMoveLimitMessage(direction) {
      if (direction === 'up') {
        this.$message.warning('已经是第一个，无法继续上移');
      } else if (direction === 'down') {
        this.$message.warning('已经是最后一个，无法继续下移');
      }
    },
    allowDrop(draggingNode, dropNode, type) {
      //个人分类与科室分类不能相互拖拽
      if(draggingNode.data.user_type !== dropNode.data.user_type){
        return false
      }
      //不允许 设备管理内移出 跟 外部移入设备管理
      if(draggingNode.data.sub_business_type !== dropNode.data.sub_business_type || dropNode.data.name==='设备管理' ){
        return false
      }
      //不能放在第一级
      if(dropNode.level === 1){
        return false
      }else{
        //如果是放入的操作 判断当前放的分类是否存在模板 存在则不允许放入
        if(type === 'inner'){
          const currentNode = this.flatTreeList.filter(item=>{return item.id === dropNode.key})
          return currentNode[0].is_folder
        }else{
          return true
        }
      }
    },
    allowDrag(draggingNode, dropNode, type) {
      console.log(draggingNode.data.sub_business_type)
      if(this.viewMode){//查看模式不允许拖动
        return false
      }
      //第一级不允许拖动 知识库不允许拖动
      if(draggingNode.level === 1 || this.isLockedFn(draggingNode.data)){
        return false
      }else{
        //有权限 或者是个人分类才能拖拽
        return this.isAllowManage || draggingNode.data.user_type === 1
      }
    },
    //type:0 初次进入页面 默认选中第一个档案或文件夹  1刷新数据 选中不变
    //2 点击IM通知 进入科室档案 默认跳到对应档案 选中审批中心 打开对应详情
    async fetchList(type){
      const params={
        user_type:null,
      }
      if(this.searchForm.is_enabled !== -1){
        params.is_enabled = this.searchForm.is_enabled
      }
      if(this.parentId){
        params.parent_id = this.parentId
        params.exclude_virtual_root = true;//为true不显示 科室档案 个人档案这一级
      }
      this.listLoading = true
      const {code,data,msg} = await getLedgerCategoryTree(params)
      this.listLoading = false
      if(code === 0){
        if (data && data.length>0) {
          if(!this.parentId){//查询全部层级 需要特殊处理下第一级（科室档案 个人档案）的id
            data.forEach((item,index)=>{
              item.id = `0_${index}`
              item.is_folder = 1
            })
          }
          const dealData = this.setEmptyChildrenToUndefined(data)
          this.treeList=dealData
          if(type === 1){
            // 拍平的列表中找到对应的 节点是否存在 存在则更新选中节点信息为最新信息（有可能修改了 名称 负责 备注等信息）
            //没有则默认选中第一个 比如正好是删除当前节点
             const node = this.flatTreeList.find(item=>{return item.id ===this.activeNode.id })
            if(node){
              this.activeNode = node
            }else{
              this.activeName = '0'
              this.activeNode = dealData[0]
            }
          }else if(type === 2){
            //查找对应的档案 是否存在 不存在给出提示并默认选中第一个
            const node = this.flatTreeList.find(item=>{return item.id ===this.LedgerId })
            if(node){
              this.activeNode = node
              this.activeName = this.openType
              this.$nextTick(()=>{
                //展开对应的审批\档案详情
                if(this.openType === '0'){
                  this.$refs.LedgerListItem.currentAnymarkObj.templateId = node.template_id
                  this.$refs.LedgerListItem.currentAnymarkObj.contentId = this.contentId
                  this.$refs.LedgerListItem.isShowLedgerDetailDrawer = true
                }else if(this.openType === '1'){
                  const row = {id:this.contentId}
                  this.$refs.LedgerTodoListItem.handleViewerContent(row)
                }
              })
            }else{
              this.$message.warning('未找到对应科室档案，可能是您当前没有权限，请联选管理员')
              this.activeName = '0'
              this.activeNode = dealData[0]
            }
          }else{
            if(this.defultLedgerId){
              const node = this.flatTreeList.find(item=>{return item.id ===this.defultLedgerId })
              if(node){
                this.activeNode = node
              }else{
                this.activeName = '0'
                this.activeNode = dealData[0]
              }
            }else{
              this.activeNode = dealData[0]
            }
          }
          //记录当前类型
          this.currentUserType = this.activeNode.user_type
          //如果当前为分类 并且没有模板id 则默认跳到档案设置 并且只有档案设置tab可以点击
          if(!this.activeNode.is_folder && !this.activeNode.template_id && !this.viewMode){
            this.activeName = '3'
          }
          this.$nextTick(()=>{
            const tree = this.$refs.menuTree;
            //设置默认选中
            tree.setCurrentKey(this.activeNode.id)
            tree.filter(this.filterText);
            const el = document.getElementById(`${this.activeNode.id}`);
            if (el) {
              // 使用scrollIntoView方法滚动到节点的位置
              setTimeout(()=>{
                el.scrollIntoView({  block: 'center' });
              },500)
            }
          })
        }else{
          this.treeList=[]
          this.activeNode = null
        }
      }else{
        this.$message.warning(msg)
      }
       
    },
    setEmptyChildrenToUndefined(treeData) {
      const processedData = [...treeData]; // 复制一份以保留原数据
      for (const node of processedData) {
        if (node.children && node.children.length === 0) {
          node.children = undefined; // 将 children 为空数组的节点的 children 设置为 undefined
        } else if (node.children && node.children.length > 0) {
          node.children = this.setEmptyChildrenToUndefined(node.children); // 递归处理子节点并赋值给当前节点的 children
        }
      }
      return processedData; // 返回处理后的数据
    },
    flatData(data){
      return data.reduce((prev, curr) => {
        prev.push(curr);
        if (curr.children && curr.children.length > 0) {
          prev.push(...this.flatData(curr.children));
        }
        return prev;
      }, []);
    },
  }
}
</script>

<style lang="less" scoped>
.contentMain{
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  display: flex;
}
.LedgerMenu{
  border-right: 1px solid #DCDFE6;
  width: 280px;
  box-sizing: border-box;
  padding: 10px;
  // margin-right: 10px;
}
.LedgerContent{
  flex: 1;
  height: 100%;
  padding: 10px 10px 10px 10px;
  box-sizing: border-box;
  overflow: auto;
  display: flex;
  flex-direction: column;
  .LedgerContentMain{
    // height: calc(100% - 60px);
    flex: 1;
    overflow: auto;
  }
}
.addBtm{
  width: 32px;
  height: 32px;
  line-height: 32px;
  display: inline-block;
  text-align: center;
  background: #e4e4e4;
  cursor: pointer;
  border-radius: 4px;
}
.menuContent{
  margin-top: 10px ;
  height: calc(100% - 42px);
  overflow: auto;
}
 .custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
  overflow: hidden;
  .moreIcon{
    display: none;
  }
  &:hover{
    .moreIcon{
      display: block;
    }
  }
  .nodeTitle{
     flex: 1;
     overflow: hidden;
     text-overflow: ellipsis;
     white-space: nowrap;
     color: #303133;
  }
  .unableTitle{
    color: #909399;
  }
}
// ::v-deep .el-tabs__nav-scroll{
//   margin-top: -10px;
// }
// ::v-deep .el-tabs__nav-prev{
//     margin-top: -10px;
// }
// ::v-deep .el-tabs__nav-next{
//     margin-top: -10px;
// }
::v-deep .el-tree-node.is-current > .el-tree-node__content:first-child{
  background: #ECF5FF !important;
}
::v-deep .countBadge{
  vertical-align: sub;
}
.noteTitle{
  font-weight: bold;
  font-size: 15px;
  color: #303133;
}
.nodeRemake{
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.clr_909{
  color: #909399;
}
//修改滚动条样式
*::-webkit-scrollbar-track-piece {
  background-color: #f8f8f800;
}
*::-webkit-scrollbar {
  width: 6px;
  transition: all 2s;
}
*::-webkit-scrollbar-thumb {
  background-color: #dddddd;
  border-radius: 100px;
}
*::-webkit-scrollbar-thumb:hover {
  background-color: #bbb;
}
*::-webkit-scrollbar-corner {
  background-color: rgba(255, 255, 255, 0);
}
.el-icon-my-fileIcon{
  background: url(../../assets/images/common/fileIcon.png) center no-repeat;
  background-size: cover;
}
.el-icon-my-fileIcon:before{
  content: "\e611";
  font-size: 16px;
  visibility: hidden;
}
.el-icon-my-moreIcon{
  background: url(../../assets/images/common/moreIcon.png) center no-repeat;
  background-size: cover;
}
.el-icon-my-moreIcon:before{
  content: "\e611";
  font-size: 16px;
  visibility: hidden;
}
.el-icon-my-stopIcon{
  background: url(../../assets/images/common/stopIcon.png) center no-repeat;
  background-size: cover;
}
.el-icon-my-stopIcon:before{
  content: "\e611";
  font-size: 16px;
  visibility: hidden;
}
.emptyImg{
    text-align: center;
    margin-top: 150px;
    .emptyImg_text{
        margin-top: 15px;
        color: #909399;
    }
}
/deep/ .el-tree-node.is-drop-inner>.el-tree-node__content .nodeTitle{
  background-color: #CEE2EF !important;
  color: #fff;
}
/deep/ .el-tree-node:focus > .el-tree-node__content{
  background: #fff;
}
/deep/ .el-tree-node__content:hover {
  background: #ECF5FF !important;
}
.el-icon-my-knowledge{
  background: url(../../assets/images/common/knowledgeIcon.svg) center no-repeat;
  background-size: cover;
}
.el-icon-my-knowledge:before{
  content: "\e611";
  font-size: 12px;
  visibility: hidden;
}
/deep/ .el-tabs__item{
  font-weight: bold;
}
.el-icon-my-admin{
  background: url(../../assets/images/common/myAdminIcon.png) center no-repeat;
  background-size: cover;
}
.el-icon-my-admin:before{
  content: "\e611";
  font-size: 14px;
  visibility: hidden;
}
.el-icon-my-remark{
  background: url(../../assets/images/common/myRemarkIcon.png) center no-repeat;
  background-size: cover;
}
.el-icon-my-remark:before{
  content: "\e611";
  font-size: 14px;
  visibility: hidden;
}
/deep/ .filterForm {
  padding:0px !important;
}
</style>
