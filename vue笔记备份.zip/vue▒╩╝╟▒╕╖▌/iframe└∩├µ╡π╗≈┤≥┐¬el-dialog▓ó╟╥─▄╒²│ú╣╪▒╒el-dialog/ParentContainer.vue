
<template>
  <div class="iframe-wrapper">
    <iframe
      ref="iframe"
      src="./IframeContent.html"
      @load="initCommunication"
    ></iframe>
    <div id="global-dialog-root"></div>
  </div>
</template>

<script>
export default {
  methods: {
    initCommunication() {
      const iframe = this.$refs.iframe
      const checkReady = () => {
        if (iframe.contentWindow?.document.readyState === 'complete') {
          iframe.contentWindow.postMessage({
            type: 'SET_GLOBAL_CONTAINER',
            containerId: 'global-dialog-root'
          }, '*')
        } else {
          setTimeout(checkReady, 100)
        }
      }
      checkReady()
    }
  }
}
</script>

<style>
.iframe-wrapper {
  width: 500px;
  height: 500px;
  position: relative;
  border: 1px solid #dcdfe6;
}
#global-dialog-root {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 9999;
}
</style>
