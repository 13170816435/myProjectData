<template>
  <div v-show="visible">
    <el-dialog
      :visible.sync="visible"
      title="全局弹窗"
      width="1000px"
      :before-close="handleBeforeClose"
      :close-on-click-modal="false"
      :append-to-body="false"
    >
      <p>这是突破iframe限制的全局弹窗内容</p>
      <span slot="footer">
        <el-button @click="visible = false">取消</el-button>
        <el-button type="primary" @click="visible = false">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      visible: false,
      container: null
    }
  },
  methods: {
    open() {
      this.visible = true
      this.$nextTick(this.moveDialog)
    },
    setContainer(id) {
      this.container = window.parent.document.getElementById(id)
    },
    handleBeforeClose(done) {
      this.visible = false
      //done()
      //this.cleanupDialog()
    },
    moveDialog() {
      const dialogWrapper = this.$el.querySelector('.el-dialog__wrapper')
      if (dialogWrapper && this.container) {
        this.container.appendChild(dialogWrapper)
      }
    },
    cleanupDialog() {
      if (this.container) {
        this.container.innerHTML = ''
      }
    }
  },
  mounted() {
    window.addEventListener('message', (e) => {
      if (e.data.type === 'SET_CONTAINER_ID') {
        this.container = parent.document.getElementById(e.data.containerId)
      }
    })
  }
}
</script>
