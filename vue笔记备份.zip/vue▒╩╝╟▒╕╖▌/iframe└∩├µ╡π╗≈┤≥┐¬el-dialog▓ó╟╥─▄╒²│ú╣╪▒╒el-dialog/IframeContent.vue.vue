<template>
  <div class="content">
    <el-button type="primary" @click="openDialog">打开弹窗</el-button>
    <global-dialog ref="dialog" />
  </div>
</template>

<script>
import GlobalDialog from './components/GlobalDialog.vue'

export default {
  components: { GlobalDialog },
  methods: {
    openDialog() {
      this.$refs.dialog?.open()
    }
  },
  mounted() {
    window.addEventListener('message', (e) => {
      if (e.data.type === 'SET_GLOBAL_CONTAINER') {
        this.$refs.dialog?.setContainer(e.data.containerId)
      }
    })
  }
}
</script>

<style scoped>
.content {
  padding: 20px;
}
</style>
