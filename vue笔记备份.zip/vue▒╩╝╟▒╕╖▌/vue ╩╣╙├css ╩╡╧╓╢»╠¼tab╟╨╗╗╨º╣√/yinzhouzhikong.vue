<template>
  <div class="visualizing-container">
    <div class="visualizing-header">
      <div class="header-bg"></div>
      <div class="title">
        <input class="title-input" type="text" v-model="screenTitle" />
      </div>
      <div class="update-date-wrapper">
        <!-- <p class="update-date">
          更新时间：{{ updateDate }}
          <i class="el-icon-refresh"></i>
        </p> -->

        <div class="m-tab">
          <div class="m-tab-item" :class="tabIndex === index ? 'm-tab-item-active' : ''" v-for="(item, index) in tabList" :key="index" @click="toggleTab(index)">{{item}}</div>
          <div class="tab-line" :style="{left: number + 'px'}"></div>
        </div>

      </div>
      <div class="btn-group">
        <div
          class="btn"
          v-for="item in btnList"
          :key="item.value"
          :class="[activeBtnValue == item.value ? 'btn-active' : '']"
          @click="onTimeChange(item.value)"
        >
          <p>{{ item.label }}</p>
          <img
            v-if="activeBtnValue == item.value"
            class="btn-active-img"
            src="@/assets/images/visualizing/icon_active.png"
            alt=""
          />
        </div>
      </div>
    </div>
    <div class="visualizing-main">
      <div class="card-list">
        <div
          class="card-item"
          v-for="item in cardList"
          :key="item.title"
          :class="item.cardClass"
        >
          <div class="icon-border left-top"></div>
          <div class="icon-border left-bottom"></div>
          <div class="icon-border right-top"></div>
          <div class="icon-border right-bottom"></div>
          <div class="header-wrapper">
            <img class="icon" :src="item.icon" alt="" />
            <p class="title">{{ item.title }}</p>
          </div>
          <div class="content">
            <div class="left">
              <p class="title">{{ item.leftTitle }}</p>
              <p class="value">{{ item.leftValue }}</p>
            </div>
            <div class="left">
              <p class="title">{{ item.rightTitle }}</p>
              <p class="value">{{ item.rightValue }}</p>
            </div>
            <div class="right">
              <p class="title">{{ item.rightTitle }}</p>
              <p class="value">{{ item.rightValue }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="chart-main">
        <div class="data-left">
          <!-- <div class="flex-warp-item workload">
            <workloadChart ref="workloadChartRef" :params="params" />
          </div> -->
          <div class="flex-warp-item positive-rate-department">
            <reportExcellentRateRankingChart
              ref="reportRateRankingChartRef"
              :params="params"
              :bussinessType="'reportRate'"
            />
          </div>
          <div class="flex-warp-item positive-rate-examine-type">
            <reportExcellentRateRankingChart
              ref="imageRateRankingChartRef"
              :params="params"
              :bussinessType="'imageRate'"
            />
          </div>
        </div>
        <div class="data-center">
          <!-- <div class="flex-warp-item quality-safety">
            <qualitySafetyChart ref="qualitySafetyChartRef" :params="params" />
          </div> -->
          <div class="flex-warp-item machine-room">
            <imageExcellenceRateExamineTypeChart
              ref="inspectWaitTimeRef"
              :params="params"
              :inspectType="'inspectWait'"
            />
          </div>
          <div class="flex-warp-item image-excellence-rate-examine-type">
            <imageExcellenceRateExamineTypeChart
              ref="inspectReportTimeRef"
              :params="params"
              :inspectType="'inspectReport'"
            />
          </div>
        </div>
        <div class="data-right">
          <div class="flex-warp-item report-excellent-rate-ranking">
            <reportExcellentRateRankingChart
              ref="diagnosisRateRankingChartRef"
              :params="params"
              :bussinessType="'diagnosisRate'"
            />
          </div>
          <div class="flex-warp-item report-excellent-rate-examine-type">
            <reportExcellentRateExamineTypeChart
              ref="reportExcellentRateExamineTypeChartRef"
              :params="params"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import imageExcellenceRateExamineTypeChart from '../yinzhouComponents/imageExcellenceRateExamineTypeChart.vue'
import reportExcellentRateExamineTypeChart from '../yinzhouComponents/reportExcellentRateExamineTypeChart.vue'
import reportExcellentRateRankingChart from '../yinzhouComponents/reportExcellentRateRankingChart.vue'
import moment from 'moment'
import Mgr from '@/utils/SecurityService'
import { dynamicInvoke } from '@/api/dataapi'
export default {
  components: {
    imageExcellenceRateExamineTypeChart,
    reportExcellentRateExamineTypeChart,
    reportExcellentRateRankingChart,
  },
  data() {
    return {
      updateDate: '',
      screenTitle: '鄞州二院放射质控大屏',
      timer: null,
      activeBtnValue: 'today',
      btnList: [
        {
          label: '今日',
          value: 'today'
        },
        {
          label: '本周',
          value: 'week'
        },
        {
          label: '本月',
          value: 'month'
        },
        {
          label: '本年',
          value: 'year'
        }
      ],
      cardList: [
        {
          title: '检查进程',
          cardClass: 'progress',
          icon: require('@/assets/images/visualizing/icon_progress.svg'),
          leftTitle: '预约人次',
          rightTitle: '检查人次',
          leftValue: '',
          rightValue: ''
        },
        {
          title: '费用情况',
          cardClass: 'cost',
          icon: require('@/assets/images/visualizing/icon_cost.svg'),
          leftTitle: '检查费用(元)',
          rightTitle: '绿色通道人次',
          leftValue: '',
          rightValue: ''
        },
        {
          title: '检查效率',
          cardClass: 'efficiency',
          icon: require('@/assets/images/visualizing/icon_efficiency.svg'),
          leftTitle: '检查耗时(分)',
          rightTitle: '报告耗时(时)',
          leftValue: '',
          rightValue: ''
        },
        {
          title: '危急报告',
          cardClass: 'critical',
          icon: require('@/assets/images/visualizing/icon_critical.svg'),
          leftTitle: '通报人次',
          rightTitle: '未处理人次',
          leftValue: '',
          rightValue: ''
        },
        {
          title: '异常检查',
          cardClass: 'check-abnormal',
          icon: require('@/assets/images/visualizing/icon_check_abnormal.svg'),
          leftTitle: '检查爽约',
          rightTitle: '检查取消',
          leftValue: '',
          rightValue: ''
        },
        {
          title: '报告异常',
          cardClass: 'report-abnormal',
          icon: require('@/assets/images/visualizing/icon_report_abnormal.svg'),
          leftTitle: '报告修订次数',
          rightTitle: '报告超时份数',
          leftValue: '',
          rightValue: ''
        }
      ],
      params: {},
      tabIndex: 0,
      tabList: ['今日','本周', '本月', '本年', '近三年'],
      number: 0,
    }
  },
  computed: {
    // 登录用户信息
    loginUserInfo () {
      return JSON.parse(localStorage.getItem('loginInfo'))
    },
  },
  async created() {
    this.setParams()
  },
  mounted() {
    this.$nextTick(() => {
      this.initPage()
      this.timer = setInterval(() => {
        this.initPage()
      }, 60 * 1000)
    })
  },
  methods: {
    toggleTab(index) {
      if (this.tabIndex < index) {
        this.number = index * 60
      } else {
        this.number = this.number - ((this.tabIndex-index) * 60)
      }
      this.tabIndex = index
    },
    onTimeChange(value) {
      this.activeBtnValue = value
      this.setParams()
      this.initPage()
    },
    setUpdateDate() {
      this.updateDate = moment().format('YYYY-MM-DD HH:mm:ss')
    },
    setParams() {
      const query = this.$route.query
      const produceCode = query.produceCode || 'IS'
      let orgId = query.orgId || ''
      const { profile } = this.loginUserInfo
      if (profile?.inst_id) {
        orgId = profile.inst_id
      }
      this.$set(this.params, 'startTime', this.getStartTime())
      this.$set(this.params, 'endTime', moment().format('YYYY-MM-DD') + ' 23:59:59')
      this.$set(this.params, 'orgId', orgId)
      this.$set(this.params, 'produceCode', produceCode)
    },
    getStartTime() {
      let startDate = ''
      if (this.activeBtnValue == 'today') {
        startDate = moment().format('YYYY-MM-DD')
      } else if (this.activeBtnValue == 'week') {
        // 本周第一天 从周一开始
        startDate = moment()
          .isoWeekday(1)
          .format('YYYY-MM-DD')
      } else if (this.activeBtnValue == 'month') {
        startDate = moment()
          .startOf('month')
          .format('YYYY-MM-DD')
      } else if (this.activeBtnValue == 'year') {
        startDate = moment()
          .startOf('year')
          .format('YYYY-MM-DD')
      }
      return startDate + ' 00:00:00'
    },
    initPage() {
      this.setUpdateDate()
      this.getData()
    },
    getData() {
      // 检查进程
      dynamicInvoke('YZ-Area-Quality-Screen_1001', this.params).then((res) => {
        if (res.code == 0) {
          this.cardList[0].leftValue = res.data.bookNum
          this.cardList[0].rightValue = res.data.examNum
        } else {
          this.$message.error(res.msg)
        }
      })
      // 费用情况
      dynamicInvoke('YZ-Area-Quality-Screen_1002', this.params).then((res) => {
        if (res.code == 0) {
          this.cardList[1].leftValue = res.data.money
          this.cardList[1].rightValue = res.data.greenNum
        } else {
          this.$message.error(res.msg)
        }
      })
      // 检查效率
      dynamicInvoke('YZ-Area-Quality-Screen_1005', this.params).then((res) => {
        if (res.code == 0) {
          this.cardList[2].leftValue = res.data.examTime
          this.cardList[2].rightValue = res.data.reportTime
        } else {
          this.$message.error(res.msg)
        }
      })
      // 危急报告
      dynamicInvoke('YZ-Area-Quality-Screen_1003', this.params).then((res) => {
        if (res.code == 0) {
          this.cardList[3].leftValue = res.data.criticalNum
          this.cardList[3].rightValue = res.data.unDisposeNum
        } else {
          this.$message.error(res.msg)
        }
      })
      // 异常检查
      dynamicInvoke('YZ-Area-Quality-Screen_1004', this.params).then((res) => {
        if (res.code == 0) {
          this.cardList[4].leftValue = res.data.notOnTimeNum
          this.cardList[4].rightValue = res.data.cancelNum
        } else {
          this.$message.error(res.msg)
        }
      })
      // 报告异常
      dynamicInvoke('YZ-Area-Quality-Screen_1006', this.params).then((res) => {
        if (res.code == 0) {
          this.cardList[5].leftValue = res.data.revisionNum
          this.cardList[5].rightValue = res.data.outTimeNum
        } else {
          this.$message.error(res.msg)
        }
      })
      // 报告阳性率
      this.$refs.reportRateRankingChartRef.refreshChart()
      // 影像优良率
      this.$refs.imageRateRankingChartRef.refreshChart()
      // 检查等待平均耗时
      this.$refs.inspectWaitTimeRef.refreshChart()
      // 检查报告平均耗时
      this.$refs.inspectReportTimeRef.refreshChart()
      // 诊断符合率
      this.$refs.diagnosisRateRankingChartRef.refreshChart()
      // 报告优良率
      this.$refs.reportExcellentRateExamineTypeChartRef.refreshChart()
    }
  },
  destroyed() {
    clearInterval(this.timer)
    this.timer = null
  }
}
</script>

<style lang="scss" scoped>
@import "~@/style/util.scss";
.visualizing-container {
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background-image: url('~@/assets/images/visualizing/bg.png');
  background-size: cover;
  background-position: center;
}
.visualizing-header {
  width: 100%;
  height: vh(81);
  position: relative;

  .header-bg {
    width: 100%;
    height: vh(63);
    background-image: url('~@/assets/images/visualizing/header_bg.png');
    background-size: 100% 100%;
    position: absolute;
    left: 0;
    bottom: 0;
  }
  .btn-group {
    position: absolute;
    left: vw(20);
    bottom: 0;
    display: flex;
    align-items: center;
    .btn {
      position: relative;
      width: vw(48);
      height: vh(30);
      // line-height: vh(30);
      display: flex;
      justify-content: center;
      align-items: center;
      font-family: PingFangSC-Regular;
      font-weight: 400;
      font-size: vh(14);
      color: #25f5ff;
      text-align: center;
      border-radius: 4px;
      border: 1px solid #25f5ff;
      box-sizing: border-box;
      cursor: pointer;
      &:not(:last-child) {
        margin-right: vw(20);
      }
    }
    .btn-active {
      border: none;
    }
    .btn-active-img {
      width: vw(48);
      height: vh(30);
      position: absolute;
      top: 0;
      left: 0;
    }
  }
  .title {
    position: relative;
  }
  .title-input {
    width: 100%;
    border: none;
    font-family: PingFangSC-SNaNpxibold;
    font-weight: 600;
    font-size: vh(54);
    text-align: center;
    letter-spacing: 8px;
    color: transparent;
    caret-color: #fff;
    line-height: vh(50);
    background-image: linear-gradient(
      90deg,
      #3f70ff 35%,
      #25f5ff 50%,
      #3f70ff 65%
    );
    -webkit-background-clip: text;
    background-clip: text;
    z-index: 999;
  }
  .update-date-wrapper {
    position: absolute;
    right: vw(20);
    bottom: 0;
    .update-date {
      font-family: PingFangSC-Medium;
      font-weight: 500;
      font-size: vh(16);
      color: #25f5ff;
    }
  }
}
.visualizing-main {
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  padding: vh(20) vw(20);
}
.card-list {
  height: vh(140);
  display: flex;
  justify-content: space-between;
  .card-item {
    position: relative;
    width: vw(296);
    height: vh(140);
    background-size: 100% 100%;
    border-radius: 10px;
    background-image: url('~@/assets/images/visualizing/other_bg1.png');
    display: flex;
    flex-direction: column;
    .icon-border {
      background: url('~@/assets/images/visualizing/icon_border1.svg');
      position: absolute;
      width: 20px;
      height: 20px;
    }
    .left-top {
      left: 0;
      top: 0;
    }
    .left-bottom {
      left: 0;
      bottom: 0;
      transform: rotateX(180deg);
    }
    .right-top {
      right: 0;
      top: 0;
      transform: rotateY(180deg);
    }
    .right-bottom {
      right: 0;
      bottom: 0;
      transform: rotateX(180deg) rotateY(180deg);
    }
    .header-wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      height: vh(30);
      .title {
        line-height: vh(22);
        font-family: PingFangSC-Medium;
        font-weight: 500;
        font-size: vh(16);
        color: #00fff6;
        margin-left: vw(6);
      }
    }
    .content {
      display: flex;
      flex: 1;
      margin-top: vh(16);
      margin-bottom: vh(19);
      margin-left: vw(30);
      margin-right: vw(30);
      .left {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }
      .right {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }
      .title {
        font-family: PingFangSC-Medium;
        font-weight: 500;
        font-size: vh(14);
        color: #00fff6;
      }
      .value {
        font-family: PingFangSC-Medium;
        font-weight: 500;
        font-size: vh(36);
        color: #00fff6;
      }
      .unit {
        font-size: vh(14);
      }
    }
    &:nth-child(n + 4) {
      background-image: url('~@/assets/images/visualizing/other_bg2.png');
      .icon-border {
        background: url('~@/assets/images/visualizing/icon_border2.svg');
      }
      .header-wrapper {
        .title {
          color: #ffe800;
        }
      }
      .content {
        .title,
        .value {
          color: #ffe800;
        }
      }
    }
  }
  .progress {
    .icon {
      width: vw(16);
      height: vw(14.8);
    }
  }

  .cost {
    .icon {
      width: vw(16);
      height: vw(15.43);
    }
  }
  .efficiency {
    .icon {
      width: vw(16);
      height: vh(14.1);
    }
  }
  .critical {
    .icon {
      width: vw(13.59);
      height: vh(16);
    }
  }
  .check-abnormal {
    .icon {
      width: vw(11.1);
      height: vh(16);
    }
  }
  .report-abnormal {
    .icon {
      width: vw(13.87);
      height: vh(16);
    }
  }
}
.chart-main {
  flex: 1;
  overflow: hidden;
  display: flex;
  justify-content: space-between;
  margin-top: vh(20);
}
.flex-warp-item {
  position: relative;
  width: 100%;
  box-sizing: border-box;
}
.data-left {
  width: vw(612);
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.data-center {
  width: vw(612);
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.data-right {
  width: vw(614);
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.workload{
  height: vh(240);
}
.positive-rate-department,
.machine-room,
.report-excellent-rate-ranking {
  height: vh(387);
}
.positive-rate-examine-type,
.image-excellence-rate-examine-type,
.report-excellent-rate-examine-type {
  height: vh(387);
}
.m-tab { position: relative;display: flex; align-items: center; justify-content: space-between;}
.m-tab-item { width: 60px; color: #25F5FF; font-size: 15px; text-align: center; padding-bottom: 10px;cursor: pointer;}
.m-tab-item-active {color: #25F5FF;font-weight: 700;}
.tab-line {height: 4px; width: 60px; background: #25F5FF; position: absolute; bottom: 0; left: 0; transition: all 0.3s ease;}

</style>
