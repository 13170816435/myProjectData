<template>
  <transition name="el-zoom-in-center" v-if="isLockPage">
    <div class="lockContent">
      <div class="lockBanner" id="lockBanner" v-if="showLock">
        <span class="loginOutLock" @click="loginOutLock">退出锁屏</span>
           <el-carousel :height="bannerHeight">
            <el-carousel-item v-for="(item,index) in bannerListArr" :key="index">
              <img :id="`bannerImg${index}`" :src="item.image"  v-if="item.image"/>
            </el-carousel-item>
          </el-carousel>
      </div>
      <div class="lock-section" v-show="showUnlock">
      <div class="user-info">
        <img class="circle-img" src="./images/circleBg.png" alt="">
        <div class="login-user">
          <img :src="curUserImg" alt="" class="user-img">
          <p class="name-info mb40 ml20">
            <span class="user-name">{{loginInfo.profile.name}}</span>
            <i class="iconfont ml5">&#xe7e9;</i>
          </p>
          <p class="clr_red mb5 f15" style="text-align:left" v-if="errorMsg">{{errorMsg}}</p>
          <el-input type='password' ref="passwordInput" placeholder="请输入登录密码" v-model="password"  style="width:360px;height:40px;" class="password-input" @keyup.enter.native="LoginIn()">
            <el-button slot="append" :disabled='!password' @click='LoginIn'><i class="iconfont sureIcon">&#xe76d;</i></el-button>
          </el-input>
          <!-- <p class="tip">在[个人中心-安全设置]中可修改锁定时间</p> -->
        </div>
      </div>
      <div class="logout-content" @click="LoginOut">
        <div class="logout">
          <i class="iconfont">&#xe6ba;</i>
        </div>
        <p>退出登录</p>
      </div>
    </div>
    </div>
  </transition>
</template>
<script>
import { Button, Input, Carousel,CarouselItem } from 'element-ui';
import Mgr from '@/utils/SecurityService'
import Vue from 'vue'
import { mapActions, mapGetters } from 'vuex'
import { getConfigurations, getUserLogo, checkPassword, getUploadImg, getLockBanners, getScreensaverTime } from '../api/screenOperate'
import { getBase64 } from '../api/commonJs'
import JSEncrypt from '@/utils/jsencrypt.min'
export default {
  name: 'LockPage',
  components: {
    elButton:Button,
    elInput:Input,
    elCarousel:Carousel,
    elCarouselItem:CarouselItem,
  },
  data () {
    return {
      showLock: true,
      showUnlock: false,
      bannerListArr: [],
      curUserImg: require('./images/doctor_boy.png'),
      defaultUserImg: require('./images/doctor_boy.png'),
      loginInfo: {
        profile: {}
      },
      password: '',
      errorMsg: '',
      bannerHeight: '100%',
      isLockPage: false,
      openLockScreen: false,
      lockScreenTime: 0,
      msgVoiceTimeout: null,
      checkTimer: null,
    }
  },
  // computed: {
  //   ...mapGetters(['loginTokenInfo','isLockPage'])
  // },
  watch: {
    'isLockPage' (val) {
      if (val) {
        const pathname = window.location.pathname
        // 如果不在武汉医疗云 大屏页面 就锁屏
        if (pathname.indexOf('customerDataCockpit/index') == -1) {
          this.password = ''
          this.errorMsg = ''
          this.showLock = true
          this.showUnlock = false
          this.initBasicInfor()
          this.beganGetLockBannerList()
          // 初始化键盘输入事件
          document.addEventListener('keydown', this.handleKeyDown);
        }
      }
    }
  },
  beforeDestroy (){
    // 移除键盘事件监听器
   document.removeEventListener('keydown', this.handleKeyDown);
   sessionStorage.removeItem('isLockPage')
  },
  mounted () {
    console.log("刷新了")
    const self = this
    if (sessionStorage.getItem('isLockPage') == 'false') {
      self.isLockPage = false
    } else if (sessionStorage.getItem('isLockPage') == 'true') {
      self.isLockPage = true
    }
    self.initBasicInfor()
    // self.beganGetLockBannerList()
    // // 初始化键盘输入事件
    // document.addEventListener('keydown', self.handleKeyDown);
  },
  methods: {
    ...mapActions(['clearLock']),
    // 弹出锁屏方法
    showDialog () {
      //console.log(this.$store)
      this.isLockPage = true
      sessionStorage.setItem('isLockPage',true)
    },
    // 关闭锁屏
    closeDialog () {
      this.isLockPage = false
      this.showLock = false
      this.showUnlock = false
      this.checkTimer = null
      sessionStorage.setItem('isLockPage',false)
      document.removeEventListener('keydown', this.handleKeyDown);
    },
    // 监听键盘输入事件
    handleKeyDown () {
      if (this.showLock == true) {
        // 这里按下任意键 就退出锁屏
        this.loginOutLock()
      }
    },
    // 退出锁屏
    loginOutLock () {
      const self = this
      self.showLock = false
      self.showUnlock = true
      self.$nextTick(() =>{
        setTimeout(() => {
          self.password = ''
          self.errorMsg = ''
          if (self.$refs.passwordInput) {
            self.$refs.passwordInput.focus() 
          }
        },100)
       
      })
    },
    // 获取锁屏banner图片列表
    async beganGetLockBannerList() {
      const self = this;
      const param = {
        scene_code: 'lockscreen',
      };
      self.bannerListArr = [];
      const res = await getLockBanners(param);
      if (res.code === 0) {
        self.getCurImg(res.data);
      } else {
        self.$message({ message: `${res.msg}`, type: "error" });
      }
    },
    // 重置 banner图片的 长和宽
    judgeImgWidth(imgId) {
      const self = this
      self.$nextTick(() => {
        var imgObj = document.getElementById(imgId);
        var containObj = document.getElementById("lockBanner");
        imgObj.onload = function() {
          // imgObj.naturalWidth 为图片本身的宽度
          var widthNum = (containObj.clientWidth / imgObj.naturalWidth).toFixed(2);
          var heightNum = (containObj.clientHeight / imgObj.naturalHeight).toFixed(2);
          if (widthNum > heightNum) {
            imgObj.style.width = imgObj.naturalWidth * widthNum + "px";
            imgObj.style.height = imgObj.naturalHeight * widthNum + "px";
          } else {
            imgObj.style.width = imgObj.naturalWidth * heightNum + "px";
            imgObj.style.height = imgObj.naturalHeight * heightNum + "px";
          }
        }
      })
    },
    async getCurImg(result) {
      const self = this;
      for (let i = 0; i < result.length; i++) {
        result[i].image = "";
        self.bannerListArr.push(result[i]);
      }
      //console.log(self.bannerListArr)
      //  获取服务介绍icon
      for (let i = 0; i < self.bannerListArr.length; i++) {
        let bannerImg = "bannerImg" + i
        // 获取logo 图片
        await getUploadImg({ document_id: self.bannerListArr[i].file_id })
          .then((res) => {
            if (res) {
              getBase64(res).then((item) => {
                self.$set(self.bannerListArr[i], "image", item);
                self.judgeImgWidth(bannerImg)
              });
            } else {
              self.$set(self.bannerListArr[i], "image", self.defaultImg);
              self.judgeImgWidth(bannerImg)
            }
          })
          .catch((error) => {
            console.log(error);
            self.$set(self.bannerListArr[i], "image", self.defaultImg);
            self.judgeImgWidth(bannerImg)
          });
      }
    },
    // 初始化信息
    initBasicInfor () {
      const _this = this
      if (_this.loginTokenInfo) {
        //_this.loginInfo = JSON.parse(localStorage.getItem('loginInfo'))
        _this.loginInfo = JSON.parse(JSON.stringify(_this.loginTokenInfo))
        const userIconId = _this.loginInfo.profile.sub
        _this.getUserIcon(userIconId)
      } else {
        var manager = new Mgr()
        manager.getRole().then(function (item) {
          if (item) {
            _this.loginInfo = item
            const userIconId = _this.loginInfo.profile.sub
            _this.getUserIcon(userIconId)
          }
        })
      }
      _this.getConfigurationsFn()
    },
    // 获取登录头像
    async getUserIcon (userIconId) {
      const imgFile = await getUserLogo(userIconId)
      if (imgFile) {
        getBase64(imgFile).then(result => {
         this.curUserImg = result
       })
      } else {
        this.curUserImg = this.defaultUserImg
      }
    },
    async getConfigurationsFn () {
      const res = await getConfigurations('TransmissionSecurity.RSA.PublicKey')
      if (res.code === 0) {
        // rsa加密
        Vue.prototype.$getRsaCode = function (str) { // 注册方法
          const pubKey = res.data// ES6 模板字符串 引用 rsa 公钥
          const encryptStr = new JSEncrypt()
          encryptStr.setPublicKey(pubKey) // 设置 加密公钥
          const data = encryptStr.encrypt(str.toString()) // 进行加密
          return data
        }
      }
    },
    // 登录
    async LoginIn () {
      if (!this.password) {
        return false
      }
      // 请求成功之后的逻辑
      const params = {
        user_name: this.loginInfo.profile.phone_number,
        // password: this.password
        password: this.$getRsaCode(this.password)
      }
      const res = await checkPassword(params)
      if (res.code === 0) {
        this.isLockPage = false
        this.showUnlock = false
        sessionStorage.setItem('isLockPage',false)
        // 调用彪哥的方法 通知关闭所有的锁屏
        window.notifyCloseLockPage && window.notifyCloseLockPage()
        //this.$store.dispatch('lockPage/clearLock', false)
        const lastTime = new Date().getTime()
        //this.$store.dispatch('lockPage/refashTime', lastTime)
      } else {
        this.errorMsg = res.msg
      }
    },
    // 退出登录
    LoginOut () {
      //this.$store.dispatch('lockPage/clearLock', false)
      this.isLockPage = false
      sessionStorage.setItem('isLockPage',false)
      const lastTime = new Date().getTime()
      //this.$store.dispatch('lockPage/refashTime', lastTime)
      window.sessionStorage.setItem('FirstEnterSystem', false)
      window.sessionStorage.removeItem('RisReportInfo')
      window.sessionStorage.removeItem('EISReportStorage')
      window.sessionStorage.removeItem('UISReportStorage')
      sessionStorage.removeItem('isOpenModifyDoctor')
      localStorage.removeItem('RISassistToken')
      sessionStorage.removeItem('currentSystemClass')
      sessionStorage.removeItem('lastname')
      sessionStorage.removeItem('FileName')
      this.$nextTick(() => {
        const manager = new Mgr()
        manager.signOut().then(_rep => {
        })
      })
    }
  }
}
</script>

<style lang="less" scoped>
.lockContent{
  width: 100%;
  height: 100%;
  position: fixed;
  left:0;
  top:0;
  z-index:899999;
  background:#c0c4cc;
  // background-image: url(../../assets/images/pacs/mianBg.png);
  .lockBanner{
    width: 100%;
    height: 100%;
    position: relative;
    ::v-deep .el-carousel{
      height: 100%;
    }
    ::v-deep .el-carousel__container{
      height: 100%;
      .el-carousel__item{
        display: flex!important;
        justify-content: center;
        align-items: center;
        img{
          display: block;
          width:auto;
          height:auto;
          max-width: 100%;
          max-height:100%;
          width: 100%;
        }
      }
      .el-carousel__arrow{
        width:70px;
        height:70px;
      }
      .el-carousel__arrow{
        font-size: 36px;
      }
    }
      .loginOutLock{
        position: absolute;
        right:20px;
        top:20px;
        cursor: pointer;
        display: inline-block;
        color: #fff;
        height: 40px;
        line-height: 40px;
        padding: 0 20px;
        font-size: 15px;
        border-radius: 20px;
        background: #0a70b0;
        z-index: 10000;
      }
  }
}
.lock-section{
  min-width:1280px;
  width:100%;
  height:100%;
  background-image: url(./images/mianBg.png);
  background-size:cover;
}
.user-info{
  width:510px;
  height:465px;
  position: relative;
  left:50%;
  top:50%;
  transform: translate(-50%,-50%);
}
.user-info .circle-img{
  width:510px;
  height:465px;
  position: absolute;
  left:50%;
  top:50%;
  transform: translate(-50%,-50%);
}
.login-user{
  position: absolute;
  left:50%;
  top:-20px;
  transform: translateX(-50%);
  text-align: center;
}
.user-info .user-img{
  width:170px;
  height:170px;
  border-radius:50%;
  border: 5px solid hsla(0,0%,100%,.2);
}
.name-info{
  line-height: 1;
  margin-top:20px;
}
.user-name{
  font-size: 32px;
  color:#fff;
  vertical-align: middle;
  letter-spacing: 2px;
}
.iconfont{
  font-size: 32px;
  color:#fff;
  vertical-align: middle;
}
.password-input ::v-deep .el-input-group__append{
  background: #0a70b0;
  border-color:#fff;
}
.password-input ::v-deep .el-button.is-disabled,.password-input ::v-deep .el-button.is-disabled:active,.password-input ::v-deep .el-button.is-disabled:focus,.password-input ::v-deep .el-button.is-disabled:hover {
  border-color: transparent!important;
  background-color: transparent!important;
  opacity: 0.45;
}
.password-input ::v-deep .el-input-group__append,.password-input ::v-deep .el-input-group__prepend{
  border:2px solid #fff;
}
.password-input ::v-deep .el-input__inner{
  border-color:#fff;
  height:40px;
}
.tip{
  font-size: 15px;
  text-align: left;
  margin-top:10px;
  color: #fff;
}
.logout-content{
  font-size: 15px;
  text-align: center;
  position: fixed;
  bottom:30px;
  left:50%;
  transform: translateX(-50%);
  color:#FFF;
  cursor: pointer;
}
.logout{
  width:48px;
  height:48px;
  line-height: 45px;
  border-radius:50%;
  background: rgba(255,255,255,0.2);
  text-align: center;
  margin-bottom:5px;
  display: inline-block;
}
.logout .iconfont{
  font-size: 22px;
}
.sureIcon{
  font-size:16px!important;
}
</style>
