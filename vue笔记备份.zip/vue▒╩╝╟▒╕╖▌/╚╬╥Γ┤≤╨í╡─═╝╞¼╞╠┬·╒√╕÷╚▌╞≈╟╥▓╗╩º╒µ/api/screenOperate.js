import request from '@/utils/request'
import qs from 'qs'
const fileName = '/api-operate'
const archivesUrl = '/api-archive'
const RoutBaseUrl = '/api-cloudpacs'
// 获取配置项
export function getConfigurations (params) {
  return request({
    url: fileName + '/configurations?key=' + params,
    method: 'get'
  })
}
// 用户logo
export function getUserLogo (id) {
  return request({
    responseType: 'arraybuffer',
    url: fileName + '/users/avatar?id=' + id,
    method: 'GET'
  })
}
// 校验密码
export function checkPassword (params) {
  return request({
    url: RoutBaseUrl + '/Common/CheckPassword',
    method: 'post',
    data: params
  })
}
// 获取屏保时间
export function getScreensaverTime (data) {
  return request({
    url: fileName + '/users/screensaver',
    method: 'get'
  })
}
// 通过document_id 调用曹磊的接口来获取图片
export function getUploadImg (data) {
  return request({
    responseType: 'arraybuffer',
    url: archivesUrl + '/download/crm-document-id',
    method: 'GET',
    params: data
  })
}
// 获取锁屏banner图列表
export function getLockBanners (data) {
  return request({
    url: fileName + '/banners',
    method: 'GET',
    params: data,
  })
}