<template>
  <div class="addofficial">
    <!-- <div class="flex_row">
      <span class="w_80 tr"><i class="iconfont iconbitian clr_da"></i>文档类别 ：</span>
      <span class="fl officialKind mr15" v-bind:class="{'activeKind': officialInfo.type === 1}" @click="chooseKind(1)">内部</span>
      <span class="fl officialKind" v-bind:class="{'activeKind': officialInfo.type === 2}" @click="chooseKind(2)">发布</span>
      <div class="fr officalState">
         <p>说明：</p>
         <span>内部类文档：为平台内用户注册协议、隐私协议等信息类文档，可在线编辑文档内容；</span><br/>
         <span>发布类文档：为系统操作手册、平台更新说明等功能性文档，需上传文档附件，供用户下载；</span>
      </div>
    </div> -->
    <div class="flex_row">
      <div class="w_80 tr">
        <i class="iconfont iconbitian clr_da"></i>文档名称 ：
      </div>
      <el-input v-model="officialInfo.name" class="width_360_input"></el-input>
    </div>
    <div class="flex_row mt15" v-if="officialInfo.type === 1">
      <div class="w_80 tr">
        <i class="iconfont iconbitian clr_da"></i>文档编码 ：
      </div>
      <el-input v-model="officialInfo.code" class="width_360_input"></el-input>
    </div>
    <div class="flex_row mt15">
      <div class="w_80 tr">文档描述：</div>
      <el-input type="textarea" v-model="officialInfo.description"></el-input>
    </div>
    <div
      class="flex_row mt15 pb15 pr10"
      style="height: 450px; overflow-y: auto"
      v-if="officialInfo.type === 1"
    >
      <div class="w_80 tr">
        <i class="iconfont iconbitian clr_da"></i>文档内容 ：
      </div>
      <quill-editor
        v-model="officialInfo.content"
        class="myQuillEditor flex_1"
        :options="editorOption"
        style="min-height: 260px; padding-bottom: 25px"
      ></quill-editor>
    </div>
    <div class="flex_row documentFile mt15 mb20" v-if="officialInfo.type === 2">
      <div class="w_80 tr">
        <i class="iconfont iconbitian clr_da"></i>文档附件：
      </div>
      <div class="oneLogVal fl">
        <div class="imageImportHead">
          <span class="myfileName"
            ><span class="templateName" v-bind:title="currentFileName">{{
              currentFileName
            }}</span>
            <!-- <i @click="delFile(addPrintTempParam.id)" class="fl delFileIcon el-icon-error" v-if="currentFileName"></i> -->
          </span>
          <el-upload
            class="upload-demo"
            :action="uploadSrc"
            :show-file-list="false"
            :on-progress="handleProgress"
            :before-upload="chooseUploadMyFrx"
            :auto-upload="true"
            :http-request="uploadSuc"
          >
            <el-button class="fileA" size="small" type="primary"
              ><i class="iconfont iconxinzeng pr5"></i>选择文件</el-button
            >
          </el-upload>
        </div>
      </div>
      <div class="progressCon" v-if="showProgress">
        <el-progress
        class="clear"
        :text-inside="true"
        :stroke-width="15"
        :percentage="progressPercent"
        color="#00D35D"
        ></el-progress>
        <!-- <el-progress :percentage="progressPercent" :status="progressStatus"></el-progress> -->
      </div>
      <div class="fileTip">
        支持.doc(.docx)、.xls(.xlsx)、pdf、.ppt (.pptx)格式, 大小不超过50M
      </div>
    </div>
    <div class="dialog_footer mt15">
      <el-button size="small" plain @click="commit('cancel')">取消</el-button>
      <el-button size="small" type="primary" @click="commit('commit')"
        >确 定</el-button
      >
    </div>
  </div>
</template>

<script>
import { quillEditor } from "vue-quill-editor";
import "quill/dist/quill.core.css";
import "quill/dist/quill.snow.css";
import "quill/dist/quill.bubble.css";
const toolbarOptions = [
  ["bold", "italic", "underline"], // 加粗 斜体 下划线 删除线
  ["blockquote", "code-block"], // 引用  代码块
  [{ color: [] }, { background: [] }], // 字体颜色、字体背景颜色
  [{ indent: "-1" }, { indent: "+1" }], // 缩进
  [{ align: [] }], // 对齐方式
  [{ header: 1 }, { header: 2 }], // 1、2 级标题
  [{ list: "ordered" }, { list: "bullet" }], // 有序、无序列表
  [{ script: "sub" }, { script: "super" }], // 上标/下标
  ["link", "image"], // 链接、图片、视频
  ["clean"], // 清除文本格式
];
export default {
  props: {
    officialInfo: Object,
    FileName: String,
    progressPercent:Number,
  },
  components: {
    quillEditor,
  },
  watch: {
    FileName(val) {
      this.currentFileName = val;
    },
    progressPercent (val) {
      if (val != 0) {
        this.showProgress = true
      }
      if (val == 100){
        setTimeout(() => {
          this.showProgress = false 
        },100)
      }
    },
  },
  data() {
    return {
      currentFileName: "",
      uploadSrc: "#",
      // uploadSrc: configUrl.apiUrl + '',
      editorOption: {
        placeholder: "请在这里输入",
        modules: {
          toolbar: toolbarOptions,
        },
      },
      //progressPercent: 0,
      showProgress:false,
    };
  },
  methods: {
    chooseKind(val) {
      this.officialInfo.type = val;
      if (val === 2) {
        this.officialInfo.code = "";
      }
    },
    verifyIsFrx(file) {
      const fileName = file.name;
      this.currentFileName = file.name;
      const type = fileName.substring(fileName.lastIndexOf(".")).toLowerCase();
      const isLt50M = file.size / 1024 / 1024 < 50;
      let isDoc = true;
      isDoc =
        type === ".doc" ||
        type === ".docx" ||
        type === ".xls" ||
        type === ".xlsx" ||
        type === ".pdf" ||
        type === ".ppt" ||
        type === ".pptx";
      if (!isDoc) {
        this.currentFileName = "";
        this.$message.error(
          "附件只能是 doc、docx、xls、xlsx、pdf、ppt、pptx格式!"
        );
        return false;
      }
      if (!isLt50M) {
        this.$message.error("文件大小不能超过 50MB!");
        return false;
      }
      return true;
    },
    chooseUploadMyFrx(file) {
      if (this.verifyIsFrx(file)) {
        this.$emit("subFile", file, this.currentFileName, true);
      } else {
        this.$emit("subFile", file, this.currentFileName, false);
      }
    },
    // 显示进度条
    handleProgress (event, file, fileList) {
      this.showProgress = true 
      this.progressPercent = Math.floor((event.loaded / event.total) * 100);
      console.log("不会触发的")
      if (this.progressPercent == 100) {// 上传完成了
        //console.log(file)
        this.$emit("uploadSuc", file)
        setTimeout(() => {
          this.showProgress = false 
        },100)
      }
    },
    // 上传成功
    uploadSuc(params) {
      //console.log(params)
      this.$emit("uploadSuc", params);
    },
    commit(type) {
      if (this.progressPercent != 0 && this.progressPercent != 100) {
        this.$message.error("文件正在上传,请耐心等待");
        return;
      }
      this.$emit("commit", type);
    },
    initData () {
      this.currentFileName = this.FileName;
      this.showProgress = false
    }
  },
  mounted() {
    
  },
};
</script>

<style lang="less" scoped>
.addofficial {
  padding-top: 20px;
  .w_80 {
    width: 100px;
    line-height: 32px;
    color: #303133;
  }
  .officialKind {
    width: 80px;
    height: 32px;
    line-height: 31px;
    text-align: center;
    border: 1px solid #dcdfe6;
    border-radius: 16px;
    color: #0a70b0;
    background: #fff;
    font-size: 15px;
    cursor: pointer;
  }
  .activeKind {
    font-weight: bold;
    color: #fff;
    background: #0a70b0;
    border-color: #0a70b0;
  }
  ::v-deep .el-textarea {
    width: 360px;
    height: 80px;
    .el-textarea__inner {
      height: 100%;
      padding: 0 8px;
    }
  }
  .myfileName {
    float: left;
    width: 360px;
    height: 32px;
    line-height: 31px;
    padding-left: 5px;
    border: 1px solid #dcdfe6;
    border-radius: 3px;
    .templateName {
      float: left;
      width: 320px;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
      word-break: break-all;
    }
    .delFileIcon {
      padding-left: 8px;
      color: #f56c6c;
      cursor: pointer;
      margin-top: 8px;
    }
  }
  .fileTip {
    color: #e6a23c;
    font-size: 15px;
    line-height: 36px;
    margin-left: 100px;
  }
  .upload-demo {
    position: relative;
    height: 0px;
  }
  .fileA {
    position: absolute;
    right: -110px;
    top: 0;
    border: 1px solid #dcdfe6;
    border-radius: 4px;
    width: 110px;
    height: 32px;
    font-size: 15px;
    text-align: center;
    overflow: hidden;
    color: #0a70b0;
    text-decoration: none;
    line-height: 31px;
    cursor: pointer;
    border-bottom-left-radius: 0;
    border-top-left-radius: 0;
    border-left: none;
    padding: 0 !important;
    background: #fff !important;
  }
}
.documentFile {
  flex-wrap: wrap;
}
.officalState {
  position: absolute;
  right: 0;
  width: 373px;
  color: #e6a23c;
  font-size: 15px;
}

  // 进度条
  ::v-deep .progressCon {
    width:360px;
    margin-left: 100px;
    margin-top: 10px;
    .el-progress {
      width: 100%;
    }
    .el-progress-bar__innerText { //进度条 进度值的样式设置
      position: relative;
      top: -17px;
      z-index: 1000;
      color: #fff!important;
    }
   .el-progress-bar__inner:before{
     content:"";
     width:100%;
     height:100%;
     display:block;
     background-image:repeating-linear-gradient(-45deg,hsla(0,0%,100%,.15) 25%,transparent 0,transparent 50%,hsla(0,0%,100%,.15) 0,hsla(0,0%,100%,.15) 75%,transparent 0,transparent);
     background-size:40px 40px;
     animation:mymove 2s linear infinite;
   }
   @keyframes mymove{
      0%   {background-position: 0;}
      25%  {background-position: 50px;}
      50%  {background-position: 100px;}
      75%  {background-position: 150px;}
      100% {background-position: 200px;}
    }
  }
</style>
