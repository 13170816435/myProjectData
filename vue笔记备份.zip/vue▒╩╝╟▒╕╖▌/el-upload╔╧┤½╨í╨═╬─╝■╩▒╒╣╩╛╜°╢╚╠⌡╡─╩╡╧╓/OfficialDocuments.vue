<template>
  <div class="userList">
    <div class="title-bar flex_row">
      <div class="tl col">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>系统运维
          <i class="iconfont iconzhankaishouqi"></i> 文档管理
        </span>
      </div>
      <div class="tr col">
        <span @click="operateFn('add')" class="function-btn bg_e6 clr_ff">
          <i class="iconfont iconxinzeng"></i>新增文档
        </span>
      </div>
    </div>
    <officalConditionInquery @getList="getList"></officalConditionInquery>
    <div class="container">
      <div
        class="table-list"
        v-bind:class="{ noTableData: tableData.length == 0 }"
      >
        <el-table
          width="100%"
          size="medium "
          :data="tableData"
          v-loading="loading"
          element-loading-text="拼命加载中"
          element-loading-background="rgba(255,255,255,0.6)"
          border
          stripe
          :height="tableheight"
          highlight-current-row
          header-row-class-name="strong"
        >
          <el-table-column type="index" label="序号" width="60" fixed="left">
            <template slot-scope="scope">
              <span>{{
                (searchOfficalData.offset - 1) * searchOfficalData.limit +
                scope.$index +
                1
              }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="100" fixed="left">
            <template slot-scope="scope">
              <span class="clr_0a pointer" @click="operateFn('info', scope.row)"
                >编辑</span
              >
              <span
                class="clr_da ml10 pointer"
                @click="operateFn('del', scope.row)"
                >删除</span
              >
            </template>
          </el-table-column>
          <el-table-column
            type="index"
            label="文档状态"
            width="80"
            fixed="left"
          >
            <template slot-scope="scope">
              <el-switch
                @change="officialStateChangeFn($event, scope.row.id)"
                class="switchStyle"
                active-color="#409EFF"
                inactive-color="#F56C6C"
                active-text="启用"
                inactive-text="禁用"
                :active-value="true"
                :inactive-value="false"
                v-model="scope.row.enable_state"
              ></el-switch>
            </template>
          </el-table-column>
          <common-table :propData="propData"></common-table>
        </el-table>
        <div class="ba">
          <pagination-tool
            :total="pageInfo.total_count"
            :page.sync="searchOfficalData.offset"
            :limit.sync="searchOfficalData.limit"
            @pagination="getOfficialListFn"
          />
        </div>
      </div>
    </div>
    <el-dialog
      :title="dialogTitle"
      :visible.sync="isInfo"
      width="650px"
      top="8vh"
      :close-on-click-modal="false"
      v-dialogDrag
    >
      <OfficialInfodialog
        :officialInfo="officialInfo"
        @commit="commit"
        @subFile="subFile"
        :progressPercent="progressPercent"
        @uploadSuc="uploadSuc"
        :FileName="FileName"
        ref="OfficialInfodialog"
      />
    </el-dialog>
  </div>
</template>

<script>
import Mgr from "@/utils/SecurityService";
import officalConditionInquery from "./components/officalConditionInquery";
import CommonTable from "./components/CommonTable";
import PaginationTool from "@/components/common/PaginationTool";
import {
  getOfficialList,
  getOfficialInfo,
  addOfficial,
  putOfficial,
  delOfficial,
  putOfficialState,
} from "@/api/platform_operate/systemset";
import OfficialInfodialog from "./components/addOfficial";
import { uploadMediaFile } from "@/api/commonHttp";
import { connectUrlParam } from "@/components/commonJs";
export default {
  components: {
    CommonTable,
    officalConditionInquery,
    PaginationTool,
    OfficialInfodialog,
  },
  data() {
    return {
      progressPercent: 0,
      tenancy_id: "",
      tableheight: "100%",
      loading: true,
      isExcelFile: false,
      pageLayout: "total, prev, pager, next, jumper",
      pageInfo: {
        eof: 1,
        offset: 1,
        limit: 20,
        total_count: 0,
        total_pages: 1,
      },
      propData: [
        { prop: "name", label: "文档名称", width: 200 },
        { prop: "file_id", label: "附件信息" },
        { prop: "description", label: "文档描述", width: 250 },
        { prop: "last_modifier_name", label: "操作用户" },
        { prop: "last_modified_time", label: "操作时间" },
      ],
      tableData: [],
      dialogTitle: "新增文档",
      // 详情
      isInfo: false,
      FileName: "",
      officialInfo: {
        id: 0,
        type: 2,
        name: "",
        code: "",
        description: "",
        content: "",
        // system: 0,
        // enable_state: true
      },
      addOfficialInfoFormData: {},
      searchOfficalData: {
        offset: 1,
        limit: 20,
      },
    };
  },
  beforeMount() {
    this.$nextTick(() => {
      this.tableheight = document.documentElement.clientHeight - 150;
    });
  },
  mounted() {
    const self = this;
    var manager = new Mgr();
    manager.getRole().then(function (logindata) {
      self.tenancy_id = sessionStorage.getItem('curTenancyId') || logindata.profile.tenancy_id;
    });
    self.addOfficialInfoFormData = new FormData();
    //self.getOfficialListFn()
  },
  methods: {
    getList(obj) {
      this.searchOfficalData = obj;
      this.getOfficialListFn();
    },
    // 获取文档列表
    async getOfficialListFn() {
      // const _url = '?offset=' + this.pageInfo.offset + '&limit=' + this.pageInfo.limit
      const res = await getOfficialList(this.searchOfficalData);
      if (res.code === 0) {
        this.loading = false;
        this.tableData = res.data;
        this.pageInfo = res.page;
      } else {
        this.loading = false;
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 获取用户详情
    async getOfficialInfoFn(id) {
      var param = {
        id: id,
        tenancy_id: this.tenancy_id,
      };
      const res = await getOfficialInfo(param);
      if (res.code === 0) {
        this.isInfo = true;
        this.officialInfo = res.data;
      } else {
        this.$message({ type: "error", message: res.msg });
      }
    },
    // 操作按钮
    operateFn(type, row) {
      const self = this
      if (type === "info") {
        // 详情
        self.isInfo = true;
        self.dialogTitle = "编辑文档";
        self.FileName = row.file_name;
        self.getOfficialInfoFn(row.id);
        self.progressPercent = 0
        self.$nextTick(() => {
          self.$refs.OfficialInfodialog.initData()
        })
      } else if (type === "add") {
        self.isInfo = true;
        self.dialogTitle = "新增文档";
        self.FileName = "";
        self.officialInfo = self.$options.data().officialInfo;
        self.progressPercent = 0
        self.$nextTick(() => {
          self.$refs.OfficialInfodialog.initData()
        })
      } else if (type === "del") {
        self.$confirm("确定要删除该文档吗？", "删除文档", {
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
        }).then(() => {
          self.delOfficialFn(row.id);
        });
      }
    },
    // subFile (val,fileName) {
    //   this.FileName = fileName
    //   this.addOfficialInfoFormData.delete('annex')
    //   this.addOfficialInfoFormData.append('annex', val)
    // },
    subFile(val, fileName, bool) {
      this.FileName = fileName;
      this.isExcelFile = bool;
      // this.addOfficialInfoFormData.delete('annex')
      // this.addOfficialInfoFormData.append('annex', val)
    },
    // 上传文件成功
    async uploadSuc(params) {
      const self = this
      if (self.isExcelFile) {
        let res;
        let param = {
          file_name: params.file.name,
          //file_sha: '123',
          file_size: params.file.size,
          position: 0,
          file_type: 2,
        };
        let paramUrl = connectUrlParam(param);
        const formData = new FormData();
        formData.append("file", params.file);
        self.progressPercent = 0
        res = await uploadMediaFile(formData, paramUrl,progressEvent => {
          // console.log(progressEvent)
          // 通过 progress 事件更新进度
          self.progressPercent = Math.floor((progressEvent.loaded / progressEvent.total) * 100)
        });
        if (res.code === 0) {
          // 手写签名
          self.addOfficialInfoFormData.delete("file_id");
          self.addOfficialInfoFormData.append("file_id", res.document_id);
        } else {
          self.$message({ type: "error", message: res.msg });
        }
      }
    },
    // 提交操作
    commit(type) {
      if (type === "cancel") {
        this.isInfo = false;
        this.officialInfo = this.$options.data().officialInfo;
      } else {
        this.addOfficialFn();
      }
    },
    deleteFormDataKey() {
      this.addOfficialInfoFormData.delete("id");
      this.addOfficialInfoFormData.delete("type");
      this.addOfficialInfoFormData.delete("name");
      this.addOfficialInfoFormData.delete("code");
      this.addOfficialInfoFormData.delete("description");
      this.addOfficialInfoFormData.delete("content");
      this.addOfficialInfoFormData.delete("tenancy_id");
      if (this.officialInfo.type === 1) {
        this.addOfficialInfoFormData.delete("annex");
      }
    },
    initFormData() {
      this.addOfficialInfoFormData.append("id", this.officialInfo.id);
      this.addOfficialInfoFormData.append("type", this.officialInfo.type);
      this.addOfficialInfoFormData.append("name", this.officialInfo.name);
      this.addOfficialInfoFormData.append("code", this.officialInfo.code);
      this.addOfficialInfoFormData.append(
        "description",
        this.officialInfo.description
      );
      this.addOfficialInfoFormData.append("content", this.officialInfo.content);
      this.addOfficialInfoFormData.append("tenancy_id", this.tenancy_id);
    },
    // 新增修改文档
    async addOfficialFn() {
      this.deleteFormDataKey();
      if (!this.officialInfo.name) {
        this.$message.error("文档名称不能为空!");
        return;
      }
      if (this.officialInfo.type === 1 && !this.officialInfo.code) {
        this.$message.error("文档编码不能为空!");
        return;
      }
      if (this.officialInfo.type === 1 && !this.officialInfo.content) {
        this.$message.error("文档内容不能为空!");
        return;
      }
      if (this.officialInfo.type === 2 && !this.FileName) {
        this.$message.error("请上传文档附件!");
        return;
      }
      this.initFormData();
      let res = null;
      let msg = "";
      if (this.officialInfo.id !== 0) {
        msg = "文档修改成功";
        // res = await putOfficial(this.officialInfo)
        res = await putOfficial(this.addOfficialInfoFormData);
      } else {
        msg = "文档添加成功";
        // res = await addOfficial(this.officialInfo)
        res = await addOfficial(this.addOfficialInfoFormData);
      }
      if (res.code === 0) {
        this.$message.success(msg);
        this.isInfo = false;
        this.getOfficialListFn();
      } else {
        this.$message.error(res.msg);
      }
    },
    // 删除文档
    async delOfficialFn(id) {
      var param = {
        id: id,
        tenancy_id: this.tenancy_id,
      };
      const res = await delOfficial(param);
      if (res.code === 0) {
        this.$message.success("删除成功！");
        this.tableData.forEach((item, i) => {
          if (item.id === id) {
            this.tableData.splice(i, 1);
          }
        });
      } else {
        this.$message.error(res.msg);
      }
    },
    // 修改文档启用状态
    async officialStateChangeFn(state, id) {
      const parmas = {
        id: id,
        enable_state: state,
        tenancy_id: this.tenancy_id,
      };
      const res = await putOfficialState(parmas);
      if (res.code === 0) {
        this.$message.success("修改成功！");
      } else {
        this.$message.error(res.msg);
      }
    },
  },
};
</script>
<style>
.el-message-box__header {
  background: #0a70b0 !important;
}
.el-message-box {
  border: none !important;
}
.el-message-box__title,
.el-message-box__headerbtn .el-message-box__close {
  color: #ffffff !important;
}
.el-message-box__message {
  font-size: 15px;
}
.switchStyle .el-switch__label {
  position: absolute;
  display: none;
  color: #fff;
}
.switchStyle .el-switch__label--left {
  z-index: 9;
  left: 19px;
}
.switchStyle .el-switch__label--right {
  z-index: 9;
  left: -6px;
}
.switchStyle .el-switch__label.is-active {
  display: block;
}
.switchStyle.el-switch .el-switch__core,
.el-switch .el-switch__label {
  width: 50px !important;
}
.el-switch__label * {
  font-size: 12px !important;
}
</style>
<style lang="less" scoped>
.userList {
  height: 100%;
  .container {
    height: calc(100% - 100px);
    padding-top: 0px;
    .table-list {
      height: 100%;
      ::v-deep .el-table {
        height: calc(100% - 57px) !important;
        ::v-deep .el-table__body-wrapper {
          height: calc(100% - 40px) !important;
          overflow-y: auto;
        }
      }
    }
    .search-bar {
      .search-bar-label {
        display: inline-block;
        min-width: 90px;
        text-align: right;
        margin-right: 5px;
        color: #303133;
        vertical-align: middle;
      }
    }
    .operate-btn {
      display: inline-block;
      width: 104px;
      text-align: center;
      padding: 0px;
      height: 32px;
      line-height: 32px;
      border-radius: 3px;
      border: none;
      margin-left: 10px;
      cursor: pointer;
    }
    .border {
      border: 1px solid #dcdfe6;
    }
    .icon-btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      color: #fff;
      line-height: 24px;
      text-align: center;
      padding: 0px;
      cursor: pointer;
      border-radius: 3px;
      margin-right: 8px;
    }
  }
  .dialoginfo {
    position: relative;
  }
  .w_340 {
    width: 340px;
  }
  .w_200 {
    width: 200px;
  }
  .CAdialog {
    min-height: 500px;
    padding: 20px 0px;
  }
}
::v-deep .el-dialog__wrapper {
  overflow: hidden;
}
@media screen and (max-width: 1336px) {
  .container {
    height: calc(100% - 145px) !important;
  }
}
</style>
