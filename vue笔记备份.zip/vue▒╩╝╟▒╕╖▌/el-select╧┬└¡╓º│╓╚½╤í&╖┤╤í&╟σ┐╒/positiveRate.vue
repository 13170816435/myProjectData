<template>
  <div class="padding10 f14">
    <div class="search-content" ref='searchRef'>
      <div class="search-item mb10">
        <div class="row mr20">
          <span>检查时间：</span>
          <el-date-picker
            v-model="searchObj.date_time"
            type="daterange"
            :clearable="false"
            align="right"
            unlink-panels
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="yyyy-MM-dd"
            size="small"
            class="flex-1"
            :picker-options="pickerOptions">
          </el-date-picker>
        </div>
        <div class="row mr20">
          <span class="w70">医疗机构：</span>
          <DistrictOrg ref="districtOrg" :orgLevel='true' style="display:inline-block" :useOrgFullName='false'></DistrictOrg> 
            <!-- <div v-if="systemType === 2 && idcasUserRole === 1" class="dib">
              <el-select v-model="searchObj.district_code" size="small" class="w120" clearable placeholder="请选择区域"  @change="changeDistrictCode">
                <el-option v-for="(item,index) in areaList"  :key="index" :label="item.district_name" :value="item.district_code"></el-option>
              </el-select>
              <el-select v-model="searchObj.level" size="small" class="w120" multiple clearable placeholder="请选择等级" >
                <el-option v-for="(item,index) in levelList"  :key="index" :label="item.name" :value="item.value"></el-option>
              </el-select>
              <el-select v-model="searchObj.org_code" size="small" class="flex-1 collapse-tags-select" collapse-tags placeholder="请选择机构" multiple clearable>
                <el-option v-for="(item,index) in orgList" :key="index" :label="item.org_name" :value="item.org_code"></el-option>
            </el-select>
            </div> 
            <el-select v-model="searchObj.org_code" size="small" class="flex-1 collapse-tags-select" collapse-tags placeholder="请选择机构" multiple clearable :disabled='idcasUserRole === 2' v-else>
              <el-option v-for="(item,index) in orgList" :key="index" :label="item.name" :value="item.code"></el-option>
            </el-select> -->
        </div>
        <div class="row mr20">
          <span class="w70" :class="systemType===4?'':''">指标：</span>
          <el-select v-model="searchObj.datum_schema" size="small" placeholder="请选择指标" class="flex-1">
            <el-option v-for="(item,index) in datum_schemaList" :key="index" :label="item.name" :value="item.value"></el-option>
          </el-select>
        </div>
        <div class="row">
          <el-button size="small" type="primary" @click="getList">统计</el-button>
          <el-button size="small"  @click="reset">重置</el-button>
          <CommonSave style="display:inline-block" pageName="positiveRate.search" ref="commonSearch" class="ml10" @refreshStatics="refreshStatics" @saveSearchData="saveSearchData" @otherClick='otherClick'></CommonSave>
          <span class="cur_point ml10 clr_main" @click="handleMore">
            <i class="iconfont icon-gaojichaxun"></i>
            <font class="ml5">{{moreSearch?'收起':'展开'}}</font>
          </span>
        </div>
      </div>
      <div class="mb10" v-show="moreSearch">
        <div class="search-item">
          <div class="row mr20">
            <span class="w70">检查类型：</span>
            <el-cascader
              v-model="searchObj.cascaderValue"
              filterable
              :options="examTypeArr"
              :props="props"
              clearable
              collapse-tags
              size="small"
              class="flex-1"
              style="width:230px">
            </el-cascader>
          </div>
          <div class="row mr20">
            <span class="w70">患者类别：</span>
            <el-select v-model="searchObj.patient_class" placeholder="请选择" multiple clearable collapse-tags size="small" class="flex-1 w260">
                <el-option v-for="(child_item,index) in patientClassArr" :key="index" :value="child_item.value" :label="child_item.name"></el-option>
            </el-select>
          </div>
          <div class="row mr20" v-if="isStatisticCategory">
            <!-- <span class="w70">项目分类：</span> -->
            <el-popover
              placement="top-start"
              width="400"
              trigger="hover">
              <div>
                <p>1、按照项目分类统计时，需先在数据字典的【项目分类】中配置对应字典值；</p>
                <p>2、建议按照项目分类维度统计时，统计时长不要超过1年，或会影响统计效率。</p>
                <!-- <p>3、当如果现场存在多项目的情况，黑白超|彩超，这种情况下，只能将数据统计到 黑白超|彩超，不能分别算在黑白超、彩超中</p> -->
              </div>
              <span class="w70"  slot="reference">项目分类<i class="iconfont icon-wenhao f14 clr_0a ml5 pointer"></i>：</span>
            </el-popover>
            <el-select v-model="searchObj.exam_body_part" placeholder="请选择" multiple collapse-tags filterable clearable size="small" class="flex-1 w260" :filter-method="dataFilter" @visible-change='visibleChange'>
              <el-option v-for="(child_item,index) in examBodyPartFilter" :key="index" :value="child_item.dic_name" :label="child_item.dic_name" :class="{'pt70':index===examBodyPartFilter.length-1}"></el-option>
              <div class="select_up pl20">
                <el-button type="text" v-on:click="selectAll">全选</el-button>
                <el-button type="text" v-on:click="selectReverse">反选</el-button>
                <el-button type="text" v-on:click="removeAll">清空</el-button>
              </div>
            </el-select>
          </div>
          <div class="row mr20">
            <el-checkbox v-model="searchObj.column_addup">列总计</el-checkbox>
          </div>
        </div>
      </div>
      <StatisticHeader ref="statisticHeader" class="mb10" :statisticHeaderObj="statisticHeaderObj" :paramCode="paramCode" @changeDateType="changeDateType" @handleSet="handleSet" @refashList='getList'>
        <template v-slot:statisticTip>
          <div class="mr5">
            <el-popover
              placement="top"
              title=""
              width="550"
              trigger="hover">
              <div class="pl10 pr10 pt10">支持配置阳性率的临界值，低于临界值的红色警告</div>
              <div class="pl10 pr10 pb10">报告数：已标注阴性、阳性及未标注（未知）的报告总数，阳性率=阳性数/报告数</div>
              <i class="iconfont icon-wenhao f14 clr_0a mr5" slot="reference"></i>
            </el-popover>
            <span>设置临界值（%）</span>
            <el-tooltip class="item" effect="dark" content="输入完成按Enter键保存" placement="top-start">
              <el-input v-model.number="criticalValue" controls-position="right" size="small"  @focus="showtips=true"
              @blur="showtips=false" @keyup.enter.native="onSave" class="w60"></el-input>
            </el-tooltip>
          </div>
        </template>
      </StatisticHeader>
    </div>
    <div class="table-content">
      <div class="mt10" ref="settlementTable">
        <uxGridTable
          :tableData="tableData"
          :columnconfig="columnconfig"
          :loading="tableLoading"
          :tableHeight="tableHet"
          :rowKey="'idd'"
          :defaultExpandAll="false"
          ref="tableModule"
          :cellClassNameSet="cellClassNameSet"
          @cellClick="cellClick">
        </uxGridTable>
      </div>
    </div>
    <StatisticFoot class="mt10" :statisticFootObj="statisticFootObj" ref="statisticFoot" :patientClassArr="patientClassArr"></StatisticFoot>
    <StatisticSet v-if="statisticSetVisible" :allConfigurationItem="allConfigurationItem"  :paramCode='paramCode' :iIstatisticItem="false" @closeStatisticSet = 'closeStatisticSet'></StatisticSet>
    <StatisticDetail v-if="statisticDetailDialog" :detailColumn='detailColumn' :detailSearchObj='detailSearchObj' pageName="positiveRate" @closeStatisticDetail="closeStatisticDetail"></StatisticDetail>
  </div>
</template>

<script>
import DistrictOrg from '@/components/common/district_org.vue'
import CommonSave from '@/components/statistic/commonSave.vue'
import StatisticHeader from '@/components/statistic/statisticHeader.vue'
import uxGridTable from '@/components/statisticTable/index.vue'
import StatisticSet from '@/components/statisticSet/index.vue'
import StatisticDetail from './modules/statisticDetail.vue'
import StatisticFoot from '@/components/statistic/statisticFoot.vue'
import {getCurrentYearTime, getCurrentMonthTime,getDefaultTime} from '@/utils/formattime.js'
import { getnew_DepartmentsList,getRelatedAgency } from '@/api/Public.js'
import {getCommonSearchListApi,setParamsItems} from '@/api/doctor_read/index.js'
import {getAreaList, getAreaInsitions} from '@/api/supervision/params.js'
import { getSystemType,getIdcasUserRole } from '@/utils/base.js'
import { getExamcntStatistic } from '@/api/system_manage/data-statistic.js'
import { qualityObservationList }   from '@/api/system_manage/overview.js'
import mixinsStatisticTable from './mixins/mixins_table_data.js'
export default {
  components: {
    DistrictOrg,
    CommonSave,
    StatisticHeader,
    uxGridTable,
    StatisticSet,
    StatisticDetail,
    StatisticFoot
  },
  mixins:[mixinsStatisticTable],
  data(){
    return{
      searchObj: {
        date_time: [],
        district_code: '',
        level: [],
        org_code: [],
        cascaderValue: [],
        patient_class: [],
        exam_body_part: [],
        datum_schema: 'exampositiveratio',
        row_schema: ['dept','examtype','patientclass'],
        segment_mode:2,
        column_addup: false,
      },
      criticalValue: '60',
      showtips:false,
      commonSet: null,
      datum_schemaList: [
        {
          name: '阳性率',
          value: 'exampositiveratio'
        },
        {
          name: '阳性数，阳性率',
          value: 'exampositivecnt.exampositiveratio'
        },
        {
          name: '报告数，阳性数，阳性率',
          value: 'examreportcnt.exampositivecnt.exampositiveratio'
        }
      ],
      orgList:[],
      areaList: [],
      levelList: [],
      examTypeArr: [],
      patientClassArr: [],
      examBodyPart: [],
      examBodyPartFilter:[],
      moreSearch: false,
      props: { multiple: true,checkStrictly: true},
      pickerOptions: {
        shortcuts: [
          {
            text: '最近三天',
            onClick(picker) {
              picker.$emit('pick', [getDefaultTime(3,-1)[0], getDefaultTime(1,-1)[0]]);
            }
          },
          {
            text: '最近一周',
            onClick(picker) {
              picker.$emit('pick', [getDefaultTime(7,-1)[0], getDefaultTime(1,-1)[0]]);
            }
          },
          {
            text: '本月',
            onClick(picker) {
              picker.$emit('pick', getCurrentMonthTime())
            }
          },
          {
            text: '本年',
            onClick(picker) {
              picker.$emit('pick', getCurrentYearTime());
            }
          }
        ]
      },
      systemType: getSystemType(),
      idcasUserRole:getIdcasUserRole(),
      statisticHeaderObj: {
        title: '报告阳性率统计',
        unit:'',
        segment_mode: 2,
        search_time: '',
        date_time: []
      },
      paramCode: '',
      // 表格数据
      tableData: [],
      columnconfig: [],
      tableLoading: false,
      tableHet: 500,
      // 配置表格自定义弹框
      statisticSetVisible: false,
      // 表格页脚显示
      statisticFootObj: {
        date_time:[],
        date_type:'检查时间',
        district_name:'',
        org_name: [],
        exam_type: [],
        patient_class: [],
        exam_body_part: []
      },
      // 详情
      statisticDetailDialog: false,
      detailColumn: [
        { label:'序号', type:'index',needMethod: true,width:'65px'},
        { label:'医疗机构', prop:'perform_org_name',minWidth:'160px'},
        { label:'患者姓名', prop:'patient_name',width:'80px'},
        { label:'性别', prop:'patient_sex_text',width:'50px'},
        { label:'年龄', prop:'patient_age_detail',width:'60px'},
        { label:'患者类别', prop:'patient_class_text',width:'80px'},
        { label:'检查号', prop:'accession_number',minWidth:'100px'},
        { label:'检查科室', prop:'perform_depart_name'},
        { label:'检查类型', prop:'exam_type',width:'80px'},
        { label:'检查项目', prop:'exam_item',width:'120px'},
        { label:'项目分类', prop:'exam_body_part',width:'120px'},
        { label:'检查状态', prop:'result_state',width:'80px'},
        { label:'检查时间', prop:'perform_time',width:'160px'},
        { label:'检查结果', prop:'abnormal_flags_text'}
      ],
      detailSearchObj: {},
      // 导出
      table_name: '报告阳性率统计',
      allConfigurationItem: [
        {dropCode:'district', dropName:'区域',dropIndex:0},
        {dropCode:'org', dropName:'机构',dropIndex:1},
        {dropCode:'dept', dropName:'检查科室',dropIndex:2},
        {dropCode:'examtype', dropName:'检查类型',dropIndex:3},
        {dropCode:'patientclass', dropName:'患者类别',dropIndex:4},
        {dropCode:'segment', dropName:'时间',dropIndex:5},
        {dropCode:'category', dropName:'项目分类',dropIndex:6},
        {dropCode:'statisticalcontent', dropName:'统计内容',dropIndex:7}
      ],
      isStatisticCategory: false
    }
  },
  watch: {
    'searchObj.date_time': {
      handler(val) {
        if(val && val.length) {
          this.$set(this.statisticHeaderObj, 'date_time', val)
        }
      },
      deep: true,
      immediate: true,
    },
  },
  /****
    报告阳性率页面
    主索引      系统管理员、机构管理员
    影像中心    系统管理员
    ******/
  created(){
    const namearr=this.$route.meta.systemname.split('_');
    this.paramCode=`${namearr[0]}.${namearr[1]}.positiveRate`
    this.searchObj.date_time = getCurrentYearTime()
    this.getexamType()
    this.getExamBodyPartList()
    this.$store.watch((state,getters)=>{
      if(state.configs.patientClass!==null){
        this.patientClassArr=state.configs.patientClass
      }
    })
  },
  mounted () { 
    this.getCommonSet()
    this.setStatisticHeader()
    this.setStatisticFoot()
    this.getTableHeight()
  },
  methods: {
    getTableHeight() {
      const headerHeight = 50
      const navHeight = 50
      const searchHeight = this.$refs.searchRef.clientHeight
      const footHeight = this.$refs.statisticFoot.$el.clientHeight 
      this.tableHet = document.body.clientHeight - headerHeight - navHeight - searchHeight - footHeight - 40
    },
    handleMore() {
      this.moreSearch = !this.moreSearch
      this.$nextTick(()=> {
        this.getTableHeight()
      })
    },
    // // 区域列表
    // getarea(){
    //   getAreaList().then(res=>{
    //     if(res.code===0){
    //       this.areaList = res.data || []
    //     }else{
    //       this.$message.error(res.msg)
    //     }
    //   })
    // },
    // changeDistrictCode() {
    //   this.searchObj.level = []
    //   this.searchObj.org_code = []
    //   this.getOrgs()
    // },
    //获取医疗机构
    // getOrgs(){
    //   const params = {
    //     district_code:this.searchObj.district_code,
    //     page_index: 1,
    //     page_size: 10000
    //   }
    //   this.levelList = []
    //   getAreaInsitions(params).then(res=>{
    //     if(res.code===0){
    //       this.orgList = res.data || []
    //       this.orgList.forEach(vm=> {
    //         if(this.levelList.findIndex(i=>i.value===vm.level)===-1) {
    //           this.levelList.push({
    //             name:vm.level,
    //             value:vm.level
    //           })
    //         }
    //       })
    //     }else{
    //       this.$message.error(res.msg)
    //       this.orgList=[]
    //     }
    //   }).catch(()=>{
    //     this.orgList=[]
    //   })
    // },
     //获取医疗机构
    // getOrgsList(){
    //   getRelatedAgency().then(res=>{
    //     if(res.code===0){
    //       this.orgList = res.data || []
    //     }else{
    //       this.$message.error(res.msg)
    //       this.orgList=[]
    //     }
    //   }).catch(()=>{
    //     this.orgList=[]
    //   })
    // },
    // 检查类型
    getexamType() {
      let params={
        dic_type_code: 'ExamDepart',
        define_value:'',
        system_id:sessionStorage.getItem('lastname'),
        organization_id:''
      };
      getnew_DepartmentsList(params).then(res=>{
        if(res.code===0){
          const resData  = res.data ||[]
          let arr = []
          for(const item of resData) {
            let childrenArr = []
            const children = []
            if(item.dic_extend) {
                childrenArr = item.dic_extend.split(',')
                for(const vm of childrenArr) {
                  children.push({
                      value:vm,
                      label:vm 
                  })  
                }
            }
            arr.push({
                value:item.dic_code,
                label:item.dic_name,
                children:children
            })
          }
          this.examTypeArr =  arr
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    getDeptExam(list) {
      let newArr = []
      if(list&&list.length) {
        list.forEach(item=>{
          if(item.length>0) {
            const index = newArr.findIndex(vm=> {return vm.dept_code === item[0]})
            if(index!==-1) {
              if(item[1]) {
                newArr[index].exam_type.push(item[1])
              }
            } else {
              if(item[1]) {
                newArr.push({
                  dept_code: item[0],
                  exam_type: [item[1]]
                })
              } else {
                newArr.push({
                  dept_code: item[0],
                  exam_type: []
                })
              }
            }
          }
        })
      }
      return newArr
    },
    getList() {
      let examType  = []
      let deptCode = []
      if(this.searchObj.cascaderValue&&this.searchObj.cascaderValue.length) {
        const newArr =  this.getDeptExam(this.searchObj.cascaderValue)
        if(newArr.length) {
          newArr.forEach(item=> {
            examType.push(item.exam_type)
            deptCode.push(item.dept_code)
          })
        }
      }
      let orgCode = []
      if(this.$refs.districtOrg.org_code&&this.$refs.districtOrg.org_code.length) {
        orgCode = this.$refs.districtOrg.org_code
      } else if(this.$refs.districtOrg.org_level&&this.$refs.districtOrg.org_level.length) {
        if(this.$refs.districtOrg.orgList.length) {
          this.$refs.districtOrg.orgList.forEach(vm=> {
            orgCode.push(vm.org_code)
          })
        }
      }
      const setObj=  JSON.parse(JSON.stringify(this.$refs.statisticHeader.getDefalut()))
      const params = {
        start_time: this.searchObj.date_time.length?this.searchObj.date_time[0]:"",
        end_time: this.searchObj.date_time.length?this.searchObj.date_time[1]:"",
        district_code:this.$refs.districtOrg.district_code,
        org_code: orgCode.join(),
        dept_code:deptCode.join(),
        exam_type:examType.join(';'),
        segment_mode: this.searchObj.segment_mode, // 时间年月日
        patient_class: this.searchObj.patient_class && this.searchObj.patient_class.length?this.searchObj.patient_class.join():"",
        exam_body_part: this.searchObj.exam_body_part && this.searchObj.exam_body_part.length? this.searchObj.exam_body_part.join():'',
        row_schema: setObj.entranceRowSchema, // 表格列
        column_schema:setObj.entranceColumnSchema + (this.searchObj.datum_schema !== 'exampositiveratio'?'.datum': ''),// 表格头
        datum_schema: this.searchObj.datum_schema, // 统计内容
        // column_addup:  this.searchObj.column_addup, //列要不要求和
        row_addup: true, //行要不要求和
      }
      // if(this.systemType===2&&this.idcasUserRole===1) { //主索引系统管理员
      //   params.district_code = this.searchObj.district_code
      //   params.org_code = this.searchObj.org_code&&this.searchObj.org_code.length?this.searchObj.org_code.join():''
      // }
      if(this.searchObj.column_addup) {
        // params.column_schema = 'total' +  (this.searchObj.datum_schema !== 'exampositiveratio'?'.datum': '')+ ';' + setObj.entranceColumnSchema + (this.searchObj.datum_schema !== 'exampositiveratio'?'.datum': '')
        params.column_schema = (setObj.entranceColumnSchema + (this.searchObj.datum_schema !== 'exampositiveratio'?'.datum': '') + ';') +(this.searchObj.datum_schema !== 'exampositiveratio'?'total.datum': 'total')
      }
      if(setObj.entranceColumnSchema.indexOf('category')!==-1 || setObj.entranceRowSchema.indexOf('category')!==-1) {
        this.isStatisticCategory = true
      } else {
        params.exam_body_part = ''
        this.isStatisticCategory = false
      }
      this.setStatisticHeader()
      this.setStatisticFoot()
      this.tableLoading = true
      this.columnconfig = []
      this.tableData = []
      qualityObservationList(params).then(res=> {
        if(res.code === 0) {
          const resData =  res.data
          const headerList = resData.column_header || []
          const rowList = resData.row_header || []
          const listData = resData.datum
          let columnconfig = []
          if (headerList.length) {
            const props ={prop:'head_value', label:'head_title', children:'children'}
            columnconfig = this.getHeaderTreeList(props,headerList)
            // if(this.searchObj.column_addup) {
            //   if(this.searchObj.datum_schema=== 'ExamCnt') { // 检查量
            //     columnconfig.unshift({
            //       label: '总计',
            //       prop:'total',
            //       index:0,
            //       minWidth:60
            //     }) 
            //   } else if(this.searchObj.datum_schema=== 'ExamCnt.UsedStorage') { // 检查量,存储量
            //     columnconfig.unshift({
            //       label: '总计',
            //       prop:'total',
            //       index:0,
            //       minWidth:60,
            //       children: [
            //         {
            //           label: '检查量',
            //           prop:'ExamCnt',
            //           index:0,
            //           minWidth:80,
            //         },
            //         {
            //           label: '存储量',
            //           prop:'UsedStorage',
            //           index:1,
            //           minWidth:120,
            //         }
            //       ]
            //     }) 
            //   } else if(this.searchObj.datum_schema=== 'ExpectedTotalExamCnt.ExpectedExamCnt.CollectedExamCnt.CollectedExamRatio') {
            //     columnconfig.unshift({
            //       label: '总计',
            //       prop:'total',
            //       index:0,
            //       minWidth:60,
            //       children: [
            //         {
            //           label: '检查总量',
            //           prop:'ExpectedTotalExamCnt',
            //           index:0,
            //           minWidth:80,
            //         },
            //         {
            //           label: '已上云量',
            //           prop:'ExpectedExamCnt',
            //           index:1,
            //           minWidth:80,
            //         },
            //         {
            //           label: '应上云量',
            //           prop:'CollectedExamCnt',
            //           index:2,
            //           minWidth:80,
            //         },
            //         {
            //           label: '云影像率',
            //           prop:'CollectedExamRatio',
            //           index:3,
            //           minWidth:80,
            //           percent: true,
            //           precision: 100
            //         }
            //       ]
            //     }) 
            //   }
            // }
            const fixList = [
              { label:'统计维度',align:'left',fixed:true,prop:'statisticalName',width:300,type:'treeNode'}
            ]
            this.columnconfig = [...fixList,...columnconfig]
          } else {
            this.columnconfig = []
          }
          if(rowList.length) {
            rowList.push({
              head_title: '总计',
              head_value:'total',
              index:0
            })
            const flatHeadList = this.getFlatList(columnconfig) // 平铺数据
            const fixColumnList =  this.getTableRowTreeList(rowList)
            const list = this.getTableTree(fixColumnList,flatHeadList,listData) // 处理表格数据
            this.tableData = list
            this.$refs.tableModule.$refs.plxTable.reloadData(list) // 表格赋值
          } else {
            this.tableData = []
            this.$refs.tableModule.$refs.plxTable.reloadData([]) // 表格赋值
          }
        } else {
          this.columnconfig = []
          this.tableData = []
          this.$refs.tableModule.$refs.plxTable.reloadData([]) // 表格赋值
          this.$message.error(res.msg)
        }
        this.tableLoading = false
      }).catch(err=> {
        this.columnconfig = []
        this.tableData = []
        this.$refs.tableModule.$refs.plxTable.reloadData([]) // 表格赋值
        this.$message.error(err)
        this.tableLoading = false
      })
      this.$set(this.statisticHeaderObj, 'title', this.table_name )
    },
    reset() {
      this.searchObj = {
        date_time: getCurrentYearTime(),
        cascaderValue:[],
        patient_class:[],
        exam_body_part:[],
        district_code: '',
        org_code: [],
        column_addup: false,
        segment_mode: 2,
        datum_schema: 'exampositiveratio',
      }
      // if(this.systemType === 2) {
      //   if(this.idcasUserRole===1) { // 主索引系统管理员
      //     this.searchObj.district_code = ''
      //     this.searchObj.org_code = []
      //   } else if(this.idcasUserRole===2) { // 主索引机构管理员
      //     this.searchObj.district_code = ''
      //     this.searchObj.org_code = sessionStorage.getItem("org_code")? [sessionStorage.getItem("org_code")]:[]
      //   }
      //   this.getOrgs()
      // } else { 
      //   this.searchObj.org_code = []
      //   this.getOrgsList()
      // }
      if(this.idcasUserRole === 2) { // 机构管理员
        this.$refs.districtOrg.org_code = sessionStorage.getItem("org_code")? [sessionStorage.getItem("org_code")]:[]
      } else {
        this.$refs.districtOrg.district_code = ''
        this.$refs.districtOrg.org_code = []
        this.$refs.districtOrg.org_level = []
      }
      this.$set(this.statisticHeaderObj,'segment_mode', 2)
      this.getList()
    },
    // 切换常用条件
    refreshStatics(val) {
      if(val) {
        this.searchObj = {...val}
        if(this.searchObj.district_code) {
          this.$refs.districtOrg.district_code = this.searchObj.district_code
        }
        if(this.searchObj.org_level&&this.searchObj.org_level.length) {
          this.$refs.districtOrg.org_level = this.searchObj.org_level
        }
        if(this.searchObj.org_code && this.searchObj.org_code.length) {
          this.$refs.districtOrg.org_code = this.searchObj.org_code
        }
        this.$set(this.statisticHeaderObj,'segment_mode', this.searchObj.segment_mode || 2)
      } else {
        this.searchObj = {
          date_time: [],
          district_code: '',
          org_code: [],
          cascaderValue: [],
          patient_class: [],
          exam_body_part:[],
          row_schema: [],
        }
      }
      this.getList()
    },
    saveSearchData() {
      this.searchObj.district_code = this.$refs.districtOrg.district_code
      this.searchObj.org_code = this.$refs.districtOrg.org_code
      this.searchObj.org_level = this.$refs.districtOrg.org_level
      this.$refs.commonSearch.subSearchCondition(this.searchObj)
    },
    otherClick(type) {
      if(type ==='export') {
        this.handleExport() // 导出方法
      }
    },
    // 表格头部组件
    changeDateType(val) {
      this.searchObj.segment_mode = val
      this.$set(this.statisticHeaderObj,'segment_mode', val)
    },
    // 保存临界值
    onSave() {
      //保存临界值
      const data={
        param_name: '报告阳性率临界值',
        system_id:'',
        param_code: this.paramCode + '.critical',
        param_value:JSON.stringify({'criticalValue': this.criticalValue}),
        match_roule:1|2|4
      }
      setParamsItems(data).then(res=>{
        if(res.code===0){
          this.$message.success("保存成功！")
          this.getCommonSet()
        }else{
          this.$message.error(res.msg)
        }
      }).catch(err=>{
        this.$message.error(err.message)
      })
    },
    //获取临界值
    getCommonSet(){
      const userinfo = this.$store.state.app.org_msg.profile;
      const params={
        param_code: this.paramCode + '.critical',
        system_id:'',
        user_id: userinfo.sub,
      };
      getCommonSearchListApi(params).then(res=>{
        if(res.code===0){
          if(res.data&&res.data.length) {
            this.commonSet = JSON.parse(res.data[0].param_value)
            this.criticalValue=this.commonSet.criticalValue || 60
          } else {
            this.criticalValue =  60
          }
        }else{
          this.criticalValue= 60
        }
      }).catch(err=>{
        this.searchObj.threshold=10
        this.$message.error(err.message)
      })
    },
    // 设置表头组件
    setStatisticHeader() {
      this.statisticHeaderObj = {
        title: this.table_name,
        unit:'',
        date_time:this.searchObj.date_time,
        segment_mode: this.searchObj.segment_mode,
        search_time: new Date( +new Date() + 8 * 3600 * 1000 ).toJSON().substr(0,19).replace("T"," "),
      }
    },
     //设置foot组价
    setStatisticFoot() {
      let district_name = ''
      let org_name = []
      if(this.$refs.districtOrg.district_code) {
        district_name = this.$refs.districtOrg.areaList.find(item=> {return item.code === this.$refs.districtOrg.district_code}).name
      }
      if(this.idcasUserRole === 2) {
        org_name = sessionStorage.getItem("org_name")? [sessionStorage.getItem("org_name")]:[]
      } else {
        if(this.$refs.districtOrg.org_code && this.$refs.districtOrg.org_code.length) {
          this.$refs.districtOrg.org_code.forEach(vm=> {
            const obj = this.$refs.districtOrg.orgList.find(item=> {
              return item.org_code === vm
            })
            if(obj) {
              org_name.push(obj.org_name)
            }
          })
        }
      }
      let cascaderValue = []
      if(this.searchObj.cascaderValue && this.searchObj.cascaderValue.length) {
        this.searchObj.cascaderValue.forEach(item=> {
          if(item&&item.length) {
            const obj = cascaderValue.find(vm=> {return vm.dept_code === item[0]})
            const itemObj = this.examTypeArr.find(k=>{return k.value === item[0]})
            if(obj) {
              if(item[1]) {
                obj.exam_type.push(item[1])
              }
            } else {
              cascaderValue.push({
                dep_name: itemObj.label,
                dept_code: item[0],
                exam_type: item[1]?[item[1]]: []
              })
            }
          }
        })
      }
      this.statisticFootObj = {
        date_time:this.searchObj.date_time,
        date_type:'检查时间',
        district_name:'',
        level:'',
        org_name: [],
        exam_type: cascaderValue,
        patient_class: this.searchObj.patient_class,
        exam_body_part: this.searchObj.exam_body_part
      }
      if(this.systemType === 2) {
        this.statisticFootObj.district_name = district_name
        this.statisticFootObj.level = this.$refs.districtOrg.org_level
        this.statisticFootObj.org_name = org_name
        if(this.idcasUserRole === 2) {
          delete this.statisticFootObj.district_name
          delete this.statisticFootObj.level
        }
      } else {
        this.statisticFootObj.level =  this.$refs.districtOrg.org_level
        this.statisticFootObj.org_name = org_name
        delete this.statisticFootObj.district_name
      }
    },
    // 点击详情
    cellClick(row, column, cell, event) {
      const reg = /^0{1}(\.\d*)|(^[1-9][0-9]*)+(\.\d*)?$/   // 非0的数字类型
      const columnObjDetail = this.getTreeObj(column.property, this.columnconfig) // 获取表格列信息
      if(columnObjDetail.percent) { // 百分数
        const value = String(row[column.property]).replace(/%/, "")
        if(!reg.test(Number(value))) {
          return false
        }
      } else {
        if(!reg.test(row[column.property]) || Number(row[column.property])===0) {
          return false
        }
      }
      this.detailSearchObj = {
        start_time: '',
        end_time: '',
        dept_code: '',
        exam_type: '',
        org_code: '',
        patient_class: '',
        exam_body_part: '',
        abnormal_flags: 0
      }
      if(this.searchObj.datum_schema === 'exampositiveratio') {
        this.detailSearchObj.abnormal_flags = 1
      }
      const obj = {org:'org_code', dept:'dept_code',examtype:'exam_type',patientclass:'patient_class'}
      // 横轴方向选中的数据
      const rowKey = obj[row.head_code]
      const rowValue = row.head_value
      if(rowKey) {
        const arr = this.getAllParentNode(row.idd,this.tableData)
        if(arr&&arr.length) {
          arr.forEach(vm=> {
            if(obj[vm.head_code]) {
              this.detailSearchObj[obj[vm.head_code]]= vm.head_value
            }
          })
        } else {
          this.detailSearchObj[rowKey] = rowValue
        }
      } else {
        if(row.head_code==='year' || row.head_code==='month' || row.head_code==='week' || row.head_code==='day') {
          this.detailSearchObj.start_time = row.segment_start
          this.detailSearchObj.end_time = row.segment_end
        } else if(row.head_code==='district') { // 机构
          this.detailSearchObj.org_code = row.org_code_csv
        } else if(row.head_code==='category') {
          this.detailSearchObj.exam_body_part = row.head_title
        }
      }
      //处理横轴（表头）对应的字段数据
      const columnProprtty = column.property
      // 通过property找数据的ids，通过ids去找所有父级
      const columnObj = this.getTreeObj(columnProprtty,this.columnconfig)
      if(columnObj) {
        const arr = this.getAllParentNode(columnObj.idd,this.columnconfig)
        if(arr&&arr.length) {
          arr.forEach(vm=> {
            if(obj[vm.head_code]) { // 机构 科室患者类别检查类型
              this.detailSearchObj[obj[vm.head_code]]= vm.head_value
            } else  {
              if(vm.head_code==='year' || vm.head_code==='month' || vm.head_code==='week' || vm.head_code==='day') {
                this.detailSearchObj.start_time = vm.segment_start
                this.detailSearchObj.end_time = vm.segment_end
              } else  if(vm.head_code==='datum'){
                if(vm.head_value === 'exampositiveratio' || vm.head_value ==='exampositivecnt') {
                  this.detailSearchObj.abnormal_flags= 1
                } else {
                  delete this.detailSearchObj.abnormal_flags
                }
              }else if(vm.head_code==='district') { // 机构
                if(!this.detailSearchObj.org_code) { // 表头只要单个区域时
                  this.detailSearchObj.org_code = vm.org_code_csv
                }
              } else if(vm.head_code==='category') {
                this.detailSearchObj.exam_body_part = vm.head_title
              }
            }
          })
        } 
      } 
      // 横纵轴没有涉及到字段，要将搜索条件传值
      // 区域机构
      if(this.systemType===1 || this.systemType === 4) { //影像中心
        if(!this.detailSearchObj.org_code) {
          if(this.$refs.districtOrg.org_code &&this.$refs.districtOrg.org_code.length) { // 筛选条件选择了机构
            this.detailSearchObj.org_code = this.$refs.districtOrg.org_code.join()
          }
        }
      } else if(this.systemType===2){ // 主索引
        if(this.idcasUserRole === 1) { // 系统管理员
          if(!this.detailSearchObj.org_code) {
            if(this.$refs.districtOrg.org_code &&this.$refs.districtOrg.org_code.length) { // 筛选条件选择了机构
              this.detailSearchObj.org_code = this.$refs.districtOrg.org_code.join()
            } else {
              if(this.$refs.districtOrg.orgList.length) {
                let orgCode = []
                this.$refs.districtOrg.orgList.forEach(vm=> {
                  orgCode.push(vm.org_code)
                })
                this.detailSearchObj.org_code = orgCode.join()
              }
            }
          }
          
        } else { // 机构管理员
          if(!this.detailSearchObj.org_code) {
            if(this.$refs.districtOrg.org_code &&this.$refs.districtOrg.org_code.length) { // 筛选条件选择了机构
              this.detailSearchObj.org_code = this.$refs.districtOrg.org_code.join()
            }
          }
        }
      }
      // 科室检查类型
      let examType  = []
      let deptCode = []
      if(this.searchObj.cascaderValue&&this.searchObj.cascaderValue.length) { 
        // this.searchObj.cascaderValue.forEach(vm=> {
        //   if(vm&&vm.length===2) {
        //     if(!depart_code.find(i=> {return i===vm[0]})) {
        //       depart_code.push(vm[0])
        //     }
        //     if(!exam_type.find(i=> {return i===vm[0]})) {
        //       exam_type.push(vm[1])
        //     }
        //   }
        //   if(vm&&vm.length===1) {
        //     if(!depart_code.find(i=> {return i===vm[0]})) {
        //       depart_code.push(vm[0])
        //     }
        //   }
        // })
        if(this.searchObj.cascaderValue&&this.searchObj.cascaderValue.length) {
          const newArr =  this.getDeptExam(this.searchObj.cascaderValue)
          if(newArr.length) {
            newArr.forEach(item=> {
              examType.push(item.exam_type)
              deptCode.push(item.dept_code)
            })
          }
        }
      }
      // 患者类别
      if(!this.detailSearchObj.patient_class) {
        this.detailSearchObj.patient_class = this.searchObj.patient_class &&this.searchObj.patient_class.length?this.searchObj.patient_class.join():''
      }
      // 时间
      if(!this.detailSearchObj.start_time || !this.detailSearchObj.end_time) {
        this.detailSearchObj.start_time = this.searchObj.date_time.length?this.searchObj.date_time[0]:""
        this.detailSearchObj.end_time = this.searchObj.date_time.length?this.searchObj.date_time[1]:""
      }
      if(!this.detailSearchObj.dept_code) {
        this.detailSearchObj.dept_code = deptCode.join()
        if(!this.detailSearchObj.exam_type) {
          this.detailSearchObj.exam_type = examType.join(';')
        }
      } else { // 点击数据包含了科室信息
        if(!this.detailSearchObj.exam_type) { //点击信息没有包含检查类型信息
          const index =  deptCode.findIndex(i=> {
            return i=== this.detailSearchObj.dept_code
          })
          if(deptCode[index]&&deptCode[index].length) {
            this.detailSearchObj.exam_type = examType[index].join()
          }
        }
      }
      if(!this.detailSearchObj.exam_body_part) {
        this.detailSearchObj.exam_body_part = this.searchObj.exam_body_part && this.searchObj.exam_body_part.length ? this.searchObj.exam_body_part.join() : ''
      }
      if(this.isStatisticCategory) { // 存在项目分类的统计维度
        if(!this.detailSearchObj.exam_body_part) {
          let allExamBodyPartList = []
          if(this.examBodyPart.length) {
            this.examBodyPart.forEach(vm=> {
              allExamBodyPartList.push(vm.dic_name)
            })
          }
          this.detailSearchObj.exam_body_part = allExamBodyPartList.join()
        }
      } else {
        this.detailSearchObj.exam_body_part = ''
      }
      this.statisticDetailDialog = true
    },
    closeStatisticDetail() {
      this.statisticDetailDialog = false
    },
    handleSet() {
      this.statisticSetVisible=true
    },
    closeStatisticSet(bol) {
      this.statisticSetVisible = false
      if(bol) {
        this.$refs.statisticHeader.getSetList()
      }
    },
    // 获取项目分类
    getExamBodyPartList() {
      let params={
        dic_type_code: 'PerformCategory',
        define_value:'',
        system_id:sessionStorage.getItem('lastname'),
        organization_id:''
      };
      getnew_DepartmentsList(params).then(res=>{
        if(res.code===0){
          this.examBodyPart = res.data || []
          this.examBodyPartFilter = res.data || []
        } else {
          this.examBodyPart = []
          this.examBodyPartFilter = []
          this.$message.error(res.msg)
        }
      })
    },
    // 搜索查询
    dataFilter(val) {
      if(val) {
        this.examBodyPartFilter = this.examBodyPart.filter((item) => {
          if (!!~item.dic_name.indexOf(val) || !!~item.dic_name.toUpperCase().indexOf(val.toUpperCase())) {
            return true
          }
        })
      } else {
        this.examBodyPartFilter = this.examBodyPart
      }
    },
    visibleChange(bol) {
      this.examBodyPartFilter = this.examBodyPart
    },
    // 全选
    selectAll() {
      this.examBodyPartFilter.map(item=> {
        if(!this.searchObj.exam_body_part.includes(item.dic_name)) {
          this.searchObj.exam_body_part.push(item.dic_name)
        }
      })
    },
    // 反选
    selectReverse() {
      let arr = []
      this.examBodyPartFilter.map(item=> {
        let index = this.searchObj.exam_body_part.indexOf(item.dic_name)
        if(index!==-1) {

        } else {
          arr.push(item.dic_name)
        }
      })
      this.searchObj.exam_body_part = arr
    },
    removeAll() {
      this.searchObj.exam_body_part = []
    }
  },
}
</script>
<style scoped lang="less">
.search-item{
  min-width: 1230px;
}
.search-item .row{
  display: inline-block;
}
.search-item .row .flex-1{
  max-width: 230px;
}
.search-item ::v-deep .el-cascader__search-input {
  min-width: 20px;
}
.select_up{
  position: absolute;
  background: #fff;
  width: calc(100% - 20px);
  bottom: 0px;
}
.pt70{
  padding-bottom: 70px;
}
</style>