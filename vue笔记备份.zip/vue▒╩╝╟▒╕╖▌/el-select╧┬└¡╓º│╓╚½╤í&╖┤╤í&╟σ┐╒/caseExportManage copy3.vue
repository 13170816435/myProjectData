<template>
  <div class="caseExportCon">
    <div class="title-bar flex_row">
      <div class="crumbsCon">
        <span class="title-name clr_303">
          <i class="iconfont icondingwei mr10"></i>病例导出<i
            class="iconfont iconzhankaishouqi"
          ></i>导出管理
        </span>
      </div>
      <div class="tr col">
        <span @click="goBack" class="clr_0a pointer">
          <i class="iconfont iconfanhui pr5"></i>返回
        </span>
      </div>
    </div>
  
    
    <div class="caseExportContainer">
      <div class="importTip">
        <span class="headIcon"></span>
        <span class="importTipTit">导出授权</span>
        <span class="importTipText">病例导出默认需要管理员审批，以下配置条件下数据允许用户申请后导出，无需等待审批；权限控制重复时，优先按照更小权限，其次按照配置顺序生效。</span>
      </div>
      <div class="searchQuery flex_row">
         <div class="queryCon ml10">
          <span class="search-bar-label">医疗机构：</span>
          <el-select
              @change="changeInstitute"
              filterable
              clearable
              v-model="searchData.institute_id"
              placeholder=""
              class="ele-select_32 width_130_select"
              style="width:200px"
          >
              <el-option
              v-for="(item,index) in orgOptions"
              :key="index"
              :label="item.name"
              :value="item.id"
              ></el-option>
          </el-select>

          <span class="search-bar-label ml10">检查科室：</span>
          <el-select
              @change="beganGetExportAuthList"
              filterable
              clearable
              v-model="searchData.office_id"
              :disabled="depmentlist.length === 0"
              placeholder=""
              class="ele-select_32 width_130_select"
              style="width:200px"
          >
              <el-option
              v-for="(item,index) in depmentlist"
              :key="index"
              :label="item.name"
              :value="item.id"
              ></el-option>
          </el-select>
          <span class="search-bar-label ml10">审批人：</span>
          <el-input class=""
            style="width:160px"
            v-on:keyup.enter.native=search
            v-model="searchData.user_id"
            placeholder="请输入审批人姓名">
          </el-input>
         </div>
         
         <div class="operateBtnCon flex_1 tr">
          <span
            class="userListoperate-btn clr_ff bg_0a mr10"
            @click="updatePermission"
            v-if="!isUpdate"
            ><i class="iconfont iconbianji mr5"></i>编辑</span
          >
         
          <span
            class="userListoperate-btn clr_ff bg_f5 mr10"
            @click="cancelUpdatePermission"
            v-if="isUpdate"
            ><i class="iconfont iconliebiao_shenhebutongguo mr5"></i>取消</span
          >

          <span
            class="userListoperate-btn clr_ff bg_0a mr10"
            @click="savePermissionSet"
            v-if="isUpdate"
            ><i class="iconfont iconliebiao_shenhetongguo mr5"></i>保存</span
          >

          <span
            class="userListoperate-btn clr_ff bg_e6 mr10"
            @click="addConfig"
            v-if="isUpdate"
            ><i class="iconfont iconxinzeng mr5"></i>新增</span
          >
         </div>

      </div>
     <div class="caseExportContent">
      <div
        class="allInspect clear"
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-background="rgba(255,255,255,0.6)"
        v-bind:class="{ noTableData: configList.length == 0 }"
      >
        <el-table
          :data="configList"
          border
          stripe
          height="100%"
          ref="tableAutoScroll"
          highlight-current-row
          header-row-class-name="strong"
        >
          <el-table-column
            fixed="left"
            align="center"
            type="index"
            label="序号"
            width="55"
          >
          </el-table-column>
          <el-table-column label="操作" width="80" fixed="left">
            <template slot-scope="scope">
              <span class="clr_da pointer" @click="deleteThisPowerSet(scope.row,scope.$index)"
                >删除</span
              >
            </template>
          </el-table-column>
          
          <el-table-column
          label="机构"
          width="400"
        >
          <template slot-scope="scope">
            <span v-if="!isUpdate">{{ scope.row.ca_state_desc }}</span>
            <el-select
              v-else
              filterable
              clearable
              multiple
              collapse-tags
              @change="handleOrgChange(scope.row)"
              :disabled="scope.row.disabled"
              v-model="scope.row.institution_ids"
              placeholder=""
              class="ele-select_32 width_130_select"
              style="width:389px"
              >
              <el-option
              v-for="(item,index) in orgOptions"
              :key="index"
              :label="item.name"
              :value="item.id"
              ></el-option>
          </el-select>
          </template>
        </el-table-column>

        <el-table-column
          label="科室"
          width="240"
        >
          <template slot-scope="scope" >
            <span v-if="!isUpdate">{{ scope.row.ca_state_desc }}</span>

            <el-select v-else v-model="scope.row.office_ids" 
              placeholder="请选择" multiple collapse-tags clearable filterable size="small" 
              class="flex-1 w180 collapse-tags-select" :filter-method="(val) => dataFilter(val, scope.$index)" @visible-change='(isVisible) => visibleChange(isVisible, scope.$index)'>
              <el-option v-for="(child_item,index) in deptOptions"
               :key="index" 
               :value="child_item.office_id"
               :label="`${child_item.office_name}`" 
               :class="{'pt70':index===deptOptions.length-1}">
                {{ child_item.office_name }}( {{child_item.institution_name}} )
              </el-option>
              <div class="select_up pl20">
                <el-button type="text" v-on:click="(val) => selectAll(val,scope.$index)">全选</el-button>
                <el-button type="text" v-on:click="(val) => selectReverse(val,scope.$index)">反选</el-button>
                <el-button type="text" v-on:click="(val) => removeAll(val,scope.$index)">清空</el-button>
              </div>
            </el-select>

          </template>
        </el-table-column>

        <el-table-column
          label="审批"
          width="200"
        >
          <template slot-scope="scope">
            <span v-if="!isUpdate">{{ scope.row.ca_state_desc }}</span>
            <el-radio-group v-if="isUpdate" v-model="scope.row.isChecked" class="radioBox" size="medium">
              <el-radio :label="true">需审批</el-radio>
              <el-radio :label="false">无需审批</el-radio>
           </el-radio-group>
          </template>
        </el-table-column>


        <el-table-column
          label="审批人"
        >
          <template slot-scope="scope">
            <span v-if="!isUpdate">{{ scope.row.ca_state_desc }}</span>
            <el-select
              v-else
              filterable
              clearable
              multiple
              collapse-tags
              v-model="scope.row.check_user_ids"
              placeholder=""
              class="ele-select_32 width_130_select"
              style="width:229px"
              >
              <el-option
              v-for="(item,index) in orgOptions"
              :key="index"
              :label="item.name"
              :value="item.id"
              ></el-option>
           </el-select>
          </template>
        </el-table-column>

        </el-table>
      </div>
      <!-- <div class="blockPage">
        <pagination-tool
          :total="totalImportOutNum"
          :page.sync="searchData.offset"
          :limit.sync="searchData.limit"
          @pagination="beganGetExportAuthList"
        />
      </div> -->
    </div>
  </div>
  </div> 
</template>
<script>
import { UnshiftToArray} from '@/components/commonJs'
import caseConditionInquery from "./components/caseConditionInquery";
import CommonTable from '@/components/common/CommonTable'
import PaginationTool from '@/components/common/PaginationTool'
import { getInstitutionListLite, getOfficesLite } from '@/api/commonHttp'
import { getCaseExportAuthList,getAllAuthOfficeList, getImportDetail, deleteImoprtPermission, saveImoprtPermission } from "@/api/platform_costomer/caseExport";

let configId = 0
export default {
   components: {
    caseConditionInquery,
    CommonTable,
    PaginationTool
   },
   data () {
    return {
      loading:false,
      searchData: {
        institute_id: "",
        office_id: "",
        user_id: "",
      },
      // 表头字段
      propData: [
        { prop: "institute_name", label: "机构", width: 400 },
        { prop: "inspect_office", label: "科室", width: 240 },
        { prop: "inspect_num", label: "审批", width: 200 },
        { prop: "operator_name", label: "审批人", },
      ],
      orgOptions: [],
      depmentlist: [],
      isUpdate: false,
      

      deptOptions: [
        { id: 101, orgId: 1, name: '科室A-1' },
        { id: 102, orgId: 1, name: '科室A-2' },
        { id: 201, orgId: 2, name: '科室B-1' },
        { id: 202, orgId: 2, name: '科室B-2' }
      ],
      // 配置列表
      configList: [],
      // 全局锁定资源
      lockedDepts: new Set()
    }
  },
  computed: {
    // 可用机构列表
    availableOrgs() {
      return this.orgOptions.filter(org => {
        const total = this.getOrgDeptCount(org.id)
        const used = this.getLockedDeptCount(org.id)
        return used < total
      })
    }
  },
  watch: {
    configList: {
      deep: true,
      handler() {
        this.updateLockStatus()
      }
    }
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    // 编辑
    updatePermission () {
      this.isUpdate = true
    },
    // 取消编辑
    cancelUpdatePermission () {
      this.isUpdate = false
      this.beganGetExportAuthList()
    },
    // 保存权限设置
    async savePermissionSet () {
      const self = this
      const params = {
        //tenancy_id: '',
        auth: [],
      }
      self.configList.forEach((item) => {
        let obj = {
          state: item.state,
          offices: [],
          user_ids: item.user_ids,
        }
        if (item.office_ids.length != 0) {
          item.office_ids.forEach((one) => {
            let officeObj = {
              institution_id: self.getInstituteId(one),
              office_id: one,
            }
            obj.offices.push(officeObj)
          })
        }
        
        params.auth.push(obj)
      })
      const res = await saveImoprtPermission({tenancy_id:'1288720863696261120'});
      if (res.code === 0) {
        this.$message({type: "success",message: "保存成功！",});  
        // 保存成功后 重新获取
        this.beganGetExportAuthList()
      } else {
        this.$message.error(res.msg);
      }
    },
    // 删除某条导出申请
    deleteThisPowerSet (row,index) {
      if (row.isAdd) {
        this.configList.splice(index,1)
        return false
      }
      this.$confirm(
        '<i class="iconfont icontishi clr_e6 mr5"></i>确定要删除该审核配置？',
        "删除用户",
        {
          distinguishCancelAndClose: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
        }
      ).then(() => {
        this.beganDelPowerSet(row.id);
      });
    },
    // 删除导出权限配置
    async beganDelPowerSet () {
      const res = await deleteImoprtPermission({tenancy_id:'1288720863696261120'});
      if (res.code === 0) {
        // 保存成功后 重新获取
        this.$message({type: "success",message: "删除成功！",});
        this.beganGetExportAuthList()
      } else {
        this.$message.error(res.msg);
      }
    },
    // 获取导出列表
    async beganGetExportAuthList () {
      const self = this;
      self.loading = true
      self.configList = []
      const res = await getCaseExportAuthList();
      if (res.code === 0) {
        self.loading = false;
        const result = res.data
        if (result.length != 0) {
          result.forEach((item) => {
            const obj = {}
            obj.state = item.state
            obj.user_ids = item.user_ids
            obj.id = ++configId
            obj.institution_ids = []
            obj.office_ids = []
            obj.officeList = self.deptOptions
            obj.disabled = false
            self.configList.push(obj)
          });
        }
        
      } else {
        self.loading = false;
        self.$message.error(res.msg);
      }
    },
    // 改变医疗机构
    changeInstitute (val) {
      this.getOfficesLiteFn(val)
      this.beganGetExportAuthList()
    },
   // 获取机构列表
   async getInstitutionListLiteFn() {
    const res = await getInstitutionListLite();
    if (res.code === 0) {
      this.orgOptions = UnshiftToArray(res.data);
    } else {
      this.$message.error(res.msg);
    }
   },
   // 获取科室列表
   async getOfficesLiteFn (id) {
    var _url = '/offices/lite?institution_id=' + id
    const res = await getOfficesLite(_url)
    if (res.code === 0) {
      this.depmentlist = UnshiftToArray(res.data)
    } else {
      this.$message({ message: `${res.msg}`, type: 'error' })
    }
   },
   // 获取机构的名字
   getInstituteName (instituteId) {
    let instituteName = ''
    this.orgOptions.forEach((item)=> {
      if (item.id == instituteId) {
        instituteName = item.name
      }
    })
    return instituteName
   },
   // 通过科室id 去找机构id
   getInstituteId (officeId) {
    let instituteId = ''
    this.deptOptions.forEach((item)=> {
      if (item.office_id == officeId) {
        instituteId = item.institution_id
      }
    })
    return instituteId
   },
   // 获取授权所有科室
   async beganGetAllAuthOfficeList () {
    const res = await getAllAuthOfficeList()
    if (res.code === 0) {
      this.deptOptions = res.data
    } else {
      this.$message({ message: `${res.msg}`, type: 'error' })
    }
   },
  // 科室下拉方法结束
  // 搜索查询
  dataFilter(value,index) {
    console.log('index',index)
    const tableIndex = index
    if(value) {
      this.configList[tableIndex].officeList = this.deptOptions.filter((item) => {
        if (!!~item.office_name.indexOf(value) || !!~item.office_name.toUpperCase().indexOf(value.toUpperCase())  || !!~item.institution_name.indexOf(value) || !!~item.institution_name.toUpperCase().indexOf(value.toUpperCase())) {
          return true
        }
      })
    } else {
      this.configList[tableIndex].officeList = this.deptOptions
    }
  },
  visibleChange(bol,index) {
    console.log('option',index)
    //this.configList[index].officeList = this.configList[index].officeCopyList
  },
  // 全选
  selectAll(e,index) {
    this.configList[index].officeList.map(item=> {
      if(!this.configList[index].office_ids.includes(item.office_id)) {
        this.configList[index].office_ids.push(item.office_id)
      }
    })
  },
  // 反选
  selectReverse(e,tableIndex) {
    
    let arr = []
    this.configList[index].officeList.map(item=> {
      let index = this.configList[tableIndex].office_ids.indexOf(item.office_id)
      if(index!==-1) {

      } else {
        arr.push(item.office_id)
      }
    })
    this.configList[tableIndex].office_ids = arr
  },
  removeAll(e,index) {
    this.configList[index].office_ids = []
  },
  // 科室下拉方法结束

  
    // 新增配置项
    addConfig() {
      this.configList.push({
        id: ++configId,
        institution_ids: [],
        office_ids: [],
        officeList: this.deptOptions,
        disabled: false,
        state: '',
        user_ids: [],
      })
    },

    // 删除配置项
    removeConfig(index) {
      const removed = this.configList.splice(index, 1)
      // 释放已选科室
      removed.office_ids.forEach(id => this.lockedDepts.delete(id))
      this.updateLockStatus()
    },

    // 处理机构变化
    handleOrgChange(row) {
      row.office_ids = []
      this.updateLockStatus()
    },
    // 获取可用科室
    getAvailableDepts(row) {
      const orgDepts = this.deptOptions.filter(d => 
        row.institution_ids.includes(d.institution_id)
      )
      console.log('orgDepts',orgDepts.filter(d => !this.lockedDepts.has(d.office_id)))
      return orgDepts.filter(d => !this.lockedDepts.has(d.office_id))
    },
    // 检查机构是否禁用
    checkOrgDisabled(orgId) {
      const total = this.getOrgDeptCount(orgId)
      const used = this.getLockedDeptCount(orgId)
      return used >= total
    },
    // 获取机构科室总数
    getOrgDeptCount(orgId) {
      return this.deptOptions.filter(d => d.institution_id === orgId).length
    },
    // 获取已锁定科室数
    getLockedDeptCount(orgId) {
      return Array.from(this.lockedDepts).filter(id => {
        const dept = this.deptOptions.find(d => d.office_id === id)
        return dept?.orgId === orgId
      }).length
    },
    // 更新锁定状态
    updateLockStatus() {
      // 合并所有已选科室
      const allSelected = this.configList.flatMap(c => c.office_ids)
      this.lockedDepts = new Set(allSelected)
      //console.log('this.lockedDepts',this.lockedDepts)
    }
  },
  mounted () {
    // 获取机构
    this.getInstitutionListLiteFn()
    // 获取所有科室
    this.beganGetAllAuthOfficeList()
    // 获取权限列表
    this.beganGetExportAuthList()
  },
}
</script>
<style lang="less" scoped>
.crumbsCon {
  display: flex;
}
.importTip{
  display: flex;
  height: 40px;
  align-items: center;
  padding-left:10px;
  .headIcon{
    width: 3px;
    height: 16px;
    background: #0A70B0;
    border-radius: 3px;
    margin-right: 5px;
  }
  .importTipTit{
    font-weight: 700;
    font-size: 15px;
    color: #333333;
    margin-right: 5px;
  }
  .importTipText{
    font-size: 14px;
    color: #EF8900;  
  }
}
.queryCon{
  display: flex;
  align-items: center;
  .search-bar-label{
    font-size: 14px;
    color: #333333;   
  }
}
.userListoperate-btn {
  display: inline-block;
  width:80px;
  height: 32px;
  text-align: center;
  line-height: 32px;
  cursor: pointer;
  border-radius: 3px;
}
.caseExportCon{
  height:100%;
}
.caseExportContainer{
  height: calc(100% - 46px);
  .caseExportContent{
    padding: 10px;
    height: calc(100% - 72px);
    ::v-deep .allInspect{
     height: 100%;
     .el-table .cell{
       padding-left: 5px!important;
       padding-right: 5px!important;  
     }
     .el-table__body-wrapper{
        height: calc(100% - 40px);
        overflow-y: auto;
      }
      .radioBox{
       .el-radio__inner{
        width:16px;
        height: 16px;
       }
       .el-radio__inner::after{
         width:6px!important;
         height: 6px!important;
       }
      }
   }
 }
}
.blockPage {
  border: 1px solid #eee;
  border-top: none;
}
.pt70{
  padding-bottom: 70px;
}
.select_up {
  position: absolute;
  background: #fff;
  width: calc(100% - 20px);
  bottom: 0;
}
</style>